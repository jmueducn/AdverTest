package gentest.org.jfree.data.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.time.*;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.general.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class TimeSeriesTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                            public void testClone_WithEmptyData() throws CloneNotSupportedException {
                                                                                                // Setup
                                                                                                TimeSeries original = new TimeSeries("Test Series");
                                                                                                
                                                                                                // Exercise
                                                                                                TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                
                                                                                                // Verify
                                                                                                assertNotSame(original, cloned);
                                                                                                assertEquals(original.getDomainDescription(), cloned.getDomainDescription());
                                                                                                assertEquals(original.getRangeDescription(), cloned.getRangeDescription());
                                                                                                assertEquals(original.getTimePeriodClass(), cloned.getTimePeriodClass());
                                                                                                assertEquals(original.getMaximumItemCount(), cloned.getMaximumItemCount());
                                                                                                assertEquals(original.getMaximumItemAge(), cloned.getMaximumItemAge());
                                                                                                assertNotNull(cloned.getItems());
                                                                                                assertEquals(0, cloned.getItemCount());
                                                                                            }

    @Test
                                                                                            public void testClone_WithNonEmptyData() throws CloneNotSupportedException {
                                                                                                // Setup
                                                                                                TimeSeries original = new TimeSeries("Test Series");
                                                                                                TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                                TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                                
                                                                                                // Mock deep clone behavior
                                                                                                List<TimeSeriesDataItem> originalData = new ArrayList<>();
                                                                                                originalData.add(item1);
                                                                                                originalData.add(item2);
                                                                                                
                                                                                                // Using reflection to set the data since it's protected
                                                                                                try {
                                                                                                    java.lang.reflect.Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                    dataField.setAccessible(true);
                                                                                                    dataField.set(original, originalData);
                                                                                                } catch (Exception e) {
                                                                                                    fail("Failed to set data field via reflection");
                                                                                                }
                                                                                                
                                                                                                // Exercise
                                                                                                TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                
                                                                                                // Verify
                                                                                                assertNotSame(original, cloned);
                                                                                                assertEquals(original.getItemCount(), cloned.getItemCount());
                                                                                                assertNotSame(original.getItems(), cloned.getItems());
                                                                                                assertEquals(original.getItems().size(), cloned.getItems().size());
                                                                                            }

    @Test
                                                                                            public void testClone_WithModifiedSettings() throws CloneNotSupportedException {
                                                                                                // Setup
                                                                                                TimeSeries original = new TimeSeries("Test Series");
                                                                                                original.setDomainDescription("Modified Domain");
                                                                                                original.setRangeDescription("Modified Range");
                                                                                                original.setMaximumItemCount(100);
                                                                                                original.setMaximumItemAge(500L);
                                                                                                
                                                                                                // Exercise
                                                                                                TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals("Modified Domain", cloned.getDomainDescription());
                                                                                                assertEquals("Modified Range", cloned.getRangeDescription());
                                                                                                assertEquals(100, cloned.getMaximumItemCount());
                                                                                                assertEquals(500L, cloned.getMaximumItemAge());
                                                                                            }

    @Test
                                                                                            public void testClone_VerifyDeepCopy() throws CloneNotSupportedException {
                                                                                                // Setup
                                                                                                TimeSeries original = new TimeSeries("Test Series");
                                                                                                TimeSeriesDataItem originalItem = mock(TimeSeriesDataItem.class);
                                                                                                
                                                                                                List<TimeSeriesDataItem> originalData = new ArrayList<>();
                                                                                                originalData.add(originalItem);
                                                                                                
                                                                                                try {
                                                                                                    java.lang.reflect.Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                    dataField.setAccessible(true);
                                                                                                    dataField.set(original, originalData);
                                                                                                } catch (Exception e) {
                                                                                                    fail("Failed to set data field via reflection");
                                                                                                }
                                                                                                
                                                                                                // Exercise
                                                                                                TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                
                                                                                                // Verify deep copy
                                                                                                List<TimeSeriesDataItem> clonedData = cloned.getItems();
                                                                                                assertEquals(1, clonedData.size());
                                                                                                assertNotSame(originalData.get(0), clonedData.get(0));
                                                                                            }

    @Test
                                                                                            public void testClone_VerifyIndependence() throws CloneNotSupportedException {
                                                                                                // Setup
                                                                                                TimeSeries original = new TimeSeries("Test Series");
                                                                                                original.setMaximumItemCount(50);
                                                                                                
                                                                                                // Exercise
                                                                                                TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                cloned.setMaximumItemCount(100);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(50, original.getMaximumItemCount());
                                                                                                assertEquals(100, cloned.getMaximumItemCount());
                                                                                            }

    @Test
                                                                                            public void testClone_WithNullDataField() throws CloneNotSupportedException {
                                                                                                // Setup
                                                                                                TimeSeries original = new TimeSeries("Test Series");
                                                                                                try {
                                                                                                    java.lang.reflect.Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                    dataField.setAccessible(true);
                                                                                                    dataField.set(original, null);
                                                                                                } catch (Exception e) {
                                                                                                    fail("Failed to set data field via reflection");
                                                                                                }
                                                                                                
                                                                                                // Exercise
                                                                                                TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                
                                                                                                // Verify
                                                                                                assertNull(cloned.getItems());
                                                                                            }

    @Test
                                                                                        public void testDeleteStartEndParameters() {
                                                                                            // Setup test data
                                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                                            
                                                                                            // Add 5 items to the series (indices 0-4)
                                                                                            for (int i = 0; i < 5; i++) {
                                                                                                series.add(new Day(i+1, 1, 2023), i);
                                                                                            }
                                                                                            
                                                                                            // Verify initial count
                                                                                            assertEquals(5, series.getItemCount());
                                                                                            
                                                                                            // Test delete from index 1 to 3 (should delete items at 1, 2, 3)
                                                                                            series.delete(1, 3);
                                                                                            
                                                                                            // Verify remaining items
                                                                                            assertEquals(2, series.getItemCount());
                                                                                            
                                                                                            // Verify correct items were deleted
                                                                                            // Original items were 0,1,2,3,4
                                                                                            // After deleting 1-3, should have 0 and 4 left
                                                                                            assertEquals(0, series.getValue(0).intValue());  // First item (index 0)
                                                                                            assertEquals(4, series.getValue(1).intValue());  // Now at index 1 (original index 4)
                                                                                            
                                                                                            // In the mutated version, parameters would be swapped
                                                                                            // So delete(1,3) would become delete(3,1)
                                                                                            // This would delete items 1,2,3 in original behavior
                                                                                            // But in mutated version would try to delete from 3 to 1 (invalid range)
                                                                                            // Either it would throw exception or delete nothing
                                                                                            // Our assertions would fail in either case
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                public void testDeleteShouldThrowWhenStartGreaterThanEnd() {
                                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                    // This should throw IllegalArgumentException because 3 > 2
                                                                                    timeSeries.delete(3, 2);
                                                                                }

    @Test
                                                                                public void testDeleteSingleItem() {
                                                                                    // Create a time series and populate it with test data
                                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                    for (int i = 0; i < 5; i++) {
                                                                                        timeSeries.add(new Day(i + 1, 1, 2000), i * 10);
                                                                                    }
                                                                                    
                                                                                    // Get the data items from the time series
                                                                                    List<TimeSeriesDataItem> mockData = timeSeries.getItems();
                                                                                    List<TimeSeriesDataItem> originalData = new ArrayList<>(mockData);
                                                                                    
                                                                                    // Delete single item at index 2
                                                                                    timeSeries.delete(2, 2);
                                                                                    
                                                                                    assertEquals(4, timeSeries.getItemCount());
                                                                                    // Verify all items except index 2 remain
                                                                                    assertSame(originalData.get(0), timeSeries.getDataItem(0));
                                                                                    assertSame(originalData.get(1), timeSeries.getDataItem(1));
                                                                                    assertSame(originalData.get(3), timeSeries.getDataItem(2));
                                                                                    assertSame(originalData.get(4), timeSeries.getDataItem(3));
                                                                                }

    @Test
                                                                        public void testDeleteRemovesCorrectItems() {
                                                                            // Create test data
                                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                            List<TimeSeriesDataItem> mockData = new ArrayList<>();
                                                                            
                                                                            // Add 5 items to the series using Day as the time period
                                                                            for (int i = 0; i < 5; i++) {
                                                                                RegularTimePeriod period = new Day(new Date(1000000000000L + (i * 86400000L))); // Adding i days to base date
                                                                                TimeSeriesDataItem item = new TimeSeriesDataItem(period, i);
                                                                                mockData.add(item);
                                                                                timeSeries.add(item);
                                                                            }
                                                                            
                                                                            // Create a copy of original data for verification
                                                                            List<TimeSeriesDataItem> originalData = new ArrayList<>(mockData);
                                                                            
                                                                            // Delete items from index 1 to 3 (inclusive)
                                                                            timeSeries.delete(1, 3);
                                                                            
                                                                            // Verify correct items were removed
                                                                            assertEquals(2, timeSeries.getItemCount()); // Should be 5 - (3-1+1) = 2
                                                                            assertSame(originalData.get(0), timeSeries.getDataItem(0)); // First item remains
                                                                            assertSame(originalData.get(4), timeSeries.getDataItem(1)); // Last item remains
                                                                            
                                                                            // With the mutant, this would fail because it would delete wrong indexes
                                                                        }

    @Test
                                                                    public void testDeleteWhenStartEqualsEnd() {
                                                                        // Setup test data
                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                        series.add(new Day(1, 1, 2023), 100); // index 0
                                                                        series.add(new Day(2, 1, 2023), 200); // index 1
                                                                        series.add(new Day(3, 1, 2023), 300); // index 2
                                                                        
                                                                        // Record initial state
                                                                        int initialItemCount = series.getItemCount();
                                                                        
                                                                        // Test the boundary case where start equals end
                                                                        series.delete(1, 1);
                                                                        
                                                                        // Verify behavior
                                                                        if (initialItemCount - 1 == series.getItemCount()) {
                                                                            // Original behavior - one item was deleted
                                                                            System.out.println("Original behavior detected - test passes");
                                                                        } else if (initialItemCount == series.getItemCount()) {
                                                                            // Mutated behavior - no deletion occurred
                                                                            fail("Mutant detected: No item was deleted when start == end");
                                                                        } else {
                                                                            fail("Unexpected behavior: Item count changed by " + 
                                                                                (initialItemCount - series.getItemCount()));
                                                                        }
                                                                        
                                                                        // Additional verification - check specific item was removed
                                                                        try {
                                                                            series.getValue(1);
                                                                            if (initialItemCount - 1 == series.getItemCount()) {
                                                                                fail("Item at index 1 was not properly removed");
                                                                            }
                                                                        } catch (IndexOutOfBoundsException e) {
                                                                            // Expected if item was properly removed
                                                                        }
                                                                    }

    @Test
                                                                public void testDelete_WhenStartEqualsEnd_ShouldNotThrowException() {
                                                                    // Create mock data list
                                                                    List<TimeSeriesDataItem> mockData = mock(List.class);
                                                                    
                                                                    // Create time series with mock data
                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                    
                                                                    // Use reflection to set the private data field
                                                                    try {
                                                                        Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                        dataField.setAccessible(true);
                                                                        dataField.set(timeSeries, mockData);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set mock data via reflection");
                                                                    }
                                                                    
                                                                    // Setup - mock data to have at least one item
                                                                    when(mockData.size()).thenReturn(1);
                                                                    
                                                                    // This should NOT throw exception in original code
                                                                    timeSeries.delete(0, 0);
                                                                    
                                                                    // Verify one item was removed
                                                                    verify(mockData, times(1)).remove(0);
                                                                }

    @Test
                                                                public void testDelete_WhenStartEqualsEnd_ShouldThrowExceptionForMutant() {
                                                                    // Setup test objects
                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                    List mockData = mock(List.class);
                                                                    
                                                                    // Use reflection to set private data field since we need to verify interactions
                                                                    try {
                                                                        Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                        dataField.setAccessible(true);
                                                                        dataField.set(timeSeries, mockData);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                    }
                                                                    
                                                                    // Setup expectation for mutant behavior
                                                                    thrown.expect(IllegalArgumentException.class);
                                                                    thrown.expectMessage("Requires start <= end.");
                                                                    
                                                                    // This would throw exception in mutated code (start == end)
                                                                    timeSeries.delete(0, 0);
                                                                    
                                                                    // Verify no interaction with data list
                                                                    verify(mockData, never()).remove(anyInt());
                                                                }

    @Test
                                                            public void testDeleteStartEndShouldOnlyDeleteWhenEndLessThanStart() {
                                                                // Setup test data
                                                                TimeSeries series = new TimeSeries("Test");
                                                                series.add(new Day(1, 1, 2020), 10.0); // index 0
                                                                series.add(new Day(2, 1, 2020), 20.0); // index 1
                                                                series.add(new Day(3, 1, 2020), 30.0); // index 2
                                                                
                                                                // Test case where end >= start (should not delete in original)
                                                                series.delete(1, 2);
                                                                
                                                                // Verify items were NOT deleted (would be deleted in mutant)
                                                                assertEquals(3, series.getItemCount());
                                                                assertEquals(10.0, series.getValue(0));
                                                                assertEquals(20.0, series.getValue(1));
                                                                assertEquals(30.0, series.getValue(2));
                                                                
                                                                // Test case where end < start (should delete in original)
                                                                series.delete(2, 1);
                                                                
                                                                // Verify items were deleted (same in both original and mutant)
                                                                assertEquals(1, series.getItemCount());
                                                                assertEquals(10.0, series.getValue(0));
                                                            }

    @Test
                                                        public void testDeleteShouldNotThrowExceptionWhenStartLessThanEnd() {
                                                            // Setup - create a valid case where start < end
                                                            int start = 1;
                                                            int end = 3;
                                                            
                                                            // Create mock and test objects
                                                            List mockData = mock(List.class);
                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                            
                                                            // Use reflection to set private data field
                                                            try {
                                                                Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                dataField.setAccessible(true);
                                                                dataField.set(timeSeries, mockData);
                                                            } catch (Exception e) {
                                                                fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                            }
                                                            
                                                            // Mock the data size to avoid IndexOutOfBoundsException
                                                            when(mockData.size()).thenReturn(4);
                                                            
                                                            try {
                                                                timeSeries.delete(start, end);
                                                                // If we get here, the test passes for original code
                                                                // Mutated code would throw exception and fail
                                                            } catch (IllegalArgumentException e) {
                                                                fail("Should not throw exception when start < end");
                                                            }
                                                            
                                                            // Verify the remove operations were called
                                                            verify(mockData, times(3)).remove(start);
                                                        }

    @Test
                                                        public void testDeleteShouldNotThrowExceptionWhenStartEqualsEnd() {
                                                            // Setup - create a valid case where start == end
                                                            int start = 2;
                                                            int end = 2;
                                                            
                                                            // Initialize required objects
                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                            List mockData = mock(List.class);
                                                            
                                                            // Use reflection to set the private data field
                                                            try {
                                                                Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                dataField.setAccessible(true);
                                                                dataField.set(timeSeries, mockData);
                                                            } catch (Exception e) {
                                                                fail("Failed to set mock data field using reflection");
                                                            }
                                                            
                                                            // Mock the data size to avoid IndexOutOfBoundsException
                                                            when(mockData.size()).thenReturn(3);
                                                            
                                                            try {
                                                                timeSeries.delete(start, end);
                                                                // If we get here, the test passes for original code
                                                                // Mutated code would throw exception and fail
                                                            } catch (IllegalArgumentException e) {
                                                                fail("Should not throw exception when start == end");
                                                            }
                                                            
                                                            // Verify the remove operation was called once
                                                            verify(mockData, times(1)).remove(start);
                                                        }

    @Test
                                                        public void testDeleteWithInvalidPeriodThrowsIllegalArgumentException() {
                                                            // Setup
                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                            RegularTimePeriod invalidPeriod = mock(RegularTimePeriod.class);
                                                            
                                                            // Mock the period to represent invalid case (start > end)
                                                            when(invalidPeriod.compareTo(any(RegularTimePeriod.class))).thenReturn(1);
                                                            
                                                            // Expect IllegalArgumentException (original behavior)
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("Requires start <= end.");
                                                            
                                                            // Execute
                                                            timeSeries.delete(invalidPeriod);
                                                            
                                                            // Verification is handled by ExpectedException rule
                                                        }

    @Test
                                                public void testDeleteThrowsIllegalArgumentExceptionWhenStartGreaterThanEnd() {
                                                    // Setup
                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                    // Add some dummy data to ensure the list isn't empty
                                                    timeSeries.add(new TimeSeriesDataItem(mock(RegularTimePeriod.class), 1.0));
                                                    
                                                    // Set expectation
                                                    thrown.expect(IllegalArgumentException.class);
                                                    thrown.expectMessage("Requires start <= end.");
                                                    
                                                    // Test - start > end should throw IllegalArgumentException
                                                    timeSeries.delete(1, 0);
                                                }

    @Test
                                                public void testDeleteRangeShouldRemoveAllItemsInclusive() {
                                                    // Setup
                                                    TimeSeries series = new TimeSeries("Test Series");
                                                    
                                                    // Add 5 items to the series (indices 0-4)
                                                    for (int i = 0; i < 5; i++) {
                                                        series.add(new Day(i+1, 1, 2000), i*10);
                                                    }
                                                    
                                                    int initialCount = series.getItemCount();
                                                    
                                                    // Test deletion from index 1 to 3 (should remove 3 items: 1, 2, 3)
                                                    int start = 1;
                                                    int end = 3;
                                                    int expectedRemoved = end - start + 1; // Should be 3 items
                                                    
                                                    // Execute
                                                    series.delete(start, end);
                                                    
                                                    // Verify
                                                    int finalCount = series.getItemCount();
                                                    assertEquals("Should have removed " + expectedRemoved + " items", 
                                                                 initialCount - expectedRemoved, finalCount);
                                                    
                                                    // Verify the remaining items
                                                    // Index 0 should remain
                                                    assertNotNull("First item should remain", series.getDataItem(0));
                                                    // Index 1 should now be the original index 4
                                                    assertNotNull("Last original item should remain", series.getDataItem(1));
                                                    assertEquals("Remaining item value should be 40", 
                                                                 40.0, series.getValue(1).doubleValue(), 0.0001);
                                                }

    @Test
                                        public void testDeleteShouldRemoveAllElementsInInclusiveRange() {
                                            // Setup - create TimeSeries with sample data
                                            TimeSeries series = new TimeSeries("Test");
                                            List<TimeSeriesDataItem> mockData = new ArrayList<>();
                                            for (int i = 0; i < 5; i++) {
                                                mockData.add(new TimeSeriesDataItem(new Day(i+1, 1, 2023), i));
                                            }
                                            
                                            // Use reflection to set the protected data field
                                            try {
                                                Field dataField = TimeSeries.class.getDeclaredField("data");
                                                dataField.setAccessible(true);
                                                dataField.set(series, mockData);
                                            } catch (Exception e) {
                                                fail("Failed to set up test data using reflection: " + e.getMessage());
                                            }
                                            
                                            // Test parameters - delete elements 1 through 3 (indices 1-3)
                                            int start = 1;
                                            int end = 3;
                                            int expectedRemovedCount = end - start + 1; // Should be 3 items removed
                                            
                                            // Execute
                                            series.delete(start, end);
                                            
                                            // Verify
                                            // Original should leave 2 items (5 - 3 = 2)
                                            // Mutant would leave 3 items (5 - 2 = 3) because loop runs one less time
                                            assertEquals("Should have correct remaining items after deletion", 
                                                5 - expectedRemovedCount, series.getItemCount());
                                            
                                            // Additional verification - first remaining item should be original index 0
                                            assertEquals("First item should remain unchanged",
                                                0, series.getValue(0).intValue());
                                            // Last remaining item should be original index 4
                                            assertEquals("Last item should remain unchanged",
                                                4, series.getValue(series.getItemCount() - 1).intValue());
                                        }

    @Test
                    public void testDeleteRangeShouldRemoveAllItemsInRange() {
                        // Setup - create a time series with 5 items
                        org.jfree.data.time.TimeSeries series = new org.jfree.data.time.TimeSeries("Test Series");
                        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(1, 1, 2023);
                        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(2, 1, 2023);
                        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, 1, 2023);
                        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(4, 1, 2023);
                        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(5, 1, 2023);
                        
                        series.add(day1, 1.0);
                        series.add(day2, 2.0);
                        series.add(day3, 3.0);
                        series.add(day4, 4.0);
                        series.add(day5, 5.0);
                        
                        // Verify initial state
                        assertEquals(5, series.getItemCount());
                        
                        // Test - delete items from index 1 to 3 (should remove day2, day3, day4)
                        series.delete(1, 3);
                        
                        // Verify - should have 2 items left (day1 and day5)
                        assertEquals(2, series.getItemCount());
                        assertEquals(1.0, series.getValue(0).doubleValue(), 0.0001);  // day1 remains
                        assertEquals(5.0, series.getValue(1).doubleValue(), 0.0001);  // day5 remains
                        
                        // Verify the exact items that should be removed are gone
                        try {
                            series.getValue(day2);
                            fail("day2 should have been removed");
                        } catch (org.jfree.data.UnknownKeyException e) {
                            // expected
                        }
                        try {
                            series.getValue(day3);
                            fail("day3 should have been removed");
                        } catch (org.jfree.data.UnknownKeyException e) {
                            // expected
                        }
                        try {
                            series.getValue(day4);
                            fail("day4 should have been removed");
                        } catch (org.jfree.data.UnknownKeyException e) {
                            // expected
                        }
                    }

    @Test
                public void testDeleteShouldRemoveAllElementsFromStartToEndInclusive() {
                    // Setup
                    TimeSeries series = new TimeSeries("Test Series");
                    for (int i = 0; i < 5; i++) {
                        series.add(new TimeSeriesDataItem(new org.jfree.data.time.Day(i+1, 1, 2023), i));
                    }
                    
                    int originalSize = series.getItemCount();
                    int start = 1;
                    int end = 3;
                    int expectedRemovals = end - start + 1;
                    
                    // Action
                    series.delete(start, end);
                    
                    // Assertions
                    // Verify correct number of elements removed
                    assertEquals(originalSize - expectedRemovals, series.getItemCount());
                    
                    // Verify remaining elements
                    // First element (index 0) should remain
                    org.jfree.data.time.Day firstDay = (org.jfree.data.time.Day) series.getTimePeriod(0);
                    assertEquals(1, firstDay.getDayOfMonth());  // Use getDayOfMonth() instead of getDay()
                    // Next element should be original index 4 (since 1-3 were removed)
                    org.jfree.data.time.Day nextDay = (org.jfree.data.time.Day) series.getTimePeriod(1);
                    assertEquals(5, nextDay.getDayOfMonth());  // Use getDayOfMonth() instead of getDay()
                    
                    // Verify boundary case: delete single element (start == end)
                    series.delete(0, 0);
                    assertEquals(originalSize - expectedRemovals - 1, series.getItemCount());
                }

    @Test
        public void testDelete_ShouldRemoveCorrectItemWhenMultipleItemsExist() throws Exception {
            // Setup test data
            TimeSeries series = new TimeSeries("Test");
            List<TimeSeriesDataItem> data = new ArrayList<>();
            
            // Create mock periods and items
            RegularTimePeriod period1 = mock(RegularTimePeriod.class);
            RegularTimePeriod period2 = mock(RegularTimePeriod.class);
            TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
            TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
            
            // Add items to test data
            data.add(item1);
            data.add(item2);
            
            // Set up series to use our test data using reflection
            Field dataField = TimeSeries.class.getDeclaredField("data");
            dataField.setAccessible(true);
            dataField.set(series, data);
            
            // Mock getIndex to return 0 for period1 (first item)
            when(series.getIndex(period1)).thenReturn(0);
            
            // Execute
            series.delete(period1);
            
            // Verify correct item was removed
            List<TimeSeriesDataItem> seriesData = (List<TimeSeriesDataItem>) dataField.get(series);
            assertEquals(1, seriesData.size());
            assertSame(item2, seriesData.get(0));  // Only item2 should remain
            
            // Verify the removed item was item1 (would fail with mutant since mutant would remove last item)
            verify(item1, never()).getPeriod();  // Additional verification
        }

    @Test
        public void testDeleteRangeShouldRemoveCorrectElements() throws Exception {
            // Setup test data
            TimeSeries series = new TimeSeries("Test");
            List<TimeSeriesDataItem> data = new ArrayList<>();
            // Add mock items to the data list
            for (int i = 0; i < 5; i++) {
                TimeSeriesDataItem item = mock(TimeSeriesDataItem.class);
                data.add(item);
            }
            
            // Use reflection to access protected data field
            Field dataField = TimeSeries.class.getDeclaredField("data");
            dataField.setAccessible(true);
            dataField.set(series, data);
            
            // Call the method to test
            series.delete(1, 3); // Should remove indices 1, 2, 3
            
            // Verify correct elements were removed
            List<TimeSeriesDataItem> seriesData = (List<TimeSeriesDataItem>) dataField.get(series);
            assertEquals(2, seriesData.size()); // Should have 0 and 4 remaining
            assertSame(data.get(0), seriesData.get(0)); // First element remains
            assertSame(data.get(4), seriesData.get(1)); // Last element remains
            
            // The mutant would fail this test because:
            // - It would remove index 3 three times (leaving indices 0,1,2,4)
            // - Or if end changes during removal, might remove wrong indices
            // - In any case, the final list contents wouldn't match expectation
        }

    @Test
    public void testDeleteShouldRemoveCorrectPeriodNotFirstElement() {
        // Setup - create a time series with multiple periods
        TimeSeries series = new TimeSeries("Test Series");
        RegularTimePeriod period1 = new Day(1, 1, 2023); // will be at index 0
        RegularTimePeriod period2 = new Day(2, 1, 2023); // will be at index 1
        series.add(period1, 10.0);
        series.add(period2, 20.0);
        
        // Mock getIndex to return 1 for period2 (though in real case it would)
        // We need to ensure we're testing the remove behavior, not getIndex
        TimeSeries spySeries = spy(series);
        when(spySeries.getIndex(period2)).thenReturn(1);
        
        // Execute - delete period2 (which should be at index 1)
        spySeries.delete(period2);
        
        // Verify - period2 should be removed, period1 should remain
        // This would fail with the mutant since it would remove index 0 (period1)
        assertEquals(1, spySeries.getItemCount());
        assertEquals(period1, spySeries.getTimePeriod(0));
        
        // Also verify the remaining value is correct
        assertEquals(10.0, spySeries.getValue(0).doubleValue(), 0.0001);
        
        // Verify fireSeriesChanged was called
        verify(spySeries).fireSeriesChanged();
    }

    @Test
    public void testDeleteShouldRemoveElementsFromStartIndex() {
        // Setup - create TimeSeries with sample data
        TimeSeries series = new TimeSeries("Test");
        List<TimeSeriesDataItem> items = new ArrayList<>();
        // Add mock items (we don't need real implementations for this test)
        for (int i = 0; i < 5; i++) {
            items.add(mock(TimeSeriesDataItem.class));
        }
        // Use reflection to set the internal data list since it's protected
        try {
            Field dataField = TimeSeries.class.getDeclaredField("data");
            dataField.setAccessible(true);
            dataField.set(series, new ArrayList<>(items));
        } catch (Exception e) {
            fail("Failed to setup test data");
        }
    
        // Test - delete elements from index 2 to 3 (should remove 2 items)
        series.delete(2, 3);
    
        // Verify - check remaining items
        // Original should have removed indexes 2 and 3, leaving 0,1,4
        // Mutant would remove indexes 0 and 0, leaving 1,2,3,4
        List remainingItems = series.getItems();
        assertEquals(3, remainingItems.size());
        assertSame(items.get(0), remainingItems.get(0));
        assertSame(items.get(1), remainingItems.get(1));
        assertSame(items.get(4), remainingItems.get(2));
    }

}
