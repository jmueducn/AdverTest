package gentest.org.jfree.data.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.time.*;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.general.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class TimeSeriesTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                                                        public void testCreateCopy_EmptySeries_ReturnsEmptyCopy() throws Exception {
                                                                                                                                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                            TimeSeries copy = timeSeries.createCopy(0, 0);
                                                                                                                                                                            
                                                                                                                                                                            assertNotNull(copy);
                                                                                                                                                                            assertEquals(0, copy.getItemCount());
                                                                                                                                                                            assertEquals(timeSeries.getDomainDescription(), copy.getDomainDescription());
                                                                                                                                                                            assertEquals(timeSeries.getRangeDescription(), copy.getRangeDescription());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testCreateCopy_EmptyRange_EndBeforeStartIndex() throws Exception {
                                                                                                                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                            RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                                                                            RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                                                                            
                                                                                                                                                                            // Add some data to the series
                                                                                                                                                                            RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                                                                                                                                                                            series.add(period1, 10.0);
                                                                                                                                                                            
                                                                                                                                                                            // Setup behavior
                                                                                                                                                                            when(start.compareTo(end)).thenReturn(-1);
                                                                                                                                                                            when(series.getIndex(start)).thenReturn(1); // start after all items
                                                                                                                                                                            when(series.getIndex(end)).thenReturn(-1); // end before first item
                                                                                                                                                                            
                                                                                                                                                                            TimeSeries result = series.createCopy(start, end);
                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                            assertEquals(0, result.getItemCount());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testCreateCopy_ValidRange() throws Exception {
                                                                                                                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                            
                                                                                                                                                                            // Create mock periods
                                                                                                                                                                            RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                                                                                                                                                                            RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                                                                                                                                                                            RegularTimePeriod period3 = mock(RegularTimePeriod.class);
                                                                                                                                                                            
                                                                                                                                                                            // Add data to series
                                                                                                                                                                            series.add(period1, 10.0);
                                                                                                                                                                            series.add(period2, 20.0);
                                                                                                                                                                            series.add(period3, 30.0);
                                                                                                                                                                            
                                                                                                                                                                            // Setup behavior
                                                                                                                                                                            when(period1.compareTo(period3)).thenReturn(-1);
                                                                                                                                                                            when(series.getIndex(period1)).thenReturn(0);
                                                                                                                                                                            when(series.getIndex(period3)).thenReturn(2);
                                                                                                                                                                            
                                                                                                                                                                            // Mock the internal createCopy method
                                                                                                                                                                            TimeSeries mockCopy = mock(TimeSeries.class);
                                                                                                                                                                            when(series.createCopy(0, 2)).thenReturn(mockCopy);
                                                                                                                                                                            
                                                                                                                                                                            TimeSeries result = series.createCopy(period1, period3);
                                                                                                                                                                            assertSame(mockCopy, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testCreateCopy_EndNotInOriginalSeries() throws Exception {
                                                                                                                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                            
                                                                                                                                                                            // Create mock periods
                                                                                                                                                                            RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                                                                                                                                                                            RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                                                                                                                                                                            RegularTimePeriod period3 = mock(RegularTimePeriod.class);
                                                                                                                                                                            RegularTimePeriod endPeriod = mock(RegularTimePeriod.class);
                                                                                                                                                                            
                                                                                                                                                                            // Add data to series
                                                                                                                                                                            series.add(period1, 10.0);
                                                                                                                                                                            series.add(period2, 20.0);
                                                                                                                                                                            series.add(period3, 30.0);
                                                                                                                                                                            
                                                                                                                                                                            // Setup behavior
                                                                                                                                                                            when(period1.compareTo(endPeriod)).thenReturn(-1);
                                                                                                                                                                            when(series.getIndex(period1)).thenReturn(0);
                                                                                                                                                                            when(series.getIndex(endPeriod)).thenReturn(-4); // Not in series
                                                                                                                                                                            
                                                                                                                                                                            // Mock the internal createCopy method
                                                                                                                                                                            TimeSeries mockCopy = mock(TimeSeries.class);
                                                                                                                                                                            when(series.createCopy(0, 2)).thenReturn(mockCopy); // endIndex adjusted to 2
                                                                                                                                                                            
                                                                                                                                                                            TimeSeries result = series.createCopy(period1, endPeriod);
                                                                                                                                                                            assertSame(mockCopy, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                public void testCreateCopy_SingleItemSeries_ReturnsCorrectCopy() throws Exception {
                                                                                                                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                    TimeSeriesDataItem mockItem = mock(TimeSeriesDataItem.class);
                                                                                                                                                                    when(mockItem.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                                                                                    
                                                                                                                                                                    // Add mock item to the series using public method
                                                                                                                                                                    timeSeries.add(mockItem);
                                                                                                                                                                    
                                                                                                                                                                    TimeSeries copy = timeSeries.createCopy(0, 0);
                                                                                                                                                                    
                                                                                                                                                                    assertNotNull(copy);
                                                                                                                                                                    assertEquals(1, copy.getItemCount());
                                                                                                                                                                    verify(mockItem).clone();
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testCreateCopy_MultipleItems_ReturnsCorrectSubset() throws Exception {
                                                                                                                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                    
                                                                                                                                                                    // Create mock items
                                                                                                                                                                    TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                                                                                                    TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                                                                                                    TimeSeriesDataItem item3 = mock(TimeSeriesDataItem.class);
                                                                                                                                                                    
                                                                                                                                                                    when(item1.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                                                                                    when(item2.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                                                                                    when(item3.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                                                                                    
                                                                                                                                                                    // Add mock items to the series
                                                                                                                                                                    timeSeries.add(item1);
                                                                                                                                                                    timeSeries.add(item2);
                                                                                                                                                                    timeSeries.add(item3);
                                                                                                                                                                    
                                                                                                                                                                    // Test copying middle items
                                                                                                                                                                    TimeSeries copy = timeSeries.createCopy(1, 2);
                                                                                                                                                                    
                                                                                                                                                                    assertNotNull(copy);
                                                                                                                                                                    assertEquals(2, copy.getItemCount());
                                                                                                                                                                    verify(item1, never()).clone();
                                                                                                                                                                    verify(item2).clone();
                                                                                                                                                                    verify(item3).clone();
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testCreateCopy_EntireSeries_ReturnsCompleteCopy() throws Exception {
                                                                                                                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                    
                                                                                                                                                                    // Create mock items
                                                                                                                                                                    TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                                                                                                    TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                                                                                                    
                                                                                                                                                                    when(item1.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                                                                                    when(item2.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                                                                                    
                                                                                                                                                                    // Add mock items to the series
                                                                                                                                                                    timeSeries.add(item1);
                                                                                                                                                                    timeSeries.add(item2);
                                                                                                                                                                    
                                                                                                                                                                    TimeSeries copy = timeSeries.createCopy(0, 1);
                                                                                                                                                                    
                                                                                                                                                                    assertNotNull(copy);
                                                                                                                                                                    assertEquals(2, copy.getItemCount());
                                                                                                                                                                    verify(item1).clone();
                                                                                                                                                                    verify(item2).clone();
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testCreateCopy_CloneThrowsException_StillReturnsCopy() throws Exception {
                                                                                                                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                    
                                                                                                                                                                    // Create mock items
                                                                                                                                                                    TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                                                                                                    TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                                                                                                    
                                                                                                                                                                    when(item1.clone()).thenThrow(new CloneNotSupportedException());
                                                                                                                                                                    when(item2.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                                                                                    
                                                                                                                                                                    // Add mock items to the series using public API
                                                                                                                                                                    timeSeries.add(item1);
                                                                                                                                                                    timeSeries.add(item2);
                                                                                                                                                                    
                                                                                                                                                                    TimeSeries copy = timeSeries.createCopy(0, 1);
                                                                                                                                                                    
                                                                                                                                                                    assertNotNull(copy);
                                                                                                                                                                    // Even though cloning one item failed, the copy should still be created
                                                                                                                                                                    // with the items that could be cloned
                                                                                                                                                                    assertEquals(1, copy.getItemCount());
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testCreateCopy_EmptyRange_StartAfterLastItem() throws Exception {
                                                                                                                                                                    TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                    RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                                                                    RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                                                                    
                                                                                                                                                                    // Setup behavior
                                                                                                                                                                    when(start.compareTo(end)).thenReturn(-1);
                                                                                                                                                                    when(series.getIndex(start)).thenReturn(-(series.getItems().size() + 1));
                                                                                                                                                                    
                                                                                                                                                                    TimeSeries result = series.createCopy(start, end);
                                                                                                                                                                    assertNotNull(result);
                                                                                                                                                                    assertEquals(0, result.getItemCount());
                                                                                                                                                                }

    @Test
                                                                                                                                                            public void testCreateCopy_NegativeStartIndex_ThrowsIllegalArgumentException() throws CloneNotSupportedException {
                                                                                                                                                                TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                
                                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                thrown.expectMessage("Requires start >= 0.");
                                                                                                                                                                
                                                                                                                                                                timeSeries.createCopy(-1, 5);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testCreateCopy_EndIndexLessThanStart_ThrowsIllegalArgumentException() {
                                                                                                                                                                TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                
                                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                thrown.expectMessage("Requires start <= end.");
                                                                                                                                                                
                                                                                                                                                                try {
                                                                                                                                                                    timeSeries.createCopy(5, 4);
                                                                                                                                                                } catch (CloneNotSupportedException e) {
                                                                                                                                                                    // This shouldn't happen in this test case
                                                                                                                                                                    throw new RuntimeException("Unexpected CloneNotSupportedException", e);
                                                                                                                                                                }
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testCreateCopy_NullStartParameter() throws CloneNotSupportedException {
                                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                thrown.expectMessage("Null 'start' argument.");
                                                                                                                                                                series.createCopy(null, mock(RegularTimePeriod.class));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testCreateCopy_NullEndParameter() throws CloneNotSupportedException {
                                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                thrown.expectMessage("Null 'end' argument.");
                                                                                                                                                                series.createCopy(mock(RegularTimePeriod.class), null);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testCreateCopy_StartAfterEnd() throws CloneNotSupportedException {
                                                                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                                RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                                                                                                RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                                                                                                
                                                                                                                                                                when(start.compareTo(end)).thenReturn(1);
                                                                                                                                                                
                                                                                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                thrown.expectMessage("Requires start on or before end.");
                                                                                                                                                                series.createCopy(start, end);
                                                                                                                                                            }

    @Test
                                                                                                                                                        public void testCreateCopyBoundaryIndices() throws SeriesException, CloneNotSupportedException {
                                                                                                                                                            // Setup test data
                                                                                                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                            RegularTimePeriod period1 = new Day(1, 1, 2000);
                                                                                                                                                            RegularTimePeriod period2 = new Day(2, 1, 2000);
                                                                                                                                                            RegularTimePeriod period3 = new Day(3, 1, 2000);
                                                                                                                                                            
                                                                                                                                                            series.add(period1, 1.0);
                                                                                                                                                            series.add(period2, 2.0);
                                                                                                                                                            series.add(period3, 3.0);
                                                                                                                                                            
                                                                                                                                                            // Test full range copy
                                                                                                                                                            TimeSeries copy1 = series.createCopy(0, 2);
                                                                                                                                                            assertEquals(3, copy1.getItemCount());
                                                                                                                                                            
                                                                                                                                                            // Test single item copy (boundary case)
                                                                                                                                                            TimeSeries copy2 = series.createCopy(1, 1);
                                                                                                                                                            assertEquals(1, copy2.getItemCount());
                                                                                                                                                            assertEquals(2.0, copy2.getValue(0));
                                                                                                                                                            
                                                                                                                                                            // Test partial range copy (including boundary)
                                                                                                                                                            TimeSeries copy3 = series.createCopy(0, 1);
                                                                                                                                                            assertEquals(2, copy3.getItemCount());
                                                                                                                                                            assertEquals(1.0, copy3.getValue(0));
                                                                                                                                                            assertEquals(2.0, copy3.getValue(1));
                                                                                                                                                            
                                                                                                                                                            // Test with negative indices (should throw exception)
                                                                                                                                                            try {
                                                                                                                                                                series.createCopy(-1, 1);
                                                                                                                                                                fail("Should have thrown IllegalArgumentException");
                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                // Expected
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Test with invalid range (should throw exception)
                                                                                                                                                            try {
                                                                                                                                                                series.createCopy(2, 1);
                                                                                                                                                                fail("Should have thrown IllegalArgumentException");
                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                // Expected
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Test empty series case
                                                                                                                                                            TimeSeries emptySeries = new TimeSeries("Empty");
                                                                                                                                                            TimeSeries emptyCopy = emptySeries.createCopy(0, 0);
                                                                                                                                                            assertEquals(0, emptyCopy.getItemCount());
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testCreateCopyWithNonExistentEndPeriod() throws CloneNotSupportedException {
                                                                                                                                                        // Setup test data
                                                                                                                                                        TimeSeries series = new TimeSeries("Test");
                                                                                                                                                        Day day1 = new Day(1, 1, 2000);
                                                                                                                                                        Day day2 = new Day(2, 1, 2000);
                                                                                                                                                        Day day3 = new Day(3, 1, 2000);
                                                                                                                                                        
                                                                                                                                                        // Add data points
                                                                                                                                                        series.add(day1, 1.0);
                                                                                                                                                        series.add(day2, 2.0);
                                                                                                                                                        series.add(day3, 3.0);
                                                                                                                                                        
                                                                                                                                                        // Create a day that doesn't exist in the series (between day2 and day3)
                                                                                                                                                        Day nonExistentEnd = new Day(2, 2, 2000);
                                                                                                                                                        
                                                                                                                                                        // Test the copy
                                                                                                                                                        TimeSeries copy = series.createCopy(day1, nonExistentEnd);
                                                                                                                                                        
                                                                                                                                                        // Verify the copy contains the correct range (day1 to day2)
                                                                                                                                                        assertEquals(2, copy.getItemCount());
                                                                                                                                                        assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                                                                                                                                                        assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
                                                                                                                                                        
                                                                                                                                                        // The mutant would incorrectly calculate endIndex and might:
                                                                                                                                                        // - Include day3 in the copy (wrong range)
                                                                                                                                                        // - Or return empty series (wrong emptyRange determination)
                                                                                                                                                    }

    @Test
                                                                                                                                                public void testCreateCopyWithEndPeriodNotInSeries() throws Exception {
                                                                                                                                                    // Setup test data
                                                                                                                                                    TimeSeries series = new TimeSeries("Test");
                                                                                                                                                    Day day1 = new Day(1, 1, 2000);
                                                                                                                                                    Day day2 = new Day(2, 1, 2000);
                                                                                                                                                    Day day3 = new Day(3, 1, 2000);
                                                                                                                                                    series.add(day1, 1.0);
                                                                                                                                                    series.add(day2, 2.0);
                                                                                                                                                    series.add(day3, 3.0);
                                                                                                                                                    
                                                                                                                                                    // Create an end period that doesn't exist in the series
                                                                                                                                                    // This will make getIndex(end) return negative
                                                                                                                                                    Day endDay = new Day(4, 1, 2000);
                                                                                                                                                    
                                                                                                                                                    // Test with start period that exists in series
                                                                                                                                                    TimeSeries copy = series.createCopy(day1, endDay);
                                                                                                                                                    
                                                                                                                                                    // Verify the copy contains the expected range (day1 to day3)
                                                                                                                                                    assertEquals(3, copy.getItemCount());
                                                                                                                                                    assertEquals(1.0, copy.getValue(day1).doubleValue(), 0.0001);
                                                                                                                                                    assertEquals(2.0, copy.getValue(day2).doubleValue(), 0.0001);
                                                                                                                                                    assertEquals(3.0, copy.getValue(day3).doubleValue(), 0.0001);
                                                                                                                                                    
                                                                                                                                                    // Test with start period that also doesn't exist (but before end)
                                                                                                                                                    Day startDay = new Day(5, 1, 2000);
                                                                                                                                                    TimeSeries emptyCopy = series.createCopy(startDay, endDay);
                                                                                                                                                    assertEquals(0, emptyCopy.getItemCount());
                                                                                                                                                }

    @Test(expected = CloneNotSupportedException.class)
                                                                                                                                public void testCreateCopyWithInvalidStart() throws CloneNotSupportedException {
                                                                                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                    timeSeries.createCopy(-1, 2);
                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                public void testCreateCopyWithInvalidRange() throws CloneNotSupportedException {
                                                                                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                    timeSeries.createCopy(3, 1);
                                                                                                                                }

    @Test
                                                                                                                                public void testCreateCopyDetectsEndIndexMutation() {
                                                                                                                                    // Setup test data
                                                                                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                    List<TimeSeriesDataItem> mockData = new ArrayList<TimeSeriesDataItem>();
                                                                                                                                    for (int i = 0; i < 5; i++) {
                                                                                                                                        RegularTimePeriod period = new Day(new Date(i * 1000L * 60 * 60 * 24)); // Using Day as RegularTimePeriod implementation
                                                                                                                                        TimeSeriesDataItem item = new TimeSeriesDataItem(period, i);
                                                                                                                                        mockData.add(item);
                                                                                                                                        timeSeries.add(item);
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    // Test with start=1, end=3 (should copy items at indices 1, 2, 3)
                                                                                                                                    TimeSeries copy = null;
                                                                                                                                    try {
                                                                                                                                        copy = timeSeries.createCopy(1, 3);
                                                                                                                                    } catch (CloneNotSupportedException e) {
                                                                                                                                        fail("Clone not supported: " + e.getMessage());
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    // Verify the copied data contains exactly items 1, 2, 3
                                                                                                                                    List<TimeSeriesDataItem> copiedData;
                                                                                                                                    try {
                                                                                                                                        java.lang.reflect.Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                                        dataField.setAccessible(true);
                                                                                                                                        copiedData = (List<TimeSeriesDataItem>) dataField.get(copy);
                                                                                                                                    } catch (Exception e) {
                                                                                                                                        fail("Failed to verify copied data");
                                                                                                                                        return;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    assertEquals(3, copiedData.size());
                                                                                                                                    assertSame(mockData.get(1), copiedData.get(0));
                                                                                                                                    assertSame(mockData.get(2), copiedData.get(1));
                                                                                                                                    assertSame(mockData.get(3), copiedData.get(2));
                                                                                                                                    
                                                                                                                                    // Test boundary case with end index at last item
                                                                                                                                    TimeSeries boundaryCopy = null;
                                                                                                                                    try {
                                                                                                                                        boundaryCopy = timeSeries.createCopy(0, 4);
                                                                                                                                    } catch (CloneNotSupportedException e) {
                                                                                                                                        fail("Clone not supported: " + e.getMessage());
                                                                                                                                    }
                                                                                                                                    List<TimeSeriesDataItem> boundaryCopiedData;
                                                                                                                                    try {
                                                                                                                                        java.lang.reflect.Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                                        dataField.setAccessible(true);
                                                                                                                                        boundaryCopiedData = (List<TimeSeriesDataItem>) dataField.get(boundaryCopy);
                                                                                                                                    } catch (Exception e) {
                                                                                                                                        fail("Failed to verify boundary copied data");
                                                                                                                                        return;
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    assertEquals(5, boundaryCopiedData.size());
                                                                                                                                    for (int i = 0; i < 5; i++) {
                                                                                                                                        assertSame(mockData.get(i), boundaryCopiedData.get(i));
                                                                                                                                    }
                                                                                                                                }

    @Test
                                                                                                                        public void testCreateCopyWithNonExistentEndPeriod1() throws CloneNotSupportedException {
                                                                                                                            // Setup test data
                                                                                                                            TimeSeries series = new TimeSeries("Test");
                                                                                                                            Day day1 = new Day(1, 1, 2000);
                                                                                                                            Day day2 = new Day(2, 1, 2000);
                                                                                                                            Day day3 = new Day(3, 1, 2000);
                                                                                                                            Day nonExistentEndDay = new Day(4, 1, 2000); // Doesn't exist in series
                                                                                                                            
                                                                                                                            series.add(day1, 1.0);
                                                                                                                            series.add(day2, 2.0);
                                                                                                                            series.add(day3, 3.0);
                                                                                                                            
                                                                                                                            // Test the copy with non-existent end period
                                                                                                                            TimeSeries copy = series.createCopy(day1, nonExistentEndDay);
                                                                                                                            
                                                                                                                            // Verify the copy contains all items up to day3 (since end is after last item)
                                                                                                                            assertEquals(3, copy.getItemCount());
                                                                                                                            assertEquals(1.0, copy.getValue(day1).doubleValue(), 0.0001);
                                                                                                                            assertEquals(2.0, copy.getValue(day2).doubleValue(), 0.0001);
                                                                                                                            assertEquals(3.0, copy.getValue(day3).doubleValue(), 0.0001);
                                                                                                                            
                                                                                                                            // The mutant would incorrectly calculate endIndex as positive number
                                                                                                                            // and likely return wrong items or throw IndexOutOfBoundsException
                                                                                                                        }

    @Test
                                                                                                                        public void testCreateCopyWithEndPeriodInMiddleOfSeries() {
                                                                                                                            // Setup test data
                                                                                                                            TimeSeries series = new TimeSeries("Test");
                                                                                                                            Day day1 = new Day(1, 1, 2000);
                                                                                                                            Day day2 = new Day(2, 1, 2000);
                                                                                                                            Day day3 = new Day(3, 1, 2000);
                                                                                                                            Day nonExistentEndDay = new Day(2, 15, 2000); // Doesn't exist in series
                                                                                                                            
                                                                                                                            series.add(day1, 1.0);
                                                                                                                            series.add(day2, 2.0);
                                                                                                                            series.add(day3, 3.0);
                                                                                                                            
                                                                                                                            // Test the copy with non-existent end period in middle
                                                                                                                            TimeSeries copy = null;
                                                                                                                            try {
                                                                                                                                copy = series.createCopy(day1, nonExistentEndDay);
                                                                                                                            } catch (CloneNotSupportedException e) {
                                                                                                                                fail("CloneNotSupportedException should not be thrown");
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Should include day1 and day2 (since end is between day2 and day3)
                                                                                                                            assertEquals(2, copy.getItemCount());
                                                                                                                            assertEquals(1.0, copy.getValue(day1).doubleValue(), 0.0001);
                                                                                                                            assertEquals(2.0, copy.getValue(day2).doubleValue(), 0.0001);
                                                                                                                            
                                                                                                                            // The mutant would incorrectly calculate endIndex and might include day3
                                                                                                                        }

    @Test
                                                                                                                    public void testCreateCopyBoundaryIndices1() throws SeriesException, CloneNotSupportedException {
                                                                                                                        // Setup test data
                                                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                                                        TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                                                        TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                                                        TimeSeriesDataItem item3 = mock(TimeSeriesDataItem.class);
                                                                                                                        
                                                                                                                        // Mock clone behavior
                                                                                                                        when(item1.clone()).thenReturn(item1);
                                                                                                                        when(item2.clone()).thenReturn(item2);
                                                                                                                        when(item3.clone()).thenReturn(item3);
                                                                                                                        
                                                                                                                        // Add items to series (using reflection since add methods might be complex)
                                                                                                                        try {
                                                                                                                            Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                            dataField.setAccessible(true);
                                                                                                                            List<TimeSeriesDataItem> data = new ArrayList<TimeSeriesDataItem>();
                                                                                                                            data.add(item1);
                                                                                                                            data.add(item2);
                                                                                                                            data.add(item3);
                                                                                                                            dataField.set(series, data);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Test setup failed");
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Test copying the entire range
                                                                                                                        TimeSeries copy = series.createCopy(0, 2);
                                                                                                                        assertEquals(3, copy.getItemCount());  // Should include all 3 items
                                                                                                                        
                                                                                                                        // Test copying boundary indices
                                                                                                                        TimeSeries partialCopy = series.createCopy(1, 1);
                                                                                                                        assertEquals(1, partialCopy.getItemCount());  // Should include only item2
                                                                                                                        
                                                                                                                        // Test copying with end index mutation would affect
                                                                                                                        TimeSeries edgeCopy = series.createCopy(0, 1);
                                                                                                                        assertEquals(2, edgeCopy.getItemCount());  // Should include item1 and item2
                                                                                                                        
                                                                                                                        // Verify the exact items were copied
                                                                                                                        assertEquals(item1, copy.getDataItem(0));
                                                                                                                        assertEquals(item2, copy.getDataItem(1));
                                                                                                                        assertEquals(item3, copy.getDataItem(2));
                                                                                                                        assertEquals(item2, partialCopy.getDataItem(0));
                                                                                                                        assertEquals(item1, edgeCopy.getDataItem(0));
                                                                                                                        assertEquals(item2, edgeCopy.getDataItem(1));
                                                                                                                    }

    @Test
                                                                                                            public void testCreateCopyDoesNotIncludeExtraItem() throws Exception {
                                                                                                                // Setup test data
                                                                                                                TimeSeries series = new TimeSeries("Test Series");
                                                                                                                TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                                                TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                                                TimeSeriesDataItem item3 = mock(TimeSeriesDataItem.class);
                                                                                                                
                                                                                                                // Mock clone behavior
                                                                                                                when(item1.clone()).thenReturn(item1);
                                                                                                                when(item2.clone()).thenReturn(item2);
                                                                                                                when(item3.clone()).thenReturn(item3);
                                                                                                                
                                                                                                                // Add items to series using public API
                                                                                                                series.add(item1);
                                                                                                                series.add(item2);
                                                                                                                series.add(item3);
                                                                                                                
                                                                                                                // Test copying first two items (indices 0 to 1)
                                                                                                                int start = 0;
                                                                                                                int end = 1;
                                                                                                                TimeSeries copy = series.createCopy(start, end);
                                                                                                                
                                                                                                                // Verify correct number of items copied
                                                                                                                assertEquals("Should copy exactly (end-start+1) items", 
                                                                                                                             end - start + 1, copy.getItemCount());
                                                                                                                
                                                                                                                // Verify the last item in copy matches original's end index item
                                                                                                                // This would fail if mutant includes extra item (index 2)
                                                                                                                assertSame("Last copied item should match original's end index item",
                                                                                                                          item2, copy.getDataItem(1));
                                                                                                                
                                                                                                                // Additional check to ensure no extra item was copied
                                                                                                                try {
                                                                                                                    copy.getDataItem(2);
                                                                                                                    fail("Should not have item at index 2 when end=1");
                                                                                                                } catch (IndexOutOfBoundsException e) {
                                                                                                                    // Expected behavior
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                        public void testCreateCopyWithEndPeriodNotInData() {
                                                                                                            // Create time series and add test data
                                                                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                            timeSeries.add(new Day(1, 1, 2023), 1);  // Day 1
                                                                                                            timeSeries.add(new Day(2, 1, 2023), 2);  // Day 2
                                                                                                            timeSeries.add(new Day(3, 1, 2023), 3);  // Day 3
                                                                                                            timeSeries.add(new Day(4, 1, 2023), 4);  // Day 4
                                                                                                            
                                                                                                            // Setup - create start and end periods where end is not in the data
                                                                                                            RegularTimePeriod startPeriod = new Day(2, 1, 2023);  // exists in data
                                                                                                            RegularTimePeriod endPeriod = new Day(4, 1, 2023);    // exists in data
                                                                                                            
                                                                                                            // Create a copy with original behavior
                                                                                                            TimeSeries copy = null;
                                                                                                            try {
                                                                                                                copy = timeSeries.createCopy(startPeriod, endPeriod);
                                                                                                            } catch (CloneNotSupportedException e) {
                                                                                                                fail("CloneNotSupportedException should not be thrown");
                                                                                                            }
                                                                                                            assertEquals(3, copy.getItemCount());  // Days 2,3,4
                                                                                                            
                                                                                                            // Now test with end period not in data (between existing items)
                                                                                                            endPeriod = new Day(3, 15, 2023);  // Doesn't exist in data
                                                                                                            
                                                                                                            // The original would include up to Day 3 (since endIndex-1 points to Day 3)
                                                                                                            // The mutant would include up to Day 4 (since endIndex+1 points to Day 4)
                                                                                                            try {
                                                                                                                copy = timeSeries.createCopy(startPeriod, endPeriod);
                                                                                                            } catch (CloneNotSupportedException e) {
                                                                                                                fail("CloneNotSupportedException should not be thrown");
                                                                                                            }
                                                                                                            
                                                                                                            // Verify correct behavior (should only include up to Day 3)
                                                                                                            assertEquals(2, copy.getItemCount());
                                                                                                            assertEquals(2, copy.getValue(0).intValue());  // Day 2
                                                                                                            assertEquals(3, copy.getValue(1).intValue());  // Day 3
                                                                                                            
                                                                                                            // The mutant would fail these assertions by including Day 4
                                                                                                        }

    @Test
                                                                                                        public void testCreateCopyWithEndPeriodAfterLastItem() throws CloneNotSupportedException {
                                                                                                            // Create a time series and populate it with data
                                                                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                            for (int i = 1; i <= 5; i++) {
                                                                                                                timeSeries.add(new Day(i, 1, 2023), i);
                                                                                                            }
                                                                                                            
                                                                                                            // Define test periods
                                                                                                            RegularTimePeriod startPeriod = new Day(1, 1, 2023);
                                                                                                            RegularTimePeriod endPeriod = new Day(6, 1, 2023);  // After last item (Day 5)
                                                                                                            
                                                                                                            // Original behavior: endIndex-1 would point to Day 5
                                                                                                            // Mutant behavior: endIndex+1 would cause index out of bounds or wrong data
                                                                                                            TimeSeries copy = timeSeries.createCopy(startPeriod, endPeriod);
                                                                                                            
                                                                                                            // Should include all items (Days 1-5)
                                                                                                            assertEquals(5, copy.getItemCount());
                                                                                                            
                                                                                                            // The mutant might throw IndexOutOfBoundsException or return wrong range
                                                                                                        }

    @Test
                                                                                                public void testCreateCopyIncludesEndIndex() throws Exception {
                                                                                                    // Setup test data - create a series with 3 items
                                                                                                    TimeSeries originalSeries = new TimeSeries("Test Series");
                                                                                                    TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                                    TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                                    TimeSeriesDataItem item3 = mock(TimeSeriesDataItem.class);
                                                                                                    when(item1.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                    when(item2.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                    when(item3.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                                    
                                                                                                    // Get the data field using reflection
                                                                                                    Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                    dataField.setAccessible(true);
                                                                                                    
                                                                                                    // Create and set the data list
                                                                                                    List<TimeSeriesDataItem> dataList = new ArrayList<>();
                                                                                                    dataList.add(item1);
                                                                                                    dataList.add(item2);
                                                                                                    dataList.add(item3);
                                                                                                    dataField.set(originalSeries, dataList);
                                                                                                
                                                                                                    // Test copying from index 1 to 2 (should include both items)
                                                                                                    TimeSeries copy = originalSeries.createCopy(1, 2);
                                                                                                    
                                                                                                    // Get the copy's data using reflection
                                                                                                    List<?> copyData = (List<?>) dataField.get(copy);
                                                                                                    
                                                                                                    // Verify the copy contains exactly 2 items (would fail if mutation is present)
                                                                                                    assertEquals("Copy should contain 2 items", 2, copyData.size());
                                                                                                    
                                                                                                    // Verify the items were properly cloned and added
                                                                                                    verify(item1, never()).clone(); // item1 should not be cloned
                                                                                                    verify(item2, times(1)).clone(); // item2 should be cloned once
                                                                                                    verify(item3, times(1)).clone(); // item3 should be cloned once
                                                                                                }

    @Test
                                                                                            public void testCreateCopyWithEndPeriodNotInSeries1() {
                                                                                                // Setup test data
                                                                                                TimeSeries series = new TimeSeries("Test");
                                                                                                Day day1 = new Day(1, 1, 2000);
                                                                                                Day day2 = new Day(2, 1, 2000);
                                                                                                Day day3 = new Day(3, 1, 2000);
                                                                                                Day day4 = new Day(4, 1, 2000);
                                                                                                
                                                                                                // Add data items to the series
                                                                                                series.add(day1, 1.0);
                                                                                                series.add(day2, 2.0);
                                                                                                series.add(day4, 4.0); // Note: day3 is missing
                                                                                                
                                                                                                // Create a test end period that falls between day2 and day4 (day3)
                                                                                                Day testEnd = new Day(3, 1, 2000);
                                                                                                
                                                                                                // Call the method
                                                                                                TimeSeries result = null;
                                                                                                try {
                                                                                                    result = series.createCopy(day1, testEnd);
                                                                                                } catch (CloneNotSupportedException e) {
                                                                                                    fail("CloneNotSupportedException was thrown: " + e.getMessage());
                                                                                                }
                                                                                                
                                                                                                // Verify the result
                                                                                                // Original behavior would include day1 and day2 (endIndex decremented)
                                                                                                // Mutant behavior would try to include day4 (endIndex not decremented)
                                                                                                assertEquals(2, result.getItemCount()); // Should only include day1 and day2
                                                                                                
                                                                                                // Verify the values
                                                                                                assertEquals(1.0, result.getValue(day1).doubleValue(), 0.0001);
                                                                                                assertEquals(2.0, result.getValue(day2).doubleValue(), 0.0001);
                                                                                                
                                                                                                // Verify day4 is not included
                                                                                                assertNull(result.getValue(day4));
                                                                                            }

    @Test
                                                                                        public void testCreateCopyDetectsEndIndexMutation1() throws Exception {
                                                                                            // Setup test data
                                                                                            TimeSeries series = new TimeSeries("Test");
                                                                                            Day day1 = new Day(1, 1, 2000);
                                                                                            Day day2 = new Day(2, 1, 2000);
                                                                                            Day day3 = new Day(3, 1, 2000);
                                                                                            Day day4 = new Day(4, 1, 2000);
                                                                                            
                                                                                            // Add some data points
                                                                                            series.add(day1, 1.0);
                                                                                            series.add(day2, 2.0);
                                                                                            series.add(day3, 3.0);
                                                                                            
                                                                                            // Create test periods
                                                                                            Day start = day2;  // exists in series
                                                                                            Day end = new Day(5, 1, 2000);  // doesn't exist, should end at day3
                                                                                            
                                                                                            // Test the copy
                                                                                            TimeSeries copy = series.createCopy(start, end);
                                                                                            
                                                                                            // Verify the copy contains the correct range (day2 and day3)
                                                                                            assertEquals(2, copy.getItemCount());
                                                                                            assertEquals(2.0, copy.getValue(day2).doubleValue(), 0.0001);
                                                                                            assertEquals(3.0, copy.getValue(day3).doubleValue(), 0.0001);
                                                                                            
                                                                                            // The mutant would incorrectly include day1 (index 0) and day2
                                                                                            // So these assertions would fail with the mutant:
                                                                                            // - Item count would be 2 (same by coincidence)
                                                                                            // - But would contain day1 (value 1.0) instead of day3
                                                                                        }

    @Test
                                                                                    public void testCreateCopyWithMultipleItemsShouldCopyCorrectRange() throws Exception {
                                                                                        // Setup - create a time series with 3 items
                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                        Day day1 = new Day(1, 1, 2023);
                                                                                        Day day2 = new Day(2, 1, 2023);
                                                                                        Day day3 = new Day(3, 1, 2023);
                                                                                        
                                                                                        TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                        TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                        TimeSeriesDataItem item3 = mock(TimeSeriesDataItem.class);
                                                                                        
                                                                                        when(item1.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                        when(item2.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                        when(item3.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                        
                                                                                        series.add(day1, 1.0); // index 0
                                                                                        series.add(day2, 2.0); // index 1
                                                                                        series.add(day3, 3.0); // index 2
                                                                                        
                                                                                        // Use reflection to access the protected data field
                                                                                        Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                        dataField.setAccessible(true);
                                                                                        List data = (List) dataField.get(series);
                                                                                        
                                                                                        // Replace actual items with mocks for verification
                                                                                        data.set(0, item1);
                                                                                        data.set(1, item2);
                                                                                        data.set(2, item3);
                                                                                        
                                                                                        // Test - copy from index 1 to 2
                                                                                        TimeSeries copy = series.createCopy(1, 2);
                                                                                        
                                                                                        // Verify - should contain items 1 and 2 (indices 1-2)
                                                                                        assertEquals(2, copy.getItemCount());
                                                                                        
                                                                                        // Verify the correct items were cloned and added
                                                                                        verify(item1, never()).clone(); // item1 should not be cloned
                                                                                        verify(item2, times(1)).clone(); // item2 should be cloned once
                                                                                        verify(item3, times(1)).clone(); // item3 should be cloned once
                                                                                        
                                                                                        // The mutant would only clone item at index 0 (due to endIndex=0)
                                                                                        // so these verifications would fail for the mutant
                                                                                    }

    @Test
                                                                                    public void testCreateCopyWithSingleItemRange() throws Exception {
                                                                                        // Setup - create a time series with 3 items
                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                        Day day1 = new Day(1, 1, 2023);
                                                                                        Day day2 = new Day(2, 1, 2023);
                                                                                        
                                                                                        TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                                        TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                                        
                                                                                        when(item1.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                        when(item2.clone()).thenReturn(mock(TimeSeriesDataItem.class));
                                                                                        
                                                                                        series.add(day1, 1.0); // index 0
                                                                                        series.add(day2, 2.0); // index 1
                                                                                        
                                                                                        // Use reflection to access the protected data field
                                                                                        Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                        dataField.setAccessible(true);
                                                                                        List data = (List) dataField.get(series);
                                                                                        
                                                                                        // Replace actual items with mocks for verification
                                                                                        data.set(0, item1);
                                                                                        data.set(1, item2);
                                                                                        
                                                                                        // Test - copy single item at index 1
                                                                                        TimeSeries copy = series.createCopy(1, 1);
                                                                                        
                                                                                        // Verify - should contain only item at index 1
                                                                                        assertEquals(1, copy.getItemCount());
                                                                                        verify(item1, never()).clone(); // item1 should not be cloned
                                                                                        verify(item2, times(1)).clone(); // item2 should be cloned once
                                                                                        
                                                                                        // The mutant would clone item at index 0 instead, making this fail
                                                                                    }

    @Test
                                                                                public void testCreateCopyWithEndIndexZeroShouldNotBeEmpty() throws Exception {
                                                                                    // Setup
                                                                                    TimeSeries series = new TimeSeries("Test");
                                                                                    RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                                                    RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                                                    
                                                                                    // Mock behavior to create scenario where:
                                                                                    // startIndex = 0, endIndex = 0
                                                                                    when(start.compareTo(end)).thenReturn(-1); // start < end
                                                                                    when(series.getIndex(start)).thenReturn(0); // start found at index 0
                                                                                    when(series.getIndex(end)).thenReturn(0); // end found at index 0
                                                                                    
                                                                                    // Mock the actual copy creation
                                                                                    TimeSeries mockCopy = mock(TimeSeries.class);
                                                                                    when(series.createCopy(0, 0)).thenReturn(mockCopy);
                                                                                    
                                                                                    // Test - should return the mock copy (non-empty)
                                                                                    TimeSeries result = series.createCopy(start, end);
                                                                                    
                                                                                    // Verify - should not return empty series
                                                                                    assertNotSame(series, result); // should be a copy
                                                                                    assertSame(mockCopy, result); // should be our mock copy (proves non-empty case was taken)
                                                                                    
                                                                                    // Verify interactions
                                                                                    verify(series).getIndex(start);
                                                                                    verify(series).getIndex(end);
                                                                                    verify(series).createCopy(0, 0);
                                                                                }

    @Test
                                                                        public void testCreateCopyWithZeroEndIndexShouldNotThrowException() throws SeriesException, NoSuchFieldException, IllegalAccessException, CloneNotSupportedException {
                                                                            // Setup
                                                                            TimeSeries series = new TimeSeries("Test Series");
                                                                            TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                            TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                            when(item1.clone()).thenReturn(item1);
                                                                            when(item2.clone()).thenReturn(item2);
                                                                            
                                                                            // Use reflection to access the protected data field
                                                                            Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                            dataField.setAccessible(true);
                                                                            List data = (List) dataField.get(series);
                                                                            
                                                                            // Add test data
                                                                            data.add(item1);
                                                                            data.add(item2);
                                                                            
                                                                            // Test valid case where start=0 and end=0
                                                                            TimeSeries result = series.createCopy(0, 0);
                                                                            
                                                                            // Verify
                                                                            assertNotNull(result);
                                                                            List resultData = (List) dataField.get(result);
                                                                            assertEquals(1, resultData.size());
                                                                        }

    @Test
                                                                        public void testCreateCopyWithEqualStartAndEndShouldNotBeEmpty() throws Exception {
                                                                            // Setup test data
                                                                            TimeSeries series = new TimeSeries("Test");
                                                                            Day day1 = new Day(1, 1, 2000);
                                                                            series.add(day1, 100.0);
                                                                            
                                                                            // Mock getIndex to return same index for start and end
                                                                            TimeSeries spySeries = spy(series);
                                                                            when(spySeries.getIndex(any(RegularTimePeriod.class))).thenReturn(0);
                                                                            
                                                                            // Execute
                                                                            TimeSeries result = spySeries.createCopy(day1, day1);
                                                                            
                                                                            // Verify
                                                                            assertFalse("Copy should not be empty for equal start and end", 
                                                                                       result.getItemCount() == 0);
                                                                        }

    @Test
                                                                public void testCreateCopyWithStartEqualToEnd() throws Exception {
                                                                    // Setup test data
                                                                    TimeSeries series = new TimeSeries("Test Series");
                                                                    TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                                    TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                                    TimeSeriesDataItem clonedItem = mock(TimeSeriesDataItem.class);
                                                                    
                                                                    // Mock the clone behavior
                                                                    when(item1.clone()).thenReturn(clonedItem);
                                                                    
                                                                    // Add items to the series using public methods
                                                                    series.add(item1);
                                                                    series.add(item2);
                                                                    
                                                                    // Test the case where start == end (should work in original, fail in mutant)
                                                                    int start = 0;
                                                                    int end = 0;  // same as start
                                                                    
                                                                    // Execute
                                                                    TimeSeries copy = series.createCopy(start, end);
                                                                    
                                                                    // Verify
                                                                    assertNotNull(copy);
                                                                    assertEquals(1, copy.getItemCount());
                                                                    verify(item1).clone();  // Verify cloning happened
                                                                }

    @Test
                                                    public void testCreateCopy_ShouldNotBeEmptyWhenEndIndexGreaterThanStartIndex() throws Exception {
                                                        // Setup test data
                                                        TimeSeries series = new TimeSeries("Test Series");
                                                        RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                        RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                        
                                                        // Mock behavior to create a valid non-empty range scenario
                                                        when(start.compareTo(end)).thenReturn(-1); // start < end
                                                        when(series.getIndex(start)).thenReturn(1); // startIndex = 1
                                                        when(series.getIndex(end)).thenReturn(2);   // endIndex = 2
                                                        
                                                        // Mock the actual copy creation to return a non-empty series
                                                        TimeSeries mockCopy = mock(TimeSeries.class);
                                                        TimeSeriesDataItem item1 = new TimeSeriesDataItem(start, 1.0);
                                                        TimeSeriesDataItem item2 = new TimeSeriesDataItem(end, 2.0);
                                                        when(mockCopy.getItems()).thenReturn(java.util.Arrays.asList(item1, item2));
                                                        when(series.createCopy(1, 2)).thenReturn(mockCopy);
                                                        
                                                        // Execute
                                                        TimeSeries result = series.createCopy(start, end);
                                                        
                                                        // Verify - should not be empty
                                                        assertFalse("Result series should not be empty when endIndex > startIndex", 
                                                                   result.getItems().isEmpty());
                                                        
                                                        // Additional verification that createCopy was called with correct indices
                                                        verify(series).createCopy(1, 2);
                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                public void testCreateCopyWithEndLessThanStartShouldThrowException() throws CloneNotSupportedException {
                                                    // Setup test data
                                                    TimeSeries series = new TimeSeries("Test Series");
                                                    
                                                    // Add some sample data
                                                    RegularTimePeriod period = new Day(); // Assuming Day is available
                                                    series.add(period, 10.0);
                                                    series.add(period.next(), 20.0);
                                                    
                                                    // This should throw IllegalArgumentException in original code
                                                    // But will pass in mutated code (which we want to catch)
                                                    series.createCopy(1, 0); // end < start
                                                    
                                                    // If we reach here in original code, the test fails
                                                    // In mutated code, it might throw IndexOutOfBoundsException or proceed incorrectly
                                                    // Either way, the expected IllegalArgumentException won't be thrown
                                                    // So the test will fail for the mutant (which is what we want)
                                                }

    @Test
                                            public void testCreateCopyWithNegativeEndIndex() throws Exception {
                                                // Setup
                                                TimeSeries series = new TimeSeries("Test Series");
                                                RegularTimePeriod start = mock(RegularTimePeriod.class);
                                                RegularTimePeriod end = mock(RegularTimePeriod.class);
                                                
                                                // Mock behavior to create scenario where:
                                                // - startIndex is valid (>= 0)
                                                // - endIndex is negative
                                                when(start.compareTo(end)).thenReturn(-1); // start < end
                                                when(series.getIndex(start)).thenReturn(5); // valid start index
                                                when(series.getIndex(end)).thenReturn(-7); // negative end index
                                                
                                                // Execute
                                                TimeSeries result = series.createCopy(start, end);
                                                
                                                // Verify - should return empty series because endIndex is negative
                                                assertEquals(0, result.getItemCount());
                                                
                                                // Additional verification that emptyRange was set correctly
                                                // We can check this by verifying the data list is empty
                                                // (since emptyRange=true leads to new empty ArrayList)
                                                assertTrue(result.getItems().isEmpty());
                                            }

    @Test
                                        public void testCreateCopyWithNegativeEndIndexShouldThrowException() throws SeriesException {
                                            // Setup test data
                                            TimeSeries series = new TimeSeries("Test Series");
                                            
                                            // Add some sample data items (need to mock RegularTimePeriod and TimeSeriesDataItem)
                                            RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                                            TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                            when(item1.clone()).thenReturn(item1);
                                            series.add(item1);
                                            
                                            RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                                            TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                            when(item2.clone()).thenReturn(item2);
                                            series.add(item2);
                                            
                                            try {
                                                // This should throw IllegalArgumentException because end index is negative
                                                // The mutant would allow this call to proceed
                                                series.createCopy(0, -1);
                                                // If we reach here, the test fails (mutant survived)
                                                fail("Expected IllegalArgumentException for negative end index");
                                            } catch (CloneNotSupportedException e) {
                                                // This is unexpected, so fail the test
                                                fail("Unexpected CloneNotSupportedException: " + e.getMessage());
                                            } catch (IllegalArgumentException e) {
                                                // This is the expected exception, test passes
                                                return;
                                            }
                                        }

    @Test
                                        public void testCreateCopyDetectsEndIndexBeforeStartIndex() throws Exception {
                                            // Setup
                                            TimeSeries series = new TimeSeries("Test Series");
                                            RegularTimePeriod start = mock(RegularTimePeriod.class);
                                            RegularTimePeriod end = mock(RegularTimePeriod.class);
                                            
                                            // Mock behavior to pass initial checks
                                            when(start.compareTo(end)).thenReturn(-1); // start < end
                                            
                                            // Mock getIndex calls to simulate:
                                            // startIndex = 5
                                            // endIndex = 3 (which is < startIndex but >= 0)
                                            TimeSeries spySeries = spy(series);
                                            when(spySeries.getIndex(start)).thenReturn(5);
                                            when(spySeries.getIndex(end)).thenReturn(-4); // will be converted to 3
                                            
                                            // Mock createCopy for the non-empty case (shouldn't be called)
                                            TimeSeries mockCopy = mock(TimeSeries.class);
                                            when(spySeries.createCopy(anyInt(), anyInt())).thenReturn(mockCopy);
                                            
                                            // Test
                                            TimeSeries result = spySeries.createCopy(start, end);
                                            
                                            // Verify - should return empty series (not the mockCopy)
                                            assertNotSame(mockCopy, result);
                                            assertEquals(0, result.getItemCount());
                                            
                                            // Verify createCopy wasn't called (since range should be empty)
                                            verify(spySeries, never()).createCopy(anyInt(), anyInt());
                                        }

    @Test
                                public void testCreateCopy_EndLessThanStart_ThrowsException() {
                                    // Setup
                                    TimeSeries series = new TimeSeries("Test Series");
                                    
                                    // Add some data to ensure the series isn't empty
                                    RegularTimePeriod period = new Day(); // Assuming Day is available
                                    series.add(period, 1.0);
                                    
                                    // Test parameters where end < start but both >= 0
                                    int start = 1;
                                    int end = 0;
                                    
                                    try {
                                        // This should throw IllegalArgumentException in original code
                                        // but would pass in mutated code
                                        series.createCopy(start, end);
                                        // If we reach here, the test fails (mutant survived)
                                        fail("Expected IllegalArgumentException when end < start");
                                    } catch (IllegalArgumentException e) {
                                        // This is the expected behavior - test passes
                                    } catch (CloneNotSupportedException e) {
                                        fail("Unexpected CloneNotSupportedException");
                                    }
                                }

    @Test
                            public void testCreateCopyWithNegativeEndIndex1() throws Exception {
                                // Setup test data
                                TimeSeries series = new TimeSeries("Test Series");
                                RegularTimePeriod start = mock(RegularTimePeriod.class);
                                RegularTimePeriod end = mock(RegularTimePeriod.class);
                                
                                // Mock behavior
                                when(start.compareTo(end)).thenReturn(-1); // start < end
                                when(series.getIndex(start)).thenReturn(1); // start found at index 1
                                when(series.getIndex(end)).thenReturn(-3); // end not found, would insert at 2
                                
                                // The key scenario:
                                // endIndex = -(-3 + 1) - 1 = 1
                                // startIndex = 1
                                // Original condition: (1 < 0) || (1 < 1) → false || false → false
                                // Mutant condition: (1 < 1) → false
                                // But we need endIndex to be negative in original calculation
                                
                                // Alternative setup where endIndex becomes negative:
                                // Let's make getIndex(end) return -1 (would insert at 0)
                                // Then endIndex = -(-1 + 1) - 1 = -1
                                when(series.getIndex(end)).thenReturn(-1);
                                
                                // Create a spy to test the actual method
                                TimeSeries spySeries = spy(series);
                                doReturn(new TimeSeries("Copy")).when(spySeries).createCopy(anyInt(), anyInt());
                                
                                // Test - should return empty series
                                TimeSeries result = spySeries.createCopy(start, end);
                                
                                // Verify - should return empty series (not call createCopy with indices)
                                assertEquals(0, result.getItemCount());
                                verify(spySeries, never()).createCopy(anyInt(), anyInt());
                            }

    @Test
                        public void testCreateCopyWithValidIndicesShouldSucceed() throws CloneNotSupportedException {
                            // Setup test data
                            TimeSeries series = new TimeSeries("Test Series");
                            
                            // Add sample data
                            RegularTimePeriod period1 = new Day();
                            RegularTimePeriod period2 = new Day();
                            series.add(period1, 1.0);
                            series.add(period2, 2.0);
                            
                            // This should work fine with valid indices
                            TimeSeries copy = series.createCopy(0, 1);
                            
                            // Verify the copy
                            assertEquals(2, copy.getItemCount());
                            assertEquals(1.0, copy.getValue(0).doubleValue(), 0.0001);
                            assertEquals(2.0, copy.getValue(1).doubleValue(), 0.0001);
                        }

    @Test(expected = IllegalArgumentException.class)
                        public void testCreateCopyWithEndLessThanStartShouldThrowException1() throws CloneNotSupportedException {
                            // Setup test data
                            TimeSeries series = new TimeSeries("Test Series");
                            
                            // Add some sample data
                            RegularTimePeriod period = new Day();
                            series.add(period, 1.0);
                            
                            // This should throw IllegalArgumentException because end < start
                            series.createCopy(1, 0);
                        }

    @Test(expected = IllegalArgumentException.class)
                        public void testCreateCopyWithNegativeStartIndexShouldThrowException() throws CloneNotSupportedException {
                            // Setup test data
                            TimeSeries series = new TimeSeries("Test Series");
                            
                            // Add some sample data
                            RegularTimePeriod period = new Day();
                            series.add(period, 1.0);
                            
                            // This should throw IllegalArgumentException because start is negative
                            series.createCopy(-1, 0);
                        }

    @Test(expected = IllegalArgumentException.class)
                    public void testCreateCopyWithNegativeEndIndexShouldThrowException1() throws CloneNotSupportedException {
                        // Setup test data
                        TimeSeries series = new TimeSeries("Test Series");
                        
                        // Add some sample data
                        RegularTimePeriod period = new Day();
                        series.add(period, 1.0);
                        
                        // This should throw IllegalArgumentException because end index is negative
                        // The mutant would allow this to pass through
                        series.createCopy(0, -1);
                    }

    @Test
                public void testCreateCopyWithEmptyRange() throws Exception {
                    // Create a TimeSeries with no data
                    TimeSeries series = new TimeSeries("Test Series");
                    
                    // Test case 1: empty data list
                    TimeSeries copy1 = series.createCopy(0, 0);
                    assertEquals(0, copy1.getItemCount());  // Should be empty
                    
                    // Test case 2: start > end (invalid range)
                    try {
                        series.createCopy(1, 0);
                        fail("Expected IllegalArgumentException for start > end");
                    } catch (IllegalArgumentException e) {
                        assertEquals("Requires start <= end.", e.getMessage());
                    }
                    
                    // Test case 3: valid range but empty data
                    TimeSeries copy3 = series.createCopy(0, 10);
                    assertEquals(0, copy3.getItemCount());  // Should be empty
                    
                    // Add some data to test non-empty cases
                    RegularTimePeriod period = new Day();
                    series.add(period, 1.0);
                    
                    // Test case 4: single item copy
                    TimeSeries copy4 = series.createCopy(0, 0);
                    assertEquals(1, copy4.getItemCount());
                    assertEquals(1.0, copy4.getValue(0).doubleValue(), 0.0001);
                    
                    // Test case 5: empty range after adding data
                    TimeSeries copy5 = series.createCopy(1, 1);
                    assertEquals(0, copy5.getItemCount());  // Should be empty as index 1 doesn't exist
                }

    @Test
        public void testCreateCopyWhenStartAfterLastDataItemShouldReturnEmptySeries() throws CloneNotSupportedException {
            // Setup
            TimeSeries series = new TimeSeries("Test");
            RegularTimePeriod start = mock(RegularTimePeriod.class);
            RegularTimePeriod end = mock(RegularTimePeriod.class);
            
            try {
                // Get the data field using reflection
                Field dataField = TimeSeries.class.getDeclaredField("data");
                dataField.setAccessible(true);
                List<?> data = (List<?>) dataField.get(series);
                
                // Mock behavior to simulate start after last data item
                when(series.getIndex(start)).thenReturn(-(data.size() + 1));
                when(series.getIndex(end)).thenReturn(0); // any valid index
                
                // Ensure start is before end (though in this case it shouldn't matter)
                when(start.compareTo(end)).thenReturn(-1);
                
                // Test
                TimeSeries result = series.createCopy(start, end);
                
                // Get the result's data field using reflection
                List<?> resultData = (List<?>) dataField.get(result);
                
                // Verify - should return empty series due to start after last item
                assertTrue("Expected empty series when start is after last data item", 
                          resultData.isEmpty());
            } catch (NoSuchFieldException | IllegalAccessException e) {
                fail("Reflection failed: " + e.getMessage());
            }
        }

    @Test
    public void testCreateCopyWithEmptyRange1() throws Exception {
        // Setup empty time series
        TimeSeries series = new TimeSeries("Test Series");
        
        // Test with empty data (should set emptyRange flag)
        TimeSeries copy1 = series.createCopy(0, 0);
        assertEquals(0, copy1.getItemCount());
        
        // Add some data
        RegularTimePeriod period = new Day();
        series.add(period, 1.0);
        
        // Test with non-empty range (should not set emptyRange flag)
        TimeSeries copy2 = series.createCopy(0, 0);
        assertEquals(1, copy2.getItemCount());
        
        // Test with empty range again (mutation would invert flag incorrectly)
        TimeSeries emptySeries = new TimeSeries("Empty");
        TimeSeries copy3 = emptySeries.createCopy(0, 0);
        assertEquals(0, copy3.getItemCount());
        
        // The mutation would cause the emptyRange flag to be toggled incorrectly,
        // potentially affecting subsequent operations. This test verifies the
        // flag remains consistent with the actual data state.
    }

    @Test
    public void testCreateCopyWhenStartAfterLastItem_DetectsEmptyRangeMutant() throws Exception {
        // Setup - create a time series with some data
        TimeSeries series = new TimeSeries("Test");
        Day day1 = new Day(1, 1, 2000);
        Day day2 = new Day(2, 1, 2000);
        series.add(day1, 100.0);
        series.add(day2, 200.0);
        
        // Create a start day that is after the last item in the series
        Day startAfterLast = new Day(3, 1, 2000);
        Day anyEnd = new Day(4, 1, 2000); // end doesn't matter for this test
        
        // Test the createCopy method
        TimeSeries result = series.createCopy(startAfterLast, anyEnd);
        
        // Verify - should return an empty series
        assertEquals(0, result.getItemCount()); // This will fail if mutant toggled emptyRange to false
        
        // Additional verification that data is empty
        assertTrue(result.getItems().isEmpty());
    }

}
