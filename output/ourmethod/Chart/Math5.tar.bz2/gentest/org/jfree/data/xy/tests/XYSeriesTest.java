package gentest.org.jfree.data.xy.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.xy.*;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.general.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class XYSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                        public void testAddOrUpdate_NullXValue() {
                                            XYSeries series = new XYSeries("Test Series");
                                            thrown.expect(IllegalArgumentException.class);
                                            thrown.expectMessage("Null 'x' argument.");
                                            series.addOrUpdate(null, 10);
                                        }

    @Test
                                        public void testAddOrUpdate_AllowDuplicateXValues() {
                                            XYSeries series = new XYSeries("Test Series", true, true);
                                            assertNull(series.addOrUpdate(1.0, 10.0)); // Should return null
                                            assertNull(series.addOrUpdate(1.0, 20.0)); // Same x, different y
                                            assertEquals(2, series.getItemCount()); // Both items should be added
                                        }

    @Test
                                        public void testAddOrUpdate_UpdateExistingItem() throws CloneNotSupportedException {
                                            XYSeries series = new XYSeries("Test Series", true, false);
                                            series.add(1.0, 10.0);
                                            
                                            XYDataItem originalItem = series.getDataItem(0);
                                            XYDataItem overwritten = series.addOrUpdate(1.0, 20.0);
                                            
                                            assertNotNull(overwritten);
                                            assertEquals(10.0, overwritten.getY().doubleValue(), 0.0001);
                                            assertEquals(20.0, series.getY(0).doubleValue(), 0.0001);
                                            assertEquals(1, series.getItemCount());
                                        }

    @Test
                                        public void testAddOrUpdate_AutoSortTrue() {
                                            XYSeries series = new XYSeries("Test Series", true, false);
                                            series.add(2.0, 20.0);
                                            series.add(4.0, 40.0);
                                            
                                            assertNull(series.addOrUpdate(3.0, 30.0)); // Should insert between 2 and 4
                                            
                                            assertEquals(3, series.getItemCount());
                                            assertEquals(2.0, series.getX(0).doubleValue(), 0.0001);
                                            assertEquals(3.0, series.getX(1).doubleValue(), 0.0001);
                                            assertEquals(4.0, series.getX(2).doubleValue(), 0.0001);
                                        }

    @Test
                                        public void testAddOrUpdate_AutoSortFalse() {
                                            XYSeries series = new XYSeries("Test Series", false, false);
                                            series.add(2.0, 20.0);
                                            series.add(4.0, 40.0);
                                            
                                            assertNull(series.addOrUpdate(3.0, 30.0)); // Should append to end
                                            
                                            assertEquals(3, series.getItemCount());
                                            assertEquals(2.0, series.getX(0).doubleValue(), 0.0001);
                                            assertEquals(4.0, series.getX(1).doubleValue(), 0.0001);
                                            assertEquals(3.0, series.getX(2).doubleValue(), 0.0001);
                                        }

    @Test
                                        public void testAddOrUpdate_MaximumItemCount() {
                                            XYSeries series = new XYSeries("Test Series", true, false);
                                            series.setMaximumItemCount(2);
                                            
                                            series.add(1.0, 10.0);
                                            series.add(2.0, 20.0);
                                            assertNull(series.addOrUpdate(3.0, 30.0)); // Should remove first item
                                            
                                            assertEquals(2, series.getItemCount());
                                            assertEquals(2.0, series.getX(0).doubleValue(), 0.0001);
                                            assertEquals(3.0, series.getX(1).doubleValue(), 0.0001);
                                        }

    @Test
                                        public void testAddOrUpdate_FireSeriesChanged() {
                                            XYSeries series = spy(new XYSeries("Test Series"));
                                            series.addOrUpdate(1.0, 10.0);
                                            verify(series).fireSeriesChanged();
                                        }

    @Test
                                public void testAddOrUpdate_AddNewPointToEmptySeries() {
                                    XYSeries series = new XYSeries("Test Series");
                                    XYDataItem result = series.addOrUpdate(1.0, 2.0);
                                    assertNotNull(result);
                                    assertEquals(1, series.getItemCount());
                                    assertEquals(1.0, series.getX(0).doubleValue(), 0.0001);
                                    assertEquals(2.0, series.getY(0).doubleValue(), 0.0001);
                                }

    @Test
                                public void testAddOrUpdate_AddMultiplePointsToSortedSeries() {
                                    // Create a new sorted XYSeries (autoSort=true)
                                    XYSeries sortedSeries = new XYSeries("Test Series", true);
                                    
                                    sortedSeries.addOrUpdate(2.0, 3.0);
                                    sortedSeries.addOrUpdate(1.0, 2.0);
                                    sortedSeries.addOrUpdate(3.0, 4.0);
                                    
                                    assertEquals(3, sortedSeries.getItemCount());
                                    // Verify sorting
                                    assertEquals(1.0, sortedSeries.getX(0).doubleValue(), 0.0001);
                                    assertEquals(2.0, sortedSeries.getX(1).doubleValue(), 0.0001);
                                    assertEquals(3.0, sortedSeries.getX(2).doubleValue(), 0.0001);
                                }

    @Test
                                public void testAddOrUpdate_AddMultiplePointsToUnsortedSeries() {
                                    XYSeries unsortedSeries = new XYSeries("Test Series", false, true);
                                    unsortedSeries.addOrUpdate(2.0, 3.0);
                                    unsortedSeries.addOrUpdate(1.0, 2.0);
                                    unsortedSeries.addOrUpdate(3.0, 4.0);
                                    
                                    assertEquals(3, unsortedSeries.getItemCount());
                                    // Verify order is maintained as added
                                    assertEquals(2.0, unsortedSeries.getX(0).doubleValue(), 0.0001);
                                    assertEquals(1.0, unsortedSeries.getX(1).doubleValue(), 0.0001);
                                    assertEquals(3.0, unsortedSeries.getX(2).doubleValue(), 0.0001);
                                }

    @Test
                                public void testAddOrUpdate_UpdateExistingPoint() {
                                    XYSeries series = new XYSeries("Test Series");
                                    series.addOrUpdate(1.0, 2.0);
                                    XYDataItem result = series.addOrUpdate(1.0, 3.0);
                                    
                                    assertEquals(1, series.getItemCount());
                                    assertEquals(1.0, series.getX(0).doubleValue(), 0.0001);
                                    assertEquals(3.0, series.getY(0).doubleValue(), 0.0001);
                                    assertEquals(3.0, result.getY().doubleValue(), 0.0001);
                                }

    @Test(expected = IllegalArgumentException.class)
                                public void testAddOrUpdate_AddDuplicateXToNoDuplicateSeries() {
                                    XYSeries noDuplicateSeries = new XYSeries("Test Series", false, false);
                                    noDuplicateSeries.addOrUpdate(1.0, 2.0);
                                    noDuplicateSeries.addOrUpdate(1.0, 3.0);
                                }

    @Test
                                public void testAddOrUpdate_AddDuplicateXToAllowDuplicateSeries() {
                                    XYSeries series = new XYSeries("Test Series", false, true); // key, autoSort, allowDuplicateXValues
                                    series.addOrUpdate(1.0, 2.0);
                                    series.addOrUpdate(1.0, 3.0); // Should be allowed
                                    
                                    assertEquals(2, series.getItemCount());
                                    assertEquals(1.0, series.getX(0).doubleValue(), 0.0001);
                                    assertEquals(2.0, series.getY(0).doubleValue(), 0.0001);
                                    assertEquals(1.0, series.getX(1).doubleValue(), 0.0001);
                                    assertEquals(3.0, series.getY(1).doubleValue(), 0.0001);
                                }

    @Test
                                public void testAddOrUpdate_AddNaNValues() {
                                    XYSeries series = new XYSeries("Test Series");
                                    XYDataItem result = series.addOrUpdate(Double.NaN, Double.NaN);
                                    assertNotNull(result);
                                    assertEquals(1, series.getItemCount());
                                    assertTrue(Double.isNaN(series.getX(0).doubleValue()));
                                    assertTrue(Double.isNaN(series.getY(0).doubleValue()));
                                }

    @Test
                                public void testAddOrUpdate_AddInfiniteValues() {
                                    XYSeries series = new XYSeries("Test Series");
                                    XYDataItem result = series.addOrUpdate(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY);
                                    assertNotNull(result);
                                    assertEquals(1, series.getItemCount());
                                    assertEquals(Double.POSITIVE_INFINITY, series.getX(0).doubleValue(), 0.0001);
                                    assertEquals(Double.NEGATIVE_INFINITY, series.getY(0).doubleValue(), 0.0001);
                                }

    @Test
                                public void testAddOrUpdate_WithMaximumItemCount() {
                                    XYSeries series = new XYSeries("Test Series");
                                    series.setMaximumItemCount(2);
                                    series.addOrUpdate(1.0, 1.0);
                                    series.addOrUpdate(2.0, 2.0);
                                    series.addOrUpdate(3.0, 3.0); // Should remove the first item
                                    
                                    assertEquals(2, series.getItemCount());
                                    assertEquals(2.0, series.getX(0).doubleValue(), 0.0001);
                                    assertEquals(3.0, series.getX(1).doubleValue(), 0.0001);
                                }

    @Test
                                public void testAddOrUpdate_UpdateWithMaximumItemCount() {
                                    XYSeries series = new XYSeries("Test Series");
                                    series.setMaximumItemCount(2);
                                    series.addOrUpdate(1.0, 1.0);
                                    series.addOrUpdate(2.0, 2.0);
                                    series.addOrUpdate(1.0, 3.0); // Should update existing item, not add new one
                                    
                                    assertEquals(2, series.getItemCount());
                                    assertEquals(1.0, series.getX(0).doubleValue(), 0.0001);
                                    assertEquals(3.0, series.getY(0).doubleValue(), 0.0001);
                                    assertEquals(2.0, series.getX(1).doubleValue(), 0.0001);
                                }

    @Test
                                public void testAddOrUpdate_CloneNotSupported() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
                                    XYSeries series = new XYSeries("Test Series", true, false);
                                    XYDataItem mockItem = mock(XYDataItem.class);
                                    when(mockItem.clone()).thenThrow(new CloneNotSupportedException());
                                    
                                    // Add the mock item to the series using reflection
                                    List<XYDataItem> mockData = new ArrayList<>();
                                    mockData.add(mockItem);
                                    Field dataField = XYSeries.class.getDeclaredField("data");
                                    dataField.setAccessible(true);
                                    dataField.set(series, mockData);
                                    
                                    thrown.expect(SeriesException.class);
                                    thrown.expectMessage("Couldn't clone XYDataItem!");
                                    series.addOrUpdate(1.0, 20.0);
                                }

    @Test
                                public void testAddOrUpdateShouldUpdateCorrectItemNotFirstItem() {
                                    // Setup - create series with multiple items
                                    XYSeries series = new XYSeries("Test Series");
                                    series.add(1.0, 10.0);  // Will be at index 0
                                    series.add(2.0, 20.0);  // Will be at index 1
                                    series.add(3.0, 30.0);  // Will be at index 2
                                    
                                    // Action - update the item with x=2.0 (not at index 0)
                                    series.addOrUpdate(2.0, 25.0);
                                    
                                    // Verification - check all items
                                    assertEquals(3, series.getItemCount());
                                    
                                    // Verify first item remains unchanged
                                    assertEquals(1.0, series.getX(0).doubleValue(), 0.0001);
                                    assertEquals(10.0, series.getY(0).doubleValue(), 0.0001);
                                    
                                    // Verify second item was updated
                                    assertEquals(2.0, series.getX(1).doubleValue(), 0.0001);
                                    assertEquals(25.0, series.getY(1).doubleValue(), 0.0001);
                                    
                                    // Verify third item remains unchanged
                                    assertEquals(3.0, series.getX(2).doubleValue(), 0.0001);
                                    assertEquals(30.0, series.getY(2).doubleValue(), 0.0001);
                                    
                                    // The mutant would incorrectly update the first item (index 0) instead of index 1
                                    // This assertion would catch that case
                                    assertNotEquals(25.0, series.getY(0).doubleValue(), 0.0001);
                                }

    @Test
                            public void testAddOrUpdateUpdatesCorrectItemWhenNotAtFirstPosition() {
                                // Setup - create series with autoSort=false and no duplicate X values allowed
                                XYSeries series = new XYSeries("Test", false, false);
                                
                                // Add multiple items where the one we'll update is not at index 0
                                series.add(1.0, 100.0);  // This will be at index 0
                                series.add(2.0, 200.0);  // This will be at index 1 - we'll update this
                                series.add(3.0, 300.0);  // This will be at index 2
                                
                                // Store original item for comparison
                                XYDataItem originalItem = series.getDataItem(1);
                                
                                // Action - update the item at x=2.0
                                XYDataItem overwritten = series.addOrUpdate(2.0, 250.0);
                                
                                // Assertions
                                // Verify the correct item was updated (not the first one)
                                assertEquals(200.0, overwritten.getY());  // Original y value
                                assertEquals(250.0, series.getY(1));     // New y value at same position
                                
                                // Verify other items weren't changed
                                assertEquals(100.0, series.getY(0));     // First item unchanged
                                assertEquals(300.0, series.getY(2));     // Third item unchanged
                                
                                // Verify the returned overwritten item matches what was at index 1
                                assertEquals(originalItem, overwritten);
                            }

    @Test(expected = SeriesException.class)
                    public void testAddOrUpdate_CloneNotSupportedException() throws Exception {
                        // Setup
                        Number x = 1.0;
                        Number y = 2.0;
                        
                        // Create mock objects
                        List<XYDataItem> mockData = mock(List.class);
                        XYDataItem mockItem = mock(XYDataItem.class);
                        
                        // Create series instance and inject mock data using reflection
                        XYSeries series = new XYSeries("Test");
                        Field dataField = XYSeries.class.getDeclaredField("data");
                        dataField.setAccessible(true);
                        dataField.set(series, mockData);
                        
                        // Mock behavior
                        when(mockData.indexOf(any())).thenReturn(0); // Item exists
                        when(mockData.get(0)).thenReturn(mockItem);
                        when(mockItem.clone()).thenThrow(new CloneNotSupportedException());
                        
                        // This should throw SeriesException as expected
                        series.addOrUpdate(x, y);
                    }

    @Test(expected = RuntimeException.class)
                    public void testAddOrUpdate_OtherExceptionShouldNotBeCaught() throws Exception {
                        // Setup
                        Number x = 1.0;
                        Number y = 2.0;
                        
                        // Create mock objects
                        List<XYDataItem> mockData = mock(List.class);
                        XYDataItem mockItem = mock(XYDataItem.class);
                        
                        // Create real series object and inject mock data using reflection
                        XYSeries series = new XYSeries("Test Series");
                        Field dataField = XYSeries.class.getDeclaredField("data");
                        dataField.setAccessible(true);
                        dataField.set(series, mockData);
                        
                        // Mock behavior
                        when(mockData.indexOf(any())).thenReturn(0); // Item exists
                        when(mockData.get(0)).thenReturn(mockItem);
                        when(mockItem.clone()).thenThrow(new RuntimeException("Test exception"));
                        
                        // Test - should throw RuntimeException
                        series.addOrUpdate(x, y);
                    }

    @Test
                public void testAddOrUpdateHandlesCloneNotSupportedException() throws CloneNotSupportedException {
                    // Create a new XYSeries instance for testing
                    XYSeries series = new XYSeries("Test Series");
                    
                    // Create a mock XYDataItem that throws CloneNotSupportedException
                    XYDataItem mockItem = mock(XYDataItem.class);
                    when(mockItem.clone()).thenThrow(new CloneNotSupportedException());
                    
                    // Create a spy of the XYSeries to control the behavior
                    XYSeries spySeries = spy(series);
                    
                    // Instead of mocking createDataItem (which is private), we'll mock the public add method
                    doReturn(mockItem).when(spySeries).addOrUpdate(anyDouble(), anyDouble());
                    
                    // When addOrUpdate is called, it will use our mock item which throws CloneNotSupportedException
                    try {
                        spySeries.addOrUpdate(1.0, 2.0);
                        // If we get here, the exception was caught and handled
                        assertTrue(true);
                    } catch (Exception e) {
                        // If any exception propagates, the test should fail
                        fail("CloneNotSupportedException should be caught and handled internally");
                    }
                    
                    // Verify that the clone() method was called (shows we exercised the right path)
                    verify(mockItem).clone();
                }

    @Test(expected = RuntimeException.class)
        public void testAddOrUpdate_CloneThrowsRuntimeException_ShouldPropagate() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
            // Setup
            XYSeries series = new XYSeries("Test", false, false);
            Number x = 1;
            Number y = 10;
            
            // Add initial item
            XYDataItem existingItem = mock(XYDataItem.class);
            when(existingItem.clone()).thenThrow(new RuntimeException("Mocked clone failure"));
            
            // Mock the data list to return our mock item using reflection
            List<XYDataItem> mockData = new ArrayList<>();
            mockData.add(existingItem);
            Field dataField = XYSeries.class.getDeclaredField("data");
            dataField.setAccessible(true);
            dataField.set(series, mockData);
            
            // Mock indexOf to return 0 (item exists)
            XYSeries spySeries = spy(series);
            doReturn(0).when(spySeries).indexOf(x);
            
            // This should throw RuntimeException
            spySeries.addOrUpdate(x, y);
        }

    @Test(expected = RuntimeException.class)
    public void testAddOrUpdateShouldNotCatchRuntimeException() {
        // Create a new XYSeries instance
        XYSeries series = new XYSeries("Test Series");
        
        // Create a mock XYSeries that throws RuntimeException when clone is called
        XYSeries spySeries = spy(series);
        try {
            doThrow(new RuntimeException("Test exception")).when(spySeries).clone();
        } catch (CloneNotSupportedException e) {
            // This should never happen in our test scenario
            throw new RuntimeException("Unexpected CloneNotSupportedException", e);
        }
        
        // This should throw RuntimeException in original version
        // but would be caught in mutated version
        spySeries.addOrUpdate(1.0, 2.0);
    }

    @Test
    public void testAddOrUpdateHandlesCloneNotSupportedException1() {
        // Create a new XYSeries instance
        XYSeries series = new XYSeries("Test Series");
        
        // Create a mock XYSeries that throws CloneNotSupportedException
        XYSeries spySeries = spy(series);
        try {
            doThrow(new CloneNotSupportedException("Test exception")).when(spySeries).clone();
        } catch (CloneNotSupportedException e) {
            fail("Setup failed: " + e.getMessage());
        }
        
        // This should be caught and handled in both original and mutated versions
        try {
            spySeries.addOrUpdate(1.0, 2.0);
        } catch (Exception e) {
            fail("CloneNotSupportedException should have been caught");
        }
    }


}
