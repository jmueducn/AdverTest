package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
    public void testRenderWrappedText_NoWrapNeeded() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        // Use reflection to set the protected field
        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
        defaultNewLineField.setAccessible(true);
        defaultNewLineField.set(formatter, "\n");
        
        StringBuffer sb = new StringBuffer();
        String text = "Short text";
        
        // Use reflection to access the protected method
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
        renderWrappedText.setAccessible(true);
        StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 50, 4, text);
        
        assertEquals("Short text", result.toString());
        assertSame(sb, result); // Should return the same StringBuffer
    }

    @Test
    public void testRenderWrappedText_SingleWrap() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        
        // Use reflection to access the protected field
        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
        defaultNewLineField.setAccessible(true);
        defaultNewLineField.set(formatter, "\n");
        
        StringBuffer sb = new StringBuffer();
        String text = "This is a long text that needs to be wrapped";
        
        // Use reflection to access the protected method
        Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
        renderWrappedTextMethod.setAccessible(true);
        StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
            formatter, sb, 20, 4, text);
        
        String expected = "This is a long text\n    that needs to be\n    wrapped";
        assertEquals(expected, result.toString());
    }

    @Test
    public void testRenderWrappedText_MultipleWraps() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        
        // Use reflection to access the protected defaultNewLine field
        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
        defaultNewLineField.setAccessible(true);
        defaultNewLineField.set(formatter, "\n");
        
        StringBuffer sb = new StringBuffer();
        String text = "This is a very long text that will require multiple wrapping operations to fit within the specified width";
        
        // Use reflection to access the protected renderWrappedText method
        Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
        renderWrappedTextMethod.setAccessible(true);
        StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(formatter, sb, 30, 4, text);
        
        String expected = "This is a very long text\n    that will require\n    multiple wrapping\n    operations to fit\n    within the specified\n    width";
        assertEquals(expected, result.toString());
    }

    @Test
    public void testRenderWrappedText_EmptyString() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");
        
        StringBuffer sb = new StringBuffer();
        
        // Use reflection to access protected method
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", 
            StringBuffer.class, 
            int.class, 
            int.class, 
            String.class
        );
        renderWrappedText.setAccessible(true);
        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
            formatter, 
            sb, 
            30, 
            4, 
            ""
        );
        
        assertEquals("", result.toString());
    }

    @Test
    public void testRenderWrappedText_NullText() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        
        // Get the protected method using reflection
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", 
            StringBuffer.class, 
            int.class, 
            int.class, 
            String.class
        );
        renderWrappedText.setAccessible(true);
        
        thrown.expect(NullPointerException.class);
        renderWrappedText.invoke(formatter, new StringBuffer(), 30, 4, null);
    }

    @Test
    public void testRenderWrappedText_ZeroWidth() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        
        // Use reflection to access the protected method
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", 
            StringBuffer.class, 
            int.class, 
            int.class, 
            String.class
        );
        renderWrappedText.setAccessible(true);
        
        StringBuffer sb = new StringBuffer();
        String text = "This should not wrap";
        StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 0, 4, text);
        
        // With zero width, it should return the original text
        assertEquals(text, result.toString());
    }

    @Test
    public void testRenderWrappedText_WithExistingBufferContent() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        // Use reflection to set the protected field
        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
        defaultNewLineField.setAccessible(true);
        defaultNewLineField.set(formatter, "\n");
        
        StringBuffer sb = new StringBuffer("Prefix: ");
        String text = "This is a long text that needs wrapping";
        
        // Use reflection to access the protected method
        Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
        renderWrappedTextMethod.setAccessible(true);
        StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
            formatter, sb, 20, 4, text);
        
        String expected = "Prefix: This is a long\n    text that needs\n    wrapping";
        assertEquals(expected, result.toString());
    }

    @Test
    public void testRenderWrappedText_WithDifferentNewLine() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        
        // Use reflection to set the protected defaultNewLine field
        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
        defaultNewLineField.setAccessible(true);
        defaultNewLineField.set(formatter, "\r\n");
        
        StringBuffer sb = new StringBuffer();
        String text = "This text will be wrapped at the specified width";
        
        // Use reflection to access the protected renderWrappedText method
        Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
        renderWrappedTextMethod.setAccessible(true);
        StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
            formatter, sb, 20, 4, text);
        
        String expected = "This text will be\r\n    wrapped at the\r\n    specified width";
        assertEquals(expected, result.toString());
    }

    @Test
    public void testRenderWrappedText_WithDifferentTabStop() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        
        // Access protected field via reflection
        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
        defaultNewLineField.setAccessible(true);
        defaultNewLineField.set(formatter, "\n");
        
        StringBuffer sb = new StringBuffer();
        String text = "Testing with different tab stop value for wrapped lines";
        
        // Access protected method via reflection
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", 
            StringBuffer.class, 
            int.class, 
            int.class, 
            String.class
        );
        renderWrappedText.setAccessible(true);
        StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 25, 8, text);
        
        String expected = "Testing with different\n        tab stop value for\n        wrapped lines";
        assertEquals(expected, result.toString());
    }

    @Test
    public void testRenderWrappedText_TextExactlyFitsWidth() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");
        
        StringBuffer sb = new StringBuffer();
        String text = "Exactly 20 chars long";
        
        // Use reflection to access protected method
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", 
            StringBuffer.class, 
            int.class, 
            int.class, 
            String.class
        );
        renderWrappedText.setAccessible(true);
        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
            formatter, 
            sb, 
            20, 
            4, 
            text
        );
        
        assertEquals(text, result.toString());
    }

    @Test
    public void testRenderWrappedText_TextWithLeadingTrailingSpaces() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");
        
        StringBuffer sb = new StringBuffer();
        String text = "   text with spaces   ";
        
        // Use reflection to access protected method
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", 
            StringBuffer.class, 
            int.class, 
            int.class, 
            String.class
        );
        renderWrappedText.setAccessible(true);
        StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 15, 4, text);
        
        assertEquals("text with spaces", result.toString());
    }


}
