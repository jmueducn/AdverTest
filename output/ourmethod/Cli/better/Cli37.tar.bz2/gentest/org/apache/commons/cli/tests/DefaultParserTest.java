package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
 
public class DefaultParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                          public void testIsShortOption_NotStartingWithDash_ReturnsFalse() throws Exception {
                                                              DefaultParser parser = new DefaultParser();
                                                              Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                              isShortOptionMethod.setAccessible(true);
                                                              boolean result = (boolean) isShortOptionMethod.invoke(parser, "option");
                                                              assertFalse(result);
                                                          }

    @Test
                                                          public void testIsShortOption_EmptyString_ReturnsFalse() throws Exception {
                                                              DefaultParser parser = new DefaultParser();
                                                              Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                              isShortOptionMethod.setAccessible(true);
                                                              boolean result = (boolean) isShortOptionMethod.invoke(parser, "");
                                                              assertFalse(result);
                                                          }

    @Test
                                                          public void testIsShortOption_OnlyEqualsSign_ReturnsFalse() throws Exception {
                                                              DefaultParser parser = new DefaultParser();
                                                              Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                              isShortOptionMethod.setAccessible(true);
                                                              boolean result = (boolean) isShortOptionMethod.invoke(parser, "-=");
                                                              assertFalse(result);
                                                          }

    @Test
                                                      public void testIsShortOption_SingleDash_ReturnsFalse() throws Exception {
                                                          DefaultParser parser = new DefaultParser();
                                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                          isShortOptionMethod.setAccessible(true);
                                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, "-");
                                                          assertFalse(result);
                                                      }

    @Test
                                                      public void testIsShortOption_ValidShortOptionNoValue_ReturnsTrue() throws Exception {
                                                          DefaultParser parser = new DefaultParser();
                                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                          isShortOptionMethod.setAccessible(true);
                                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, "-f");
                                                          assertTrue(result);
                                                      }

    @Test
                                                      public void testIsShortOption_ValidShortOptionWithValue_ReturnsTrue() throws Exception {
                                                          // Setup
                                                          DefaultParser parser = new DefaultParser();
                                                          
                                                          // Get the private method using reflection
                                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                          isShortOptionMethod.setAccessible(true);
                                                          
                                                          // Test and verify
                                                          assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-f=value"));
                                                      }

    @Test
                                                      public void testIsShortOption_InvalidShortOptionNoValue_ReturnsFalse() throws Exception {
                                                          DefaultParser parser = new DefaultParser();
                                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                          isShortOptionMethod.setAccessible(true);
                                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, "-x");
                                                          assertFalse(result);
                                                      }

    @Test
                                                      public void testIsShortOption_InvalidShortOptionWithValue_ReturnsFalse() throws Exception {
                                                          DefaultParser parser = new DefaultParser();
                                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                          isShortOptionMethod.setAccessible(true);
                                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, "-x=value");
                                                          assertFalse(result);
                                                      }

    @Test
                                                      public void testIsShortOption_MultipleCharacterOptionNoValue_ReturnsTrue() throws Exception {
                                                          DefaultParser parser = new DefaultParser();
                                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                          isShortOptionMethod.setAccessible(true);
                                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, "-abc");
                                                          assertTrue(result);
                                                      }

    @Test
                                                      public void testIsShortOption_MultipleCharacterOptionWithValue_ReturnsTrue() {
                                                          // Create mock objects
                                                          Options options = mock(Options.class);
                                                          DefaultParser parser = new DefaultParser();
                                                          
                                                          // Set up mock behavior
                                                          when(options.hasShortOption("abc")).thenReturn(true);
                                                          
                                                          try {
                                                              // Use reflection to set the private options field in parser
                                                              Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                              optionsField.setAccessible(true);
                                                              optionsField.set(parser, options);
                                                              
                                                              // Use reflection to access the private isShortOption method
                                                              Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                              isShortOptionMethod.setAccessible(true);
                                                              
                                                              // Test the method
                                                              boolean result = (boolean) isShortOptionMethod.invoke(parser, "-abc=value");
                                                              assertTrue(result);
                                                          } catch (Exception e) {
                                                              fail("Failed to test isShortOption due to reflection error: " + e.getMessage());
                                                          }
                                                      }

    @Test
                                                      public void testIsShortOption_NullInput_ThrowsException() throws Exception {
                                                          DefaultParser parser = new DefaultParser();
                                                          Method method = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                          method.setAccessible(true);
                                                          
                                                          try {
                                                              method.invoke(parser, (Object) null);
                                                              fail("Expected NullPointerException to be thrown");
                                                          } catch (InvocationTargetException e) {
                                                              assertTrue(e.getCause() instanceof NullPointerException);
                                                          }
                                                      }

    @Test
                                                      public void testIsShortOption_OptionWithEmptyValue_ReturnsTrue() throws Exception {
                                                          DefaultParser parser = new DefaultParser();
                                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                          isShortOptionMethod.setAccessible(true);
                                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, "-f=");
                                                          assertTrue(result);
                                                      }

    @Test
                                     public void testIsShortOption_DetectsMutant() {
                                         // Helper method to invoke private isShortOption method
                                         java.util.function.Function<String, Boolean> invokeIsShortOption = (String token) -> {
                                             try {
                                                 DefaultParser parser = new DefaultParser();
                                                 Options options = mock(Options.class);
                                                 
                                                 // Use reflection to set the private options field in parser
                                                 Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                 optionsField.setAccessible(true);
                                                 optionsField.set(parser, options);
                                                 
                                                 // Get the private isShortOption method
                                                 Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                 isShortOptionMethod.setAccessible(true);
                                                 
                                                 return (Boolean) isShortOptionMethod.invoke(parser, token);
                                             } catch (Exception e) {
                                                 fail("Failed to invoke isShortOption method: " + e.getMessage());
                                                 return false;
                                             }
                                         };
                                     
                                         // Create parser instance and mock options
                                         DefaultParser parser = new DefaultParser();
                                         Options options = mock(Options.class);
                                         
                                         // Use reflection to set the private options field in parser
                                         try {
                                             Field optionsField = DefaultParser.class.getDeclaredField("options");
                                             optionsField.setAccessible(true);
                                             optionsField.set(parser, options);
                                         } catch (Exception e) {
                                             fail("Failed to set options field via reflection");
                                         }
                                         
                                         // Case 1: Token starts with "-" but length is 1 - should return false
                                         assertFalse(invokeIsShortOption.apply("-"));
                                         
                                         // Case 2: Token doesn't start with "-" but length > 1 - should return false
                                         assertFalse(invokeIsShortOption.apply("abc"));
                                         
                                         // Case 3: Valid short option - starts with "-" and length > 1
                                         when(options.hasShortOption("f")).thenReturn(true);
                                         assertTrue(invokeIsShortOption.apply("-f"));
                                         
                                         // Case 4: Token doesn't start with "-" and length is 1 - should return false
                                         assertFalse(invokeIsShortOption.apply("a"));
                                     }

    @Test
                                public void testIsShortOptionWithMultipleEquals() throws Exception {
                                    // Setup test objects
                                    DefaultParser parser = new DefaultParser();
                                    Options options = mock(Options.class);
                                    
                                    // Use reflection to set protected field
                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                    optionsField.setAccessible(true);
                                    optionsField.set(parser, options);
                                    
                                    // Configure mock behavior
                                    when(options.hasShortOption("a")).thenReturn(true);
                                    when(options.hasShortOption("a=b")).thenReturn(false);
                                    
                                    // Test with token containing multiple equals signs
                                    String token = "-a=b=c";
                                    
                                    // Use reflection to access private method
                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                    isShortOptionMethod.setAccessible(true);
                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                    
                                    // Original should return true (a is valid short option)
                                    // Mutated will return false (a=b is not valid short option)
                                    assertTrue(result);
                                    
                                    // Verify mock interactions
                                    verify(options).hasShortOption("a");
                                }

    @Test
                       public void testIsShortOption_WithoutEqualSign_ShouldExtractCorrectOptionName() throws Exception {
                           // Setup
                           DefaultParser parser = new DefaultParser();
                           Options options = mock(Options.class);
                           
                           // Use reflection to set protected options field
                           Field optionsField = DefaultParser.class.getDeclaredField("options");
                           optionsField.setAccessible(true);
                           optionsField.set(parser, options);
                           
                           // Mock behavior - only accept "a" as short option, not "-a"
                           when(options.hasShortOption("a")).thenReturn(true);
                           when(options.hasShortOption("-a")).thenReturn(false);
                           
                           // Use reflection to access private isShortOption method
                           Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                           isShortOptionMethod.setAccessible(true);
                           
                           // Test with simple short option "-a"
                           String token = "-a";
                           boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                           
                           // Verify
                           assertTrue("Should recognize -a as valid short option", result);
                           
                           // Verify the correct option name was checked
                           verify(options).hasShortOption("a");
                           verify(options, never()).hasShortOption("-a");
                       }

    @Test
                  public void testIsShortOption_ValidSingleCharOption_ShouldReturnTrue() throws Exception {
                      // Setup
                      DefaultParser parser = new DefaultParser();
                      Options options = mock(Options.class);
                      
                      // Use reflection to set the protected options field
                      Field optionsField = DefaultParser.class.getDeclaredField("options");
                      optionsField.setAccessible(true);
                      optionsField.set(parser, options);
                      
                      // Mock the options to return true for short option "a"
                      when(options.hasShortOption("a")).thenReturn(true);
                      
                      // Test a valid single-character short option without equals
                      String token = "-a";
                      
                      // Use reflection to access the private isShortOption method
                      Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                      isShortOptionMethod.setAccessible(true);
                      boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                      
                      // Verify
                      assertTrue(result);
                      
                      // Verify interaction with mock
                      verify(options).hasShortOption("a");
                  }

    @Test
             public void testIsShortOption_EqualsSignAtPosition() throws Exception {
                 // Setup
                 DefaultParser parser = new DefaultParser();
                 
                 // Use reflection to set protected options field
                 Field optionsField = DefaultParser.class.getDeclaredField("options");
                 optionsField.setAccessible(true);
                 optionsField.set(parser, mock(Options.class));
                 
                 // This token is invalid per method's initial check, but tests the mutation
                 String token = "=-abc";
                 
                 // Use reflection to access private isShortOption method
                 Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                 isShortOptionMethod.setAccessible(true);
                 boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                 
                 // Verify the method returns false (due to initial checks)
                 assertFalse(result);
                 
                 // The key point is that the mutation affects behavior even if the initial check fails
                 // The original would process the substring differently than the mutant
             }

    @Test
             public void testIsShortOption_EqualsSignAtPosition1() throws Exception {
                 // Setup
                 DefaultParser parser = new DefaultParser();
                 
                 // Mock options using reflection since it's protected
                 Options mockOptions = mock(Options.class);
                 when(mockOptions.hasShortOption("a")).thenReturn(true);
                 
                 Field optionsField = DefaultParser.class.getDeclaredField("options");
                 optionsField.setAccessible(true);
                 optionsField.set(parser, mockOptions);
                 
                 String token = "-a=value";
                 
                 // Access private method via reflection
                 Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                 isShortOptionMethod.setAccessible(true);
                 boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                 
                 // Both original and mutant would find "=" at position 2
                 assertTrue(result);
                 verify(mockOptions).hasShortOption("a");
             }

    @Test
             public void testIsShortOption_EqualsSignAtPosition2() throws Exception {
                 // Setup
                 DefaultParser parser = new DefaultParser();
                 
                 // Mock options using reflection since it's protected
                 Options mockOptions = mock(Options.class);
                 Field optionsField = DefaultParser.class.getDeclaredField("options");
                 optionsField.setAccessible(true);
                 optionsField.set(parser, mockOptions);
                 
                 when(mockOptions.hasShortOption("ab")).thenReturn(true);
                 
                 String token = "-ab=value";
                 
                 // Access private method using reflection
                 Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                 isShortOptionMethod.setAccessible(true);
                 boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                 
                 // Both original and mutant would find "=" at position 3
                 assertTrue(result);
                 verify(mockOptions).hasShortOption("ab");
             }

    @Test
    public void testIsShortOption_WithEqualsNotAtPosition1_DetectsMutant() {
        // Create mock objects
        Options options = mock(Options.class);
        DefaultParser parser = new DefaultParser();
        
        // Setup mock behavior
        when(options.hasShortOption("abc")).thenReturn(true);
        
        // Test case where "=" is not at position 1
        String token = "-abc=value";
        
        // Use reflection to set the private options field in parser
        try {
            Field optionsField = DefaultParser.class.getDeclaredField("options");
            optionsField.setAccessible(true);
            optionsField.set(parser, options);
        } catch (Exception e) {
            fail("Failed to set options field via reflection");
        }
        
        // Use reflection to invoke the private isShortOption method
        boolean result;
        try {
            Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
            isShortOptionMethod.setAccessible(true);
            result = (boolean) isShortOptionMethod.invoke(parser, token);
        } catch (Exception e) {
            fail("Failed to invoke isShortOption method via reflection");
            return;
        }
        
        // Verify correct behavior
        assertTrue(result);
        verify(options).hasShortOption("abc");
        
        // Mutant would call hasShortOption("ab") which would fail
    }

    @Test
    public void testIsShortOption_NoEquals_DetectsMutant() {
        // Create mock objects
        Options options = mock(Options.class);
        DefaultParser parser = new DefaultParser();
        
        // Setup mock behavior
        when(options.hasShortOption("abc")).thenReturn(true);
        
        // Inject options into parser using reflection
        try {
            Field optionsField = DefaultParser.class.getDeclaredField("options");
            optionsField.setAccessible(true);
            optionsField.set(parser, options);
        } catch (Exception e) {
            fail("Failed to set options field via reflection");
        }
        
        // Test case with no "="
        String token = "-abc";
        
        // Use reflection to invoke private isShortOption method
        boolean result;
        try {
            Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
            isShortOptionMethod.setAccessible(true);
            result = (boolean) isShortOptionMethod.invoke(parser, token);
        } catch (Exception e) {
            fail("Failed to invoke isShortOption method via reflection");
            return;
        }
        
        // Verify correct behavior
        assertTrue(result);
        verify(options).hasShortOption("abc");
    }

    @Test
    public void testIsShortOption_EqualsAtPosition1_WorksSame() throws Exception {
        // Create mock objects
        Options options = mock(Options.class);
        DefaultParser parser = new DefaultParser();
        
        // Setup mock behavior
        when(options.hasShortOption("a")).thenReturn(true);
        
        // Test case where "=" is at position 1
        String token = "-a=value";
        
        // Use reflection to access private method
        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
        isShortOptionMethod.setAccessible(true);
        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
        
        assertTrue(result);
        verify(options).hasShortOption("a");
    }


}
