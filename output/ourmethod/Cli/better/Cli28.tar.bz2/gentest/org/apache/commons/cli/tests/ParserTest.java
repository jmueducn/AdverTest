package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;
 
public class ParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                             public void testProcessProperties_OptionWithoutArg_ValidValues() {
                                                                                                                                                                                                                                 // Create test properties
                                                                                                                                                                                                                                 Properties props = new Properties();
                                                                                                                                                                                                                                 props.setProperty("flag1", "yes");
                                                                                                                                                                                                                                 props.setProperty("flag2", "true");
                                                                                                                                                                                                                                 props.setProperty("flag3", "1");
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Mock the Option
                                                                                                                                                                                                                                 Option opt = mock(Option.class);
                                                                                                                                                                                                                                 when(opt.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Mock the CommandLine and Options
                                                                                                                                                                                                                                 CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                                 Options options = mock(Options.class);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Create a real parser instance (can't mock abstract class with protected methods)
                                                                                                                                                                                                                                 // We'll use an anonymous subclass to access protected methods
                                                                                                                                                                                                                                 Parser parser = new Parser() {
                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                     protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                         return new String[0];
                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                     protected Options getOptions() {
                                                                                                                                                                                                                                         return options;
                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                 };
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Set up mock behavior
                                                                                                                                                                                                                                 when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                                                                 when(options.getOption(anyString())).thenReturn(opt);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Use reflection to set the cmd field in parser since it's protected
                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                     Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                     cmdField.setAccessible(true);
                                                                                                                                                                                                                                     cmdField.set(parser, cmd);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Also need to set options field since we're not using the mocked getOptions()
                                                                                                                                                                                                                                     Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                                     optionsField.setAccessible(true);
                                                                                                                                                                                                                                     optionsField.set(parser, options);
                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                     fail("Failed to set fields via reflection");
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Use reflection to call the protected processProperties method
                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                     Method method = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                     method.setAccessible(true);
                                                                                                                                                                                                                                     method.invoke(parser, props);
                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                     fail("Failed to invoke processProperties via reflection");
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Verify the behavior - need to use reflection to verify addOption calls
                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                     Field optionsField = CommandLine.class.getDeclaredField("options");
                                                                                                                                                                                                                                     optionsField.setAccessible(true);
                                                                                                                                                                                                                                     @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                     List<Option> optionList = (List<Option>) optionsField.get(cmd);
                                                                                                                                                                                                                                     assertEquals(3, optionList.size());
                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                     fail("Failed to verify options via reflection");
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                             public void testProcessProperties_OptionWithoutArg_InvalidValues() {
                                                                                                                                                                                                                                 // Create test properties
                                                                                                                                                                                                                                 Properties props = new Properties();
                                                                                                                                                                                                                                 props.setProperty("flag1", "no");
                                                                                                                                                                                                                                 props.setProperty("flag2", "false");
                                                                                                                                                                                                                                 props.setProperty("flag3", "0");
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Mock the Option
                                                                                                                                                                                                                                 Option opt = mock(Option.class);
                                                                                                                                                                                                                                 when(opt.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Mock the CommandLine and Options
                                                                                                                                                                                                                                 CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                                 Options options = mock(Options.class);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Create the parser instance (assuming it's a BasicParser or similar)
                                                                                                                                                                                                                                 Parser parser = new BasicParser();
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Use reflection to set private fields if needed
                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                     Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                                     optionsField.setAccessible(true);
                                                                                                                                                                                                                                     optionsField.set(parser, options);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                     cmdField.setAccessible(true);
                                                                                                                                                                                                                                     cmdField.set(parser, cmd);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Access the protected processProperties method via reflection
                                                                                                                                                                                                                                     Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                     processProperties.setAccessible(true);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Set up mock behavior
                                                                                                                                                                                                                                     when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                                                                     when(options.getOption(anyString())).thenReturn(opt);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Test the method
                                                                                                                                                                                                                                     processProperties.invoke(parser, props);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Verify behavior - since we can't verify addOption directly, verify that hasOption was called
                                                                                                                                                                                                                                     // with the expected values but never returned true (meaning options weren't added)
                                                                                                                                                                                                                                     verify(cmd, times(3)).hasOption(anyString());
                                                                                                                                                                                                                                     verify(cmd, never()).hasOption(eq("flag1"));
                                                                                                                                                                                                                                     verify(cmd, never()).hasOption(eq("flag2"));
                                                                                                                                                                                                                                     verify(cmd, never()).hasOption(eq("flag3"));
                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                     fail("Failed to test processProperties: " + e.getMessage());
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                         public void testProcessProperties_OptionWithArg_ValidValue() {
                                                                                                                                                                                                                             // Setup test objects
                                                                                                                                                                                                                             Properties props = new Properties();
                                                                                                                                                                                                                             props.setProperty("optWithArg", "testValue");
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Create mocks
                                                                                                                                                                                                                             CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                             Options options = mock(Options.class);
                                                                                                                                                                                                                             Option opt = mock(Option.class);
                                                                                                                                                                                                                             Parser parser = new Parser() {
                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                 protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                     return new String[0];
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                             };
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Set mock behavior
                                                                                                                                                                                                                             when(opt.hasArg()).thenReturn(true);
                                                                                                                                                                                                                             when(opt.getValues()).thenReturn(null);
                                                                                                                                                                                                                             when(cmd.hasOption("optWithArg")).thenReturn(false);
                                                                                                                                                                                                                             when(options.getOption("optWithArg")).thenReturn(opt);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Use reflection to set private fields if needed
                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                 Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                                 optionsField.setAccessible(true);
                                                                                                                                                                                                                                 optionsField.set(parser, options);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                 cmdField.setAccessible(true);
                                                                                                                                                                                                                                 cmdField.set(parser, cmd);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Use reflection to access protected method
                                                                                                                                                                                                                                 Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                 processProperties.setAccessible(true);
                                                                                                                                                                                                                                 processProperties.invoke(parser, props);
                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                 fail("Failed to set up parser fields via reflection: " + e.getMessage());
                                                                                                                                                                                                                             }
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Verify interactions
                                                                                                                                                                                                                             verify(opt).addValue("testValue");
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Instead of trying to verify the private addOption call, we can verify that the option was processed
                                                                                                                                                                                                                             // by checking that the value was added to the option
                                                                                                                                                                                                                             verify(opt).getValues(); // This was called during processing
                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                         public void testProcessProperties_OptionWithArg_AlreadyHasValue() {
                                                                                                                                                                                                                             // Setup test objects
                                                                                                                                                                                                                             Properties props = new Properties();
                                                                                                                                                                                                                             props.setProperty("optWithArg", "testValue");
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                             Option opt = mock(Option.class);
                                                                                                                                                                                                                             CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                             Options options = mock(Options.class);
                                                                                                                                                                                                                             Parser parser = new Parser() {
                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                 protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                     return new String[0];
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                             };
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Set mock behavior
                                                                                                                                                                                                                             when(opt.hasArg()).thenReturn(true);
                                                                                                                                                                                                                             when(opt.getValues()).thenReturn(new String[]{"existing"});
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             when(cmd.hasOption("optWithArg")).thenReturn(false);
                                                                                                                                                                                                                             when(options.getOption("optWithArg")).thenReturn(opt);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Use reflection to set private fields if needed
                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                 Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                                 optionsField.setAccessible(true);
                                                                                                                                                                                                                                 optionsField.set(parser, options);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                 cmdField.setAccessible(true);
                                                                                                                                                                                                                                 cmdField.set(parser, cmd);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Access protected method via reflection
                                                                                                                                                                                                                                 Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                 processProperties.setAccessible(true);
                                                                                                                                                                                                                                 processProperties.invoke(parser, props);
                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                 fail("Failed to set up or execute test via reflection: " + e.getMessage());
                                                                                                                                                                                                                             }
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Verify behavior by checking if the option was processed
                                                                                                                                                                                                                             // We verify that the option was retrieved from options
                                                                                                                                                                                                                             verify(options).getOption("optWithArg");
                                                                                                                                                                                                                             // And that it has arguments (since we set hasArg to true)
                                                                                                                                                                                                                             verify(opt).hasArg();
                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                             public void testProcessProperties_MultipleProperties() {
                                                                                                                                                                                                                 // Setup test objects
                                                                                                                                                                                                                 java.util.Properties props = new java.util.Properties();
                                                                                                                                                                                                                 props.setProperty("opt1", "value1");
                                                                                                                                                                                                                 props.setProperty("flag1", "true");
                                                                                                                                                                                                                 props.setProperty("opt2", "value2");
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Mock enumeration for property names
                                                                                                                                                                                                                 java.util.Vector<String> keys = new java.util.Vector<String>();
                                                                                                                                                                                                                 keys.add("opt1");
                                                                                                                                                                                                                 keys.add("flag1");
                                                                                                                                                                                                                 keys.add("opt2");
                                                                                                                                                                                                                 @SuppressWarnings("rawtypes")
                                                                                                                                                                                                                 java.util.Enumeration enumeration = keys.elements();
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Create a spy of properties to control propertyNames() return
                                                                                                                                                                                                                 java.util.Properties spyProps = spy(props);
                                                                                                                                                                                                                 when(spyProps.propertyNames()).thenReturn(enumeration);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Mock command line and options
                                                                                                                                                                                                                 CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                 Options options = mock(Options.class);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Create parser instance
                                                                                                                                                                                                                 Parser parser = new BasicParser();
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                     Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                     optionsField.setAccessible(true);
                                                                                                                                                                                                                     optionsField.set(parser, options);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                     cmdField.setAccessible(true);
                                                                                                                                                                                                                     cmdField.set(parser, cmd);
                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                     fail("Failed to set up parser fields via reflection: " + e.getMessage());
                                                                                                                                                                                                                 }
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Mock options
                                                                                                                                                                                                                 Option optWithArg = mock(Option.class);
                                                                                                                                                                                                                 when(optWithArg.hasArg()).thenReturn(true);
                                                                                                                                                                                                                 when(optWithArg.getValues()).thenReturn(new String[0]);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 Option flag = mock(Option.class);
                                                                                                                                                                                                                 when(flag.hasArg()).thenReturn(false);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                                                 when(options.getOption("opt1")).thenReturn(optWithArg);
                                                                                                                                                                                                                 when(options.getOption("flag1")).thenReturn(flag);
                                                                                                                                                                                                                 when(options.getOption("opt2")).thenReturn(optWithArg);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Test the method using reflection since it's protected
                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                     Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                     processPropertiesMethod.setAccessible(true);
                                                                                                                                                                                                                     processPropertiesMethod.invoke(parser, spyProps);
                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                     fail("Failed to invoke processProperties: " + e.getMessage());
                                                                                                                                                                                                                 }
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify interactions by checking the results rather than implementation details
                                                                                                                                                                                                                 // Since we can't verify non-public methods directly, we'll verify the expected state changes
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify that properties were processed by checking the command line state
                                                                                                                                                                                                                 // This assumes the parser sets some visible state we can check
                                                                                                                                                                                                                 // If there's no public way to verify, we might need to reconsider the test approach
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Alternative verification approach:
                                                                                                                                                                                                                 // Since we can't verify the internal method calls, we can verify the expected
                                                                                                                                                                                                                 // behavior through the public API or other observable effects
                                                                                                                                                                                                                 verify(options, times(3)).getOption(anyString());
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // If the parser modifies the command line in a way that's visible through its public API,
                                                                                                                                                                                                                 // we should verify that instead of implementation details
                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                 public void testProcessProperties_OptionWithArg_ExceptionDuringProcessing() {
                                                                                                                                                                                                     // Setup test objects
                                                                                                                                                                                                     Properties props = new Properties();
                                                                                                                                                                                                     props.setProperty("problemOpt", "badValue");
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Mock required objects
                                                                                                                                                                                                     Option opt = mock(Option.class);
                                                                                                                                                                                                     Options options = mock(Options.class);
                                                                                                                                                                                                     CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                     DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Set mock behaviors
                                                                                                                                                                                                     when(opt.hasArg()).thenReturn(true);
                                                                                                                                                                                                     when(opt.getValues()).thenReturn(null);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Mock the behavior to throw exception when processing the option
                                                                                                                                                                                                     // We'll let the actual processing fail naturally rather than mocking a private method
                                                                                                                                                                                                     when(cmd.hasOption("problemOpt")).thenReturn(false);
                                                                                                                                                                                                     when(options.getOption("problemOpt")).thenReturn(opt);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Set the options and cmd on the parser using reflection
                                                                                                                                                                                                     try {
                                                                                                                                                                                                         Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                                                                                         optionsField.setAccessible(true);
                                                                                                                                                                                                         optionsField.set(parser, options);
                                                                                                                                                                                                         
                                                                                                                                                                                                         Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                                                                                                                         cmdField.setAccessible(true);
                                                                                                                                                                                                         cmdField.set(parser, cmd);
                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                         fail("Failed to set parser fields via reflection");
                                                                                                                                                                                                     }
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Call processProperties using reflection since it's protected
                                                                                                                                                                                                     try {
                                                                                                                                                                                                         Method processProperties = DefaultParser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                         processProperties.setAccessible(true);
                                                                                                                                                                                                         processProperties.invoke(parser, props);
                                                                                                                                                                                                     } catch (InvocationTargetException e) {
                                                                                                                                                                                                         // Expected - the exception should be thrown during processing
                                                                                                                                                                                                         assertTrue(e.getCause() instanceof RuntimeException);
                                                                                                                                                                                                         assertEquals("Test exception", e.getCause().getMessage());
                                                                                                                                                                                                         return;
                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                         fail("Unexpected exception: " + e.getMessage());
                                                                                                                                                                                                     }
                                                                                                                                                                                                     
                                                                                                                                                                                                     fail("Expected RuntimeException was not thrown");
                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                             public void testProcessProperties_NullProperties() {
                                                                                                                                                                                                 // Create mock objects
                                                                                                                                                                                                 org.apache.commons.cli.DefaultParser parser = new org.apache.commons.cli.DefaultParser();
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Should do nothing and not throw any exceptions
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Verify no interactions with the CommandLine mock
                                                                                                                                                                                                 // Note: Since cmd isn't actually used in processProperties, this verification is redundant
                                                                                                                                                                                                 // but kept as per original test intent
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                             public void testProcessProperties_OptionAlreadyInCmd() {
                                                                                                                                                                                                 // Setup test objects
                                                                                                                                                                                                 CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                 DefaultParser parser = new DefaultParser() {
                                                                                                                                                                                                     protected void processProperties(Properties properties) {
                                                                                                                                                                                                         try {
                                                                                                                                                                                                             // Get the parent class's processProperties method
                                                                                                                                                                                                             Method method = DefaultParser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                             // Invoke on the parent class
                                                                                                                                                                                                             method.invoke(this, properties);
                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                             fail("Failed to invoke processProperties method");
                                                                                                                                                                                                         }
                                                                                                                                                                                                     }
                                                                                                                                                                                                     
                                                                                                                                                                                                     protected CommandLine getCommandLine() {
                                                                                                                                                                                                         return cmd;
                                                                                                                                                                                                     }
                                                                                                                                                                                                 };
                                                                                                                                                                                                 
                                                                                                                                                                                                 Properties props = new Properties();
                                                                                                                                                                                                 props.setProperty("existingOpt", "value");
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Mock the behavior
                                                                                                                                                                                                 when(cmd.hasOption("existingOpt")).thenReturn(true);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Call the method
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Verify hasOption was called
                                                                                                                                                                                                 verify(cmd).hasOption("existingOpt");
                                                                                                                                                                                                 // Verify addOption was NOT called
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                        public void testProcessPropertiesWithMultipleBooleanOptions() throws Exception {
                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                            Properties properties = new Properties();
                                                                                                                                                                                            properties.setProperty("opt1", "true");  // should be added
                                                                                                                                                                                            properties.setProperty("opt2", "no");   // should be skipped (continue)
                                                                                                                                                                                            properties.setProperty("opt3", "1");    // should be added (but mutant breaks before this)
                                                                                                                                                                                            
                                                                                                                                                                                            // Mock dependencies
                                                                                                                                                                                            CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                            Options options = mock(Options.class);
                                                                                                                                                                                            Option opt1 = mock(Option.class);
                                                                                                                                                                                            Option opt2 = mock(Option.class);
                                                                                                                                                                                            Option opt3 = mock(Option.class);
                                                                                                                                                                                            
                                                                                                                                                                                            // Stub behavior
                                                                                                                                                                                            when(opt1.hasArg()).thenReturn(false);
                                                                                                                                                                                            when(opt2.hasArg()).thenReturn(false);
                                                                                                                                                                                            when(opt3.hasArg()).thenReturn(false);
                                                                                                                                                                                            when(options.getOption("opt1")).thenReturn(opt1);
                                                                                                                                                                                            when(options.getOption("opt2")).thenReturn(opt2);
                                                                                                                                                                                            when(options.getOption("opt3")).thenReturn(opt3);
                                                                                                                                                                                            when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                            
                                                                                                                                                                                            // Create parser and set dependencies using reflection
                                                                                                                                                                                            Parser parser = new Parser() {
                                                                                                                                                                                                @Override
                                                                                                                                                                                                protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                    return new String[0];
                                                                                                                                                                                                }
                                                                                                                                                                                            };
                                                                                                                                                                                            
                                                                                                                                                                                            // Set protected options field using reflection
                                                                                                                                                                                            Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                            optionsField.setAccessible(true);
                                                                                                                                                                                            optionsField.set(parser, options);
                                                                                                                                                                                            
                                                                                                                                                                                            // Set protected cmd field using reflection
                                                                                                                                                                                            Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                            cmdField.setAccessible(true);
                                                                                                                                                                                            cmdField.set(parser, cmd);
                                                                                                                                                                                            
                                                                                                                                                                                            // Call protected processProperties method using reflection
                                                                                                                                                                                            Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                            processPropertiesMethod.setAccessible(true);
                                                                                                                                                                                            processPropertiesMethod.invoke(parser, properties);
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify all valid options were processed
                                                                                                                                                                                            // Using reflection to verify addOption calls since it's not public
                                                                                                                                                                                            Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                                                                                                                                            addOptionMethod.setAccessible(true);
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify opt1 was added
                                                                                                                                                                                            verify(cmd, times(1)).hasOption("opt1");
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify opt3 was added
                                                                                                                                                                                            verify(cmd, times(1)).hasOption("opt3");
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify opt2 was never added
                                                                                                                                                                                            verify(cmd, never()).hasOption("opt2");
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify number of interactions
                                                                                                                                                                                            verify(cmd, times(2)).hasOption(anyString());
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                       public void testProcessPropertiesBooleanOptionWithNegativeValue() throws Exception {
                                                                                                                                                                           // Setup test data
                                                                                                                                                                           Properties props = new Properties();
                                                                                                                                                                           props.setProperty("verbose", "false"); // Negative boolean value
                                                                                                                                                                           
                                                                                                                                                                           // Create required objects
                                                                                                                                                                           Options options = new Options();
                                                                                                                                                                           options.addOption(new Option("verbose", "verbose option")); // Boolean option
                                                                                                                                                                           
                                                                                                                                                                           // Create parser instance using reflection since constructor is not public
                                                                                                                                                                           Constructor<Parser> constructor = Parser.class.getDeclaredConstructor();
                                                                                                                                                                           constructor.setAccessible(true);
                                                                                                                                                                           Parser parser = constructor.newInstance();
                                                                                                                                                                           
                                                                                                                                                                           // Set options using reflection since setOptions is protected
                                                                                                                                                                           Method setOptionsMethod = Parser.class.getDeclaredMethod("setOptions", Options.class);
                                                                                                                                                                           setOptionsMethod.setAccessible(true);
                                                                                                                                                                           setOptionsMethod.invoke(parser, options);
                                                                                                                                                                           
                                                                                                                                                                           // Create command line instance using parse() since constructor is not public
                                                                                                                                                                           CommandLine cmd = parser.parse(options, new String[0]);
                                                                                                                                                                           
                                                                                                                                                                           // Mock cmd to track option presence
                                                                                                                                                                           CommandLine spyCmd = spy(cmd);
                                                                                                                                                                           when(spyCmd.hasOption("verbose")).thenReturn(false);
                                                                                                                                                                           
                                                                                                                                                                           // Get processProperties method via reflection since it's protected
                                                                                                                                                                           Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                           processPropertiesMethod.setAccessible(true);
                                                                                                                                                                           
                                                                                                                                                                           // Execute test
                                                                                                                                                                           processPropertiesMethod.invoke(parser, props);
                                                                                                                                                                           
                                                                                                                                                                           // Verify - option should NOT be present for negative boolean value
                                                                                                                                                                           // Instead of verifying addOption, we just verify the final state
                                                                                                                                                                           assertFalse(spyCmd.hasOption("verbose"));
                                                                                                                                                                       }

    @Test
                                                                                                                                                                  public void testProcessProperties_ShouldNotAddBooleanOptionWithInvalidValue() {
                                                                                                                                                                      // Setup test data
                                                                                                                                                                      Properties properties = new Properties();
                                                                                                                                                                      properties.setProperty("testOpt", "false"); // Invalid value for boolean option
                                                                                                                                                                      
                                                                                                                                                                      // Create mock objects
                                                                                                                                                                      CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                      Options options = mock(Options.class);
                                                                                                                                                                      Option opt = mock(Option.class);
                                                                                                                                                                      
                                                                                                                                                                      // Setup mock behavior
                                                                                                                                                                      when(opt.hasArg()).thenReturn(false); // Boolean option
                                                                                                                                                                      when(options.getOption("testOpt")).thenReturn(opt);
                                                                                                                                                                      when(cmd.hasOption("testOpt")).thenReturn(false); // Option not already in cmd
                                                                                                                                                                      
                                                                                                                                                                      // Create parser and set test data
                                                                                                                                                                      Parser parser = new Parser() {
                                                                                                                                                                          @Override
                                                                                                                                                                          protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                              return new String[0];
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set protected options field
                                                                                                                                                                      try {
                                                                                                                                                                          Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                          optionsField.setAccessible(true);
                                                                                                                                                                          optionsField.set(parser, options);
                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                          fail("Failed to set options field via reflection");
                                                                                                                                                                      }
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set protected cmd field
                                                                                                                                                                      try {
                                                                                                                                                                          Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                          cmdField.setAccessible(true);
                                                                                                                                                                          cmdField.set(parser, cmd);
                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                          fail("Failed to set cmd field via reflection");
                                                                                                                                                                      }
                                                                                                                                                                      
                                                                                                                                                                      // Execute method under test using reflection
                                                                                                                                                                      try {
                                                                                                                                                                          Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                          processProperties.setAccessible(true);
                                                                                                                                                                          processProperties.invoke(parser, properties);
                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                          fail("Failed to invoke processProperties via reflection");
                                                                                                                                                                      }
                                                                                                                                                                      
                                                                                                                                                                      // Verify behavior - option should NOT be added
                                                                                                                                                                      // We need to verify the internal behavior through reflection since addOption is not public
                                                                                                                                                                      try {
                                                                                                                                                                          Field optionsField = CommandLine.class.getDeclaredField("options");
                                                                                                                                                                          optionsField.setAccessible(true);
                                                                                                                                                                          @SuppressWarnings("unchecked")
                                                                                                                                                                          List<Option> actualOptions = (List<Option>) optionsField.get(cmd);
                                                                                                                                                                          assertFalse("Option should not be added", actualOptions.contains(opt));
                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                          fail("Failed to verify options via reflection");
                                                                                                                                                                      }
                                                                                                                                                                  }

    @Test
                                                                                                                                                             public void testProcessProperties_ShouldAddOptionToCommandLine() {
                                                                                                                                                                 // Setup test data
                                                                                                                                                                 Properties properties = new Properties();
                                                                                                                                                                 properties.setProperty("testOption", "testValue");
                                                                                                                                                                 
                                                                                                                                                                 // Create mock objects
                                                                                                                                                                 CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                                                                 Options mockOptions = mock(Options.class);
                                                                                                                                                                 Option mockOption = mock(Option.class);
                                                                                                                                                                 
                                                                                                                                                                 // Create parser instance and set mocks
                                                                                                                                                                 Parser parser = new Parser() {
                                                                                                                                                                     @Override
                                                                                                                                                                     protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                         return new String[0];
                                                                                                                                                                     }
                                                                                                                                                                 };
                                                                                                                                                                 
                                                                                                                                                                 // Use reflection to set protected fields since we don't have setters
                                                                                                                                                                 try {
                                                                                                                                                                     Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                     cmdField.setAccessible(true);
                                                                                                                                                                     cmdField.set(parser, mockCmd);
                                                                                                                                                                     
                                                                                                                                                                     Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                     optionsField.setAccessible(true);
                                                                                                                                                                     optionsField.set(parser, mockOptions);
                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                     fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                 }
                                                                                                                                                                 
                                                                                                                                                                 // Configure mock behavior
                                                                                                                                                                 when(mockOptions.getOption("testOption")).thenReturn(mockOption);
                                                                                                                                                                 when(mockCmd.hasOption("testOption")).thenReturn(false);
                                                                                                                                                                 when(mockOption.hasArg()).thenReturn(true);
                                                                                                                                                                 when(mockOption.getValues()).thenReturn(null);
                                                                                                                                                                 
                                                                                                                                                                 // Execute the method under test using reflection
                                                                                                                                                                 try {
                                                                                                                                                                     Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                     processPropertiesMethod.setAccessible(true);
                                                                                                                                                                     processPropertiesMethod.invoke(parser, properties);
                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                     fail("Failed to invoke processProperties method: " + e.getMessage());
                                                                                                                                                                 }
                                                                                                                                                                 
                                                                                                                                                                 // Verify the option was added to command line using reflection
                                                                                                                                                                 try {
                                                                                                                                                                     Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                                                                                                                     addOptionMethod.setAccessible(true);
                                                                                                                                                                     verify(mockCmd, times(1));
                                                                                                                                                                     addOptionMethod.invoke(mockCmd, mockOption);
                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                     fail("Failed to verify addOption call: " + e.getMessage());
                                                                                                                                                                 }
                                                                                                                                                             }

    @Test
                                                                                                                                                        public void testProcessProperties_AddsOptionToCommandLine() throws Exception {
                                                                                                                                                            // Setup test data
                                                                                                                                                            Properties props = new Properties();
                                                                                                                                                            props.setProperty("testOpt", "value");
                                                                                                                                                            
                                                                                                                                                            // Create mock objects
                                                                                                                                                            CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                                                            Options mockOptions = mock(Options.class);
                                                                                                                                                            Option mockOption = mock(Option.class);
                                                                                                                                                            
                                                                                                                                                            // Setup behavior for mocks
                                                                                                                                                            when(mockOptions.getOption("testOpt")).thenReturn(mockOption);
                                                                                                                                                            when(mockOption.hasArg()).thenReturn(true);
                                                                                                                                                            when(mockOption.getValues()).thenReturn(null);
                                                                                                                                                            
                                                                                                                                                            // Create parser instance and set mocks
                                                                                                                                                            Parser parser = new Parser() {
                                                                                                                                                                @Override
                                                                                                                                                                protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                    return new String[0];
                                                                                                                                                                }
                                                                                                                                                            };
                                                                                                                                                            
                                                                                                                                                            // Use reflection to set protected fields since no setters available
                                                                                                                                                            Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                            cmdField.setAccessible(true);
                                                                                                                                                            cmdField.set(parser, mockCmd);
                                                                                                                                                            
                                                                                                                                                            Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                            optionsField.setAccessible(true);
                                                                                                                                                            optionsField.set(parser, mockOptions);
                                                                                                                                                            
                                                                                                                                                            // Get the processProperties method and make it accessible
                                                                                                                                                            Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                            processPropertiesMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Execute test
                                                                                                                                                            processPropertiesMethod.invoke(parser, props);
                                                                                                                                                            
                                                                                                                                                            // Verify behavior - this will catch the mutant
                                                                                                                                                            // Need to use reflection to verify the protected addOption call
                                                                                                                                                            Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                                                                                                            addOptionMethod.setAccessible(true);
                                                                                                                                                            verify(mockCmd, times(1));
                                                                                                                                                            addOptionMethod.invoke(mockCmd, mockOption);
                                                                                                                                                        }

    @Test
                                                                                                                                       public void testProcessPropertiesAddOptionNotWrappedInConditional() throws Exception {
                                                                                                                                           // Setup test data
                                                                                                                                           Properties properties = new Properties();
                                                                                                                                           properties.setProperty("testOpt", "value");
                                                                                                                                           
                                                                                                                                           // Create mock objects
                                                                                                                                           CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                                           Options mockOptions = mock(Options.class);
                                                                                                                                           Option mockOption = mock(Option.class);
                                                                                                                                           
                                                                                                                                           // Setup mock behavior
                                                                                                                                           when(mockOptions.getOption("testOpt")).thenReturn(mockOption);
                                                                                                                                           when(mockOption.hasArg()).thenReturn(true);
                                                                                                                                           when(mockOption.getValues()).thenReturn(new String[]{"value"});
                                                                                                                                           
                                                                                                                                           // Create parser instance and set mocks
                                                                                                                                           Parser parser = new Parser() {
                                                                                                                                               @Override
                                                                                                                                               protected Options getOptions() {
                                                                                                                                                   return mockOptions;
                                                                                                                                               }
                                                                                                                                               
                                                                                                                                               @Override
                                                                                                                                               protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                   return new String[0];
                                                                                                                                               }
                                                                                                                                           };
                                                                                                                                           
                                                                                                                                           // Use reflection to set protected cmd field
                                                                                                                                           Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                           cmdField.setAccessible(true);
                                                                                                                                           cmdField.set(parser, mockCmd);
                                                                                                                                           
                                                                                                                                           // Use reflection to call protected processProperties method
                                                                                                                                           Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                           processPropertiesMethod.setAccessible(true);
                                                                                                                                           processPropertiesMethod.invoke(parser, properties);
                                                                                                                                           
                                                                                                                                           // Verify that the option was retrieved from options
                                                                                                                                           verify(mockOptions).getOption("testOpt");
                                                                                                                                           
                                                                                                                                           // Verify the option was processed (hasArg and getValues were called)
                                                                                                                                           verify(mockOption).hasArg();
                                                                                                                                           verify(mockOption).getValues();
                                                                                                                                           
                                                                                                                                           // Additional verification that no other interactions occurred with the option
                                                                                                                                           verifyNoMoreInteractions(mockOption);
                                                                                                                                       }

    @Test
                                                                                                                              public void testProcessProperties_ShouldAddEachOptionOnlyOnce() {
                                                                                                                                  // Setup test data
                                                                                                                                  Properties properties = new Properties();
                                                                                                                                  properties.setProperty("testOption", "true");
                                                                                                                                  
                                                                                                                                  // Mock dependencies
                                                                                                                                  CommandLine cmd = mock(CommandLine.class);
                                                                                                                                  Options options = mock(Options.class);
                                                                                                                                  Option opt = mock(Option.class);
                                                                                                                                  
                                                                                                                                  // Create parser instance (might need reflection if constructor is private)
                                                                                                                                  Parser parser = new Parser() {
                                                                                                                                      @Override
                                                                                                                                      protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                          return new String[0];
                                                                                                                                      }
                                                                                                                                  };
                                                                                                                                  
                                                                                                                                  // Set up mock behavior
                                                                                                                                  when(options.getOption("testOption")).thenReturn(opt);
                                                                                                                                  when(opt.hasArg()).thenReturn(false);
                                                                                                                                  when(cmd.hasOption("testOption")).thenReturn(false);
                                                                                                                                  
                                                                                                                                  // Use reflection to set private fields if needed
                                                                                                                                  try {
                                                                                                                                      Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                      cmdField.setAccessible(true);
                                                                                                                                      cmdField.set(parser, cmd);
                                                                                                                                      
                                                                                                                                      Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                      optionsField.setAccessible(true);
                                                                                                                                      optionsField.set(parser, options);
                                                                                                                                      
                                                                                                                                      // Access protected method via reflection
                                                                                                                                      Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                      processProperties.setAccessible(true);
                                                                                                                                      processProperties.invoke(parser, properties);
                                                                                                                                      
                                                                                                                                      // Verify behavior indirectly by checking if hasOption returns true after processing
                                                                                                                                      verify(cmd, times(1)).hasOption("testOption");
                                                                                                                                      
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Additional verification that no other interactions occurred
                                                                                                                                  verifyNoMoreInteractions(cmd);
                                                                                                                              }

    @Test
                                                                                                                         public void testProcessPropertiesWithNullOption() {
                                                                                                                             // Setup test data
                                                                                                                             Properties properties = new Properties();
                                                                                                                             properties.setProperty("testOption", "no"); // Value that should trigger continue
                                                                                                                             
                                                                                                                             // Mock dependencies
                                                                                                                             CommandLine cmd = mock(CommandLine.class);
                                                                                                                             Options options = mock(Options.class);
                                                                                                                             Option nullOption = null;
                                                                                                                             
                                                                                                                             // Create parser instance and set fields (using reflection since no constructor)
                                                                                                                             Parser parser = new Parser() {
                                                                                                                                 @Override
                                                                                                                                 protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                     return new String[0];
                                                                                                                                 }
                                                                                                                             };
                                                                                                                             
                                                                                                                             // Set up mock behavior
                                                                                                                             when(options.getOption("testOption")).thenReturn(nullOption);
                                                                                                                             
                                                                                                                             // Use reflection to set private fields
                                                                                                                             try {
                                                                                                                                 Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                 cmdField.setAccessible(true);
                                                                                                                                 cmdField.set(parser, cmd);
                                                                                                                                 
                                                                                                                                 Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                 optionsField.setAccessible(true);
                                                                                                                                 optionsField.set(parser, options);
                                                                                                                             } catch (Exception e) {
                                                                                                                                 fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                             }
                                                                                                                             
                                                                                                                             // Execute test using reflection to access protected method
                                                                                                                             try {
                                                                                                                                 Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                 processPropertiesMethod.setAccessible(true);
                                                                                                                                 processPropertiesMethod.invoke(parser, properties);
                                                                                                                             } catch (Exception e) {
                                                                                                                                 fail("Failed to invoke processProperties method: " + e.getMessage());
                                                                                                                             }
                                                                                                                             
                                                                                                                             // Verify behavior - should not try to add null option
                                                                                                                             // Using reflection to verify addOption was never called with null
                                                                                                                             try {
                                                                                                                                 Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                                                                                 addOptionMethod.setAccessible(true);
                                                                                                                                 verify(cmd, never());
                                                                                                                             } catch (Exception e) {
                                                                                                                                 fail("Failed to verify addOption method: " + e.getMessage());
                                                                                                                             }
                                                                                                                             
                                                                                                                             // Also verify getOption was called (to ensure we hit the right code path)
                                                                                                                             verify(options).getOption("testOption");
                                                                                                                         }

    @Test
                                                                                                                public void testProcessPropertiesWithNullOption1() {
                                                                                                                    // Setup test data
                                                                                                                    Properties properties = new Properties();
                                                                                                                    properties.setProperty("testOption", "value");
                                                                                                                    
                                                                                                                    // Mock dependencies
                                                                                                                    CommandLine cmd = mock(CommandLine.class);
                                                                                                                    Options options = mock(Options.class);
                                                                                                                    
                                                                                                                    // Create parser instance and set fields using reflection
                                                                                                                    Parser parser = new Parser() {
                                                                                                                        @Override
                                                                                                                        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                            return new String[0];
                                                                                                                        }
                                                                                                                    };
                                                                                                                    
                                                                                                                    // Set up mock behavior
                                                                                                                    when(options.getOption("testOption")).thenReturn(null); // Return null Option
                                                                                                                    when(cmd.hasOption("testOption")).thenReturn(false); // Option not in cmd yet
                                                                                                                    
                                                                                                                    // Set private fields using reflection
                                                                                                                    try {
                                                                                                                        Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                        cmdField.setAccessible(true);
                                                                                                                        cmdField.set(parser, cmd);
                                                                                                                        
                                                                                                                        Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                        optionsField.setAccessible(true);
                                                                                                                        optionsField.set(parser, options);
                                                                                                                        
                                                                                                                        // Access protected method via reflection
                                                                                                                        Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                        processProperties.setAccessible(true);
                                                                                                                        
                                                                                                                        // Execute method under test
                                                                                                                        processProperties.invoke(parser, properties);
                                                                                                                        
                                                                                                                        // Verify behavior - since we can't verify the protected addOption call directly,
                                                                                                                        // we verify that hasOption was called (which is public)
                                                                                                                        verify(cmd, times(1)).hasOption("testOption");
                                                                                                                        // Also verify that getOption was called on the options mock
                                                                                                                        verify(options, times(1)).getOption("testOption");
                                                                                                                    } catch (Exception e) {
                                                                                                                        fail("Failed to set up or execute test due to reflection error: " + e.getMessage());
                                                                                                                    }
                                                                                                                }

    @Test
                                                                                                           public void testProcessPropertiesContinueVsBreakMutant() throws Exception {
                                                                                                               // Setup test data
                                                                                                               Properties props = new Properties();
                                                                                                               props.setProperty("bool1", "true");  // valid boolean option
                                                                                                               props.setProperty("bool2", "no");    // invalid boolean option (should skip)
                                                                                                               props.setProperty("bool3", "1");     // valid boolean option after invalid one
                                                                                                               
                                                                                                               // Mock dependencies
                                                                                                               CommandLine cmd = mock(CommandLine.class);
                                                                                                               Options options = mock(Options.class);
                                                                                                               Option opt1 = mock(Option.class);
                                                                                                               Option opt2 = mock(Option.class);
                                                                                                               Option opt3 = mock(Option.class);
                                                                                                               
                                                                                                               // Setup mock behaviors
                                                                                                               when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                                               when(options.getOption("bool1")).thenReturn(opt1);
                                                                                                               when(options.getOption("bool2")).thenReturn(opt2);
                                                                                                               when(options.getOption("bool3")).thenReturn(opt3);
                                                                                                               
                                                                                                               when(opt1.hasArg()).thenReturn(false);
                                                                                                               when(opt2.hasArg()).thenReturn(false);
                                                                                                               when(opt3.hasArg()).thenReturn(false);
                                                                                                               
                                                                                                               // Create parser instance and set mocks using reflection
                                                                                                               Parser parser = new Parser() {
                                                                                                                   @Override
                                                                                                                   protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                       return new String[0];
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               // Set protected options field using reflection
                                                                                                               Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                               optionsField.setAccessible(true);
                                                                                                               optionsField.set(parser, options);
                                                                                                               
                                                                                                               // Set protected cmd field using reflection
                                                                                                               Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                               cmdField.setAccessible(true);
                                                                                                               cmdField.set(parser, cmd);
                                                                                                               
                                                                                                               // Get and invoke protected processProperties method using reflection
                                                                                                               Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                               processPropertiesMethod.setAccessible(true);
                                                                                                               processPropertiesMethod.invoke(parser, props);
                                                                                                               
                                                                                                               // Verify behavior - should process bool1 and bool3 (original)
                                                                                                               // Mutant would only process bool1 due to break
                                                                                                               // Use reflection to verify addOption calls since it's not public
                                                                                                               Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                                                                                               addOptionMethod.setAccessible(true);
                                                                                                               
                                                                                                               // Verify opt1 was added
                                                                                                               verify(cmd, times(1)).hasOption("bool1");
                                                                                                               // Verify opt2 was never added
                                                                                                               verify(cmd, never()).hasOption("bool2");
                                                                                                               // Verify opt3 was added (would fail for mutant)
                                                                                                               verify(cmd, times(1)).hasOption("bool3");
                                                                                                           }

    @Test
                                                                                                      public void testProcessPropertiesContinueVsReturnMutant() throws Exception {
                                                                                                          // Setup test data
                                                                                                          Properties props = new Properties();
                                                                                                          props.setProperty("skipMe", "no");  // Non-boolean value for non-arg option
                                                                                                          props.setProperty("addMe", "true"); // Valid boolean value for non-arg option
                                                                                                          
                                                                                                          // Mock dependencies
                                                                                                          CommandLine cmd = mock(CommandLine.class);
                                                                                                          Options options = mock(Options.class);
                                                                                                          Option skipOption = mock(Option.class);
                                                                                                          Option addOption = mock(Option.class);
                                                                                                          
                                                                                                          // Stub behavior
                                                                                                          when(cmd.hasOption("skipMe")).thenReturn(false);
                                                                                                          when(cmd.hasOption("addMe")).thenReturn(false);
                                                                                                          when(options.getOption("skipMe")).thenReturn(skipOption);
                                                                                                          when(options.getOption("addMe")).thenReturn(addOption);
                                                                                                          when(skipOption.hasArg()).thenReturn(false);
                                                                                                          when(addOption.hasArg()).thenReturn(false);
                                                                                                          
                                                                                                          // Create parser and set dependencies using reflection
                                                                                                          Parser parser = new Parser() {
                                                                                                              @Override
                                                                                                              protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                  return new String[0];
                                                                                                              }
                                                                                                          };
                                                                                                          
                                                                                                          // Set protected options field using reflection
                                                                                                          Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                          optionsField.setAccessible(true);
                                                                                                          optionsField.set(parser, options);
                                                                                                          
                                                                                                          // Set protected cmd field using reflection
                                                                                                          Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                          cmdField.setAccessible(true);
                                                                                                          cmdField.set(parser, cmd);
                                                                                                          
                                                                                                          // Get and invoke protected processProperties method
                                                                                                          Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                          processProperties.setAccessible(true);
                                                                                                          processProperties.invoke(parser, props);
                                                                                                          
                                                                                                          // Verify behavior - mutant would fail here
                                                                                                          // Original: should process addMe (skip skipMe but continue)
                                                                                                          // Mutant: would return after skipMe and never process addMe
                                                                                                          
                                                                                                          // Verify options were added to command line through public methods
                                                                                                          verify(cmd).hasOption("addMe");
                                                                                                          verify(cmd).hasOption("skipMe");
                                                                                                          
                                                                                                          // Verify the options were retrieved from options
                                                                                                          verify(options).getOption("addMe");
                                                                                                          verify(options).getOption("skipMe");
                                                                                                      }

    @Test
                                                                                             public void testProcessProperties_ShouldNotAddOptionWhenValueIsInvalid() throws Exception {
                                                                                                 // Setup test data
                                                                                                 Properties props = new Properties();
                                                                                                 props.setProperty("testOpt", "no"); // Invalid value for boolean option
                                                                                                 
                                                                                                 // Mock dependencies
                                                                                                 CommandLine cmd = mock(CommandLine.class);
                                                                                                 Options options = mock(Options.class);
                                                                                                 Option opt = mock(Option.class);
                                                                                                 
                                                                                                 // Setup Parser instance using reflection since no constructor
                                                                                                 Parser parser = new Parser() {
                                                                                                     @Override
                                                                                                     protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                         return new String[0];
                                                                                                     }
                                                                                                 };
                                                                                                 
                                                                                                 // Set up mock behavior
                                                                                                 when(cmd.hasOption("testOpt")).thenReturn(false);
                                                                                                 when(options.getOption("testOpt")).thenReturn(opt);
                                                                                                 when(opt.hasArg()).thenReturn(false); // Boolean option
                                                                                                 
                                                                                                 // Inject mocks into parser
                                                                                                 Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                 cmdField.setAccessible(true);
                                                                                                 cmdField.set(parser, cmd);
                                                                                                 
                                                                                                 Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                 optionsField.setAccessible(true);
                                                                                                 optionsField.set(parser, options);
                                                                                                 
                                                                                                 // Execute
                                                                                                 Method method = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                 method.setAccessible(true);
                                                                                                 method.invoke(parser, props);
                                                                                                 
                                                                                                 // Verify - option should NOT be added for invalid value
                                                                                                 // Since we can't verify addOption directly, we verify that hasOption still returns false
                                                                                                 verify(cmd, never()).hasOption("testOpt");
                                                                                             }

    @Test
                                                                                        public void testProcessProperties_ShouldNotAddOptionForInvalidBooleanValue() throws Exception {
                                                                                            // Setup test data
                                                                                            Properties properties = new Properties();
                                                                                            properties.setProperty("testOption", "no"); // Invalid boolean value
                                                                                            
                                                                                            // Mock dependencies
                                                                                            CommandLine cmd = mock(CommandLine.class);
                                                                                            Options options = mock(Options.class);
                                                                                            Option opt = mock(Option.class);
                                                                                            
                                                                                            // Setup mock behavior
                                                                                            when(opt.hasArg()).thenReturn(false); // Boolean option
                                                                                            when(options.getOption("testOption")).thenReturn(opt);
                                                                                            
                                                                                            // Create parser instance and set mocks
                                                                                            Parser parser = new Parser() {
                                                                                                @Override
                                                                                                protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                    return new String[0];
                                                                                                }
                                                                                            };
                                                                                            
                                                                                            // Use reflection to set protected options field
                                                                                            Field optionsField = Parser.class.getDeclaredField("options");
                                                                                            optionsField.setAccessible(true);
                                                                                            optionsField.set(parser, options);
                                                                                            
                                                                                            // Use reflection to set protected cmd field
                                                                                            Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                            cmdField.setAccessible(true);
                                                                                            cmdField.set(parser, cmd);
                                                                                            
                                                                                            // Get and invoke the protected processProperties method
                                                                                            Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                            processProperties.setAccessible(true);
                                                                                            processProperties.invoke(parser, properties);
                                                                                            
                                                                                            // Verify behavior - option should NOT be added for invalid boolean value
                                                                                            // We need to verify through reflection since addOption is not public
                                                                                            Field optionsFieldCmd = CommandLine.class.getDeclaredField("options");
                                                                                            optionsFieldCmd.setAccessible(true);
                                                                                            List<Option> actualOptions = (List<Option>) optionsFieldCmd.get(cmd);
                                                                                            assertFalse(actualOptions.contains(opt));
                                                                                        }

    @Test
                                                                               public void testProcessProperties_AddsOptionToCommandLine1() {
                                                                                   // Setup test data
                                                                                   Properties properties = new Properties();
                                                                                   properties.setProperty("testOption", "testValue");
                                                                                   
                                                                                   // Mock dependencies
                                                                                   CommandLine cmd = mock(CommandLine.class);
                                                                                   Options options = mock(Options.class);
                                                                                   Option opt = mock(Option.class);
                                                                                   
                                                                                   // Create parser instance (may need reflection to set private fields)
                                                                                   Parser parser = new Parser() {
                                                                                       @Override
                                                                                       protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                           return new String[0];
                                                                                       }
                                                                                   };
                                                                                   
                                                                                   // Set up mock behavior
                                                                                   when(options.getOption("testOption")).thenReturn(opt);
                                                                                   when(opt.hasArg()).thenReturn(true);
                                                                                   when(opt.getValues()).thenReturn(null);
                                                                                   
                                                                                   // Use reflection to set private fields since there are no setters
                                                                                   try {
                                                                                       Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                       cmdField.setAccessible(true);
                                                                                       cmdField.set(parser, cmd);
                                                                                       
                                                                                       Field optionsField = Parser.class.getDeclaredField("options");
                                                                                       optionsField.setAccessible(true);
                                                                                       optionsField.set(parser, options);
                                                                                   } catch (Exception e) {
                                                                                       fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                   }
                                                                                   
                                                                                   // Execute method under test using reflection since it's protected
                                                                                   try {
                                                                                       Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                       processProperties.setAccessible(true);
                                                                                       processProperties.invoke(parser, properties);
                                                                                   } catch (Exception e) {
                                                                                       fail("Failed to invoke processProperties: " + e.getMessage());
                                                                                   }
                                                                                   
                                                                                   // Verify behavior - check if the option was processed by examining the command line
                                                                                   // Since we can't verify private methods, we'll verify the expected interaction
                                                                                   // with the command line through other means
                                                                                   
                                                                                   // Verify that the option was added to the command line
                                                                                   // We can check if the option was processed by verifying that getOption was called
                                                                                   verify(options, times(1)).getOption("testOption");
                                                                                   
                                                                                   // Verify that the option was processed with the correct value
                                                                                   // Since we can't verify the private addValueForProcessing method,
                                                                                   // we can verify that the option has the expected value through its public API
                                                                                   try {
                                                                                       Method getValues = Option.class.getDeclaredMethod("getValues");
                                                                                       getValues.setAccessible(true);
                                                                                       String[] values = (String[]) getValues.invoke(opt);
                                                                                       assertNotNull("Option values should not be null after processing", values);
                                                                                       assertEquals("Option should have one value", 1, values.length);
                                                                                       assertEquals("Option value should match property value", "testValue", values[0]);
                                                                                   } catch (Exception e) {
                                                                                       fail("Failed to verify option values: " + e.getMessage());
                                                                                   }
                                                                               }

    @Test
                                                                          public void testProcessProperties_NonArgOptionWithInvalidValue_ShouldNotAddOption() throws Exception {
                                                                              // Setup test data
                                                                              Properties props = new Properties();
                                                                              props.setProperty("verbose", "no"); // "no" is not in yes/true/1
                                                                              
                                                                              // Create mock objects
                                                                              CommandLine cmd = mock(CommandLine.class);
                                                                              Options options = mock(Options.class);
                                                                              Option opt = mock(Option.class);
                                                                              
                                                                              // Setup mock behavior
                                                                              when(cmd.hasOption("verbose")).thenReturn(false);
                                                                              when(options.getOption("verbose")).thenReturn(opt);
                                                                              when(opt.hasArg()).thenReturn(false); // Non-arg option
                                                                              
                                                                              // Create parser and set dependencies
                                                                              Parser parser = new Parser() {
                                                                                  @Override
                                                                                  protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                      return new String[0];
                                                                                  }
                                                                              };
                                                                              
                                                                              // Use reflection to set protected options field
                                                                              Field optionsField = Parser.class.getDeclaredField("options");
                                                                              optionsField.setAccessible(true);
                                                                              optionsField.set(parser, options);
                                                                              
                                                                              // Use reflection to set protected cmd field
                                                                              Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                              cmdField.setAccessible(true);
                                                                              cmdField.set(parser, cmd);
                                                                              
                                                                              // Use reflection to call protected processProperties method
                                                                              Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                              processProperties.setAccessible(true);
                                                                              processProperties.invoke(parser, props);
                                                                              
                                                                              // Verify behavior - should not add option for invalid value
                                                                              // Since addOption is not public, we verify that hasOption remains false
                                                                              verify(cmd, never()).hasOption("verbose");
                                                                          }

    @Test
                                                                     public void testProcessPropertiesWithNullOptionAndInvalidValue() {
                                                                         // Setup test data
                                                                         Properties properties = new Properties();
                                                                         properties.setProperty("testOption", "no"); // Value that should make it continue
                                                                         
                                                                         // Mock dependencies
                                                                         CommandLine cmd = mock(CommandLine.class);
                                                                         Options options = mock(Options.class);
                                                                         Option opt = null; // Null option to trigger the mutant
                                                                         
                                                                         // Create parser instance and set fields (using reflection since no constructor)
                                                                         Parser parser = new Parser() {
                                                                             @Override
                                                                             protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                 return new String[0];
                                                                             }
                                                                         };
                                                                         
                                                                         // Set private fields using reflection
                                                                         try {
                                                                             Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                             cmdField.setAccessible(true);
                                                                             cmdField.set(parser, cmd);
                                                                             
                                                                             Field optionsField = Parser.class.getDeclaredField("options");
                                                                             optionsField.setAccessible(true);
                                                                             optionsField.set(parser, options);
                                                                         } catch (Exception e) {
                                                                             fail("Failed to set up test due to reflection error");
                                                                         }
                                                                         
                                                                         // Stub behavior
                                                                         when(options.getOption("testOption")).thenReturn(opt);
                                                                         when(cmd.hasOption("testOption")).thenReturn(false);
                                                                         
                                                                         // Execute processProperties via reflection
                                                                         try {
                                                                             Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                             processProperties.setAccessible(true);
                                                                             processProperties.invoke(parser, properties);
                                                                         } catch (Exception e) {
                                                                             fail("Failed to invoke processProperties via reflection");
                                                                         }
                                                                         
                                                                         // Verify - should not try to add null option
                                                                         // Since we can't verify addOption directly, we verify that hasOption was called
                                                                         verify(cmd).hasOption("testOption");
                                                                         // Verify getOption was called (indirect verification)
                                                                         verify(options).getOption("testOption");
                                                                     }

    @Test
                                                                public void testProcessPropertiesWithNullOptionShouldThrowException() {
                                                                    // Setup test data
                                                                    Properties properties = new Properties();
                                                                    properties.setProperty("testOption", "value");
                                                                    
                                                                    // Create mock objects
                                                                    CommandLine cmd = mock(CommandLine.class);
                                                                    Options options = mock(Options.class);
                                                                    
                                                                    // Create parser instance and set required fields
                                                                    Parser parser = new Parser() {
                                                                        @Override
                                                                        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                            return new String[0];
                                                                        }
                                                                    };
                                                                    
                                                                    // Use reflection to set private fields since there are no setters
                                                                    try {
                                                                        Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                        cmdField.setAccessible(true);
                                                                        cmdField.set(parser, cmd);
                                                                        
                                                                        Field optionsField = Parser.class.getDeclaredField("options");
                                                                        optionsField.setAccessible(true);
                                                                        optionsField.set(parser, options);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                    }
                                                                    
                                                                    // Configure mock behavior
                                                                    when(cmd.hasOption("testOption")).thenReturn(false);
                                                                    when(options.getOption("testOption")).thenReturn(null); // Return null option
                                                                    
                                                                    // Execute test - should throw NullPointerException for original code
                                                                    try {
                                                                        Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                        processProperties.setAccessible(true);
                                                                        processProperties.invoke(parser, properties);
                                                                    } catch (InvocationTargetException e) {
                                                                        // Expected - original code throws NullPointerException
                                                                        assertTrue(e.getCause() instanceof NullPointerException);
                                                                    } catch (Exception e) {
                                                                        fail("Unexpected exception: " + e.getMessage());
                                                                    }
                                                                    
                                                                    // Verify the option was not added (mutant behavior would reach here)
                                                                    try {
                                                                        Method addOption = cmd.getClass().getDeclaredMethod("addOption", Option.class);
                                                                        addOption.setAccessible(true);
                                                                        verify(cmd, never()).getClass().getDeclaredMethod("addOption", Option.class);
                                                                    } catch (Exception e) {
                                                                        fail("Verification failed: " + e.getMessage());
                                                                    }
                                                                }

    @Test
                                                           public void testProcessPropertiesContinueVsBreakMutant1() throws Exception {
                                                               // Setup test data
                                                               Properties props = new Properties();
                                                               props.setProperty("boolFalse", "no");  // Should be skipped
                                                               props.setProperty("boolTrue", "yes");  // Should be added
                                                               
                                                               // Mock dependencies
                                                               CommandLine cmd = mock(CommandLine.class);
                                                               Options options = mock(Options.class);
                                                               Option optFalse = mock(Option.class);
                                                               Option optTrue = mock(Option.class);
                                                               
                                                               // Setup mock behaviors
                                                               when(cmd.hasOption("boolFalse")).thenReturn(false);
                                                               when(cmd.hasOption("boolTrue")).thenReturn(false);
                                                               when(options.getOption("boolFalse")).thenReturn(optFalse);
                                                               when(options.getOption("boolTrue")).thenReturn(optTrue);
                                                               when(optFalse.hasArg()).thenReturn(false);
                                                               when(optTrue.hasArg()).thenReturn(false);
                                                               
                                                               // Create parser and set mocks using reflection
                                                               Parser parser = new Parser() {
                                                                   @Override
                                                                   protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                       return new String[0];
                                                                   }
                                                               };
                                                               
                                                               // Set protected options field using reflection
                                                               Method setOptionsMethod = Parser.class.getDeclaredMethod("setOptions", Options.class);
                                                               setOptionsMethod.setAccessible(true);
                                                               setOptionsMethod.invoke(parser, options);
                                                               
                                                               // Set protected cmd field using reflection
                                                               Field cmdField = Parser.class.getDeclaredField("cmd");
                                                               cmdField.setAccessible(true);
                                                               cmdField.set(parser, cmd);
                                                               
                                                               // Call protected processProperties method using reflection
                                                               Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                               processPropertiesMethod.setAccessible(true);
                                                               processPropertiesMethod.invoke(parser, props);
                                                               
                                                               // Verify behavior - mutant would stop after first option
                                                               // Original should process both, but only add the true one
                                                               verify(options).getOption("boolFalse");
                                                               verify(options).getOption("boolTrue");
                                                               
                                                               // Verify CommandLine.addOption() was called correctly
                                                               // Note: We need to verify through the mock behavior since addOption is protected
                                                               verify(cmd, never()).hasOption("boolFalse");  // Shouldn't be added
                                                               verify(cmd).hasOption("boolTrue");           // Should be added
                                                           }

    @Test
                                                      public void testProcessPropertiesWithInvalidBooleanValueShouldContinueProcessing() {
                                                          // Setup test data
                                                          Properties properties = new Properties();
                                                          properties.setProperty("valid1", "true");  // valid boolean
                                                          properties.setProperty("invalidBool", "no");  // invalid boolean (should skip)
                                                          properties.setProperty("valid2", "1");  // valid boolean
                                                          
                                                          // Mock dependencies
                                                          CommandLine cmd = mock(CommandLine.class);
                                                          Options options = mock(Options.class);
                                                          Option validOpt1 = mock(Option.class);
                                                          Option invalidOpt = mock(Option.class);
                                                          Option validOpt2 = mock(Option.class);
                                                          
                                                          // Setup mock behavior
                                                          when(options.getOption("valid1")).thenReturn(validOpt1);
                                                          when(options.getOption("invalidBool")).thenReturn(invalidOpt);
                                                          when(options.getOption("valid2")).thenReturn(validOpt2);
                                                          
                                                          when(validOpt1.hasArg()).thenReturn(false);
                                                          when(invalidOpt.hasArg()).thenReturn(false);
                                                          when(validOpt2.hasArg()).thenReturn(false);
                                                          
                                                          when(cmd.hasOption(anyString())).thenReturn(false);
                                                          
                                                          // Create parser instance and set dependencies
                                                          Parser parser = new Parser() {
                                                              @Override
                                                              protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                  return new String[0];
                                                              }
                                                          };
                                                          
                                                          // Use reflection to set private fields since there are no public setters
                                                          try {
                                                              Field cmdField = Parser.class.getDeclaredField("cmd");
                                                              cmdField.setAccessible(true);
                                                              cmdField.set(parser, cmd);
                                                              
                                                              Field optionsField = Parser.class.getDeclaredField("options");
                                                              optionsField.setAccessible(true);
                                                              optionsField.set(parser, options);
                                                          } catch (Exception e) {
                                                              fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                          }
                                                          
                                                          // Execute test using reflection to access protected method
                                                          try {
                                                              Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                              processPropertiesMethod.setAccessible(true);
                                                              processPropertiesMethod.invoke(parser, properties);
                                                          } catch (Exception e) {
                                                              fail("Failed to invoke processProperties method: " + e.getMessage());
                                                          }
                                                          
                                                          // Verify behavior - should process all valid options despite invalid one
                                                          // Since addOption is not public, we can't verify it directly
                                                          // Instead verify that the valid options were processed by checking hasOption calls
                                                          verify(cmd).hasOption("valid1");
                                                          verify(cmd).hasOption("valid2");
                                                          verify(cmd).hasOption("invalidBool");
                                                      }

    @Test
                                         public void testProcessProperties_ShouldSkipInvalidBooleanOptions() {
                                             // Setup test data
                                             Properties props = new Properties();
                                             props.setProperty("verbose", "no"); // Invalid boolean value
                                             
                                             // Mock dependencies
                                             CommandLine mockCmd = mock(CommandLine.class);
                                             Options mockOptions = mock(Options.class);
                                             Option mockOption = mock(Option.class);
                                             
                                             // Create parser instance
                                             Parser parser = new Parser() {
                                                 protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                     return new String[0];
                                                 }
                                             };
                                             
                                             // Set up mock behavior
                                             when(mockOptions.getOption("verbose")).thenReturn(mockOption);
                                             when(mockOption.hasArg()).thenReturn(false); // Boolean option
                                             
                                             // Use reflection to set private fields
                                             try {
                                                 Field cmdField = Parser.class.getDeclaredField("cmd");
                                                 cmdField.setAccessible(true);
                                                 cmdField.set(parser, mockCmd);
                                                 
                                                 Field optionsField = Parser.class.getDeclaredField("options");
                                                 optionsField.setAccessible(true);
                                                 optionsField.set(parser, mockOptions);
                                             } catch (Exception e) {
                                                 fail("Failed to set up test due to reflection error");
                                             }
                                             
                                             // Execute test using reflection to access protected method
                                             try {
                                                 Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                 processProperties.setAccessible(true);
                                                 processProperties.invoke(parser, props);
                                             } catch (Exception e) {
                                                 fail("Failed to invoke processProperties method");
                                             }
                                             
                                             // Verify behavior through mock interactions
                                             // Instead of trying to verify the non-public addOption method,
                                             // we can verify that the command line wasn't modified by checking
                                             // that no interactions occurred with the mockCmd
                                             verifyNoInteractions(mockCmd);
                                         }

    @Test
                                    public void testProcessProperties_ShouldNotAddBooleanOptionWithInvalidValue1() throws Exception {
                                        // Setup test data
                                        Properties properties = new Properties();
                                        properties.setProperty("verbose", "no"); // Invalid boolean value
                                        
                                        // Mock dependencies
                                        CommandLine cmd = mock(CommandLine.class);
                                        Options options = mock(Options.class);
                                        Option opt = mock(Option.class);
                                        
                                        // Setup mock behavior
                                        when(cmd.hasOption("verbose")).thenReturn(false);
                                        when(options.getOption("verbose")).thenReturn(opt);
                                        when(opt.hasArg()).thenReturn(false); // Boolean option
                                        
                                        // Create parser instance and set fields via reflection
                                        Parser parser = new Parser() {
                                            @Override
                                            protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                return new String[0];
                                            }
                                        };
                                        
                                        Field cmdField = Parser.class.getDeclaredField("cmd");
                                        cmdField.setAccessible(true);
                                        cmdField.set(parser, cmd);
                                        
                                        Field optionsField = Parser.class.getDeclaredField("options");
                                        optionsField.setAccessible(true);
                                        optionsField.set(parser, options);
                                        
                                        // Get the processProperties method and make it accessible
                                        Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                        processPropertiesMethod.setAccessible(true);
                                        
                                        // Execute method under test
                                        processPropertiesMethod.invoke(parser, properties);
                                        
                                        // Verify - option should NOT be added for invalid boolean value
                                        // Using reflection to verify the addOption call since it's not public
                                        Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                        addOptionMethod.setAccessible(true);
                                        
                                        verify(cmd, never());
                                        // Alternative verification since we can't directly verify non-public methods
                                        // We can verify that no interaction happened with the option
                                        verify(opt, never()).getValues();
                                    }

    @Test
                               public void testProcessProperties_VerifyAddOptionCalled() throws Exception {
                                   // Setup test data
                                   Properties properties = new Properties();
                                   properties.setProperty("testOption", "value");
                                   
                                   // Create mock objects
                                   CommandLine mockCmd = mock(CommandLine.class);
                                   Options mockOptions = mock(Options.class);
                                   Option mockOption = mock(Option.class);
                                   
                                   // Setup mock behavior
                                   when(mockOptions.getOption("testOption")).thenReturn(mockOption);
                                   when(mockOption.hasArg()).thenReturn(true);
                                   when(mockOption.getValues()).thenReturn(null);
                                   
                                   // Create parser instance and set mocks
                                   Parser parser = new Parser() {
                                       @Override
                                       protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                           return new String[0];
                                       }
                                   };
                                   
                                   // Use reflection to set protected fields since we don't have direct access
                                   Field cmdField = Parser.class.getDeclaredField("cmd");
                                   cmdField.setAccessible(true);
                                   cmdField.set(parser, mockCmd);
                                   
                                   Field optionsField = Parser.class.getDeclaredField("options");
                                   optionsField.setAccessible(true);
                                   optionsField.set(parser, mockOptions);
                                   
                                   // Get the processProperties method and make it accessible
                                   Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                   processPropertiesMethod.setAccessible(true);
                                   
                                   // Execute method under test
                                   processPropertiesMethod.invoke(parser, properties);
                                   
                                   // Verify behavior - use reflection to call addOption since it's not public
                                   Method addOptionMethod = CommandLine.class.getDeclaredMethod("addOption", Option.class);
                                   addOptionMethod.setAccessible(true);
                                   verify(mockCmd, times(1));
                                   addOptionMethod.invoke(mockCmd, mockOption);
                               }

    @Test
              public void testProcessProperties_NonTrueBooleanOption_ShouldNotAddOption() throws Exception {
                  // Setup test data
                  Properties props = new Properties();
                  props.setProperty("verbose", "no"); // Non-true value
                  
                  // Mock dependencies
                  CommandLine cmd = mock(CommandLine.class);
                  Options options = mock(Options.class);
                  Option opt = mock(Option.class);
                  
                  // Stub behavior
                  when(cmd.hasOption("verbose")).thenReturn(false);
                  when(options.getOption("verbose")).thenReturn(opt);
                  when(opt.hasArg()).thenReturn(false); // Boolean option
                  
                  // Create parser and set dependencies using reflection
                  Parser parser = new Parser() {
                      @Override
                      protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                          return new String[0];
                      }
                  };
                  
                  // Set protected options field using reflection
                  Field optionsField = Parser.class.getDeclaredField("options");
                  optionsField.setAccessible(true);
                  optionsField.set(parser, options);
                  
                  // Set protected cmd field using reflection
                  Field cmdField = Parser.class.getDeclaredField("cmd");
                  cmdField.setAccessible(true);
                  cmdField.set(parser, cmd);
                  
                  // Invoke protected processProperties method using reflection
                  Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                  processProperties.setAccessible(true);
                  processProperties.invoke(parser, props);
                  
                  // Verify - option should NOT be processed for non-true value
                  // We verify that hasOption is still false (option wasn't added)
                  verify(cmd, never()).hasOption("verbose");
              }

    @Test
         public void testProcessPropertiesWithNullBooleanOption() throws Exception {
             // Setup test data
             Properties properties = new Properties();
             properties.setProperty("nullOpt", "false"); // Value that should make it continue
             
             // Create CommandLine instance using reflection since constructor isn't public
             Constructor<CommandLine> constructor = CommandLine.class.getDeclaredConstructor();
             constructor.setAccessible(true);
             CommandLine cmd = constructor.newInstance();
             
             Parser parser = new Parser() {
                 @Override
                 protected Options getOptions() {
                     Options options = new Options();
                     // Add option with empty char instead of null
                     options.addOption(OptionBuilder.withLongOpt("nullOpt").create());
                     return options;
                 }
                 
                 @Override
                 protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                     return new String[0]; // Dummy implementation
                 }
             };
             
             // Set parser's cmd using reflection
             Field cmdField = Parser.class.getDeclaredField("cmd");
             cmdField.setAccessible(true);
             cmdField.set(parser, cmd);
             
             // Call method using reflection since it's protected
             Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
             processProperties.setAccessible(true);
             processProperties.invoke(parser, properties);
             
             // Verify no options were added (original would try to add null, mutant would continue)
             assertTrue("CommandLine should have no options added", cmd.getOptions().length == 0);
         }

    @Test
    public void testProcessPropertiesWithNullOption2() {
        // Setup test data
        Properties properties = new Properties();
        properties.setProperty("testOption", "value");
        
        // Create mock objects
        CommandLine cmd = mock(CommandLine.class);
        Options options = mock(Options.class);
        Option opt = null; // This will cause the NPE in original code
        
        // Create parser instance and set up mocks
        Parser parser = new Parser() {
            @Override
            protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                return new String[0];
            }
        };
        
        // Use reflection to set protected fields
        try {
            Field cmdField = Parser.class.getDeclaredField("cmd");
            cmdField.setAccessible(true);
            cmdField.set(parser, cmd);
            
            Field optionsField = Parser.class.getDeclaredField("options");
            optionsField.setAccessible(true);
            optionsField.set(parser, options);
        } catch (Exception e) {
            fail("Failed to set up test due to reflection error: " + e.getMessage());
        }
        
        // Mock behavior
        when(cmd.hasOption("testOption")).thenReturn(false);
        when(options.getOption("testOption")).thenReturn(opt);
        
        // Use reflection to invoke protected method
        try {
            Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
            processPropertiesMethod.setAccessible(true);
            processPropertiesMethod.invoke(parser, properties);
        } catch (Exception e) {
            fail("Failed to invoke processProperties method: " + e.getMessage());
        }
    }


}
