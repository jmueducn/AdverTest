package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                   public void testRenderWrappedText_ShortTextNoWrapNeeded() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       
                       // Set defaultNewLine using reflection since it might be private
                       Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                       defaultNewLineField.setAccessible(true);
                       defaultNewLineField.set(formatter, "\n");
                       
                       StringBuffer sb = new StringBuffer();
                       String text = "Short text";
                       
                       // Get the protected method using reflection
                       Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", 
                           StringBuffer.class, 
                           int.class, 
                           int.class, 
                           String.class
                       );
                       renderWrappedText.setAccessible(true);
                       
                       StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 20, 4, text);
                       
                       assertEquals("Short text", result.toString());
                       assertSame(sb, result);
                   }

    @Test
                   public void testRenderWrappedText_TextExactlyFitsWidth() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       formatter.setNewLine("\n");
                       
                       StringBuffer sb = new StringBuffer();
                       String text = "Exactly 12 chars";
                       
                       // Use reflection to access protected method
                       Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", 
                           StringBuffer.class, 
                           int.class, 
                           int.class, 
                           String.class
                       );
                       renderWrappedText.setAccessible(true);
                       StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 12, 4, text);
                       
                       assertEquals("Exactly 12 chars", result.toString());
                   }

    @Test
                   public void testRenderWrappedText_TextRequiresMultipleWraps() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       
                       // Access the protected defaultNewLine field using reflection
                       Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                       defaultNewLineField.setAccessible(true);
                       defaultNewLineField.set(formatter, "\n");
                       
                       StringBuffer sb = new StringBuffer();
                       String text = "This is a long text that needs to be wrapped multiple times";
                       
                       // Access the protected renderWrappedText method using reflection
                       Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                       renderWrappedTextMethod.setAccessible(true);
                       StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(formatter, sb, 10, 2, text);
                       
                       String expected = "This is a\n  long\n  text\n  that\n  needs\n  to be\n  wrapped\n  multiple\n  times";
                       assertEquals(expected, result.toString());
                   }

    @Test
                   public void testRenderWrappedText_EmptyText() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       
                       // Set defaultNewLine using reflection since it's likely a private field
                       Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                       defaultNewLineField.setAccessible(true);
                       defaultNewLineField.set(formatter, "\n");
                       
                       StringBuffer sb = new StringBuffer();
                       
                       // Get the protected method using reflection
                       Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", 
                           StringBuffer.class, 
                           int.class, 
                           int.class, 
                           String.class
                       );
                       renderWrappedTextMethod.setAccessible(true);
                       
                       // Invoke the method
                       StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
                           formatter, 
                           sb, 
                           10, 
                           4, 
                           ""
                       );
                       
                       assertEquals("", result.toString());
                   }

    @Test
                   public void testRenderWrappedText_TextWithSpecialCharacters() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       
                       // Use reflection to set the protected field
                       Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                       defaultNewLineField.setAccessible(true);
                       defaultNewLineField.set(formatter, "\n");
                       
                       StringBuffer sb = new StringBuffer();
                       String text = "Text with \t tabs and \n newlines";
                       
                       // Use reflection to access the protected method
                       Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                       renderWrappedTextMethod.setAccessible(true);
                       StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
                           formatter, sb, 10, 4, text);
                       
                       String expected = "Text with\n    tabs\n    and\n    newlines";
                       assertEquals(expected, result.toString());
                   }

    @Test
                   public void testRenderWrappedText_FindWrapPosReturnsMinusOne() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       
                       // Use reflection to set the defaultNewLine field since it's likely protected/private
                       Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                       defaultNewLineField.setAccessible(true);
                       defaultNewLineField.set(formatter, "\n");
                       
                       // Create a spy that we'll use to mock findWrapPos
                       HelpFormatter spyFormatter = spy(formatter);
                       
                       // Mock findWrapPos using reflection since it's protected
                       Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                           "findWrapPos", String.class, int.class, int.class);
                       findWrapPosMethod.setAccessible(true);
                       when(findWrapPosMethod.invoke(spyFormatter, anyString(), anyInt(), anyInt())).thenReturn(-1);
                       
                       StringBuffer sb = new StringBuffer();
                       String text = "This text will not be wrapped";
                       
                       // Call renderWrappedText using reflection since it's protected
                       Method renderMethod = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                       renderMethod.setAccessible(true);
                       StringBuffer result = (StringBuffer) renderMethod.invoke(spyFormatter, sb, 10, 4, text);
                       
                       assertEquals("This text will not be wrapped", result.toString());
                   }

    @Test
                   public void testRenderWrappedText_TextLongerThanWidthWithPosAtTabStop() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       
                       // Set defaultNewLine using reflection since it's likely a private field
                       Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                       defaultNewLineField.setAccessible(true);
                       defaultNewLineField.set(formatter, "\n");
                       
                       // Create a spy of the formatter
                       HelpFormatter spyFormatter = spy(formatter);
                       
                       // Mock findWrapPos using reflection
                       Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                           "findWrapPos", String.class, int.class, int.class);
                       findWrapPosMethod.setAccessible(true);
                       
                       when(findWrapPosMethod.invoke(spyFormatter, anyString(), anyInt(), anyInt()))
                           .thenReturn(3)  // first call
                           .thenReturn(3); // second call (nextLineTabStop - 1)
                       
                       StringBuffer sb = new StringBuffer();
                       String text = "Text that triggers special case";
                       
                       // Call renderWrappedText using reflection
                       Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                       renderWrappedTextMethod.setAccessible(true);
                       
                       StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
                           spyFormatter, sb, 10, 4, text);
                       
                       // Should append the entire text when pos == nextLineTabStop - 1
                       assertEquals("Text\n    that triggers special case", result.toString());
                   }

    @Test
                   public void testRenderWrappedText_NullStringBuffer() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       
                       // Set private field using reflection
                       Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                       defaultNewLineField.setAccessible(true);
                       defaultNewLineField.set(formatter, "\n");
                       
                       // Get the protected method
                       Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", 
                           StringBuffer.class, 
                           int.class, 
                           int.class, 
                           String.class
                       );
                       renderWrappedText.setAccessible(true);
                       
                       thrown.expect(NullPointerException.class);
                       renderWrappedText.invoke(formatter, null, 10, 4, "Some text");
                   }

    @Test
                   public void testRenderWrappedText_NullText() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       
                       // Use reflection to access the protected method
                       Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", 
                           StringBuffer.class, 
                           int.class, 
                           int.class, 
                           String.class
                       );
                       renderWrappedText.setAccessible(true);
                       
                       StringBuffer sb = new StringBuffer();
                       StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                           formatter, 
                           sb, 
                           10, 
                           4, 
                           null
                       );
                       
                       assertEquals("", result.toString());
                   }

    @Test
                   public void testRenderWrappedText_ZeroWidth() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       
                       // Use reflection to access the protected field
                       Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                       defaultNewLineField.setAccessible(true);
                       defaultNewLineField.set(formatter, "\n");
                       
                       StringBuffer sb = new StringBuffer();
                       String text = "Should handle zero width";
                       
                       // Use reflection to access the protected method
                       Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", 
                           StringBuffer.class, 
                           int.class, 
                           int.class, 
                           String.class
                       );
                       renderWrappedTextMethod.setAccessible(true);
                       
                       StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
                           formatter, 
                           sb, 
                           0, 
                           4, 
                           text
                       );
                       
                       assertNotNull(result);
                   }

    @Test
              public void testRenderWrappedText_ExactWidthBoundary() throws Exception {
                  // Setup
                  HelpFormatter formatter = new HelpFormatter();
                  formatter.setWidth(10);  // Set width to 10
                  formatter.setNewLine("\n");
                  
                  // Create text with length exactly equal to width (10)
                  String text = "1234567890";
                  StringBuffer sb = new StringBuffer();
                  
                  // Set nextLineTabStop so that pos will be nextLineTabStop-1
                  int nextLineTabStop = 5;
                  
                  // Create spy and mock findWrapPos
                  HelpFormatter spyFormatter = spy(formatter);
                  
                  // Get the protected findWrapPos method via reflection
                  Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                      "findWrapPos", String.class, int.class, int.class);
                  findWrapPosMethod.setAccessible(true);
                  
                  // Mock the method to return nextLineTabStop-1 (4)
                  when(findWrapPosMethod.invoke(spyFormatter, anyString(), anyInt(), anyInt()))
                      .thenReturn(nextLineTabStop - 1);
                  
                  // Get the protected renderWrappedText method via reflection
                  Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                      "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                  renderWrappedTextMethod.setAccessible(true);
                  
                  // Execute
                  StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
                      spyFormatter, sb, 10, nextLineTabStop, text);
                  
                  // Verify - original would continue processing (add new line), 
                  // mutant would append text and return
                  // So we check if new line was added (original behavior)
                  String output = result.toString();
                  assertTrue("Should contain newline for exact width case", 
                             output.contains("\n"));
                  
                  // Also verify the exact output
                  String expected = "1234\n     67890"; // Original behavior with padding
                  assertEquals(expected, output.trim());
              }

    @Test
         public void testRenderWrappedText_DetectMutant() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             
             // Use reflection to set defaultNewLine since it might be private
             Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
             defaultNewLineField.setAccessible(true);
             defaultNewLineField.set(formatter, "\n");
             
             StringBuffer sb = new StringBuffer();
             int width = 10;
             int nextLineTabStop = 5;
             String text = "1234 6789";
             
             // Create spy
             HelpFormatter spyFormatter = spy(formatter);
             
             // Mock findWrapPos using reflection
             Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                 "findWrapPos", String.class, int.class, int.class);
             findWrapPosMethod.setAccessible(true);
             when(findWrapPosMethod.invoke(spyFormatter, anyString(), anyInt(), anyInt()))
                 .thenReturn(nextLineTabStop - 1)  // pos = 4
                 .thenReturn(-1);
             
             // Mock rtrim using reflection
             Method rtrimMethod = HelpFormatter.class.getDeclaredMethod("rtrim", String.class);
             rtrimMethod.setAccessible(true);
             when(rtrimMethod.invoke(spyFormatter, anyString())).thenAnswer(i -> i.getArguments()[0]);
             
             // Mock createPadding using reflection
             Method createPaddingMethod = HelpFormatter.class.getDeclaredMethod("createPadding", int.class);
             createPaddingMethod.setAccessible(true);
             when(createPaddingMethod.invoke(spyFormatter, anyInt())).thenReturn("    ");
             
             // Execute using reflection
             Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                 "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
             renderWrappedTextMethod.setAccessible(true);
             StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
                 spyFormatter, sb, width, nextLineTabStop, text);
             
             // Verify
             String expected = "1234\n    6789";
             assertEquals("Mutant should be caught by different output", expected, result.toString());
         }

    @Test
    public void testRenderWrappedText_ShortTextAtTabStop() throws Exception {
        // Setup
        HelpFormatter formatter = new HelpFormatter();
        // Use reflection to set the protected field
        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
        defaultNewLineField.setAccessible(true);
        defaultNewLineField.set(formatter, "\n");
        
        StringBuffer sb = new StringBuffer();
        int width = 20;
        int nextLineTabStop = 5;
        
        // Create text that's shorter than width but will have pos == nextLineTabStop - 1
        // The text is constructed so that the first wrap pos is at 4 (nextLineTabStop - 1)
        // but the total length is less than width
        String text = "1234 678";
        
        // Get the protected method via reflection
        Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", 
            StringBuffer.class, 
            int.class, 
            int.class, 
            String.class
        );
        renderWrappedTextMethod.setAccessible(true);
        
        // Execute
        StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
            formatter, 
            sb, 
            width, 
            nextLineTabStop, 
            text
        );
        
        // Verify
        // Original would produce wrapped text with padding
        // Mutant would produce just the first part without wrapping
        String expected = "1234\n     678"; // Original behavior with padding
        assertEquals("Text should be properly wrapped even when short at tab stop", 
                    expected, 
                    result.toString());
    }


}
