package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                          public void testRenderWrappedText_NoWrapNeeded() throws Exception {
                                              HelpFormatter formatter = new HelpFormatter();
                                              StringBuffer sb = new StringBuffer();
                                              String text = "Short text";
                                              
                                              // Use reflection to access protected method
                                              Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              renderWrappedText.setAccessible(true);
                                              StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 50, 4, text);
                                              
                                              assertEquals("Text should remain unchanged when no wrap needed", 
                                                          text, result.toString());
                                              assertSame("Should return same StringBuffer instance", sb, result);
                                          }

    @Test
                                          public void testRenderWrappedText_SingleWrap() throws Exception {
                                              HelpFormatter formatter = new HelpFormatter();
                                              StringBuffer sb = new StringBuffer();
                                              String text = "This is a longer text that needs to be wrapped";
                                              
                                              // Use reflection to access protected method
                                              Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              renderWrappedText.setAccessible(true);
                                              StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 20, 4, text);
                                              
                                              String expected = "This is a longer\ntext that needs to\nbe wrapped";
                                              assertEquals("Text should be properly wrapped", expected, result.toString());
                                          }

    @Test
                                          public void testRenderWrappedText_MultipleWrapsWithIndent() throws Exception {
                                              HelpFormatter formatter = new HelpFormatter();
                                              StringBuffer sb = new StringBuffer();
                                              String text = "This is a very long text that will require multiple wraps with indentation";
                                              
                                              // Use reflection to access protected method
                                              Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              renderWrappedText.setAccessible(true);
                                              StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 25, 4, text);
                                              
                                              String expected = "This is a very long text\n    that will require\n    multiple wraps with\n    indentation";
                                              assertEquals("Text should be wrapped with proper indentation", expected, result.toString());
                                          }

    @Test
                                          public void testRenderWrappedText_EdgeCaseWidth() throws Exception {
                                              HelpFormatter formatter = new HelpFormatter();
                                              StringBuffer sb = new StringBuffer();
                                              String text = "Exactly fits";
                                              
                                              // Use reflection to access protected method
                                              Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              renderWrappedText.setAccessible(true);
                                              StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                  formatter, 
                                                  sb, 
                                                  text.length(), 
                                                  4, 
                                                  text
                                              );
                                              
                                              assertEquals("Text exactly fitting width should not wrap", text, result.toString());
                                          }

    @Test
                                          public void testRenderWrappedText_NextLineTabStopTooLarge() throws Exception {
                                              HelpFormatter formatter = new HelpFormatter();
                                              StringBuffer sb = new StringBuffer();
                                              String text = "Text with nextLineTabStop larger than width";
                                              
                                              // Use reflection to access protected method
                                              Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              renderWrappedText.setAccessible(true);
                                              StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                  formatter, 
                                                  sb, 
                                                  20, 
                                                  25, 
                                                  text
                                              );
                                              
                                              // Should adjust nextLineTabStop to width-1
                                              String expected = "Text with\n                   nextLineTabStop\n                   larger than\n                   width";
                                              assertEquals("Should handle too large nextLineTabStop", expected, result.toString());
                                          }

    @Test
                                          public void testRenderWrappedText_EmptyText() throws Exception {
                                              HelpFormatter formatter = new HelpFormatter();
                                              StringBuffer sb = new StringBuffer();
                                              String text = "";
                                              
                                              // Use reflection to access protected method
                                              Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              renderWrappedText.setAccessible(true);
                                              StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                  formatter, 
                                                  sb, 
                                                  20, 
                                                  4, 
                                                  text
                                              );
                                              
                                              assertEquals("Empty text should return empty buffer", "", result.toString());
                                          }

    @Test
                                          public void testRenderWrappedText_NullText() throws Exception {
                                              StringBuffer sb = new StringBuffer();
                                              HelpFormatter formatter = new HelpFormatter();
                                              
                                              // Since renderWrappedText is protected, we need to use reflection to access it
                                              Method method = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              method.setAccessible(true);
                                              
                                              try {
                                                  method.invoke(formatter, sb, 20, 4, null);
                                                  fail("Expected NullPointerException to be thrown");
                                              } catch (InvocationTargetException e) {
                                                  assertTrue(e.getCause() instanceof NullPointerException);
                                              }
                                          }

    @Test
                                          public void testRenderWrappedText_NullStringBuffer() throws Exception {
                                              HelpFormatter formatter = new HelpFormatter();
                                              ExpectedException exception = ExpectedException.none();
                                              exception.expect(NullPointerException.class);
                                              
                                              // Use reflection to access the protected method
                                              Method method = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              method.setAccessible(true);
                                              method.invoke(formatter, null, 20, 4, "test");
                                          }

    @Test
                                          public void testRenderWrappedText_WithExistingBufferContent() throws Exception {
                                              HelpFormatter formatter = new HelpFormatter();
                                              StringBuffer sb = new StringBuffer("Prefix ");
                                              String text = "This text should wrap";
                                              
                                              // Use reflection to access protected method
                                              Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              renderWrappedText.setAccessible(true);
                                              StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 15, 4, text);
                                              
                                              String expected = "Prefix This text\n    should wrap";
                                              assertEquals("Should preserve existing buffer content", expected, result.toString());
                                          }

    @Test
                                          public void testRenderWrappedText_SpecialCasePosEqualsTabStopMinusOne() throws Exception {
                                              HelpFormatter formatter = new HelpFormatter();
                                              StringBuffer sb = new StringBuffer();
                                              // Create a text that will trigger the special case where pos == nextLineTabStop - 1
                                              String text = "This is a text designed to trigger the special case in the wrapping algorithm";
                                              
                                              // Use reflection to access the protected method
                                              Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              renderWrappedText.setAccessible(true);
                                              StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 20, 5, text);
                                              
                                              // Verify the special case handling (pos = width when text.length() > width && pos == nextLineTabStop - 1)
                                              String expected = "This is a text\ndesigned to trigger\n the special case in\n the wrapping\n algorithm";
                                              assertEquals("Should handle special case pos == nextLineTabStop-1", expected, result.toString());
                                          }

    @Test
                                          public void testRenderWrappedText_WithWhitespace() throws Exception {
                                              HelpFormatter formatter = new HelpFormatter();
                                              StringBuffer sb = new StringBuffer();
                                              String text = "   Text with leading and trailing whitespace   ";
                                              
                                              // Use reflection to access protected method
                                              Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              renderWrappedText.setAccessible(true);
                                              StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                  formatter, 
                                                  sb, 
                                                  20, 
                                                  4, 
                                                  text
                                              );
                                              
                                              String expected = "Text with leading\n    and trailing\n    whitespace";
                                              assertEquals("Should properly handle whitespace", expected, result.toString());
                                          }

    @Test
                             public void testRenderWrappedText_WhenNextLineTabStopEqualsWidth_ShouldAdjustTabStop() throws Exception {
                                 // Setup
                                 HelpFormatter formatter = new HelpFormatter();
                                 
                                 // Use reflection to set protected field
                                 Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                 defaultNewLineField.setAccessible(true);
                                 defaultNewLineField.set(formatter, "\n");
                                 
                                 StringBuffer sb = new StringBuffer();
                                 int width = 10;
                                 int nextLineTabStop = 10;  // Equal to width
                                 String text = "This is a long text that needs to be wrapped properly";
                                 
                                 // Mock the dependencies using reflection
                                 HelpFormatter spyFormatter = spy(formatter);
                                 
                                 // Mock findWrapPos
                                 Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod("findWrapPos", String.class, int.class, int.class);
                                 findWrapPosMethod.setAccessible(true);
                                 when(findWrapPosMethod.invoke(eq(spyFormatter), anyString(), anyInt(), anyInt()))
                                     .thenReturn(5)
                                     .thenReturn(15)
                                     .thenReturn(-1);
                                 
                                 // Mock rtrim
                                 Method rtrimMethod = HelpFormatter.class.getDeclaredMethod("rtrim", String.class);
                                 rtrimMethod.setAccessible(true);
                                 when(rtrimMethod.invoke(eq(spyFormatter), anyString()))
                                     .thenAnswer(invocation -> invocation.getArgument(0));
                                 
                                 // Mock createPadding
                                 Method createPaddingMethod = HelpFormatter.class.getDeclaredMethod("createPadding", int.class);
                                 createPaddingMethod.setAccessible(true);
                                 when(createPaddingMethod.invoke(eq(spyFormatter), eq(5)))
                                     .thenReturn("     ");
                                 
                                 // Execute using reflection
                                 Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod("renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                 renderWrappedTextMethod.setAccessible(true);
                                 StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(spyFormatter, sb, width, nextLineTabStop, text);
                                 
                                 // Verify the output contains the expected padding
                                 String output = result.toString();
                                 assertTrue(output.contains("\n     ")); // Should have 5 spaces (from width-1)
                                 
                                 // Additional verification that the text was properly wrapped
                                 String[] lines = output.split("\n");
                                 assertEquals(3, lines.length); // Original line + two wrapped lines
                                 assertTrue(lines[1].startsWith("     ")); // Second line should have padding
                             }

    @Test
                        public void testRenderWrappedText_WhenNextLineTabStopExceedsWidth() throws Exception {
                            // Setup
                            HelpFormatter formatter = new HelpFormatter();
                            formatter.setWidth(5);  // Small width to trigger the condition
                            formatter.setNewLine("\n");
                            StringBuffer sb = new StringBuffer();
                            int nextLineTabStop = 10;  // Larger than width to trigger the condition
                            String text = "This is a test string that should wrap";
                            
                            // Get the protected method via reflection
                            Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                "renderWrappedText", 
                                StringBuffer.class, 
                                int.class, 
                                int.class, 
                                String.class
                            );
                            renderWrappedText.setAccessible(true);
                            
                            // Execute
                            StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                formatter, 
                                sb, 
                                formatter.getWidth(), 
                                nextLineTabStop, 
                                text
                            );
                            
                            // Verify the indentation was properly limited
                            String[] lines = result.toString().split("\n");
                            if (lines.length > 1) {
                                // Check the indentation of second line
                                String secondLine = lines[1];
                                // Original would indent by width-1 (4 spaces), mutant would indent by width-2 (3 spaces)
                                assertTrue("Second line should be indented by 4 spaces", 
                                           secondLine.startsWith("    "));
                                
                                // Verify the line length doesn't exceed width
                                assertTrue("Line length should not exceed width", 
                                           secondLine.length() <= formatter.getWidth());
                            }
                            
                            // Verify the complete output contains all original text
                            assertTrue("Result should contain original text", 
                                       result.toString().contains(text.trim()));
                        }

    @Test
                   public void testRenderWrappedText_WhenNextLineTabStopExceedsWidth_ShouldMaintainIndentation() throws Exception {
                       // Setup
                       HelpFormatter formatter = new HelpFormatter();
                       // Use reflection to set the protected defaultNewLine field
                       Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                       defaultNewLineField.setAccessible(true);
                       defaultNewLineField.set(formatter, "\n");
                       
                       StringBuffer sb = new StringBuffer();
                       int width = 10;
                       int nextLineTabStop = 15; // Exceeds width
                       String text = "This is a long text that needs to be wrapped multiple times";
                       
                       // Use reflection to access the protected method
                       Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                       renderWrappedTextMethod.setAccessible(true);
                       
                       // Execute
                       StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
                           formatter, sb, width, nextLineTabStop, text);
                       
                       // Verify
                       String output = result.toString();
                       String[] lines = output.split("\n");
                       
                       // First line shouldn't be indented
                       assertTrue(lines[0].length() <= width);
                       
                       // Subsequent lines should be indented (original behavior)
                       // If mutant is present, these would fail as lines wouldn't be indented
                       for (int i = 1; i < lines.length; i++) {
                           assertTrue("Line " + i + " should be indented", 
                                     lines[i].startsWith("     ")); // Expecting indentation of width-1 (9) spaces
                           assertTrue(lines[i].length() <= width);
                       }
                       
                       // Additional verification that the text was properly wrapped
                       String reconstructed = output.replace("\n", "");
                       assertEquals("Text content should be preserved", 
                                   text.replace(" ", ""), 
                                   reconstructed.replace(" ", ""));
                   }

    @Test
              public void testRenderWrappedText_NextLineTabStopGreaterThanWidth() throws Exception {
                  // Setup
                  HelpFormatter formatter = new HelpFormatter();
                  // Use reflection to set the protected field
                  Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                  defaultNewLineField.setAccessible(true);
                  defaultNewLineField.set(formatter, "\n");
                  
                  StringBuffer sb = new StringBuffer();
                  int width = 10;
                  int nextLineTabStop = 15; // Greater than width to trigger the condition
                  String text = "This is a long text that needs to be wrapped properly";
                  
                  // Use reflection to access the protected method
                  Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                      "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                  renderWrappedText.setAccessible(true);
                  
                  // Execute
                  StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
                  
                  // Verify the padding in subsequent lines
                  String output = result.toString();
                  String[] lines = output.split("\n");
                  
                  // First line shouldn't have padding
                  assertTrue(lines[0].trim().equals("This is a"));
                  
                  // Subsequent lines should have padding of width-1 (9 spaces for width=10)
                  // The mutant would make this only 1 space
                  for (int i = 1; i < lines.length; i++) {
                      String line = lines[i];
                      if (!line.isEmpty()) {
                          // Check padding before the actual text
                          assertTrue("Line should start with 9 spaces", line.startsWith("         "));
                          // Verify padding isn't just 1 space (which the mutant would do)
                          assertFalse("Line shouldn't start with just 1 space", line.startsWith(" "));
                      }
                  }
                  
                  // Verify the entire output is correct
                  String expected = 
                      "This is a\n" +
                      "         long\n" +  // 9 spaces padding
                      "         text\n" + // 9 spaces padding
                      "         that\n" + // 9 spaces padding
                      "         needs\n" + // 9 spaces padding
                      "         to be\n" + // 9 spaces padding
                      "         wrapped\n" + // 9 spaces padding
                      "         properly"; // 9 spaces padding
                  assertEquals(expected, output);
              }

    @Test
         public void testRenderWrappedText_WhenNextLineTabStopEqualsWidth_ShouldAdjustTabStop1() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             formatter.setNewLine("\n");
             StringBuffer sb = new StringBuffer();
             int width = 10;
             int nextLineTabStop = 10; // Equal to width
             String text = "This is a long text that needs to be wrapped";
             
             // Get protected method via reflection
             java.lang.reflect.Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                 "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
             renderWrappedText.setAccessible(true);
             
             // Execute
             StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
             
             // Verify the padding was adjusted (should use width-1 spaces)
             // Look for the indentation in subsequent lines
             String output = result.toString();
             String[] lines = output.split("\n");
             
             // First line shouldn't have padding
             assertTrue(lines[0].startsWith("This is a"));
             
             // Subsequent lines should have padding of width-1 (9) spaces
             if (lines.length > 1) {
                 String secondLine = lines[1];
                 assertTrue(secondLine.startsWith("         ")); // 9 spaces
                 assertEquals(9, secondLine.indexOf('l')); // 'l' of "long" should be at position 9
             }
             
             // Also verify no infinite loop occurred
             assertTrue(lines.length > 0 && lines.length < 10); // Reasonable line count
         }

    @Test
    public void testRenderWrappedText_NextLineTabStopGreaterThanWidth1() throws Exception {
        // Setup
        HelpFormatter formatter = new HelpFormatter();
        formatter.setWidth(10);  // Small width to force wrapping
        formatter.setNewLine("\n");
        
        // Create a case where nextLineTabStop >= width
        int width = 10;
        int nextLineTabStop = 15;  // Greater than width
        String text = "This is a long text that needs to be wrapped properly";
        StringBuffer sb = new StringBuffer();
        
        // Get the protected method using reflection
        Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", 
            StringBuffer.class, 
            int.class, 
            int.class, 
            String.class
        );
        renderWrappedTextMethod.setAccessible(true);
        
        // Execute
        StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
            formatter, 
            sb, 
            width, 
            nextLineTabStop, 
            text
        );
        
        // Verify the mutation by checking the indentation
        String[] lines = result.toString().split("\n");
        
        // Original behavior: nextLineTabStop should be width-1 (9)
        // Mutant behavior: nextLineTabStop would be width-2 (8)
        // Check second line starts with exactly 9 spaces
        if (lines.length > 1) {
            String secondLine = lines[1];
            assertTrue("Second line should start with 9 spaces", 
                       secondLine.startsWith("         "));  // 9 spaces
            assertEquals("Second line should have exactly 9 leading spaces", 
                         9, secondLine.length() - secondLine.trim().length());
        }
        
        // Additional verification to ensure no infinite loop occurred
        assertTrue("Result should contain multiple lines", lines.length > 1);
        assertFalse("Result should not be empty", result.toString().isEmpty());
    }


}
