package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                              public void testRenderWrappedText_NoWrapNeeded() {
                                                  HelpFormatter formatter = new HelpFormatter();
                                                  StringBuffer sb = new StringBuffer();
                                                  String text = "Short text";
                                                  
                                                  // Use reflection to access protected method
                                                  try {
                                                      Method method = HelpFormatter.class.getDeclaredMethod(
                                                          "renderWrappedText", 
                                                          StringBuffer.class, 
                                                          int.class, 
                                                          int.class, 
                                                          String.class
                                                      );
                                                      method.setAccessible(true);
                                                      StringBuffer result = (StringBuffer) method.invoke(formatter, sb, 20, 4, text);
                                                      
                                                      assertEquals("Short text", result.toString());
                                                      assertSame(sb, result);
                                                  } catch (Exception e) {
                                                      fail("Failed to invoke protected method: " + e.getMessage());
                                                  }
                                              }

    @Test
                                              public void testRenderWrappedText_SingleWrap() {
                                                  HelpFormatter formatter = new HelpFormatter();
                                                  StringBuffer sb = new StringBuffer();
                                                  String text = "This is a longer text that needs wrapping";
                                                  
                                                  // Use reflection to access protected method
                                                  try {
                                                      Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                          "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                      renderWrappedText.setAccessible(true);
                                                      StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 10, 2, text);
                                                      
                                                      String expected = "This is a\n  longer\n  text\n  that\n  needs\n  wrapping";
                                                      assertEquals(expected, result.toString());
                                                  } catch (Exception e) {
                                                      fail("Failed to invoke protected method: " + e.getMessage());
                                                  }
                                              }

    @Test
                                              public void testRenderWrappedText_MultipleWrapsWithPadding() throws Exception {
                                                  HelpFormatter formatter = new HelpFormatter();
                                                  StringBuffer sb = new StringBuffer();
                                                  String text = "A very long text that will require multiple wrapping operations";
                                                  
                                                  // Use reflection to access protected method
                                                  Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                      "renderWrappedText", 
                                                      StringBuffer.class, 
                                                      int.class, 
                                                      int.class, 
                                                      String.class
                                                  );
                                                  renderWrappedText.setAccessible(true);
                                                  StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 15, 3, text);
                                                  
                                                  String expected = "A very long\n   text that\n   will\n   require\n   multiple\n   wrapping\n   operations";
                                                  assertEquals(expected, result.toString());
                                              }

    @Test
                                              public void testRenderWrappedText_EdgeCaseWidth() throws Exception {
                                                  HelpFormatter formatter = new HelpFormatter();
                                                  StringBuffer sb = new StringBuffer();
                                                  String text = "Exactly ten chars";
                                                  
                                                  // Use reflection to access protected method
                                                  Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                      "renderWrappedText", 
                                                      StringBuffer.class, 
                                                      int.class, 
                                                      int.class, 
                                                      String.class
                                                  );
                                                  renderWrappedText.setAccessible(true);
                                                  StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 10, 2, text);
                                                  
                                                  assertEquals("Exactly\n  ten\n  chars", result.toString());
                                              }

    @Test
                                              public void testRenderWrappedText_NextLineTabStopLargerThanWidth() throws Exception {
                                                  HelpFormatter formatter = new HelpFormatter();
                                                  StringBuffer sb = new StringBuffer();
                                                  String text = "Text with tab stop larger than width";
                                                  
                                                  // Use reflection to access protected method
                                                  Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                      "renderWrappedText", 
                                                      StringBuffer.class, 
                                                      int.class, 
                                                      int.class, 
                                                      String.class
                                                  );
                                                  renderWrappedText.setAccessible(true);
                                                  StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 10, 15, text);
                                                  
                                                  // Should reset nextLineTabStop to 1
                                                  String expected = "Text with\n tab stop\n larger\n than\n width";
                                                  assertEquals(expected, result.toString());
                                              }

    @Test
                                              public void testRenderWrappedText_EmptyString() {
                                                  HelpFormatter formatter = new HelpFormatter();
                                                  StringBuffer sb = new StringBuffer();
                                                  
                                                  // Since renderWrappedText is protected, we need to access it via reflection
                                                  try {
                                                      Method method = HelpFormatter.class.getDeclaredMethod(
                                                          "renderWrappedText", 
                                                          StringBuffer.class, 
                                                          int.class, 
                                                          int.class, 
                                                          String.class
                                                      );
                                                      method.setAccessible(true);
                                                      StringBuffer result = (StringBuffer) method.invoke(formatter, sb, 10, 2, "");
                                                      assertEquals("", result.toString());
                                                  } catch (Exception e) {
                                                      fail("Failed to invoke protected method: " + e.getMessage());
                                                  }
                                              }

    @Test
                                              public void testRenderWrappedText_NullString() throws Exception {
                                                  HelpFormatter formatter = new HelpFormatter();
                                                  StringBuffer sb = new StringBuffer();
                                                  
                                                  try {
                                                      Method method = HelpFormatter.class.getDeclaredMethod(
                                                          "renderWrappedText", 
                                                          StringBuffer.class, 
                                                          int.class, 
                                                          int.class, 
                                                          String.class
                                                      );
                                                      method.setAccessible(true);
                                                      method.invoke(formatter, sb, 10, 2, null);
                                                      fail("Expected NullPointerException to be thrown");
                                                  } catch (InvocationTargetException e) {
                                                      assertTrue(e.getCause() instanceof NullPointerException);
                                                  }
                                              }

    @Test
                                              public void testRenderWrappedText_WithLeadingAndTrailingSpaces() throws Exception {
                                                  HelpFormatter formatter = new HelpFormatter();
                                                  StringBuffer sb = new StringBuffer();
                                                  String text = "   Text with spaces   ";
                                                  
                                                  // Use reflection to access protected method
                                                  Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                      "renderWrappedText", 
                                                      StringBuffer.class, 
                                                      int.class, 
                                                      int.class, 
                                                      String.class
                                                  );
                                                  renderWrappedText.setAccessible(true);
                                                  StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 10, 2, text);
                                                  
                                                  assertEquals("Text with\n  spaces", result.toString());
                                              }

    @Test
                                              public void testRenderWrappedText_SingleWordLongerThanWidth() throws Exception {
                                                  HelpFormatter formatter = new HelpFormatter();
                                                  StringBuffer sb = new StringBuffer();
                                                  String text = "Supercalifragilisticexpialidocious";
                                                  
                                                  // Use reflection to access protected method
                                                  Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                      "renderWrappedText", 
                                                      StringBuffer.class, 
                                                      int.class, 
                                                      int.class, 
                                                      String.class
                                                  );
                                                  renderWrappedText.setAccessible(true);
                                                  StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 10, 2, text);
                                                  
                                                  // Should break the word at width
                                                  assertEquals("Supercalif\n  ragilist\n  icexpial\n  idocious", result.toString());
                                              }

    @Test
                                              public void testRenderWrappedText_WithExistingBufferContent() {
                                                  HelpFormatter formatter = new HelpFormatter();
                                                  StringBuffer sb = new StringBuffer("Existing content. ");
                                                  String text = "New content to wrap";
                                                  
                                                  // Use reflection to access protected method
                                                  try {
                                                      Method method = HelpFormatter.class.getDeclaredMethod(
                                                          "renderWrappedText", 
                                                          StringBuffer.class, 
                                                          int.class, 
                                                          int.class, 
                                                          String.class
                                                      );
                                                      method.setAccessible(true);
                                                      StringBuffer result = (StringBuffer) method.invoke(formatter, sb, 10, 2, text);
                                                      
                                                      assertEquals("Existing content. New\n  content\n  to wrap", result.toString());
                                                  } catch (Exception e) {
                                                      fail("Failed to invoke protected method: " + e.getMessage());
                                                  }
                                              }

    @Test
                             public void testRenderWrappedText_WhenNextLineTabStopEqualsWidth_ShouldResetTabStop() throws Exception {
                                 // Setup
                                 HelpFormatter formatter = new HelpFormatter();
                                 Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                 defaultNewLineField.setAccessible(true);
                                 defaultNewLineField.set(formatter, "\n");  // Ensure consistent line endings
                                 
                                 StringBuffer sb = new StringBuffer();
                                 int width = 10;
                                 int nextLineTabStop = 10;  // Equal to width to trigger the condition
                                 String text = "This is a test string that is longer than the width";
                                 
                                 // Mock the dependencies using reflection
                                 HelpFormatter spyFormatter = spy(formatter);
                                 
                                 // Mock findWrapPos
                                 Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod("findWrapPos", String.class, int.class, int.class);
                                 findWrapPosMethod.setAccessible(true);
                                 when(findWrapPosMethod.invoke(spyFormatter, anyString(), eq(width), eq(0))).thenReturn(8).thenReturn(-1);
                                 
                                 // Mock createPadding
                                 Method createPaddingMethod = HelpFormatter.class.getDeclaredMethod("createPadding", int.class);
                                 createPaddingMethod.setAccessible(true);
                                 when(createPaddingMethod.invoke(spyFormatter, anyInt())).thenReturn("          ");
                                 
                                 // Execute using reflection
                                 Method renderMethod = HelpFormatter.class.getDeclaredMethod("renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                 renderMethod.setAccessible(true);
                                 StringBuffer result = (StringBuffer) renderMethod.invoke(spyFormatter, sb, width, nextLineTabStop, text);
                                 
                                 // Verify createPadding was called with 1 (the reset value) using reflection
                                 verify(createPaddingMethod, times(1)).invoke(spyFormatter, eq(1));
                                 
                                 // Additional assertions to ensure proper behavior
                                 assertTrue(result.toString().contains("\n"));
                                 
                                 // Verify findWrapPos was called using reflection
                                 verify(findWrapPosMethod, atLeastOnce()).invoke(spyFormatter, anyString(), eq(width), eq(0));
                                 
                                 // Verify the padding was applied correctly
                                 String[] lines = result.toString().split("\n");
                                 assertEquals(2, lines.length);
                                 assertTrue(lines[1].startsWith(" "));  // Should have single space padding
                             }

    @Test
                        public void testRenderWrappedText_DetectsWidthMutant() throws Exception {
                            // Setup
                            HelpFormatter formatter = new HelpFormatter();
                            
                            // Use reflection to set private fields
                            Field defaultWidthField = HelpFormatter.class.getDeclaredField("defaultWidth");
                            defaultWidthField.setAccessible(true);
                            defaultWidthField.set(formatter, 10);
                            
                            Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                            defaultNewLineField.setAccessible(true);
                            defaultNewLineField.set(formatter, "\n");
                            
                            // Create a scenario where:
                            // - text length > width (15 > 10)
                            // - nextLineTabStop is 1 (so nextLineTabStop-1 = 0)
                            // - initial wrap position will be 0 (equals nextLineTabStop-1)
                            StringBuffer sb = new StringBuffer();
                            String text = "1234567890ABCDE"; // 15 chars
                            int width = 10;
                            int nextLineTabStop = 1;
                            
                            // Use reflection to access protected method
                            Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                                "renderWrappedText", 
                                StringBuffer.class, 
                                int.class, 
                                int.class, 
                                String.class
                            );
                            renderWrappedTextMethod.setAccessible(true);
                            
                            // Execute
                            StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
                                formatter, 
                                sb, 
                                width, 
                                nextLineTabStop, 
                                text
                            );
                            
                            // Verify
                            String output = result.toString();
                            String[] lines = output.split("\n");
                            
                            // Check first line doesn't exceed width (should be exactly width chars)
                            assertEquals(10, lines[0].length());
                            
                            // Check second line (should be the remaining 5 chars plus padding)
                            assertEquals(5 + nextLineTabStop, lines[1].length());
                            
                            // Verify the mutant would fail here because:
                            // Original: pos=width → line1=10 chars
                            // Mutant: pos=width+1 → line1=11 chars (would fail first assertion)
                        }

    @Test
                   public void testRenderWrappedText_DetectsPosWidthMutant() throws Exception {
                       // Setup
                       HelpFormatter formatter = new HelpFormatter();
                       formatter.setWidth(10);  // Small width to force wrapping
                       formatter.setNewLine("\n");
                       
                       // Create a scenario where:
                       // 1. Text length > width
                       // 2. The wrap position equals nextLineTabStop-1
                       String text = "1234567890abc";  // Length 13 > width 10
                       int nextLineTabStop = 2;  // So nextLineTabStop-1 = 1
                       
                       // We need the findWrapPos to return 1 (equals nextLineTabStop-1)
                       // To simulate this, we'll create text where the first space is at position 1
                       text = "1 34567890abc";
                       
                       StringBuffer sb = new StringBuffer();
                       
                       // Get the protected method using reflection
                       Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", 
                           StringBuffer.class, 
                           int.class, 
                           int.class, 
                           String.class
                       );
                       renderWrappedTextMethod.setAccessible(true);
                       
                       // Execute
                       StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
                           formatter, 
                           sb, 
                           10, 
                           nextLineTabStop, 
                           text
                       );
                       
                       // Verify - mutant would create empty line at position 0
                       String output = result.toString();
                       assertFalse("Output should not contain empty lines", output.contains("\n\n"));  // Check for empty line
                       assertTrue("Output should contain wrapped text", output.contains("1\n"));  // Check proper wrapping
                       assertTrue("Output should contain remaining text", output.contains("34567890abc"));  // Check remaining text
                   }

    @Test
              public void testRenderWrappedText_WhenNextLineTabStopEqualsWidth_ShouldResetTabStop1() throws Exception {
                  // Setup
                  HelpFormatter formatter = new HelpFormatter();
                  formatter.setWidth(10);
                  formatter.setNewLine("\n");
                  
                  StringBuffer sb = new StringBuffer();
                  String text = "This is a long text that needs to be wrapped";
                  int width = 10;
                  int nextLineTabStop = 10; // Equal to width
                  
                  // Use reflection to access protected method
                  Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                      "renderWrappedText", 
                      StringBuffer.class, 
                      int.class, 
                      int.class, 
                      String.class
                  );
                  renderWrappedText.setAccessible(true);
                  
                  // Execute
                  StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                      formatter, 
                      sb, 
                      width, 
                      nextLineTabStop, 
                      text
                  );
                  
                  // Verify the padding of subsequent lines
                  String output = result.toString();
                  String[] lines = output.split("\n");
                  
                  // Original behavior: first line has no padding, subsequent lines have 1 space (from reset)
                  // Mutant behavior: subsequent lines would have 10 spaces (no reset)
                  assertTrue("Subsequent lines should have proper padding", 
                             lines.length > 1 && lines[1].startsWith(" "));
                  assertEquals("Subsequent lines should have single space padding", 
                              1, lines[1].indexOf(lines[1].trim()));
                  
                  // Additional verification that text was properly wrapped
                  assertTrue("Output should contain original text", output.contains("This is a"));
                  assertTrue("Output should contain wrapped text", output.contains("long text"));
              }

    @Test
         public void testRenderWrappedText_DetectsPosWidthMutation() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             formatter.setNewLine("\n");
             StringBuffer sb = new StringBuffer();
             int width = 10;
             int nextLineTabStop = 5;
             
             // Create text that will trigger the special case:
             // - Length > width
             // - Natural wrap position would be at nextLineTabStop-1 (4)
             String text = "1234 6789ABCDEF";
             
             // Expected behavior (original): should wrap at width (10)
             String expected = "1234 6789\n      ABCDEF";
             
             // Get protected methods via reflection
             Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                 "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
             renderWrappedText.setAccessible(true);
             
             Method findWrapPos = HelpFormatter.class.getDeclaredMethod(
                 "findWrapPos", String.class, int.class, int.class);
             findWrapPos.setAccessible(true);
             
             // Execute
             StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                 formatter, sb, width, nextLineTabStop, text);
             
             // Verify
             assertEquals("Text should be wrapped at exact width when special condition met", 
                         expected, 
                         result.toString());
             
             // Additional verification that we hit the special case
             int wrapPos = (Integer) findWrapPos.invoke(formatter, text, width, 0);
             assertTrue("Test case should trigger the pos=width branch",
                        text.length() > width && 
                        wrapPos == nextLineTabStop - 1);
         }

    @Test
    public void testRenderWrappedText_DetectsPosWidthMutant1() throws Exception {
        // Setup
        HelpFormatter formatter = new HelpFormatter();
        formatter.setWidth(10);  // Small width to force wrapping
        formatter.defaultNewLine = "\n";
        
        // Create a scenario where:
        // 1. Text length > width
        // 2. The wrap position equals nextLineTabStop-1
        // nextLineTabStop is 1 by default, so we need pos=0
        // But since we can't directly control findWrapPos, we'll create text that will
        // naturally wrap at position 0 when padded
        
        String text = "123456789012345";  // Longer than width
        int nextLineTabStop = 1;  // So pos == nextLineTabStop-1 means pos == 0
        
        // The mutation would cause the text to be split at position 0
        // instead of position 10 (width)
        
        // Execute using reflection to access protected method
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", 
            StringBuffer.class, 
            int.class, 
            int.class, 
            String.class
        );
        renderWrappedText.setAccessible(true);
        
        StringBuffer sb = new StringBuffer();
        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
            formatter, 
            sb, 
            10, 
            nextLineTabStop, 
            text
        );
        
        // Verify the first line is properly wrapped at width (10 chars)
        // With the mutation, it would wrap at position 0 creating an empty line
        String output = result.toString();
        String[] lines = output.split("\n");
        
        // First line should be the first 10 characters (or less if wrapped earlier)
        assertTrue("First line should not be empty", lines[0].length() > 0);
        
        // Verify we didn't get an empty line first (which would happen with pos=0)
        assertNotEquals("", lines[0].trim());
        
        // Verify the first line is properly limited to width
        assertTrue(lines[0].length() <= 10);
        
        // Verify subsequent lines have proper padding
        if (lines.length > 1) {
            assertTrue(lines[1].startsWith(" "));  // Should have padding
        }
    }


}
