package gentest.org.apache.commons.cli2.builder.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli2.builder.*;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.validation.ClassValidator;
import org.apache.commons.cli2.validation.DateValidator;
import org.apache.commons.cli2.validation.FileValidator;
import org.apache.commons.cli2.validation.NumberValidator;
import org.apache.commons.cli2.validation.UrlValidator;
import org.apache.commons.cli2.validation.Validator;
 
public class PatternBuilderTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
          public void testConstructor_InitializedBuildersAreIndependentInstances() throws Exception {
              // Arrange
              GroupBuilder mockGroupBuilder = new GroupBuilder();
              GroupBuilder anotherGroupBuilder = new GroupBuilder();
              DefaultOptionBuilder defaultOptionBuilder1 = new DefaultOptionBuilder();
              DefaultOptionBuilder defaultOptionBuilder2 = new DefaultOptionBuilder();
              ArgumentBuilder argumentBuilder1 = new ArgumentBuilder();
              ArgumentBuilder argumentBuilder2 = new ArgumentBuilder();
              
              // Act
              PatternBuilder pb1 = new PatternBuilder(mockGroupBuilder, defaultOptionBuilder1, argumentBuilder1);
              PatternBuilder pb2 = new PatternBuilder(anotherGroupBuilder, defaultOptionBuilder2, argumentBuilder2);
              
              // Use reflection to access private fields
              Field gbuilderField = PatternBuilder.class.getDeclaredField("gbuilder");
              Field obuilderField = PatternBuilder.class.getDeclaredField("obuilder");
              Field abuilderField = PatternBuilder.class.getDeclaredField("abuilder");
              Field optionsField = PatternBuilder.class.getDeclaredField("options");
              
              gbuilderField.setAccessible(true);
              obuilderField.setAccessible(true);
              abuilderField.setAccessible(true);
              optionsField.setAccessible(true);
              
              Object pb1Gbuilder = gbuilderField.get(pb1);
              Object pb2Gbuilder = gbuilderField.get(pb2);
              Object pb1Obuilder = obuilderField.get(pb1);
              Object pb2Obuilder = obuilderField.get(pb2);
              Object pb1Abuilder = abuilderField.get(pb1);
              Object pb2Abuilder = abuilderField.get(pb2);
              Object pb1Options = optionsField.get(pb1);
              Object pb2Options = optionsField.get(pb2);
              
              // Assert
              assertNotSame("Different PatternBuilders should have different GroupBuilders",
                           pb1Gbuilder, pb2Gbuilder);
              assertNotSame("Different PatternBuilders should have different OptionBuilders",
                           pb1Obuilder, pb2Obuilder);
              assertNotSame("Different PatternBuilders should have different ArgumentBuilders",
                           pb1Abuilder, pb2Abuilder);
              assertNotSame("Different PatternBuilders should have different Options sets",
                           pb1Options, pb2Options);
          }

 @Test
          public void testConstructor_ThrowsExceptionForNullGroupBuilder() {
              // Arrange
              DefaultOptionBuilder mockOptionBuilder = mock(DefaultOptionBuilder.class);
              ArgumentBuilder mockArgumentBuilder = mock(ArgumentBuilder.class);
              
              // Setup exception expectation
              ExpectedException exception = ExpectedException.none();
              exception.expect(NullPointerException.class);
              exception.expectMessage("GroupBuilder cannot be null");
              
              // Act
              new PatternBuilder(null, mockOptionBuilder, mockArgumentBuilder);
          }

 @Test
          public void testConstructor_ThrowsExceptionForNullOptionBuilder() {
              // Arrange
              GroupBuilder mockGroupBuilder = mock(GroupBuilder.class);
              ArgumentBuilder mockArgumentBuilder = mock(ArgumentBuilder.class);
              
              // Setup exception expectation
              ExpectedException exception = ExpectedException.none();
              exception.expect(NullPointerException.class);
              exception.expectMessage("DefaultOptionBuilder cannot be null");
              
              // Act
              new PatternBuilder(mockGroupBuilder, null, mockArgumentBuilder);
          }

 @Test
          public void testConstructor_ThrowsExceptionForNullArgumentBuilder() {
              // Arrange
              GroupBuilder mockGroupBuilder = mock(GroupBuilder.class);
              DefaultOptionBuilder mockOptionBuilder = mock(DefaultOptionBuilder.class);
              
              try {
                  // Act
                  new PatternBuilder(mockGroupBuilder, mockOptionBuilder, null);
                  fail("Expected NullPointerException to be thrown");
              } catch (NullPointerException e) {
                  // Assert
                  assertEquals("ArgumentBuilder cannot be null", e.getMessage());
              }
          }

 @Test
      public void testConstructor_InitializesAllBuilders() throws Exception {
          // Arrange
          GroupBuilder mockGroupBuilder = new GroupBuilder();
          DefaultOptionBuilder mockOptionBuilder = new DefaultOptionBuilder();
          ArgumentBuilder mockArgumentBuilder = new ArgumentBuilder();
          
          // Act
          PatternBuilder patternBuilder = new PatternBuilder(mockGroupBuilder, mockOptionBuilder, mockArgumentBuilder);
          
          // Use reflection to access private fields
          Class<?> patternBuilderClass = patternBuilder.getClass();
          Field gbuilderField = patternBuilderClass.getDeclaredField("gbuilder");
          Field obuilderField = patternBuilderClass.getDeclaredField("obuilder");
          Field abuilderField = patternBuilderClass.getDeclaredField("abuilder");
          Field optionsField = patternBuilderClass.getDeclaredField("options");
          
          gbuilderField.setAccessible(true);
          obuilderField.setAccessible(true);
          abuilderField.setAccessible(true);
          optionsField.setAccessible(true);
          
          Object gbuilder = gbuilderField.get(patternBuilder);
          Object obuilder = obuilderField.get(patternBuilder);
          Object abuilder = abuilderField.get(patternBuilder);
          Object options = optionsField.get(patternBuilder);
          
          // Assert
          assertNotNull("GroupBuilder should be initialized", gbuilder);
          assertNotNull("DefaultOptionBuilder should be initialized", obuilder);
          assertNotNull("ArgumentBuilder should be initialized", abuilder);
          assertNotNull("Options set should be initialized", options);
          assertTrue("Options set should be empty initially", ((Set<?>)options).isEmpty());
      }

 @Test
      public void testConstructor_WithNullGroupBuilder_ThrowsException() {
          // Arrange
          org.apache.commons.cli2.builder.GroupBuilder groupBuilder = null;
          org.apache.commons.cli2.builder.DefaultOptionBuilder optionBuilder = new org.apache.commons.cli2.builder.DefaultOptionBuilder();
          org.apache.commons.cli2.builder.ArgumentBuilder argumentBuilder = new org.apache.commons.cli2.builder.ArgumentBuilder();
          
          // Set up expected exception
          org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
          exception.expect(IllegalArgumentException.class);
          exception.expectMessage("GroupBuilder cannot be null");
          
          // Act
          PatternBuilder patternBuilder = new PatternBuilder(groupBuilder, optionBuilder, argumentBuilder);
      }

 @Test
      public void testConstructor_OptionsSetIsModifiable() {
          // Arrange
          GroupBuilder mockGroupBuilder = mock(GroupBuilder.class);
          DefaultOptionBuilder mockOptionBuilder = mock(DefaultOptionBuilder.class);
          ArgumentBuilder mockArgumentBuilder = mock(ArgumentBuilder.class);
          PatternBuilder patternBuilder = new PatternBuilder(mockGroupBuilder, mockOptionBuilder, mockArgumentBuilder);
          
          // Use reflection to access private options field
          try {
              Field optionsField = PatternBuilder.class.getDeclaredField("options");
              optionsField.setAccessible(true);
              Set<String> options = (Set<String>) optionsField.get(patternBuilder);
              
              // Act
              boolean initialAddResult = options.add("testOption");
              
              // Assert
              assertTrue("Should be able to add to options set", initialAddResult);
              assertEquals("Options set should contain added item", 1, options.size());
          } catch (NoSuchFieldException | IllegalAccessException e) {
              fail("Failed to access private options field: " + e.getMessage());
          }
      }

 @Test
      public void testConstructor_InitializesFieldsCorrectly() throws Exception {
          // Arrange
          GroupBuilder mockGroupBuilder = mock(GroupBuilder.class);
          DefaultOptionBuilder mockOptionBuilder = mock(DefaultOptionBuilder.class);
          ArgumentBuilder mockArgumentBuilder = mock(ArgumentBuilder.class);
          
          // Act
          PatternBuilder patternBuilder = new PatternBuilder(
              mockGroupBuilder, 
              mockOptionBuilder, 
              mockArgumentBuilder
          );
          
          // Use reflection to access private fields
          Class<?> patternBuilderClass = patternBuilder.getClass();
          Field gbuilderField = patternBuilderClass.getDeclaredField("gbuilder");
          Field obuilderField = patternBuilderClass.getDeclaredField("obuilder");
          Field abuilderField = patternBuilderClass.getDeclaredField("abuilder");
          Field optionsField = patternBuilderClass.getDeclaredField("options");
          
          gbuilderField.setAccessible(true);
          obuilderField.setAccessible(true);
          abuilderField.setAccessible(true);
          optionsField.setAccessible(true);
          
          // Assert
          assertSame("GroupBuilder not initialized correctly", 
                     mockGroupBuilder, gbuilderField.get(patternBuilder));
          assertSame("DefaultOptionBuilder not initialized correctly", 
                     mockOptionBuilder, obuilderField.get(patternBuilder));
          assertSame("ArgumentBuilder not initialized correctly", 
                     mockArgumentBuilder, abuilderField.get(patternBuilder));
          
          @SuppressWarnings("unchecked")
          Set<Option> options = (Set<Option>) optionsField.get(patternBuilder);
          assertNotNull("Options set should be initialized", options);
          assertTrue("Options set should be empty initially", options.isEmpty());
      }

}
