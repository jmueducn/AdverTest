package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
 
public class PosixParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                  public void testProcessOptionToken_ValidOption_StopAtNonOptionFalse() throws Exception {
                                      // Setup
                                      String token = "-f";
                                      Options options = mock(Options.class);
                                      Option mockOption = mock(Option.class);
                                      
                                      // Create parser instance and set private fields using reflection
                                      PosixParser parser = new PosixParser();
                                      Field optionsField = parser.getClass().getDeclaredField("options");
                                      optionsField.setAccessible(true);
                                      optionsField.set(parser, options);
                                      
                                      Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                      currentOptionField.setAccessible(true);
                                      
                                      Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                      eatTheRestField.setAccessible(true);
                                      
                                      Field tokensField = parser.getClass().getDeclaredField("tokens");
                                      tokensField.setAccessible(true);
                                      tokensField.set(parser, new ArrayList<String>());
                                      
                                      // Get the private method and make it accessible
                                      Method processOptionTokenMethod = parser.getClass().getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                      processOptionTokenMethod.setAccessible(true);
                                  
                                      when(options.hasOption(token)).thenReturn(true);
                                      when(options.getOption(token)).thenReturn(mockOption);
                                      
                                      // Execute
                                      processOptionTokenMethod.invoke(parser, token, false);
                                      
                                      // Verify
                                      verify(options).hasOption(token);
                                      verify(options).getOption(token);
                                      
                                      // Check state changes
                                      assertEquals(mockOption, currentOptionField.get(parser));
                                      assertFalse(eatTheRestField.getBoolean(parser));
                                      
                                      // Verify token was added
                                      @SuppressWarnings("unchecked")
                                      List<String> tokens = (List<String>) tokensField.get(parser);
                                      assertEquals(1, tokens.size());
                                      assertEquals(token, tokens.get(0));
                                  }

    @Test
                                  public void testProcessOptionToken_InvalidOption_StopAtNonOptionTrue() throws Exception {
                                      // Setup
                                      String token = "invalid";
                                      Options options = mock(Options.class);
                                      when(options.hasOption(token)).thenReturn(false);
                                      
                                      // Create parser instance and set required fields using reflection
                                      PosixParser parser = new PosixParser();
                                      Field optionsField = parser.getClass().getDeclaredField("options");
                                      optionsField.setAccessible(true);
                                      optionsField.set(parser, options);
                                      
                                      Field tokensField = parser.getClass().getDeclaredField("tokens");
                                      tokensField.setAccessible(true);
                                      tokensField.set(parser, new ArrayList<String>());
                                      
                                      // Get the private method and make it accessible
                                      Method processOptionToken = parser.getClass().getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                      processOptionToken.setAccessible(true);
                                      
                                      // Execute
                                      processOptionToken.invoke(parser, token, true);
                                      
                                      // Verify
                                      verify(options).hasOption(token);
                                      
                                      // Check state changes
                                      Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                      currentOptionField.setAccessible(true);
                                      assertNull(currentOptionField.get(parser));
                                      
                                      Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                      eatTheRestField.setAccessible(true);
                                      assertTrue((Boolean) eatTheRestField.get(parser));
                                      
                                      // Verify token was added
                                      @SuppressWarnings("unchecked")
                                      List<String> tokens = (List<String>) tokensField.get(parser);
                                      assertEquals(1, tokens.size());
                                      assertEquals(token, tokens.get(0));
                                  }

    @Test
                                  public void testProcessOptionToken_InvalidOption_StopAtNonOptionFalse() throws Exception {
                                      // Setup
                                      Options options = mock(Options.class);
                                      PosixParser parser = new PosixParser();
                                      
                                      // Use reflection to set private fields
                                      Field optionsField = parser.getClass().getDeclaredField("options");
                                      optionsField.setAccessible(true);
                                      optionsField.set(parser, options);
                                      
                                      Field tokensField = parser.getClass().getDeclaredField("tokens");
                                      tokensField.setAccessible(true);
                                      tokensField.set(parser, new ArrayList<String>());
                                      
                                      String token = "invalid";
                                      when(options.hasOption(token)).thenReturn(false);
                                      
                                      // Get the private method and make it accessible
                                      Method processOptionToken = parser.getClass().getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                      processOptionToken.setAccessible(true);
                                      
                                      // Execute
                                      processOptionToken.invoke(parser, token, false);
                                      
                                      // Verify
                                      verify(options).hasOption(token);
                                      
                                      // Check state changes
                                      Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                      currentOptionField.setAccessible(true);
                                      assertNull(currentOptionField.get(parser));
                                      
                                      Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                      eatTheRestField.setAccessible(true);
                                      assertFalse(eatTheRestField.getBoolean(parser));
                                      
                                      // Verify token was added
                                      @SuppressWarnings("unchecked")
                                      List<String> tokens = (List<String>) tokensField.get(parser);
                                      assertEquals(1, tokens.size());
                                      assertEquals(token, tokens.get(0));
                                  }

    @Test
                                  public void testProcessOptionToken_NullToken_ShouldThrowException() throws Exception {
                                      PosixParser parser = new PosixParser();
                                      Method method = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                      method.setAccessible(true);
                                      
                                      try {
                                          method.invoke(parser, null, true);
                                          fail("Expected NullPointerException to be thrown");
                                      } catch (InvocationTargetException e) {
                                          assertTrue(e.getCause() instanceof NullPointerException);
                                      }
                                  }

    @Test
                                  public void testProcessOptionToken_MultipleTokens_ShouldAddAll() {
                                      // Setup
                                      Options options = mock(Options.class);
                                      Option mockOption = mock(Option.class);
                                      PosixParser parser = new PosixParser();
                                      
                                      // Use reflection to set private options field in parser
                                      try {
                                          Field optionsField = parser.getClass().getDeclaredField("options");
                                          optionsField.setAccessible(true);
                                          optionsField.set(parser, options);
                                      } catch (Exception e) {
                                          fail("Failed to set options field via reflection");
                                      }
                                      
                                      String token1 = "-a";
                                      String token2 = "-b";
                                      when(options.hasOption(token1)).thenReturn(true);
                                      when(options.hasOption(token2)).thenReturn(true);
                                      when(options.getOption(token1)).thenReturn(mockOption);
                                      when(options.getOption(token2)).thenReturn(mockOption);
                                      
                                      // Execute using reflection to call private method
                                      try {
                                          Method processOptionToken = parser.getClass().getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                          processOptionToken.setAccessible(true);
                                          processOptionToken.invoke(parser, token1, false);
                                          processOptionToken.invoke(parser, token2, false);
                                      } catch (Exception e) {
                                          fail("Failed to invoke processOptionToken via reflection");
                                      }
                                      
                                      // Verify
                                      try {
                                          Field tokensField = parser.getClass().getDeclaredField("tokens");
                                          tokensField.setAccessible(true);
                                          @SuppressWarnings("unchecked")
                                          List<String> tokens = (List<String>) tokensField.get(parser);
                                          assertEquals(2, tokens.size());
                                          assertEquals(token1, tokens.get(0));
                                          assertEquals(token2, tokens.get(1));
                                      } catch (Exception e) {
                                          fail("Failed to verify tokens via reflection");
                                      }
                                  }

    @Test
                                  public void testProcessOptionToken_EmptyString_ShouldAddToken() throws Exception {
                                      // Setup
                                      Options options = mock(Options.class);
                                      PosixParser parser = new PosixParser();
                                      
                                      // Use reflection to set private fields
                                      Field optionsField = parser.getClass().getDeclaredField("options");
                                      optionsField.setAccessible(true);
                                      optionsField.set(parser, options);
                                      
                                      Field tokensField = parser.getClass().getDeclaredField("tokens");
                                      tokensField.setAccessible(true);
                                      
                                      Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                      eatTheRestField.setAccessible(true);
                                      
                                      String token = "";
                                      when(options.hasOption(token)).thenReturn(false);
                                      
                                      // Get and invoke the private method
                                      Method processOptionToken = parser.getClass().getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                      processOptionToken.setAccessible(true);
                                      processOptionToken.invoke(parser, token, true);
                                      
                                      // Verify
                                      @SuppressWarnings("unchecked")
                                      List<String> tokens = (List<String>) tokensField.get(parser);
                                      assertEquals(1, tokens.size());
                                      assertEquals(token, tokens.get(0));
                                      assertTrue((boolean) eatTheRestField.get(parser));
                                  }

    @Test
                             public void testProcessOptionToken_EatTheRestBehavior() throws Exception {
                                 // Setup
                                 PosixParser parser = new PosixParser();
                                 Options options = mock(Options.class);
                                 
                                 // Set private options field using reflection
                                 Field optionsField = PosixParser.class.getDeclaredField("options");
                                 optionsField.setAccessible(true);
                                 optionsField.set(parser, options);
                                 
                                 // Mock options to return false for hasOption
                                 when(options.hasOption(anyString())).thenReturn(false);
                                 
                                 // Get private fields and methods for later use
                                 Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                 eatTheRestField.setAccessible(true);
                                 
                                 Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                 tokensField.setAccessible(true);
                                 
                                 Method processOptionTokenMethod = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                 processOptionTokenMethod.setAccessible(true);
                                 
                                 // Initial state
                                 eatTheRestField.setBoolean(parser, false);
                                 String token = "nonexistent";
                                 
                                 // First call - both original and mutant would set to true
                                 processOptionTokenMethod.invoke(parser, token, true);
                                 assertTrue(eatTheRestField.getBoolean(parser)); // Both pass
                                 
                                 // Second call - original keeps true, mutant toggles to false
                                 processOptionTokenMethod.invoke(parser, token, true);
                                 assertTrue(eatTheRestField.getBoolean(parser)); // Original passes, mutant fails
                                 
                                 // Verify token was added twice
                                 @SuppressWarnings("unchecked")
                                 List<String> tokens = (List<String>) tokensField.get(parser);
                                 assertEquals(2, tokens.size());
                                 assertEquals(token, tokens.get(0));
                                 assertEquals(token, tokens.get(1));
                             }

    @Test
                        public void testProcessOptionToken_NonOptionWithStopAtNonOptionFalse_ShouldSetEatTheRest() {
                            // Setup
                            PosixParser parser = new PosixParser();
                            Options options = mock(Options.class);
                            when(options.hasOption(anyString())).thenReturn(false); // Token is not an option
                            
                            // Use reflection to set private fields since no constructor is available
                            // This is needed to set up the test scenario
                            try {
                                Field optionsField = PosixParser.class.getDeclaredField("options");
                                optionsField.setAccessible(true);
                                optionsField.set(parser, options);
                                
                                Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                eatTheRestField.setAccessible(true);
                                eatTheRestField.set(parser, false); // Initial state
                            } catch (Exception e) {
                                fail("Failed to set up test via reflection");
                            }
                            
                            // Test case where stopAtNonOption is false
                            boolean stopAtNonOption = false;
                            String token = "nonOptionToken";
                            
                            // Execute using reflection to access private method
                            try {
                                Method method = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                method.setAccessible(true);
                                method.invoke(parser, token, stopAtNonOption);
                            } catch (Exception e) {
                                fail("Failed to invoke processOptionToken via reflection");
                            }
                            
                            // Verify
                            try {
                                Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                eatTheRestField.setAccessible(true);
                                boolean actualEatTheRest = (boolean) eatTheRestField.get(parser);
                                
                                // Original would set eatTheRest to true regardless of stopAtNonOption
                                // Mutant would set it to false (same as stopAtNonOption)
                                assertTrue("eatTheRest should be true for non-option when stopAtNonOption is false", 
                                          actualEatTheRest);
                                
                                // Also verify token was added
                                Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                tokensField.setAccessible(true);
                                @SuppressWarnings("unchecked")
                                List<String> tokens = (List<String>) tokensField.get(parser);
                                assertTrue("Token should be added to tokens list", tokens.contains(token));
                            } catch (Exception e) {
                                fail("Failed to verify test results");
                            }
                        }

    @Test
                   public void testProcessOptionToken_AlwaysAddsTokenToList() {
                       // Setup
                       PosixParser parser = new PosixParser();
                       Options options = new Options();
                       options.addOption("a", "alpha", false, "alpha option");
                       
                       // Use reflection to access private fields and methods
                       try {
                           // Access tokens field
                           Field tokensField = PosixParser.class.getDeclaredField("tokens");
                           tokensField.setAccessible(true);
                           List<String> tokens = (List<String>) tokensField.get(parser);
                           
                           // Set options field
                           Field optionsField = PosixParser.class.getDeclaredField("options");
                           optionsField.setAccessible(true);
                           optionsField.set(parser, options);
                           
                           // Get private processOptionToken method
                           Method processOptionTokenMethod = PosixParser.class.getDeclaredMethod(
                               "processOptionToken", String.class, boolean.class);
                           processOptionTokenMethod.setAccessible(true);
                           
                           // Test with option token
                           processOptionTokenMethod.invoke(parser, "a", false);
                           assertEquals(1, tokens.size());
                           assertEquals("a", tokens.get(0));
                           
                           // Clear and test with non-option token
                           tokens.clear();
                           processOptionTokenMethod.invoke(parser, "b", false);
                           assertEquals(1, tokens.size());
                           assertEquals("b", tokens.get(0));
                           
                           // Clear and test with stopAtNonOption true
                           tokens.clear();
                           processOptionTokenMethod.invoke(parser, "c", true);
                           assertEquals(1, tokens.size());
                           assertEquals("c", tokens.get(0));
                       } catch (Exception e) {
                           fail("Reflection failed: " + e.getMessage());
                       }
                   }

    @Test
              public void testProcessOptionToken_ShouldBeCaseSensitive() {
                  // Setup
                  PosixParser parser = new PosixParser();
                  Options options = new Options();
                  Option helpOption = new Option("Help", "help command");
                  options.addOption(helpOption);
                  
                  // Use reflection to set private fields since no constructor/setters
                  try {
                      Field optionsField = PosixParser.class.getDeclaredField("options");
                      optionsField.setAccessible(true);
                      optionsField.set(parser, options);
                      
                      Field tokensField = PosixParser.class.getDeclaredField("tokens");
                      tokensField.setAccessible(true);
                      tokensField.set(parser, new ArrayList<String>());
                  } catch (Exception e) {
                      fail("Failed to set up test due to reflection error: " + e.getMessage());
                  }
                  
                  // Get the private processOptionToken method
                  Method processOptionTokenMethod;
                  try {
                      processOptionTokenMethod = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                      processOptionTokenMethod.setAccessible(true);
                  } catch (Exception e) {
                      fail("Failed to get processOptionToken method: " + e.getMessage());
                      return;
                  }
                  
                  // Test with uppercase token that exists (should match)
                  try {
                      processOptionTokenMethod.invoke(parser, "Help", false);
                  } catch (Exception e) {
                      fail("Failed to invoke processOptionToken: " + e.getMessage());
                  }
                  
                  // Verify option was set
                  try {
                      Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                      currentOptionField.setAccessible(true);
                      Option result = (Option) currentOptionField.get(parser);
                      assertEquals(helpOption, result);
                      
                      // Verify token was added
                      Field tokensField = PosixParser.class.getDeclaredField("tokens");
                      tokensField.setAccessible(true);
                      List<String> tokens = (List<String>) tokensField.get(parser);
                      assertEquals(1, tokens.size());
                      assertEquals("Help", tokens.get(0));
                  } catch (Exception e) {
                      fail("Failed to verify test due to reflection error: " + e.getMessage());
                  }
                  
                  // Reset for next test
                  try {
                      Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                      currentOptionField.setAccessible(true);
                      currentOptionField.set(parser, null);
                      
                      Field tokensField = PosixParser.class.getDeclaredField("tokens");
                      tokensField.setAccessible(true);
                      tokensField.set(parser, new ArrayList<String>());
                  } catch (Exception e) {
                      fail("Failed to reset test state: " + e.getMessage());
                  }
                  
                  // Test with lowercase token that would match if case insensitive (should NOT match)
                  try {
                      processOptionTokenMethod.invoke(parser, "help", false);
                  } catch (Exception e) {
                      fail("Failed to invoke processOptionToken: " + e.getMessage());
                  }
                  
                  // Verify option was NOT set
                  try {
                      Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                      currentOptionField.setAccessible(true);
                      Option result = (Option) currentOptionField.get(parser);
                      assertNull(result);
                      
                      // Verify token was still added
                      Field tokensField = PosixParser.class.getDeclaredField("tokens");
                      tokensField.setAccessible(true);
                      List<String> tokens = (List<String>) tokensField.get(parser);
                      assertEquals(1, tokens.size());
                      assertEquals("help", tokens.get(0));
                  } catch (Exception e) {
                      fail("Failed to verify test due to reflection error: " + e.getMessage());
                  }
              }

    @Test
         public void testProcessOptionToken_ShouldAddDuplicateTokens() throws Exception {
             // Setup
             PosixParser parser = new PosixParser();
             List<String> tokens = new ArrayList<>();
             
             // Use reflection to set private tokens field
             Field tokensField = PosixParser.class.getDeclaredField("tokens");
             tokensField.setAccessible(true);
             tokensField.set(parser, tokens);
             
             // Mock options to return false for hasOption to test the else branch
             Options options = mock(Options.class);
             when(options.hasOption(anyString())).thenReturn(false);
             
             // Use reflection to set private options field
             Field optionsField = PosixParser.class.getDeclaredField("options");
             optionsField.setAccessible(true);
             optionsField.set(parser, options);
             
             String testToken = "testToken";
             
             // Get private processOptionToken method
             Method processOptionToken = PosixParser.class.getDeclaredMethod(
                 "processOptionToken", String.class, boolean.class);
             processOptionToken.setAccessible(true);
             
             // First add the token
             processOptionToken.invoke(parser, testToken, false);
             
             // Verify token was added once
             assertEquals(1, tokens.size());
             assertEquals(testToken, tokens.get(0));
             
             // Process the same token again
             processOptionToken.invoke(parser, testToken, false);
             
             // Original behavior: token should be added again (size = 2)
             // Mutant behavior: token would not be added again (size = 1)
             assertEquals("Token should be added even if it already exists in tokens", 
                          2, tokens.size());
             assertEquals(testToken, tokens.get(1));
         }

    @Test
    public void testProcessOptionTokenWithWhitespaceShouldNotMatchOption() throws Exception {
        // Setup
        PosixParser parser = new PosixParser();
        Options options = mock(Options.class);
        
        // Use reflection to set private fields
        Field optionsField = PosixParser.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        optionsField.set(parser, options);
        
        // Configure mock behavior
        when(options.hasOption(" opt ")).thenReturn(false);
        when(options.hasOption("opt")).thenReturn(true);
        Option expectedOption = new Option("opt", "description");
        when(options.getOption("opt")).thenReturn(expectedOption);
        
        // Test with token containing whitespace
        String tokenWithWhitespace = " opt ";
        Method processOptionToken = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
        processOptionToken.setAccessible(true);
        processOptionToken.invoke(parser, tokenWithWhitespace, false);
        
        // Verify using reflection
        Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
        currentOptionField.setAccessible(true);
        assertNull("currentOption should not be set for token with whitespace", 
                   currentOptionField.get(parser));
        
        Field tokensField = PosixParser.class.getDeclaredField("tokens");
        tokensField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<String> tokens = (List<String>) tokensField.get(parser);
        assertTrue("Token should be added to tokens list",
                   tokens.contains(tokenWithWhitespace));
        
        Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
        eatTheRestField.setAccessible(true);
        assertFalse("eatTheRest should remain false", 
                    eatTheRestField.getBoolean(parser));
        
        // Verify mock interactions
        verify(options).hasOption(" opt ");
        verify(options, never()).getOption(anyString());
    }


}
