package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
 
public class OptionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                              public void testGetId_WithShortOptOnly() {
                                                                                                                                                  // Test with single character option
                                                                                                                                                  Option option = new Option("a", "description");
                                                                                                                                                  assertEquals('a', option.getId());
                                                                                                                                                  
                                                                                                                                                  // Test with multi-character option
                                                                                                                                                  Option option2 = new Option("abc", "description");
                                                                                                                                                  assertEquals('a', option2.getId());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetId_WithShortAndLongOpt() {
                                                                                                                                                  // Test with both short and long options
                                                                                                                                                  Option option = new Option("f", "file", true, "input file");
                                                                                                                                                  assertEquals('f', option.getId());
                                                                                                                                                  
                                                                                                                                                  Option option2 = new Option("v", "verbose", false, "verbose output");
                                                                                                                                                  assertEquals('v', option2.getId());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetId_WithDifferentConstructors() {
                                                                                                                                                  // Test with 2-arg constructor
                                                                                                                                                  Option option1 = new Option("t", "test description");
                                                                                                                                                  assertEquals('t', option1.getId());
                                                                                                                                                  
                                                                                                                                                  // Test with 3-arg constructor (hasArg)
                                                                                                                                                  Option option2 = new Option("d", true, "debug mode");
                                                                                                                                                  assertEquals('d', option2.getId());
                                                                                                                                                  
                                                                                                                                                  // Test with 4-arg constructor
                                                                                                                                                  Option option3 = new Option("l", "log", true, "log file");
                                                                                                                                                  assertEquals('l', option3.getId());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetId_WithUpperCaseOption() {
                                                                                                                                                  Option option = new Option("X", "exclude", false, "exclude pattern");
                                                                                                                                                  assertEquals('X', option.getId());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetId_WithNumericOption() {
                                                                                                                                                  Option option = new Option("1", "first", false, "first option");
                                                                                                                                                  assertEquals('1', option.getId());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetId_WithSpecialCharacterOption() {
                                                                                                                                                  Option option = new Option("@", "at", false, "at symbol");
                                                                                                                                                  assertEquals('@', option.getId());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetId_WithEmptyOptionShouldThrowException() {
                                                                                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                                                                                  new Option("", "empty option");
                                                                                                                                                  // The exception should be thrown during construction
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetType_WithStringClass() {
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  Class<?> expectedType = String.class;
                                                                                                                                                  
                                                                                                                                                  option.setType(expectedType);
                                                                                                                                                  assertEquals("Type should be set to String.class", 
                                                                                                                                                             expectedType, option.getType());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetType_WithIntegerClass() {
                                                                                                                                                  Option option = new Option("n", "number option");
                                                                                                                                                  Class<?> expectedType = Integer.class;
                                                                                                                                                  
                                                                                                                                                  option.setType(expectedType);
                                                                                                                                                  assertEquals("Type should be set to Integer.class", 
                                                                                                                                                             expectedType, option.getType());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetType_WithNull() {
                                                                                                                                                  Option option = new Option("x", "option with null type");
                                                                                                                                                  
                                                                                                                                                  option.setType(null);
                                                                                                                                                  assertNull("Type should be set to null", option.getType());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetType_OverwriteExistingType() {
                                                                                                                                                  Option option = new Option("f", "option with changing type");
                                                                                                                                                  option.setType(List.class);
                                                                                                                                                  
                                                                                                                                                  Class<?> newType = Double.class;
                                                                                                                                                  option.setType(newType);
                                                                                                                                                  
                                                                                                                                                  assertEquals("Type should be updated to Double.class", 
                                                                                                                                                              newType, option.getType());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetLongOpt_ValidValue() {
                                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                                  String testValue = "output";
                                                                                                                                                  option.setLongOpt(testValue);
                                                                                                                                                  assertEquals("Long option should be set correctly", testValue, option.getLongOpt());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetLongOpt_NullValue() {
                                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                                  option.setLongOpt(null);
                                                                                                                                                  assertNull("Long option should be set to null", option.getLongOpt());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetLongOpt_EmptyString() {
                                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                                  option.setLongOpt("");
                                                                                                                                                  assertEquals("Long option should be set to empty string", "", option.getLongOpt());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetLongOpt_SpecialCharacters() {
                                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                                  String testValue = "file-name";
                                                                                                                                                  option.setLongOpt(testValue);
                                                                                                                                                  assertEquals("Long option with special characters should be set correctly", 
                                                                                                                                                              testValue, option.getLongOpt());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetLongOpt_OverwriteExistingValue() {
                                                                                                                                                  Option option = new Option("o", "output", true, "description");
                                                                                                                                                  String originalValue = option.getLongOpt();
                                                                                                                                                  String newValue = "new-output";
                                                                                                                                                  
                                                                                                                                                  option.setLongOpt(newValue);
                                                                                                                                                  assertEquals("Long option should be updated to new value", 
                                                                                                                                                              newValue, option.getLongOpt());
                                                                                                                                                  assertNotEquals("Long option should no longer have original value", 
                                                                                                                                                                 originalValue, option.getLongOpt());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetLongOpt_VerifyHasLongOpt() {
                                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                                  assertFalse("Initially should not have long option", option.hasLongOpt());
                                                                                                                                                  
                                                                                                                                                  option.setLongOpt("output");
                                                                                                                                                  assertTrue("Should have long option after setting", option.hasLongOpt());
                                                                                                                                                  
                                                                                                                                                  option.setLongOpt(null);
                                                                                                                                                  assertFalse("Should not have long option after setting to null", option.hasLongOpt());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetOptionalArg_NewOption() {
                                                                                                                                                  // Test with a newly created option
                                                                                                                                                  Option newOption = new Option("n", "new", false, "New option");
                                                                                                                                                  assertFalse(newOption.hasOptionalArg());
                                                                                                                                                  
                                                                                                                                                  newOption.setOptionalArg(true);
                                                                                                                                                  assertTrue(newOption.hasOptionalArg());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasOptionalArg_WithDifferentConstructors() {
                                                                                                                                                  // Test with different constructor variations
                                                                                                                                                  Option opt1 = new Option("a", "description");
                                                                                                                                                  assertFalse(opt1.hasOptionalArg());
                                                                                                                                                  
                                                                                                                                                  Option opt2 = new Option("b", true, "description");
                                                                                                                                                  assertFalse(opt2.hasOptionalArg()); // constructor doesn't set optionalArg
                                                                                                                                                  
                                                                                                                                                  Option opt3 = new Option("c", "long", true, "description");
                                                                                                                                                  assertFalse(opt3.hasOptionalArg()); // constructor doesn't set optionalArg
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasLongOpt_WhenLongOptIsNull() {
                                                                                                                                                  // Create option with no longOpt
                                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                                  
                                                                                                                                                  assertFalse(option.hasLongOpt());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasLongOpt_WhenLongOptIsNotNull() {
                                                                                                                                                  // Create option with longOpt
                                                                                                                                                  Option option = new Option("o", "longOption", false, "description");
                                                                                                                                                  
                                                                                                                                                  assertTrue(option.hasLongOpt());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasLongOpt_AfterSettingLongOptToNull() {
                                                                                                                                                  // Create option with longOpt then set to null
                                                                                                                                                  Option option = new Option("o", "longOption", false, "description");
                                                                                                                                                  option.setLongOpt(null);
                                                                                                                                                  
                                                                                                                                                  assertFalse(option.hasLongOpt());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasLongOpt_AfterSettingLongOptToNonNull() {
                                                                                                                                                  // Create option without longOpt then set it
                                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                                  option.setLongOpt("newLongOption");
                                                                                                                                                  
                                                                                                                                                  assertTrue(option.hasLongOpt());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasLongOpt_AfterChangingLongOpt() {
                                                                                                                                                  // Create option with longOpt, change it, and verify
                                                                                                                                                  Option option = new Option("o", "originalLong", false, "description");
                                                                                                                                                  assertTrue(option.hasLongOpt());
                                                                                                                                                  
                                                                                                                                                  option.setLongOpt("newLong");
                                                                                                                                                  assertTrue(option.hasLongOpt());
                                                                                                                                                  
                                                                                                                                                  option.setLongOpt(null);
                                                                                                                                                  assertFalse(option.hasLongOpt());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasArg_WhenNumberOfArgsIsZero_ShouldReturnFalse() {
                                                                                                                                                  // Arrange
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgs(0); // Explicitly set to 0
                                                                                                                                                  
                                                                                                                                                  // Act & Assert
                                                                                                                                                  assertFalse(option.hasArg());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasArg_WhenNumberOfArgsIsOne_ShouldReturnTrue() {
                                                                                                                                                  // Arrange
                                                                                                                                                  Option option = new Option("t", true, "test option");
                                                                                                                                                  // Constructor sets numberOfArgs to 1 when hasArg is true
                                                                                                                                                  
                                                                                                                                                  // Act & Assert
                                                                                                                                                  assertTrue(option.hasArg());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasArg_WhenNumberOfArgsGreaterThanOne_ShouldReturnTrue() {
                                                                                                                                                  // Arrange
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgs(2); // Set to more than 1
                                                                                                                                                  
                                                                                                                                                  // Act & Assert
                                                                                                                                                  assertTrue(option.hasArg());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasArg_WhenNumberOfArgsIsUnlimitedValues_ShouldReturnTrue() {
                                                                                                                                                  // Arrange
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                                                  
                                                                                                                                                  // Act & Assert
                                                                                                                                                  assertTrue(option.hasArg());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasArg_WhenNumberOfArgsIsNegativeButNotUnlimited_ShouldReturnFalse() {
                                                                                                                                                  // Arrange
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgs(-5); // Negative but not UNLIMITED_VALUES
                                                                                                                                                  
                                                                                                                                                  // Act & Assert
                                                                                                                                                  assertFalse(option.hasArg());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetDescription_NormalString() {
                                                                                                                                                  Option option = new Option("t", "test");
                                                                                                                                                  String description = "This is a normal description";
                                                                                                                                                  option.setDescription(description);
                                                                                                                                                  assertEquals(description, option.getDescription());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetDescription_EmptyString() {
                                                                                                                                                  Option option = new Option("t", "test");
                                                                                                                                                  String description = "";
                                                                                                                                                  option.setDescription(description);
                                                                                                                                                  assertEquals(description, option.getDescription());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetDescription_Null() {
                                                                                                                                                  Option option = new Option("t", "test");
                                                                                                                                                  option.setDescription(null);
                                                                                                                                                  assertNull(option.getDescription());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetDescription_LongString() {
                                                                                                                                                  Option option = new Option("t", "test");
                                                                                                                                                  String description = "This is a very long description that might test the boundaries of the "
                                                                                                                                                          + "description field. It contains multiple sentences and various punctuation marks! "
                                                                                                                                                          + "Does it handle this properly? Let's find out...";
                                                                                                                                                  option.setDescription(description);
                                                                                                                                                  assertEquals(description, option.getDescription());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetDescription_SpecialCharacters() {
                                                                                                                                                  Option option = new Option("t", "test");
                                                                                                                                                  String description = "Special chars: !@#$%^&*()_+-=[]{};':\",./<>?`~";
                                                                                                                                                  option.setDescription(description);
                                                                                                                                                  assertEquals(description, option.getDescription());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetDescription_UnicodeCharacters() {
                                                                                                                                                  Option option = new Option("t", "test");
                                                                                                                                                  String description = "Unicode: こんにちは, Привет, 😊";
                                                                                                                                                  option.setDescription(description);
                                                                                                                                                  assertEquals(description, option.getDescription());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetDescription_AfterInitialization() {
                                                                                                                                                  Option option = new Option("t", "initial description");
                                                                                                                                                  String newDescription = "updated description";
                                                                                                                                                  option.setDescription(newDescription);
                                                                                                                                                  assertEquals(newDescription, option.getDescription());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetDescription_MultipleChanges() {
                                                                                                                                                  Option option = new Option("t", "first description");
                                                                                                                                                  option.setDescription("second description");
                                                                                                                                                  option.setDescription("third description");
                                                                                                                                                  assertEquals("third description", option.getDescription());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testIsRequired_WithDifferentConstructor() {
                                                                                                                                                  // Test with different constructor to ensure required is false by default
                                                                                                                                                  Option option2 = new Option("a", "another option");
                                                                                                                                                  assertFalse(option2.isRequired());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetRequired_True() {
                                                                                                                                                  // Setup
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  
                                                                                                                                                  // Exercise
                                                                                                                                                  option.setRequired(true);
                                                                                                                                                  
                                                                                                                                                  // Verify
                                                                                                                                                  assertTrue("Option should be required after setting to true", 
                                                                                                                                                            option.isRequired());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetRequired_False() {
                                                                                                                                                  // Setup
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setRequired(true); // Set to true first to test changing to false
                                                                                                                                                  
                                                                                                                                                  // Exercise
                                                                                                                                                  option.setRequired(false);
                                                                                                                                                  
                                                                                                                                                  // Verify
                                                                                                                                                  assertFalse("Option should not be required after setting to false", 
                                                                                                                                                             option.isRequired());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetRequired_DoesNotAffectOtherFields() {
                                                                                                                                                  // Setup
                                                                                                                                                  Option option = new Option("t", "longT", true, "description");
                                                                                                                                                  String originalLongOpt = option.getLongOpt();
                                                                                                                                                  String originalDescription = option.getDescription();
                                                                                                                                                  int originalNumberOfArgs = option.getArgs();
                                                                                                                                                  
                                                                                                                                                  // Exercise
                                                                                                                                                  option.setRequired(true);
                                                                                                                                                  
                                                                                                                                                  // Verify
                                                                                                                                                  assertEquals("Long option should remain unchanged", 
                                                                                                                                                              originalLongOpt, option.getLongOpt());
                                                                                                                                                  assertEquals("Description should remain unchanged", 
                                                                                                                                                              originalDescription, option.getDescription());
                                                                                                                                                  assertEquals("Number of args should remain unchanged", 
                                                                                                                                                              originalNumberOfArgs, option.getArgs());
                                                                                                                                                  assertTrue("Required flag should be set", option.isRequired());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetRequired_ToggleMultipleTimes() {
                                                                                                                                                  // Setup
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  
                                                                                                                                                  // Exercise & Verify in sequence
                                                                                                                                                  option.setRequired(true);
                                                                                                                                                  assertTrue("First set to true", option.isRequired());
                                                                                                                                                  
                                                                                                                                                  option.setRequired(false);
                                                                                                                                                  assertFalse("Then set to false", option.isRequired());
                                                                                                                                                  
                                                                                                                                                  option.setRequired(true);
                                                                                                                                                  assertTrue("Finally set back to true", option.isRequired());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgName_WithValidName() {
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  String expectedArgName = "filename";
                                                                                                                                                  
                                                                                                                                                  option.setArgName(expectedArgName);
                                                                                                                                                  
                                                                                                                                                  assertEquals("Argument name should be set correctly", 
                                                                                                                                                              expectedArgName, option.getArgName());
                                                                                                                                                  assertTrue("Option should have argument name", 
                                                                                                                                                            option.hasArgName());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgName_WithNull() {
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgName("originalName");
                                                                                                                                                  
                                                                                                                                                  option.setArgName(null);
                                                                                                                                                  
                                                                                                                                                  assertNull("Argument name should be null", option.getArgName());
                                                                                                                                                  assertFalse("Option should not have argument name", 
                                                                                                                                                             option.hasArgName());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgName_WithEmptyString() {
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  
                                                                                                                                                  option.setArgName("");
                                                                                                                                                  
                                                                                                                                                  assertEquals("Argument name should be empty string", 
                                                                                                                                                              "", option.getArgName());
                                                                                                                                                  assertTrue("Empty string should be considered as having argument name", 
                                                                                                                                                            option.hasArgName());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgName_VerifyStateChange() {
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  assertFalse("Initially should not have argument name", 
                                                                                                                                                             option.hasArgName());
                                                                                                                                                  
                                                                                                                                                  option.setArgName("testArg");
                                                                                                                                                  assertTrue("After setting should have argument name", 
                                                                                                                                                           option.hasArgName());
                                                                                                                                                  
                                                                                                                                                  option.setArgName(null);
                                                                                                                                                  assertFalse("After setting to null should not have argument name", 
                                                                                                                                                             option.hasArgName());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgName_WithSpecialCharacters() {
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  String specialArgName = "arg-name_with.special@chars!123";
                                                                                                                                                  
                                                                                                                                                  option.setArgName(specialArgName);
                                                                                                                                                  
                                                                                                                                                  assertEquals("Special characters in argument name should be preserved",
                                                                                                                                                             specialArgName, option.getArgName());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasArgName_WhenArgNameIsNull() {
                                                                                                                                                  // Setup
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgName(null); // Explicitly set to null
                                                                                                                                                  
                                                                                                                                                  // Test & Verify
                                                                                                                                                  assertFalse(option.hasArgName());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasArgName_WhenArgNameIsEmpty() {
                                                                                                                                                  // Setup
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgName(""); // Empty string
                                                                                                                                                  
                                                                                                                                                  // Test & Verify
                                                                                                                                                  assertFalse(option.hasArgName());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasArgName_WhenArgNameHasContent() {
                                                                                                                                                  // Setup
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgName("filename"); // Normal case
                                                                                                                                                  
                                                                                                                                                  // Test & Verify
                                                                                                                                                  assertTrue(option.hasArgName());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasArgName_WhenArgNameIsSingleSpace() {
                                                                                                                                                  // Setup
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgName(" "); // Edge case - single space
                                                                                                                                                  
                                                                                                                                                  // Test & Verify
                                                                                                                                                  assertTrue(option.hasArgName());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasArgName_WhenArgNameIsVeryLong() {
                                                                                                                                                  // Setup
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  String longString = new String(new char[1000]).replace('\0', 'x');
                                                                                                                                                  option.setArgName(longString); // Edge case - very long string
                                                                                                                                                  
                                                                                                                                                  // Test & Verify
                                                                                                                                                  assertTrue(option.hasArgName());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasArgName_AfterClearingArgName() {
                                                                                                                                                  // Setup
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgName("filename"); // Set to valid value first
                                                                                                                                                  option.setArgName(null); // Then clear it
                                                                                                                                                  
                                                                                                                                                  // Test & Verify
                                                                                                                                                  assertFalse(option.hasArgName());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgs_WithPositiveNumber() {
                                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                                  option.setArgs(3);
                                                                                                                                                  assertEquals(3, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgs_WithZero() {
                                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                                  option.setArgs(0);
                                                                                                                                                  assertEquals(0, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgs_WithUninitializedConstant() {
                                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                                  option.setArgs(Option.UNINITIALIZED);
                                                                                                                                                  assertEquals(Option.UNINITIALIZED, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgs_WithUnlimitedValuesConstant() {
                                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                                  option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                                                  assertEquals(Option.UNLIMITED_VALUES, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgs_WithMaxIntValue() {
                                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                                  option.setArgs(Integer.MAX_VALUE);
                                                                                                                                                  assertEquals(Integer.MAX_VALUE, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgs_OverwritesPreviousValue() {
                                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                                  option.setArgs(2);
                                                                                                                                                  option.setArgs(5);
                                                                                                                                                  assertEquals(5, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testSetArgs_WithNegativeNumber() {
                                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                                  option.setArgs(-1);
                                                                                                                                                  assertEquals(-1, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetValueSeparator_WithMultipleInstances() {
                                                                                                                                                  // Verify each instance maintains its own separator
                                                                                                                                                  Option option1 = new Option("a", "alpha", true, "first option");
                                                                                                                                                  Option option2 = new Option("b", "beta", true, "second option");
                                                                                                                                                  
                                                                                                                                                  option1.setValueSeparator('=');
                                                                                                                                                  option2.setValueSeparator(':');
                                                                                                                                                  
                                                                                                                                                  assertEquals('=', option1.getValueSeparator());
                                                                                                                                                  assertEquals(':', option2.getValueSeparator());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHasValueSeparator_DefaultConstructor_ShouldReturnFalse() {
                                                                                                                                                  // Arrange
                                                                                                                                                  Option defaultOption = new Option("d", "default option");
                                                                                                                                                  
                                                                                                                                                  // Act & Assert
                                                                                                                                                  assertFalse(defaultOption.hasValueSeparator());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetArgs_WhenNoArgsSet() {
                                                                                                                                                  // Test when numberOfArgs is not explicitly set (default case)
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  assertEquals(Option.UNINITIALIZED, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetArgs_WhenSingleArgSetInConstructor() {
                                                                                                                                                  // Test when hasArg is true in constructor (should set numberOfArgs to 1)
                                                                                                                                                  Option option = new Option("t", true, "test option");
                                                                                                                                                  assertEquals(1, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetArgs_WhenUnlimitedValuesSet() {
                                                                                                                                                  // Test when unlimited values are set
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                                                  assertEquals(Option.UNLIMITED_VALUES, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetArgs_WhenSpecificNumberOfArgsSet() {
                                                                                                                                                  // Test when specific number of args is set
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgs(3);
                                                                                                                                                  assertEquals(3, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetArgs_AfterClone() throws CloneNotSupportedException {
                                                                                                                                                  // Test that cloned object returns same args value
                                                                                                                                                  Option original = new Option("t", true, "test option");
                                                                                                                                                  Option cloned = (Option) original.clone();
                                                                                                                                                  assertEquals(original.getArgs(), cloned.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetArgs_WithLongOptAndArgs() {
                                                                                                                                                  // Test with long option and args set
                                                                                                                                                  Option option = new Option("t", "testOption", true, "test description");
                                                                                                                                                  assertEquals(1, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetArgs_AfterMultipleSetArgsCalls() {
                                                                                                                                                  // Test that last setArgs call determines the value
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgs(2);
                                                                                                                                                  option.setArgs(5);
                                                                                                                                                  assertEquals(5, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetArgs_WhenInitializedWithZeroArgs() {
                                                                                                                                                  // Test when explicitly set to 0 args
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgs(0);
                                                                                                                                                  assertEquals(0, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetArgs_WithNegativeValue() {
                                                                                                                                                  // Test with negative value (should be allowed as it might have special meaning)
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  option.setArgs(-1);
                                                                                                                                                  assertEquals(-1, option.getArgs());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testAddValue_WhenAcceptsArg_AddsValueToList() {
                                                                                                                                                  // Setup option with unlimited values
                                                                                                                                                  Option option = new Option("t", "test option", true, "description");
                                                                                                                                                  option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                                                  
                                                                                                                                                  String testValue = "testValue";
                                                                                                                                                  boolean result = option.addValue(testValue);
                                                                                                                                                  
                                                                                                                                                  assertTrue(result);
                                                                                                                                                  assertEquals(1, option.getValuesList().size());
                                                                                                                                                  assertEquals(testValue, option.getValue());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testAddValue_WithNullValue_AddsNullToList() {
                                                                                                                                                  Option option = new Option("t", "test option", true, "description");
                                                                                                                                                  option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                                                  
                                                                                                                                                  boolean result = option.addValue(null);
                                                                                                                                                  
                                                                                                                                                  assertTrue(result);
                                                                                                                                                  assertNull(option.getValue());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testAddValue_WithEmptyString_AddsEmptyString() {
                                                                                                                                                  Option option = new Option("t", "test option", true, "description");
                                                                                                                                                  option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                                                  
                                                                                                                                                  boolean result = option.addValue("");
                                                                                                                                                  
                                                                                                                                                  assertTrue(result);
                                                                                                                                                  assertEquals("", option.getValue());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testAddValue_WhenUnlimitedValues_CanAddMultipleValues() {
                                                                                                                                                  Option option = new Option("t", "test option", true, "description");
                                                                                                                                                  option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                                                  
                                                                                                                                                  option.addValue("value1");
                                                                                                                                                  option.addValue("value2");
                                                                                                                                                  option.addValue("value3");
                                                                                                                                                  
                                                                                                                                                  assertEquals(3, option.getValuesList().size());
                                                                                                                                                  assertArrayEquals(new String[]{"value1", "value2", "value3"}, option.getValues());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetValue_ReturnsDefaultWhenStoredValueIsNull() {
                                                                                                                                                  // Arrange
                                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                                  // No values added, so getValue() will return null
                                                                                                                                                  
                                                                                                                                                  // Act
                                                                                                                                                  String result = option.getValue("defaultValue");
                                                                                                                                                  
                                                                                                                                                  // Assert
                                                                                                                                                  assertEquals("defaultValue", result);
                                                                                                                                              }

    @Test
                                                                                                                                              public void testGetValue_ReturnsNullWhenBothStoredAndDefaultAreNull() {
                                                                                                                                                  // Arrange
                                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                                  // No values added, so getValue() will return null
                                                                                                                                                  
                                                                                                                                                  // Act
                                                                                                                                                  String result = option.getValue(null);
                                                                                                                                                  
                                                                                                                                                  // Assert
                                                                                                                                                  assertNull(result);
                                                                                                                                              }

    @Test
                                                                                                                                              public void testToString_ShortOptionOnly() {
                                                                                                                                                  Option option = new Option("f", "file option");
                                                                                                                                                  String expected = "[ option: f :: file option ]";
                                                                                                                                                  assertEquals(expected, option.toString());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testToString_WithLongOption() {
                                                                                                                                                  Option option = new Option("f", "file", false, "file option");
                                                                                                                                                  String expected = "[ option: f file :: file option ]";
                                                                                                                                                  assertEquals(expected, option.toString());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testToString_WithSingleArg() {
                                                                                                                                                  Option option = new Option("f", true, "file option");
                                                                                                                                                  String expected = "[ option: f [ARG] :: file option ]";
                                                                                                                                                  assertEquals(expected, option.toString());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testToString_WithMultipleArgs() {
                                                                                                                                                  Option option = new Option("f", "file", true, "file option");
                                                                                                                                                  option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                                                  String expected = "[ option: f file [ARG...] :: file option ]";
                                                                                                                                                  assertEquals(expected, option.toString());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testToString_WithType() {
                                                                                                                                                  Option option = new Option("f", "file", false, "file option");
                                                                                                                                                  option.setType(String.class);
                                                                                                                                                  String expected = "[ option: f file :: file option :: class java.lang.String ]";
                                                                                                                                                  assertEquals(expected, option.toString());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testToString_WithAllFeatures() {
                                                                                                                                                  Option option = new Option("f", "file", true, "file option");
                                                                                                                                                  option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                                                  option.setType(String.class);
                                                                                                                                                  String expected = "[ option: f file [ARG...] :: file option :: class java.lang.String ]";
                                                                                                                                                  assertEquals(expected, option.toString());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testToString_WithNullDescription() {
                                                                                                                                                  Option option = new Option("f", null);
                                                                                                                                                  String expected = "[ option: f :: null ]";
                                                                                                                                                  assertEquals(expected, option.toString());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testToString_WithEmptyDescription() {
                                                                                                                                                  Option option = new Option("f", "");
                                                                                                                                                  String expected = "[ option: f ::  ]";
                                                                                                                                                  assertEquals(expected, option.toString());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testToString_WithNullType() {
                                                                                                                                                  Option option = new Option("f", "file", false, "file option");
                                                                                                                                                  option.setType(null);
                                                                                                                                                  String expected = "[ option: f file :: file option ]";
                                                                                                                                                  assertEquals(expected, option.toString());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_Reflexive() {
                                                                                                                                                  Option option = new Option("a", "alpha", true, "description");
                                                                                                                                                  assertTrue(option.equals(option));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_Symmetric() {
                                                                                                                                                  Option option1 = new Option("a", "alpha", true, "description");
                                                                                                                                                  Option option2 = new Option("a", "alpha", true, "different description");
                                                                                                                                                  assertTrue(option1.equals(option2));
                                                                                                                                                  assertTrue(option2.equals(option1));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_Transitive() {
                                                                                                                                                  Option option1 = new Option("a", "alpha", true, "description");
                                                                                                                                                  Option option2 = new Option("a", "alpha", true, "different description");
                                                                                                                                                  Option option3 = new Option("a", "alpha", true, "another description");
                                                                                                                                                  assertTrue(option1.equals(option2));
                                                                                                                                                  assertTrue(option2.equals(option3));
                                                                                                                                                  assertTrue(option1.equals(option3));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_NullComparison() {
                                                                                                                                                  Option option = new Option("a", "alpha", true, "description");
                                                                                                                                                  assertFalse(option.equals(null));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_DifferentClass() {
                                                                                                                                                  Option option = new Option("a", "alpha", true, "description");
                                                                                                                                                  assertFalse(option.equals("string object"));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_SameOptAndLongOpt() {
                                                                                                                                                  Option option1 = new Option("a", "alpha", true, "description");
                                                                                                                                                  Option option2 = new Option("a", "alpha", false, "different description");
                                                                                                                                                  assertTrue(option1.equals(option2));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_DifferentOpt() {
                                                                                                                                                  Option option1 = new Option("a", "alpha", true, "description");
                                                                                                                                                  Option option2 = new Option("b", "alpha", true, "description");
                                                                                                                                                  assertFalse(option1.equals(option2));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_DifferentLongOpt() {
                                                                                                                                                  Option option1 = new Option("a", "alpha", true, "description");
                                                                                                                                                  Option option2 = new Option("a", "beta", true, "description");
                                                                                                                                                  assertFalse(option1.equals(option2));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_NullOpt() {
                                                                                                                                                  Option option1 = new Option(null, "alpha", true, "description");
                                                                                                                                                  Option option2 = new Option(null, "alpha", true, "description");
                                                                                                                                                  assertTrue(option1.equals(option2));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_OneNullOpt() {
                                                                                                                                                  Option option1 = new Option(null, "alpha", true, "description");
                                                                                                                                                  Option option2 = new Option("a", "alpha", true, "description");
                                                                                                                                                  assertFalse(option1.equals(option2));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_NullLongOpt() {
                                                                                                                                                  Option option1 = new Option("a", null, true, "description");
                                                                                                                                                  Option option2 = new Option("a", null, true, "description");
                                                                                                                                                  assertTrue(option1.equals(option2));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_OneNullLongOpt() {
                                                                                                                                                  Option option1 = new Option("a", null, true, "description");
                                                                                                                                                  Option option2 = new Option("a", "alpha", true, "description");
                                                                                                                                                  assertFalse(option1.equals(option2));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_BothNullOptAndLongOpt() {
                                                                                                                                                  Option option1 = new Option(null, null, true, "description");
                                                                                                                                                  Option option2 = new Option(null, null, true, "different description");
                                                                                                                                                  assertTrue(option1.equals(option2));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testEquals_AllFieldsSameExceptNonComparedFields() {
                                                                                                                                                  Option option1 = new Option("a", "alpha", true, "description");
                                                                                                                                                  option1.setRequired(true);
                                                                                                                                                  option1.setArgName("arg");
                                                                                                                                                  
                                                                                                                                                  Option option2 = new Option("a", "alpha", true, "description");
                                                                                                                                                  option2.setRequired(false);
                                                                                                                                                  option2.setArgName("differentArg");
                                                                                                                                                  
                                                                                                                                                  assertTrue(option1.equals(option2));
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHashCode_BothFieldsNull() {
                                                                                                                                                  Option option = new Option(null, null, false, null);
                                                                                                                                                  int expectedHash = 0; // 31 * (0) + 0 = 0
                                                                                                                                                  
                                                                                                                                                  assertEquals(expectedHash, option.hashCode());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHashCode_OptNullLongOptNotNull() {
                                                                                                                                                  String longOptValue = "help";
                                                                                                                                                  Option option = new Option(null, longOptValue, false, null);
                                                                                                                                                  int expectedHash = 31 * 0 + longOptValue.hashCode();
                                                                                                                                                  
                                                                                                                                                  assertEquals(expectedHash, option.hashCode());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHashCode_OptNotNullLongOptNull() {
                                                                                                                                                  String optValue = "h";
                                                                                                                                                  Option option = new Option(optValue, null, false, null);
                                                                                                                                                  int expectedHash = 31 * optValue.hashCode() + 0;
                                                                                                                                                  
                                                                                                                                                  assertEquals(expectedHash, option.hashCode());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHashCode_NeitherFieldNull() {
                                                                                                                                                  String optValue = "h";
                                                                                                                                                  String longOptValue = "help";
                                                                                                                                                  Option option = new Option(optValue, longOptValue, false, null);
                                                                                                                                                  int expectedHash = 31 * optValue.hashCode() + longOptValue.hashCode();
                                                                                                                                                  
                                                                                                                                                  assertEquals(expectedHash, option.hashCode());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHashCode_Consistency() {
                                                                                                                                                  Option option = new Option("h", "help", false, "description");
                                                                                                                                                  int firstHash = option.hashCode();
                                                                                                                                                  
                                                                                                                                                  // Multiple calls should return same value
                                                                                                                                                  assertEquals(firstHash, option.hashCode());
                                                                                                                                                  assertEquals(firstHash, option.hashCode());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testHashCode_EqualObjectsSameHash() {
                                                                                                                                                  Option option1 = new Option("h", "help", false, "description");
                                                                                                                                                  Option option2 = new Option("h", "help", false, "description");
                                                                                                                                                  
                                                                                                                                                  // Equal objects must have same hash code
                                                                                                                                                  assertEquals(option1.hashCode(), option2.hashCode());
                                                                                                                                              }

    @Test
                                                                                                                                              public void testClone_WhenCloneNotSupported() throws Exception {
                                                                                                                                                  // Create a spy that will throw CloneNotSupportedException
                                                                                                                                                  Option original = spy(new Option("t", "test", true, "description"));
                                                                                                                                                  doThrow(new CloneNotSupportedException("Test exception")).when(original).clone();
                                                                                                                                                  
                                                                                                                                                  // Expect RuntimeException
                                                                                                                                                  thrown.expect(RuntimeException.class);
                                                                                                                                                  thrown.expectMessage("A CloneNotSupportedException was thrown: Test exception");
                                                                                                                                                  
                                                                                                                                                  original.clone();
                                                                                                                                              }

    @Test
                                                                                                                                              public void testAddValue_ThrowsUnsupportedOperationException() {
                                                                                                                                                  // Setup
                                                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                                                  
                                                                                                                                                  // Expect exception
                                                                                                                                                  thrown.expect(UnsupportedOperationException.class);
                                                                                                                                                  thrown.expectMessage("The addValue method is not intended for client use. "
                                                                                                                                                          + "Subclasses should use the addValueForProcessing method instead.");
                                                                                                                                                  
                                                                                                                                                  // Exercise
                                                                                                                                                  option.addValue("testValue");
                                                                                                                                              }

    @Test
                                                                                                                                      public void testGetKey_WhenOptIsNotNull_ReturnsOpt() throws Exception {
                                                                                                                                          // Arrange
                                                                                                                                          String expected = "o";
                                                                                                                                          Option option = new Option(expected, "description");
                                                                                                                                          
                                                                                                                                          // Use reflection to access the private getKey() method
                                                                                                                                          Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                                                                          getKeyMethod.setAccessible(true);
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String actual = (String) getKeyMethod.invoke(option);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals(expected, actual);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetKey_WhenOptIsNull_ReturnsLongOpt() throws Exception {
                                                                                                                                          // Arrange
                                                                                                                                          String expected = "longOption";
                                                                                                                                          Option option = new Option(null, expected, false, "description");
                                                                                                                                          
                                                                                                                                          // Use reflection to access the private getKey() method
                                                                                                                                          Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                                                                          getKeyMethod.setAccessible(true);
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String actual = (String) getKeyMethod.invoke(option);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals(expected, actual);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetKey_WhenBothOptAndLongOptAreNull_ReturnsNull() throws Exception {
                                                                                                                                          // Arrange
                                                                                                                                          Option option = new Option(null, null, false, "description");
                                                                                                                                          
                                                                                                                                          // Use reflection to access the private getKey() method
                                                                                                                                          Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                                                                          getKeyMethod.setAccessible(true);
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String actual = (String) getKeyMethod.invoke(option);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertNull(actual);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetKey_WhenOptIsEmptyString_ReturnsEmptyString() throws Exception {
                                                                                                                                          // Arrange
                                                                                                                                          String expected = "";
                                                                                                                                          Option option = new Option(expected, "longOption", false, "description");
                                                                                                                                          
                                                                                                                                          // Use reflection to access the private getKey() method
                                                                                                                                          Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                                                                          getKeyMethod.setAccessible(true);
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String actual = (String) getKeyMethod.invoke(option);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals(expected, actual);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetKey_WhenOptIsNullAndLongOptIsEmptyString_ReturnsEmptyString() throws Exception {
                                                                                                                                          // Arrange
                                                                                                                                          String expected = "";
                                                                                                                                          Option option = new Option(null, expected, false, "description");
                                                                                                                                          
                                                                                                                                          // Use reflection to access the package-private getKey() method
                                                                                                                                          Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                                                                          getKeyMethod.setAccessible(true);
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String actual = (String) getKeyMethod.invoke(option);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals(expected, actual);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetOpt_WithShortOptionOnly() {
                                                                                                                                          String expectedOpt = "f";
                                                                                                                                          Option option = new Option(expectedOpt, "file option");
                                                                                                                                          
                                                                                                                                          assertEquals("Should return the short option value", 
                                                                                                                                                      expectedOpt, option.getOpt());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetOpt_WithShortAndLongOption() {
                                                                                                                                          String expectedOpt = "f";
                                                                                                                                          Option option = new Option(expectedOpt, "file", true, "file option");
                                                                                                                                          
                                                                                                                                          assertEquals("Should return the short option value even when long option is present", 
                                                                                                                                                      expectedOpt, option.getOpt());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetOpt_AfterSettingLongOption() {
                                                                                                                                          String expectedOpt = "v";
                                                                                                                                          Option option = new Option(expectedOpt, "verbose", false, "verbose option");
                                                                                                                                          option.setLongOpt("very-verbose");
                                                                                                                                          
                                                                                                                                          assertEquals("Changing long option shouldn't affect short option", 
                                                                                                                                                      expectedOpt, option.getOpt());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetOpt_WithNullOption() {
                                                                                                                                          // This shouldn't happen as the constructor validates the option
                                                                                                                                          // But we'll test the behavior if somehow opt is null
                                                                                                                                          
                                                                                                                                          // Create a valid option first
                                                                                                                                          Option option = new Option("t", "test option");
                                                                                                                                          
                                                                                                                                          // Use reflection to set opt to null for testing purposes
                                                                                                                                          try {
                                                                                                                                              java.lang.reflect.Field field = Option.class.getDeclaredField("opt");
                                                                                                                                              field.setAccessible(true);
                                                                                                                                              field.set(option, null);
                                                                                                                                              
                                                                                                                                              assertNull("Should return null if opt is null", option.getOpt());
                                                                                                                                          } catch (Exception e) {
                                                                                                                                              fail("Reflection failed: " + e.getMessage());
                                                                                                                                          }
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetOpt_WithEmptyStringOption() {
                                                                                                                                          // This shouldn't happen as the constructor validates the option
                                                                                                                                          // But we'll test the behavior if somehow opt is empty
                                                                                                                                          
                                                                                                                                          // Create a valid option first
                                                                                                                                          Option option = new Option("t", "test option");
                                                                                                                                          
                                                                                                                                          // Use reflection to set opt to empty string for testing purposes
                                                                                                                                          try {
                                                                                                                                              java.lang.reflect.Field field = Option.class.getDeclaredField("opt");
                                                                                                                                              field.setAccessible(true);
                                                                                                                                              field.set(option, "");
                                                                                                                                              
                                                                                                                                              assertEquals("Should return empty string if opt is empty", 
                                                                                                                                                          "", option.getOpt());
                                                                                                                                          } catch (Exception e) {
                                                                                                                                              fail("Reflection failed: " + e.getMessage());
                                                                                                                                          }
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetOpt_AfterClone() throws CloneNotSupportedException {
                                                                                                                                          String expectedOpt = "c";
                                                                                                                                          Option option = new Option(expectedOpt, "clone option");
                                                                                                                                          Option clonedOption = (Option) option.clone();
                                                                                                                                          
                                                                                                                                          assertEquals("Cloned option should return same short option", 
                                                                                                                                                      expectedOpt, clonedOption.getOpt());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetOpt_AfterMultipleOperations() {
                                                                                                                                          String expectedOpt = "m";
                                                                                                                                          Option option = new Option(expectedOpt, "multi option");
                                                                                                                                          
                                                                                                                                          // Perform various operations
                                                                                                                                          option.setDescription("new description");
                                                                                                                                          option.setRequired(true);
                                                                                                                                          option.setArgs(2);
                                                                                                                                          option.setValueSeparator(',');
                                                                                                                                          
                                                                                                                                          assertEquals("Various operations shouldn't affect getOpt()", 
                                                                                                                                                      expectedOpt, option.getOpt());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetType_AfterChangingType_ShouldReturnNewType() {
                                                                                                                                          // Arrange
                                                                                                                                          Option option = new Option("t", "test option");
                                                                                                                                          Class<?> initialType = Integer.class;
                                                                                                                                          Class<?> newType = Double.class;
                                                                                                                                          
                                                                                                                                          option.setType(initialType);
                                                                                                                                          Class<?> firstResult = (Class<?>) option.getType();
                                                                                                                                          
                                                                                                                                          // Act - change the type
                                                                                                                                          option.setType(newType);
                                                                                                                                          Class<?> secondResult = (Class<?>) option.getType();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertSame("First result should match initial type", initialType, firstResult);
                                                                                                                                          assertSame("Second result should match new type", newType, secondResult);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testSetType_WithCustomClass() {
                                                                                                                                          Option option = new Option("d", "date option");
                                                                                                                                          Class<?> expectedType = java.util.Date.class;
                                                                                                                                          
                                                                                                                                          option.setType(expectedType);
                                                                                                                                          assertEquals("Type should be set to Date.class", 
                                                                                                                                                     expectedType, option.getType());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetLongOpt_WhenLongOptIsNull() {
                                                                                                                                          // Arrange
                                                                                                                                          Option option = new Option("a", null, false, "description");
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String result = option.getLongOpt();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertNull(result);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetLongOpt_WhenLongOptIsEmptyString() {
                                                                                                                                          // Arrange
                                                                                                                                          Option option = new Option("a", "", false, "description");
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String result = option.getLongOpt();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals("", result);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetLongOpt_WhenLongOptIsValid() {
                                                                                                                                          // Arrange
                                                                                                                                          String expectedLongOpt = "alpha";
                                                                                                                                          Option option = new Option("a", expectedLongOpt, false, "description");
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String result = option.getLongOpt();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals(expectedLongOpt, result);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetLongOpt_AfterSettingLongOpt() {
                                                                                                                                          // Arrange
                                                                                                                                          Option option = new Option("a", null, false, "description");
                                                                                                                                          String expectedLongOpt = "newLongOpt";
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          option.setLongOpt(expectedLongOpt);
                                                                                                                                          String result = option.getLongOpt();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals(expectedLongOpt, result);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetLongOpt_AfterChangingLongOpt() {
                                                                                                                                          // Arrange
                                                                                                                                          String initialLongOpt = "initial";
                                                                                                                                          String newLongOpt = "new";
                                                                                                                                          Option option = new Option("a", initialLongOpt, false, "description");
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          option.setLongOpt(newLongOpt);
                                                                                                                                          String result = option.getLongOpt();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals(newLongOpt, result);
                                                                                                                                          assertNotEquals(initialLongOpt, result);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetLongOpt_WithSpecialCharacters() {
                                                                                                                                          // Arrange
                                                                                                                                          String specialLongOpt = "long-option-with-dashes";
                                                                                                                                          Option option = new Option("a", specialLongOpt, false, "description");
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String result = option.getLongOpt();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals(specialLongOpt, result);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetLongOpt_WithNumbers() {
                                                                                                                                          // Arrange
                                                                                                                                          String numericLongOpt = "option123";
                                                                                                                                          Option option = new Option("a", numericLongOpt, false, "description");
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String result = option.getLongOpt();
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals(numericLongOpt, result);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testSetOptionalArg_True() {
                                                                                                                                          // Create an Option object with required properties
                                                                                                                                          Option option = new Option("t", "test", true, "Test option");
                                                                                                                                          option.setArgs(1); // Set the number of arguments as per the test expectation
                                                                                                                                          
                                                                                                                                          // Set optional argument to true
                                                                                                                                          option.setOptionalArg(true);
                                                                                                                                          
                                                                                                                                          // Verify the value was set
                                                                                                                                          assertTrue(option.hasOptionalArg());
                                                                                                                                          
                                                                                                                                          // Verify it doesn't affect other properties
                                                                                                                                          assertEquals("t", option.getOpt());
                                                                                                                                          assertEquals("test", option.getLongOpt());
                                                                                                                                          assertEquals("Test option", option.getDescription());
                                                                                                                                          assertEquals(1, option.getArgs()); // Should remain unchanged
                                                                                                                                      }

    @Test
                                                                                                                                      public void testSetOptionalArg_False() {
                                                                                                                                          // Create an Option instance for testing
                                                                                                                                          Option option = new Option("t", "test option");
                                                                                                                                          
                                                                                                                                          // First set to true to ensure we can change it
                                                                                                                                          option.setOptionalArg(true);
                                                                                                                                          assertTrue(option.hasOptionalArg());
                                                                                                                                          
                                                                                                                                          // Now set to false
                                                                                                                                          option.setOptionalArg(false);
                                                                                                                                          
                                                                                                                                          // Verify the value was set
                                                                                                                                          assertFalse(option.hasOptionalArg());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testSetOptionalArg_MultipleChanges() {
                                                                                                                                          // Create an Option instance for testing
                                                                                                                                          Option option = new Option("test", "description");
                                                                                                                                          
                                                                                                                                          // Verify we can toggle the value multiple times
                                                                                                                                          option.setOptionalArg(true);
                                                                                                                                          assertTrue(option.hasOptionalArg());
                                                                                                                                          
                                                                                                                                          option.setOptionalArg(false);
                                                                                                                                          assertFalse(option.hasOptionalArg());
                                                                                                                                          
                                                                                                                                          option.setOptionalArg(true);
                                                                                                                                          assertTrue(option.hasOptionalArg());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testSetOptionalArg_WithOtherSetters() {
                                                                                                                                          // Create an Option instance for testing
                                                                                                                                          Option option = new Option("t", "test option");
                                                                                                                                          
                                                                                                                                          // Verify interaction with other setter methods
                                                                                                                                          option.setOptionalArg(true);
                                                                                                                                          option.setRequired(false);
                                                                                                                                          option.setDescription("Modified description");
                                                                                                                                          
                                                                                                                                          assertTrue(option.hasOptionalArg());
                                                                                                                                          assertFalse(option.isRequired());
                                                                                                                                          assertEquals("Modified description", option.getDescription());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testHasOptionalArg_DefaultValue() {
                                                                                                                                          // Create an Option instance with required parameters
                                                                                                                                          Option option = new Option("t", "test description");
                                                                                                                                          
                                                                                                                                          // By default, optionalArg should be false
                                                                                                                                          assertFalse(option.hasOptionalArg());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testHasOptionalArg_AfterSettingTrue() {
                                                                                                                                          Option option = new Option("test", "description");
                                                                                                                                          option.setOptionalArg(true);
                                                                                                                                          assertTrue(option.hasOptionalArg());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testHasOptionalArg_AfterSettingFalse() {
                                                                                                                                          Option option = new Option("test", "description"); // Create Option instance
                                                                                                                                          option.setOptionalArg(true); // First set to true
                                                                                                                                          option.setOptionalArg(false); // Then set to false
                                                                                                                                          assertFalse(option.hasOptionalArg());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testHasOptionalArg_MultipleToggle() {
                                                                                                                                          // Create an Option object for testing
                                                                                                                                          Option option = new Option("test", "description");
                                                                                                                                          
                                                                                                                                          // Test toggling the value multiple times
                                                                                                                                          option.setOptionalArg(true);
                                                                                                                                          assertTrue(option.hasOptionalArg());
                                                                                                                                          
                                                                                                                                          option.setOptionalArg(false);
                                                                                                                                          assertFalse(option.hasOptionalArg());
                                                                                                                                          
                                                                                                                                          option.setOptionalArg(true);
                                                                                                                                          assertTrue(option.hasOptionalArg());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testHasOptionalArg_AfterClone() throws CloneNotSupportedException {
                                                                                                                                          Option option = new Option("test", "description");
                                                                                                                                          option.setOptionalArg(true);
                                                                                                                                          Option clonedOption = (Option) option.clone();
                                                                                                                                          assertTrue(clonedOption.hasOptionalArg());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetDescription_WhenConstructedWithDescription() {
                                                                                                                                          String expectedDescription = "Test description";
                                                                                                                                          Option option = new Option("t", expectedDescription);
                                                                                                                                          
                                                                                                                                          assertEquals("Description should match constructor argument", 
                                                                                                                                                      expectedDescription, option.getDescription());
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetDescription_WhenConstructedWithEmptyDescription() {
                                                                                                                                          Option option = new Option("t", "");
                                                                                                                                          
                                                                                                                                          assertEquals("Description should be empty string", 
                                                                                                                                                      "", option.getDescription());
                                                                                                                                      }

    @Test
                                                                                                                                  public void testGetDescription_WhenConstructedWithNullDescription() {
                                                                                                                                      Option option = new Option("t", null);
                                                                                                                                      
                                                                                                                                      assertNull("Description should be null", option.getDescription());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetDescription_AfterSettingNewDescription() {
                                                                                                                                      Option option = new Option("t", "Initial description");
                                                                                                                                      String newDescription = "Updated description";
                                                                                                                                      option.setDescription(newDescription);
                                                                                                                                      
                                                                                                                                      assertEquals("Description should be updated", 
                                                                                                                                                  newDescription, option.getDescription());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetDescription_AfterSettingEmptyDescription() {
                                                                                                                                      Option option = new Option("t", "Initial description");
                                                                                                                                      option.setDescription("");
                                                                                                                                      
                                                                                                                                      assertEquals("Description should be empty string", 
                                                                                                                                                  "", option.getDescription());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetDescription_AfterSettingNullDescription() {
                                                                                                                                      Option option = new Option("t", "Initial description");
                                                                                                                                      option.setDescription(null);
                                                                                                                                      
                                                                                                                                      assertNull("Description should be null after setting to null", 
                                                                                                                                                option.getDescription());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetDescription_WithLongConstructor() {
                                                                                                                                      String expectedDescription = "Long constructor description";
                                                                                                                                      Option option = new Option("t", "test", true, expectedDescription);
                                                                                                                                      
                                                                                                                                      assertEquals("Description should match constructor argument", 
                                                                                                                                                  expectedDescription, option.getDescription());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetDescription_WithBooleanConstructor() {
                                                                                                                                      String expectedDescription = "Boolean constructor description";
                                                                                                                                      Option option = new Option("t", true, expectedDescription);
                                                                                                                                      
                                                                                                                                      assertEquals("Description should match constructor argument", 
                                                                                                                                                  expectedDescription, option.getDescription());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testIsRequired_DefaultValue() {
                                                                                                                                      // Create an Option object with required parameters
                                                                                                                                      Option option = new Option("t", "test option");
                                                                                                                                      
                                                                                                                                      // By default, required should be false
                                                                                                                                      assertFalse(option.isRequired());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testIsRequired_AfterSettingTrue() {
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      option.setRequired(true);
                                                                                                                                      assertTrue(option.isRequired());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testIsRequired_AfterSettingFalse() {
                                                                                                                                      Option option = new Option("test", "description");  // Create Option instance
                                                                                                                                      option.setRequired(true);  // First set to true
                                                                                                                                      option.setRequired(false); // Then set to false
                                                                                                                                      assertFalse(option.isRequired());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testIsRequired_AfterMultipleChanges() {
                                                                                                                                      // Create an Option instance for testing
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      
                                                                                                                                      // Test that the value can be toggled multiple times
                                                                                                                                      option.setRequired(true);
                                                                                                                                      assertTrue(option.isRequired());
                                                                                                                                      
                                                                                                                                      option.setRequired(false);
                                                                                                                                      assertFalse(option.isRequired());
                                                                                                                                      
                                                                                                                                      option.setRequired(true);
                                                                                                                                      assertTrue(option.isRequired());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testIsRequired_AfterClone() throws CloneNotSupportedException {
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      option.setRequired(true);
                                                                                                                                      Option clonedOption = (Option) option.clone();
                                                                                                                                      assertTrue(clonedOption.isRequired());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetArgName_WhenNotSet_ShouldReturnNull() {
                                                                                                                                      // Arrange - create an Option instance with minimal required parameters
                                                                                                                                      Option option = new Option("t", "test description");
                                                                                                                                      
                                                                                                                                      // Act
                                                                                                                                      String result = option.getArgName();
                                                                                                                                      
                                                                                                                                      // Assert
                                                                                                                                      assertNull("Default argName should be null", result);
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetArgName_WhenSetToNonNullValue_ShouldReturnCorrectValue() {
                                                                                                                                      // Arrange
                                                                                                                                      String expectedArgName = "filename";
                                                                                                                                      Option option = new Option("f", "file option");  // Initialize Option object
                                                                                                                                      option.setArgName(expectedArgName);
                                                                                                                                      
                                                                                                                                      // Act
                                                                                                                                      String result = option.getArgName();
                                                                                                                                      
                                                                                                                                      // Assert
                                                                                                                                      assertEquals("Should return the set argName", expectedArgName, result);
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetArgName_WhenSetToEmptyString_ShouldReturnEmptyString() {
                                                                                                                                      // Arrange
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      option.setArgName("");
                                                                                                                                      
                                                                                                                                      // Act
                                                                                                                                      String result = option.getArgName();
                                                                                                                                      
                                                                                                                                      // Assert
                                                                                                                                      assertEquals("Should return empty string", "", result);
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetArgName_WhenSetToWhitespace_ShouldReturnWhitespace() {
                                                                                                                                      // Arrange
                                                                                                                                      String expectedArgName = "   ";
                                                                                                                                      Option option = new Option("test", "description");  // Create Option instance
                                                                                                                                      option.setArgName(expectedArgName);
                                                                                                                                      
                                                                                                                                      // Act
                                                                                                                                      String result = option.getArgName();
                                                                                                                                      
                                                                                                                                      // Assert
                                                                                                                                      assertEquals("Should return whitespace string", expectedArgName, result);
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetArgName_AfterMultipleSets_ShouldReturnLastSetValue() {
                                                                                                                                      // Arrange
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      option.setArgName("first");
                                                                                                                                      option.setArgName("second");
                                                                                                                                      String expectedArgName = "final";
                                                                                                                                      option.setArgName(expectedArgName);
                                                                                                                                      
                                                                                                                                      // Act
                                                                                                                                      String result = option.getArgName();
                                                                                                                                      
                                                                                                                                      // Assert
                                                                                                                                      assertEquals("Should return the last set argName", expectedArgName, result);
                                                                                                                                  }

    @Test
                                                                                                                                  public void testHasArgs_WhenNumberOfArgsIsZero_ShouldReturnFalse() {
                                                                                                                                      Option option = new Option("t", "test option");
                                                                                                                                      option.setArgs(0);
                                                                                                                                      assertFalse(option.hasArgs());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testHasArgs_WhenNumberOfArgsIsOne_ShouldReturnFalse() {
                                                                                                                                      Option option = new Option("t", "test option");
                                                                                                                                      option.setArgs(1);
                                                                                                                                      assertFalse(option.hasArgs());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testHasArgs_WhenNumberOfArgsIsTwo_ShouldReturnTrue() {
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      option.setArgs(2);
                                                                                                                                      assertTrue(option.hasArgs());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testHasArgs_WhenNumberOfArgsIsUnlimited_ShouldReturnTrue() {
                                                                                                                                      Option option = new Option("test", "description");  // Create Option instance
                                                                                                                                      option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                                      assertTrue(option.hasArgs());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testHasArgs_WhenNumberOfArgsIsNegative_ShouldReturnFalse() {
                                                                                                                                      Option option = new Option("t", "test option");
                                                                                                                                      option.setArgs(-1);
                                                                                                                                      assertFalse(option.hasArgs());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testHasArgs_WhenNumberOfArgsIsLargePositive_ShouldReturnTrue() {
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      option.setArgs(Integer.MAX_VALUE);
                                                                                                                                      assertTrue(option.hasArgs());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testSetValueSeparator_StandardCharacter() {
                                                                                                                                      char testSeparator = '=';
                                                                                                                                      Option option = new Option("test", "description"); // Create Option instance
                                                                                                                                      option.setValueSeparator(testSeparator);
                                                                                                                                      
                                                                                                                                      assertEquals("Separator should be set correctly", 
                                                                                                                                                  testSeparator, option.getValueSeparator());
                                                                                                                                      assertTrue("Should have value separator", 
                                                                                                                                                 option.hasValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testSetValueSeparator_SpecialCharacters() {
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      char[] specialChars = {' ', '\t', '\n', ';', ':', '|'};
                                                                                                                                      
                                                                                                                                      for (char sep : specialChars) {
                                                                                                                                          option.setValueSeparator(sep);
                                                                                                                                          assertEquals("Separator should be set correctly for char: " + (int)sep, 
                                                                                                                                                       sep, option.getValueSeparator());
                                                                                                                                          assertTrue("Should have value separator for char: " + (int)sep, 
                                                                                                                                                     option.hasValueSeparator());
                                                                                                                                      }
                                                                                                                                  }

    @Test
                                                                                                                                  public void testSetValueSeparator_UnicodeCharacter() {
                                                                                                                                      Option option = new Option("test", "description"); // Initialize Option object
                                                                                                                                      char unicodeChar = '\u00A9'; // copyright symbol
                                                                                                                                      option.setValueSeparator(unicodeChar);
                                                                                                                                      
                                                                                                                                      assertEquals("Unicode separator should be set correctly", 
                                                                                                                                                  unicodeChar, option.getValueSeparator());
                                                                                                                                      assertTrue("Should have value separator for unicode char", 
                                                                                                                                                option.hasValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testSetValueSeparator_DefaultState() {
                                                                                                                                      // Create a new Option instance
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      
                                                                                                                                      // Verify initial state before setting any separator
                                                                                                                                      assertEquals("Default separator should be 0", 
                                                                                                                                                  '\u0000', option.getValueSeparator());
                                                                                                                                      assertFalse("Should not have value separator by default", 
                                                                                                                                                 option.hasValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testSetValueSeparator_ChangeSeparator() {
                                                                                                                                      // Create an Option instance for testing
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      
                                                                                                                                      // Set initial separator
                                                                                                                                      option.setValueSeparator('=');
                                                                                                                                      assertEquals('=', option.getValueSeparator());
                                                                                                                                      assertTrue(option.hasValueSeparator());
                                                                                                                                      
                                                                                                                                      // Change separator
                                                                                                                                      option.setValueSeparator(':');
                                                                                                                                      assertEquals("Separator should be updated", 
                                                                                                                                                  ':', option.getValueSeparator());
                                                                                                                                      assertTrue("Should still have value separator", 
                                                                                                                                                option.hasValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testSetValueSeparator_RemoveSeparator() {
                                                                                                                                      // Create an Option instance
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      
                                                                                                                                      // Set initial separator
                                                                                                                                      option.setValueSeparator('=');
                                                                                                                                      
                                                                                                                                      // "Remove" separator by setting it to null character
                                                                                                                                      option.setValueSeparator('\u0000');
                                                                                                                                      assertEquals("Separator should be reset to default", 
                                                                                                                                                  '\u0000', option.getValueSeparator());
                                                                                                                                      assertFalse("Should no longer have value separator", 
                                                                                                                                                 option.hasValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetValueSeparator_DefaultValue() {
                                                                                                                                      // Create an Option instance
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      
                                                                                                                                      // Default value should be '\0' (null character)
                                                                                                                                      assertEquals('\0', option.getValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetValueSeparator_AfterSettingSeparator() {
                                                                                                                                      // Create an Option object for testing
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      
                                                                                                                                      // Set a separator and verify it's returned
                                                                                                                                      option.setValueSeparator('=');
                                                                                                                                      assertEquals('=', option.getValueSeparator());
                                                                                                                                      
                                                                                                                                      // Set another separator and verify
                                                                                                                                      option.setValueSeparator(':');
                                                                                                                                      assertEquals(':', option.getValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetValueSeparator_WithSpecialCharacters() {
                                                                                                                                      // Create an Option object for testing
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      
                                                                                                                                      // Test with various special characters
                                                                                                                                      option.setValueSeparator(' ');
                                                                                                                                      assertEquals(' ', option.getValueSeparator());
                                                                                                                                      
                                                                                                                                      option.setValueSeparator('\t');
                                                                                                                                      assertEquals('\t', option.getValueSeparator());
                                                                                                                                      
                                                                                                                                      option.setValueSeparator('\n');
                                                                                                                                      assertEquals('\n', option.getValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetValueSeparator_WithUnicodeCharacters() {
                                                                                                                                      // Create an Option instance for testing
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      
                                                                                                                                      // Test with Unicode characters
                                                                                                                                      option.setValueSeparator('€');
                                                                                                                                      assertEquals('€', option.getValueSeparator());
                                                                                                                                      
                                                                                                                                      option.setValueSeparator('字');
                                                                                                                                      assertEquals('字', option.getValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetValueSeparator_AfterClone() throws Exception {
                                                                                                                                      // Create an option instance
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      
                                                                                                                                      // Set a separator
                                                                                                                                      option.setValueSeparator('|');
                                                                                                                                      
                                                                                                                                      // Clone the option and verify separator is preserved
                                                                                                                                      Option clonedOption = (Option) option.clone();
                                                                                                                                      assertEquals('|', clonedOption.getValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testHasValueSeparator_WhenSeparatorIsZero_ShouldReturnFalse() {
                                                                                                                                      // Arrange
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      option.setValueSeparator((char)0);
                                                                                                                                      
                                                                                                                                      // Act & Assert
                                                                                                                                      assertFalse(option.hasValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testHasValueSeparator_WhenSeparatorIsPositive_ShouldReturnTrue() {
                                                                                                                                      // Arrange
                                                                                                                                      Option option = new Option("test", "description");
                                                                                                                                      option.setValueSeparator('=');
                                                                                                                                      
                                                                                                                                      // Act & Assert
                                                                                                                                      assertTrue(option.hasValueSeparator());
                                                                                                                                  }

    @Test
                                                                                                                              public void testHasValueSeparator_WhenSeparatorIsNegative_ShouldReturnFalse() {
                                                                                                                                  // Note: Since char is unsigned in Java, this test might be redundant
                                                                                                                                  // but included for completeness
                                                                                                                                  
                                                                                                                                  // Arrange
                                                                                                                                  Option option = new Option("test", "description");  // Initialize Option object
                                                                                                                                  // Need to use reflection to set negative value since char is unsigned
                                                                                                                                  try {
                                                                                                                                      java.lang.reflect.Field field = Option.class.getDeclaredField("valuesep");
                                                                                                                                      field.setAccessible(true);
                                                                                                                                      field.set(option, (char)-1);
                                                                                                                                      
                                                                                                                                      // Act & Assert
                                                                                                                                      assertFalse(option.hasValueSeparator());
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Reflection failed: " + e.getMessage());
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                                                              public void testHasValueSeparator_AfterClone_ShouldReturnSameValue() throws Exception {
                                                                                                                                  // Arrange
                                                                                                                                  Option option = new Option("test", "description");
                                                                                                                                  option.setValueSeparator(':');
                                                                                                                                  Option clonedOption = (Option)option.clone();
                                                                                                                                  
                                                                                                                                  // Act & Assert
                                                                                                                                  assertTrue(clonedOption.hasValueSeparator());
                                                                                                                              }

    @Test
                                                                                                                              public void testGetArgs_AfterClearingValues() throws Exception {
                                                                                                                                  // Test that getArgs returns the same value even after clearing values
                                                                                                                                  Option option = new Option("t", true, "test option");
                                                                                                                                  
                                                                                                                                  // Use reflection to access the private clearValues method
                                                                                                                                  Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                                  clearValuesMethod.setAccessible(true);
                                                                                                                                  clearValuesMethod.invoke(option);
                                                                                                                                  
                                                                                                                                  assertEquals(1, option.getArgs());
                                                                                                                              }

    @Test
                                                                                                                              public void testAddValueForProcessing_WithEmptyString_ShouldProcessValue() throws Exception {
                                                                                                                                  // Arrange
                                                                                                                                  Option option = spy(new Option("t", true, "test option"));
                                                                                                                                  String emptyValue = "";
                                                                                                                                  
                                                                                                                                  // Use reflection to call package-private method
                                                                                                                                  Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                  addValueMethod.setAccessible(true);
                                                                                                                                  
                                                                                                                                  // Act
                                                                                                                                  addValueMethod.invoke(option, emptyValue);
                                                                                                                                  
                                                                                                                                  // Assert - verify the effect rather than the private method call
                                                                                                                                  assertTrue(option.getValuesList().contains(emptyValue));
                                                                                                                              }

    @Test
                                                                                                                              public void testProcessValue_NoSeparator() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                  option.setArgs(1); // Expecting 1 argument
                                                                                                                                  
                                                                                                                                  // Mock hasValueSeparator to return false
                                                                                                                                  Option spyOption = spy(option);
                                                                                                                                  when(spyOption.hasValueSeparator()).thenReturn(false);
                                                                                                                                  
                                                                                                                                  // Use reflection to access addValueForProcessing
                                                                                                                                  Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                  addValueForProcessing.setAccessible(true);
                                                                                                                                  
                                                                                                                                  // Execute
                                                                                                                                  addValueForProcessing.invoke(spyOption, "simpleValue");
                                                                                                                                  
                                                                                                                                  // Verify
                                                                                                                                  assertEquals("simpleValue", spyOption.getValue());
                                                                                                                                  assertEquals(1, spyOption.getValuesList().size());
                                                                                                                              }

    @Test
                                                                                                                              public void testProcessValue_SingleSeparatorWithinLimit() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                  option.setArgs(2); // Expecting 2 arguments
                                                                                                                                  option.setValueSeparator(',');
                                                                                                                                  
                                                                                                                                  // Mock hasValueSeparator to return true
                                                                                                                                  Option spyOption = spy(option);
                                                                                                                                  when(spyOption.hasValueSeparator()).thenReturn(true);
                                                                                                                                  when(spyOption.getValueSeparator()).thenReturn(',');
                                                                                                                                  
                                                                                                                                  // Use reflection to access addValueForProcessing
                                                                                                                                  Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                  addValueForProcessing.setAccessible(true);
                                                                                                                                  addValueForProcessing.invoke(spyOption, "val1,val2");
                                                                                                                                  
                                                                                                                                  // Verify
                                                                                                                                  List<String> values = spyOption.getValuesList();
                                                                                                                                  assertEquals(2, values.size());
                                                                                                                                  assertEquals("val1", values.get(0));
                                                                                                                                  assertEquals("val2", values.get(1));
                                                                                                                              }

    @Test
                                                                                                                              public void testProcessValue_MultipleSeparatorsExceedingLimit() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                  option.setArgs(2); // Expecting 2 arguments (1 separator allowed)
                                                                                                                                  option.setValueSeparator(',');
                                                                                                                                  
                                                                                                                                  // Mock hasValueSeparator to return true
                                                                                                                                  Option spyOption = spy(option);
                                                                                                                                  when(spyOption.hasValueSeparator()).thenReturn(true);
                                                                                                                                  when(spyOption.getValueSeparator()).thenReturn(',');
                                                                                                                                  
                                                                                                                                  // Use reflection to access private addValueForProcessing method
                                                                                                                                  Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                  addValueForProcessing.setAccessible(true);
                                                                                                                                  addValueForProcessing.invoke(spyOption, "val1,val2,val3");
                                                                                                                                  
                                                                                                                                  // Verify
                                                                                                                                  List<String> values = spyOption.getValuesList();
                                                                                                                                  assertEquals(2, values.size());
                                                                                                                                  assertEquals("val1", values.get(0));
                                                                                                                                  assertEquals("val2,val3", values.get(1));
                                                                                                                              }

    @Test
                                                                                                                              public void testProcessValue_EmptyValue() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                  option.setArgs(1);
                                                                                                                                  
                                                                                                                                  // Mock hasValueSeparator to return false
                                                                                                                                  Option spyOption = spy(option);
                                                                                                                                  when(spyOption.hasValueSeparator()).thenReturn(false);
                                                                                                                                  
                                                                                                                                  // Use reflection to access addValueForProcessing method
                                                                                                                                  Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                  addValueForProcessing.setAccessible(true);
                                                                                                                                  
                                                                                                                                  // Execute
                                                                                                                                  addValueForProcessing.invoke(spyOption, "");
                                                                                                                                  
                                                                                                                                  // Verify
                                                                                                                                  assertEquals("", spyOption.getValue());
                                                                                                                                  assertEquals(1, spyOption.getValuesList().size());
                                                                                                                              }

    @Test
                                                                                                                              public void testProcessValue_SeparatorAtStart() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                  option.setArgs(2);
                                                                                                                                  option.setValueSeparator(',');
                                                                                                                                  
                                                                                                                                  // Mock hasValueSeparator to return true
                                                                                                                                  Option spyOption = spy(option);
                                                                                                                                  when(spyOption.hasValueSeparator()).thenReturn(true);
                                                                                                                                  when(spyOption.getValueSeparator()).thenReturn(',');
                                                                                                                                  
                                                                                                                                  // Use reflection to call addValueForProcessing
                                                                                                                                  Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                  addValueForProcessing.setAccessible(true);
                                                                                                                                  addValueForProcessing.invoke(spyOption, ",val2");
                                                                                                                                  
                                                                                                                                  // Verify
                                                                                                                                  List<String> values = spyOption.getValuesList();
                                                                                                                                  assertEquals(2, values.size());
                                                                                                                                  assertEquals("", values.get(0));
                                                                                                                                  assertEquals("val2", values.get(1));
                                                                                                                              }

    @Test
                                                                                                                              public void testProcessValue_SeparatorAtEnd() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                  option.setArgs(2);
                                                                                                                                  option.setValueSeparator(',');
                                                                                                                                  
                                                                                                                                  // Mock hasValueSeparator to return true
                                                                                                                                  Option spyOption = spy(option);
                                                                                                                                  when(spyOption.hasValueSeparator()).thenReturn(true);
                                                                                                                                  when(spyOption.getValueSeparator()).thenReturn(',');
                                                                                                                                  
                                                                                                                                  // Use reflection to access addValueForProcessing
                                                                                                                                  Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                  addValueForProcessing.setAccessible(true);
                                                                                                                                  addValueForProcessing.invoke(spyOption, "val1,");
                                                                                                                                  
                                                                                                                                  // Verify
                                                                                                                                  List<String> values = spyOption.getValuesList();
                                                                                                                                  assertEquals(2, values.size());
                                                                                                                                  assertEquals("val1", values.get(0));
                                                                                                                                  assertEquals("", values.get(1));
                                                                                                                              }

    @Test
                                                                                                                              public void testProcessValue_UnlimitedArgs() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                  option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                                  option.setValueSeparator(',');
                                                                                                                                  
                                                                                                                                  // Mock hasValueSeparator to return true
                                                                                                                                  Option spyOption = spy(option);
                                                                                                                                  when(spyOption.hasValueSeparator()).thenReturn(true);
                                                                                                                                  when(spyOption.getValueSeparator()).thenReturn(',');
                                                                                                                                  
                                                                                                                                  // Use reflection to access private addValueForProcessing method
                                                                                                                                  Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                  addValueForProcessing.setAccessible(true);
                                                                                                                                  addValueForProcessing.invoke(spyOption, "val1,val2,val3,val4");
                                                                                                                                  
                                                                                                                                  // Verify
                                                                                                                                  List<String> values = spyOption.getValuesList();
                                                                                                                                  assertEquals(4, values.size());
                                                                                                                                  assertEquals("val1", values.get(0));
                                                                                                                                  assertEquals("val2", values.get(1));
                                                                                                                                  assertEquals("val3", values.get(2));
                                                                                                                                  assertEquals("val4", values.get(3));
                                                                                                                              }

    @Test(expected = RuntimeException.class)
                                                                                                                              public void testAddValue_WhenDoesNotAcceptArg_ThrowsException() {
                                                                                                                                  // Setup option with no more capacity
                                                                                                                                  Option option = new Option("t", "test option", true, "description");
                                                                                                                                  option.setArgs(1); // Only accepts one value
                                                                                                                                  option.addValue("firstValue"); // Fill the capacity
                                                                                                                                  
                                                                                                                                  // This should throw the expected exception
                                                                                                                                  option.addValue("secondValue");
                                                                                                                              }

    @Test
                                                                                                                              public void testAddValue_WhenLimitedValues_StopsAfterLimit() {
                                                                                                                                  Option option = new Option("t", "test option", true, "description");
                                                                                                                                  option.setArgs(2); // Accepts exactly 2 values
                                                                                                                                  
                                                                                                                                  option.addValue("value1");
                                                                                                                                  option.addValue("value2");
                                                                                                                                  
                                                                                                                                  try {
                                                                                                                                      option.addValue("value3");
                                                                                                                                      fail("Expected RuntimeException");
                                                                                                                                  } catch (RuntimeException e) {
                                                                                                                                      assertEquals("Cannot add value, list full.", e.getMessage());
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                                                              public void testAddValue_WhenNoArgsAllowed_AlwaysThrowsException() {
                                                                                                                                  Option option = new Option("t", "test option", false, "description");
                                                                                                                                  assertEquals(0, option.getArgs());
                                                                                                                                  
                                                                                                                                  // Set up expected exception
                                                                                                                                  try {
                                                                                                                                      option.addValue("anyValue");
                                                                                                                                      fail("Expected RuntimeException to be thrown");
                                                                                                                                  } catch (RuntimeException e) {
                                                                                                                                      assertEquals("Cannot add value, list full.", e.getMessage());
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                                                              public void testGetValue_WhenNoValuesExist_ShouldReturnNull() {
                                                                                                                                  // Given - no values added (default state)
                                                                                                                                  Option option = new Option("test", "description");
                                                                                                                                  
                                                                                                                                  // When
                                                                                                                                  String result = option.getValue();
                                                                                                                                  
                                                                                                                                  // Then
                                                                                                                                  assertNull(result);
                                                                                                                              }

    @Test
                                                                                                                              public void testGetValue_WhenSingleValueExists_ShouldReturnThatValue() {
                                                                                                                                  // Given
                                                                                                                                  String expectedValue = "testValue";
                                                                                                                                  Option option = new Option("test", "description");  // Initialize Option object
                                                                                                                                  option.addValue(expectedValue);
                                                                                                                                  
                                                                                                                                  // When
                                                                                                                                  String result = option.getValue();
                                                                                                                                  
                                                                                                                                  // Then
                                                                                                                                  assertEquals(expectedValue, result);
                                                                                                                              }

    @Test
                                                                                                                              public void testGetValue_WhenMultipleValuesExist_ShouldReturnFirstValue() {
                                                                                                                                  // Given
                                                                                                                                  Option option = new Option("test", "description");
                                                                                                                                  String firstValue = "first";
                                                                                                                                  String secondValue = "second";
                                                                                                                                  option.addValue(firstValue);
                                                                                                                                  option.addValue(secondValue);
                                                                                                                                  
                                                                                                                                  // When
                                                                                                                                  String result = option.getValue();
                                                                                                                                  
                                                                                                                                  // Then
                                                                                                                                  assertEquals(firstValue, result);
                                                                                                                              }

    @Test
                                                                                                                              public void testGetValue_WhenFirstValueIsNull_ShouldReturnNull() {
                                                                                                                                  // Given
                                                                                                                                  Option option = new Option("test", "description");
                                                                                                                                  option.addValue(null);
                                                                                                                                  option.addValue("notNull");
                                                                                                                                  
                                                                                                                                  // When
                                                                                                                                  String result = option.getValue();
                                                                                                                                  
                                                                                                                                  // Then
                                                                                                                                  assertNull(result);
                                                                                                                              }

    @Test
                                                                                                                              public void testGetValue_WithValidIndex_ReturnsCorrectValue() {
                                                                                                                                  // Setup
                                                                                                                                  Option option = new Option("test", "description");
                                                                                                                                  List<String> mockValues = mock(List.class);
                                                                                                                                  
                                                                                                                                  // Use reflection to set private values field since it's not accessible directly
                                                                                                                                  try {
                                                                                                                                      Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                                      valuesField.setAccessible(true);
                                                                                                                                      valuesField.set(option, mockValues);
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Mock behavior
                                                                                                                                  when(mockValues.isEmpty()).thenReturn(false);
                                                                                                                                  when(mockValues.get(0)).thenReturn("testValue");
                                                                                                                                  
                                                                                                                                  // Execute and verify
                                                                                                                                  assertEquals("testValue", option.getValue(0));
                                                                                                                              }

    @Test
                                                                                                                              public void testGetValue_WithEmptyStringValue_ReturnsEmptyString() {
                                                                                                                                  // Setup
                                                                                                                                  Option option = new Option("test", "description");
                                                                                                                                  List<String> mockValues = mock(List.class);
                                                                                                                                  
                                                                                                                                  // Use reflection to set private values field since it's not directly accessible
                                                                                                                                  try {
                                                                                                                                      Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                                      valuesField.setAccessible(true);
                                                                                                                                      valuesField.set(option, mockValues);
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Failed to set values field via reflection");
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Mock behavior
                                                                                                                                  when(mockValues.isEmpty()).thenReturn(false);
                                                                                                                                  when(mockValues.get(0)).thenReturn("");
                                                                                                                                  
                                                                                                                                  // Execute and verify
                                                                                                                                  assertEquals("", option.getValue(0));
                                                                                                                              }

    @Test
                                                                                                                              public void testGetValue_ReturnsStoredValueWhenNotNull() {
                                                                                                                                  // Arrange
                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                  try {
                                                                                                                                      Method method = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                      method.setAccessible(true);
                                                                                                                                      method.invoke(option, "testValue");
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Failed to call addValueForProcessing via reflection");
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Act
                                                                                                                                  String result = option.getValue("default");
                                                                                                                                  
                                                                                                                                  // Assert
                                                                                                                                  assertEquals("testValue", result);
                                                                                                                              }

    @Test
                                                                                                                              public void testGetValue_ReturnsEmptyStringWhenStoredValueIsEmpty() {
                                                                                                                                  // Arrange
                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                  try {
                                                                                                                                      Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                      addValueForProcessing.setAccessible(true);
                                                                                                                                      addValueForProcessing.invoke(option, "");
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Failed to set value through reflection: " + e.getMessage());
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Act
                                                                                                                                  String result = option.getValue("default");
                                                                                                                                  
                                                                                                                                  // Assert
                                                                                                                                  assertEquals("", result);
                                                                                                                              }

    @Test
                                                                                                                              public void testGetValue_WithMultipleValuesReturnsFirstValue() throws Exception {
                                                                                                                                  // Arrange
                                                                                                                                  Option option = new Option("o", "description");
                                                                                                                                  
                                                                                                                                  // Use reflection to access private addValueForProcessing method
                                                                                                                                  Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                  addValueMethod.setAccessible(true);
                                                                                                                                  addValueMethod.invoke(option, "value1");
                                                                                                                                  addValueMethod.invoke(option, "value2");
                                                                                                                                  
                                                                                                                                  // Act
                                                                                                                                  String result = option.getValue("default");
                                                                                                                                  
                                                                                                                                  // Assert
                                                                                                                                  assertEquals("value1", result);
                                                                                                                              }

    @Test
                                                                                                                              public void testGetValues_WhenNoValues_ReturnsNull() {
                                                                                                                                  // Given - no values added (default state)
                                                                                                                                  Option option = new Option("test", "description");
                                                                                                                                  
                                                                                                                                  // When
                                                                                                                                  String[] result = option.getValues();
                                                                                                                                  
                                                                                                                                  // Then
                                                                                                                                  assertNull(result);
                                                                                                                              }

    @Test
                                                                                                                              public void testGetValuesList_WhenNoValuesSet_ShouldReturnNull() {
                                                                                                                                  // Given - no values set (default state)
                                                                                                                                  Option option = new Option("test", "description");
                                                                                                                                  
                                                                                                                                  // When
                                                                                                                                  List<String> result = option.getValuesList();
                                                                                                                                  
                                                                                                                                  // Then
                                                                                                                                  assertNull(result);
                                                                                                                              }

    @Test
                                                                                                                          public void testClone_SuccessfulCloneWithValues() throws Exception {
                                                                                                                              // Setup original Option with values
                                                                                                                              Option original = new Option("t", "test", true, "description");
                                                                                                                              original.setRequired(true);
                                                                                                                              original.setOptionalArg(false);
                                                                                                                              original.setArgs(2);
                                                                                                                              original.setType(String.class);
                                                                                                                              original.setValueSeparator(',');
                                                                                                                              original.addValue("value1");
                                                                                                                              original.addValue("value2");
                                                                                                                              
                                                                                                                              // Perform clone
                                                                                                                              Option cloned = (Option) original.clone();
                                                                                                                              
                                                                                                                              // Verify basic properties
                                                                                                                              assertNotSame(original, cloned);
                                                                                                                              assertEquals(original.getOpt(), cloned.getOpt());
                                                                                                                              assertEquals(original.getLongOpt(), cloned.getLongOpt());
                                                                                                                              assertEquals(original.getDescription(), cloned.getDescription());
                                                                                                                              assertEquals(original.isRequired(), cloned.isRequired());
                                                                                                                              assertEquals(original.hasOptionalArg(), cloned.hasOptionalArg());
                                                                                                                              assertEquals(original.getArgs(), cloned.getArgs());
                                                                                                                              assertEquals(original.getType(), cloned.getType());
                                                                                                                              assertEquals(original.getValueSeparator(), cloned.getValueSeparator());
                                                                                                                              
                                                                                                                              // Verify values were deep copied
                                                                                                                              assertNotSame(original.getValuesList(), cloned.getValuesList());
                                                                                                                              assertEquals(original.getValuesList(), cloned.getValuesList());
                                                                                                                              
                                                                                                                              // Verify modifying original doesn't affect clone
                                                                                                                              original.addValue("newValue");
                                                                                                                              assertFalse(cloned.getValuesList().contains("newValue"));
                                                                                                                          }

    @Test
                                                                                                                          public void testClone_WithNullValues() throws Exception {
                                                                                                                              Option original = new Option("t", "test", true, "description");
                                                                                                                              Method setValuesList = Option.class.getDeclaredMethod("setValuesList", List.class);
                                                                                                                              setValuesList.setAccessible(true);
                                                                                                                              setValuesList.invoke(original, (List<?>) null);
                                                                                                                              
                                                                                                                              Option cloned = (Option) original.clone();
                                                                                                                              
                                                                                                                              assertNull(cloned.getValuesList());
                                                                                                                          }

    @Test
                                                                                                                          public void testClone_VerifyDeepCopyOfValues() throws Exception {
                                                                                                                              Option original = new Option("t", "test", true, "description");
                                                                                                                              original.addValue("value1");
                                                                                                                              original.addValue("value2");
                                                                                                                              
                                                                                                                              Option cloned = (Option) original.clone();
                                                                                                                              
                                                                                                                              // Modify the clone's values
                                                                                                                              cloned.getValuesList().add("value3");
                                                                                                                              
                                                                                                                              // Verify original wasn't affected
                                                                                                                              assertEquals(2, original.getValuesList().size());
                                                                                                                              assertFalse(original.getValuesList().contains("value3"));
                                                                                                                          }

    @Test
                                                                                                                          public void testClone_VerifyAllFieldsCopied() throws Exception {
                                                                                                                              Option original = new Option("t", "longTest", true, "description");
                                                                                                                              original.setRequired(true);
                                                                                                                              original.setOptionalArg(true);
                                                                                                                              original.setArgs(3);
                                                                                                                              original.setType(Integer.class);
                                                                                                                              original.setValueSeparator(';');
                                                                                                                              original.addValue("1");
                                                                                                                              original.addValue("2");
                                                                                                                              
                                                                                                                              Option cloned = (Option) original.clone();
                                                                                                                              
                                                                                                                              assertEquals(original.getOpt(), cloned.getOpt());
                                                                                                                              assertEquals(original.getLongOpt(), cloned.getLongOpt());
                                                                                                                              assertEquals(original.getDescription(), cloned.getDescription());
                                                                                                                              assertEquals(original.isRequired(), cloned.isRequired());
                                                                                                                              assertEquals(original.hasOptionalArg(), cloned.hasOptionalArg());
                                                                                                                              assertEquals(original.getArgs(), cloned.getArgs());
                                                                                                                              assertEquals(original.getType(), cloned.getType());
                                                                                                                              assertEquals(original.getValueSeparator(), cloned.getValueSeparator());
                                                                                                                              assertEquals(original.getValuesList(), cloned.getValuesList());
                                                                                                                          }

    @Test
                                                                                                                          public void testRequiresArg_WhenLimitedArgsAndAcceptsArgReturnsTrue_ReturnsTrue() throws Exception {
                                                                                                                              // Create test objects
                                                                                                                              Option option = new Option("test", "description");
                                                                                                                              option.setArgs(1);
                                                                                                                              
                                                                                                                              // Create mock values list
                                                                                                                              List<String> mockValues = mock(List.class);
                                                                                                                              when(mockValues.size()).thenReturn(0);
                                                                                                                              
                                                                                                                              // Use reflection to set private field 'values' in Option class
                                                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, mockValues);
                                                                                                                              
                                                                                                                              // Create spy and mock private method behavior
                                                                                                                              Option spyOption = spy(option);
                                                                                                                              
                                                                                                                              // Mock acceptsArg() using reflection since it's package-private
                                                                                                                              Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                                              acceptsArgMethod.setAccessible(true);
                                                                                                                              when(acceptsArgMethod.invoke(spyOption)).thenReturn(true);
                                                                                                                              
                                                                                                                              // Test requiresArg() using reflection
                                                                                                                              Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                                                              requiresArgMethod.setAccessible(true);
                                                                                                                              boolean result = (boolean) requiresArgMethod.invoke(spyOption);
                                                                                                                              
                                                                                                                              assertTrue(result);
                                                                                                                          }

    @Test
                                                                                                                          public void testRequiresArg_WhenNumberOfArgsIsUninitialized_ReturnsResultOfAcceptsArg() {
                                                                                                                              // Create option instance
                                                                                                                              Option option = new Option("test", "description");
                                                                                                                              
                                                                                                                              // Set args to UNINITIALIZED using reflection since it's package-private
                                                                                                                              try {
                                                                                                                                  Field argsField = Option.class.getDeclaredField("args");
                                                                                                                                  argsField.setAccessible(true);
                                                                                                                                  argsField.set(option, Option.UNINITIALIZED);
                                                                                                                              } catch (Exception e) {
                                                                                                                                  fail("Failed to set args field via reflection");
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Test when acceptsArg would return true
                                                                                                                              try {
                                                                                                                                  Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                                                  acceptsArgMethod.setAccessible(true);
                                                                                                                                  boolean resultWhenTrue = (boolean) acceptsArgMethod.invoke(option);
                                                                                                                                  
                                                                                                                                  Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                                                                  requiresArgMethod.setAccessible(true);
                                                                                                                                  boolean requiresArgResult = (boolean) requiresArgMethod.invoke(option);
                                                                                                                                  
                                                                                                                                  assertEquals(resultWhenTrue, requiresArgResult);
                                                                                                                              } catch (Exception e) {
                                                                                                                                  fail("Failed to invoke methods via reflection");
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Note: We can't directly mock the behavior of acceptsArg() since it's package-private
                                                                                                                              // and we're not using Mockito in this solution. Instead, we test the actual behavior.
                                                                                                                          }

    @Test
                                                                                                                      public void testGetOpt_ConsistencyWithGetKey() throws Exception {
                                                                                                                          String expectedOpt = "k";
                                                                                                                          Option option = new Option(expectedOpt, "key option");
                                                                                                                          
                                                                                                                          // Use reflection to access the private getKey() method
                                                                                                                          Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                                                          getKeyMethod.setAccessible(true);
                                                                                                                          String keyValue = (String) getKeyMethod.invoke(option);
                                                                                                                          
                                                                                                                          assertEquals("getOpt() should return same value as getKey()", 
                                                                                                                                      keyValue, option.getOpt());
                                                                                                                      }

    @Test
                                                                                                                      public void testGetType_WhenTypeNotSet_ShouldReturnNull() {
                                                                                                                          // Arrange - type is not set by default
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          // Act
                                                                                                                          Object result = option.getType();
                                                                                                                          
                                                                                                                          // Assert
                                                                                                                          assertNull("Type should be null when not set", result);
                                                                                                                      }

    @Test
                                                                                                                      public void testGetType_WhenTypeSet_ShouldReturnCorrectType() {
                                                                                                                          // Arrange
                                                                                                                          Option option = new Option("t", "test option");
                                                                                                                          Class<?> stringClass = String.class;
                                                                                                                          option.setType(stringClass);
                                                                                                                          
                                                                                                                          // Act
                                                                                                                          Object result = option.getType();
                                                                                                                          
                                                                                                                          // Assert
                                                                                                                          assertSame("Should return the set type", stringClass, result);
                                                                                                                      }

    @Test
                                                                                                                      public void testGetType_WithMockedClass_ShouldReturnMockedClass() {
                                                                                                                          // Arrange
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          Class<?> mockedClass = mock(Class.class);
                                                                                                                          option.setType(mockedClass);
                                                                                                                          
                                                                                                                          // Act
                                                                                                                          Object result = option.getType();
                                                                                                                          
                                                                                                                          // Assert
                                                                                                                          assertSame("Should return the mocked class", mockedClass, result);
                                                                                                                      }

    @Test
                                                                                                                      public void testGetType_AfterSettingToNull_ShouldReturnNull() {
                                                                                                                          // Arrange
                                                                                                                          Option option = new Option("test", "description"); // Initialize Option object
                                                                                                                          option.setType(String.class); // Set to non-null first
                                                                                                                          option.setType(null); // Then set to null
                                                                                                                          
                                                                                                                          // Act
                                                                                                                          Object result = option.getType(); // Changed from Class<?> to Object
                                                                                                                          
                                                                                                                          // Assert
                                                                                                                          assertNull("Type should be null after setting to null", result);
                                                                                                                      }

    @Test
                                                                                                                      public void testHasOptionalArg_AfterClearValues() throws Exception {
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.setOptionalArg(true);
                                                                                                                          
                                                                                                                          // Use reflection to access private clearValues() method
                                                                                                                          Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                          clearValuesMethod.setAccessible(true);
                                                                                                                          clearValuesMethod.invoke(option);
                                                                                                                          
                                                                                                                          // clearValues shouldn't affect optionalArg
                                                                                                                          assertTrue(option.hasOptionalArg());
                                                                                                                      }

    @Test
                                                                                                                      public void testIsRequired_AfterClearValues() throws Exception {
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.setRequired(true);
                                                                                                                          
                                                                                                                          // Use reflection to access the private clearValues() method
                                                                                                                          Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                          clearValuesMethod.setAccessible(true);
                                                                                                                          clearValuesMethod.invoke(option);
                                                                                                                          
                                                                                                                          // clearValues shouldn't affect the required flag
                                                                                                                          assertTrue(option.isRequired());
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValueSeparator_AfterClearValues() throws Exception {
                                                                                                                          // Create an Option instance
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          // Set a separator and verify
                                                                                                                          option.setValueSeparator('=');
                                                                                                                          assertEquals('=', option.getValueSeparator());
                                                                                                                          
                                                                                                                          // Use reflection to access clearValues()
                                                                                                                          Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                          clearValuesMethod.setAccessible(true);
                                                                                                                          clearValuesMethod.invoke(option);
                                                                                                                          
                                                                                                                          // Verify separator remains unchanged after clearing values
                                                                                                                          assertEquals('=', option.getValueSeparator());
                                                                                                                      }

    @Test
                                                                                                                      public void testHasValueSeparator_AfterClearValues_ShouldMaintainSeparator() throws Exception {
                                                                                                                          // Arrange
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.setValueSeparator(';');
                                                                                                                          
                                                                                                                          // Use reflection to access clearValues()
                                                                                                                          Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                          clearValuesMethod.setAccessible(true);
                                                                                                                          clearValuesMethod.invoke(option);
                                                                                                                          
                                                                                                                          // Act & Assert
                                                                                                                          assertTrue(option.hasValueSeparator());
                                                                                                                      }

    @Test
                                                                                                                      public void testAddValueForProcessing_WhenUninitialized_ShouldThrowException() throws Exception {
                                                                                                                          // Arrange
                                                                                                                          Option option = new Option("t", "test option");
                                                                                                                          // Set numberOfArgs to UNINITIALIZED through reflection since it's private
                                                                                                                          Field field = Option.class.getDeclaredField("numberOfArgs");
                                                                                                                          field.setAccessible(true);
                                                                                                                          field.set(option, -1); // UNINITIALIZED is typically -1 in Apache Commons CLI
                                                                                                                      
                                                                                                                          // Expect exception
                                                                                                                          ExpectedException exceptionRule = ExpectedException.none();
                                                                                                                          exceptionRule.expect(RuntimeException.class);
                                                                                                                          exceptionRule.expectMessage("NO_ARGS_ALLOWED");
                                                                                                                      
                                                                                                                          // Act - need to use reflection to call private method
                                                                                                                          Method method = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                          method.setAccessible(true);
                                                                                                                          method.invoke(option, "test");
                                                                                                                      }

    @Test
                                                                                                                      public void testAddValueForProcessing_WhenNumberOfArgsSet_ShouldProcessValue() throws Exception {
                                                                                                                          // Arrange
                                                                                                                          Option option = new Option("t", true, "test option");
                                                                                                                          String testValue = "testValue";
                                                                                                                          
                                                                                                                          // Use reflection to access private methods
                                                                                                                          Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                          addValueForProcessing.setAccessible(true);
                                                                                                                          
                                                                                                                          // Act
                                                                                                                          addValueForProcessing.invoke(option, testValue);
                                                                                                                          
                                                                                                                          // Assert - verify the value was processed by checking internal state
                                                                                                                          Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                          valuesField.setAccessible(true);
                                                                                                                          List<String> values = (List<String>) valuesField.get(option);
                                                                                                                          
                                                                                                                          assertFalse(values.isEmpty());
                                                                                                                          assertEquals(testValue, values.get(0));
                                                                                                                      }

    @Test
                                                                                                                      public void testAddValueForProcessing_WithNullValue_ShouldProcessValue() throws Exception {
                                                                                                                          // Arrange
                                                                                                                          Option option = new Option("t", true, "test option");
                                                                                                                          
                                                                                                                          // Get the private processValue method
                                                                                                                          Method processValueMethod = Option.class.getDeclaredMethod("processValue", String.class);
                                                                                                                          processValueMethod.setAccessible(true);
                                                                                                                          
                                                                                                                          // Get the package-private addValueForProcessing method
                                                                                                                          Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                          addValueMethod.setAccessible(true);
                                                                                                                          
                                                                                                                          // Act
                                                                                                                          addValueMethod.invoke(option, (String)null);
                                                                                                                          
                                                                                                                          // Assert - Verify the value was processed by checking internal state
                                                                                                                          // Since processValue is private, we can't verify it directly, but we can check its effect
                                                                                                                          // For example, if processValue adds to some internal collection, we can check that
                                                                                                                          // Here we assume processValue would affect the option's values
                                                                                                                          assertNull(option.getValue(0));  // Or whatever the expected behavior is
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValue_AfterClearingValues_ShouldReturnNull() {
                                                                                                                          // Given
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.addValue("value");
                                                                                                                          
                                                                                                                          try {
                                                                                                                              // Use reflection to access the private clearValues method
                                                                                                                              Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                              clearValuesMethod.setAccessible(true);
                                                                                                                              clearValuesMethod.invoke(option);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to clear values using reflection: " + e.getMessage());
                                                                                                                          }
                                                                                                                          
                                                                                                                          // When
                                                                                                                          String result = option.getValue();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertNull(result);
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValue_WhenValueAddedViaProcessing_ShouldReturnValue() throws Exception {
                                                                                                                          // Given
                                                                                                                          String expectedValue = "processedValue";
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          // Use reflection to access the private method
                                                                                                                          Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                          addValueForProcessing.setAccessible(true);
                                                                                                                          addValueForProcessing.invoke(option, expectedValue);
                                                                                                                          
                                                                                                                          // When
                                                                                                                          String result = option.getValue();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertEquals(expectedValue, result);
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValue_WhenNoValuesExist_ReturnsNull() {
                                                                                                                          // Setup - create Option with no values
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          // Execute and verify
                                                                                                                          assertNull(option.getValue(0));
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValue_WithIndexBeyondSize_ThrowsIndexOutOfBoundsException() {
                                                                                                                          // Setup
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          List<String> mockValues = mock(List.class);
                                                                                                                          
                                                                                                                          // Use reflection to set private values field since it's not directly accessible
                                                                                                                          try {
                                                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, mockValues);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to set up test due to reflection error");
                                                                                                                          }
                                                                                                                          
                                                                                                                          // Mock behavior
                                                                                                                          when(mockValues.isEmpty()).thenReturn(false);
                                                                                                                          when(mockValues.size()).thenReturn(2);
                                                                                                                          
                                                                                                                          // Execute and verify exception
                                                                                                                          try {
                                                                                                                              option.getValue(2); // valid indexes are 0 and 1
                                                                                                                              fail("Expected IndexOutOfBoundsException");
                                                                                                                          } catch (IndexOutOfBoundsException e) {
                                                                                                                              assertEquals("Index: 2, Size: 2", e.getMessage());
                                                                                                                          }
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValue_WithNonStringValue_ReturnsNull() {
                                                                                                                          // Setup
                                                                                                                          Option option = mock(Option.class);
                                                                                                                          List<String> mockValues = mock(List.class);
                                                                                                                          
                                                                                                                          // Mock the behavior
                                                                                                                          try {
                                                                                                                              // Mock hasNoValues() which is private in Option class
                                                                                                                              Method hasNoValuesMethod = Option.class.getDeclaredMethod("hasNoValues");
                                                                                                                              hasNoValuesMethod.setAccessible(true);
                                                                                                                              when(hasNoValuesMethod.invoke(option)).thenReturn(false);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to mock hasNoValues method via reflection");
                                                                                                                          }
                                                                                                                          
                                                                                                                          // Mock list behavior with proper type casting
                                                                                                                          when(mockValues.get(0)).thenReturn("123"); // Changed from Integer to String
                                                                                                                          
                                                                                                                          // Use reflection to set the private values field
                                                                                                                          try {
                                                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, mockValues);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to set values field via reflection");
                                                                                                                          }
                                                                                                                          
                                                                                                                          // Execute and verify
                                                                                                                          assertNull(option.getValue(0));
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValues_WithSingleValue_ReturnsCorrectArray() {
                                                                                                                          // Given
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.addValue("value1");
                                                                                                                          
                                                                                                                          // When
                                                                                                                          String[] result = option.getValues();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertNotNull(result);
                                                                                                                          assertEquals(1, result.length);
                                                                                                                          assertEquals("value1", result[0]);
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValues_WithMultipleValues_ReturnsCorrectArray() {
                                                                                                                          // Given
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          try {
                                                                                                                              // Use reflection to access the private addValueForProcessing method
                                                                                                                              Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                              addValueMethod.setAccessible(true);
                                                                                                                              addValueMethod.invoke(option, "value1");
                                                                                                                              addValueMethod.invoke(option, "value2");
                                                                                                                              addValueMethod.invoke(option, "value3");
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to add values via reflection: " + e.getMessage());
                                                                                                                          }
                                                                                                                          
                                                                                                                          // When
                                                                                                                          String[] result = option.getValues();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertNotNull(result);
                                                                                                                          assertEquals(3, result.length);
                                                                                                                          assertArrayEquals(new String[]{"value1", "value2", "value3"}, result);
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValues_WithNullValue_ReturnsArrayWithNull() {
                                                                                                                          // Given
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          try {
                                                                                                                              Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                              addValueForProcessing.setAccessible(true);
                                                                                                                              addValueForProcessing.invoke(option, (String) null);
                                                                                                                              addValueForProcessing.invoke(option, "value2");
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to invoke addValueForProcessing via reflection: " + e.getMessage());
                                                                                                                          }
                                                                                                                          
                                                                                                                          // When
                                                                                                                          String[] result = option.getValues();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertNotNull(result);
                                                                                                                          assertEquals(2, result.length);
                                                                                                                          assertNull(result[0]);
                                                                                                                          assertEquals("value2", result[1]);
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValues_AfterClearValues_ReturnsNull() {
                                                                                                                          // Given
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.addValue("value1");
                                                                                                                          option.addValue("value2");
                                                                                                                          
                                                                                                                          // Use reflection to clear values since clearValues() is package-private
                                                                                                                          try {
                                                                                                                              Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                              clearValuesMethod.setAccessible(true);
                                                                                                                              clearValuesMethod.invoke(option);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to clear values using reflection: " + e.getMessage());
                                                                                                                          }
                                                                                                                          
                                                                                                                          // When
                                                                                                                          String[] result = option.getValues();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertNull(result);
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValues_WithLargeNumberOfValues_ReturnsCorrectArray() {
                                                                                                                          // Given
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          try {
                                                                                                                              Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                              addValueMethod.setAccessible(true);
                                                                                                                              for (int i = 0; i < 1000; i++) {
                                                                                                                                  addValueMethod.invoke(option, "value" + i);
                                                                                                                              }
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to add values via reflection: " + e.getMessage());
                                                                                                                          }
                                                                                                                          
                                                                                                                          // When
                                                                                                                          String[] result = option.getValues();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertNotNull(result);
                                                                                                                          assertEquals(1000, result.length);
                                                                                                                          assertEquals("value0", result[0]);
                                                                                                                          assertEquals("value999", result[999]);
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValuesList_WhenEmptyValuesList_ShouldReturnEmptyList() throws Exception {
                                                                                                                          // Given
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          // Use reflection to call addValueForProcessing
                                                                                                                          Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                          addValueMethod.setAccessible(true);
                                                                                                                          addValueMethod.invoke(option, "");
                                                                                                                          
                                                                                                                          // Use reflection to call clearValues
                                                                                                                          Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                          clearValuesMethod.setAccessible(true);
                                                                                                                          clearValuesMethod.invoke(option);
                                                                                                                          
                                                                                                                          // When
                                                                                                                          List<String> result = option.getValuesList();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertNotNull(result);
                                                                                                                          assertTrue(result.isEmpty());
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValuesList_WhenSingleValueAdded_ShouldReturnListWithOneValue() throws Exception {
                                                                                                                          // Given
                                                                                                                          Option option = new Option("t", "test option");
                                                                                                                          String testValue = "testValue";
                                                                                                                          
                                                                                                                          // Use reflection to access the private method
                                                                                                                          Method addValueForProcessing = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                          addValueForProcessing.setAccessible(true);
                                                                                                                          addValueForProcessing.invoke(option, testValue);
                                                                                                                          
                                                                                                                          // When
                                                                                                                          List<String> result = option.getValuesList();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertNotNull(result);
                                                                                                                          assertEquals(1, result.size());
                                                                                                                          assertEquals(testValue, result.get(0));
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValuesList_AfterClearValues_ShouldReturnNull() {
                                                                                                                          // Given
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.addValue("value1");
                                                                                                                          option.addValue("value2");
                                                                                                                          
                                                                                                                          // Clear values using reflection since clearValues() is not public
                                                                                                                          try {
                                                                                                                              Method clearValues = Option.class.getDeclaredMethod("clearValues");
                                                                                                                              clearValues.setAccessible(true);
                                                                                                                              clearValues.invoke(option);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to clear values via reflection: " + e.getMessage());
                                                                                                                          }
                                                                                                                          
                                                                                                                          // When
                                                                                                                          List<String> result = option.getValuesList();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertNull(result);
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValuesList_WhenValuesContainNull_ShouldReturnListWithNull() {
                                                                                                                          // Given
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          try {
                                                                                                                              Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                              addValueMethod.setAccessible(true);
                                                                                                                              addValueMethod.invoke(option, (String) null);
                                                                                                                              addValueMethod.invoke(option, "validValue");
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to invoke addValueForProcessing method via reflection");
                                                                                                                          }
                                                                                                                          
                                                                                                                          // When
                                                                                                                          List<String> result = option.getValuesList();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertNotNull(result);
                                                                                                                          assertEquals(2, result.size());
                                                                                                                          assertNull(result.get(0));
                                                                                                                          assertEquals("validValue", result.get(1));
                                                                                                                      }

    @Test
                                                                                                                      public void testGetValuesList_ReturnsNewInstance_ShouldNotModifyInternalState() throws Exception {
                                                                                                                          // Given
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          // Use reflection to access private addValueForProcessing method
                                                                                                                          Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                          addValueMethod.setAccessible(true);
                                                                                                                          addValueMethod.invoke(option, "original");
                                                                                                                          
                                                                                                                          List<String> firstCall = option.getValuesList();
                                                                                                                          firstCall.add("modified");
                                                                                                                          
                                                                                                                          // When
                                                                                                                          List<String> secondCall = option.getValuesList();
                                                                                                                          
                                                                                                                          // Then
                                                                                                                          assertEquals(1, secondCall.size());
                                                                                                                          assertEquals("original", secondCall.get(0));
                                                                                                                      }

    @Test
                                                                                                                      public void testHasNoValues_WhenListIsEmpty() throws Exception {
                                                                                                                          // Create an option with no arguments
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          // Use reflection to access the private hasNoValues method
                                                                                                                          Method hasNoValuesMethod = Option.class.getDeclaredMethod("hasNoValues");
                                                                                                                          hasNoValuesMethod.setAccessible(true);
                                                                                                                          
                                                                                                                          // values list should be empty after initialization
                                                                                                                          assertTrue((Boolean) hasNoValuesMethod.invoke(option));
                                                                                                                      }

    @Test
                                                                                                                      public void testHasNoValues_WhenListHasOneValue() throws Exception {
                                                                                                                          // Create an option instance
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          // Add one value to the option
                                                                                                                          option.addValue("value1");
                                                                                                                          
                                                                                                                          // Use reflection to access the private hasNoValues method
                                                                                                                          Method hasNoValuesMethod = Option.class.getDeclaredMethod("hasNoValues");
                                                                                                                          hasNoValuesMethod.setAccessible(true);
                                                                                                                          boolean result = (boolean) hasNoValuesMethod.invoke(option);
                                                                                                                          
                                                                                                                          assertFalse(result);
                                                                                                                      }

    @Test
                                                                                                                      public void testHasNoValues_WhenListHasMultipleValues() throws Exception {
                                                                                                                          // Create an option instance
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          // Add multiple values to the option
                                                                                                                          option.addValue("value1");
                                                                                                                          option.addValue("value2");
                                                                                                                          option.addValue("value3");
                                                                                                                          
                                                                                                                          // Get the private hasNoValues method using reflection
                                                                                                                          Method hasNoValuesMethod = Option.class.getDeclaredMethod("hasNoValues");
                                                                                                                          hasNoValuesMethod.setAccessible(true);
                                                                                                                          
                                                                                                                          // Invoke the method and verify the option has values
                                                                                                                          boolean result = (boolean) hasNoValuesMethod.invoke(option);
                                                                                                                          assertFalse(result);
                                                                                                                      }

    @Test
                                                                                                                      public void testHasNoValues_AfterClearingValues() throws Exception {
                                                                                                                          // Create an Option object
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          // Add values then clear them
                                                                                                                          option.addValue("value1");
                                                                                                                          option.addValue("value2");
                                                                                                                          
                                                                                                                          // Use reflection to access clearValues()
                                                                                                                          Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                          clearValuesMethod.setAccessible(true);
                                                                                                                          clearValuesMethod.invoke(option);
                                                                                                                          
                                                                                                                          // Use reflection to access hasNoValues()
                                                                                                                          Method hasNoValuesMethod = Option.class.getDeclaredMethod("hasNoValues");
                                                                                                                          hasNoValuesMethod.setAccessible(true);
                                                                                                                          boolean result = (boolean) hasNoValuesMethod.invoke(option);
                                                                                                                          
                                                                                                                          assertTrue(result);
                                                                                                                      }

    @Test
                                                                                                                      public void testHasNoValues_WithValueSeparator() {
                                                                                                                          // Create an Option object for testing
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          
                                                                                                                          // Test with value separator (shouldn't affect empty check)
                                                                                                                          option.setValueSeparator(',');
                                                                                                                          assertTrue(option.getValuesList().isEmpty());
                                                                                                                          
                                                                                                                          option.addValue("value1");
                                                                                                                          assertFalse(option.getValuesList().isEmpty());
                                                                                                                      }

    @Test
                                                                                                                      public void testClearValues_WhenValuesListIsEmpty() {
                                                                                                                          // Setup
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          @SuppressWarnings("unchecked")
                                                                                                                          List<String> mockValues = mock(List.class);
                                                                                                                          
                                                                                                                          // Use reflection to set the private values field
                                                                                                                          try {
                                                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, mockValues);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                          }
                                                                                                                          
                                                                                                                          when(mockValues.isEmpty()).thenReturn(true);
                                                                                                                          
                                                                                                                          // Execute
                                                                                                                          try {
                                                                                                                              Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                              clearValuesMethod.setAccessible(true);
                                                                                                                              clearValuesMethod.invoke(option);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to invoke clearValues method: " + e.getMessage());
                                                                                                                          }
                                                                                                                          
                                                                                                                          // Verify
                                                                                                                          verify(mockValues).clear();
                                                                                                                          verify(mockValues, never()).isEmpty(); // isEmpty() shouldn't be called
                                                                                                                      }

    @Test
                                                                                                                      public void testClearValues_WhenValuesListHasElements() {
                                                                                                                          // Setup
                                                                                                                          Option option = new Option("test", "description");  // Create Option instance
                                                                                                                          List<String> realValues = new ArrayList<>();
                                                                                                                          realValues.add("value1");
                                                                                                                          realValues.add("value2");
                                                                                                                          
                                                                                                                          try {
                                                                                                                              // Set private values field
                                                                                                                              java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, realValues);
                                                                                                                              
                                                                                                                              // Pre-condition check
                                                                                                                              assertEquals(2, realValues.size());
                                                                                                                              
                                                                                                                              // Get and invoke private clearValues method
                                                                                                                              java.lang.reflect.Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                              clearValuesMethod.setAccessible(true);
                                                                                                                              clearValuesMethod.invoke(option);
                                                                                                                              
                                                                                                                              // Verify
                                                                                                                              assertTrue(realValues.isEmpty());
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to execute test due to reflection error: " + e.getMessage());
                                                                                                                          }
                                                                                                                      }

    @Test
                                                                                                                      public void testClearValues_WhenValuesListIsNull() {
                                                                                                                          // Setup
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          try {
                                                                                                                              // Set values field to null using reflection
                                                                                                                              java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, null);
                                                                                                                              
                                                                                                                              // Get clearValues method using reflection
                                                                                                                              java.lang.reflect.Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                              clearValuesMethod.setAccessible(true);
                                                                                                                              
                                                                                                                              // Execute
                                                                                                                              clearValuesMethod.invoke(option); // Should not throw exception
                                                                                                                              
                                                                                                                              // Verify - no exception thrown
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                          }
                                                                                                                      }

    @Test
                                                                                                                      public void testClearValues_VerifyInteractionWithList() {
                                                                                                                          // Setup
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          @SuppressWarnings("unchecked")
                                                                                                                          List<String> mockValues = mock(List.class);
                                                                                                                          
                                                                                                                          // Use reflection to set the private values field since it's not accessible directly
                                                                                                                          try {
                                                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, mockValues);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                          }
                                                                                                                          
                                                                                                                          // Execute
                                                                                                                          try {
                                                                                                                              Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                              clearValuesMethod.setAccessible(true);
                                                                                                                              clearValuesMethod.invoke(option);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to invoke clearValues method: " + e.getMessage());
                                                                                                                          }
                                                                                                                          
                                                                                                                          // Verify
                                                                                                                          verify(mockValues).clear();
                                                                                                                          verifyNoMoreInteractions(mockValues);
                                                                                                                      }

    @Test
                                                                                                                      public void testClearValues_AfterAddingValues() {
                                                                                                                          // Setup
                                                                                                                          Option option = new Option("test", "description");  // Initialize option with required parameters
                                                                                                                          List<String> realValues = new ArrayList<>();
                                                                                                                          realValues.add("test1");
                                                                                                                          realValues.add("test2");
                                                                                                                          
                                                                                                                          try {
                                                                                                                              // Set values field using reflection
                                                                                                                              java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, realValues);
                                                                                                                              
                                                                                                                              // Pre-condition check
                                                                                                                              assertEquals(2, option.getValuesList().size());
                                                                                                                              
                                                                                                                              // Execute clearValues using reflection
                                                                                                                              java.lang.reflect.Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                              clearValuesMethod.setAccessible(true);
                                                                                                                              clearValuesMethod.invoke(option);
                                                                                                                              
                                                                                                                              // Verify
                                                                                                                              assertTrue(option.getValuesList().isEmpty());
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to execute test due to reflection error: " + e.getMessage());
                                                                                                                          }
                                                                                                                      }

    @Test
                                                                                                                      public void testClearValues_MultipleCalls() {
                                                                                                                          // Setup
                                                                                                                          Option option = new Option("test", "description"); // Initialize Option object
                                                                                                                          List<String> realValues = new ArrayList<>();
                                                                                                                          realValues.add("value");
                                                                                                                          
                                                                                                                          try {
                                                                                                                              // Set up values field using reflection
                                                                                                                              java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, realValues);
                                                                                                                              
                                                                                                                              // Get clearValues method using reflection
                                                                                                                              java.lang.reflect.Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                                              clearValuesMethod.setAccessible(true);
                                                                                                                              
                                                                                                                              // First call
                                                                                                                              clearValuesMethod.invoke(option);
                                                                                                                              assertTrue(realValues.isEmpty());
                                                                                                                              
                                                                                                                              // Second call on already empty list
                                                                                                                              clearValuesMethod.invoke(option);
                                                                                                                              assertTrue(realValues.isEmpty());
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to execute test due to reflection error: " + e.getMessage());
                                                                                                                          }
                                                                                                                      }

    @Test
                                                                                                                      public void testAcceptsArg_NoArgOptions_ReturnsFalse() throws Exception {
                                                                                                                          // Setup
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.setArgs(0);
                                                                                                                          option.setOptionalArg(false);
                                                                                                                          
                                                                                                                          // Use reflection to access the private method
                                                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                                                          
                                                                                                                          // Test
                                                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                                                          assertFalse(result);
                                                                                                                      }

    @Test
                                                                                                                      public void testAcceptsArg_HasArgButNoValuesNeeded_ReturnsTrue() throws Exception {
                                                                                                                          // Setup: Option accepts arguments but doesn't require any
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          List<String> mockValues = mock(List.class);
                                                                                                                          
                                                                                                                          // Use reflection to set the private values field
                                                                                                                          try {
                                                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, mockValues);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to set values field via reflection");
                                                                                                                          }
                                                                                                                          
                                                                                                                          when(mockValues.size()).thenReturn(0);
                                                                                                                          option.setArgs(0);
                                                                                                                          option.setOptionalArg(true);
                                                                                                                      
                                                                                                                          // Use reflection to access the private acceptsArg method
                                                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                                                          
                                                                                                                          assertTrue(result);
                                                                                                                      }

    @Test
                                                                                                                      public void testAcceptsArg_HasArgWithValuesNotFilled_ReturnsTrue() {
                                                                                                                          // Setup
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          List<String> mockValues = mock(List.class);
                                                                                                                          
                                                                                                                          // Option requires 3 args but only has 2
                                                                                                                          when(mockValues.size()).thenReturn(2);
                                                                                                                          option.setArgs(3);
                                                                                                                          
                                                                                                                          // Use reflection to set the private values field
                                                                                                                          try {
                                                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, mockValues);
                                                                                                                              
                                                                                                                              // Use reflection to access the acceptsArg method
                                                                                                                              Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                                              acceptsArgMethod.setAccessible(true);
                                                                                                                              boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                                                              
                                                                                                                              assertTrue(result);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to access or invoke method via reflection: " + e.getMessage());
                                                                                                                          }
                                                                                                                      }

    @Test
                                                                                                                      public void testAcceptsArg_HasArgWithMoreValuesThanNeeded_ReturnsFalse() {
                                                                                                                          // Setup
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          List<String> mockValues = mock(List.class);
                                                                                                                          
                                                                                                                          // Option requires 1 arg but has 2
                                                                                                                          when(mockValues.size()).thenReturn(2);
                                                                                                                          option.setArgs(1);
                                                                                                                          
                                                                                                                          // Use reflection to set the private values field
                                                                                                                          try {
                                                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, mockValues);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to set values field via reflection");
                                                                                                                          }
                                                                                                                          
                                                                                                                          // Use reflection to access the private acceptsArg method
                                                                                                                          try {
                                                                                                                              Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                                              acceptsArgMethod.setAccessible(true);
                                                                                                                              boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                                                              assertFalse(result);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to invoke acceptsArg method via reflection");
                                                                                                                          }
                                                                                                                      }

    @Test
                                                                                                                      public void testAcceptsArg_OptionalArgWithValue_ReturnsFalse() {
                                                                                                                          // Setup: Option has optional arg and already has value
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          List<String> mockValues = mock(List.class);
                                                                                                                          
                                                                                                                          // Use reflection to set the private values field
                                                                                                                          try {
                                                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, mockValues);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to set values field via reflection");
                                                                                                                          }
                                                                                                                          
                                                                                                                          when(mockValues.size()).thenReturn(1);
                                                                                                                          option.setOptionalArg(true);
                                                                                                                          option.setArgs(1);
                                                                                                                          
                                                                                                                          // Use reflection to access the package-private acceptsArg() method
                                                                                                                          try {
                                                                                                                              Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                                              acceptsArgMethod.setAccessible(true);
                                                                                                                              boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                                                              assertFalse(result);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to invoke acceptsArg method via reflection");
                                                                                                                          }
                                                                                                                      }

    @Test
                                                                                                                      public void testAcceptsArg_HasArgsWithNegativeNumberOfArgs_ReturnsTrue() throws Exception {
                                                                                                                          // Setup: Option has args but numberOfArgs is negative
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.setArgs(-1);
                                                                                                                          
                                                                                                                          // Use reflection to access the package-private acceptsArg() method
                                                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                                                          
                                                                                                                          assertTrue(result);
                                                                                                                      }

    @Test
                                                                                                                      public void testRequiresArg_WhenOptionalArgIsTrue_ReturnsFalse() throws Exception {
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.setOptionalArg(true);
                                                                                                                          
                                                                                                                          // Use reflection to access the private requiresArg() method
                                                                                                                          Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                                                          requiresArgMethod.setAccessible(true);
                                                                                                                          boolean result = (boolean) requiresArgMethod.invoke(option);
                                                                                                                          
                                                                                                                          assertFalse(result);
                                                                                                                      }

    @Test
                                                                                                                      public void testRequiresArg_WhenUnlimitedValuesAndEmptyValues_ReturnsTrue() {
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                          
                                                                                                                          @SuppressWarnings("unchecked")
                                                                                                                          List<String> mockValues = mock(List.class);
                                                                                                                          when(mockValues.size()).thenReturn(0);
                                                                                                                          
                                                                                                                          // Set the values list in the option using reflection
                                                                                                                          try {
                                                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                              valuesField.setAccessible(true);
                                                                                                                              valuesField.set(option, mockValues);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to set values field via reflection");
                                                                                                                          }
                                                                                                                          
                                                                                                                          // Access requiresArg() method using reflection
                                                                                                                          try {
                                                                                                                              Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                                                              requiresArgMethod.setAccessible(true);
                                                                                                                              boolean result = (boolean) requiresArgMethod.invoke(option);
                                                                                                                              assertTrue(result);
                                                                                                                          } catch (Exception e) {
                                                                                                                              fail("Failed to invoke requiresArg method via reflection");
                                                                                                                          }
                                                                                                                      }

    @Test
                                                                                                                      public void testRequiresArg_WhenLimitedArgsAndAcceptsArgReturnsFalse_ReturnsFalse() throws Exception {
                                                                                                                          // Create test option
                                                                                                                          Option option = new Option("test", "description");
                                                                                                                          option.setArgs(1);
                                                                                                                          
                                                                                                                          // Get the Values class using reflection since it's likely package-private
                                                                                                                          Class<?> valuesClass = null;
                                                                                                                          for (Class<?> clazz : Option.class.getDeclaredClasses()) {
                                                                                                                              if (clazz.getSimpleName().equals("Values")) {
                                                                                                                                  valuesClass = clazz;
                                                                                                                                  break;
                                                                                                                              }
                                                                                                                          }
                                                                                                                          assertNotNull("Values class not found", valuesClass);
                                                                                                                          
                                                                                                                          // Create mock Values object
                                                                                                                          Object mockValues = mock(valuesClass);
                                                                                                                          Method sizeMethod = valuesClass.getDeclaredMethod("size");
                                                                                                                          when(sizeMethod.invoke(mockValues)).thenReturn(0);
                                                                                                                          
                                                                                                                          // Use reflection to set the values field since it's package-private
                                                                                                                          Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                          valuesField.setAccessible(true);
                                                                                                                          valuesField.set(option, mockValues);
                                                                                                                          
                                                                                                                          // Mock acceptsArg() behavior using reflection
                                                                                                                          Option spyOption = spy(option);
                                                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                                                          when(acceptsArgMethod.invoke(spyOption)).thenReturn(false);
                                                                                                                          
                                                                                                                          // Test requiresArg() using reflection
                                                                                                                          Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                                                          requiresArgMethod.setAccessible(true);
                                                                                                                          boolean result = (boolean) requiresArgMethod.invoke(spyOption);
                                                                                                                          
                                                                                                                          assertFalse(result);
                                                                                                                      }

    @Test
                                                                                                                  public void testRequiresArg_WhenValuesListIsNull_ThrowsNullPointerException() throws Exception {
                                                                                                                      // Initialize required objects
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      
                                                                                                                      // Set values to null using reflection
                                                                                                                      Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                      valuesField.setAccessible(true);
                                                                                                                      valuesField.set(option, null);
                                                                                                                      
                                                                                                                      option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                      
                                                                                                                      // Get the requiresArg method via reflection
                                                                                                                      Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                                                      requiresArgMethod.setAccessible(true);
                                                                                                                      
                                                                                                                      // Verify exception is thrown
                                                                                                                      ExpectedException exception = ExpectedException.none();
                                                                                                                      exception.expect(NullPointerException.class);
                                                                                                                      requiresArgMethod.invoke(option);
                                                                                                                  }

    @Test(expected = IndexOutOfBoundsException.class)
                                                                                                                  public void testGetValue_WithNegativeIndex_ThrowsIndexOutOfBoundsException() throws Exception {
                                                                                                                      // Setup
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      
                                                                                                                      // Use reflection to call private addValueForProcessing method
                                                                                                                      Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                      addValueMethod.setAccessible(true);
                                                                                                                      addValueMethod.invoke(option, "value1");
                                                                                                                      
                                                                                                                      // Execute - should throw IndexOutOfBoundsException
                                                                                                                      option.getValue(-1);
                                                                                                                  }

    @Test
                                                                                                                  public void testAcceptsArg_HasArgWithValuesFilled_ReturnsFalse() {
                                                                                                                      // Setup
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      option.setArgs(2);
                                                                                                                      
                                                                                                                      // Mock values list
                                                                                                                      @SuppressWarnings("unchecked")
                                                                                                                      List<String> mockValues = mock(List.class);
                                                                                                                      when(mockValues.size()).thenReturn(2);
                                                                                                                      
                                                                                                                      // Use reflection to set the private values field
                                                                                                                      try {
                                                                                                                          Field valuesField = Option.class.getDeclaredField("values");
                                                                                                                          valuesField.setAccessible(true);
                                                                                                                          valuesField.set(option, mockValues);
                                                                                                                      } catch (Exception e) {
                                                                                                                          fail("Failed to set values field via reflection");
                                                                                                                      }
                                                                                                                      
                                                                                                                      // Test
                                                                                                                      try {
                                                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                                                          assertFalse(result);
                                                                                                                      } catch (Exception e) {
                                                                                                                          fail("Failed to invoke acceptsArg method via reflection");
                                                                                                                      }
                                                                                                                  }

    @Test
                                                                                                          public void testRequiresArg_WhenUnlimitedValuesAndNonEmptyValues_ReturnsFalse() {
                                                                                                              // Create the option object
                                                                                                              Option option = new Option("test", "description");
                                                                                                              
                                                                                                              // Set up the test - unlimited args and add a value
                                                                                                              option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                              option.addValue("testValue");
                                                                                                              
                                                                                                              try {
                                                                                                                  // Use reflection to access the private requiresArg() method
                                                                                                                  Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                                                  requiresArgMethod.setAccessible(true);
                                                                                                                  
                                                                                                                  // Assert the expected result
                                                                                                                  assertFalse((boolean) requiresArgMethod.invoke(option));
                                                                                                              } catch (Exception e) {
                                                                                                                  fail("Failed to access private method via reflection");
                                                                                                              }
                                                                                                          }

    @Test
                                                                                                  public void testClone_WithEmptyValues() throws Exception {
                                                                                                      Option original = new Option("t", "test", true, "description");
                                                                                                      
                                                                                                      Option cloned = (Option) original.clone();
                                                                                                      
                                                                                                      assertNotNull(cloned.getValuesList());
                                                                                                      assertTrue(cloned.getValuesList().isEmpty());
                                                                                                  }

    @Test
                                                                                                  public void testAcceptsArg_HasArgWithUnlimitedValues_ReturnsTrue() {
                                                                                                      // Setup
                                                                                                      org.apache.commons.cli.Option option = new org.apache.commons.cli.Option("test", "description");
                                                                                                      
                                                                                                      // Option accepts unlimited arguments
                                                                                                      option.setArgs(org.apache.commons.cli.Option.UNLIMITED_VALUES);
                                                                                                      
                                                                                                      try {
                                                                                                          // Use reflection to access the private addValueForProcessing() method
                                                                                                          java.lang.reflect.Method addValueMethod = org.apache.commons.cli.Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                          addValueMethod.setAccessible(true);
                                                                                                          
                                                                                                          // Add some values to simulate having arguments
                                                                                                          addValueMethod.invoke(option, "value1");
                                                                                                          addValueMethod.invoke(option, "value2");
                                                                                                          addValueMethod.invoke(option, "value3");
                                                                                                          addValueMethod.invoke(option, "value4");
                                                                                                          addValueMethod.invoke(option, "value5");
                                                                                                          
                                                                                                          // Use reflection to access the private acceptsArg() method
                                                                                                          java.lang.reflect.Method acceptsArgMethod = org.apache.commons.cli.Option.class.getDeclaredMethod("acceptsArg");
                                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                                          
                                                                                                          org.junit.Assert.assertTrue(result);
                                                                                                      } catch (Exception e) {
                                                                                                          org.junit.Assert.fail("Failed to access private method via reflection: " + e.getMessage());
                                                                                                      }
                                                                                                  }

    @Test
                                                                                              public void testAcceptsArg_OptionalArgWithNoValues_ReturnsTrue() {
                                                                                                  // Setup: Option has optional arg and no values
                                                                                                  org.apache.commons.cli.Option option = new org.apache.commons.cli.Option("test", "description");
                                                                                                  try {
                                                                                                      java.lang.reflect.Field valuesField = org.apache.commons.cli.Option.class.getDeclaredField("values");
                                                                                                      valuesField.setAccessible(true);
                                                                                                      // Set values to empty list since we're testing no values case
                                                                                                      valuesField.set(option, new java.util.ArrayList<String>());
                                                                                                  } catch (Exception e) {
                                                                                                      org.junit.Assert.fail("Failed to set values field via reflection");
                                                                                                  }
                                                                                                  
                                                                                                  option.setOptionalArg(true);
                                                                                                  option.setArgs(1);
                                                                                                  
                                                                                                  // Use reflection to access private acceptsArg() method
                                                                                                  try {
                                                                                                      java.lang.reflect.Method acceptsArgMethod = org.apache.commons.cli.Option.class.getDeclaredMethod("acceptsArg");
                                                                                                      acceptsArgMethod.setAccessible(true);
                                                                                                      boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                                      org.junit.Assert.assertTrue(result);
                                                                                                  } catch (Exception e) {
                                                                                                      org.junit.Assert.fail("Failed to invoke acceptsArg method via reflection");
                                                                                                  }
                                                                                              }

    @Test
                                                                                              public void testAcceptsArg_UninitializedNumberOfArgs_ReturnsTrue() {
                                                                                                  // Setup: Option has args but numberOfArgs is UNINITIALIZED
                                                                                                  Option option = new Option("test", "description");
                                                                                                  
                                                                                                  // Use reflection to set the private numberOfArgs field to UNINITIALIZED
                                                                                                  try {
                                                                                                      Field argsField = Option.class.getDeclaredField("numberOfArgs");
                                                                                                      argsField.setAccessible(true);
                                                                                                      argsField.setInt(option, Option.UNINITIALIZED);
                                                                                                  } catch (Exception e) {
                                                                                                      org.junit.Assert.fail("Failed to set numberOfArgs field via reflection");
                                                                                                  }
                                                                                                  
                                                                                                  // Use reflection to call the private acceptsArg() method
                                                                                                  try {
                                                                                                      Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                      acceptsArgMethod.setAccessible(true);
                                                                                                      org.junit.Assert.assertTrue((boolean) acceptsArgMethod.invoke(option));
                                                                                                  } catch (Exception e) {
                                                                                                      org.junit.Assert.fail("Failed to invoke acceptsArg method via reflection");
                                                                                                  }
                                                                                              }

    @Test
                                                                                          public void testGetValuesList_WhenMultipleValuesAdded_ShouldReturnAllValues() throws Exception {
                                                                                              // Given
                                                                                              Option option = new Option("test", "description");
                                                                                              java.util.List<String> expectedValues = java.util.Arrays.asList("value1", "value2", "value3");
                                                                                              
                                                                                              // Use reflection to access the private addValueForProcessing method
                                                                                              java.lang.reflect.Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                              addValueMethod.setAccessible(true);
                                                                                              
                                                                                              for (String value : expectedValues) {
                                                                                                  addValueMethod.invoke(option, value);
                                                                                              }
                                                                                              
                                                                                              // When
                                                                                              java.util.List<String> result = option.getValuesList();
                                                                                              
                                                                                              // Then
                                                                                              assertNotNull(result);
                                                                                              assertEquals(expectedValues.size(), result.size());
                                                                                              assertTrue(result.containsAll(expectedValues));
                                                                                          }

    @Test
                                                                                          public void testConstructorWithInvalidOptShouldThrowException() {
                                                                                              // The test will fail if the exception isn't thrown,
                                                                                              // and will also fail if the method signature declares the exception
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              
                                                                                              // Test with invalid option string that should trigger exception
                                                                                              new Option(null, "description");
                                                                                              
                                                                                              // Note: We don't need to assert anything else because:
                                                                                              // 1. If exception is thrown, test passes (original behavior)
                                                                                              // 2. If exception isn't thrown, test fails
                                                                                              // 3. If method signature declares the exception, compilation would fail
                                                                                              //    but since we're testing against the mutated version, this test
                                                                                              //    will compile and run, catching the mutation
                                                                                          }

    @Test
                                                                                          public void testConstructorWithEmptyOptShouldThrowException() {
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              new Option("", "description");
                                                                                          }

    @Test
                                                                                          public void testConstructorWithInvalidSingleCharOptShouldThrowException() {
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              new Option("?", "description"); // Assuming '?' is invalid option character
                                                                                          }

    @Test
                                                                                          public void testConstructorWithInvalidOptShouldThrowIllegalArgumentException() {
                                                                                              // The original method declares it throws IllegalArgumentException,
                                                                                              // while the mutant removes this declaration but might still throw it
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              
                                                                                              // Test with invalid option string that should trigger the exception
                                                                                              // For example, null or empty string might be invalid
                                                                                              new Option(null, "description");
                                                                                          }

    @Test
                                                                                          public void testConstructorWithEmptyOptShouldThrowIllegalArgumentException() {
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              new Option("", "description");
                                                                                          }

    @Test
                                                                                          public void testConstructorWithInvalidFormatOptShouldThrowIllegalArgumentException() {
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              // Assuming options can't contain spaces or special characters
                                                                                              new Option("invalid option", "description");
                                                                                          }

    @Test
                                                                                          public void testConstructorShouldDeclareIllegalArgumentException() throws Exception {
                                                                                              // Get the constructor method
                                                                                              Class<Option> optionClass = Option.class;
                                                                                              Method constructor = optionClass.getMethod("Option", String.class, String.class);
                                                                                              
                                                                                              // Verify the method declares IllegalArgumentException
                                                                                              Class<?>[] exceptionTypes = constructor.getExceptionTypes();
                                                                                              boolean declaresException = false;
                                                                                              for (Class<?> exType : exceptionTypes) {
                                                                                                  if (exType.equals(IllegalArgumentException.class)) {
                                                                                                      declaresException = true;
                                                                                                      break;
                                                                                                  }
                                                                                              }
                                                                                              
                                                                                              assertTrue("Constructor should declare IllegalArgumentException", declaresException);
                                                                                          }

    @Test(expected = IllegalArgumentException.class)
                                                                                          public void testConstructorThrowsOnInvalidOption() {
                                                                                              // This test ensures the behavior still exists, 
                                                                                              // while the above test checks the declaration
                                                                                              new Option("@invalid", "description");
                                                                                          }

    @Test
                                                                                         public void testConstructorWithNullOptThrowsIllegalArgumentException() {
                                                                                             // Expect IllegalArgumentException when opt is null
                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                             thrown.expectMessage("opt");
                                                                                             new Option(null, "description");
                                                                                         }

    @Test
                                                                                         public void testConstructorWithEmptyOptThrowsIllegalArgumentException() {
                                                                                             // Expect IllegalArgumentException when opt is empty
                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                             thrown.expectMessage("opt");
                                                                                             new Option("", "description");
                                                                                         }

    @Test
                                                                                         public void testConstructorWithInvalidSingleCharOptThrowsIllegalArgumentException() {
                                                                                             // Expect IllegalArgumentException when opt has invalid character
                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                             thrown.expectMessage("opt");
                                                                                             new Option("?", "description");
                                                                                         }

    @Test(expected = IllegalArgumentException.class)
                                                                                         public void testConstructorWithInvalidOptShouldThrowIllegalArgumentException1() {
                                                                                             // Test with invalid option name that should trigger exception
                                                                                             // Empty string is typically invalid for command line options
                                                                                             new Option("", "description");
                                                                                             
                                                                                             // If we reach here, no exception was thrown - test fails
                                                                                             fail("Expected IllegalArgumentException for empty option name");
                                                                                         }

    @Test(expected = IllegalArgumentException.class)
                                                                                         public void testConstructorWithNullOptShouldThrowIllegalArgumentException() {
                                                                                             // Test with null option name which should be invalid
                                                                                             new Option(null, "description");
                                                                                             
                                                                                             // If we reach here, no exception was thrown - test fails
                                                                                             fail("Expected IllegalArgumentException for null option name");
                                                                                         }

    @Test(expected = IllegalArgumentException.class)
                                                                                         public void testConstructorWithInvalidSingleCharOptShouldThrowIllegalArgumentException() {
                                                                                             // Test with invalid single character (e.g., '?')
                                                                                             new Option("?", "description");
                                                                                             
                                                                                             // If we reach here, no exception was thrown - test fails
                                                                                             fail("Expected IllegalArgumentException for invalid option character");
                                                                                         }

    @Test(expected = IllegalArgumentException.class)
                                                                                         public void testConstructorWithInvalidOptionShouldThrowIllegalArgumentException() {
                                                                                             // This test will fail if the method throws RuntimeException instead
                                                                                             new Option(null, "description");
                                                                                         }

    @Test(expected = IllegalArgumentException.class)
                                                                                         public void testConstructorWithEmptyOptionShouldThrowIllegalArgumentException() {
                                                                                             // Empty string is invalid for an option
                                                                                             new Option("", "description");
                                                                                         }

    @Test(expected = IllegalArgumentException.class)
                                                                                         public void testConstructorWithInvalidOptionCharacterShouldThrowIllegalArgumentException() {
                                                                                             // Option containing invalid character
                                                                                             new Option("?", "description");
                                                                                         }

    @Test
                                                                                        public void testConstructorWithInvalidOptShouldThrowIllegalArgumentException2() {
                                                                                            // Arrange
                                                                                            String invalidOpt = null; // null opt should trigger exception
                                                                                            String description = "test description";
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("opt is null");
                                                                                            
                                                                                            // Act - this should throw IllegalArgumentException
                                                                                            new Option(invalidOpt, description);
                                                                                        }

    @Test
                                                                                        public void testConstructorWithValidParameters() {
                                                                                            // Test normal case - should work without exception
                                                                                            Option option = new Option("h", "help");
                                                                                            assertEquals("h", option.getOpt());
                                                                                            assertEquals("help", option.getDescription());
                                                                                        }

    @Test
                                                                                        public void testConstructorWithNullOptionShouldThrowException() {
                                                                                            // Test case that should throw IllegalArgumentException
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("opt is null");
                                                                                            
                                                                                            // This should throw IllegalArgumentException even though it's not declared
                                                                                            new Option(null, "description");
                                                                                        }

    @Test
                                                                                        public void testConstructorWithEmptyOptionShouldThrowException() {
                                                                                            // Another test case that should throw IllegalArgumentException
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("opt is empty");
                                                                                            
                                                                                            // This should throw IllegalArgumentException even though it's not declared
                                                                                            new Option("", "description");
                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                        public void testConstructorWithInvalidOptionShouldThrowException() {
                                                                                            // This test will detect the mutant because:
                                                                                            // 1. Original version explicitly declares it throws IllegalArgumentException
                                                                                            // 2. Mutated version doesn't declare it but should still throw
                                                                                            // 3. If mutant survives (doesn't throw), test will fail
                                                                                            
                                                                                            // Invalid option - empty string should fail validation
                                                                                            new Option("", "description");
                                                                                            
                                                                                            // If we get here, no exception was thrown and test fails
                                                                                        }

    @Test
                                                                                        public void testConstructorWithValidOptionShouldNotThrowException() {
                                                                                            // Valid option test for completeness
                                                                                            try {
                                                                                                Option option = new Option("v", "verbose");
                                                                                                assertNotNull(option);
                                                                                                assertEquals("v", option.getOpt());
                                                                                                assertEquals("verbose", option.getDescription());
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                fail("Valid option should not throw exception");
                                                                                            }
                                                                                        }

    @Test
                                                                                   public void testConstructorWithOptNullFalseDescription() {
                                                                                       // Arrange
                                                                                       String testOpt = "testOpt";
                                                                                       String testDescription = "test description";
                                                                                       
                                                                                       // Act
                                                                                       Option option = new Option(testOpt, null, false, testDescription);
                                                                                       
                                                                                       // Assert
                                                                                       assertEquals("opt field should match constructor parameter", 
                                                                                                    testOpt, option.getOpt());
                                                                                       assertNull("longOpt should be null as passed to constructor", 
                                                                                                  option.getLongOpt());
                                                                                       assertFalse("required should be false as passed to constructor", 
                                                                                                   option.isRequired());
                                                                                       assertEquals("description field should match constructor parameter", 
                                                                                                    testDescription, option.getDescription());
                                                                                       
                                                                                       // Additional checks for default values
                                                                                       assertEquals("numberOfArgs should default to UNINITIALIZED",
                                                                                                   Option.UNINITIALIZED, option.getArgs());
                                                                                       assertFalse("optionalArg should default to false",
                                                                                                   option.hasOptionalArg());
                                                                                       assertNull("type should default to null",
                                                                                                  option.getType());
                                                                                   }

    @Test
                                                                                       public void testConstructorWithThreeParameters() {
                                                                                           // Arrange
                                                                                           String expectedOpt = "t";
                                                                                           boolean expectedHasArg = true;
                                                                                           String expectedDescription = "test option";
                                                                                           
                                                                                           // Act
                                                                                           Option option = new Option(expectedOpt, expectedHasArg, expectedDescription);
                                                                                           
                                                                                           // Assert
                                                                                           assertEquals("opt should match constructor parameter", 
                                                                                                       expectedOpt, option.getOpt());
                                                                                           assertEquals("hasArg should match constructor parameter", 
                                                                                                       expectedHasArg, option.hasArg());
                                                                                           assertEquals("description should match constructor parameter", 
                                                                                                       expectedDescription, option.getDescription());
                                                                                           assertNull("longOpt should be null", option.getLongOpt());
                                                                                           
                                                                                           // Additional verification to catch potential mutant where parameters are not properly used
                                                                                           assertFalse("Optional arg should default to false", 
                                                                                                      option.hasOptionalArg());
                                                                                           assertEquals("Number of args should default to 1 when hasArg is true", 
                                                                                                      1, option.getArgs());
                                                                                       }

    @Test
                                                                                   public void testConstructorInitializesFieldsCorrectly() {
                                                                                       // Arrange
                                                                                       String opt = "t";
                                                                                       String longOpt = "test";
                                                                                       boolean hasArg = true;
                                                                                       String description = "test option";
                                                                                       
                                                                                       // Act
                                                                                       Option option = new Option(opt, longOpt, hasArg, description);
                                                                                       
                                                                                       // Assert
                                                                                       assertEquals("opt field not set correctly", opt, option.getOpt());
                                                                                       assertEquals("longOpt field not set correctly", longOpt, option.getLongOpt());
                                                                                       assertEquals("numberOfArgs not set correctly when hasArg is true", 
                                                                                                    1, option.getArgs());
                                                                                       assertEquals("description field not set correctly", 
                                                                                                    description, option.getDescription());
                                                                                       assertFalse("required should default to false", option.isRequired());
                                                                                       assertFalse("optionalArg should default to false", option.hasOptionalArg());
                                                                                       assertEquals("type should default to null", null, option.getType());
                                                                                       assertEquals("valuesep should default to 0", 0, option.getValueSeparator());
                                                                                   }

    @Test
                                                                                  public void testConstructorInitialization() {
                                                                                      // Arrange
                                                                                      String testOpt = "t";
                                                                                      String testDescription = "test description";
                                                                                      
                                                                                      // Act
                                                                                      Option option = new Option(testOpt, null, false, testDescription);
                                                                                      
                                                                                      // Assert
                                                                                      assertEquals("opt should be set to provided value", testOpt, option.getOpt());
                                                                                      assertNull("longOpt should be null", option.getLongOpt());
                                                                                      assertFalse("required should be false", option.isRequired());
                                                                                      assertEquals("description should be set to provided value", testDescription, option.getDescription());
                                                                                      
                                                                                      // Verify default values
                                                                                      assertNull("argName should be null by default", option.getArgName());
                                                                                      assertFalse("optionalArg should be false by default", option.hasOptionalArg());
                                                                                      assertEquals("numberOfArgs should be default (UNINITIALIZED)", Option.UNINITIALIZED, option.getArgs());
                                                                                      assertNull("type should be null by default", option.getType());
                                                                                      assertTrue("values should be empty by default", option.getValuesList().isEmpty());
                                                                                      assertEquals("valuesep should be default (0)", (char) 0, option.getValueSeparator());
                                                                                  }

    @Test
                                                                                  public void testConstructorWithOptHasArgDescription() {
                                                                                      // Arrange
                                                                                      String testOpt = "t";
                                                                                      boolean testHasArg = true;
                                                                                      String testDescription = "test option";
                                                                                      
                                                                                      // Act
                                                                                      Option option = new Option(testOpt, testHasArg, testDescription);
                                                                                      
                                                                                      // Assert
                                                                                      assertEquals("opt should match constructor parameter", testOpt, option.getOpt());
                                                                                      assertTrue("hasArg should match constructor parameter", option.hasArg());
                                                                                      assertEquals("description should match constructor parameter", 
                                                                                                   testDescription, option.getDescription());
                                                                                      assertNull("longOpt should be null", option.getLongOpt());
                                                                                      assertFalse("required should default to false", option.isRequired());
                                                                                      assertEquals("numberOfArgs should default to UNINITIALIZED", 
                                                                                                   Option.UNINITIALIZED, option.getArgs());
                                                                                      assertNull("type should default to null", option.getType());
                                                                                  }

    @Test
                                                                                      public void testConstructorSetsFieldsCorrectly() {
                                                                                          // Test with hasArg = true
                                                                                          String opt = "t";
                                                                                          String longOpt = "test";
                                                                                          String description = "Test option";
                                                                                          boolean hasArg = true;
                                                                                          
                                                                                          Option option = new Option(opt, longOpt, hasArg, description);
                                                                                          
                                                                                          // Verify all fields are set correctly
                                                                                          assertEquals("opt field not set correctly", opt, option.getOpt());
                                                                                          assertEquals("longOpt field not set correctly", longOpt, option.getLongOpt());
                                                                                          assertEquals("description field not set correctly", description, option.getDescription());
                                                                                          assertEquals("numberOfArgs not set to 1 when hasArg is true", 1, option.getArgs());
                                                                                          
                                                                                          // Test with hasArg = false
                                                                                          hasArg = false;
                                                                                          option = new Option(opt, longOpt, hasArg, description);
                                                                                          assertEquals("numberOfArgs should be uninitialized when hasArg is false", 
                                                                                                       Option.UNINITIALIZED, option.getArgs());
                                                                                          
                                                                                          // Verify documentation through reflection if possible
                                                                                          try {
                                                                                              // This would verify the documentation hasn't changed
                                                                                              Class<?> optionClass = Option.class;
                                                                                              java.lang.reflect.Constructor<?> constructor = optionClass.getConstructor(
                                                                                                  String.class, String.class, boolean.class, String.class);
                                                                                              
                                                                                              // While we can't directly test the javadoc, we can verify the parameter names
                                                                                              // which should match the documentation style
                                                                                              java.lang.reflect.Parameter[] parameters = constructor.getParameters();
                                                                                              assertEquals("First parameter name should match documentation style", 
                                                                                                           "opt", parameters[0].getName());
                                                                                          } catch (Exception e) {
                                                                                              fail("Reflection test failed: " + e.getMessage());
                                                                                          }
                                                                                      }

    @Test
                                                                                     public void testConstructorFieldAssignments() {
                                                                                         // Setup
                                                                                         String opt = "testOpt";
                                                                                         String description = "test description";
                                                                                         
                                                                                         // Exercise
                                                                                         Option option = new Option(opt, null, false, description);
                                                                                         
                                                                                         // Verify
                                                                                         assertEquals("opt should be set correctly", opt, option.getOpt());
                                                                                         assertNull("longOpt should be null", option.getLongOpt());
                                                                                         assertFalse("required should be false", option.isRequired());
                                                                                         assertEquals("description should be set correctly", description, option.getDescription());
                                                                                         
                                                                                         // Additional checks to catch the mutant
                                                                                         assertNotEquals("longOpt should not be false (mutant check)", 
                                                                                                        Boolean.FALSE.toString(), option.getLongOpt());
                                                                                     }

    @Test
                                                                                     public void testConstructorWithOptHasArgDescription1() {
                                                                                         // Arrange
                                                                                         String expectedOpt = "testOpt";
                                                                                         boolean expectedHasArg = true;
                                                                                         String expectedDescription = "test description";
                                                                                         
                                                                                         // Act
                                                                                         Option option = new Option(expectedOpt, expectedHasArg, expectedDescription);
                                                                                         
                                                                                         // Assert
                                                                                         assertEquals("Option value should not be concatenated with null", 
                                                                                             expectedOpt, option.getOpt());
                                                                                         assertEquals("hasArg should match input", 
                                                                                             expectedHasArg, option.hasArg());
                                                                                         assertEquals("description should match input", 
                                                                                             expectedDescription, option.getDescription());
                                                                                         assertNull("longOpt should be null", option.getLongOpt());
                                                                                     }

    @Test
                                                                                 public void testConstructorSetsNumberOfArgsTo1WhenHasArgIsTrue() {
                                                                                     // Arrange
                                                                                     String opt = "t";
                                                                                     String longOpt = "test";
                                                                                     String description = "test option";
                                                                                     boolean hasArg = true;
                                                                                     
                                                                                     // Act
                                                                                     Option option = new Option(opt, longOpt, hasArg, description);
                                                                                     
                                                                                     // Assert
                                                                                     assertEquals("When hasArg is true, numberOfArgs should be set to exactly 1", 
                                                                                                 1, option.getArgs());
                                                                                     
                                                                                     // Additional check to ensure it's not just incrementing
                                                                                     Option option2 = new Option(opt, longOpt, hasArg, description);
                                                                                     assertEquals("Subsequent creations with hasArg should still result in 1", 
                                                                                                 1, option2.getArgs());
                                                                                 }

    @Test
                                                                                    public void testConstructorInitialization1() {
                                                                                        // Setup test data
                                                                                        String testOpt = "t";
                                                                                        String testDescription = "test option";
                                                                                        
                                                                                        // Create option instance
                                                                                        Option option = new Option(testOpt, null, false, testDescription);
                                                                                        
                                                                                        // Verify all fields are properly initialized
                                                                                        assertEquals("Short option not set correctly", testOpt, option.getOpt());
                                                                                        assertNull("Long option should be null", option.getLongOpt());
                                                                                        assertFalse("Required flag should be false", option.isRequired());
                                                                                        assertEquals("Description not set correctly", 
                                                                                                    testDescription, option.getDescription());
                                                                                        assertEquals("Number of args should be UNINITIALIZED", 
                                                                                                    Option.UNINITIALIZED, option.getArgs());
                                                                                        assertNull("Type should be null by default", option.getType());
                                                                                    }

    @Test
                                                                                    public void testConstructorWithValidParameters1() {
                                                                                        // Arrange
                                                                                        String opt = "t";
                                                                                        boolean hasArg = true;
                                                                                        String description = "test option";
                                                                                        
                                                                                        // Act & Assert
                                                                                        try {
                                                                                            Option option = new Option(opt, null, hasArg, description);
                                                                                            
                                                                                            // Verify all fields were set correctly
                                                                                            assertEquals(opt, option.getOpt());
                                                                                            assertNull(option.getLongOpt());
                                                                                            assertEquals(hasArg, option.hasArg());
                                                                                            assertEquals(description, option.getDescription());
                                                                                        } catch (Exception e) {
                                                                                            fail("Constructor threw unexpected exception: " + e.getMessage());
                                                                                        }
                                                                                    }

    @Test(expected = Exception.class)
                                                                                    public void testMutatedConstructorShouldFail() {
                                                                                        // This test would only pass if the mutant exists
                                                                                        // In the mutated version, this would throw an exception
                                                                                        // due to invalid division operation
                                                                                        
                                                                                        String opt = "t";
                                                                                        boolean hasArg = true;
                                                                                        String description = "test option";
                                                                                        
                                                                                        // This line would fail to compile or throw an exception in mutated version
                                                                                        Option option = new Option(opt, null, hasArg, description);
                                                                                    }

    @Test
                                                                                    public void testValidateOptionWithArithmeticMutation() {
                                                                                        // Test case designed to catch arithmetic operation mutations in validation
                                                                                        // This would fail if multiplication was mutated to division in validation
                                                                                        
                                                                                        // Setup
                                                                                        String opt = "a";  // Simple valid option
                                                                                        String longOpt = "alpha";
                                                                                        boolean hasArg = true;
                                                                                        String description = "test option";
                                                                                        
                                                                                        // Test the constructor which calls validateOption
                                                                                        Option option = new Option(opt, longOpt, hasArg, description);
                                                                                        
                                                                                        // Verify the option was properly initialized
                                                                                        assertEquals(opt, option.getOpt());
                                                                                        assertEquals(longOpt, option.getLongOpt());
                                                                                        assertEquals(1, option.getArgs());  // Should be 1 since hasArg is true
                                                                                        assertEquals(description, option.getDescription());
                                                                                        
                                                                                        // Additional test with numeric option that would expose arithmetic mutation
                                                                                        String numericOpt = "2";  // Could be involved in arithmetic during validation
                                                                                        Option numericOption = new Option(numericOpt, "numeric", true, "numeric option");
                                                                                        assertEquals(numericOpt, numericOption.getOpt());
                                                                                    }

    @Test
                                                                                   public void testConstructorWithShortOption() {
                                                                                       // Arrange
                                                                                       String shortOpt = "a";
                                                                                       String description = "Test option";
                                                                                       
                                                                                       // Act
                                                                                       Option option = new Option(shortOpt, null, false, description);
                                                                                       
                                                                                       // Assert
                                                                                       assertEquals("Short option should match input", shortOpt, option.getOpt());
                                                                                       assertNull("Long option should be null", option.getLongOpt());
                                                                                       assertFalse("Required should be false", option.isRequired());
                                                                                       assertEquals("Description should match input", description, option.getDescription());
                                                                                       
                                                                                       // Additional verification to ensure opt is treated as short option
                                                                                       assertTrue("Should have short option", option.getOpt() != null && option.getOpt().length() == 1);
                                                                                   }

    @Test
                                                                                   public void testConstructorWithOptParameterAsShortOption() {
                                                                                       // Arrange
                                                                                       String shortOpt = "f";
                                                                                       boolean hasArg = true;
                                                                                       String description = "file option";
                                                                                       
                                                                                       // Act
                                                                                       Option option = new Option(shortOpt, null, hasArg, description);
                                                                                       
                                                                                       // Assert
                                                                                       // Verify opt is treated as short option
                                                                                       assertEquals("Short option should match input", shortOpt, option.getOpt());
                                                                                       assertNull("Long option should be null", option.getLongOpt());
                                                                                       assertTrue("Should have argument", option.hasArg());
                                                                                       assertEquals("Description should match", description, option.getDescription());
                                                                                       
                                                                                       // Additional verification that opt is not being treated as long option
                                                                                       assertFalse("Should not have long option", option.hasLongOpt());
                                                                                   }

    @Test
                                                                              public void testConstructorValidatesShortOptionFormat() {
                                                                                  // Create test parameters
                                                                                  String shortOpt = "f";  // Valid short option
                                                                                  String longOpt = "file";
                                                                                  boolean hasArg = true;
                                                                                  String description = "test option";
                                                                                  
                                                                                  // Create the option - validation happens in constructor
                                                                                  Option option = new Option(shortOpt, longOpt, hasArg, description);
                                                                                  
                                                                                  // Verify the opt field was set to a short option
                                                                                  assertEquals(shortOpt, option.getOpt());
                                                                                  
                                                                                  // Additional checks for correct initialization
                                                                                  assertEquals(longOpt, option.getLongOpt());
                                                                                  assertEquals(1, option.getArgs());  // Because hasArg is true
                                                                                  assertEquals(description, option.getDescription());
                                                                                  
                                                                                  // Test that invalid short option format throws exception
                                                                                  try {
                                                                                      new Option("invalid", longOpt, hasArg, description);
                                                                                      fail("Expected IllegalArgumentException for invalid short option format");
                                                                                  } catch (IllegalArgumentException e) {
                                                                                      // Expected
                                                                                  }
                                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                                              public void testConstructorRejectsLongOptionFormat() {
                                                                                  // Try to create with long option format which should be invalid
                                                                                  String invalidOpt = "--file";  // Long option format
                                                                                  new Option(invalidOpt, "file", true, "test");
                                                                              }

    @Test
                                                                              public void testOptParameterShouldBeShortRepresentation() {
                                                                                  // Test with a very long opt string (should be invalid if original spec is enforced)
                                                                                  String longOptString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                                                                                  
                                                                                  // Create option with long string
                                                                                  Option option = new Option(longOptString, null, false, "description");
                                                                                  
                                                                                  // Verify the opt was stored exactly as provided (mutant behavior)
                                                                                  assertEquals(longOptString, option.getOpt());
                                                                                  
                                                                                  // If original behavior was to enforce short representation, 
                                                                                  // we would expect either:
                                                                                  // 1. The constructor to throw an exception, or
                                                                                  // 2. The stored opt to be truncated
                                                                                  // Since neither happens, the mutant survives
                                                                              }

    @Test
                                                                              public void testShortOptRepresentation() {
                                                                                  // Test with a short opt string (valid case)
                                                                                  String shortOptString = "a";
                                                                                  Option option = new Option(shortOptString, null, false, "description");
                                                                                  
                                                                                  assertEquals(shortOptString, option.getOpt());
                                                                              }

    @Test
                                                                              public void testOptShouldBeShortRepresentation() {
                                                                                  // Test that opt is properly handled as a short (single-character) option
                                                                                  Option option = new Option("h", true, "Help option");
                                                                                  
                                                                                  // Verify the opt is exactly what was set
                                                                                  assertEquals("h", option.getOpt());
                                                                                  
                                                                                  // Verify the opt is a single character (short representation)
                                                                                  assertEquals(1, option.getOpt().length());
                                                                                  
                                                                                  // Test with empty string should fail (though constructor might allow it)
                                                                                  try {
                                                                                      Option emptyOption = new Option("", true, "Empty option");
                                                                                      fail("Should have thrown IllegalArgumentException for empty opt");
                                                                                  } catch (IllegalArgumentException e) {
                                                                                      // Expected behavior
                                                                                  }
                                                                                  
                                                                                  // Test with multi-character string should fail
                                                                                  try {
                                                                                      Option longOpt = new Option("help", true, "Long option");
                                                                                      fail("Should have thrown IllegalArgumentException for multi-character opt");
                                                                                  } catch (IllegalArgumentException e) {
                                                                                      // Expected behavior
                                                                                  }
                                                                              }

    @Test
                                                                              public void testConstructorRejectsMultiCharacterOption() throws Exception {
                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                  thrown.expectMessage("Single character option required");
                                                                                  
                                                                                  new Option("multi", "long-opt", false, "description");
                                                                              }

    @Test
                                                                              public void testConstructorHandlesEmptyOption() throws Exception {
                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                  thrown.expectMessage("Empty option name");
                                                                                  
                                                                                  new Option("", "long-opt", false, "description");
                                                                              }

    @Test
                                                                         public void testConstructorValidatesShortOption() throws Exception {
                                                                             // Test with valid single-character option
                                                                             new Option("a", "long-opt", false, "description"); // Should not throw
                                                                             
                                                                             // Test with invalid multi-character option should throw
                                                                             thrown.expect(IllegalArgumentException.class);
                                                                             new Option("invalid", "long-opt", false, "description");
                                                                         }

    @Test
                                                                         public void testConstructorSetsDescriptionCorrectly() {
                                                                             // Arrange
                                                                             String testOpt = "t";
                                                                             String testDescription = "Test description for the option";
                                                                             
                                                                             // Act
                                                                             Option option = new Option(testOpt, null, false, testDescription);
                                                                             
                                                                             // Assert
                                                                             assertEquals("Description should be set correctly", 
                                                                                         testDescription, 
                                                                                         option.getDescription());
                                                                         }

    @Test
                                                                         public void testConstructorParameterDocumentationConsistency() throws NoSuchMethodException {
                                                                             // Get the constructor with parameters (String, boolean, String)
                                                                             Constructor<Option> constructor = Option.class.getDeclaredConstructor(
                                                                                 String.class, boolean.class, String.class);
                                                                             
                                                                             // Get the parameter annotations
                                                                             Parameter[] parameters = constructor.getParameters();
                                                                             String paramName = parameters[2].getName(); // description parameter
                                                                             
                                                                             // Verify parameter name matches documentation convention
                                                                             assertEquals("Parameter name should be 'description'", "description", paramName);
                                                                             
                                                                             // Verify the description field is properly set and accessible
                                                                             Option option = new Option("t", true, "test description");
                                                                             assertEquals("Description should match constructor argument", 
                                                                                 "test description", option.getDescription());
                                                                         }

    @Test
                                                                         public void testDescriptionIsProperlySet() {
                                                                             // Arrange
                                                                             String opt = "t";
                                                                             String longOpt = "test";
                                                                             boolean hasArg = false;
                                                                             String expectedDescription = "Test description";
                                                                             
                                                                             // Act - This would fail to compile if parameter was renamed to 'desc'
                                                                             // but assignment still uses 'description'
                                                                             Option option = new Option(opt, longOpt, hasArg, expectedDescription);
                                                                             
                                                                             // Assert
                                                                             assertEquals("Description should match input", 
                                                                                         expectedDescription, 
                                                                                         option.getDescription());
                                                                         }

    @Test
                                                                        public void testDescriptionFieldBehavior() {
                                                                            // Test normal description setting and retrieval
                                                                            String testDescription = "Test option description";
                                                                            Option option = new Option("t", null, false, testDescription);
                                                                            
                                                                            // Verify description is stored and retrieved correctly
                                                                            assertEquals("Description should match what was set in constructor", 
                                                                                        testDescription, option.getDescription());
                                                                            
                                                                            // Verify description is used in toString()
                                                                            String toStringResult = option.toString();
                                                                            assertTrue("toString() should contain the description",
                                                                                      toStringResult.contains(testDescription));
                                                                            
                                                                            // Test empty description
                                                                            Option emptyDescOption = new Option("e", null, false, "");
                                                                            assertEquals("Empty description should be stored as empty string",
                                                                                        "", emptyDescOption.getDescription());
                                                                            
                                                                            // Test null description
                                                                            Option nullDescOption = new Option("n", null, false, null);
                                                                            assertNull("Null description should be stored as null",
                                                                                      nullDescOption.getDescription());
                                                                            
                                                                            // Verify setDescription works as expected
                                                                            String newDescription = "New description";
                                                                            option.setDescription(newDescription);
                                                                            assertEquals("setDescription should update the description",
                                                                                        newDescription, option.getDescription());
                                                                        }

    @Test
                                                                        public void testConstructorSetsDescriptionCorrectly1() {
                                                                            // Test with non-null description
                                                                            String testDescription = "This option controls verbose output";
                                                                            Option option = new Option("v", false, testDescription);
                                                                            
                                                                            // Verify description is stored and retrieved correctly
                                                                            assertEquals("Description should match what was passed to constructor", 
                                                                                        testDescription, option.getDescription());
                                                                            
                                                                            // Test with null description
                                                                            Option nullDescOption = new Option("f", true, null);
                                                                            assertNull("Null description should be allowed", 
                                                                                      nullDescOption.getDescription());
                                                                            
                                                                            // Test with empty string description
                                                                            Option emptyDescOption = new Option("e", false, "");
                                                                            assertEquals("Empty string description should be preserved",
                                                                                       "", emptyDescOption.getDescription());
                                                                        }

    @Test
                                                                    public void testDescriptionIsSetCorrectly() {
                                                                        // Arrange
                                                                        String opt = "t";
                                                                        String longOpt = "test";
                                                                        boolean hasArg = true;
                                                                        String description = "test description";
                                                                        
                                                                        // Act - create the Option instance
                                                                        Option option = new Option(opt, longOpt, hasArg, description);
                                                                        
                                                                        // Assert
                                                                        assertEquals(description, option.getDescription());
                                                                    }

    @Test
                                                                    public void testOptionInitialization() {
                                                                        // Arrange
                                                                        String opt = "t";
                                                                        String longOpt = "test";
                                                                        boolean hasArg = true;
                                                                        String description = "test description";
                                                                        
                                                                        // Act
                                                                        Option option = new Option(opt, longOpt, hasArg, description);
                                                                        
                                                                        // Assert all fields are set correctly
                                                                        assertEquals(opt, option.getOpt());
                                                                        assertEquals(longOpt, option.getLongOpt());
                                                                        assertEquals(1, option.getArgs()); // Because hasArg is true
                                                                        assertEquals(description, option.getDescription());
                                                                    }

    @Test
                                                                    public void testOptionInitializationWithoutArgs() {
                                                                        // Arrange
                                                                        String opt = "t";
                                                                        String longOpt = "test";
                                                                        boolean hasArg = false;
                                                                        String description = "test description";
                                                                        
                                                                        // Act
                                                                        Option option = new Option(opt, longOpt, hasArg, description);
                                                                        
                                                                        // Assert numberOfArgs is not set when hasArg is false
                                                                        assertEquals(0, option.getArgs());
                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                       public void testMutantWouldFailDueToParameterShift() {
                                                                           // This test would catch the mutant because:
                                                                           // Original: this(opt, null, false, description)
                                                                           // Mutant: this(opt + null, false, description)
                                                                           // The mutant would try to use 'false' as longOpt parameter which expects String
                                                                           String opt = "t";
                                                                           String description = "test option";
                                                                           
                                                                           // If the mutant was present, this would throw IllegalArgumentException
                                                                           // because 'false' cannot be cast to String for longOpt parameter
                                                                           new Option(opt, null, false, description);
                                                                       }

    @Test
                                                                       public void testConstructorWithOptAndDescription() {
                                                                           // Test data
                                                                           String opt = "t";
                                                                           boolean hasArg = true;
                                                                           String description = "test option";
                                                                           
                                                                           // Create option using constructor
                                                                           Option option = new Option(opt, null, hasArg, description);
                                                                           
                                                                           // Verify fields are set correctly
                                                                           assertEquals("Short option should match", opt, option.getOpt());
                                                                           assertNull("Long option should be null", option.getLongOpt());
                                                                           assertEquals("Description should match", description, option.getDescription());
                                                                           assertTrue("Should have argument", option.hasArg());
                                                                           
                                                                           // This would fail with the mutant because:
                                                                           // 1. Mutant would try to call constructor with wrong number of parameters
                                                                           // 2. If mutant somehow compiled, getOpt() might return wrong value
                                                                           // 3. Other fields might not be set properly
                                                                       }

    @Test
                                                                       public void testNumberOfArgsWhenHasArgIsTrue() {
                                                                           // Setup
                                                                           String opt = "t";
                                                                           String longOpt = "test";
                                                                           String description = "test option";
                                                                           boolean hasArg = true;
                                                                           
                                                                           // Mock the validator if needed (though in this case it might not be necessary)
                                                                           // OptionValidator validator = mock(OptionValidator.class);
                                                                           // doNothing().when(validator).validateOption(anyString());
                                                                           
                                                                           // Test the constructor
                                                                           Option option = new Option(opt, longOpt, hasArg, description);
                                                                           
                                                                           // Verify the numberOfArgs is set correctly
                                                                           // Original behavior would set it to 1 (if it was 1 * 1)
                                                                           // Mutated behavior would set it to 2 (if it was 1 + 1)
                                                                           assertEquals("numberOfArgs should be 1 when hasArg is true", 1, option.getArgs());
                                                                           
                                                                           // Additional verification
                                                                           assertEquals(opt, option.getOpt());
                                                                           assertEquals(longOpt, option.getLongOpt());
                                                                           assertEquals(description, option.getDescription());
                                                                           assertTrue(option.hasArg());
                                                                       }

    @Test
                                                                  public void testConstructorInitialization2() {
                                                                      // Setup test data
                                                                      String opt = "t";
                                                                      String description = "test option";
                                                                      
                                                                      // Create option instance
                                                                      Option option = new Option(opt, null, false, description);
                                                                      
                                                                      // Verify fields are correctly initialized
                                                                      assertEquals("Short option should match", opt, option.getOpt());
                                                                      assertNull("Long option should be null", option.getLongOpt());
                                                                      assertFalse("Should not be required", option.isRequired());
                                                                      assertEquals("Description should match", description, option.getDescription());
                                                                      
                                                                      // Verify no values are set initially by checking public methods
                                                                      assertNull("Values array should be null initially", option.getValues());
                                                                      assertEquals("Number of args should be UNINITIALIZED", 
                                                                          Option.UNINITIALIZED, option.getArgs());
                                                                  }

    @Test
                                                              public void testOptionConstructorWithShortOptAndDescription() {
                                                                  // Arrange
                                                                  String opt = "t";
                                                                  String description = "test option";
                                                                  
                                                                  // Act
                                                                  Option option = new Option(opt, null, false, description);
                                                                  
                                                                  // Assert
                                                                  assertEquals("Short option should match", opt, option.getOpt());
                                                                  assertNull("Long option should be null", option.getLongOpt());
                                                                  assertFalse("Option should not be required", option.isRequired());
                                                                  assertEquals("Description should match", description, option.getDescription());
                                                                  
                                                                  // Additional state checks
                                                                  assertFalse("Should not have optional arg", option.hasOptionalArg());
                                                                  assertEquals("Should have 0 args", 0, option.getArgs());
                                                                  assertNull("Should have null arg name", option.getArgName());
                                                              }

    @Test
                                                              public void testConstructorWithNullLongOpt() {
                                                                  // Arrange
                                                                  String opt = "t";
                                                                  boolean hasArg = true;
                                                                  String description = "test option";
                                                                  
                                                                  // Act
                                                                  Option option = new Option(opt, hasArg, description);
                                                                  
                                                                  // Assert
                                                                  assertNull("The longOpt should be null when constructed with this constructor", 
                                                                             option.getLongOpt());
                                                                  assertEquals("Short option should match", opt, option.getOpt());
                                                                  assertEquals("hasArg should match", hasArg, option.hasArg());
                                                                  assertEquals("Description should match", description, option.getDescription());
                                                              }

    @Test
                                                                  public void testNumberOfArgsSetWhenHasArgIsTrue() {
                                                                      // Test case where hasArg is true
                                                                      String opt = "t";
                                                                      String longOpt = "test";
                                                                      String description = "test option";
                                                                      boolean hasArg = true;
                                                                      
                                                                      Option option = new Option(opt, longOpt, hasArg, description);
                                                                      
                                                                      // Verify numberOfArgs is set to 1 when hasArg is true
                                                                      assertEquals(1, option.getArgs());
                                                                  }

    @Test
                                                                  public void testNumberOfArgsNotSetWhenHasArgIsFalse() {
                                                                      // Test case where hasArg is false
                                                                      String opt = "t";
                                                                      String longOpt = "test";
                                                                      String description = "test option";
                                                                      boolean hasArg = false;
                                                                      
                                                                      Option option = new Option(opt, longOpt, hasArg, description);
                                                                      
                                                                      // Verify numberOfArgs remains default (likely 0) when hasArg is false
                                                                      // Assuming default is 0 (UNINITIALIZED might be -1, adjust as needed)
                                                                      assertNotEquals(1, option.getArgs());
                                                                  }

    @Test
                                                                 public void testConstructorWithNullOptShouldThrowIllegalArgumentException1() {
                                                                     // Prepare
                                                                     String nullOpt = null;
                                                                     String description = "test description";
                                                                     
                                                                     // Expect
                                                                     thrown.expect(IllegalArgumentException.class);
                                                                     thrown.expectMessage("opt");
                                                                     
                                                                     // Execute
                                                                     new Option(nullOpt, null, false, description);
                                                                 }

    @Test
                                                                 public void testConstructorWithEmptyOptShouldThrowIllegalArgumentException1() {
                                                                     // Prepare
                                                                     String emptyOpt = "";
                                                                     String description = "test description";
                                                                     
                                                                     // Expect
                                                                     thrown.expect(IllegalArgumentException.class);
                                                                     thrown.expectMessage("opt");
                                                                     
                                                                     // Execute
                                                                     new Option(emptyOpt, null, false, description);
                                                                 }

    @Test
                                                                 public void testConstructorWithInvalidSingleCharOptShouldThrowIllegalArgumentException1() {
                                                                     // Prepare
                                                                     String invalidOpt = "?";
                                                                     String description = "test description";
                                                                     
                                                                     // Expect
                                                                     thrown.expect(IllegalArgumentException.class);
                                                                     thrown.expectMessage("opt");
                                                                     
                                                                     // Execute
                                                                     new Option(invalidOpt, null, false, description);
                                                                 }

    @Test
                                                                 public void testConstructorWithNullOptShouldThrowIllegalArgumentException2() {
                                                                     // Prepare test data
                                                                     String nullOpt = null;
                                                                     boolean hasArg = true;
                                                                     String description = "test description";
                                                                     
                                                                     // Set expectation - original should throw IllegalArgumentException
                                                                     thrown.expect(IllegalArgumentException.class);
                                                                     thrown.expectMessage("opt");
                                                                     
                                                                     // Execute test
                                                                     new Option(nullOpt, hasArg, description);
                                                                 }

    @Test
                                                                 public void testConstructorWithEmptyOptShouldThrowIllegalArgumentException2() {
                                                                     // Prepare test data
                                                                     String emptyOpt = "";
                                                                     boolean hasArg = true;
                                                                     String description = "test description";
                                                                     
                                                                     // Set expectation - original should throw IllegalArgumentException
                                                                     thrown.expect(IllegalArgumentException.class);
                                                                     thrown.expectMessage("opt");
                                                                     
                                                                     // Execute test
                                                                     new Option(emptyOpt, hasArg, description);
                                                                 }

    @Test
                                                                 public void testConstructorWithInvalidOptShouldThrowIllegalArgumentException3() {
                                                                     // Prepare test data
                                                                     String invalidOpt = "invalid-option"; // contains invalid character
                                                                     boolean hasArg = true;
                                                                     String description = "test description";
                                                                     
                                                                     // Set expectation - original should throw IllegalArgumentException
                                                                     thrown.expect(IllegalArgumentException.class);
                                                                     thrown.expectMessage("opt");
                                                                     
                                                                     // Execute test
                                                                     new Option(invalidOpt, hasArg, description);
                                                                 }

    @Test
                                                                 public void testConstructorWithInvalidOptionThrowsIllegalArgumentException() {
                                                                     // Setup expected exception
                                                                     thrown.expect(IllegalArgumentException.class);
                                                                     thrown.expectMessage("Invalid option"); // Adjust message if known
                                                                     
                                                                     // Test data - using invalid option that should fail validation
                                                                     String invalidOpt = "@"; // Typically invalid character for options
                                                                     String longOpt = "long-option";
                                                                     boolean hasArg = true;
                                                                     String description = "description";
                                                                     
                                                                     // This should throw IllegalArgumentException with original code
                                                                     // Will throw NullPointerException with mutated code
                                                                     new Option(invalidOpt, longOpt, hasArg, description);
                                                                 }

    @Test(expected = IllegalArgumentException.class)
                                                                public void testConstructorWithInvalidShortOption() {
                                                                    // Test with invalid short option (null)
                                                                    new Option(null, null, false, "description");
                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                public void testConstructorWithEmptyShortOption() {
                                                                    // Test with empty short option
                                                                    new Option("", null, false, "description");
                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                public void testConstructorWithInvalidShortOptionFormat() {
                                                                    // Test with invalid short option format (more than one character)
                                                                    new Option("abc", null, false, "description");
                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                public void testConstructorWithInvalidCharacterInShortOption() {
                                                                    // Test with special character in short option
                                                                    new Option("?", null, false, "description");
                                                                }

    @Test
                                                                public void testConstructorWithValidShortOption() {
                                                                    // Test with valid short option to ensure it doesn't throw exception
                                                                    Option option = new Option("a", null, false, "description");
                                                                    assertEquals("a", option.getOpt());
                                                                    assertNull(option.getLongOpt());
                                                                    assertFalse(option.isRequired());
                                                                    assertEquals("description", option.getDescription());
                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                public void testConstructorWithNullOpt() {
                                                                    new Option(null, true, "description");
                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                public void testConstructorWithEmptyOpt() {
                                                                    new Option("", true, "description");
                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                public void testConstructorWithInvalidSingleCharOpt() {
                                                                    new Option("?", true, "description");
                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                public void testConstructorWithInvalidMultiCharOpt() {
                                                                    new Option("invalid", true, "description");
                                                                }

    @Test
                                                                public void testConstructorWithValidOpt() {
                                                                    Option option = new Option("v", true, "description");
                                                                    assertEquals("v", option.getOpt());
                                                                    assertTrue(option.hasArg());
                                                                    assertEquals("description", option.getDescription());
                                                                }

    @Test
                                                                public void testConstructorWithInvalidShortOption1() {
                                                                    thrown.expect(IllegalArgumentException.class);
                                                                    thrown.expectMessage("Illegal option name");
                                                                    
                                                                    // Test with invalid short option (null)
                                                                    new Option(null, false, "description");
                                                                }

    @Test
                                                                public void testConstructorWithEmptyShortOption1() {
                                                                    thrown.expect(IllegalArgumentException.class);
                                                                    thrown.expectMessage("Illegal option name");
                                                                    
                                                                    // Test with empty short option
                                                                    new Option("", false, "description");
                                                                }

    @Test
                                                                public void testConstructorWithInvalidCharacterShortOption() {
                                                                    thrown.expect(IllegalArgumentException.class);
                                                                    thrown.expectMessage("Illegal option name");
                                                                    
                                                                    // Test with special character that's not allowed
                                                                    new Option("@", false, "description");
                                                                }

    @Test
                                                                public void testConstructorWithMultiCharacterShortOption() {
                                                                    thrown.expect(IllegalArgumentException.class);
                                                                    thrown.expectMessage("Illegal option name");
                                                                    
                                                                    // Test with multiple characters where single character is expected
                                                                    new Option("abc", false, "description");
                                                                }

    @Test
                                                               public void testOptionConstructorPreservesCase() {
                                                                   // Arrange
                                                                   String testOpt = "testOpt";
                                                                   String description = "test description";
                                                                   
                                                                   // Act
                                                                   Option option = new Option(testOpt, null, false, description);
                                                                   
                                                                   // Assert
                                                                   // Verify the option name preserves its original case
                                                                   assertEquals("Option name should preserve original case", 
                                                                               testOpt, 
                                                                               option.getOpt());
                                                               }

    @Test
                                                               public void testOptionConstructorPreservesCaseOfOptParameter() {
                                                                   // Arrange
                                                                   String mixedCaseOpt = "TeSt";
                                                                   boolean hasArg = false;
                                                                   String description = "Test option";
                                                                   
                                                                   // Act - Create option with mixed case opt parameter
                                                                   Option option = new Option(mixedCaseOpt, hasArg, description);
                                                                   
                                                                   // Assert - Verify opt parameter preserves original case
                                                                   assertEquals("Option constructor should preserve exact case of opt parameter", 
                                                                               mixedCaseOpt, option.getOpt());
                                                               }

    @Test(expected = IllegalArgumentException.class)
                                                               public void testValidateOptionShouldCheckCorrectParameter() {
                                                                   // This test will fail if the mutant is present because:
                                                                   // Original: validates "invalid-opt" (should throw)
                                                                   // Mutant: validates OPT (might not throw if OPT is valid)
                                                                   
                                                                   String invalidOpt = "invalid-opt"; // contains invalid character '-'
                                                                   String longOpt = "longOption";
                                                                   String description = "description";
                                                                   boolean hasArg = true;
                                                                   
                                                                   // The test will pass with original code (throws exception)
                                                                   // and fail with mutant (if OPT is valid)
                                                                   new Option(invalidOpt, longOpt, hasArg, description);
                                                               }

    @Test
                                                               public void testValidateOptionWithValidOpt() {
                                                                   // Additional test to verify valid option works
                                                                   String validOpt = "v";
                                                                   String longOpt = "valid";
                                                                   String description = "description";
                                                                   boolean hasArg = true;
                                                                   
                                                                   Option option = new Option(validOpt, longOpt, hasArg, description);
                                                                   
                                                                   assertEquals(validOpt, option.getOpt());
                                                                   assertEquals(longOpt, option.getLongOpt());
                                                                   assertEquals(1, option.getArgs()); // verify hasArg set numberOfArgs
                                                                   assertEquals(description, option.getDescription());
                                                               }

    @Test
                                                              public void testOptionConstructorWithSpecialCharactersInOpt() {
                                                                  // Test with standard option format (should work in both original and mutant)
                                                                  Option standardOption = new Option("f", null, false, "file option");
                                                                  assertEquals("f", standardOption.getOpt());
                                                                  
                                                                  // Test cases that should detect the mutant
                                                                  // 1. Option with special characters that should be handled differently
                                                                  Option specialCharOption = new Option("-f@", null, false, "special char option");
                                                                  // Original would likely process/strip special chars, mutant would keep them
                                                                  assertNotEquals("-f@", specialCharOption.getOpt());
                                                                  
                                                                  // 2. Option with multiple special characters
                                                                  Option multiSpecialOption = new Option("--f$#", null, false, "multi special option");
                                                                  // Original might normalize this, mutant would keep as-is
                                                                  assertNotEquals("--f$#", multiSpecialOption.getOpt());
                                                                  
                                                                  // 3. Empty option string
                                                                  Option emptyOption = new Option("", null, false, "empty option");
                                                                  // Original might have validation, mutant might accept empty string
                                                                  assertNotEquals("", emptyOption.getOpt());
                                                                  
                                                                  // 4. Option with spaces
                                                                  Option spaceOption = new Option("f ", null, false, "space option");
                                                                  // Original might trim, mutant would keep space
                                                                  assertNotEquals("f ", spaceOption.getOpt());
                                                              }

    @Test
                                                              public void testOptStringHandling() {
                                                                  // Test with single character option
                                                                  Option option1 = new Option("a", null, false, "test option");
                                                                  assertEquals("Original should process opt string properly", "a", option1.getOpt());
                                                                  
                                                                  // Test with multi-character option
                                                                  Option option2 = new Option("abc", null, false, "test option");
                                                                  assertEquals("Original should process opt string properly", "abc", option2.getOpt());
                                                                  
                                                                  // Test with special characters
                                                                  Option option3 = new Option("a-b", null, false, "test option");
                                                                  assertEquals("Original should process opt string properly", "a-b", option3.getOpt());
                                                                  
                                                                  // Test with empty string
                                                                  Option option4 = new Option("", null, false, "test option");
                                                                  assertEquals("Original should process opt string properly", "", option4.getOpt());
                                                                  
                                                                  // Test with null (should throw exception)
                                                                  try {
                                                                      new Option(null, null, false, "test option");
                                                                      fail("Should have thrown IllegalArgumentException for null opt");
                                                                  } catch (IllegalArgumentException e) {
                                                                      // Expected behavior
                                                                  }
                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                              public void testConstructorWithInvalidShortOptionShouldThrowException() {
                                                                  // This test should pass with original code but fail with mutated code
                                                                  new Option(null, false, "description"); // null option
                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                              public void testConstructorWithEmptyShortOptionShouldThrowException() {
                                                                  // This test should pass with original code but fail with mutated code
                                                                  new Option("", false, "description"); // empty option
                                                              }

    @Test(expected = IllegalArgumentException.class)
                                                              public void testConstructorWithInvalidCharacterShouldThrowException() {
                                                                  // This test should pass with original code but fail with mutated code
                                                                  new Option("@", false, "description"); // invalid character option
                                                              }

    @Test
                                                              public void testConstructorWithValidOptionShouldNotThrowException1() {
                                                                  // Valid option should work in both original and mutated code
                                                                  Option option = new Option("a", false, "description");
                                                                  assertEquals("a", option.getOpt());
                                                                  assertEquals("description", option.getDescription());
                                                              }

    @Test
                                                         public void testConstructorWithCommentMutation() {
                                                             // Arrange
                                                             String opt = "t";
                                                             String description = "test option";
                                                             
                                                             // Act - this calls the constructor with the mutated comment
                                                             Option option = new Option(opt, null, false, description);
                                                             
                                                             // Assert - verify all fields are set correctly
                                                             assertEquals(opt, option.getOpt());
                                                             assertNull(option.getLongOpt());
                                                             assertFalse(option.isRequired());
                                                             assertEquals(description, option.getDescription());
                                                             assertEquals(1, option.getArgs()); // default number of args
                                                             assertFalse(option.hasOptionalArg());
                                                             assertFalse(option.hasValueSeparator());
                                                         }

    @Test
                                                         public void testConstructorWithNullLongOpt1() {
                                                             // Arrange
                                                             String opt = "t";
                                                             boolean hasArg = true;
                                                             String description = "test option";
                                                             
                                                             // Act
                                                             Option option = new Option(opt, hasArg, description);
                                                             
                                                             // Assert
                                                             assertEquals(opt, option.getOpt());
                                                             assertNull(option.getLongOpt());  // Verify longOpt is null as per the constructor
                                                             assertEquals(hasArg, option.hasArg());
                                                             assertEquals(description, option.getDescription());
                                                         }

    @Test
                                                         public void testConstructorSetsFieldsCorrectly1() {
                                                             // Arrange
                                                             String opt = "o";
                                                             String longOpt = "option";
                                                             boolean hasArg = true;
                                                             String description = "description";
                                                             
                                                             // Act
                                                             Option option = new Option(opt, longOpt, hasArg, description);
                                                             
                                                             // Assert
                                                             assertEquals("opt field not set correctly", opt, option.getOpt());
                                                             assertEquals("longOpt field not set correctly", longOpt, option.getLongOpt());
                                                             assertEquals("numberOfArgs not set correctly when hasArg is true", 1, option.getArgs());
                                                             assertEquals("description field not set correctly", description, option.getDescription());
                                                             
                                                             // Additional verification that the comment doesn't affect behavior
                                                             assertTrue("Method should complete execution despite comment change", 
                                                                 option.getOpt() != null && option.getDescription() != null);
                                                         }

    @Test
                                                            public void testConstructorWithInvalidOptShouldThrowException1() {
                                                                // The original method declares it throws IllegalArgumentException,
                                                                // and the implementation should still throw it for invalid input
                                                                // even though the throws clause was removed by mutation
                                                                
                                                                // Test with null option name
                                                                thrown.expect(IllegalArgumentException.class);
                                                                thrown.expectMessage("opt");
                                                                new Option(null, "description");
                                                                
                                                                // Test with empty option name
                                                                thrown.expect(IllegalArgumentException.class);
                                                                thrown.expectMessage("opt");
                                                                new Option("", "description");
                                                                
                                                                // Test with option name that's too long
                                                                thrown.expect(IllegalArgumentException.class);
                                                                thrown.expectMessage("opt");
                                                                new Option("toolongoption", "description");
                                                            }

    @Test
                                                            public void testConstructorWithValidOptShouldNotThrowException() {
                                                                // Valid single-character option
                                                                Option option = new Option("a", "valid option");
                                                                assertEquals("a", option.getOpt());
                                                                assertEquals("valid option", option.getDescription());
                                                                assertNull(option.getLongOpt());
                                                                assertFalse(option.isRequired());
                                                                
                                                                // Valid option with special characters (if allowed)
                                                                Option option2 = new Option("?", "help option");
                                                                assertEquals("?", option2.getOpt());
                                                            }

    @Test(expected = IllegalArgumentException.class)
                                                            public void testConstructorWithInvalidOptShouldThrowException2() {
                                                                // This should throw IllegalArgumentException even though it's no longer declared
                                                                // because the mutation removed the throws clause but didn't change the behavior
                                                                new Option(null, "description");
                                                            }

    @Test
                                                            public void testConstructorWithValidOptShouldNotThrowException1() {
                                                                // Valid case that shouldn't throw exception
                                                                Option option = new Option("v", "verbose mode");
                                                                assertEquals("v", option.getOpt());
                                                                assertEquals("verbose mode", option.getDescription());
                                                            }

    @Test(expected = IllegalArgumentException.class)
                                                            public void testConstructorWithEmptyOptShouldThrowException1() {
                                                                // Empty string should be invalid
                                                                new Option("", "empty option");
                                                            }

    @Test(expected = IllegalArgumentException.class)
                                                            public void testConstructorWithInvalidCharacterShouldThrowException1() {
                                                                // Option containing invalid character should throw
                                                                new Option("@", "invalid char option");
                                                            }

    @Test(expected = IllegalArgumentException.class)
                                                            public void testConstructorWithInvalidOptionShouldThrowException1() {
                                                                // This tests the runtime behavior still throws exception
                                                                new Option("invalid@option", "description");
                                                            }

    @Test
                                                       public void testConstructorExceptionDeclaration() throws NoSuchMethodException {
                                                           // This tests the method signature (contract)
                                                           Class<Option> optionClass = Option.class;
                                                           Constructor<Option> constructor = optionClass.getConstructor(String.class, String.class);
                                                           
                                                           // Verify the method doesn't declare any exceptions (mutated behavior)
                                                           Class<?>[] exceptionTypes = constructor.getExceptionTypes();
                                                           assertTrue("Constructor should not declare any exceptions after mutation", 
                                                                     exceptionTypes.length == 0);
                                                           
                                                           // Verify the method is not declared to throw IllegalArgumentException
                                                           boolean throwsIllegalArgumentException = false;
                                                           for (Class<?> exceptionType : exceptionTypes) {
                                                               if (exceptionType.equals(IllegalArgumentException.class)) {
                                                                   throwsIllegalArgumentException = true;
                                                                   break;
                                                               }
                                                           }
                                                           assertFalse("Constructor should not declare IllegalArgumentException after mutation",
                                                                      throwsIllegalArgumentException);
                                                       }

    @Test
                                                       public void testConstructorThrowsIllegalArgumentExceptionForInvalidOpt() {
                                                           // Arrange
                                                           String invalidOpt = null; // null option should be invalid
                                                           String description = "test description";
                                                           
                                                           // Expect IllegalArgumentException specifically
                                                           thrown.expect(IllegalArgumentException.class);
                                                           thrown.expectMessage("opt"); // Option class typically includes 'opt' in exception message
                                                           
                                                           // Act
                                                           new Option(invalidOpt, description);
                                                       }

    @Test
                                                       public void testConstructorThrowsIllegalArgumentExceptionForEmptyOpt() {
                                                           // Arrange
                                                           String emptyOpt = ""; // empty string should be invalid
                                                           String description = "test description";
                                                           
                                                           // Expect IllegalArgumentException specifically
                                                           thrown.expect(IllegalArgumentException.class);
                                                           thrown.expectMessage("opt"); // Option class typically includes 'opt' in exception message
                                                           
                                                           // Act
                                                           new Option(emptyOpt, description);
                                                       }

    @Test
                                                       public void testConstructorWithInvalidOptThrowsIllegalArgumentException() {
                                                           // Arrange
                                                           String invalidOpt = null; // null option should be invalid
                                                           String description = "test description";
                                                           
                                                           // Expect
                                                           thrown.expect(IllegalArgumentException.class);
                                                           thrown.expectMessage("opt"); // Option constructors typically mention 'opt' in their exception message
                                                           
                                                           // Act
                                                           new Option(invalidOpt, description);
                                                       }

    @Test
                                                       public void testConstructorWithEmptyOptThrowsIllegalArgumentException1() {
                                                           // Arrange
                                                           String emptyOpt = ""; // empty string option should be invalid
                                                           String description = "test description";
                                                           
                                                           // Expect
                                                           thrown.expect(IllegalArgumentException.class);
                                                           thrown.expectMessage("opt"); // Option constructors typically mention 'opt' in their exception message
                                                           
                                                           // Act
                                                           new Option(emptyOpt, description);
                                                       }

    @Test
                                                       public void testConstructorShouldThrowIllegalArgumentExceptionForInvalidOption() {
                                                           // Arrange - prepare invalid option values that should fail validation
                                                           String[] invalidOptions = {
                                                               null,           // null option
                                                               "",             // empty string
                                                               "invalid",      // too long (more than 1 char)
                                                               "-",            // just a hyphen
                                                               " ",            // whitespace
                                                               "@"             // special character
                                                           };
                                                           
                                                           String description = "test description";
                                                           
                                                           for (String invalidOpt : invalidOptions) {
                                                               try {
                                                                   // Act - try to create Option with invalid parameter
                                                                   new Option(invalidOpt, description);
                                                                   
                                                                   // Fail if no exception was thrown
                                                                   fail("Expected IllegalArgumentException for option: " + invalidOpt);
                                                               } catch (Exception e) {
                                                                   // Assert - verify exact exception type
                                                                   assertEquals("Should throw IllegalArgumentException for invalid option: " + invalidOpt,
                                                                                IllegalArgumentException.class, e.getClass());
                                                               }
                                                           }
                                                       }

    @Test
                                                  public void testConstructorInitializesFieldsCorrectly1() {
                                                      // Arrange
                                                      String testOpt = "t";
                                                      String testDescription = "test description";
                                                      
                                                      // Act
                                                      Option option = new Option(testOpt, null, false, testDescription);
                                                      
                                                      // Assert
                                                      assertEquals("Short option should match input", testOpt, option.getOpt());
                                                      assertNull("Long option should be null", option.getLongOpt());
                                                      assertFalse("Required should be false", option.isRequired());
                                                      assertEquals("Description should match input", testDescription, option.getDescription());
                                                      
                                                      // Verify other fields initialized to defaults
                                                      assertNull("Type should be null by default", option.getType());
                                                      assertEquals("Number of args should be 0 by default", 0, option.getArgs());
                                                      assertFalse("Should not have optional arg by default", option.hasOptionalArg());
                                                      assertNull("Arg name should be null by default", option.getArgName());
                                                  }

    @Test
                                                  public void testConstructorWithOptHasArgDescription2() {
                                                      // Test data
                                                      String opt = "t";
                                                      boolean hasArg = true;
                                                      String description = "test option";
                                                      
                                                      // Create option using the constructor
                                                      Option option = new Option(opt, hasArg, description);
                                                      
                                                      // Verify all fields are set correctly
                                                      assertEquals("Short option not set correctly", opt, option.getOpt());
                                                      assertNull("Long option should be null", option.getLongOpt());
                                                      assertEquals("Description not set correctly", description, option.getDescription());
                                                      assertEquals("hasArg not set correctly", hasArg, option.hasArg());
                                                      
                                                      // Verify default values
                                                      assertFalse("Default required should be false", option.isRequired());
                                                      assertFalse("Default optionalArg should be false", option.hasOptionalArg());
                                                      assertEquals("Default numberOfArgs should be UNINITIALIZED", 
                                                                   Option.UNINITIALIZED, option.getArgs());
                                                      assertNull("Default type should be null", option.getType());
                                                      assertFalse("Default hasValueSeparator should be false", option.hasValueSeparator());
                                                  }

    @Test
                                                 public void testOptionConstructorSetsAllFieldsCorrectly() {
                                                     // Arrange
                                                     String opt = "t";
                                                     String longOpt = "test";
                                                     boolean hasArg = true;
                                                     String description = "test option";
                                                     
                                                     // Act - create the option
                                                     Option option = new Option(opt, longOpt, hasArg, description);
                                                     
                                                     // Assert - verify all fields are set correctly
                                                     assertEquals("opt field not set correctly", opt, option.getOpt());
                                                     assertEquals("longOpt field not set correctly", longOpt, option.getLongOpt());
                                                     assertEquals("description field not set correctly", description, option.getDescription());
                                                     assertEquals("numberOfArgs not set correctly when hasArg is true", 1, option.getArgs());
                                                     
                                                     // Additional check for when hasArg is false
                                                     Option optionNoArg = new Option(opt, longOpt, false, description);
                                                     assertEquals("numberOfArgs should be 0 when hasArg is false", 0, optionNoArg.getArgs());
                                                 }

    @Test
                                             public void testConstructorWithOptAndDescription1() {
                                                 // Arrange
                                                 String expectedOpt = "t";
                                                 String expectedDescription = "test option";
                                                 
                                                 // Act
                                                 Option option = new Option(expectedOpt, null, false, expectedDescription);
                                                 
                                                 // Assert
                                                 assertEquals("Short option should match constructor parameter", 
                                                              expectedOpt, option.getOpt());
                                                 assertNull("Long option should be null", option.getLongOpt());
                                                 assertFalse("Required flag should be false", option.isRequired());
                                                 assertEquals("Description should match constructor parameter",
                                                              expectedDescription, option.getDescription());
                                             }

    @Test
                                             public void testConstructorWithOptHasArgDescription3() {
                                                 // Arrange
                                                 String opt = "t";
                                                 boolean hasArg = true;
                                                 String description = "test option";
                                                 
                                                 // Act
                                                 Option option = new Option(opt, hasArg, description);
                                                 
                                                 // Assert
                                                 assertEquals("opt should be set to provided value", opt, option.getOpt());
                                                 assertNull("longOpt should be null", option.getLongOpt());
                                                 assertEquals("hasArg should be set to provided value", hasArg, option.hasArg());
                                                 assertEquals("description should be set to provided value", 
                                                              description, option.getDescription());
                                                 
                                                 // Verify default values
                                                 assertFalse("required should default to false", option.isRequired());
                                                 assertFalse("optionalArg should default to false", option.hasOptionalArg());
                                                 assertEquals("numberOfArgs should default to UNINITIALIZED", 
                                                              Option.UNINITIALIZED, option.getArgs());
                                                 assertNull("type should default to null", option.getType());
                                             }

    @Test
                                             public void testConstructorSetsFieldsCorrectly2() {
                                                 // Arrange
                                                 String opt = "t";
                                                 String longOpt = "test";
                                                 boolean hasArg = true;
                                                 String description = "test option";
                                                 
                                                 // Act
                                                 Option option = new Option(opt, longOpt, hasArg, description);
                                                 
                                                 // Assert
                                                 assertEquals("opt field not set correctly", opt, option.getOpt());
                                                 assertEquals("longOpt field not set correctly", longOpt, option.getLongOpt());
                                                 assertEquals("numberOfArgs not set to 1 when hasArg is true", 1, option.getArgs());
                                                 assertEquals("description field not set correctly", description, option.getDescription());
                                                 
                                                 // Test with hasArg false
                                                 Option option2 = new Option(opt, longOpt, false, description);
                                                 assertEquals("numberOfArgs should be 0 when hasArg is false", 0, option2.getArgs());
                                             }

    @Test
                                                public void testConstructorWithOptNullFalseDescription1() {
                                                    // Setup
                                                    String opt = "t";
                                                    String description = "test option";
                                                    
                                                    // Exercise
                                                    Option option = new Option(opt, null, false, description);
                                                    
                                                    // Verify
                                                    assertEquals("Short option not set correctly", opt, option.getOpt());
                                                    assertNull("Long option should be null", option.getLongOpt());
                                                    assertFalse("Required flag should be false", option.isRequired());
                                                    assertEquals("Description not set correctly", description, option.getDescription());
                                                    assertEquals("Number of args should be uninitialized", Option.UNINITIALIZED, option.getArgs());
                                                }

    @Test
                                                public void testConstructorWithOptAndDescription2() {
                                                    // Test data
                                                    String opt = "t";
                                                    boolean hasArg = true;
                                                    String description = "Test option";
                                                    
                                                    // Create option using constructor
                                                    Option option = new Option(opt, null, hasArg, description);
                                                    
                                                    // Verify all fields are set correctly
                                                    assertEquals("Short option should match", opt, option.getOpt());
                                                    assertNull("Long option should be null", option.getLongOpt());
                                                    assertEquals("Has arg should match", hasArg, option.hasArg());
                                                    assertEquals("Description should match", description, option.getDescription());
                                                    
                                                    // Additional checks for default values
                                                    assertFalse("Should not be required by default", option.isRequired());
                                                    assertEquals("Should have UNINITIALIZED args by default", 
                                                                 Option.UNINITIALIZED, option.getArgs());
                                                }

    @Test
                                            public void testNumberOfArgsWhenHasArgIsTrue1() {
                                                // Arrange
                                                String opt = "t";
                                                String longOpt = "test";
                                                String description = "test option";
                                                boolean hasArg = true;
                                                
                                                // Act
                                                Option option = new Option(opt, longOpt, hasArg, description);
                                                
                                                // Assert
                                                assertEquals("When hasArg is true, numberOfArgs should be exactly 1", 
                                                            1, option.getArgs());
                                                
                                                // Additional verification that it's not being incremented
                                                assertNotEquals("numberOfArgs should not be affected by addition mutation",
                                                               2, option.getArgs());
                                                assertNotEquals("numberOfArgs should not be affected by addition mutation",
                                                               0, option.getArgs());
                                            }

    @Test
                                           public void testOptionConstructorInitialization() {
                                               // Arrange
                                               String testOpt = "t";
                                               String testDescription = "test option";
                                               
                                               // Act
                                               Option option = new Option(testOpt, null, false, testDescription);
                                               
                                               // Assert
                                               assertEquals("Short option not set correctly", testOpt, option.getOpt());
                                               assertNull("Long option should be null", option.getLongOpt());
                                               assertFalse("Option should not be required", option.isRequired());
                                               assertEquals("Description not set correctly", testDescription, option.getDescription());
                                               assertEquals("Number of args should be UNINITIALIZED", 
                                                            Option.UNINITIALIZED, option.getArgs());
                                               assertFalse("Should not have optional arg", option.hasOptionalArg());
                                               assertFalse("Should not have value separator", option.hasValueSeparator());
                                           }

    @Test
                                               public void testConstructorInitialization3() {
                                                   // Arrange
                                                   String opt = "t";
                                                   boolean hasArg = true;
                                                   String description = "test option";
                                                   
                                                   // Act - this would fail to compile with the mutant
                                                   Option option = new Option(opt, null, hasArg, description);
                                                   
                                                   // Assert
                                                   assertEquals("Short option should match", opt, option.getOpt());
                                                   assertNull("Long option should be null", option.getLongOpt());
                                                   assertTrue("Should require argument", option.hasArg());
                                                   assertEquals("Description should match", description, option.getDescription());
                                               }

    @Test
                                               public void testNumberOfArgsWhenHasArgIsTrue2() {
                                                   // Test normal case where hasArg is true
                                                   Option option = new Option("a", "arg", true, "description");
                                                   assertEquals("When hasArg is true, numberOfArgs should be 1", 
                                                                1, option.getArgs());
                                                   
                                                   // Test with different description to ensure it doesn't affect numberOfArgs
                                                   Option option2 = new Option("b", "arg2", true, "different description");
                                                   assertEquals("When hasArg is true, numberOfArgs should always be 1 regardless of description",
                                                                1, option2.getArgs());
                                                   
                                                   // Test with empty strings to ensure edge cases
                                                   Option option3 = new Option("", "", true, "");
                                                   assertEquals("When hasArg is true, numberOfArgs should be 1 even with empty strings",
                                                                1, option3.getArgs());
                                               }

    @Test
                                               public void testNumberOfArgsWhenHasArgIsFalse() {
                                                   // Test case where hasArg is false should not set numberOfArgs to 1
                                                   Option option = new Option("a", "arg", false, "description");
                                                   assertNotEquals("When hasArg is false, numberOfArgs should not be 1",
                                                                  1, option.getArgs());
                                               }

    @Test
                                          public void testConstructorWithShortOptionTreatsParamAsShortOpt() {
                                              // Arrange
                                              String shortOpt = "a"; // single character for short option
                                              String description = "test option";
                                              
                                              // Act
                                              Option option = new Option(shortOpt, null, false, description);
                                              
                                              // Assert
                                              // Verify opt is treated as short option
                                              assertEquals(shortOpt, option.getOpt());
                                              // Verify longOpt remains null (was passed as null)
                                              assertNull(option.getLongOpt());
                                              // Verify description was set correctly
                                              assertEquals(description, option.getDescription());
                                              // Verify hasLongOpt is false
                                              assertFalse(option.hasLongOpt());
                                          }

    @Test
                                              public void testConstructorWithShortOption1() {
                                                  // Arrange
                                                  String shortOpt = "s";
                                                  boolean hasArg = true;
                                                  String description = "Test option";
                                                  
                                                  // Act
                                                  Option option = new Option(shortOpt, null, hasArg, description);
                                                  
                                                  // Assert
                                                  // Verify opt is treated as short option
                                                  assertEquals("Short option should match input", shortOpt, option.getOpt());
                                                  assertNull("Long option should be null", option.getLongOpt());
                                                  assertEquals("Description should match", description, option.getDescription());
                                                  assertTrue("Should have argument", option.hasArg());
                                                  
                                                  // Additional verification that opt is stored as short option
                                                  // This would fail if opt was actually being treated as long option
                                                  assertFalse("Should not have long option", option.hasLongOpt());
                                              }

    @Test
                                         public void testConstructorValidatesShortOption1() {
                                             // Create test data - short option should be single character
                                             String shortOpt = "a";
                                             String longOpt = "alpha";
                                             boolean hasArg = true;
                                             String description = "test option";
                                             
                                             // Create the option - validation happens in constructor
                                             Option option = new Option(shortOpt, longOpt, hasArg, description);
                                             
                                             // Verify fields are set correctly
                                             assertEquals(shortOpt, option.getOpt());
                                             assertEquals(longOpt, option.getLongOpt());
                                             assertEquals(1, option.getArgs());
                                             assertEquals(description, option.getDescription());
                                         }

    @Test(expected = IllegalArgumentException.class)
                                         public void testConstructorRejectsLongOptionAsShortOpt() {
                                             // Try to create option with long form as short option
                                             // This should throw IllegalArgumentException because "invalid-long-opt" is not a valid short option
                                             new Option("invalid-long-opt", "valid-long", true, "should fail");
                                         }

    @Test
                                         public void testOptParameterShouldBeSingleCharacter() {
                                             // Test with valid single-character opt
                                             Option singleCharOption = new Option("a", true, "description");
                                             assertEquals("a", singleCharOption.getOpt());
                                             
                                             // Test with empty string opt (should this be allowed?)
                                             try {
                                                 Option emptyOption = new Option("", true, "description");
                                                 fail("Should throw IllegalArgumentException for empty opt");
                                             } catch (IllegalArgumentException e) {
                                                 // Expected
                                             }
                                             
                                             // Test with multi-character opt (should this be allowed?)
                                             try {
                                                 Option multiCharOption = new Option("abc", true, "description");
                                                 fail("Should throw IllegalArgumentException for multi-character opt");
                                             } catch (IllegalArgumentException e) {
                                                 // Expected
                                             }
                                             
                                             // Test with null opt
                                             try {
                                                 Option nullOption = new Option(null, true, "description");
                                                 fail("Should throw NullPointerException for null opt");
                                             } catch (NullPointerException e) {
                                                 // Expected
                                             }
                                         }

    @Test
                                    public void testOptParameterValidation() {
                                        // Test with valid single-character opt (should pass)
                                        try {
                                            new Option("a", "long", true, "description");
                                            // No exception expected - test passes
                                        } catch (IllegalArgumentException e) {
                                            fail("Valid single-character opt should not throw exception");
                                        }
                                        
                                        try {
                                            // Test with invalid multi-character opt (should fail)
                                            new Option("abc", "long", true, "description");
                                            fail("Expected IllegalArgumentException for multi-character opt");
                                        } catch (IllegalArgumentException e) {
                                            // Original behavior - test passes
                                            assertTrue(e.getMessage().contains("opt"));
                                        }
                                        
                                        // Additional edge case - empty string opt
                                        try {
                                            new Option("", "long", true, "description");
                                            fail("Expected IllegalArgumentException for empty opt");
                                        } catch (IllegalArgumentException e) {
                                            assertTrue(e.getMessage().contains("opt"));
                                        }
                                        
                                        // Null case
                                        try {
                                            new Option(null, "long", true, "description");
                                            fail("Expected IllegalArgumentException for null opt");
                                        } catch (IllegalArgumentException e) {
                                            assertTrue(e.getMessage().contains("opt"));
                                        }
                                    }

    @Test
                                    public void testConstructorParameterName() throws Exception {
                                        // Get the constructor with parameters (String, String, boolean, String)
                                        Constructor<?>[] constructors = Option.class.getDeclaredConstructors();
                                        Constructor<?> targetConstructor = null;
                                        
                                        for (Constructor<?> constructor : constructors) {
                                            Class<?>[] paramTypes = constructor.getParameterTypes();
                                            if (paramTypes.length == 4 && 
                                                paramTypes[0] == String.class && 
                                                paramTypes[1] == String.class && 
                                                paramTypes[2] == boolean.class && 
                                                paramTypes[3] == String.class) {
                                                targetConstructor = constructor;
                                                break;
                                            }
                                        }
                                        
                                        // Make sure we found the constructor
                                        assert targetConstructor != null;
                                        
                                        // Get the parameters
                                        Parameter[] parameters = targetConstructor.getParameters();
                                        
                                        // Verify the fourth parameter is named "description"
                                        assertEquals("Parameter name should be 'description'", 
                                                    "description", 
                                                    parameters[3].getName());
                                    }

    @Test
                                    public void testDescriptionParameterNameAndDocumentation() {
                                        // Test that the description parameter is properly named and documented
                                        String opt = "t";
                                        String longOpt = "test";
                                        String description = "Test option";
                                        boolean hasArg = true;
                                        
                                        // Create option with description
                                        Option option = new Option(opt, longOpt, hasArg, description);
                                        
                                        // Verify description was set correctly
                                        assertEquals(description, option.getDescription());
                                        
                                        // The following would fail if parameter name was changed to 'desc':
                                        try {
                                            Option.class.getMethod("setDescription", String.class);
                                        } catch (NoSuchMethodException e) {
                                            fail("Method setDescription(String) should exist");
                                        }
                                        
                                        // Verify the parameter name in the constructor matches documentation
                                        // This would catch if parameter name was changed to 'desc'
                                        try {
                                            java.lang.reflect.Constructor<?>[] constructors = Option.class.getConstructors();
                                            for (java.lang.reflect.Constructor<?> constructor : constructors) {
                                                java.lang.reflect.Parameter[] parameters = constructor.getParameters();
                                                for (java.lang.reflect.Parameter param : parameters) {
                                                    if (param.getName().equals("description")) {
                                                        return; // Found correctly named parameter
                                                    }
                                                }
                                            }
                                            fail("Constructor should have parameter named 'description'");
                                        } catch (Exception e) {
                                            fail("Exception while checking parameter names: " + e.getMessage());
                                        }
                                    }

    @Test
                                   public void testConstructorSetsDescriptionCorrectly2() {
                                       // Arrange
                                       String testOpt = "t";
                                       String testDescription = "test description";
                                       
                                       // Act - create option with test description
                                       Option option = new Option(testOpt, null, false, testDescription);
                                       
                                       // Assert - verify description was set correctly
                                       assertEquals("Description should match constructor argument", 
                                                   testDescription, option.getDescription());
                                       
                                       // Additional verification that description is properly used
                                       assertNotNull("Description should not be null", option.getDescription());
                                       assertTrue("Description should not be empty", 
                                                 !option.getDescription().isEmpty());
                                   }

    @Test
                               public void testConstructorSetsDescriptionCorrectly3() {
                                   // Arrange
                                   String testOpt = "t";
                                   boolean testHasArg = false;
                                   String testDescription = "Test description for the option";
                                   
                                   // Act
                                   Option option = new Option(testOpt, testHasArg, testDescription);
                                   
                                   // Assert
                                   assertEquals("Description should be exactly what was provided", 
                                                testDescription, 
                                                option.getDescription());
                                   assertNotNull("Description should not be null", option.getDescription());
                               }

    @Test
                                   public void testDescriptionFieldIsSetCorrectly() {
                                       // Arrange
                                       String opt = "t";
                                       String longOpt = "test";
                                       boolean hasArg = true;
                                       String description = "test description";
                                       
                                       // Act - This would normally be done via reflection since it's a constructor
                                       // For demonstration, we'll assume we can access the description field
                                       Option option = new Option(opt, longOpt, hasArg, description);
                                       
                                       // Assert
                                       assertEquals("Description field should be set correctly", 
                                                   description, option.getDescription());
                                   }

    @Test
                  public void testParameterJavaDoc() throws Exception {
                      // Get the validateOption method from Option class
                      Method method = Option.class.getMethod("validateOption", String.class);
                      
                      // Get parameters of the method
                      java.lang.reflect.Parameter[] parameters = method.getParameters();
                      
                      // Get parameter annotations to check for documentation
                      // Note: In Java 8, parameter names might not be available unless compiled with -parameters flag
                      // We'll check for any documentation in the parameter's annotations
                      String javaDoc = "";
                      for (java.lang.reflect.Parameter parameter : parameters) {
                          java.lang.annotation.Annotation[] annotations = parameter.getAnnotations();
                          for (java.lang.annotation.Annotation annotation : annotations) {
                              if (annotation.toString().contains("describes the function of the option")) {
                                  javaDoc = annotation.toString();
                                  break;
                              }
                          }
                          if (!javaDoc.isEmpty()) {
                              break;
                          }
                      }
                      
                      assertTrue("Parameter should have documentation describing the function of the option", 
                                !javaDoc.isEmpty() && javaDoc.contains("describes the function of the option"));
                  }

    @Test
                  public void testConstructorInitialization4() {
                      // Setup
                      String opt = "t";
                      String description = "test option";
                      
                      // Exercise
                      Option option = new Option(opt, null, false, description);
                      
                      // Verify
                      assertEquals("Short option not set correctly", opt, option.getOpt());
                      assertNull("Long option should be null", option.getLongOpt());
                      assertFalse("Required flag should be false", option.isRequired());
                      assertEquals("Description not set correctly", description, option.getDescription());
                  }

    @Test
              public void testConstructorWithNullLongOpt2() {
                  // Arrange
                  String expectedOpt = "testOpt";
                  boolean expectedHasArg = true;
                  String expectedDescription = "test description";
                  
                  // Act
                  Option option = new Option(expectedOpt, null, expectedHasArg, expectedDescription);
                  
                  // Assert
                  assertEquals("Short option should match input", expectedOpt, option.getOpt());
                  assertNull("Long option should be null", option.getLongOpt());
                  assertEquals("HasArg should match input", expectedHasArg, option.hasArg());
                  assertEquals("Description should match input", expectedDescription, option.getDescription());
                  
                  // Additional check to ensure opt wasn't modified by concatenation
                  assertSame("Opt string reference should be identical (no concatenation occurred)", 
                            expectedOpt, option.getOpt());
              }

    @Test
              public void testConstructorSetsNumberOfArgsCorrectly() {
                  // Test case where hasArg is true - should set numberOfArgs to exactly 1
                  String opt = "t";
                  String longOpt = "test";
                  String description = "test option";
                  boolean hasArg = true;
                  
                  Option option = new Option(opt, longOpt, hasArg, description);
                  
                  // Verify numberOfArgs is set to 1 (not incremented)
                  assertEquals(1, option.getArgs());
                  
                  // Test case where hasArg is false - numberOfArgs should remain uninitialized
                  hasArg = false;
                  Option option2 = new Option(opt, longOpt, hasArg, description);
                  
                  // Verify numberOfArgs is not set (should be UNINITIALIZED)
                  assertEquals(Option.UNINITIALIZED, option2.getArgs());
              }

    @Test
                 public void testConstructorWithOptAndDescription3() {
                     // Setup
                     String opt = "t";
                     String description = "test option";
                     
                     // Exercise
                     Option option = new Option(opt, description);
                     
                     // Verify
                     assertEquals("Short option not set correctly", opt, option.getOpt());
                     assertNull("Long option should be null", option.getLongOpt());
                     assertFalse("Option should not be required", option.isRequired());
                     assertEquals("Description not set correctly", description, option.getDescription());
                     assertEquals("Number of args should be UNINITIALIZED", 
                                  Option.UNINITIALIZED, option.getArgs());
                     assertFalse("Should not have optional arg", option.hasOptionalArg());
                 }

    @Test
                 public void testConstructorWithNullLongOpt3() {
                     // Test data
                     String opt = "t";
                     boolean hasArg = true;
                     String description = "test option";
                     
                     // Create option using the constructor
                     Option option = new Option(opt, null, hasArg, description);
                     
                     // Verify all fields are set correctly
                     assertEquals("Short option not set correctly", opt, option.getOpt());
                     assertNull("Long option should be null", option.getLongOpt());
                     assertEquals("hasArg not set correctly", hasArg, option.hasArg());
                     assertEquals("Description not set correctly", description, option.getDescription());
                     
                     // Additional verification that no values are set initially
                     assertFalse("Should not have values initially", option.hasArgs());
                     assertEquals("Should have 0 values initially", 0, option.getValuesList().size());
                 }

    @Test
                 public void testConstructorSetsNumberOfArgsOnlyWhenHasArgIsTrue() {
                     // Test case where hasArg is true
                     String opt = "t";
                     String longOpt = "test";
                     String description = "test option";
                     boolean hasArg = true;
                     
                     Option optionWithArg = new Option(opt, longOpt, hasArg, description);
                     assertEquals("Number of args should be 1 when hasArg is true", 1, optionWithArg.getArgs());
                     assertEquals(opt, optionWithArg.getOpt());
                     assertEquals(longOpt, optionWithArg.getLongOpt());
                     assertEquals(description, optionWithArg.getDescription());
                     
                     // Test case where hasArg is false
                     hasArg = false;
                     Option optionWithoutArg = new Option(opt, longOpt, hasArg, description);
                     assertEquals("Number of args should not be set when hasArg is false", 
                                 Option.UNINITIALIZED, optionWithoutArg.getArgs());
                     assertEquals(opt, optionWithoutArg.getOpt());
                     assertEquals(longOpt, optionWithoutArg.getLongOpt());
                     assertEquals(description, optionWithoutArg.getDescription());
                 }

    @Test
                public void testConstructorValidationWithInvalidShortOpt() {
                    // Test with invalid single-character option (contains invalid character)
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Invalid option name");
                    new Option("@", null, false, "description"); // '@' is invalid for option name
                }

    @Test
                public void testConstructorValidationWithNullShortOpt() {
                    // Test with null option name
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Invalid option name");
                    new Option(null, null, false, "description");
                }

    @Test
                public void testConstructorValidationWithEmptyShortOpt() {
                    // Test with empty option name
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Invalid option name");
                    new Option("", null, false, "description");
                }

    @Test
                public void testConstructorValidationWithMultiCharShortOpt() {
                    // Test with multi-character option name (should be single character)
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Invalid option name");
                    new Option("abc", null, false, "description");
                }

    @Test(expected = IllegalArgumentException.class)
                public void testConstructorWithInvalidOpt() {
                    // Test with invalid short option (null)
                    new Option(null, true, "description");
                }

    @Test(expected = IllegalArgumentException.class)
                public void testConstructorWithEmptyOpt1() {
                    // Test with empty short option
                    new Option("", true, "description");
                }

    @Test(expected = IllegalArgumentException.class)
                public void testConstructorWithInvalidDescription() {
                    // Test with null description
                    new Option("a", true, null);
                }

    @Test
                public void testConstructorWithValidArguments() {
                    // Test with valid arguments to ensure no exception is thrown
                    Option option = new Option("a", true, "valid description");
                    assertEquals("a", option.getOpt());
                    assertTrue(option.hasArg());
                    assertEquals("valid description", option.getDescription());
                }

    @Test
           public void testConstructorThrowsIllegalArgumentExceptionForInvalidOption() {
               // Set up test data with invalid option
               String invalidOpt = "invalid";  // This should trigger validation failure
               String longOpt = "longOption";
               boolean hasArg = true;
               String description = "description";
           
               // Expect exception
               thrown.expect(IllegalArgumentException.class);
               thrown.expectMessage("Invalid option");
           
               // Create option with invalid opt - should throw
               new Option(invalidOpt, longOpt, hasArg, description);
           }

    @Test
           public void testConstructorAcceptsValidOption() {
               // Set up test data
               String validOpt = "valid";
               String longOpt = "longOption";
               boolean hasArg = true;
               String description = "description";
           
               // Should not throw
               Option option = new Option(validOpt, longOpt, hasArg, description);
           
               // Verify option was created with correct values
               assertEquals(validOpt, option.getOpt());
               assertEquals(longOpt, option.getLongOpt());
               assertEquals(1, option.getArgs()); // Because hasArg is true
               assertEquals(description, option.getDescription());
           }

    @Test
           public void testOptionConstructorPreservesCase1() {
               // Test with lowercase option
               String lowerCaseOpt = "test";
               Option option1 = new Option(lowerCaseOpt, null, false, "description");
               assertEquals("Option should preserve lowercase opt", lowerCaseOpt, option1.getOpt());
               
               // Test with mixed case option
               String mixedCaseOpt = "TeSt";
               Option option2 = new Option(mixedCaseOpt, null, false, "description");
               assertEquals("Option should preserve mixed case opt", mixedCaseOpt, option2.getOpt());
               
               // Test with uppercase option
               String upperCaseOpt = "TEST";
               Option option3 = new Option(upperCaseOpt, null, false, "description");
               assertEquals("Option should preserve uppercase opt", upperCaseOpt, option3.getOpt());
           }

    @Test
           public void testOptionCaseSensitivity() {
               // Create two options with same letters but different cases
               Option lowerCaseOpt = new Option("a", null, true, "description");
               Option upperCaseOpt = new Option("A", null, true, "description");
               
               // Verify they are treated as different options
               assertNotEquals("Options with different cases should be different", 
                              lowerCaseOpt.getOpt(), 
                              upperCaseOpt.getOpt());
               
               // Verify each option maintains its original case
               assertEquals("a", lowerCaseOpt.getOpt());
               assertEquals("A", upperCaseOpt.getOpt());
           }

    @Test(expected = IllegalArgumentException.class)
           public void testValidateOptionCatchesInvalidOpt() {
               // This test should pass with original code (validation checks opt)
               // but fail with mutant (validation checks OPT instead)
               new Option("@", false, "description");
               // '@' is an invalid option character that should be caught by validation
               // If mutant checks OPT instead of opt, this test case would pass when it shouldn't
           }

    @Test
           public void testValidateOptionAcceptsValidOpt() {
               // Valid option character should work
               Option option = new Option("a", false, "description");
               assertEquals("a", option.getOpt());
           }

    @Test(expected = IllegalArgumentException.class)
           public void testValidateOptionRejectsNullOpt() {
               // Null opt should be rejected
               new Option(null, false, "description");
           }

    @Test(expected = IllegalArgumentException.class)
           public void testValidateOptionRejectsEmptyOpt() {
               // Empty opt should be rejected
               new Option("", false, "description");
           }

    @Test
          public void testOptionConstructorWithSpecialCharactersInOpt1() {
              // Test with special characters that should be handled differently
              String testOpt = "-@#$%";
              String description = "test description";
              
              Option option = new Option(testOpt, null, false, description);
              
              // Verify the opt string is stored exactly as passed (mutant behavior)
              // Original behavior might have modified/validated the opt string
              assertEquals("Option constructor should store opt string exactly as passed", 
                          testOpt, option.getOpt());
              
              // Additional verification that other fields are set correctly
              assertNull("Long option should be null", option.getLongOpt());
              assertFalse("Option should not be required", option.isRequired());
              assertEquals("Description should match", description, option.getDescription());
          }

    @Test
          public void testOptionConstructorWithEmptyOpt() {
              // Test edge case of empty opt string
              String testOpt = "";
              String description = "empty opt test";
              
              Option option = new Option(testOpt, null, false, description);
              
              assertEquals("Empty opt string should be stored as-is", 
                          testOpt, option.getOpt());
          }

    @Test
          public void testOptionConstructorWithNormalOpt() {
              // Test normal case
              String testOpt = "f";
              String description = "normal option test";
              
              Option option = new Option(testOpt, null, false, description);
              
              assertEquals("Normal opt string should be stored as-is", 
                          testOpt, option.getOpt());
          }

    @Test
          public void testOptionConstructorWithSpecialCharacters() {
              // Test with typical option characters
              Option option1 = new Option("a", true, "description");
              assertEquals("a", option1.getOpt());
              
              // Test with special characters that might need handling
              Option option2 = new Option("@", true, "description");
              assertEquals("@", option2.getOpt());
              
              // Test with multiple characters (if opt should only take single char)
              Option option3 = new Option("abc", true, "description");
              assertEquals("abc", option3.getOpt());
              
              // Test with empty string
              Option option4 = new Option("", true, "description");
              assertEquals("", option4.getOpt());
              
              // Test with null (should probably throw exception)
              try {
                  Option option5 = new Option(null, true, "description");
                  fail("Expected NullPointerException");
              } catch (NullPointerException e) {
                  // Expected behavior
              }
          }

    @Test(expected = IllegalArgumentException.class)
          public void testValidateOptionWithInvalidCharacter() {
              // Test with invalid option character (null)
              new Option(null, "longOpt", true, "description");
          }

    @Test(expected = IllegalArgumentException.class)
          public void testValidateOptionWithEmptyString() {
              // Test with empty string option
              new Option("", "longOpt", true, "description");
          }

    @Test(expected = IllegalArgumentException.class)
          public void testValidateOptionWithInvalidSpecialCharacter() {
              // Test with special character that's not allowed
              new Option("@", "longOpt", true, "description");
          }

    @Test
          public void testValidateOptionWithValidCharacter() {
              // Test with valid single character option
              Option option = new Option("a", "longOpt", true, "description");
              assertEquals("a", option.getOpt());
          }

    @Test
          public void testValidateOptionWithValidNumber() {
              // Test with valid number option
              Option option = new Option("1", "longOpt", true, "description");
              assertEquals("1", option.getOpt());
          }

    @Test
         public void testConstructorBehaviorWithMutatedComment() {
             // Test that the constructor works correctly despite comment mutation
             String opt = "t";
             String description = "test option";
             
             Option option = new Option(opt, null, false, description);
             
             // Verify all fields are set correctly
             assertEquals(opt, option.getOpt());
             assertNull(option.getLongOpt());
             assertFalse(option.isRequired());
             assertEquals(description, option.getDescription());
             
             // Verify toString() output isn't affected by comment mutation
             String toStringOutput = option.toString();
             assertNotNull(toStringOutput);
             assertTrue(toStringOutput.contains(opt));
             assertTrue(toStringOutput.contains(description));
             
             // Verify no values are set by default
             assertNull(option.getValue());
             assertEquals(0, option.getValuesList().size());
         }

    @Test
     public void testConstructorBehaviorWithHasArgTrue() {
         // Setup
         String opt = "t";
         String longOpt = "test";
         String description = "test option";
         boolean hasArg = true;
         
         // Execute
         Option option = new Option(opt, longOpt, hasArg, description);
         
         // Verify
         assertEquals(opt, option.getOpt());
         assertEquals(longOpt, option.getLongOpt());
         assertEquals(1, option.getArgs()); // Verify numberOfArgs is set correctly
         assertEquals(description, option.getDescription());
     }

    @Test
     public void testConstructorBehaviorWithHasArgFalse() {
         // Setup
         String opt = "t";
         String longOpt = "test";
         String description = "test option";
         boolean hasArg = false;
         
         // Execute
         Option option = new Option(opt, longOpt, hasArg, description);
         
         // Verify
         assertEquals(opt, option.getOpt());
         assertEquals(longOpt, option.getLongOpt());
         assertEquals(0, option.getArgs()); // Verify numberOfArgs remains default
         assertEquals(description, option.getDescription());
     }

    @Test
    public void testConstructorWithNullLongOpt4() {
        // Test that the constructor behaves correctly regardless of comment changes
        String opt = "t";
        boolean hasArg = true;
        String description = "test option";
        
        Option option = new Option(opt, hasArg, description);
        
        // Verify all fields are set correctly
        assertEquals(opt, option.getOpt());
        assertNull(option.getLongOpt());
        assertEquals(hasArg, option.hasArg());
        assertEquals(description, option.getDescription());
        
        // Verify no values are set initially by checking values list size
        assertEquals(0, option.getValuesList().size());
        
        // Verify other default values
        assertFalse(option.isRequired());
        assertFalse(option.hasOptionalArg());
        assertEquals(1, option.getArgs()); // Default for hasArg=true
    }


}
