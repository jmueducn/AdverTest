package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
 
public class PosixParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                            public void testProcess_WhenCurrentOptionIsNull() throws Exception {
                                                                                                // Arrange
                                                                                                PosixParser parser = new PosixParser();
                                                                                                String value = "testValue";
                                                                                                
                                                                                                // Get tokens field via reflection since it's private
                                                                                                java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                tokensField.setAccessible(true);
                                                                                                @SuppressWarnings("unchecked")
                                                                                                List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                
                                                                                                // Use reflection to verify eatTheRest is initially false
                                                                                                java.lang.reflect.Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                                                eatTheRestField.setAccessible(true);
                                                                                                assertFalse((boolean) eatTheRestField.get(parser));
                                                                                                
                                                                                                // Act
                                                                                                java.lang.reflect.Method method = PosixParser.class.getDeclaredMethod("process", String.class);
                                                                                                method.setAccessible(true);
                                                                                                method.invoke(parser, value);
                                                                                                
                                                                                                // Assert
                                                                                                assertEquals(2, tokens.size());
                                                                                                assertEquals("--", tokens.get(0));
                                                                                                assertEquals(value, tokens.get(1));
                                                                                                assertTrue((boolean) eatTheRestField.get(parser));
                                                                                            }

    @Test
                                                                                            public void testProcess_WhenCurrentOptionHasSingleArg() throws Exception {
                                                                                                // Arrange
                                                                                                String value = "argValue";
                                                                                                Option mockOption = mock(Option.class);
                                                                                                when(mockOption.hasArg()).thenReturn(true);
                                                                                                when(mockOption.hasArgs()).thenReturn(false);
                                                                                                
                                                                                                // Initialize parser and tokens
                                                                                                PosixParser parser = new PosixParser();
                                                                                                java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                tokensField.setAccessible(true);
                                                                                                @SuppressWarnings("unchecked")
                                                                                                List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                
                                                                                                // Set currentOption via reflection
                                                                                                java.lang.reflect.Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                                                currentOptionField.setAccessible(true);
                                                                                                currentOptionField.set(parser, mockOption);
                                                                                                
                                                                                                // Act
                                                                                                java.lang.reflect.Method method = PosixParser.class.getDeclaredMethod("process", String.class);
                                                                                                method.setAccessible(true);
                                                                                                method.invoke(parser, value);
                                                                                                
                                                                                                // Assert
                                                                                                assertEquals(1, tokens.size());
                                                                                                assertEquals(value, tokens.get(0));
                                                                                                
                                                                                                // Verify currentOption was set to null
                                                                                                assertNull(currentOptionField.get(parser));
                                                                                            }

    @Test
                                                                                            public void testProcess_WhenCurrentOptionHasMultipleArgs() throws Exception {
                                                                                                // Arrange
                                                                                                String value1 = "arg1";
                                                                                                String value2 = "arg2";
                                                                                                Option mockOption = mock(Option.class);
                                                                                                when(mockOption.hasArg()).thenReturn(false);
                                                                                                when(mockOption.hasArgs()).thenReturn(true);
                                                                                                
                                                                                                // Create parser instance and get tokens field
                                                                                                PosixParser parser = new PosixParser();
                                                                                                Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                tokensField.setAccessible(true);
                                                                                                @SuppressWarnings("unchecked")
                                                                                                List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                
                                                                                                // Set currentOption via reflection
                                                                                                Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                                                currentOptionField.setAccessible(true);
                                                                                                currentOptionField.set(parser, mockOption);
                                                                                                
                                                                                                // Act - process first value
                                                                                                Method method = PosixParser.class.getDeclaredMethod("process", String.class);
                                                                                                method.setAccessible(true);
                                                                                                method.invoke(parser, value1);
                                                                                                
                                                                                                // Assert after first value
                                                                                                assertEquals(1, tokens.size());
                                                                                                assertEquals(value1, tokens.get(0));
                                                                                                assertSame(mockOption, currentOptionField.get(parser)); // currentOption should remain
                                                                                                
                                                                                                // Act - process second value
                                                                                                method.invoke(parser, value2);
                                                                                                
                                                                                                // Assert after second value
                                                                                                assertEquals(2, tokens.size());
                                                                                                assertEquals(value1, tokens.get(0));
                                                                                                assertEquals(value2, tokens.get(1));
                                                                                                assertSame(mockOption, currentOptionField.get(parser)); // currentOption should remain
                                                                                            }

    @Test
                                                                                            public void testProcess_WhenCurrentOptionHasNoArgs() throws Exception {
                                                                                                // Arrange
                                                                                                PosixParser parser = new PosixParser();
                                                                                                List<String> tokens = new ArrayList<>();
                                                                                                
                                                                                                // Set tokens via reflection
                                                                                                java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                tokensField.setAccessible(true);
                                                                                                tokensField.set(parser, tokens);
                                                                                                
                                                                                                String value = "value";
                                                                                                Option mockOption = mock(Option.class);
                                                                                                when(mockOption.hasArg()).thenReturn(false);
                                                                                                when(mockOption.hasArgs()).thenReturn(false);
                                                                                                
                                                                                                // Set currentOption via reflection
                                                                                                java.lang.reflect.Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                                                currentOptionField.setAccessible(true);
                                                                                                currentOptionField.set(parser, mockOption);
                                                                                                
                                                                                                // Act
                                                                                                java.lang.reflect.Method method = PosixParser.class.getDeclaredMethod("process", String.class);
                                                                                                method.setAccessible(true);
                                                                                                method.invoke(parser, value);
                                                                                                
                                                                                                // Assert - should fall through to else case
                                                                                                assertEquals(2, tokens.size());
                                                                                                assertEquals("--", tokens.get(0));
                                                                                                assertEquals(value, tokens.get(1));
                                                                                                
                                                                                                // Verify eatTheRest was set to true
                                                                                                java.lang.reflect.Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                                                eatTheRestField.setAccessible(true);
                                                                                                assertTrue((boolean) eatTheRestField.get(parser));
                                                                                            }

    @Test
                                                                                        public void testFlatten_EmptyArguments() throws Exception {
                                                                                            Options options = new Options();
                                                                                            PosixParser parser = new PosixParser();
                                                                                            
                                                                                            // Use reflection to access protected flatten method
                                                                                            Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                                "flatten", 
                                                                                                Options.class, 
                                                                                                String[].class, 
                                                                                                boolean.class
                                                                                            );
                                                                                            flattenMethod.setAccessible(true);
                                                                                            
                                                                                            String[] result = (String[]) flattenMethod.invoke(
                                                                                                parser, 
                                                                                                options, 
                                                                                                new String[]{}, 
                                                                                                false
                                                                                            );
                                                                                            
                                                                                            assertNotNull(result);
                                                                                            assertEquals(0, result.length);
                                                                                        }

    @Test
                                                                                        public void testFlatten_LongOptionWithoutEquals() throws Exception {
                                                                                            Options options = mock(Options.class);
                                                                                            when(options.hasOption("--verbose")).thenReturn(true);
                                                                                            PosixParser parser = new PosixParser();
                                                                                            String[] args = {"--verbose"};
                                                                                            
                                                                                            // Use reflection to access protected flatten method
                                                                                            Method flattenMethod = PosixParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                                            flattenMethod.setAccessible(true);
                                                                                            String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                            
                                                                                            assertArrayEquals(new String[]{"--verbose"}, result);
                                                                                        }

    @Test
                                                                                        public void testFlatten_SingleHyphen() throws Exception {
                                                                                            Options options = new Options();
                                                                                            PosixParser parser = new PosixParser();
                                                                                            String[] args = {"-"};
                                                                                            
                                                                                            // Use reflection to access protected flatten method
                                                                                            Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                                "flatten", 
                                                                                                Options.class, 
                                                                                                String[].class, 
                                                                                                boolean.class
                                                                                            );
                                                                                            flattenMethod.setAccessible(true);
                                                                                            String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                            
                                                                                            assertArrayEquals(new String[]{"-"}, result);
                                                                                        }

    @Test
                                                                                        public void testFlatten_ShortOption() throws Exception {
                                                                                            // Create mock Options
                                                                                            Options options = mock(Options.class);
                                                                                            when(options.hasOption("-a")).thenReturn(true);
                                                                                            
                                                                                            // Create parser instance
                                                                                            PosixParser parser = new PosixParser();
                                                                                            
                                                                                            // Get the flatten method using reflection
                                                                                            Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                                "flatten", Options.class, String[].class, boolean.class);
                                                                                            flattenMethod.setAccessible(true);
                                                                                            
                                                                                            String[] args = {"-a"};
                                                                                            String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                            assertArrayEquals(new String[]{"-a"}, result);
                                                                                        }

    @Test
                                                                                        public void testFlatten_ShortOptionGroup() throws Exception {
                                                                                            // Create mock Options
                                                                                            Options options = mock(Options.class);
                                                                                            // Mock that options -a and -b exist but -ab doesn't
                                                                                            when(options.hasOption("-a")).thenReturn(true);
                                                                                            when(options.hasOption("-b")).thenReturn(true);
                                                                                            when(options.hasOption("-ab")).thenReturn(false);
                                                                                            
                                                                                            // Create parser instance
                                                                                            PosixParser parser = new PosixParser();
                                                                                            
                                                                                            // Get the flatten method using reflection
                                                                                            Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                                "flatten", Options.class, String[].class, boolean.class);
                                                                                            flattenMethod.setAccessible(true);
                                                                                            
                                                                                            String[] args = {"-ab"};
                                                                                            String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                            assertArrayEquals(new String[]{"-a", "-b"}, result);
                                                                                        }

    @Test
                                                                                        public void testFlatten_NonOptionToken() throws Exception {
                                                                                            Options options = new Options();
                                                                                            PosixParser parser = new PosixParser();
                                                                                            String[] args = {"filename.txt"};
                                                                                            
                                                                                            // Use reflection to access protected flatten method
                                                                                            Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                                "flatten", 
                                                                                                Options.class, 
                                                                                                String[].class, 
                                                                                                boolean.class
                                                                                            );
                                                                                            flattenMethod.setAccessible(true);
                                                                                            
                                                                                            String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                            assertArrayEquals(new String[]{"filename.txt"}, result);
                                                                                        }

    @Test
                                                                                        public void testFlatten_StopAtNonOption() throws Exception {
                                                                                            // Create required objects
                                                                                            Options options = new Options();
                                                                                            PosixParser parser = new PosixParser();
                                                                                            
                                                                                            // Define test inputs
                                                                                            String[] args = {"-a", "filename.txt", "-b"};
                                                                                            
                                                                                            // Get the protected flatten method using reflection
                                                                                            Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                                "flatten", 
                                                                                                Options.class, 
                                                                                                String[].class, 
                                                                                                boolean.class
                                                                                            );
                                                                                            flattenMethod.setAccessible(true);
                                                                                            
                                                                                            // Call method under test using reflection
                                                                                            String[] result = (String[]) flattenMethod.invoke(parser, options, args, true);
                                                                                            
                                                                                            // Verify results - should stop processing after filename.txt
                                                                                            assertArrayEquals(new String[]{"-a", "filename.txt"}, result);
                                                                                        }

    @Test
                                                                                        public void testFlatten_MixedArguments() throws Exception {
                                                                                            // Initialize required objects
                                                                                            Options options = mock(Options.class);
                                                                                            PosixParser parser = new PosixParser();
                                                                                            
                                                                                            // Mock behavior
                                                                                            when(options.hasOption("-a")).thenReturn(true);
                                                                                            when(options.hasOption("-b")).thenReturn(true);
                                                                                            when(options.hasOption("--output")).thenReturn(true);
                                                                                            
                                                                                            // Get the protected flatten method using reflection
                                                                                            Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                                "flatten", 
                                                                                                Options.class, 
                                                                                                String[].class, 
                                                                                                boolean.class
                                                                                            );
                                                                                            flattenMethod.setAccessible(true);
                                                                                            
                                                                                            String[] args = {"-a", "--output=out.txt", "file1", "-b", "file2"};
                                                                                            String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                            
                                                                                            assertArrayEquals(new String[]{"-a", "--output", "out.txt", "file1", "-b", "file2"}, result);
                                                                                        }

    @Test
                                                                                        public void testFlatten_NullOptions() throws Exception {
                                                                                            // Setup
                                                                                            PosixParser parser = new PosixParser();
                                                                                            ExpectedException exception = ExpectedException.none();
                                                                                            
                                                                                            // Expect exception
                                                                                            exception.expect(NullPointerException.class);
                                                                                            
                                                                                            // Get the protected flatten method using reflection
                                                                                            Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                                "flatten", 
                                                                                                Options.class, 
                                                                                                String[].class, 
                                                                                                boolean.class
                                                                                            );
                                                                                            flattenMethod.setAccessible(true);
                                                                                            
                                                                                            // Test
                                                                                            flattenMethod.invoke(parser, null, new String[]{"-a"}, false);
                                                                                        }

    @Test
                                                                                        public void testFlatten_NullArguments() throws Exception {
                                                                                            PosixParser parser = new PosixParser();
                                                                                            Options options = new Options();
                                                                                            
                                                                                            // Use reflection to access protected method
                                                                                            Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                                "flatten", 
                                                                                                Options.class, 
                                                                                                String[].class, 
                                                                                                boolean.class
                                                                                            );
                                                                                            flattenMethod.setAccessible(true);
                                                                                            flattenMethod.invoke(parser, options, null, false);
                                                                                        }

    @Test
                                                                                        public void testFlatten_UnknownOptionWithStopAtNonOption() throws Exception {
                                                                                            Options options = mock(Options.class);
                                                                                            when(options.hasOption("-x")).thenReturn(false);
                                                                                            PosixParser parser = new PosixParser();
                                                                                            String[] args = {"-x", "file.txt"};
                                                                                            
                                                                                            // Use reflection to access protected method
                                                                                            Method flattenMethod = PosixParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                                            flattenMethod.setAccessible(true);
                                                                                            String[] result = (String[]) flattenMethod.invoke(parser, options, args, true);
                                                                                            
                                                                                            assertArrayEquals(new String[]{"-x"}, result);
                                                                                        }

    @Test
                                                                                        public void testProcessOptionToken_ValidOption_StopAtNonOptionFalse() throws Exception {
                                                                                            // Setup
                                                                                            String token = "-a";
                                                                                            Options options = mock(Options.class);
                                                                                            Option mockOption = mock(Option.class);
                                                                                            
                                                                                            // Create parser instance and set private fields using reflection
                                                                                            PosixParser parser = new PosixParser();
                                                                                            Field optionsField = parser.getClass().getDeclaredField("options");
                                                                                            optionsField.setAccessible(true);
                                                                                            optionsField.set(parser, options);
                                                                                            
                                                                                            when(options.hasOption(token)).thenReturn(true);
                                                                                            when(options.getOption(token)).thenReturn(mockOption);
                                                                                            
                                                                                            // Get the private method and make it accessible
                                                                                            Method processOptionToken = parser.getClass().getDeclaredMethod(
                                                                                                "processOptionToken", String.class, boolean.class);
                                                                                            processOptionToken.setAccessible(true);
                                                                                            
                                                                                            // Execute
                                                                                            processOptionToken.invoke(parser, token, false);
                                                                                            
                                                                                            // Verify
                                                                                            verify(options).hasOption(token);
                                                                                            verify(options).getOption(token);
                                                                                            
                                                                                            // Check state changes using reflection
                                                                                            Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                                            tokensField.setAccessible(true);
                                                                                            @SuppressWarnings("unchecked")
                                                                                            List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                            
                                                                                            assertEquals(1, tokens.size());
                                                                                            assertEquals(token, tokens.get(0));
                                                                                            
                                                                                            Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                                                                            currentOptionField.setAccessible(true);
                                                                                            assertSame(mockOption, currentOptionField.get(parser));
                                                                                            
                                                                                            Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                                                                            eatTheRestField.setAccessible(true);
                                                                                            assertFalse((boolean) eatTheRestField.get(parser));
                                                                                        }

    @Test
                                                                                        public void testProcessOptionToken_ValidOption_StopAtNonOptionTrue() throws Exception {
                                                                                            // Setup
                                                                                            String token = "-b";
                                                                                            Options options = mock(Options.class);
                                                                                            Option mockOption = mock(Option.class);
                                                                                            
                                                                                            // Create parser instance and set private fields using reflection
                                                                                            PosixParser parser = new PosixParser();
                                                                                            Field optionsField = parser.getClass().getDeclaredField("options");
                                                                                            optionsField.setAccessible(true);
                                                                                            optionsField.set(parser, options);
                                                                                            
                                                                                            Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                                            tokensField.setAccessible(true);
                                                                                            tokensField.set(parser, new ArrayList<String>());
                                                                                            
                                                                                            when(options.hasOption(token)).thenReturn(true);
                                                                                            when(options.getOption(token)).thenReturn(mockOption);
                                                                                            
                                                                                            // Get the private method and make it accessible
                                                                                            Method processOptionTokenMethod = parser.getClass().getDeclaredMethod(
                                                                                                "processOptionToken", String.class, boolean.class);
                                                                                            processOptionTokenMethod.setAccessible(true);
                                                                                            
                                                                                            // Execute
                                                                                            processOptionTokenMethod.invoke(parser, token, true);
                                                                                            
                                                                                            // Verify
                                                                                            verify(options).hasOption(token);
                                                                                            verify(options).getOption(token);
                                                                                            
                                                                                            // Check state changes
                                                                                            @SuppressWarnings("unchecked")
                                                                                            List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                            assertEquals(1, tokens.size());
                                                                                            assertEquals(token, tokens.get(0));
                                                                                            
                                                                                            Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                                                                            currentOptionField.setAccessible(true);
                                                                                            assertSame(mockOption, currentOptionField.get(parser));
                                                                                            
                                                                                            Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                                                                            eatTheRestField.setAccessible(true);
                                                                                            assertFalse((boolean) eatTheRestField.get(parser));
                                                                                        }

    @Test
                                                                                        public void testProcessOptionToken_InvalidOption_StopAtNonOptionTrue() {
                                                                                            // Setup
                                                                                            String token = "invalid";
                                                                                            Options options = mock(Options.class);
                                                                                            when(options.hasOption(token)).thenReturn(false);
                                                                                            
                                                                                            // Create parser instance and set options using reflection
                                                                                            PosixParser parser = new PosixParser();
                                                                                            try {
                                                                                                Field optionsField = parser.getClass().getDeclaredField("options");
                                                                                                optionsField.setAccessible(true);
                                                                                                optionsField.set(parser, options);
                                                                                                
                                                                                                // Get and invoke the private method
                                                                                                Method processOptionTokenMethod = parser.getClass().getDeclaredMethod(
                                                                                                    "processOptionToken", String.class, boolean.class);
                                                                                                processOptionTokenMethod.setAccessible(true);
                                                                                                processOptionTokenMethod.invoke(parser, token, true);
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to set options field or invoke processOptionToken via reflection");
                                                                                            }
                                                                                            
                                                                                            // Verify
                                                                                            verify(options).hasOption(token);
                                                                                            
                                                                                            // Check state changes
                                                                                            try {
                                                                                                Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                                                tokensField.setAccessible(true);
                                                                                                @SuppressWarnings("unchecked")
                                                                                                List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                
                                                                                                assertEquals(1, tokens.size());
                                                                                                assertEquals(token, tokens.get(0));
                                                                                                
                                                                                                Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                                                                                currentOptionField.setAccessible(true);
                                                                                                assertNull(currentOptionField.get(parser));
                                                                                                
                                                                                                Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                                                                                eatTheRestField.setAccessible(true);
                                                                                                assertTrue((boolean) eatTheRestField.get(parser));
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to access private fields via reflection");
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testProcessOptionToken_InvalidOption_StopAtNonOptionFalse() throws Exception {
                                                                                            // Setup
                                                                                            String token = "invalid";
                                                                                            Options options = mock(Options.class);
                                                                                            when(options.hasOption(token)).thenReturn(false);
                                                                                            
                                                                                            PosixParser parser = new PosixParser();
                                                                                            // Use reflection to set private fields
                                                                                            Field optionsField = parser.getClass().getDeclaredField("options");
                                                                                            optionsField.setAccessible(true);
                                                                                            optionsField.set(parser, options);
                                                                                            
                                                                                            Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                                            tokensField.setAccessible(true);
                                                                                            tokensField.set(parser, new ArrayList<String>());
                                                                                            
                                                                                            // Get the private method and make it accessible
                                                                                            Method processOptionToken = parser.getClass().getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                                                            processOptionToken.setAccessible(true);
                                                                                            
                                                                                            // Execute
                                                                                            processOptionToken.invoke(parser, token, false);
                                                                                            
                                                                                            // Verify
                                                                                            verify(options).hasOption(token);
                                                                                            
                                                                                            // Check state changes
                                                                                            @SuppressWarnings("unchecked")
                                                                                            List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                            assertTrue(tokens.isEmpty());
                                                                                            
                                                                                            Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                                                                            currentOptionField.setAccessible(true);
                                                                                            assertNull(currentOptionField.get(parser));
                                                                                            
                                                                                            Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                                                                            eatTheRestField.setAccessible(true);
                                                                                            assertFalse((boolean) eatTheRestField.get(parser));
                                                                                        }

    @Test
                                                                                    public void testFlatten_LongOptionWithEquals() throws Exception {
                                                                                        Options options = mock(Options.class);
                                                                                        when(options.hasOption("--config")).thenReturn(true);
                                                                                        PosixParser parser = new PosixParser();
                                                                                        String[] args = {"--config=file.txt"};
                                                                                        
                                                                                        // Use reflection to access protected method
                                                                                        Method flattenMethod = PosixParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                                        flattenMethod.setAccessible(true);
                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                        
                                                                                        assertArrayEquals(new String[]{"--config", "file.txt"}, result);
                                                                                    }

    @Test
                                                                                    public void testFlatten_ComplexOptionGroup() throws Exception {
                                                                                        // Initialize required objects
                                                                                        Options options = mock(Options.class);
                                                                                        PosixParser parser = new PosixParser();
                                                                                        
                                                                                        // Mock behavior
                                                                                        when(options.hasOption("-a")).thenReturn(true);
                                                                                        when(options.hasOption("-b")).thenReturn(true);
                                                                                        when(options.hasOption("-c")).thenReturn(true);
                                                                                        when(options.hasOption("-abc")).thenReturn(false);
                                                                                        
                                                                                        // Get the protected flatten method using reflection
                                                                                        Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                            "flatten", 
                                                                                            Options.class, 
                                                                                            String[].class, 
                                                                                            boolean.class
                                                                                        );
                                                                                        flattenMethod.setAccessible(true);
                                                                                        
                                                                                        String[] args = {"-abc"};
                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                        assertArrayEquals(new String[]{"-a", "-b", "-c"}, result);
                                                                                    }

    @Test(expected = NullPointerException.class)
                                                                                    public void testProcessOptionToken_NullToken_ShouldThrowException() throws Exception {
                                                                                        PosixParser parser = new PosixParser();
                                                                                        Method method = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                                                        method.setAccessible(true);
                                                                                        method.invoke(parser, null, true);
                                                                                    }

    @Test
                                                                                    public void testProcessOptionToken_EmptyToken_ShouldBeTreatedAsInvalidOption() throws Exception {
                                                                                        // Setup
                                                                                        String token = "";
                                                                                        Options options = mock(Options.class);
                                                                                        when(options.hasOption(token)).thenReturn(false);
                                                                                        
                                                                                        // Create parser instance and set private fields using reflection
                                                                                        PosixParser parser = new PosixParser();
                                                                                        Field optionsField = parser.getClass().getDeclaredField("options");
                                                                                        optionsField.setAccessible(true);
                                                                                        optionsField.set(parser, options);
                                                                                        
                                                                                        Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                                        tokensField.setAccessible(true);
                                                                                        tokensField.set(parser, new ArrayList<String>());
                                                                                        
                                                                                        // Get and invoke the private method
                                                                                        Method processOptionTokenMethod = parser.getClass().getDeclaredMethod(
                                                                                            "processOptionToken", String.class, boolean.class);
                                                                                        processOptionTokenMethod.setAccessible(true);
                                                                                        processOptionTokenMethod.invoke(parser, token, true);
                                                                                        
                                                                                        // Verify
                                                                                        verify(options).hasOption(token);
                                                                                        
                                                                                        // Check state changes
                                                                                        List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                        assertEquals(1, tokens.size());
                                                                                        assertEquals(token, tokens.get(0));
                                                                                        
                                                                                        Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                                                                        currentOptionField.setAccessible(true);
                                                                                        assertNull(currentOptionField.get(parser));
                                                                                        
                                                                                        Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                                                                        eatTheRestField.setAccessible(true);
                                                                                        assertTrue((boolean) eatTheRestField.get(parser));
                                                                                    }

    @Test
                                                                               public void testProcessOptionToken_NonOptionWithStopAtNonOptionFalse() throws Exception {
                                                                                   // Setup
                                                                                   PosixParser parser = new PosixParser();
                                                                                   Options options = mock(Options.class);
                                                                                   when(options.hasOption(anyString())).thenReturn(false); // Token is not a valid option
                                                                                   
                                                                                   // Use reflection to set private fields since no constructor
                                                                                   Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                   optionsField.setAccessible(true);
                                                                                   optionsField.set(parser, options);
                                                                                   
                                                                                   Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                                   eatTheRestField.setAccessible(true);
                                                                                   eatTheRestField.set(parser, false); // Initial state
                                                                                   
                                                                                   Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                   tokensField.setAccessible(true);
                                                                                   @SuppressWarnings("unchecked")
                                                                                   List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                   if (tokens == null) {
                                                                                       tokens = new ArrayList<>();
                                                                                       tokensField.set(parser, tokens);
                                                                                   }
                                                                                   
                                                                                   // Get the private method and make it accessible
                                                                                   Method processOptionTokenMethod = PosixParser.class.getDeclaredMethod(
                                                                                       "processOptionToken", String.class, boolean.class);
                                                                                   processOptionTokenMethod.setAccessible(true);
                                                                                   
                                                                                   // Test
                                                                                   String token = "invalidToken";
                                                                                   processOptionTokenMethod.invoke(parser, token, false); // stopAtNonOption = false
                                                                                   
                                                                                   // Verify
                                                                                   assertFalse((boolean) eatTheRestField.get(parser)); // Should remain false
                                                                                   assertTrue(tokens.contains(token)); // Token should still be added
                                                                               }

    @Test
                                                                          public void testProcessOptionToken_DetectsHasArgsMutant() throws Exception {
                                                                              // Setup test data
                                                                              PosixParser parser = new PosixParser();
                                                                              String token = "-f";
                                                                              boolean stopAtNonOption = false;
                                                                              
                                                                              // Mock dependencies
                                                                              Options options = mock(Options.class);
                                                                              Option option = mock(Option.class);
                                                                              
                                                                              // Set mock behaviors
                                                                              when(options.hasOption(token)).thenReturn(true);
                                                                              when(options.getOption(token)).thenReturn(option);
                                                                              when(option.hasArgs()).thenReturn(true);  // Option has arguments
                                                                              
                                                                              // Inject mocks
                                                                              Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                              optionsField.setAccessible(true);
                                                                              optionsField.set(parser, options);
                                                                              
                                                                              // Get and invoke private method
                                                                              Method processOptionTokenMethod = PosixParser.class.getDeclaredMethod(
                                                                                  "processOptionToken", String.class, boolean.class);
                                                                              processOptionTokenMethod.setAccessible(true);
                                                                              processOptionTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                              
                                                                              // Verify behavior - original would process, mutant would not
                                                                              Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                              tokensField.setAccessible(true);
                                                                              List<String> tokens = (List<String>) tokensField.get(parser);
                                                                              
                                                                              // Assert token was added (original behavior)
                                                                              assertTrue(tokens.contains(token));
                                                                              
                                                                              // Also verify eatTheRest remains false
                                                                              Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                              eatTheRestField.setAccessible(true);
                                                                              assertFalse(eatTheRestField.getBoolean(parser));
                                                                          }

    @Test
                                                                          public void testProcessOptionTokenWithNullCurrentOption() {
                                                                              // Setup
                                                                              PosixParser parser = new PosixParser();
                                                                              String token = "invalidToken";
                                                                              
                                                                              // Mock dependencies
                                                                              Options options = mock(Options.class);
                                                                              when(options.hasOption(token)).thenReturn(false);
                                                                              
                                                                              // Use reflection to set private fields since no constructor
                                                                              try {
                                                                                  java.lang.reflect.Field optionsField = parser.getClass().getDeclaredField("options");
                                                                                  optionsField.setAccessible(true);
                                                                                  optionsField.set(parser, options);
                                                                                  
                                                                                  java.lang.reflect.Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                                  tokensField.setAccessible(true);
                                                                                  tokensField.set(parser, new ArrayList<String>());
                                                                                  
                                                                                  java.lang.reflect.Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                                                                  currentOptionField.setAccessible(true);
                                                                                  currentOptionField.set(parser, null); // Explicitly set currentOption to null
                                                                              } catch (Exception e) {
                                                                                  fail("Failed to set up test via reflection");
                                                                              }
                                                                              
                                                                              // Test the method
                                                                              try {
                                                                                  // Call private method via reflection
                                                                                  java.lang.reflect.Method method = parser.getClass().getDeclaredMethod(
                                                                                      "processOptionToken", String.class, boolean.class);
                                                                                  method.setAccessible(true);
                                                                                  method.invoke(parser, token, false);
                                                                                  
                                                                                  // Verify behavior
                                                                                  // Original would throw NPE, mutant would continue
                                                                                  // So if we get here without exception, mutant survived
                                                                                  fail("Expected NullPointerException but none was thrown");
                                                                              } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                  // Check if the cause is NPE (original behavior)
                                                                                  assertTrue("Expected NullPointerException", 
                                                                                      e.getCause() instanceof NullPointerException);
                                                                              } catch (Exception e) {
                                                                                  fail("Unexpected exception: " + e);
                                                                              }
                                                                          }

    @Test
                                                                    public void testProcessOptionToken_AddsTokenWhenOptionExists() throws Exception {
                                                                        // Setup
                                                                        PosixParser parser = new PosixParser();
                                                                        Options options = mock(Options.class);
                                                                        
                                                                        // Set private options field using reflection
                                                                        Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                        optionsField.setAccessible(true);
                                                                        optionsField.set(parser, options);
                                                                        
                                                                        // Set private tokens field using reflection
                                                                        Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                        tokensField.setAccessible(true);
                                                                        tokensField.set(parser, new ArrayList<>());
                                                                        
                                                                        String testToken = "-f";
                                                                        when(options.hasOption(testToken)).thenReturn(true);
                                                                        
                                                                        // Get private processOptionToken method using reflection
                                                                        Method processOptionTokenMethod = PosixParser.class.getDeclaredMethod(
                                                                            "processOptionToken", String.class, boolean.class);
                                                                        processOptionTokenMethod.setAccessible(true);
                                                                        
                                                                        // Execute
                                                                        processOptionTokenMethod.invoke(parser, testToken, false);
                                                                        
                                                                        // Verify
                                                                        @SuppressWarnings("unchecked")
                                                                        List<String> tokens = (List<String>) tokensField.get(parser);
                                                                        assertTrue("Token should be present in tokens list", 
                                                                                  tokens.contains(testToken));
                                                                        assertEquals("Tokens list should have exactly one element", 
                                                                                   1, tokens.size());
                                                                    }

    @Test
                                                                    public void testProcessOptionToken_AddsTokenWhenStopAtNonOption() throws Exception {
                                                                        // Setup
                                                                        PosixParser parser = new PosixParser();
                                                                        Options options = mock(Options.class);
                                                                        
                                                                        // Set private fields using reflection
                                                                        Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                        optionsField.setAccessible(true);
                                                                        optionsField.set(parser, options);
                                                                        
                                                                        Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                        tokensField.setAccessible(true);
                                                                        tokensField.set(parser, new ArrayList<>());
                                                                        
                                                                        String testToken = "nonOption";
                                                                        when(options.hasOption(testToken)).thenReturn(false);
                                                                        
                                                                        // Get and invoke private method using reflection
                                                                        Method processOptionToken = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                                        processOptionToken.setAccessible(true);
                                                                        processOptionToken.invoke(parser, testToken, true);
                                                                        
                                                                        // Verify
                                                                        List<?> tokens = (List<?>) tokensField.get(parser);
                                                                        assertTrue("Token should be present in tokens list", 
                                                                                  tokens.contains(testToken));
                                                                        
                                                                        Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                        eatTheRestField.setAccessible(true);
                                                                        assertTrue("eatTheRest should be set to true", 
                                                                                  (boolean) eatTheRestField.get(parser));
                                                                        
                                                                        assertEquals("Tokens list should have exactly one element", 
                                                                                  1, tokens.size());
                                                                    }

    @Test
                                                               public void testProcessOptionToken_ValidOption_AddsActualToken() throws Exception {
                                                                   // Setup
                                                                   String testToken = "-f";
                                                                   Options options = mock(Options.class);
                                                                   when(options.hasOption(testToken)).thenReturn(true);
                                                                   Option mockOption = mock(Option.class);
                                                                   when(options.getOption(testToken)).thenReturn(mockOption);
                                                                   
                                                                   PosixParser parser = new PosixParser();
                                                                   // Access the private tokens field via reflection
                                                                   Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                   tokensField.setAccessible(true);
                                                                   @SuppressWarnings("unchecked")
                                                                   List<String> tokens = (List<String>) tokensField.get(parser);
                                                                   
                                                                   // Execute
                                                                   java.lang.reflect.Method method = PosixParser.class.getDeclaredMethod(
                                                                       "processOptionToken", String.class, boolean.class);
                                                                   method.setAccessible(true);
                                                                   method.invoke(parser, testToken, false);
                                                                   
                                                                   // Verify
                                                                   assertEquals("Token list should contain the actual token", 
                                                                       1, tokens.size());
                                                                   assertEquals("Token should be added to tokens list", 
                                                                       testToken, tokens.get(0));
                                                               }

    @Test
                                                               public void testProcessOptionToken_NonOptionWithStop_AddsActualToken() throws Exception {
                                                                   // Setup
                                                                   Options options = mock(Options.class);
                                                                   List<String> tokens = new ArrayList<>();
                                                                   PosixParser parser = new PosixParser();
                                                                   
                                                                   // Set up private fields using reflection
                                                                   Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                   optionsField.setAccessible(true);
                                                                   optionsField.set(parser, options);
                                                                   
                                                                   Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                   tokensField.setAccessible(true);
                                                                   tokensField.set(parser, tokens);
                                                                   
                                                                   String testToken = "file.txt";
                                                                   when(options.hasOption(testToken)).thenReturn(false);
                                                                   
                                                                   // Execute
                                                                   java.lang.reflect.Method method = PosixParser.class.getDeclaredMethod(
                                                                       "processOptionToken", String.class, boolean.class);
                                                                   method.setAccessible(true);
                                                                   method.invoke(parser, testToken, true);
                                                                   
                                                                   // Verify
                                                                   assertEquals("Token list should contain the actual token", 
                                                                       1, tokens.size());
                                                                   assertEquals("Token should be added to tokens list", 
                                                                       testToken, tokens.get(0));
                                                                   
                                                                   // Also verify eatTheRest was set
                                                                   java.lang.reflect.Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                   eatTheRestField.setAccessible(true);
                                                                   assertTrue("eatTheRest should be true", 
                                                                       (boolean) eatTheRestField.get(parser));
                                                               }

    @Test
                                                          public void testProcessOptionToken_AddsTokenWhenOptionExists1() throws Exception {
                                                              // Setup
                                                              PosixParser parser = new PosixParser();
                                                              Options options = mock(Options.class);
                                                              
                                                              // Set private fields using reflection
                                                              Field optionsField = PosixParser.class.getDeclaredField("options");
                                                              optionsField.setAccessible(true);
                                                              optionsField.set(parser, options);
                                                              
                                                              Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                              tokensField.setAccessible(true);
                                                              tokensField.set(parser, new ArrayList<>());
                                                              
                                                              String testToken = "-f";
                                                              Option testOption = mock(Option.class);
                                                              
                                                              when(options.hasOption(testToken)).thenReturn(true);
                                                              when(options.getOption(testToken)).thenReturn(testOption);
                                                              
                                                              // Get private method using reflection
                                                              Method processOptionTokenMethod = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                              processOptionTokenMethod.setAccessible(true);
                                                              
                                                              // Execute
                                                              processOptionTokenMethod.invoke(parser, testToken, false);
                                                              
                                                              // Verify
                                                              Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                              currentOptionField.setAccessible(true);
                                                              Option currentOption = (Option) currentOptionField.get(parser);
                                                              
                                                              List<?> tokens = (List<?>) tokensField.get(parser);
                                                              
                                                              assertSame(testOption, currentOption);
                                                              assertEquals(1, tokens.size());
                                                              assertEquals(testToken, tokens.get(0));
                                                          }

    @Test
                                                          public void testProcessOptionToken_AddsTokenWhenStopAtNonOption1() throws Exception {
                                                              // Setup
                                                              PosixParser parser = new PosixParser();
                                                              Options options = mock(Options.class);
                                                              
                                                              // Set private fields using reflection
                                                              Field optionsField = PosixParser.class.getDeclaredField("options");
                                                              optionsField.setAccessible(true);
                                                              optionsField.set(parser, options);
                                                              
                                                              Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                              tokensField.setAccessible(true);
                                                              tokensField.set(parser, new ArrayList<>());
                                                              
                                                              String testToken = "nonOption";
                                                              
                                                              when(options.hasOption(testToken)).thenReturn(false);
                                                              
                                                              // Access private method using reflection
                                                              Method processOptionToken = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                              processOptionToken.setAccessible(true);
                                                              
                                                              // Execute
                                                              processOptionToken.invoke(parser, testToken, true);
                                                              
                                                              // Verify
                                                              Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                              eatTheRestField.setAccessible(true);
                                                              assertTrue((boolean) eatTheRestField.get(parser));
                                                              
                                                              List<?> tokens = (List<?>) tokensField.get(parser);
                                                              assertEquals(1, tokens.size());
                                                              assertEquals(testToken, tokens.get(0));
                                                          }

    @Test
                                                     public void testProcessOptionToken_AddsActualTokenNotNull() throws Exception {
                                                         // Setup
                                                         PosixParser parser = new PosixParser();
                                                         List<String> tokens = new ArrayList<>();
                                                         
                                                         // Use reflection to set private fields
                                                         Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                         tokensField.setAccessible(true);
                                                         tokensField.set(parser, tokens);
                                                         
                                                         Options options = mock(Options.class);
                                                         Field optionsField = PosixParser.class.getDeclaredField("options");
                                                         optionsField.setAccessible(true);
                                                         optionsField.set(parser, options);
                                                         
                                                         String testToken = "testToken";
                                                         
                                                         // Get private method
                                                         Method processOptionToken = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                         processOptionToken.setAccessible(true);
                                                         
                                                         // Test case 1: When hasOption is true
                                                         when(options.hasOption(testToken)).thenReturn(true);
                                                         Option mockOption = mock(Option.class);
                                                         when(options.getOption(testToken)).thenReturn(mockOption);
                                                         
                                                         processOptionToken.invoke(parser, testToken, false);
                                                         
                                                         // Verify token was added (not null)
                                                         assertEquals(1, tokens.size());
                                                         assertEquals(testToken, tokens.get(0));
                                                         
                                                         // Clear for next test
                                                         tokens.clear();
                                                         Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                         currentOptionField.setAccessible(true);
                                                         currentOptionField.set(parser, null);
                                                         
                                                         // Test case 2: When hasOption is false and stopAtNonOption is true
                                                         when(options.hasOption(testToken)).thenReturn(false);
                                                         
                                                         processOptionToken.invoke(parser, testToken, true);
                                                         
                                                         // Verify token was added (not null) and eatTheRest was set
                                                         assertEquals(1, tokens.size());
                                                         assertEquals(testToken, tokens.get(0));
                                                         
                                                         Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                         eatTheRestField.setAccessible(true);
                                                         assertTrue((boolean) eatTheRestField.get(parser));
                                                     }

    @Test
                                            public void testProcessOptionToken_CallsProcessWithCorrectToken() throws Exception {
                                                // Setup
                                                PosixParser parser = new PosixParser();
                                                Options options = mock(Options.class);
                                                
                                                // Use reflection to set private options field
                                                Field optionsField = PosixParser.class.getDeclaredField("options");
                                                optionsField.setAccessible(true);
                                                optionsField.set(parser, options);
                                                
                                                // Mock behavior - treat token as valid option
                                                String testToken = "-f";
                                                when(options.hasOption(testToken.substring(1))).thenReturn(true);
                                                when(options.getOption(testToken.substring(1))).thenReturn(new Option("f", false, ""));
                                                
                                                // Create a spy of the parser
                                                PosixParser spyParser = spy(parser);
                                                
                                                // Use reflection to call private processOptionToken method
                                                Method processOptionTokenMethod = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                processOptionTokenMethod.setAccessible(true);
                                                processOptionTokenMethod.invoke(spyParser, testToken, false);
                                                
                                                // Verify process() was called by checking its side effects
                                                Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                tokensField.setAccessible(true);
                                                @SuppressWarnings("unchecked")
                                                List<String> tokens = (List<String>) tokensField.get(spyParser);
                                                assertTrue(tokens.contains(testToken));
                                                
                                                // Additional assertions for other behaviors using reflection
                                                Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                eatTheRestField.setAccessible(true);
                                                assertFalse((boolean) eatTheRestField.get(spyParser));
                                                
                                                Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                currentOptionField.setAccessible(true);
                                                assertNotNull(currentOptionField.get(spyParser));
                                            }

    @Test
                                       public void testProcessOptionToken_DetectsEatTheRestMutant() {
                                           // Setup
                                           PosixParser parser = new PosixParser();
                                           
                                           // Mock dependencies
                                           Options options = mock(Options.class);
                                           when(options.hasOption(anyString())).thenReturn(false); // Not a valid option
                                           
                                           // Use reflection to set private fields since no constructor
                                           try {
                                               java.lang.reflect.Field optionsField = PosixParser.class.getDeclaredField("options");
                                               optionsField.setAccessible(true);
                                               optionsField.set(parser, options);
                                               
                                               java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                               tokensField.setAccessible(true);
                                               tokensField.set(parser, new ArrayList<String>());
                                           } catch (Exception e) {
                                               fail("Failed to set up test due to reflection error");
                                           }
                                           
                                           // Get the private method using reflection
                                           try {
                                               Method processOptionToken = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                               processOptionToken.setAccessible(true);
                                               
                                               // Test case 1: stopAtNonOption is true
                                               processOptionToken.invoke(parser, "testToken", true);
                                               
                                               // Verify eatTheRest was set to true (would fail if mutant is active)
                                               java.lang.reflect.Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                               eatTheRestField.setAccessible(true);
                                               assertTrue("eatTheRest should be true when stopAtNonOption is true", 
                                                         (boolean) eatTheRestField.get(parser));
                                               
                                               // Reset eatTheRest for next test case
                                               eatTheRestField.set(parser, false);
                                               
                                               // Test case 2: stopAtNonOption is false (shouldn't reach the branch, but mutant would behave differently)
                                               processOptionToken.invoke(parser, "testToken", false);
                                               
                                               // Verify eatTheRest remains false (mutant would set it to false if branch was somehow reached)
                                               assertFalse("eatTheRest should remain false when stopAtNonOption is false", 
                                                          (boolean) eatTheRestField.get(parser));
                                           } catch (Exception e) {
                                               fail("Failed to invoke private method or verify fields: " + e.getMessage());
                                           }
                                       }

    @Test
                                  public void testProcessOptionToken_DetectsHasArgsMutant1() throws Exception {
                                      // Setup test data
                                      PosixParser parser = new PosixParser();
                                      String token = "testToken";
                                      boolean stopAtNonOption = false;
                                      
                                      // Mock dependencies
                                      Options options = mock(Options.class);
                                      Option option = mock(Option.class);
                                      
                                      // Set mock behaviors
                                      when(options.hasOption(token)).thenReturn(true);
                                      when(options.getOption(token)).thenReturn(option);
                                      when(option.hasArgs()).thenReturn(true);  // Critical for detecting mutant
                                      
                                      // Use reflection to set private fields
                                      Field optionsField = PosixParser.class.getDeclaredField("options");
                                      optionsField.setAccessible(true);
                                      optionsField.set(parser, options);
                                      
                                      Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                      tokensField.setAccessible(true);
                                      tokensField.set(parser, new ArrayList<String>());
                                      
                                      // Use reflection to access private method
                                      Method processOptionToken = PosixParser.class.getDeclaredMethod(
                                          "processOptionToken", String.class, boolean.class);
                                      processOptionToken.setAccessible(true);
                                      processOptionToken.invoke(parser, token, stopAtNonOption);
                                      
                                      // Verify behavior - original would add token, mutant would not
                                      @SuppressWarnings("unchecked")
                                      List<String> tokens = (List<String>) tokensField.get(parser);
                                      assertTrue("Token should be added when option has args", tokens.contains(token));
                                      
                                      // Verify eatTheRest remains false
                                      Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                      eatTheRestField.setAccessible(true);
                                      boolean eatTheRest = (boolean) eatTheRestField.get(parser);
                                      assertFalse("eatTheRest should remain false", eatTheRest);
                                  }

    @Test
                             public void testProcessOptionTokenWithNullCurrentOption1() throws Exception {
                                 // Setup
                                 PosixParser parser = new PosixParser();
                                 
                                 // Mock dependencies
                                 Options options = mock(Options.class);
                                 Option option = mock(Option.class);
                                 
                                 // Set up test conditions
                                 String token = "testToken";
                                 when(options.hasOption(token)).thenReturn(false);
                                 
                                 // Use reflection to set private fields
                                 Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                 currentOptionField.setAccessible(true);
                                 currentOptionField.set(parser, null);
                                 
                                 // Set up the tokens list
                                 List<String> tokensList = new ArrayList<>();
                                 Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                 tokensField.setAccessible(true);
                                 tokensField.set(parser, tokensList);
                                 
                                 // Set stopAtNonOption to false to reach the mutated condition
                                 boolean stopAtNonOption = false;
                                 
                                 // Use reflection to call private method
                                 Method processOptionTokenMethod = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                 processOptionTokenMethod.setAccessible(true);
                                 processOptionTokenMethod.invoke(parser, token, stopAtNonOption);
                                 
                                 // Verify behavior using reflection
                                 Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                 eatTheRestField.setAccessible(true);
                                 assertFalse((Boolean) eatTheRestField.get(parser)); // Should remain false
                                 
                                 assertEquals(0, tokensList.size()); // Should not add token
                                 assertNull(currentOptionField.get(parser)); // Should still be null
                                 
                                 // Verify mock interactions
                                 verify(options).hasOption(token);
                                 verifyNoMoreInteractions(options, option);
                             }

    @Test
                        public void testProcessOptionToken_DetectsAddToTokensMutation() throws Exception {
                            // Setup test data
                            String testToken = "testToken";
                            Options options = mock(Options.class);
                            when(options.hasOption(testToken)).thenReturn(true);
                            Option mockOption = mock(Option.class);
                            when(options.getOption(testToken)).thenReturn(mockOption);
                            
                            // Create parser instance
                            PosixParser parser = new PosixParser();
                            
                            // Use reflection to set private fields
                            Field optionsField = PosixParser.class.getDeclaredField("options");
                            optionsField.setAccessible(true);
                            optionsField.set(parser, options);
                            
                            Field tokensField = PosixParser.class.getDeclaredField("tokens");
                            tokensField.setAccessible(true);
                            tokensField.set(parser, new ArrayList<>()); // Start with empty list
                            
                            // Get private method and make it accessible
                            Method processOptionToken = PosixParser.class.getDeclaredMethod(
                                "processOptionToken", String.class, boolean.class);
                            processOptionToken.setAccessible(true);
                            
                            // Call method under test
                            processOptionToken.invoke(parser, testToken, false);
                            
                            // Verify behavior - original would add token, mutant would remove
                            // Get tokens list via reflection
                            @SuppressWarnings("unchecked")
                            List<String> tokens = (List<String>) tokensField.get(parser);
                            
                            // Check token was added (would fail if mutant is present)
                            assertEquals(1, tokens.size());
                            assertEquals(testToken, tokens.get(0));
                            
                            // Also verify currentOption was set
                            Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                            currentOptionField.setAccessible(true);
                            assertEquals(mockOption, currentOptionField.get(parser));
                        }

    @Test
                        public void testProcessOptionToken_StopAtNonOption_DetectsAddToTokensMutation() throws Exception {
                            // Setup test data
                            String testToken = "nonOptionToken";
                            Options options = mock(Options.class);
                            when(options.hasOption(testToken)).thenReturn(false);
                            
                            // Create parser instance
                            PosixParser parser = new PosixParser();
                            
                            // Set private fields using reflection
                            Field optionsField = PosixParser.class.getDeclaredField("options");
                            optionsField.setAccessible(true);
                            optionsField.set(parser, options);
                            
                            Field tokensField = PosixParser.class.getDeclaredField("tokens");
                            tokensField.setAccessible(true);
                            tokensField.set(parser, new ArrayList<>()); // Start with empty list
                            
                            // Get private method using reflection
                            Method processOptionTokenMethod = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                            processOptionTokenMethod.setAccessible(true);
                            
                            // Call method with stopAtNonOption=true
                            processOptionTokenMethod.invoke(parser, testToken, true);
                            
                            // Verify behavior - original would add token and set eatTheRest
                            // Check token was added (would fail if mutant is present)
                            List<?> tokens = (List<?>) tokensField.get(parser);
                            assertEquals(1, tokens.size());
                            assertEquals(testToken, tokens.get(0));
                            
                            // Also verify eatTheRest was set
                            Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                            eatTheRestField.setAccessible(true);
                            assertTrue((boolean) eatTheRestField.get(parser));
                        }

    @Test
                   public void testProcessOptionToken_PreservesOriginalToken() {
                       // Setup
                       PosixParser parser = new PosixParser();
                       Options options = mock(Options.class);
                       Option option = mock(Option.class);
                       
                       // Use reflection to set private fields since no constructor is available
                       try {
                           java.lang.reflect.Field optionsField = PosixParser.class.getDeclaredField("options");
                           optionsField.setAccessible(true);
                           optionsField.set(parser, options);
                           
                           java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                           tokensField.setAccessible(true);
                           List<String> tokens = new ArrayList<>();
                           tokensField.set(parser, tokens);
                       } catch (Exception e) {
                           fail("Failed to setup test due to reflection error");
                       }
                       
                       String testToken = "testToken";
                       
                       // Test case 1: When option exists
                       when(options.hasOption(testToken)).thenReturn(true);
                       when(options.getOption(testToken)).thenReturn(option);
                       
                       // Invoke the method (assuming processOptionToken is accessible)
                       try {
                           java.lang.reflect.Method method = PosixParser.class.getDeclaredMethod(
                               "processOptionToken", String.class, boolean.class);
                           method.setAccessible(true);
                           method.invoke(parser, testToken, false);
                       } catch (Exception e) {
                           fail("Failed to invoke method");
                       }
                       
                       // Verify token was added correctly
                       try {
                           java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                           tokensField.setAccessible(true);
                           List<String> tokens = (List<String>) tokensField.get(parser);
                           assertEquals(1, tokens.size());
                           assertEquals(testToken, tokens.get(0)); // This would fail if mutant is present
                       } catch (Exception e) {
                           fail("Failed to verify tokens due to reflection error");
                       }
                       
                       // Reset
                       try {
                           java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                           tokensField.setAccessible(true);
                           List<String> tokens = (List<String>) tokensField.get(parser);
                           tokens.clear();
                       } catch (Exception e) {
                           fail("Failed to reset tokens due to reflection error");
                       }
                       
                       // Test case 2: When option doesn't exist and stopAtNonOption is true
                       when(options.hasOption(testToken)).thenReturn(false);
                       
                       try {
                           java.lang.reflect.Method method = PosixParser.class.getDeclaredMethod(
                               "processOptionToken", String.class, boolean.class);
                           method.setAccessible(true);
                           method.invoke(parser, testToken, true);
                       } catch (Exception e) {
                           fail("Failed to invoke method");
                       }
                       
                       // Verify token was added correctly and eatTheRest was set
                       try {
                           java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                           tokensField.setAccessible(true);
                           List<String> tokens = (List<String>) tokensField.get(parser);
                           assertEquals(1, tokens.size());
                           assertEquals(testToken, tokens.get(0)); // This would fail if mutant is present
                           
                           java.lang.reflect.Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                           eatTheRestField.setAccessible(true);
                           assertTrue((boolean) eatTheRestField.get(parser));
                       } catch (Exception e) {
                           fail("Failed to verify results due to reflection error");
                       }
                   }

    @Test
               public void testProcessOptionToken_ShouldAddTokenWhenStopAtNonOption() throws Exception {
                   // Setup
                   PosixParser parser = new PosixParser();
                   Options options = mock(Options.class);
                   
                   // Use reflection to set private fields
                   Field optionsField = PosixParser.class.getDeclaredField("options");
                   optionsField.setAccessible(true);
                   optionsField.set(parser, options);
                   
                   Field tokensField = PosixParser.class.getDeclaredField("tokens");
                   tokensField.setAccessible(true);
                   List<String> tokens = new ArrayList<>();
                   tokensField.set(parser, tokens);
                   
                   Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                   eatTheRestField.setAccessible(true);
                   
                   String testToken = "testToken";
                   
                   // Mock behavior
                   when(options.hasOption(testToken)).thenReturn(false);
                   
                   // Test
                   Method method = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                   method.setAccessible(true);
                   method.invoke(parser, testToken, true);
                   
                   // Verify
                   assertTrue("Token should be added to tokens list", tokens.contains(testToken));
                   assertTrue("eatTheRest should be set to true", (boolean)eatTheRestField.get(parser));
               }

    @Test
              public void testProcessOptionToken_ShouldAddTokenWhenOptionExists() throws Exception {
                  // Setup
                  PosixParser parser = new PosixParser();
                  Options options = mock(Options.class);
                  Option option = mock(Option.class);
                  
                  // Use reflection to set private fields since no constructor
                  Field optionsField = PosixParser.class.getDeclaredField("options");
                  optionsField.setAccessible(true);
                  optionsField.set(parser, options);
                  
                  Field tokensField = PosixParser.class.getDeclaredField("tokens");
                  tokensField.setAccessible(true);
                  List<String> tokens = new ArrayList<>();
                  tokensField.set(parser, tokens);
                  
                  String testToken = "testToken";
                  
                  // Mock behavior
                  when(options.hasOption(testToken)).thenReturn(true);
                  when(options.getOption(testToken)).thenReturn(option);
                  
                  // Test
                  Method method = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                  method.setAccessible(true);
                  method.invoke(parser, testToken, false);
                  
                  // Verify
                  assertTrue("Token should be added to tokens list", tokens.contains(testToken));
                  
                  // Use reflection to verify currentOption
                  Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                  currentOptionField.setAccessible(true);
                  Option actualOption = (Option) currentOptionField.get(parser);
                  assertEquals("Current option should be set", option, actualOption);
              }

    @Test
         public void testProcessOptionToken_AddsActualTokenNotNull1() {
             // Setup test data
             PosixParser parser = new PosixParser();
             Options options = mock(Options.class);
             Option mockOption = mock(Option.class);
             
             // Set parser's options field via reflection since it's private
             try {
                 Field optionsField = PosixParser.class.getDeclaredField("options");
                 optionsField.setAccessible(true);
                 optionsField.set(parser, options);
                 
                 Field tokensField = PosixParser.class.getDeclaredField("tokens");
                 tokensField.setAccessible(true);
                 tokensField.set(parser, new ArrayList<String>());
             } catch (Exception e) {
                 fail("Failed to set up test due to reflection error: " + e.getMessage());
             }
             
             String testToken = "testToken";
             
             // Test case 1: When options.hasOption returns true
             when(options.hasOption(testToken)).thenReturn(true);
             when(options.getOption(testToken)).thenReturn(mockOption);
             
             // Invoke the method (using reflection since it's private)
             try {
                 Method method = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                 method.setAccessible(true);
                 method.invoke(parser, testToken, false);
             } catch (Exception e) {
                 fail("Failed to invoke method: " + e.getMessage());
             }
             
             // Verify token was added properly using reflection
             try {
                 Field tokensField = PosixParser.class.getDeclaredField("tokens");
                 tokensField.setAccessible(true);
                 @SuppressWarnings("unchecked")
                 List<String> tokens = (List<String>) tokensField.get(parser);
                 
                 assertEquals(1, tokens.size());
                 assertEquals(testToken, tokens.get(0));
                 
                 // Reset for next test case
                 tokens.clear();
             } catch (Exception e) {
                 fail("Failed to verify tokens: " + e.getMessage());
             }
             
             // Test case 2: When options.hasOption returns false and stopAtNonOption is true
             when(options.hasOption(testToken)).thenReturn(false);
             
             // Invoke the method again with stopAtNonOption=true
             try {
                 Method method = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                 method.setAccessible(true);
                 method.invoke(parser, testToken, true);
             } catch (Exception e) {
                 fail("Failed to invoke method: " + e.getMessage());
             }
             
             // Verify token was added properly and eatTheRest was set using reflection
             try {
                 Field tokensField = PosixParser.class.getDeclaredField("tokens");
                 tokensField.setAccessible(true);
                 @SuppressWarnings("unchecked")
                 List<String> tokens = (List<String>) tokensField.get(parser);
                 
                 Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                 eatTheRestField.setAccessible(true);
                 boolean eatTheRest = eatTheRestField.getBoolean(parser);
                 
                 assertEquals(1, tokens.size());
                 assertEquals(testToken, tokens.get(0));
                 assertTrue(eatTheRest);
             } catch (Exception e) {
                 fail("Failed to verify tokens or eatTheRest: " + e.getMessage());
             }
         }

    @Test
    public void testProcessOptionToken_CallsProcessWithCorrectToken1() throws Exception {
        // Setup test objects
        PosixParser parser = new PosixParser();
        Options options = mock(Options.class);
        List<String> tokens = new ArrayList<>();
        
        // Use reflection to set private fields needed for the test
        Field optionsField = PosixParser.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        optionsField.set(parser, options);
        
        Field tokensField = PosixParser.class.getDeclaredField("tokens");
        tokensField.setAccessible(true);
        tokensField.set(parser, tokens);
        
        String testToken = "testToken";
        
        // Mock the options to return false for hasOption to test the else branch
        when(options.hasOption(testToken)).thenReturn(false);
        
        // Use reflection to call the private method
        java.lang.reflect.Method method = PosixParser.class.getDeclaredMethod(
            "processOptionToken", String.class, boolean.class);
        method.setAccessible(true);
        method.invoke(parser, testToken, true);
        
        // Verify the side effects that would be affected by process()
        // If process(null) was called instead of process(token), these would fail
        assertTrue(tokens.contains(testToken));
        
        // Verify eatTheRest flag was set (using reflection to access private field)
        Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
        eatTheRestField.setAccessible(true);
        assertTrue((boolean) eatTheRestField.get(parser));
    }

    @Test
    public void testProcessOptionToken_ValidOption_CallsProcessWithCorrectToken() throws Exception {
        String testToken = "validToken";
        Option mockOption = mock(Option.class);
        
        // Create and initialize required objects
        Options options = mock(Options.class);
        PosixParser parser = new PosixParser();
        
        // Use reflection to access private tokens field
        Field tokensField = PosixParser.class.getDeclaredField("tokens");
        tokensField.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<String> tokens = (List<String>) tokensField.get(parser);
        
        // Mock the options to return true for hasOption
        when(options.hasOption(testToken)).thenReturn(true);
        when(options.getOption(testToken)).thenReturn(mockOption);
        
        // Set options to parser using reflection
        Field optionsField = PosixParser.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        optionsField.set(parser, options);
        
        // Use reflection to call the private method
        java.lang.reflect.Method method = PosixParser.class.getDeclaredMethod(
            "processOptionToken", String.class, boolean.class);
        method.setAccessible(true);
        method.invoke(parser, testToken, false);
        
        // Verify the side effects
        assertTrue(tokens.contains(testToken));
        
        // Verify current option using reflection
        Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
        currentOptionField.setAccessible(true);
        Option currentOption = (Option) currentOptionField.get(parser);
        assertEquals(mockOption, currentOption);
    }


}
