package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
 
public class OptionBuilderTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                public void testCreate_WithSimpleChar() {
                                    Option option = OptionBuilder.create('a');
                                    assertNotNull(option);
                                    assertEquals("a", option.getOpt());
                                    assertNull(option.getLongOpt());
                                    assertFalse(option.isRequired());
                                    assertEquals(0, option.getArgs());
                                }

    @Test
                                public void testCreate_WithLongOpt() {
                                    OptionBuilder.withLongOpt("alpha");
                                    Option option = OptionBuilder.create('a');
                                    assertEquals("alpha", option.getLongOpt());
                                }

    @Test
                                public void testCreate_WithRequired() {
                                    OptionBuilder.isRequired();
                                    Option option = OptionBuilder.create('a');
                                    assertTrue(option.isRequired());
                                }

    @Test
                                public void testCreate_WithDescription() {
                                    OptionBuilder.withDescription("Test option");
                                    Option option = OptionBuilder.create('a');
                                    assertEquals("Test option", option.getDescription());
                                }

    @Test
                                public void testCreate_WithArgName() {
                                    OptionBuilder.withArgName("filename");
                                    Option option = OptionBuilder.create('a');
                                    assertEquals("filename", option.getArgName());
                                }

    @Test
                                public void testCreate_WithSingleArg() {
                                    OptionBuilder.hasArg();
                                    Option option = OptionBuilder.create('a');
                                    assertEquals(1, option.getArgs());
                                }

    @Test
                                public void testCreate_WithMultipleArgs() {
                                    OptionBuilder.hasArgs(3);
                                    Option option = OptionBuilder.create('a');
                                    assertEquals(3, option.getArgs());
                                }

    @Test
                                public void testCreate_WithOptionalArg() {
                                    OptionBuilder.hasOptionalArg();
                                    Option option = OptionBuilder.create('a');
                                    assertTrue(option.hasOptionalArg());
                                }

    @Test
                                public void testCreate_WithValueSeparator() {
                                    OptionBuilder.withValueSeparator(':');
                                    Option option = OptionBuilder.create('a');
                                    assertEquals(':', option.getValueSeparator());
                                }

    @Test
                                public void testCreate_WithType() {
                                    Object type = new Object();
                                    OptionBuilder.withType(type);
                                    Option option = OptionBuilder.create('a');
                                    assertEquals(type, option.getType());
                                }

    @Test
                                public void testCreate_WithAllProperties() {
                                    Object type = String.class;
                                    OptionBuilder.withLongOpt("alpha")
                                               .withDescription("Test option")
                                               .withArgName("file")
                                               .isRequired()
                                               .hasArgs(2)
                                               .withValueSeparator('=')
                                               .withType(type);
                                    
                                    Option option = OptionBuilder.create('a');
                                    
                                    assertEquals("a", option.getOpt());
                                    assertEquals("alpha", option.getLongOpt());
                                    assertEquals("Test option", option.getDescription());
                                    assertEquals("file", option.getArgName());
                                    assertTrue(option.isRequired());
                                    assertEquals(2, option.getArgs());
                                    assertEquals('=', option.getValueSeparator());
                                    assertEquals(type, option.getType());
                                }

    @Test
                                public void testCreate_WithSpecialChar() {
                                    Option option = OptionBuilder.create('?');
                                    assertEquals("?", option.getOpt());
                                }

    @Test
                                public void testCreate_WithMinimumProperties() {
                                    // Setup - only required properties
                                    OptionBuilder.withDescription("basic option");
                                    
                                    // Test
                                    Option option = OptionBuilder.create('b');
                                    
                                    // Verify
                                    assertEquals("b", option.getOpt());
                                    assertEquals("basic option", option.getDescription());
                                    assertNull(option.getLongOpt());
                                    assertFalse(option.isRequired());
                                    assertEquals(0, option.getArgs());
                                    assertNull(option.getType());
                                    assertFalse(option.hasOptionalArg());
                                    assertEquals((char)0, option.getValueSeparator());
                                }

    @Test
                                public void testCreate_WithStringOption() {
                                    // Setup
                                    OptionBuilder.withLongOpt("verbose")
                                                .withDescription("verbose mode")
                                                .hasArg();
                                    
                                    // Test
                                    Option option = OptionBuilder.create("verbose");
                                    
                                    // Verify
                                    assertNull(option.getOpt()); // char opt should be null when created with String
                                    assertEquals("verbose", option.getLongOpt());
                                    assertEquals("verbose mode", option.getDescription());
                                    assertEquals(1, option.getArgs());
                                }

    @Test
                                public void testCreate_WithNoOptionCharacter() {
                                    // Setup
                                    OptionBuilder.withLongOpt("help")
                                                .withDescription("display help");
                                    
                                    // Test
                                    Option option = OptionBuilder.create();
                                    
                                    // Verify
                                    assertNull(option.getOpt());
                                    assertEquals("help", option.getLongOpt());
                                    assertEquals("display help", option.getDescription());
                                }

    @Test
                                public void testCreate_WithMultipleArgs1() {
                                    // Setup
                                    OptionBuilder.hasArgs(3)
                                                .withArgName("files");
                                    
                                    // Test
                                    Option option = OptionBuilder.create('f');
                                    
                                    // Verify
                                    assertEquals(3, option.getArgs());
                                    assertEquals("files", option.getArgName());
                                }

    @Test
                                public void testCreate_WithOptionalArgs() {
                                    // Setup
                                    OptionBuilder.hasOptionalArgs(2)
                                                .withValueSeparator();
                                    
                                    // Test
                                    Option option = OptionBuilder.create('o');
                                    
                                    // Verify
                                    assertTrue(option.hasOptionalArg());
                                    assertEquals(2, option.getArgs());
                                    assertEquals('=', option.getValueSeparator()); // default separator
                                }

    @Test
                                public void testCreate_WithValueSeparator1() {
                                    // Setup
                                    OptionBuilder.withValueSeparator(':');
                                    
                                    // Test
                                    Option option = OptionBuilder.create('s');
                                    
                                    // Verify
                                    assertEquals(':', option.getValueSeparator());
                                }

    @Test
                        public void testCreate_WithInvalidChar() {
                            ExpectedException exception = ExpectedException.none();
                            exception.expect(IllegalArgumentException.class);
                            OptionBuilder.create(' ');
                        }

    @Test
                        public void testCreate_WhenLongOptIsNull_ShouldThrowIllegalArgumentException() throws Exception {
                            // Setup
                            // Use reflection to call private reset() method
                            Method resetMethod = OptionBuilder.class.getDeclaredMethod("reset");
                            resetMethod.setAccessible(true);
                            resetMethod.invoke(null);
                            
                            // Use reflection to set private longopt field
                            Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
                            longoptField.setAccessible(true);
                            longoptField.set(null, null);
                            
                            // Expect exception
                            ExpectedException exception = ExpectedException.none();
                            exception.expect(IllegalArgumentException.class);
                            exception.expectMessage("must specify longopt");
                            
                            // Test
                            OptionBuilder.create();
                        }

    @Test
                        public void testCreate_WhenLongOptIsNotNull_ShouldCallCreateWithNull() {
                            // Setup
                            try {
                                // Reset OptionBuilder using reflection
                                Method resetMethod = OptionBuilder.class.getDeclaredMethod("reset");
                                resetMethod.setAccessible(true);
                                resetMethod.invoke(null);
                                
                                // Set longopt using reflection
                                Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
                                longoptField.setAccessible(true);
                                longoptField.set(null, "testLongOpt");
                                
                                // Mock the Option that would be returned by create(String)
                                Option expectedOption = mock(Option.class);
                                
                                // Spy on OptionBuilder to verify create(String) is called
                                OptionBuilder spyBuilder = spy(OptionBuilder.class);
                                doReturn(expectedOption).when(spyBuilder).create((String)isNull());
                                
                                // Test
                                Option result = spyBuilder.create();
                                
                                // Verify
                                verify(spyBuilder).create((String)isNull());
                                assertEquals(expectedOption, result);
                            } catch (Exception e) {
                                fail("Reflection operation failed: " + e.getMessage());
                            }
                        }

    @Test
                        public void testCreate_WhenCalled_ShouldResetBuilder() throws Exception {
                            // Setup - use public methods to set values
                            OptionBuilder.withLongOpt("testLongOpt");
                            OptionBuilder.withDescription("testDescription");
                            OptionBuilder.isRequired(true);
                            
                            // Mock the Option that would be returned by create(String)
                            Option expectedOption = mock(Option.class);
                            
                            // Spy on OptionBuilder to verify create is called
                            OptionBuilder spyBuilder = spy(OptionBuilder.class);
                            doReturn(expectedOption).when(spyBuilder).create((String)isNull());
                            
                            // Test
                            spyBuilder.create();
                            
                            // Verify that reset was called by checking fields are cleared
                            // Use reflection to access private fields
                            Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
                            longoptField.setAccessible(true);
                            assertNull(longoptField.get(null));
                            
                            Field descriptionField = OptionBuilder.class.getDeclaredField("description");
                            descriptionField.setAccessible(true);
                            assertNull(descriptionField.get(null));
                            
                            Field requiredField = OptionBuilder.class.getDeclaredField("required");
                            requiredField.setAccessible(true);
                            assertFalse(requiredField.getBoolean(null));
                        }

    @Test
                        public void testCreate_WithAllPropertiesSet() {
                            // Setup
                            OptionBuilder.withLongOpt("longopt")
                                        .withDescription("description")
                                        .withArgName("argName")
                                        .isRequired(true)
                                        .hasArgs(2)
                                        .withType(String.class)
                                        .hasOptionalArg()  // Changed from hasOptionalArg(true) to hasOptionalArg()
                                        .withValueSeparator('=');
                            
                            // Test
                            Option option = OptionBuilder.create('a');
                            
                            // Verify
                            assertEquals("a", option.getOpt());
                            assertEquals("longopt", option.getLongOpt());
                            assertEquals("description", option.getDescription());
                            assertEquals("argName", option.getArgName());
                            assertTrue(option.isRequired());
                            assertEquals(2, option.getArgs());
                            assertEquals(String.class, option.getType());
                            assertTrue(option.hasOptionalArg());
                            assertEquals('=', option.getValueSeparator());
                        }

    @Test
                        public void testCreate_ResetAfterCreation() {
                            // Setup some properties
                            OptionBuilder.withLongOpt("test").isRequired(true);
                            
                            // Create option
                            Option option = OptionBuilder.create('t');
                            
                            // Verify properties are reset by checking new option creation
                            Option newOption = OptionBuilder.withLongOpt(null).create();
                            assertNull(newOption.getLongOpt());
                            
                            Option requiredOption = OptionBuilder.isRequired(false).create();
                            assertFalse(requiredOption.isRequired());
                        }

    @Test
                        public void testCreate_WithInvalidNumberOfArgs() {
                            // Setup
                            OptionBuilder.hasArgs(-2);
                            
                            // Expect exception
                            ExpectedException exception = ExpectedException.none();
                            exception.expect(IllegalArgumentException.class);
                            
                            // Test
                            OptionBuilder.create('i');
                        }

    @Test
                    public void testCreateShouldResetPropertiesEvenWhenNoExceptionOccurs() {
                        // Setup: Set some properties that should be cleared after creation
                        OptionBuilder.withLongOpt("longopt");
                        OptionBuilder.withDescription("description");
                        OptionBuilder.isRequired(true);
                        OptionBuilder.hasArgs(2);
                        
                        // Act: Create an option (should succeed)
                        Option option = OptionBuilder.create("opt");
                        
                        // Assert: Verify properties were reset by checking their default values
                        // We need to use reflection to check private static fields since there are no getters
                        try {
                            Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
                            longoptField.setAccessible(true);
                            assertNull(longoptField.get(null));
                            
                            Field descriptionField = OptionBuilder.class.getDeclaredField("description");
                            descriptionField.setAccessible(true);
                            assertNull(descriptionField.get(null));
                            
                            Field requiredField = OptionBuilder.class.getDeclaredField("required");
                            requiredField.setAccessible(true);
                            assertFalse(requiredField.getBoolean(null));
                            
                            Field numberOfArgsField = OptionBuilder.class.getDeclaredField("numberOfArgs");
                            numberOfArgsField.setAccessible(true);
                            assertEquals(-1, numberOfArgsField.getInt(null));
                        } catch (Exception e) {
                            fail("Reflection failed: " + e.getMessage());
                        }
                        
                        // Also verify the created option has the expected properties
                        assertEquals("opt", option.getOpt());
                        assertEquals("longopt", option.getLongOpt());
                        assertEquals("description", option.getDescription());
                        assertTrue(option.isRequired());
                        assertEquals(2, option.getArgs());
                    }

    @Test
                   public void testCreateCharShouldResetStaticVariablesInFinallyBlock() throws Exception {
                       // Setup - modify static variables to non-default values
                       OptionBuilder.withLongOpt("testLongOpt");
                       OptionBuilder.hasArg(true);
                       OptionBuilder.withDescription("test description");
                       OptionBuilder.isRequired(true);
                       
                       // Call method - this should reset static variables in finally block
                       OptionBuilder.create('a');
                       
                       // Use reflection to access private static fields
                       Class<?> optionBuilderClass = OptionBuilder.class;
                       
                       Field longoptField = optionBuilderClass.getDeclaredField("longopt");
                       longoptField.setAccessible(true);
                       assertNull("longopt should be reset to null", longoptField.get(null));
                       
                       Field descriptionField = optionBuilderClass.getDeclaredField("description");
                       descriptionField.setAccessible(true);
                       assertNull("description should be reset to null", descriptionField.get(null));
                       
                       Field requiredField = optionBuilderClass.getDeclaredField("required");
                       requiredField.setAccessible(true);
                       assertFalse("required should be reset to false", requiredField.getBoolean(null));
                       
                       Field numberOfArgsField = optionBuilderClass.getDeclaredField("numberOfArgs");
                       numberOfArgsField.setAccessible(true);
                       assertEquals("numberOfArgs should be reset to -1", -1, numberOfArgsField.getInt(null));
                   }

    @Test
                   public void testCreateCharShouldResetEvenWhenExceptionOccurs() throws Exception {
                       // Setup - modify static variables to non-default values
                       OptionBuilder.withLongOpt("testLongOpt");
                       OptionBuilder.hasArg(true);
                       OptionBuilder.withDescription("test description");
                       OptionBuilder.isRequired(true);
                       
                       try {
                           // Call method with invalid input that might cause exception
                           OptionBuilder.create('\0');
                       } catch (Exception e) {
                           // Even if exception occurs, variables should be reset
                       }
                       
                       // Use reflection to access private fields
                       Class<?> optionBuilderClass = OptionBuilder.class;
                       
                       Field longoptField = optionBuilderClass.getDeclaredField("longopt");
                       longoptField.setAccessible(true);
                       assertNull("longopt should be reset to null even if exception occurs", 
                           longoptField.get(null));
                       
                       Field descriptionField = optionBuilderClass.getDeclaredField("description");
                       descriptionField.setAccessible(true);
                       assertNull("description should be reset to null even if exception occurs", 
                           descriptionField.get(null));
                       
                       Field requiredField = optionBuilderClass.getDeclaredField("required");
                       requiredField.setAccessible(true);
                       assertFalse("required should be reset to false even if exception occurs", 
                           requiredField.getBoolean(null));
                       
                       Field numberOfArgsField = optionBuilderClass.getDeclaredField("numberOfArgs");
                       numberOfArgsField.setAccessible(true);
                       assertEquals("numberOfArgs should be reset to -1 even if exception occurs", 
                           -1, numberOfArgsField.getInt(null));
                   }

    @Test
                   public void testCreateWithNullLongoptResetsState() throws Exception {
                       // Set up - use reflection to set private longopt field to null
                       Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
                       longoptField.setAccessible(true);
                       longoptField.set(null, null);
                       
                       try {
                           // Act - should throw exception
                           OptionBuilder.create();
                           fail("Expected IllegalArgumentException");
                       } catch (IllegalArgumentException e) {
                           // Expected exception
                       } finally {
                           // Verify reset was called exactly once using reflection
                           Method resetMethod = OptionBuilder.class.getDeclaredMethod("reset");
                           resetMethod.setAccessible(true);
                           resetMethod.invoke(null);
                           
                           // Verify the reset was called by checking if longopt is null
                           // (since we can't verify private method calls directly)
                           assertNull(longoptField.get(null));
                       }
                   }

    @Test
                   public void testCreateWithNonNullLongoptResetsState() throws Exception {
                       // Set up
                       // Use reflection to set private longopt field
                       Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
                       longoptField.setAccessible(true);
                       longoptField.set(null, "valid");
                       
                       // Mock the other create method to return a dummy option
                       Option dummyOption = mock(Option.class);
                       when(OptionBuilder.create(null)).thenReturn(dummyOption);
                       
                       // Act
                       Option result = OptionBuilder.create();
                       
                       // Assert
                       assertEquals(dummyOption, result);
                       
                       // Verify reset was called exactly once using reflection
                       Method resetMethod = OptionBuilder.class.getDeclaredMethod("reset");
                       resetMethod.setAccessible(true);
                       
                       // Create a spy to verify reset was called
                       // Note: This is tricky since OptionBuilder is static, 
                       // but we can verify the effect of reset by checking if longopt was cleared
                       resetMethod.invoke(null);
                       assertNull(longoptField.get(null));
                   }

    @Test
                   public void testCreateCharResetsBuilderState() {
                       // First set some non-default values
                       OptionBuilder.withLongOpt("longopt");
                       OptionBuilder.hasArg(true);
                       OptionBuilder.isRequired(true);
                       OptionBuilder.withValueSeparator('=');
                       
                       // Create an option - this should reset the builder
                       Option option1 = OptionBuilder.create('a');
                       
                       // Now create another option without explicit settings
                       Option option2 = OptionBuilder.create('b');
                       
                       // Verify the second option has default values
                       assertNull("Long option should be null", option2.getLongOpt());
                       assertFalse("Should not have argument", option2.hasArg());
                       assertFalse("Should not be required", option2.isRequired());
                       assertEquals("Value separator should be default", (char)0, option2.getValueSeparator());
                       
                       // Additional verification that first option kept its settings
                       assertEquals("longopt", option1.getLongOpt());
                       assertTrue(option1.hasArg());
                       assertTrue(option1.isRequired());
                       assertEquals('=', option1.getValueSeparator());
                   }

    @Test
               public void testCreateResetsOptionBuilderProperties() throws Exception {
                   // Set some non-default values to OptionBuilder static properties
                   OptionBuilder.withLongOpt("testLongOpt");
                   OptionBuilder.withDescription("testDescription");
                   OptionBuilder.withArgName("testArgName");
                   OptionBuilder.isRequired(true);
                   OptionBuilder.hasArgs(2);
                   OptionBuilder.withType(String.class);
                   OptionBuilder.hasOptionalArg();
                   OptionBuilder.withValueSeparator('=');
                   
                   // Create an option (this should reset the properties in original code)
                   Option option = OptionBuilder.create("t");
                   
                   // Verify OptionBuilder properties were reset
                   // Since we can't directly access private static fields, we'll test through the builder methods
                   // Create another option without setting properties - should use defaults if reset worked
                   Option defaultOption = OptionBuilder.create("d");
                   
                   // Verify the new option has default values
                   assertNull("Long option should be null after reset", defaultOption.getLongOpt());
                   assertNull("Description should be null after reset", defaultOption.getDescription());
                   assertNull("Arg name should be null after reset", defaultOption.getArgName());
                   assertFalse("Required should be false after reset", defaultOption.isRequired());
                   assertEquals("Number of args should be -1 after reset", -1, defaultOption.getArgs());
                   assertNull("Type should be null after reset", defaultOption.getType());
                   assertFalse("Optional arg should be false after reset", defaultOption.hasOptionalArg());
                   assertEquals("Value separator should be 0 after reset", 0, defaultOption.getValueSeparator());
               }

    @Test
              public void testCreateWithNullLongOptResetsBuilderState() throws Exception {
                  // Setup some state in OptionBuilder
                  OptionBuilder.withLongOpt("test");
                  OptionBuilder.hasArg(true);
                  OptionBuilder.isRequired();
                  OptionBuilder.withDescription("test description");
                  
                  try {
                      // This should reset the builder before throwing exception
                      OptionBuilder.create();
                  } catch (IllegalArgumentException e) {
                      // Verify exception message
                      assertEquals("must specify longopt", e.getMessage());
                      
                      // Use reflection to access private fields
                      Class<?> optionBuilderClass = OptionBuilder.class;
                      Field longoptField = optionBuilderClass.getDeclaredField("longopt");
                      longoptField.setAccessible(true);
                      Field descriptionField = optionBuilderClass.getDeclaredField("description");
                      descriptionField.setAccessible(true);
                      Field requiredField = optionBuilderClass.getDeclaredField("required");
                      requiredField.setAccessible(true);
                      Field numberOfArgsField = optionBuilderClass.getDeclaredField("numberOfArgs");
                      numberOfArgsField.setAccessible(true);
                      
                      // Verify builder was reset by checking its fields
                      assertNull(longoptField.get(null));
                      assertNull(descriptionField.get(null));
                      assertFalse(requiredField.getBoolean(null));
                      assertEquals(0, numberOfArgsField.getInt(null));
                      
                      throw e; // rethrow for @Test annotation
                  }
              }

    @Test
         public void testCreateCharDoesNotResetStaticState() throws Exception {
             // Setup initial static state
             OptionBuilder.withLongOpt("longOpt");
             OptionBuilder.hasArg(true);
             OptionBuilder.withDescription("description");
             OptionBuilder.isRequired(true);
             
             // Get private fields via reflection
             Class<?> optionBuilderClass = OptionBuilder.class;
             Field longoptField = optionBuilderClass.getDeclaredField("longopt");
             Field requiredField = optionBuilderClass.getDeclaredField("required");
             Field descriptionField = optionBuilderClass.getDeclaredField("description");
             Field numberOfArgsField = optionBuilderClass.getDeclaredField("numberOfArgs");
             
             longoptField.setAccessible(true);
             requiredField.setAccessible(true);
             descriptionField.setAccessible(true);
             numberOfArgsField.setAccessible(true);
             
             // Remember some static field values before create()
             String expectedLongOpt = (String) longoptField.get(null);
             boolean expectedRequired = (boolean) requiredField.get(null);
             
             // Call the method
             Option option = OptionBuilder.create('a');
             
             // Verify static state wasn't reset
             assertEquals("longOpt field should not be reset", 
                 expectedLongOpt, longoptField.get(null));
             assertEquals("required field should not be reset",
                 expectedRequired, requiredField.get(null));
             assertNotNull("description field should not be reset",
                 descriptionField.get(null));
             assertTrue("hasArg should not be reset",
                 ((int) numberOfArgsField.get(null)) > 0);
         }

    @Test
         public void testCreateWithNullLongOptResetsBuilder() throws Exception {
             // Use reflection to set private static fields
             Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
             longoptField.setAccessible(true);
             Field descriptionField = OptionBuilder.class.getDeclaredField("description");
             descriptionField.setAccessible(true);
             Field requiredField = OptionBuilder.class.getDeclaredField("required");
             requiredField.setAccessible(true);
             
             // Set initial values
             longoptField.set(null, "test");
             descriptionField.set(null, "description");
             requiredField.set(null, true);
             
             try {
                 OptionBuilder.create();
                 fail("Expected IllegalArgumentException");
             } catch (IllegalArgumentException e) {
                 assertEquals("must specify longopt", e.getMessage());
             }
             
             // Verify static fields were reset
             assertNull(longoptField.get(null));
             assertNull(descriptionField.get(null));
             assertFalse((Boolean) requiredField.get(null));
         }

    @Test
         public void testCreateWithNonNullLongOptShouldNotResetBuilderInOriginal() throws Exception {
             // Use reflection to set private fields
             Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
             longoptField.setAccessible(true);
             longoptField.set(null, "test");
             
             Field descriptionField = OptionBuilder.class.getDeclaredField("description");
             descriptionField.setAccessible(true);
             descriptionField.set(null, "description");
             
             Field requiredField = OptionBuilder.class.getDeclaredField("required");
             requiredField.setAccessible(true);
             requiredField.set(null, true);
             
             // Mock the create(String) method to return a dummy option
             Option dummyOption = mock(Option.class);
             OptionBuilder optionBuilderSpy = spy(OptionBuilder.class);
             doReturn(dummyOption).when(optionBuilderSpy).create(null);
             
             Option result = OptionBuilder.create();
             
             // Verify create(null) was called
             assertEquals(dummyOption, result);
             
             // Verify static fields were NOT reset in original code
             // This will fail if the mutant is present (which adds reset in finally)
             assertEquals("test", longoptField.get(null));
             assertEquals("description", descriptionField.get(null));
             assertTrue((Boolean) requiredField.get(null));
         }

    @Test
         public void testCreate_ResetsOptionBuilderProperties_EvenWhenExceptionOccurs() throws Exception {
             // Setup - set some values to OptionBuilder static fields
             OptionBuilder.withLongOpt("longopt");
             OptionBuilder.withDescription("description");
             OptionBuilder.withArgName("argName");
             OptionBuilder.isRequired(true);
             OptionBuilder.hasArgs(2);
             OptionBuilder.withType(String.class);
             OptionBuilder.hasOptionalArg(); // Fixed: changed from hasOptionalArg(true) to hasOptionalArg()
             OptionBuilder.withValueSeparator('=');
             
             // Use reflection to get field values
             Class<?> optionBuilderClass = OptionBuilder.class;
             
             // Save original values to verify reset
             Field longoptField = optionBuilderClass.getDeclaredField("longopt");
             longoptField.setAccessible(true);
             String originalLongopt = (String) longoptField.get(null);
             
             Field descriptionField = optionBuilderClass.getDeclaredField("description");
             descriptionField.setAccessible(true);
             String originalDescription = (String) descriptionField.get(null);
             
             Field argNameField = optionBuilderClass.getDeclaredField("argName");
             argNameField.setAccessible(true);
             String originalArgName = (String) argNameField.get(null);
             
             Field requiredField = optionBuilderClass.getDeclaredField("required");
             requiredField.setAccessible(true);
             boolean originalRequired = requiredField.getBoolean(null);
             
             Field numberOfArgsField = optionBuilderClass.getDeclaredField("numberOfArgs");
             numberOfArgsField.setAccessible(true);
             int originalNumberOfArgs = numberOfArgsField.getInt(null);
             
             Field typeField = optionBuilderClass.getDeclaredField("type");
             typeField.setAccessible(true);
             Object originalType = typeField.get(null);
             
             Field optionalArgField = optionBuilderClass.getDeclaredField("optionalArg");
             optionalArgField.setAccessible(true);
             boolean originalOptionalArg = optionalArgField.getBoolean(null);
             
             Field valuesepField = optionBuilderClass.getDeclaredField("valuesep");
             valuesepField.setAccessible(true);
             char originalValuesep = valuesepField.getChar(null);
             
             try {
                 // Act - call create with invalid input to trigger exception
                 OptionBuilder.create(null); // This should throw IllegalArgumentException
                 fail("Expected IllegalArgumentException");
             } catch (IllegalArgumentException e) {
                 // Expected exception
             } finally {
                 // Assert - verify all static fields were reset using reflection
                 assertNull("longopt should be reset to null", longoptField.get(null));
                 assertNull("description should be reset to null", descriptionField.get(null));
                 assertNull("argName should be reset to null", argNameField.get(null));
                 assertFalse("required should be reset to false", requiredField.getBoolean(null));
                 assertEquals("numberOfArgs should be reset to 0", 0, numberOfArgsField.getInt(null));
                 assertNull("type should be reset to null", typeField.get(null));
                 assertFalse("optionalArg should be reset to false", optionalArgField.getBoolean(null));
                 assertEquals("valuesep should be reset to 0", 0, valuesepField.getChar(null));
             }
         }

    @Test
     public void testCreateResetsOptionBuilderProperties1() throws Exception {
         // Setup: Set some static properties on OptionBuilder
         OptionBuilder.withLongOpt("testLongOpt");
         OptionBuilder.withDescription("testDescription");
         OptionBuilder.isRequired(true);
         OptionBuilder.hasArgs(3);
         
         // Action: Create an option (this should trigger reset in original code)
         Option option = OptionBuilder.create("t");
         
         // Verification: Check if static properties were reset
         // We need to use reflection to check private static fields since there's no public getter
         try {
             Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
             longoptField.setAccessible(true);
             assertNull("longopt should be reset to null", longoptField.get(null));
             
             Field descriptionField = OptionBuilder.class.getDeclaredField("description");
             descriptionField.setAccessible(true);
             assertNull("description should be reset to null", descriptionField.get(null));
             
             Field requiredField = OptionBuilder.class.getDeclaredField("required");
             requiredField.setAccessible(true);
             assertFalse("required should be reset to false", requiredField.getBoolean(null));
             
             Field numberOfArgsField = OptionBuilder.class.getDeclaredField("numberOfArgs");
             numberOfArgsField.setAccessible(true);
             assertEquals("numberOfArgs should be reset to -1", -1, numberOfArgsField.getInt(null));
         } catch (Exception e) {
             fail("Failed to verify OptionBuilder reset state: " + e.getMessage());
         }
     }

    @Test
    public void testCreateCharResetsBuilderState1() {
        // Setup initial state in OptionBuilder
        OptionBuilder.withLongOpt("testLongOpt");
        OptionBuilder.hasArg(true);
        OptionBuilder.withDescription("test description");
        OptionBuilder.withArgName("arg");
        OptionBuilder.isRequired(true);
        OptionBuilder.withValueSeparator('=');
        
        // Call the method under test
        OptionBuilder.create('a');
        
        // Verify all static fields were reset
        try {
            Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
            longoptField.setAccessible(true);
            assertNull("longopt should be reset to null", longoptField.get(null));
            
            Field descriptionField = OptionBuilder.class.getDeclaredField("description");
            descriptionField.setAccessible(true);
            assertNull("description should be reset to null", descriptionField.get(null));
            
            Field argNameField = OptionBuilder.class.getDeclaredField("argName");
            argNameField.setAccessible(true);
            assertNull("argName should be reset to null", argNameField.get(null));
            
            Field requiredField = OptionBuilder.class.getDeclaredField("required");
            requiredField.setAccessible(true);
            assertFalse("required should be reset to false", requiredField.getBoolean(null));
            
            Field numberOfArgsField = OptionBuilder.class.getDeclaredField("numberOfArgs");
            numberOfArgsField.setAccessible(true);
            assertEquals("numberOfArgs should be reset to -1", -1, numberOfArgsField.getInt(null));
            
            Field typeField = OptionBuilder.class.getDeclaredField("type");
            typeField.setAccessible(true);
            assertNull("type should be reset to null", typeField.get(null));
            
            Field valuesepField = OptionBuilder.class.getDeclaredField("valuesep");
            valuesepField.setAccessible(true);
            assertEquals("valuesep should be reset to 0", 0, valuesepField.getChar(null));
        } catch (Exception e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    public void testCreateWithNullLongOptResetsBuilderState1() throws Exception {
        // Setup - set some non-default values in OptionBuilder
        OptionBuilder.withLongOpt("test");
        OptionBuilder.hasArg(true);
        OptionBuilder.isRequired(true);
        OptionBuilder.withDescription("description");
        OptionBuilder.withArgName("arg");
        OptionBuilder.withType(String.class);
        OptionBuilder.withValueSeparator('=');
        
        try {
            // Act - call create with null longopt
            OptionBuilder.create();
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Assert - verify exception message
            assertEquals("must specify longopt", e.getMessage());
            
            // Verify builder was reset by checking default values using reflection
            Class<?> optionBuilderClass = OptionBuilder.class;
            
            Field longoptField = optionBuilderClass.getDeclaredField("longopt");
            longoptField.setAccessible(true);
            assertNull(longoptField.get(null));
            
            Field descriptionField = optionBuilderClass.getDeclaredField("description");
            descriptionField.setAccessible(true);
            assertNull(descriptionField.get(null));
            
            Field argNameField = optionBuilderClass.getDeclaredField("argName");
            argNameField.setAccessible(true);
            assertNull(argNameField.get(null));
            
            Field requiredField = optionBuilderClass.getDeclaredField("required");
            requiredField.setAccessible(true);
            assertFalse(requiredField.getBoolean(null));
            
            Field numberOfArgsField = optionBuilderClass.getDeclaredField("numberOfArgs");
            numberOfArgsField.setAccessible(true);
            assertEquals(0, numberOfArgsField.getInt(null));
            
            Field typeField = optionBuilderClass.getDeclaredField("type");
            typeField.setAccessible(true);
            assertNull(typeField.get(null));
            
            Field optionalArgField = optionBuilderClass.getDeclaredField("optionalArg");
            optionalArgField.setAccessible(true);
            assertFalse(optionalArgField.getBoolean(null));
            
            Field valuesepField = optionBuilderClass.getDeclaredField("valuesep");
            valuesepField.setAccessible(true);
            assertEquals('\0', valuesepField.getChar(null));
        }
    }


}
