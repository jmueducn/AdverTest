package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
 
public class OptionGroupTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
              public void testAddOption_SingleOption() {
                  // Create test objects
                  OptionGroup optionGroup = new OptionGroup();
                  Option option1 = new Option("key1", "description1");
                  
                  OptionGroup result = optionGroup.addOption(option1);
                  
                  // Verify return value is the same instance
                  assertSame(optionGroup, result);
                  
                  // Verify option was added to map
                  assertEquals(1, optionGroup.getOptions().size());
                  assertTrue(optionGroup.getNames().contains("key1"));
              }

    @Test
              public void testAddOption_MultipleOptions() {
                  OptionGroup optionGroup = new OptionGroup();
                  Option option1 = new Option("key1", "description1");
                  Option option2 = new Option("key2", "description2");
                  
                  optionGroup.addOption(option1);
                  optionGroup.addOption(option2);
                  
                  assertEquals(2, optionGroup.getOptions().size());
                  assertTrue(optionGroup.getNames().contains("key1"));
                  assertTrue(optionGroup.getNames().contains("key2"));
              }

    @Test
              public void testAddOption_DuplicateOption() {
                  Option option1 = mock(Option.class);
                  Option optionDuplicate = mock(Option.class);
                  OptionGroup optionGroup = new OptionGroup();
                  
                  when(option1.getOpt()).thenReturn("key1");
                  when(optionDuplicate.getOpt()).thenReturn("key1");
                  
                  optionGroup.addOption(option1);
                  optionGroup.addOption(optionDuplicate);
                  
                  // Should only have one entry (last one wins)
                  assertEquals(1, optionGroup.getOptions().size());
                  // Verify the last added option is the one in the map
                  assertSame(optionDuplicate, optionGroup.getOptions().iterator().next());
              }

    @Test
              public void testAddOption_NullOption() {
                  ExpectedException exception = ExpectedException.none();
                  exception.expect(NullPointerException.class);
                  exception.expectMessage("Option cannot be null");
                  
                  OptionGroup optionGroup = new OptionGroup();
                  optionGroup.addOption(null);
              }

    @Test
              public void testAddOption_OptionWithNullKey() {
                  org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                  OptionGroup optionGroup = new OptionGroup();
                  Option optionWithNullKey = new Option(null, "description");
                  
                  exception.expect(IllegalArgumentException.class);
                  exception.expectMessage("Option key cannot be null");
                  
                  optionGroup.addOption(optionWithNullKey);
              }

    @Test
         public void testAddOptionReturnsThis() {
             // Create test objects
             OptionGroup optionGroup = new OptionGroup();
             Option option = mock(Option.class);
             
             // Call method and verify return value
             OptionGroup returned = optionGroup.addOption(option);
             
             // Assertions to catch the mutant
             assertNotNull("Method should never return null", returned);
             assertSame("Method should return the same instance (this)", optionGroup, returned);
             
             // Verify the option was actually added to the map
             assertTrue("Option should be added to the map", 
                 optionGroup.getOptions().contains(option));
         }

    @Test
    public void testAddOptionReturnsThisInstance() {
        // Setup
        OptionGroup optionGroup = new OptionGroup();
        Option mockOption = mock(Option.class);
        
        // Execute
        OptionGroup returnedInstance = optionGroup.addOption(mockOption);
        
        // Verify
        // Check that returned instance is exactly the same object (== comparison)
        assertSame("Returned instance should be the same as the original", 
                  optionGroup, returnedInstance);
        
        // Check that returned instance is not null
        assertNotNull("Returned instance should not be null", returnedInstance);
        
        // Verify method chaining works
        OptionGroup chainedResult = optionGroup.addOption(mockOption)
                                             .addOption(mockOption);
        assertSame("Method chaining should work properly", 
                  optionGroup, chainedResult);
    }


}
