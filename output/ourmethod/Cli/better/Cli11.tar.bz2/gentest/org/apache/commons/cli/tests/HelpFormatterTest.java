package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
             public void testAppendOption_ShortOptNotRequiredNoArg() throws Exception {
                 // Setup
                 StringBuffer buff = new StringBuffer();
                 Option option = mock(Option.class);
                 when(option.getOpt()).thenReturn("f");
                 when(option.getLongOpt()).thenReturn(null);
                 when(option.hasArg()).thenReturn(false);
                 when(option.hasArgName()).thenReturn(false);
             
                 // Get private method via reflection
                 Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                     "appendOption", StringBuffer.class, Option.class, boolean.class);
                 appendOptionMethod.setAccessible(true);
             
                 // Execute
                 appendOptionMethod.invoke(null, buff, option, false);
             
                 // Verify
                 assertEquals("[ -f]", buff.toString());
             }

    @Test
             public void testAppendOption_LongOptRequiredWithArg() throws Exception {
                 // Setup
                 StringBuffer buff = new StringBuffer();
                 Option option = mock(Option.class);
                 when(option.getOpt()).thenReturn(null);
                 when(option.getLongOpt()).thenReturn("file");
                 when(option.hasArg()).thenReturn(true);
                 when(option.hasArgName()).thenReturn(true);
                 when(option.getArgName()).thenReturn("filename");
             
                 // Get private method via reflection
                 Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                     "appendOption", StringBuffer.class, Option.class, boolean.class);
                 appendOptionMethod.setAccessible(true);
             
                 // Execute
                 appendOptionMethod.invoke(null, buff, option, true);
             
                 // Verify
                 assertEquals("--file <filename>", buff.toString());
             }

    @Test
             public void testAppendOption_ShortOptRequiredWithArg() throws Exception {
                 // Setup
                 StringBuffer buff = new StringBuffer();
                 Option option = mock(Option.class);
                 when(option.getOpt()).thenReturn("f");
                 when(option.getLongOpt()).thenReturn(null);
                 when(option.hasArg()).thenReturn(true);
                 when(option.hasArgName()).thenReturn(true);
                 when(option.getArgName()).thenReturn("file");
             
                 // Get private method via reflection
                 Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                     "appendOption", StringBuffer.class, Option.class, boolean.class);
                 appendOptionMethod.setAccessible(true);
             
                 // Execute
                 appendOptionMethod.invoke(null, buff, option, true);
             
                 // Verify
                 assertEquals("-f <file>", buff.toString());
             }

    @Test
             public void testAppendOption_LongOptNotRequiredNoArg() throws Exception {
                 // Setup
                 StringBuffer buff = new StringBuffer();
                 Option option = mock(Option.class);
                 when(option.getOpt()).thenReturn(null);
                 when(option.getLongOpt()).thenReturn("help");
                 when(option.hasArg()).thenReturn(false);
                 when(option.hasArgName()).thenReturn(false);
             
                 // Get private method via reflection
                 Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                     "appendOption", StringBuffer.class, Option.class, boolean.class);
                 appendOptionMethod.setAccessible(true);
             
                 // Execute
                 appendOptionMethod.invoke(null, buff, option, false);
             
                 // Verify
                 assertEquals("[ --help]", buff.toString());
             }

    @Test
             public void testAppendOption_ShortOptNotRequiredWithArg() throws Exception {
                 // Setup
                 StringBuffer buff = new StringBuffer();
                 Option option = mock(Option.class);
                 when(option.getOpt()).thenReturn("v");
                 when(option.getLongOpt()).thenReturn(null);
                 when(option.hasArg()).thenReturn(true);
                 when(option.hasArgName()).thenReturn(true);
                 when(option.getArgName()).thenReturn("value");
             
                 // Get private method via reflection
                 Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                     "appendOption", StringBuffer.class, Option.class, boolean.class);
                 appendOptionMethod.setAccessible(true);
             
                 // Execute
                 appendOptionMethod.invoke(null, buff, option, false);
             
                 // Verify
                 assertEquals("[ -v <value>]", buff.toString());
             }

    @Test
             public void testAppendOption_NullOptionThrowsException() throws Exception {
                 // Setup
                 StringBuffer buff = new StringBuffer();
                 HelpFormatter helpFormatter = new HelpFormatter();
                 
                 // Get private method using reflection
                 Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                     "appendOption", 
                     StringBuffer.class, 
                     Option.class, 
                     boolean.class
                 );
                 appendOptionMethod.setAccessible(true);
                 
                 // Expect exception
                 try {
                     appendOptionMethod.invoke(helpFormatter, buff, null, true);
                     fail("Expected NullPointerException to be thrown");
                 } catch (InvocationTargetException e) {
                     Throwable cause = e.getCause();
                     assertTrue(cause instanceof NullPointerException);
                     assertEquals("option", cause.getMessage());
                 }
             }

    @Test
             public void testAppendOption_NeitherShortNorLongOptSpecified() throws Exception {
                 // Setup
                 StringBuffer buff = new StringBuffer();
                 Option option = mock(Option.class);
                 when(option.getOpt()).thenReturn(null);
                 when(option.getLongOpt()).thenReturn(null);
                 when(option.hasArg()).thenReturn(false);
                 when(option.hasArgName()).thenReturn(false);
             
                 // Get private method via reflection
                 Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                     "appendOption", StringBuffer.class, Option.class, boolean.class);
                 appendOptionMethod.setAccessible(true);
             
                 // Execute
                 appendOptionMethod.invoke(null, buff, option, true);
             
                 // Verify - should just append nothing (empty string)
                 assertEquals("", buff.toString());
             }

    @Test
             public void testAppendOption_HasArgButNoArgName() throws Exception {
                 // Setup
                 StringBuffer buff = new StringBuffer();
                 Option option = mock(Option.class);
                 when(option.getOpt()).thenReturn("f");
                 when(option.getLongOpt()).thenReturn(null);
                 when(option.hasArg()).thenReturn(true);
                 when(option.hasArgName()).thenReturn(false);
             
                 // Get the private method via reflection
                 Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                     "appendOption", StringBuffer.class, Option.class, boolean.class);
                 appendOptionMethod.setAccessible(true);
             
                 // Execute
                 appendOptionMethod.invoke(null, buff, option, true);
             
                 // Verify - should not append the arg name part
                 assertEquals("-f", buff.toString());
             }

    @Test
         public void testAppendOption_NullBufferThrowsException() throws Exception {
             // Setup
             Option option = mock(Option.class);
             HelpFormatter helpFormatter = new HelpFormatter();
             
             // Get the private method using reflection
             Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                 "appendOption", StringBuffer.class, Option.class, boolean.class);
             appendOptionMethod.setAccessible(true);
             
             // Define exception rule
             ExpectedException exception = ExpectedException.none();
             exception.expect(NullPointerException.class);
             exception.expectMessage("buff");
             
             // Execute
             appendOptionMethod.invoke(helpFormatter, null, option, true);
         }

    @Test
    public void testAppendOption_ShouldNotShowArgWhenHasArgNameButNoArg() throws Exception {
        // Setup
        StringBuffer buff = new StringBuffer();
        Option option = mock(Option.class);
        when(option.getOpt()).thenReturn("f"); // short option
        when(option.getLongOpt()).thenReturn(null);
        when(option.hasArg()).thenReturn(false); // doesn't require argument
        when(option.hasArgName()).thenReturn(true); // but has arg name
        when(option.getArgName()).thenReturn("file");
        
        boolean required = false;
        
        // Get private method via reflection
        Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
            "appendOption", StringBuffer.class, Option.class, boolean.class);
        appendOptionMethod.setAccessible(true);
        
        // Execute
        appendOptionMethod.invoke(null, buff, option, required);
        
        // Verify
        String result = buff.toString();
        assertFalse("Should not contain argument syntax when option doesn't require argument", 
                   result.contains("<file>"));
        
        // Also verify other parts of the output
        assertEquals("[-f]", result);
    }


}
