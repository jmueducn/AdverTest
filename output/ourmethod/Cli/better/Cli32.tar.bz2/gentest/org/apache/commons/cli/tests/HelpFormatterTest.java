package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                        public void testFindWrapPos_NewLineBeforeWidth() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = "This is a\ntest string";
                            int width = 20;
                            int startPos = 0;
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                            
                            assertEquals(9, result); // Should return position after '\n'
                        }

    @Test
                        public void testFindWrapPos_TabBeforeWidth() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = "This is a\ttest string";
                            int width = 20;
                            int startPos = 0;
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                            
                            assertEquals(9, result); // Should return position after '\t'
                        }

    @Test
                        public void testFindWrapPos_NoWrapNeeded() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = "Short text";
                            int width = 20;
                            int startPos = 0;
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                            
                            assertEquals(-1, result); // Should return -1 as no wrapping needed
                        }

    @Test
                        public void testFindWrapPos_WrapAtLastSpaceBeforeWidth() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = "This is a test string that needs wrapping";
                            int width = 10;
                            int startPos = 0;
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                            
                            assertEquals(7, result); // Should wrap at space after "is"
                        }

    @Test
                        public void testFindWrapPos_NoWhitespaceBeforeWidth() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = "ThisIsALongWordWithoutSpaces";
                            int width = 10;
                            int startPos = 0;
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                            
                            assertEquals(10, result); // Should hard-wrap at width position
                        }

    @Test
                        public void testFindWrapPos_StartPosNotZero() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = "This is a test string with multiple words";
                            int width = 10;
                            int startPos = 5;
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                            
                            assertEquals(14, result); // Should wrap at space after "test"
                        }

    @Test
                        public void testFindWrapPos_ExactWidthAtEndOfString() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = "Exactly ten";
                            int width = text.length();
                            int startPos = 0;
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                            
                            assertEquals(-1, result); // Should return -1 as no wrapping needed
                        }

    @Test
                        public void testFindWrapPos_WidthLargerThanTextLength() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = "Short";
                            int width = 20;
                            int startPos = 0;
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                            
                            assertEquals(-1, result); // Should return -1 as no wrapping needed
                        }

    @Test
                        public void testFindWrapPos_EmptyString() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = "";
                            int width = 10;
                            int startPos = 0;
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                            
                            assertEquals(-1, result); // Should return -1 for empty string
                        }

    @Test
                        public void testFindWrapPos_OnlyWhitespace() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = "   \t\n  ";
                            int width = 2;
                            int startPos = 0;
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                            
                            assertEquals(3, result); // Should return position after first whitespace
                        }

    @Test
                        public void testFindWrapPos_StartPosAtEndOfString() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = "Test string";
                            int width = 5;
                            int startPos = text.length();
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                            
                            assertEquals(-1, result); // Should return -1 when startPos is at end
                        }

    @Test
                        public void testFindWrapPos_StartPosBeyondStringLength() throws Exception {
                            String text = "Test";
                            int width = 5;
                            int startPos = 10;
                            
                            HelpFormatter formatter = new HelpFormatter();
                            Method method = HelpFormatter.class.getDeclaredMethod("findWrapPos", String.class, int.class, int.class);
                            method.setAccessible(true);
                            
                            ExpectedException thrown = ExpectedException.none();
                            thrown.expect(StringIndexOutOfBoundsException.class);
                            method.invoke(formatter, text, width, startPos);
                        }

    @Test
                        public void testFindWrapPos_NullText() throws Exception {
                            HelpFormatter helpFormatter = new HelpFormatter();
                            String text = null;
                            int width = 10;
                            int startPos = 0;
                            
                            thrown.expect(NullPointerException.class);
                            
                            // Use reflection to access protected method
                            Method method = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            method.setAccessible(true);
                            method.invoke(helpFormatter, text, width, startPos);
                        }

    @Test
                   public void testFindWrapPosWithNonZeroStartPos() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       String text = "ThisIsALongStringWithNoSpaces";
                       int width = 10;
                       int startPos = 5;
                       
                       // Get the protected method using reflection
                       Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                           "findWrapPos", String.class, int.class, int.class);
                       findWrapPosMethod.setAccessible(true);
                       
                       // Original should return 15 (startPos + width)
                       // Mutant will return 10 (just width)
                       int expected = startPos + width;
                       int actual = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                       
                       assertEquals("Wrap position should be startPos + width when no natural breaks exist", 
                                   expected, actual);
                   }

    @Test
              public void testFindWrapPos_ExactTextLength() throws Exception {
                  // Setup
                  HelpFormatter formatter = new HelpFormatter();
                  String text = "12345";  // length = 5
                  int width = 5;
                  int startPos = 0;
                  
                  // Get the protected method using reflection
                  Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                      "findWrapPos", String.class, int.class, int.class);
                  findWrapPosMethod.setAccessible(true);
                  
                  // Test - when startPos + width equals text length
                  int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                  
                  // Verify - original would return -1, mutant would return 5
                  assertEquals("Should return -1 when pos equals text length", -1, result);
                  
                  // Additional verification with different startPos
                  startPos = 2;
                  result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                  assertEquals("Should return -1 when pos would exceed text length", -1, result);
              }

    @Test
         public void testFindWrapPos_AtEndOfString() throws Exception {
             HelpFormatter formatter = new HelpFormatter();
             String text = "ThisIsATestStringWithoutSpaces";
             int width = text.length();
             int startPos = 0;
             
             // Use reflection to access protected method
             Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                 "findWrapPos", String.class, int.class, int.class);
             findWrapPosMethod.setAccessible(true);
             int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
             
             assertEquals("Should return -1 when position equals text length", 
                         -1, result);
             
             // Additional assertion to ensure it's not returning 0
             assertNotEquals("Should not return 0 when position equals text length",
                           0, result);
         }

    @Test
    public void testFindWrapPos_NoWhitespaceAtEndOfString() throws Exception {
        HelpFormatter formatter = new HelpFormatter();
        String text = "abcdefgh"; // No whitespace characters
        int width = 8; // Equal to text length
        int startPos = 0;
        
        // Use reflection to access protected method
        Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
            "findWrapPos", String.class, int.class, int.class);
        findWrapPosMethod.setAccessible(true);
        int result = (Integer) findWrapPosMethod.invoke(formatter, text, width, startPos);
        
        assertEquals("Should return -1 when position equals text length", -1, result);
    }


}
