package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
 
public class DefaultParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                         public void testIsShortOption_NotStartingWithDash_ReturnsFalse() throws Exception {
                                                                             DefaultParser parser = new DefaultParser();
                                                                             Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                             isShortOptionMethod.setAccessible(true);
                                                                             boolean result = (boolean) isShortOptionMethod.invoke(parser, "option");
                                                                             assertFalse(result);
                                                                         }

    @Test
                                                                         public void testIsShortOption_EmptyOptionAfterDash_ReturnsFalse() throws Exception {
                                                                             DefaultParser parser = new DefaultParser();
                                                                             Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                             isShortOptionMethod.setAccessible(true);
                                                                             boolean result = (boolean) isShortOptionMethod.invoke(parser, "-");
                                                                             assertFalse(result);
                                                                         }

    @Test
                                                                         public void testIsShortOption_EmptyString_ReturnsFalse() throws Exception {
                                                                             DefaultParser parser = new DefaultParser();
                                                                             Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                             isShortOptionMethod.setAccessible(true);
                                                                             boolean result = (boolean) isShortOptionMethod.invoke(parser, "");
                                                                             assertFalse(result);
                                                                         }

    @Test
                                                                         public void testIsShortOption_OnlyEqualsAfterDash_ReturnsFalse() throws Exception {
                                                                             DefaultParser parser = new DefaultParser();
                                                                             Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                             isShortOptionMethod.setAccessible(true);
                                                                             boolean result = (boolean) isShortOptionMethod.invoke(parser, "-=");
                                                                             assertFalse(result);
                                                                         }

    @Test
                                                                     public void testIsShortOption_SingleDash_ReturnsFalse() throws Exception {
                                                                         DefaultParser parser = new DefaultParser();
                                                                         Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                         isShortOptionMethod.setAccessible(true);
                                                                         boolean result = (boolean) isShortOptionMethod.invoke(parser, "-");
                                                                         assertFalse(result);
                                                                     }

    @Test
                                                                     public void testIsShortOption_ValidShortOptionWithoutValue_ReturnsTrue() throws Exception {
                                                                         DefaultParser parser = new DefaultParser();
                                                                         Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                         isShortOptionMethod.setAccessible(true);
                                                                         boolean result = (boolean) isShortOptionMethod.invoke(parser, "-a");
                                                                         assertTrue(result);
                                                                     }

    @Test
                                                                     public void testIsShortOption_ValidShortOptionWithValue_ReturnsTrue() throws Exception {
                                                                         DefaultParser parser = new DefaultParser();
                                                                         Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                         isShortOptionMethod.setAccessible(true);
                                                                         boolean result = (boolean) isShortOptionMethod.invoke(parser, "-a=value");
                                                                         assertTrue(result);
                                                                     }

    @Test
                                                                     public void testIsShortOption_InvalidShortOption_ReturnsFalse() throws Exception {
                                                                         DefaultParser parser = new DefaultParser();
                                                                         Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                         isShortOptionMethod.setAccessible(true);
                                                                         boolean result = (boolean) isShortOptionMethod.invoke(parser, "-b");
                                                                         assertFalse(result);
                                                                     }

    @Test
                                                                     public void testIsShortOption_ConcatenatedOptionsFirstValid_ReturnsTrue() {
                                                                         // Create mock Options
                                                                         Options options = mock(Options.class);
                                                                         when(options.hasShortOption("a")).thenReturn(true);
                                                                         when(options.hasShortOption("b")).thenReturn(false);
                                                                         
                                                                         // Create parser instance
                                                                         DefaultParser parser = new DefaultParser();
                                                                         
                                                                         // Use reflection to set the private options field in parser
                                                                         try {
                                                                             Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                             optionsField.setAccessible(true);
                                                                             optionsField.set(parser, options);
                                                                         } catch (Exception e) {
                                                                             fail("Failed to set options field via reflection");
                                                                         }
                                                                         
                                                                         // Use reflection to access the private isShortOption method
                                                                         try {
                                                                             Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                             isShortOptionMethod.setAccessible(true);
                                                                             boolean result = (boolean) isShortOptionMethod.invoke(parser, "-ab");
                                                                             assertTrue(result);
                                                                         } catch (Exception e) {
                                                                             fail("Failed to invoke isShortOption method via reflection");
                                                                         }
                                                                     }

    @Test
                                                                     public void testIsShortOption_ConcatenatedOptionsNoneValid_ReturnsFalse() throws Exception {
                                                                         Options options = mock(Options.class);
                                                                         DefaultParser parser = new DefaultParser();
                                                                         
                                                                         when(options.hasShortOption("a")).thenReturn(false);
                                                                         when(options.hasShortOption("b")).thenReturn(false);
                                                                         
                                                                         // Use reflection to access private method
                                                                         Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                         isShortOptionMethod.setAccessible(true);
                                                                         boolean result = (boolean) isShortOptionMethod.invoke(parser, "-ab");
                                                                         
                                                                         assertFalse(result);
                                                                     }

    @Test
                                                                     public void testIsShortOption_NullInput_ThrowsException() throws Exception {
                                                                         DefaultParser parser = new DefaultParser();
                                                                         Method method = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                         method.setAccessible(true);
                                                                         
                                                                         try {
                                                                             method.invoke(parser, (String) null);
                                                                             fail("Expected NullPointerException to be thrown");
                                                                         } catch (InvocationTargetException e) {
                                                                             assertTrue(e.getCause() instanceof NullPointerException);
                                                                         }
                                                                     }

    @Test
                                                                     public void testIsShortOption_MultipleDashes_ReturnsFalse() throws Exception {
                                                                         DefaultParser parser = new DefaultParser();
                                                                         Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                         isShortOptionMethod.setAccessible(true);
                                                                         boolean result = (boolean) isShortOptionMethod.invoke(parser, "--option");
                                                                         assertFalse(result);
                                                                     }

    @Test
                                                                     public void testIsShortOption_ValidOptionWithEmptyValue_ReturnsTrue() throws Exception {
                                                                         Options options = mock(Options.class);
                                                                         DefaultParser parser = new DefaultParser();
                                                                         when(options.hasShortOption("a")).thenReturn(true);
                                                                         
                                                                         // Use reflection to access private method
                                                                         Method method = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                         method.setAccessible(true);
                                                                         boolean result = (boolean) method.invoke(parser, "-a=");
                                                                         
                                                                         assertTrue(result);
                                                                     }

    @Test
                                                                public void testIsShortOptionWithMultipleEqualsSigns() throws Exception {
                                                                    // Setup
                                                                    DefaultParser parser = new DefaultParser();
                                                                    Options options = mock(Options.class);
                                                                    
                                                                    // Set protected options field using reflection
                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                    optionsField.setAccessible(true);
                                                                    optionsField.set(parser, options);
                                                                    
                                                                    // Mock behavior - should check for "f" (first part before first =)
                                                                    when(options.hasShortOption("f")).thenReturn(true);
                                                                    
                                                                    // Test with token containing multiple = signs
                                                                    String token = "-f=value=extra";
                                                                    
                                                                    // Get private isShortOption method using reflection
                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                    isShortOptionMethod.setAccessible(true);
                                                                    
                                                                    // Verify
                                                                    assertTrue((Boolean) isShortOptionMethod.invoke(parser, token));
                                                                    
                                                                    // Verify mock interaction - should check for "f" not "f=value"
                                                                    verify(options).hasShortOption("f");
                                                                }

    @Test
                                                           public void testIsShortOption_WithEqualsSign_ShouldDetectShortOption() throws Exception {
                                                               // Setup
                                                               DefaultParser parser = new DefaultParser();
                                                               Options options = mock(Options.class);
                                                               
                                                               // Use reflection to set protected field
                                                               Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                               optionsField.setAccessible(true);
                                                               optionsField.set(parser, options);
                                                               
                                                               // Mock behavior - the option 'f' exists
                                                               when(options.hasShortOption("f")).thenReturn(true);
                                                               
                                                               // Test with option containing equals sign
                                                               String tokenWithValue = "-f=value";
                                                               
                                                               // Use reflection to call private method
                                                               Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                               isShortOptionMethod.setAccessible(true);
                                                               boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithValue);
                                                               
                                                               // Verify original behavior should return true
                                                               assertTrue(result);
                                                               
                                                               // Explanation: The mutant would fail here because:
                                                               // Original: finds "=" at pos 2, extracts "f" as optName
                                                               // Mutant: doesn't find "==", extracts "f=value" as optName
                                                               // hasShortOption("f") returns true (original passes)
                                                               // hasShortOption("f=value") would return false (mutant fails)
                                                           }

    @Test
                                                      public void testIsShortOption_WithEqualsSign_ShouldExtractCorrectOptionName() throws Exception {
                                                          // Setup
                                                          DefaultParser parser = new DefaultParser();
                                                          Options options = mock(Options.class);
                                                          
                                                          // Use reflection to set protected options field
                                                          Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                          optionsField.setAccessible(true);
                                                          optionsField.set(parser, options);
                                                          
                                                          // Mock behavior - return false for full option check, true for first char check
                                                          when(options.hasShortOption("a")).thenReturn(false);
                                                          when(options.hasShortOption("a=value")).thenReturn(false);
                                                          when(options.hasShortOption(String.valueOf('a'))).thenReturn(true);
                                                          
                                                          // Test with token that has equals sign
                                                          String token = "-a=value";
                                                          
                                                          // Use reflection to access private isShortOption method
                                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                          isShortOptionMethod.setAccessible(true);
                                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                          
                                                          // Original should return true (extracts "a" and checks first char)
                                                          // Mutant will return false (extracts "-a" which won't match)
                                                          assertTrue(result);
                                                          
                                                          // Verify mock interactions
                                                          verify(options).hasShortOption("a");
                                                          verify(options).hasShortOption(String.valueOf('a'));
                                                      }

    @Test
                                                 public void testIsShortOption_WithEqualsSign_ShouldNotIncludeEqualsInOptionName() throws Exception {
                                                     // Setup
                                                     DefaultParser parser = new DefaultParser();
                                                     Options options = mock(Options.class);
                                                     
                                                     // Use reflection to set protected field
                                                     Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                     optionsField.setAccessible(true);
                                                     optionsField.set(parser, options);
                                                     
                                                     // Mock behavior - "o" is a valid short option
                                                     when(options.hasShortOption("o")).thenReturn(true);
                                                     
                                                     // Use reflection to call private method
                                                     Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                     isShortOptionMethod.setAccessible(true);
                                                     boolean result = (boolean) isShortOptionMethod.invoke(parser, "-o=value");
                                                     
                                                     // Verify
                                                     assertTrue("Method should return true for valid short option with value", result);
                                                     
                                                     // Additional verification that we checked for "o" not "o="
                                                     verify(options).hasShortOption("o");
                                                     verify(options, never()).hasShortOption("o=");
                                                 }

    @Test
                                            public void testIsShortOption_ShouldReturnFalseWhenOptionNotExists() throws Exception {
                                                // Setup
                                                DefaultParser parser = new DefaultParser();
                                                Options mockOptions = mock(Options.class);
                                                
                                                // Use reflection to set protected options field
                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                optionsField.setAccessible(true);
                                                optionsField.set(parser, mockOptions);
                                                
                                                // Mock behavior - option doesn't exist
                                                when(mockOptions.hasShortOption(anyString())).thenReturn(false);
                                                
                                                // Test with valid format but non-existent option
                                                String token = "-x"; // Valid format but option doesn't exist
                                                
                                                // Use reflection to call private isShortOption method
                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                isShortOptionMethod.setAccessible(true);
                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                
                                                // Original should return false, mutant would return true
                                                assertFalse(result);
                                                
                                                // Verify the interaction
                                                verify(mockOptions).hasShortOption("x");
                                            }

    @Test
                                            public void testIsShortOption_ShouldCheckConcatenatedOptionsWhenMainOptionNotExists() throws Exception {
                                                // Setup
                                                DefaultParser parser = new DefaultParser();
                                                Options mockOptions = mock(Options.class);
                                                
                                                // Use reflection to set protected options field
                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                optionsField.setAccessible(true);
                                                optionsField.set(parser, mockOptions);
                                                
                                                // Mock behavior - main option doesn't exist but first character does
                                                when(mockOptions.hasShortOption("xy")).thenReturn(false);
                                                when(mockOptions.hasShortOption("x")).thenReturn(true);
                                                
                                                // Test with concatenated options
                                                String token = "-xy"; // Valid format, "xy" doesn't exist but "x" does
                                                
                                                // Use reflection to call private isShortOption method
                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                isShortOptionMethod.setAccessible(true);
                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                
                                                // Original should return true (due to concatenated check), mutant would return true immediately
                                                assertTrue(result);
                                                
                                                // Verify both interactions occurred (mutant would only check the first one)
                                                verify(mockOptions).hasShortOption("xy");
                                                verify(mockOptions).hasShortOption("x");
                                            }

    @Test
                                       public void testIsShortOption_WithValidShortOption_ShouldReturnTrue() throws Exception {
                                           // Setup
                                           DefaultParser parser = new DefaultParser();
                                           Options options = mock(Options.class);
                                           
                                           // Use reflection to set protected options field
                                           Field optionsField = DefaultParser.class.getDeclaredField("options");
                                           optionsField.setAccessible(true);
                                           optionsField.set(parser, options);
                                           
                                           // Mock behavior - return true for option "f"
                                           when(options.hasShortOption("f")).thenReturn(true);
                                           
                                           // Test with valid short option "-f" that exists in options
                                           String token = "-f";
                                           
                                           // Use reflection to access private isShortOption method
                                           Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                           isShortOptionMethod.setAccessible(true);
                                           boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                           
                                           // Verify
                                           assertTrue("Method should return true for existing short option", result);
                                           
                                           // Verify interaction with mock
                                           verify(options).hasShortOption("f");
                                       }

    @Test
                                  public void testIsShortOption_DetectsFullOptionNameMutation() throws Exception {
                                      // Setup
                                      DefaultParser parser = new DefaultParser();
                                      Options options = mock(Options.class);
                                      
                                      // Use reflection to set protected options field
                                      Field optionsField = DefaultParser.class.getDeclaredField("options");
                                      optionsField.setAccessible(true);
                                      optionsField.set(parser, options);
                                      
                                      // Mock behavior - return true for full option name "abc" but false for just "a"
                                      when(options.hasShortOption("abc")).thenReturn(true);
                                      when(options.hasShortOption("a")).thenReturn(false);
                                      
                                      // Use reflection to access private isShortOption method
                                      Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                      isShortOptionMethod.setAccessible(true);
                                      boolean result = (boolean) isShortOptionMethod.invoke(parser, "-abc");
                                      
                                      // Verify
                                      assertTrue("Method should return true for existing full option name", result);
                                      verify(options).hasShortOption("abc"); // This will fail if mutated to substring(0)
                                  }

    @Test
                             public void testIsShortOption_ConcatenatedInvalidOption_ShouldReturnFalse() throws Exception {
                                 // Setup
                                 DefaultParser parser = new DefaultParser();
                                 
                                 // Use reflection to set protected options field
                                 Options mockOptions = mock(Options.class);
                                 Field optionsField = DefaultParser.class.getDeclaredField("options");
                                 optionsField.setAccessible(true);
                                 optionsField.set(parser, mockOptions);
                                 
                                 // Case where optName has length > 0 but first character is not a valid option
                                 String invalidOption = "-ab"; // 'a' is invalid, 'b' is invalid
                                 when(mockOptions.hasShortOption("a")).thenReturn(false);
                                 when(mockOptions.hasShortOption("b")).thenReturn(false);
                                 
                                 // Use reflection to call private isShortOption method
                                 Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                 isShortOptionMethod.setAccessible(true);
                                 boolean result = (boolean) isShortOptionMethod.invoke(parser, invalidOption);
                                 
                                 // Test and verify
                                 assertFalse(result);
                             }

    @Test
                             public void testIsShortOption_EmptyOptionName_ShouldReturnFalse() throws Exception {
                                 // Setup
                                 DefaultParser parser = new DefaultParser();
                                 
                                 // Use reflection to set protected options field
                                 Options mockOptions = mock(Options.class);
                                 Field optionsField = DefaultParser.class.getDeclaredField("options");
                                 optionsField.setAccessible(true);
                                 optionsField.set(parser, mockOptions);
                                 
                                 // Case where optName is empty (should return false)
                                 String emptyOption = "-";
                                 when(mockOptions.hasShortOption(anyString())).thenReturn(true);
                                 
                                 // Use reflection to access private isShortOption method
                                 Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                 isShortOptionMethod.setAccessible(true);
                                 boolean result = (boolean) isShortOptionMethod.invoke(parser, emptyOption);
                                 
                                 // Test and verify
                                 assertFalse(result);
                             }

    @Test
                        public void testIsShortOptionWithEmptyOptionName() throws Exception {
                            // Setup
                            DefaultParser parser = new DefaultParser();
                            
                            // Mock options using reflection since it's protected
                            Options mockOptions = mock(Options.class);
                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                            optionsField.setAccessible(true);
                            optionsField.set(parser, mockOptions);
                            
                            // This token will result in empty optName after processing
                            String token = "-=value"; // After removing "-" and "=value", optName is empty
                            
                            // Test - original should return false, mutant would proceed to check hasShortOption
                            Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                            isShortOptionMethod.setAccessible(true);
                            boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                            
                            // Verify
                            assertFalse("Should return false for empty option name", result);
                            verify(mockOptions, never()).hasShortOption(anyString());
                        }

    @Test
                   public void testIsShortOption_ShouldReturnFalseForInvalidConcatenatedOption() throws Exception {
                       // Setup
                       DefaultParser parser = new DefaultParser();
                       Options options = mock(Options.class);
                       
                       // Use reflection to set protected field
                       Field optionsField = DefaultParser.class.getDeclaredField("options");
                       optionsField.setAccessible(true);
                       optionsField.set(parser, options);
                       
                       // Mock behavior - no short option exists for 'x'
                       when(options.hasShortOption("abc")).thenReturn(false);
                       when(options.hasShortOption("a")).thenReturn(false);
                       
                       // Use reflection to access private method
                       Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                       isShortOptionMethod.setAccessible(true);
                       
                       // Test - token is "-abc" where 'a' is not a valid short option
                       String token = "-abc";
                       boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                       
                       // Verify - should return false since first character 'a' is invalid
                       assertFalse(result);
                       
                       // Verify interactions
                       verify(options).hasShortOption("abc");
                       verify(options).hasShortOption("a");
                   }

    @Test
              public void testIsShortOption_WithEqualsSign_ShouldDetectOptionBeforeEqual() throws Exception {
                  // Setup
                  DefaultParser parser = new DefaultParser();
                  Options options = mock(Options.class);
                  
                  // Use reflection to set protected options field
                  Field optionsField = DefaultParser.class.getDeclaredField("options");
                  optionsField.setAccessible(true);
                  optionsField.set(parser, options);
                  
                  // Mock behavior - option "f" exists
                  when(options.hasShortOption("f")).thenReturn(true);
                  
                  // Test with option containing "="
                  String tokenWithValue = "-f=value";
                  
                  // Use reflection to access private isShortOption method
                  Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                  isShortOptionMethod.setAccessible(true);
                  boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithValue);
                  
                  // Original behavior should return true (f is a valid option)
                  // Mutated behavior would return false (would look for "-f=value" as whole option)
                  assertTrue(result);
                  
                  // Verify mock interaction
                  verify(options).hasShortOption("f");
              }

    @Test
         public void testIsShortOption_WithEqualsSign_ShouldDetectOption() throws Exception {
             // Setup
             DefaultParser parser = new DefaultParser();
             Options options = mock(Options.class);
             
             // Use reflection to set protected options field
             Field optionsField = DefaultParser.class.getDeclaredField("options");
             optionsField.setAccessible(true);
             optionsField.set(parser, options);
             
             // Get private isShortOption method
             Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
             isShortOptionMethod.setAccessible(true);
             
             // Test case 1: Single option with value (e.g., "-f=value")
             when(options.hasShortOption("f")).thenReturn(true);
             assertTrue("Should recognize valid short option with value", 
                       (boolean) isShortOptionMethod.invoke(parser, "-f=value"));
             
             // Test case 2: Concatenated options with value (e.g., "-abc=value")
             when(options.hasShortOption("a")).thenReturn(true);
             assertTrue("Should recognize first option in concatenated options with value", 
                       (boolean) isShortOptionMethod.invoke(parser, "-abc=value"));
             
             // Verify interactions
             verify(options).hasShortOption("f");
             verify(options).hasShortOption("a");
         }

    @Test
    public void testIsShortOption_WithSingleCharConcatenatedOption() throws Exception {
        // Setup
        DefaultParser parser = new DefaultParser();
        Options options = mock(Options.class);
        
        // Use reflection to set protected field
        Field optionsField = DefaultParser.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        optionsField.set(parser, options);
        
        // Mock behavior - full option name doesn't exist, but first character does
        when(options.hasShortOption("a")).thenReturn(false);
        when(options.hasShortOption("b")).thenReturn(true);
        
        // Use reflection to access private method
        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
        isShortOptionMethod.setAccessible(true);
        
        // Test single character option that should be checked for concatenation
        boolean result = (boolean) isShortOptionMethod.invoke(parser, "-b");
        assertTrue("Should return true for single char concatenated option", result);
        
        // Verify mock interactions
        verify(options).hasShortOption("b");
        verify(options).hasShortOption(String.valueOf("b".charAt(0)));
    }


}
