package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
 
public class UtilTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                           public void testStripLeadingHyphens_NullInput() throws Exception {
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method stripLeadingHyphensMethod = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                               stripLeadingHyphensMethod.setAccessible(true);
                               
                               String result = (String) stripLeadingHyphensMethod.invoke(null, (String) null);
                               assertNull(result);
                           }

    @Test
                           public void testStripLeadingHyphens_EmptyString() throws Exception {
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                               stripLeadingHyphens.setAccessible(true);
                               
                               String result = (String) stripLeadingHyphens.invoke(null, "");
                               assertEquals("", result);
                           }

    @Test
                           public void testStripLeadingHyphens_SingleHyphen() throws Exception {
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                               stripLeadingHyphens.setAccessible(true);
                               
                               String input = "-test";
                               String expected = "test";
                               String result = (String) stripLeadingHyphens.invoke(null, input);
                               
                               assertEquals(expected, result);
                           }

    @Test
                           public void testStripLeadingHyphens_DoubleHyphen() throws Exception {
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                               stripLeadingHyphens.setAccessible(true);
                               
                               String input = "--test";
                               String result = (String) stripLeadingHyphens.invoke(null, input);
                               assertEquals("test", result);
                           }

    @Test
                           public void testStripLeadingHyphens_MultipleHyphens() throws Exception {
                               // Get the stripLeadingHyphens method via reflection
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                               stripLeadingHyphens.setAccessible(true);
                               
                               // Invoke the method
                               String result = (String) stripLeadingHyphens.invoke(null, "---test");
                               
                               // Only strips first two hyphens according to method logic
                               assertEquals("-test", result);
                           }

    @Test
                           public void testStripLeadingHyphens_NoHyphen() throws Exception {
                               String input = "testString";
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                               stripLeadingHyphens.setAccessible(true);
                               String result = (String) stripLeadingHyphens.invoke(null, input);
                               assertEquals(input, result);
                           }

    @Test
                           public void testStripLeadingHyphens_SingleHyphenOnly() throws Exception {
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                               stripLeadingHyphens.setAccessible(true);
                               
                               String input = "-";
                               String result = (String) stripLeadingHyphens.invoke(null, input);
                               assertEquals("", result);
                           }

    @Test
                           public void testStripLeadingHyphens_DoubleHyphenOnly() throws Exception {
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                               stripLeadingHyphens.setAccessible(true);
                               String result = (String) stripLeadingHyphens.invoke(null, "--");
                               assertEquals("", result);
                           }

    @Test
                           public void testStripLeadingHyphens_WithSpecialCharacters() throws Exception {
                               // Get the Util class
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               // Get the stripLeadingHyphens method
                               Method method = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                               // Make the method accessible
                               method.setAccessible(true);
                               
                               // Invoke the method
                               String result = (String) method.invoke(null, "--@#$%");
                               assertEquals("@#$%", result);
                           }

    @Test
                           public void testStripLeadingHyphens_WithNumbers() throws Exception {
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                               stripLeadingHyphens.setAccessible(true);
                               String result = (String) stripLeadingHyphens.invoke(null, "--123");
                               assertEquals("123", result);
                           }

    @Test
                       public void testStripLeadingHyphens_WithSpaces() throws Exception {
                           String input = "- test string";
                           String expected = " test string";
                           
                           // Get the method using reflection
                           Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                           Method stripMethod = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                           stripMethod.setAccessible(true);
                           
                           // Invoke the method
                           String result = (String) stripMethod.invoke(null, input);
                           assertEquals(expected, result);
                       }

    @Test
                  public void testStripLeadingHyphens_withNullInput_shouldReturnNull() throws Exception {
                      // Arrange
                      String input = null;
                      
                      // Get the method via reflection
                      Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                      Method stripLeadingHyphensMethod = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                      stripLeadingHyphensMethod.setAccessible(true);
                      
                      // Act
                      String result = (String) stripLeadingHyphensMethod.invoke(null, input);
                      
                      // Assert
                      assertNull("Method should return null for null input", result);
                  }

    @Test
             public void testStripLeadingHyphens_doubleHyphen() throws Exception {
                 // This test will catch the mutant
                 String input = "--test";
                 
                 // Original behavior: should just remove "--" -> "test"
                 // Mutated behavior: would first remove "--" -> "test", 
                 // then check for "-" again and remove "t" -> "est"
                 
                 // Get the method using reflection
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                 stripLeadingHyphens.setAccessible(true);
                 
                 // Invoke the method
                 String result = (String) stripLeadingHyphens.invoke(null, input);
                 
                 assertEquals("test", result);
             }

    @Test
             public void testStripLeadingHyphens_singleHyphen() throws Exception {
                 String input = "-test";
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                 stripLeadingHyphens.setAccessible(true);
                 String result = (String) stripLeadingHyphens.invoke(null, input);
                 assertEquals("test", result);
             }

    @Test
             public void testStripLeadingHyphens_noHyphen() throws Exception {
                 String input = "test";
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method stripMethod = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                 stripMethod.setAccessible(true);
                 String result = (String) stripMethod.invoke(null, input);
                 assertEquals("test", result);
             }

    @Test
             public void testStripLeadingHyphens_nullInput() throws Exception {
                 String input = null;
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                 stripLeadingHyphens.setAccessible(true);
                 String result = (String) stripLeadingHyphens.invoke(null, input);
                 assertNull(result);
             }

    @Test
         public void testStripLeadingHyphens_doubleHyphenFollowedBySingle() {
             String input = "-test";
             
             try {
                 // Get the Util class
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 
                 // Get the stripLeadingHyphens method
                 Method method = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                 method.setAccessible(true);
                 
                 // Invoke the method
                 String result = (String) method.invoke(null, input);
                 
                 assertEquals("test", result);
             } catch (Exception e) {
                 fail("Failed to invoke stripLeadingHyphens method: " + e.getMessage());
             }
         }

    @Test
    public void testStripLeadingHyphens_containsHyphenButNotAtStart() throws Exception {
        // Get the private method via reflection
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
        stripLeadingHyphens.setAccessible(true);
        
        // Test case where hyphen appears in middle of string
        String input1 = "abc-def";
        assertEquals("Should return unchanged when hyphen in middle", 
                    input1, stripLeadingHyphens.invoke(null, input1));
        
        // Test case where hyphen appears at end of string
        String input2 = "abcdef-";
        assertEquals("Should return unchanged when hyphen at end",
                    input2, stripLeadingHyphens.invoke(null, input2));
        
        // Test case with multiple hyphens but not starting with one
        String input3 = "a-b-c-d";
        assertEquals("Should return unchanged with multiple hyphens not at start",
                    input3, stripLeadingHyphens.invoke(null, input3));
        
        // Test case with hyphen after whitespace
        String input4 = " abc-def";
        assertEquals("Should return unchanged when hyphen after whitespace",
                    input4, stripLeadingHyphens.invoke(null, input4));
    }


}
