package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
 
public class OptionGroupTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                 public void testSetSelected_WithNullOption_ResetsSelection() {
                                                                                     OptionGroup optionGroup = new OptionGroup();
                                                                                     try {
                                                                                         optionGroup.setSelected(null);
                                                                                         assertNull(optionGroup.getSelected());
                                                                                     } catch (AlreadySelectedException e) {
                                                                                         fail("Unexpected AlreadySelectedException thrown");
                                                                                     }
                                                                                 }

    @Test
                                                                                 public void testSetSelected_WhenNoOptionSelected_SetsNewSelection() throws AlreadySelectedException {
                                                                                     OptionGroup optionGroup = new OptionGroup();
                                                                                     Option mockOption = mock(Option.class);
                                                                                     
                                                                                     // Add the mock option to the group first
                                                                                     optionGroup.addOption(mockOption);
                                                                                     
                                                                                     // Set the mock option as selected
                                                                                     optionGroup.setSelected(mockOption);
                                                                                     
                                                                                     // Verify the selected option is the one we set
                                                                                     assertSame(mockOption, optionGroup.getSelected());
                                                                                 }

    @Test
                                                                                 public void testSetSelected_WhenSameOptionReselected_KeepsSelection() {
                                                                                     OptionGroup optionGroup = new OptionGroup();
                                                                                     Option mockOption = mock(Option.class);
                                                                                     
                                                                                     // Mock the option's toString() to return a known value since we can't access getKey()
                                                                                     when(mockOption.toString()).thenReturn("option1");
                                                                                     
                                                                                     try {
                                                                                         // First selection
                                                                                         optionGroup.setSelected(mockOption);
                                                                                         // Reselect same option
                                                                                         optionGroup.setSelected(mockOption);
                                                                                         
                                                                                         // Verify the selected option matches our mocked toString() value
                                                                                         assertEquals("option1", optionGroup.getSelected());
                                                                                     } catch (AlreadySelectedException e) {
                                                                                         fail("Reselecting same option should not throw AlreadySelectedException");
                                                                                     }
                                                                                 }

    @Test
                                                                                 public void testSetSelected_AfterReset_AllowsNewSelection() throws AlreadySelectedException {
                                                                                     OptionGroup optionGroup = new OptionGroup();
                                                                                     Option mockOption1 = mock(Option.class);
                                                                                     Option mockOption2 = mock(Option.class);
                                                                                     
                                                                                     // First selection
                                                                                     optionGroup.setSelected(mockOption1);
                                                                                     // Reset
                                                                                     optionGroup.setSelected(null);
                                                                                     // New selection
                                                                                     optionGroup.setSelected(mockOption2);
                                                                                     
                                                                                     assertEquals(mockOption2, optionGroup.getSelected());
                                                                                 }

    @Test
                                                                                 public void testSetSelected_WhenDifferentOptionSelected_ThrowsException() throws AlreadySelectedException {
                                                                                     OptionGroup optionGroup = new OptionGroup();
                                                                                     Option mockOption1 = mock(Option.class);
                                                                                     when(mockOption1.getOpt()).thenReturn("option1");
                                                                                     Option mockOption2 = mock(Option.class);
                                                                                     when(mockOption2.getOpt()).thenReturn("option2");
                                                                                     
                                                                                     ExpectedException exception = ExpectedException.none();
                                                                                     exception.expect(AlreadySelectedException.class);
                                                                                     
                                                                                     // First selection (should not throw exception)
                                                                                     optionGroup.setSelected(mockOption1);
                                                                                     
                                                                                     // Second selection should throw exception
                                                                                     optionGroup.setSelected(mockOption2);
                                                                                 }

    @Test
                                                                    public void testSetSelectedSameOptionTwiceShouldNotThrowException() {
                                                                        // Setup
                                                                        OptionGroup optionGroup = new OptionGroup();
                                                                        Option option1 = mock(Option.class);
                                                                        
                                                                        // Mock toString() instead of getKey() since it's public
                                                                        when(option1.toString()).thenReturn("opt1");
                                                                        
                                                                        try {
                                                                            // First selection should work
                                                                            optionGroup.setSelected(option1);
                                                                            
                                                                            // Second selection of same option should work (original behavior)
                                                                            // Mutant would throw exception here
                                                                            optionGroup.setSelected(option1);
                                                                        } catch (AlreadySelectedException e) {
                                                                            fail("Same option selection twice should not throw exception");
                                                                        }
                                                                        
                                                                        // Verify selection was maintained - using toString() representation
                                                                        assertEquals("opt1", optionGroup.getSelected());
                                                                    }

    @Test(expected = AlreadySelectedException.class)
                                                                    public void testSetSelectedDifferentOptionShouldThrowException() throws AlreadySelectedException {
                                                                        // Setup
                                                                        OptionGroup optionGroup = new OptionGroup();
                                                                        Option option1 = mock(Option.class);
                                                                        Option option2 = mock(Option.class);
                                                                        
                                                                        // First selection
                                                                        optionGroup.setSelected(option1);
                                                                        
                                                                        // Second different selection should throw exception (original behavior)
                                                                        // Mutant would allow this
                                                                        optionGroup.setSelected(option2);
                                                                    }

    @Test
                                                           public void testSetSelected_ReselectSameOption_ShouldNotThrowException() {
                                                               // Setup
                                                               OptionGroup optionGroup = new OptionGroup();
                                                               Option option = mock(Option.class);
                                                               
                                                               // First selection - should work
                                                               try {
                                                                   optionGroup.setSelected(option);
                                                               } catch (AlreadySelectedException e) {
                                                                   fail("First selection should not throw AlreadySelectedException");
                                                               }
                                                               
                                                               try {
                                                                   // Second selection of same option - should work in original, throw in mutant
                                                                   optionGroup.setSelected(option);
                                                                   
                                                                   // Verify selection is still set by checking if the option is in the group
                                                                   assertTrue(optionGroup.getOptions().contains(option));
                                                               } catch (AlreadySelectedException e) {
                                                                   // This assertion will fail for original code but pass for mutant
                                                                   fail("Reselecting same option should not throw AlreadySelectedException");
                                                               }
                                                           }

    @Test(expected = AlreadySelectedException.class)
                                                      public void testSetSelected_shouldThrowWhenSelectingDifferentOption() throws AlreadySelectedException {
                                                          // Setup
                                                          OptionGroup optionGroup = new OptionGroup();
                                                          
                                                          // Create two different options
                                                          Option firstOption = mock(Option.class);
                                                          Option secondOption = mock(Option.class);
                                                          
                                                          // First selection should work
                                                          optionGroup.setSelected(firstOption);
                                                          
                                                          // Second selection with different option should throw
                                                          optionGroup.setSelected(secondOption);
                                                          
                                                          // If no exception is thrown, the test will fail
                                                      }

    @Test(expected = NullPointerException.class)
                                                 public void testSetSelectedWithNullKeyShouldThrowNPE() throws Exception {
                                                     // Setup
                                                     OptionGroup optionGroup = new OptionGroup();
                                                     
                                                     // Create first option with null key using reflection
                                                     Option option = mock(Option.class);
                                                     Field keyField = Option.class.getDeclaredField("key");
                                                     keyField.setAccessible(true);
                                                     keyField.set(option, null);
                                                     
                                                     // First selection (should work)
                                                     optionGroup.setSelected(option);
                                                     
                                                     // Create another option with null key
                                                     Option anotherOption = mock(Option.class);
                                                     keyField.set(anotherOption, null);
                                                     
                                                     // This should throw NPE
                                                     optionGroup.setSelected(anotherOption);
                                                 }

    @Test
                                            public void testSetSelectedWithEqualButDifferentStringObjects() throws AlreadySelectedException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
                                                // Setup
                                                OptionGroup optionGroup = new OptionGroup();
                                                Option option1 = mock(Option.class);
                                                Option option2 = mock(Option.class);
                                                
                                                // Create two different String objects with same value
                                                String key1 = new String("testKey");
                                                String key2 = new String("testKey");
                                                
                                                // Use reflection to access private getKey() method
                                                Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                getKeyMethod.setAccessible(true);
                                                
                                                // Mock the options to return these different-but-equal keys
                                                when(getKeyMethod.invoke(option1)).thenReturn(key1);
                                                when(getKeyMethod.invoke(option2)).thenReturn(key2);
                                                
                                                // First selection should work
                                                optionGroup.setSelected(option1);
                                                
                                                // Second selection with equal value should work in original,
                                                // but mutated version would throw AlreadySelectedException
                                                optionGroup.setSelected(option2);
                                                
                                                // Verify the selected value is updated (would fail in mutated version)
                                                assertEquals(key2, optionGroup.getSelected());
                                            }

    @Test
                                       public void testSetSelectedStoresOptionKey() throws AlreadySelectedException {
                                           // Setup
                                           OptionGroup optionGroup = new OptionGroup();
                                           Option option = mock(Option.class);
                                           
                                           // We'll verify the selected option through the OptionGroup's public API
                                           optionGroup.addOption(option);
                                           
                                           // Exercise
                                           optionGroup.setSelected(option);
                                           
                                           // Verify
                                           assertSame(option, optionGroup.getSelected());
                                           
                                           // Additional verification that it works for reselection
                                           optionGroup.setSelected(option);
                                           assertSame(option, optionGroup.getSelected());
                                       }

    @Test
                                  public void testSetSelectedDetectsMutant() throws AlreadySelectedException {
                                      // Setup test objects
                                      Option option1 = mock(Option.class);
                                      when(option1.toString()).thenReturn("opt1");
                                      
                                      Option option2 = mock(Option.class);
                                      when(option2.toString()).thenReturn("opt2");
                                      
                                      OptionGroup optionGroup = new OptionGroup();
                                      
                                      // First selection should work (no previous selection)
                                      optionGroup.setSelected(option1);
                                      assertEquals("opt1", optionGroup.getSelected());
                                      
                                      // Second selection with different option should update selection in original,
                                      // but mutant would keep old value
                                      optionGroup.setSelected(option2);
                                      // This assertion would pass in original but fail in mutated code
                                      assertEquals("opt2", optionGroup.getSelected());
                                      
                                      // Verify interactions
                                      verify(option1).toString();
                                      verify(option2).toString();
                                  }

    @Test
                             public void testSetSelectedActuallySetsTheSelection() throws AlreadySelectedException {
                                 // Setup
                                 OptionGroup optionGroup = new OptionGroup();
                                 Option option = mock(Option.class);
                                 
                                 // We'll use reflection to access the private key field of Option
                                 try {
                                     Field keyField = Option.class.getDeclaredField("key");
                                     keyField.setAccessible(true);
                                     keyField.set(option, "testKey");
                                 } catch (Exception e) {
                                     fail("Failed to set key field via reflection");
                                 }
                                 
                                 // Action - set selection for the first time (should work)
                                 optionGroup.setSelected(option);
                                 
                                 // Verification - check if selection was actually set
                                 assertEquals("testKey", optionGroup.getSelected());
                                 
                                 // Additional test: verify reselecting same option maintains the selection
                                 optionGroup.setSelected(option);
                                 assertEquals("testKey", optionGroup.getSelected());
                             }

    @Test(expected = AlreadySelectedException.class)
                        public void testSetSelected_shouldThrowWhenSelectingDifferentOption1() throws AlreadySelectedException {
                            // Setup
                            OptionGroup optionGroup = new OptionGroup();
                            Option option1 = mock(Option.class);
                            Option option2 = mock(Option.class);
                            
                            // Mock toString() instead of getKey() since getKey() is not accessible
                            when(option1.toString()).thenReturn("opt1");
                            when(option2.toString()).thenReturn("opt2");
                            
                            // First selection should work
                            optionGroup.setSelected(option1);
                            
                            // Second different selection should throw
                            optionGroup.setSelected(option2);
                            
                            // If we reach here, the mutant survived (no exception thrown)
                            // So we need to verify the selection wasn't changed
                            // This is just a backup check - the main detection is the expected exception
                            assertEquals("opt1", optionGroup.getSelected());
                        }

    @Test
                   public void testSetSelectedFirstSelectionShouldBeAccepted() throws Exception {
                       // Setup
                       OptionGroup optionGroup = new OptionGroup();
                       Option option = mock(Option.class);
                       
                       // We'll use reflection to set the key since getKey() isn't accessible
                       Field keyField = Option.class.getDeclaredField("key");
                       keyField.setAccessible(true);
                       keyField.set(option, "testKey");
                       
                       // Exercise
                       optionGroup.setSelected(option);
                       
                       // Verify
                       // If the method works correctly, it should accept the first selection
                       // If mutant is present, it would throw AlreadySelectedException
                       assertEquals("testKey", optionGroup.getSelected());
                   }

    @Test(expected = Exception.class)
                   public void testSetSelectedDifferentOptionShouldThrowException1() throws Exception {
                       // Setup
                       OptionGroup optionGroup = new OptionGroup();
                       
                       // Create mock options without directly calling getKey()
                       Option option1 = mock(Option.class);
                       // Instead of using getKey(), we'll use toString() which is public
                       when(option1.toString()).thenReturn("firstKey");
                       
                       Option option2 = mock(Option.class);
                       when(option2.toString()).thenReturn("secondKey");
                       
                       // First selection should work
                       optionGroup.setSelected(option1);
                       
                       // Second different selection should throw
                       optionGroup.setSelected(option2);
                   }

    @Test
                   public void testSetSelectedNullOptionShouldResetSelection() throws Exception {
                       // Setup
                       OptionGroup optionGroup = new OptionGroup();
                       Option option = mock(Option.class);
                       when(option.toString()).thenReturn("testKey");
                       optionGroup.setSelected(option);
                       
                       // Exercise
                       optionGroup.setSelected(null);
                       
                       // Verify
                       assertNull(optionGroup.getSelected());
                   }

    @Test(expected = NullPointerException.class)
              public void testSetSelectedWithNullOptionKeyShouldThrowNPE() throws AlreadySelectedException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
                  // Setup
                  OptionGroup optionGroup = new OptionGroup();
                  Option option1 = mock(Option.class);
                  
                  // Use reflection to access private getKey() method
                  Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                  getKeyMethod.setAccessible(true);
                  
                  // First set a valid selection
                  when(getKeyMethod.invoke(option1)).thenReturn("key1");
                  optionGroup.setSelected(option1);
                  
                  // Now try to set an option with null key
                  Option optionWithNullKey = mock(Option.class);
                  when(getKeyMethod.invoke(optionWithNullKey)).thenReturn(null);
                  
                  // This should throw NPE
                  optionGroup.setSelected(optionWithNullKey);
              }

    @Test
         public void testSetSelectedStoresKeyNotToString() throws Exception {
             // Setup
             OptionGroup optionGroup = new OptionGroup();
             Option option = mock(Option.class);
             
             // Use reflection to access the private getKey() method
             Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
             getKeyMethod.setAccessible(true);
             when(getKeyMethod.invoke(option)).thenReturn("testKey");
             
             when(option.toString()).thenReturn("Option@1234");
         
             // Execute
             optionGroup.setSelected(option);
         
             // Verify
             // The original behavior should store the key, mutant stores toString
             assertEquals("testKey", optionGroup.getSelected());
             
             // Additional verification that toString wasn't stored
             assertNotEquals("Option@1234", optionGroup.getSelected());
         }

    @Test
    public void testSetSelectedStoresCorrectKey() throws AlreadySelectedException {
        // Setup
        OptionGroup optionGroup = new OptionGroup();
        Option option = mock(Option.class);
        
        // Use reflection to access the private key field in Option
        try {
            Field keyField = Option.class.getDeclaredField("key");
            keyField.setAccessible(true);
            keyField.set(option, "testKey");
        } catch (Exception e) {
            fail("Failed to set up test due to reflection error: " + e.getMessage());
        }
        
        // Exercise
        optionGroup.setSelected(option);
        
        // Verify
        assertEquals("testKey", optionGroup.getSelected());
    }


}
