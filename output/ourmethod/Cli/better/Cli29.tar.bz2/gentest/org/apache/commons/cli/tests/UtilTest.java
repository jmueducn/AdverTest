package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
 
public class UtilTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
             public void testStripLeadingAndTrailingQuotes_EmptyString() throws Exception {
                 String input = "";
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 method.setAccessible(true);
                 String result = (String) method.invoke(null, input);
                 assertEquals("", result);
             }

    @Test
             public void testStripLeadingAndTrailingQuotes_SingleCharacter() throws Exception {
                 String input = "\"";
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 method.setAccessible(true);
                 String result = (String) method.invoke(null, input);
                 assertEquals("\"", result);
             }

    @Test
             public void testStripLeadingAndTrailingQuotes_NoQuotes() throws Exception {
                 String input = "hello world";
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 method.setAccessible(true);
                 String result = (String) method.invoke(null, input);
                 assertEquals("hello world", result);
             }

    @Test
             public void testStripLeadingAndTrailingQuotes_OnlyQuotes() throws Exception {
                 String input = "\"\"";
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 stripMethod.setAccessible(true);
                 String result = (String) stripMethod.invoke(null, input);
                 assertEquals("", result);
             }

    @Test
             public void testStripLeadingAndTrailingQuotes_WithQuotes() throws Exception {
                 String input = "\"hello\"";
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 method.setAccessible(true);
                 String result = (String) method.invoke(null, input);
                 assertEquals("hello", result);
             }

    @Test
             public void testStripLeadingAndTrailingQuotes_WithInternalQuotes() throws Exception {
                 String input = "\"hello\"world\"";
                 
                 // Get the Util class using reflection
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 // Get the method
                 java.lang.reflect.Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 // Make it accessible
                 method.setAccessible(true);
                 // Invoke the method
                 String result = (String) method.invoke(null, input);
                 
                 assertEquals("\"hello\"world\"", result);
             }

    @Test
             public void testStripLeadingAndTrailingQuotes_OnlyStartQuote() throws Exception {
                 String input = "\"hello";
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 stripMethod.setAccessible(true);
                 String result = (String) stripMethod.invoke(null, input);
                 assertEquals("\"hello", result);
             }

    @Test
             public void testStripLeadingAndTrailingQuotes_OnlyEndQuote() throws Exception {
                 String input = "hello\"";
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 stripMethod.setAccessible(true);
                 String result = (String) stripMethod.invoke(null, input);
                 assertEquals("hello\"", result);
             }

    @Test
             public void testStripLeadingAndTrailingQuotes_MultipleQuotesAtEnds() throws Exception {
                 String input = "\"\"\"hello\"\"\"";
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 stripMethod.setAccessible(true);
                 String result = (String) stripMethod.invoke(null, input);
                 assertEquals("\"\"hello\"\"", result);
             }

    @Test
             public void testStripLeadingAndTrailingQuotes_NullInput() throws Exception {
                 ExpectedException exceptionRule = ExpectedException.none();
                 exceptionRule.expect(NullPointerException.class);
                 
                 // Get the Util class and method using reflection
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 stripMethod.setAccessible(true);
                 
                 // Invoke the method with null input
                 stripMethod.invoke(null, (String)null);
             }

    @Test
             public void testStripLeadingAndTrailingQuotes_SpecialCharacters() throws Exception {
                 String input = "\"!@#$%^&*()\"";
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 stripMethod.setAccessible(true);
                 String result = (String) stripMethod.invoke(null, input);
                 assertEquals("!@#$%^&*()", result);
             }

    @Test
             public void testStripLeadingAndTrailingQuotes_LongString() throws Exception {
                 String input = "\"This is a very long string with multiple words that should be properly handled by the method\"";
                 
                 // Get the Util class and method using reflection
                 Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                 Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                 stripMethod.setAccessible(true);
                 
                 // Invoke the method
                 String result = (String) stripMethod.invoke(null, input);
                 
                 assertEquals("This is a very long string with multiple words that should be properly handled by the method", result);
             }

    @Test
         public void testStripLeadingAndTrailingQuotes_WhitespaceInsideQuotes() throws Exception {
             String input = "\"  hello  \"";
             Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
             Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
             stripMethod.setAccessible(true);
             String result = (String) stripMethod.invoke(null, input);
             assertEquals("  hello  ", result);
         }

    @Test
    public void testStripLeadingAndTrailingQuotes_returnsSameObjectWhenNoChangeNeeded() throws Exception {
        // Arrange
        String input = "hello";
        
        // Get the method via reflection
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
        stripMethod.setAccessible(true);
        
        // Act
        String result = (String) stripMethod.invoke(null, input);
        
        // Assert
        // This will fail if the mutant (return str + "") is present
        // because it will return a new String object instead of the original
        assertSame("Should return the same String object when no quotes are stripped", 
                  input, result);
    }

    @Test
    public void testStripLeadingAndTrailingQuotes_removesQuotesWhenPresent() throws Exception {
        // Arrange
        String input = "\"quoted\"";
        String expected = "quoted";
        
        // Get the Util class and method using reflection
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
        stripMethod.setAccessible(true);
        
        // Act
        String result = (String) stripMethod.invoke(null, input);
        
        // Assert
        assertEquals("Should remove surrounding quotes", expected, result);
    }

    @Test
    public void testStripLeadingAndTrailingQuotes_doesNotRemoveQuotesIfInnerQuotesExist() throws Exception {
        // Arrange
        String input = "\"quo\"ted\"";
        
        // Get the method via reflection
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
        stripMethod.setAccessible(true);
        
        // Act
        String result = (String) stripMethod.invoke(null, input);
        
        // Assert
        assertEquals("Should not remove quotes when inner quotes exist", input, result);
    }

    @Test
    public void testStripLeadingAndTrailingQuotes_handlesEmptyString() throws Exception {
        // Arrange
        String input = "";
        
        // Get the method via reflection
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
        stripMethod.setAccessible(true);
        
        // Act
        String result = (String) stripMethod.invoke(null, input);
        
        // Assert
        assertEquals("Should return empty string unchanged", input, result);
    }


}
