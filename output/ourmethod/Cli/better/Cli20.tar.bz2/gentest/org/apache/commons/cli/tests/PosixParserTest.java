package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
 
public class PosixParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                      public void testFlatten_LongOptionWithoutValue() throws Exception {
                                                                                          // Create mock Options
                                                                                          Options options = mock(Options.class);
                                                                                          when(options.hasOption("--foo")).thenReturn(true);
                                                                                          
                                                                                          // Create parser instance
                                                                                          PosixParser parser = new PosixParser();
                                                                                          
                                                                                          // Get the flatten method using reflection
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", 
                                                                                              Options.class, 
                                                                                              String[].class, 
                                                                                              boolean.class
                                                                                          );
                                                                                          flattenMethod.setAccessible(true);
                                                                                          
                                                                                          String[] args = {"--foo"};
                                                                                          String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                          assertArrayEquals(new String[]{"--foo"}, result);
                                                                                      }

    @Test
                                                                                      public void testFlatten_LongOptionWithValue() throws Exception {
                                                                                          Options options = mock(Options.class);
                                                                                          when(options.hasOption("--foo")).thenReturn(true);
                                                                                          PosixParser parser = new PosixParser();
                                                                                          String[] args = {"--foo=bar"};
                                                                                          
                                                                                          // Use reflection to access protected flatten method
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", 
                                                                                              Options.class, 
                                                                                              String[].class, 
                                                                                              boolean.class
                                                                                          );
                                                                                          flattenMethod.setAccessible(true);
                                                                                          String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                          
                                                                                          assertArrayEquals(new String[]{"--foo", "bar"}, result);
                                                                                      }

    @Test
                                                                                      public void testFlatten_UnknownLongOptionWithStopAtNonOption() throws Exception {
                                                                                          Options options = mock(Options.class);
                                                                                          when(options.hasOption("--unknown")).thenReturn(false);
                                                                                          PosixParser parser = new PosixParser();
                                                                                          String[] args = {"--unknown"};
                                                                                          
                                                                                          // Get the protected flatten method using reflection
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", 
                                                                                              Options.class, 
                                                                                              String[].class, 
                                                                                              boolean.class
                                                                                          );
                                                                                          flattenMethod.setAccessible(true);
                                                                                          
                                                                                          // Invoke the method
                                                                                          String[] result = (String[]) flattenMethod.invoke(parser, options, args, true);
                                                                                          
                                                                                          assertArrayEquals(new String[]{"--unknown"}, result);
                                                                                      }

    @Test
                                                                                      public void testFlatten_SingleHyphen() throws Exception {
                                                                                          Options options = new Options();
                                                                                          PosixParser parser = new PosixParser();
                                                                                          String[] args = {"-"};
                                                                                          
                                                                                          // Use reflection to access protected flatten method
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", 
                                                                                              Options.class, 
                                                                                              String[].class, 
                                                                                              boolean.class
                                                                                          );
                                                                                          flattenMethod.setAccessible(true);
                                                                                          String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                          
                                                                                          assertArrayEquals(new String[]{"-"}, result);
                                                                                      }

    @Test
                                                                                      public void testFlatten_ShortOption() throws Exception {
                                                                                          // Create mock objects
                                                                                          Options options = mock(Options.class);
                                                                                          PosixParser parser = new PosixParser();
                                                                                          
                                                                                          // Setup mock behavior
                                                                                          when(options.hasOption("-f")).thenReturn(true);
                                                                                          
                                                                                          // Test data
                                                                                          String[] args = {"-f"};
                                                                                          
                                                                                          // Get the protected flatten method via reflection
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", 
                                                                                              Options.class, 
                                                                                              String[].class, 
                                                                                              boolean.class
                                                                                          );
                                                                                          flattenMethod.setAccessible(true);
                                                                                          
                                                                                          // Execute test using reflection
                                                                                          String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                          
                                                                                          // Verify
                                                                                          assertArrayEquals(new String[]{"-f"}, result);
                                                                                      }

    @Test
                                                                                      public void testFlatten_ShortOptionBursting() throws Exception {
                                                                                          // Create mock Options
                                                                                          Options options = mock(Options.class);
                                                                                          when(options.hasOption("-a")).thenReturn(true);
                                                                                          when(options.hasOption("-b")).thenReturn(true);
                                                                                          when(options.hasOption("-c")).thenReturn(false);
                                                                                          
                                                                                          // Create parser instance
                                                                                          PosixParser parser = new PosixParser();
                                                                                          
                                                                                          // Get the protected flatten method via reflection
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", Options.class, String[].class, boolean.class);
                                                                                          flattenMethod.setAccessible(true);
                                                                                          
                                                                                          String[] args = {"-abc"};
                                                                                          // Invoke the method using reflection
                                                                                          String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                          
                                                                                          assertArrayEquals(new String[]{"-a", "-b", "-c"}, result);
                                                                                      }

    @Test
                                                                                      public void testFlatten_NonOptionArgument() throws Exception {
                                                                                          Options options = new Options();
                                                                                          PosixParser parser = new PosixParser();
                                                                                          String[] args = {"filename"};
                                                                                          
                                                                                          // Use reflection to access protected flatten method
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", 
                                                                                              Options.class, 
                                                                                              String[].class, 
                                                                                              boolean.class
                                                                                          );
                                                                                          flattenMethod.setAccessible(true);
                                                                                          
                                                                                          String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                          assertArrayEquals(new String[]{"filename"}, result);
                                                                                      }

    @Test
                                                                                      public void testFlatten_NonOptionArgumentWithStopAtNonOption() throws Exception {
                                                                                          // Create required objects
                                                                                          Options options = new Options();
                                                                                          PosixParser parser = new PosixParser();
                                                                                          
                                                                                          String[] args = {"filename"};
                                                                                          
                                                                                          // Get the protected flatten method using reflection
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", 
                                                                                              Options.class, 
                                                                                              String[].class, 
                                                                                              boolean.class
                                                                                          );
                                                                                          flattenMethod.setAccessible(true);
                                                                                          
                                                                                          // Invoke the method
                                                                                          String[] result = (String[]) flattenMethod.invoke(parser, options, args, true);
                                                                                          
                                                                                          assertArrayEquals(new String[]{"filename"}, result);
                                                                                      }

    @Test
                                                                                      public void testFlatten_MixedArguments() throws Exception {
                                                                                          // Create mock objects
                                                                                          Options options = mock(Options.class);
                                                                                          PosixParser parser = new PosixParser();
                                                                                          
                                                                                          // Set up mock behavior
                                                                                          when(options.hasOption("--output")).thenReturn(true);
                                                                                          when(options.hasOption("-v")).thenReturn(true);
                                                                                          
                                                                                          // Test data
                                                                                          String[] args = {"--output=file.txt", "-v", "input.txt"};
                                                                                          
                                                                                          // Get the protected flatten method using reflection
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", Options.class, String[].class, boolean.class);
                                                                                          flattenMethod.setAccessible(true);
                                                                                          
                                                                                          // Call method under test
                                                                                          String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                          
                                                                                          // Verify result
                                                                                          assertArrayEquals(new String[]{"--output", "file.txt", "-v", "input.txt"}, result);
                                                                                      }

    @Test
                                                                                      public void testFlatten_EmptyArguments() throws Exception {
                                                                                          Options options = new Options();
                                                                                          PosixParser parser = new PosixParser();
                                                                                          String[] args = {};
                                                                                          
                                                                                          // Use reflection to access protected method
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", Options.class, String[].class, boolean.class);
                                                                                          flattenMethod.setAccessible(true);
                                                                                          String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                          
                                                                                          assertEquals(0, result.length);
                                                                                      }

    @Test
                                                                                      public void testFlatten_NullArguments() throws Exception {
                                                                                          // Setup
                                                                                          PosixParser parser = new PosixParser();
                                                                                          Options options = new Options();
                                                                                          
                                                                                          // Get the protected method via reflection
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", 
                                                                                              Options.class, 
                                                                                              String[].class, 
                                                                                              boolean.class
                                                                                          );
                                                                                          flattenMethod.setAccessible(true);
                                                                                          
                                                                                          // Expected exception
                                                                                          try {
                                                                                              flattenMethod.invoke(parser, options, null, false);
                                                                                              fail("Expected NullPointerException to be thrown");
                                                                                          } catch (InvocationTargetException e) {
                                                                                              assertTrue(e.getCause() instanceof NullPointerException);
                                                                                          }
                                                                                      }

    @Test
                                                                                      public void testFlatten_StopAtNonOptionWithFollowingOptions() throws Exception {
                                                                                          // Create mock Options
                                                                                          Options options = mock(Options.class);
                                                                                          when(options.hasOption("--opt1")).thenReturn(true);
                                                                                          when(options.hasOption("-a")).thenReturn(false);
                                                                                          
                                                                                          // Create parser instance
                                                                                          PosixParser parser = new PosixParser();
                                                                                          
                                                                                          // Get the protected flatten method via reflection
                                                                                          Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                              "flatten", Options.class, String[].class, boolean.class);
                                                                                          flattenMethod.setAccessible(true);
                                                                                          
                                                                                          String[] args = {"nonopt", "--opt1", "-abc"};
                                                                                          // With stopAtNonOption=true, all tokens after first non-option should be treated as arguments
                                                                                          String[] result = (String[]) flattenMethod.invoke(parser, options, args, true);
                                                                                          assertArrayEquals(new String[]{"nonopt", "--opt1", "-abc"}, result);
                                                                                      }

    @Test
                                                                                 public void testFlatten_ShouldDistinguishBetweenLongAndShortOptions() throws Exception {
                                                                                     // Setup
                                                                                     PosixParser parser = new PosixParser();
                                                                                     Options options = mock(Options.class);
                                                                                     when(options.hasOption("--long")).thenReturn(true);
                                                                                     when(options.hasOption("-s")).thenReturn(true);
                                                                                     
                                                                                     // Test both long and short options in same input
                                                                                     String[] args = {"--long", "-s"};
                                                                                     boolean stopAtNonOption = false;
                                                                                     
                                                                                     // Get the protected flatten method via reflection
                                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod("flatten", 
                                                                                         Options.class, String[].class, boolean.class);
                                                                                     flattenMethod.setAccessible(true);
                                                                                     
                                                                                     // Execute
                                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, stopAtNonOption);
                                                                                     
                                                                                     // Verify long option was processed correctly
                                                                                     assertEquals("--long", result[0]);
                                                                                     
                                                                                     // Verify short option was NOT processed as long option
                                                                                     // This assertion would fail with the mutant since it would process "-s" as long option
                                                                                     assertEquals("-s", result[1]);
                                                                                     
                                                                                     // Also verify the number of tokens
                                                                                     assertEquals(2, result.length);
                                                                                 }

    @Test
                                                                            public void testFlatten_NonOptionTokenShouldNotBeProcessedAsLongOption() throws Exception {
                                                                                // Setup
                                                                                PosixParser parser = new PosixParser();
                                                                                Options options = mock(Options.class);
                                                                                when(options.hasOption(anyString())).thenReturn(false);
                                                                                
                                                                                // This token should NOT be processed as a long option
                                                                                String[] arguments = {"testToken"}; 
                                                                                
                                                                                // Get the protected flatten method via reflection
                                                                                Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                                    "flatten", 
                                                                                    Options.class, 
                                                                                    String[].class, 
                                                                                    boolean.class
                                                                                );
                                                                                flattenMethod.setAccessible(true);
                                                                                
                                                                                // Execute
                                                                                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, false);
                                                                                
                                                                                // Verify - the token should be added as-is, not processed as long option
                                                                                assertEquals(1, result.length);
                                                                                assertEquals("testToken", result[0]);
                                                                                
                                                                                // Additional verification that it didn't go through long option processing
                                                                                // If it did, the token would be modified or split on '='
                                                                                assertFalse(result[0].startsWith("--"));
                                                                            }

    @Test
                                                                       public void testFlatten_ShouldDetectMutatedConditionForLongOption() throws Exception {
                                                                           // Setup test data
                                                                           Options options = mock(Options.class);
                                                                           when(options.hasOption("--invalid")).thenReturn(false);
                                                                           String[] arguments = {"--invalid=value"};
                                                                           
                                                                           // Create parser and set up internal state using reflection
                                                                           PosixParser parser = new PosixParser();
                                                                           Method initMethod = PosixParser.class.getDeclaredMethod("init");
                                                                           initMethod.setAccessible(true);
                                                                           initMethod.invoke(parser);
                                                                           
                                                                           // Call protected flatten method using reflection
                                                                           Method flattenMethod = PosixParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                           flattenMethod.setAccessible(true);
                                                                           String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, false);
                                                                           
                                                                           // Verify behavior
                                                                           // Original: Should add both "--invalid" and "value" to tokens
                                                                           // Mutant: Should process "--invalid=value" (won't be added to tokens)
                                                                           assertEquals(2, result.length); // Original behavior expectation
                                                                           assertEquals("--invalid", result[0]);
                                                                           assertEquals("value", result[1]);
                                                                           
                                                                           // Alternative verification if we could access tokens directly:
                                                                           // Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                           // tokensField.setAccessible(true);
                                                                           // List<String> tokens = (List<String>) tokensField.get(parser);
                                                                           // assertEquals(2, tokens.size());
                                                                           // assertEquals("--invalid", tokens.get(0));
                                                                           // assertEquals("value", tokens.get(1));
                                                                       }

    @Test
                                                                  public void testFlatten_UnrecognizedLongOptionWithStopAtNonOptionFalse() throws Exception {
                                                                      // Setup
                                                                      PosixParser parser = new PosixParser();
                                                                      Options options = new Options(); // empty options - no recognized options
                                                                      String[] arguments = {"--unknown=value"};
                                                                      boolean stopAtNonOption = false;
                                                                      
                                                                      // Get the protected flatten method
                                                                      Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                          "flatten", Options.class, String[].class, boolean.class);
                                                                      flattenMethod.setAccessible(true);
                                                                      
                                                                      // Execute
                                                                      String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                      
                                                                      // Verify
                                                                      assertEquals(2, result.length); // --unknown and value should be separate tokens
                                                                      assertEquals("--unknown", result[0]);
                                                                      assertEquals("value", result[1]);
                                                                      
                                                                      // Verify process() was never called by checking tokens were not processed
                                                                      // Since process() is private, we can't verify it directly, but we can verify the output
                                                                      // which should be the unprocessed tokens
                                                                  }

    @Test
                                                             public void testFlatten_WithExistingLongOptionAndStopAtNonOption_ShouldAddToTokens() {
                                                                 // Setup
                                                                 PosixParser parser = new PosixParser();
                                                                 Options options = new Options();
                                                                 options.addOption(OptionBuilder.withLongOpt("foo").create());
                                                                 
                                                                 // Use reflection to set private fields since no constructor
                                                                 try {
                                                                     Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                     optionsField.setAccessible(true);
                                                                     optionsField.set(parser, options);
                                                                     
                                                                     Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                     tokensField.setAccessible(true);
                                                                     tokensField.set(parser, new ArrayList<String>());
                                                                 } catch (Exception e) {
                                                                     fail("Failed to set up test via reflection");
                                                                 }
                                                                 
                                                                 String[] arguments = {"--foo=bar"};
                                                                 boolean stopAtNonOption = true;
                                                                 
                                                                 // Execute using reflection to access protected method
                                                                 String[] result = null;
                                                                 try {
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                     flattenMethod.setAccessible(true);
                                                                     result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                 } catch (Exception e) {
                                                                     fail("Failed to invoke flatten method via reflection");
                                                                 }
                                                                 
                                                                 // Verify
                                                                 assertEquals(2, result.length); // Should contain both --foo and bar
                                                                 assertEquals("--foo", result[0]);
                                                                 assertEquals("bar", result[1]);
                                                                 
                                                                 // Also verify the mutated version would fail this test
                                                                 // Mutated version would process the token instead of adding to tokens,
                                                                 // so result would be empty or different
                                                             }

    @Test
                                                public void testFlatten_UnrecognizedLongOptionWithStopAtNonOption_CallsProcess() throws Exception {
                                                    // Setup
                                                    PosixParser parser = new PosixParser();
                                                    Options options = new Options(); // Empty options - won't recognize any options
                                                    String[] arguments = {"--invalidOption"};
                                                    boolean stopAtNonOption = true;
                                                    
                                                    // Get the protected flatten method
                                                    Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                        "flatten", 
                                                        Options.class, 
                                                        String[].class, 
                                                        boolean.class
                                                    );
                                                    flattenMethod.setAccessible(true);
                                                    
                                                    // Execute flatten
                                                    String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                    
                                                    // Get the private process method to verify it was called
                                                    Method processMethod = PosixParser.class.getDeclaredMethod("process", String.class);
                                                    processMethod.setAccessible(true);
                                                    
                                                    // Verify the token wasn't added to the tokens list
                                                    assertFalse(Arrays.asList(result).contains("--invalidOption"));
                                                    
                                                    // Since we can't directly verify private method calls with Mockito,
                                                    // we rely on the side effect that process() would normally throw an exception
                                                    // for unrecognized options, but since we're not seeing the token in the result,
                                                    // we can infer it was processed
                                                }

    @Test
                                           public void testFlatten_HandlesLongOptionWithEqualsAtStart() throws Exception {
                                               // Setup
                                               PosixParser parser = new PosixParser();
                                               Options options = mock(Options.class);
                                               when(options.hasOption("--")).thenReturn(false);
                                               
                                               // Test case with '=' at start of token
                                               String[] args = {"--=value"};
                                               
                                               // Get the protected flatten method using reflection
                                               Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                   "flatten", 
                                                   Options.class, 
                                                   String[].class, 
                                                   boolean.class
                                               );
                                               flattenMethod.setAccessible(true);
                                               
                                               // Execute
                                               String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                               
                                               // Verify
                                               // Original behavior would include "value" in tokens
                                               // Mutated behavior (pos > 0) would skip it
                                               assertEquals(2, result.length);
                                               assertEquals("--", result[0]);
                                               assertEquals("value", result[1]);
                                           }

    @Test
                                           public void testFlatten_HandlesNormalLongOptionWithValue() throws Exception {
                                               // Setup
                                               PosixParser parser = new PosixParser();
                                               Options options = mock(Options.class);
                                               when(options.hasOption("--foo")).thenReturn(false);
                                               
                                               // Normal case with '=' not at start
                                               String[] args = {"--foo=bar"};
                                               
                                               // Get the protected flatten method via reflection
                                               Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                   "flatten", 
                                                   Options.class, 
                                                   String[].class, 
                                                   boolean.class
                                               );
                                               flattenMethod.setAccessible(true);
                                               
                                               // Execute
                                               String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                               
                                               // Verify - both original and mutated would handle this correctly
                                               assertEquals(2, result.length);
                                               assertEquals("--foo", result[0]);
                                               assertEquals("bar", result[1]);
                                           }

    @Test
                                      public void testFlattenWithMultipleEqualsSigns() throws Exception {
                                          // Setup
                                          PosixParser parser = new PosixParser();
                                          Options options = mock(Options.class);
                                          when(options.hasOption("--foo=bar")).thenReturn(false);
                                          when(options.hasOption("--foo")).thenReturn(true);
                                          
                                          // Input with multiple equals signs
                                          String[] arguments = {"--foo=bar=baz"};
                                          
                                          // Get the protected flatten method using reflection
                                          Method flattenMethod = PosixParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                          flattenMethod.setAccessible(true);
                                          
                                          // Execute
                                          String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, false);
                                          
                                          // Verify
                                          // Original behavior (indexOf): "--foo", "bar=baz"
                                          // Mutant behavior (lastIndexOf): "--foo=bar", "baz"
                                          assertEquals(2, result.length);
                                          assertEquals("--foo", result[0]);  // This will fail with the mutant
                                          assertEquals("bar=baz", result[1]); // This will fail with the mutant
                                      }

    @Test
                             public void testFlatten_ShouldDistinguishLongOptionsFromShortOptions() throws Exception {
                                 // Setup test with one long option and one short option
                                 Options options = new Options();
                                 options.addOption("s", false, "short option");
                                 options.addOption("longOption", false, "long option");
                                 PosixParser parser = new PosixParser();
                                 String[] args = {"--longOption", "-s"};
                                 
                                 // Get the protected flatten method via reflection
                                 Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                     "flatten", 
                                     Options.class, 
                                     String[].class, 
                                     boolean.class
                                 );
                                 flattenMethod.setAccessible(true);
                                 
                                 // Execute
                                 String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                 
                                 // Verify long option is processed correctly (should be first element)
                                 assertEquals("--longOption", result[0]);
                                 // Verify short option is processed correctly (should be second element)
                                 assertEquals("-s", result[1]);
                                 // Verify exactly 2 tokens were produced
                                 assertEquals(2, result.length);
                             }

    @Test
                             public void testFlatten_ShouldHandleLongOptionWithValue() throws Exception {
                                 // Setup test with long option containing value
                                 String[] args = {"--option=value"};
                                 Options options = new Options();
                                 options.addOption("option", true, "test option");
                                 PosixParser parser = new PosixParser();
                                 
                                 // Get the protected flatten method using reflection
                                 Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                     "flatten", 
                                     Options.class, 
                                     String[].class, 
                                     boolean.class
                                 );
                                 flattenMethod.setAccessible(true);
                                 
                                 // Execute
                                 String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                 
                                 // Verify long option name is first element
                                 assertEquals("--option", result[0]);
                                 // Verify value is second element
                                 assertEquals("value", result[1]);
                                 // Verify exactly 2 tokens were produced
                                 assertEquals(2, result.length);
                             }

    @Test
                        public void testFlatten_ProcessTokenWithNonExistingLongOptionAndStopAtNonOption() throws Exception {
                            // Setup
                            PosixParser parser = new PosixParser();
                            Options options = new Options(); // empty options
                            String[] arguments = {"--nonexisting=value"};
                            boolean stopAtNonOption = true;
                            
                            // Get the protected flatten method
                            Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                "flatten", Options.class, String[].class, boolean.class);
                            flattenMethod.setAccessible(true);
                            
                            // Execute
                            String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                            
                            // Verify the result contains our token
                            assertEquals(1, result.length);
                            assertEquals("--nonexisting=value", result[0]);
                            
                            // Verify tokens list is empty (using reflection)
                            Field tokensField = PosixParser.class.getDeclaredField("tokens");
                            tokensField.setAccessible(true);
                            @SuppressWarnings("unchecked")
                            List<String> tokens = (List<String>) tokensField.get(parser);
                            assertEquals(0, tokens.size());
                        }

    @Test
                   public void testFlatten_UnknownLongOptionWithStopAtNonOption_ProcessesOriginalCase() throws Exception {
                       // Setup
                       PosixParser parser = new PosixParser();
                       Options options = new Options(); // empty options
                       String[] args = {"--unknownOption=value"};
                       boolean stopAtNonOption = true;
                       
                       // Use reflection to access protected flatten method
                       Method flattenMethod = PosixParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                       flattenMethod.setAccessible(true);
                       
                       // Execute
                       String[] result = (String[]) flattenMethod.invoke(parser, options, args, stopAtNonOption);
                       
                       // Verify
                       // Check that the original case is preserved in the output
                       assertEquals(1, result.length);
                       assertEquals("--unknownOption=value", result[0]);
                   }

    @Test
              public void testFlatten_DetectEqualSignAtStartOfToken() throws Exception {
                  // Setup
                  PosixParser parser = new PosixParser();
                  Options options = mock(Options.class);
                  when(options.hasOption("--")).thenReturn(false);
                  
                  // Get the protected flatten method via reflection
                  Method flattenMethod = PosixParser.class.getDeclaredMethod(
                      "flatten", Options.class, String[].class, boolean.class
                  );
                  flattenMethod.setAccessible(true);
                  
                  // This token has '=' at position 0 which the mutant would miss
                  String[] arguments = {"--=value"};
                  
                  // Execute
                  String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, false);
                  
                  // Verify - original would split into ["--", "value"], mutant would keep whole token
                  assertEquals(2, result.length);
                  assertEquals("--", result[0]);
                  assertEquals("value", result[1]);
                  
                  // Additional test case where '=' is at position 1 (should work same as original)
                  String[] arguments2 = {"--a=value"};
                  String[] result2 = (String[]) flattenMethod.invoke(parser, options, arguments2, false);
                  assertEquals(2, result2.length);
                  assertEquals("--a", result2[0]);
                  assertEquals("value", result2[1]);
              }

    @Test
         public void testFlatten_NonOptionToken_WhenStopAtNonOptionFalse_ShouldAddToken() throws Exception {
             // Setup
             PosixParser parser = new PosixParser();
             Options options = mock(Options.class);
             String[] arguments = {"testArg"}; // Non-option argument
             boolean stopAtNonOption = false;
             
             // Get the protected flatten method using reflection
             Method flattenMethod = PosixParser.class.getDeclaredMethod(
                 "flatten", 
                 Options.class, 
                 String[].class, 
                 boolean.class
             );
             flattenMethod.setAccessible(true);
             
             // Execute
             String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
             
             // Verify
             assertNotNull(result);
             assertEquals(1, result.length);
             assertEquals("testArg", result[0]); // This would fail if mutant is present (would be null)
             
             // Additional verification that the token was properly added
             assertNotNull(result[0]); // Explicit check for null
         }

    @Test
    public void testFlattenMaintainsTokenOrder() throws Exception {
        // Setup
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption("a", "alpha", false, "Alpha option");
        options.addOption("b", "beta", false, "Beta option");
        
        // Test with multiple arguments where order matters
        String[] arguments = {"--alpha", "value1", "--beta", "value2", "plainArg"};
        String[] expected = {"--alpha", "value1", "--beta", "value2", "plainArg"};
        
        // Get the protected flatten method via reflection
        Method flattenMethod = PosixParser.class.getDeclaredMethod(
            "flatten", 
            Options.class, 
            String[].class, 
            boolean.class
        );
        flattenMethod.setAccessible(true);
        
        // Execute
        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, false);
        
        // Verify
        assertArrayEquals("Token order should be maintained", expected, result);
        
        // Additional verification for the specific mutation
        // The mutation would produce: ["plainArg", "value2", "--beta", "value1", "--alpha"]
        assertNotEquals("Should not have reverse order", 
                       new String[]{"plainArg", "value2", "--beta", "value1", "--alpha"}, 
                       result);
    }


}
