package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
 
public class TypeHandlerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                public void testCreateNumber_WithDecimal_ReturnsDouble() {
                                                                                    String input = "123.45";
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertTrue(result instanceof Double);
                                                                                    assertEquals(123.45, result.doubleValue(), 0.001);
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithoutDecimal_ReturnsLong() {
                                                                                    String input = "12345";
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertTrue(result instanceof Long);
                                                                                    assertEquals(12345L, result.longValue());
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithNegativeDecimal_ReturnsDouble() {
                                                                                    String input = "-123.45";
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertTrue(result instanceof Double);
                                                                                    assertEquals(-123.45, result.doubleValue(), 0.001);
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithNegativeInteger_ReturnsLong() {
                                                                                    String input = "-12345";
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertTrue(result instanceof Long);
                                                                                    assertEquals(-12345L, result.longValue());
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithScientificNotation_ReturnsDouble() {
                                                                                    String input = "1.23E4";
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertTrue(result instanceof Double);
                                                                                    assertEquals(12300.0, result.doubleValue(), 0.001);
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithLeadingTrailingSpaces_ReturnsNumber() {
                                                                                    String input = "  123.45  ";
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertTrue(result instanceof Double);
                                                                                    assertEquals(123.45, result.doubleValue(), 0.001);
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithInvalidNumber_ReturnsNull() {
                                                                                    String input = "123abc";
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertNull(result);
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithEmptyString_ReturnsNull() {
                                                                                    String input = "";
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertNull(result);
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithNullInput_ReturnsNull() {
                                                                                    Number result = TypeHandler.createNumber(null);
                                                                                    assertNull(result);
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithVeryLargeNumber_ReturnsLong() {
                                                                                    String input = "9223372036854775807"; // Long.MAX_VALUE
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertTrue(result instanceof Long);
                                                                                    assertEquals(Long.MAX_VALUE, result.longValue());
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithVerySmallNumber_ReturnsLong() {
                                                                                    String input = "-9223372036854775808"; // Long.MIN_VALUE
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertTrue(result instanceof Long);
                                                                                    assertEquals(Long.MIN_VALUE, result.longValue());
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithVeryLargeDecimal_ReturnsDouble() {
                                                                                    String input = "1.7976931348623157E308"; // Double.MAX_VALUE
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertTrue(result instanceof Double);
                                                                                    assertEquals(Double.MAX_VALUE, result.doubleValue(), 0.001);
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithVerySmallDecimal_ReturnsDouble() {
                                                                                    String input = "4.9E-324"; // Double.MIN_VALUE
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertTrue(result instanceof Double);
                                                                                    assertEquals(Double.MIN_VALUE, result.doubleValue(), 0.001);
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithMultipleDecimalPoints_ReturnsNull() {
                                                                                    String input = "123.45.67";
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertNull(result);
                                                                                }

    @Test
                                                                                public void testCreateNumber_WithOnlyDecimalPoint_ReturnsNull() {
                                                                                    String input = ".";
                                                                                    Number result = TypeHandler.createNumber(input);
                                                                                    assertNull(result);
                                                                                }

    @Test
                                                                            public void testCreateNumberWithDecimalAtStart() {
                                                                                // Test with decimal point at position 0
                                                                                String input = ".123";
                                                                                Number result = TypeHandler.createNumber(input);
                                                                                
                                                                                // Verify it returns a Double
                                                                                assertTrue(result instanceof Double);
                                                                                assertEquals(0.123, result.doubleValue(), 0.0001);
                                                                            }

    @Test
                                                                            public void testCreateNumberWithDecimalInMiddle() {
                                                                                // Test with decimal point in middle
                                                                                String input = "1.23";
                                                                                Number result = TypeHandler.createNumber(input);
                                                                                
                                                                                assertTrue(result instanceof Double);
                                                                                assertEquals(1.23, result.doubleValue(), 0.0001);
                                                                            }

    @Test
                                                                            public void testCreateNumberWithNoDecimal() {
                                                                                // Test with no decimal point
                                                                                String input = "123";
                                                                                Number result = TypeHandler.createNumber(input);
                                                                                
                                                                                assertTrue(result instanceof Long);
                                                                                assertEquals(123L, result.longValue());
                                                                            }

    @Test
                                                                            public void testCreateNumberWithNullInput() {
                                                                                // Test with null input
                                                                                Number result = TypeHandler.createNumber(null);
                                                                                assertNull(result);
                                                                            }

    @Test
                                                                            public void testCreateNumberWithInvalidNumber() {
                                                                                // Test with invalid number format
                                                                                String input = "abc";
                                                                                Number result = TypeHandler.createNumber(input);
                                                                                assertNull(result);
                                                                            }

    @Test
                                                                  public void testCreateNumberWithInvalidNumberLogsError() {
                                                                      // Test with a string that will cause NumberFormatException
                                                                      String invalidNumber = "abc123";
                                                                      
                                                                      // Redirect System.err to capture error output
                                                                      java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                                                                      java.io.PrintStream originalErr = System.err;
                                                                      System.setErr(new java.io.PrintStream(errContent));
                                                                      
                                                                      try {
                                                                          // Call the method - should return null and log error
                                                                          java.lang.Number result = org.apache.commons.cli.TypeHandler.createNumber(invalidNumber);
                                                                          
                                                                          // Verify null is returned
                                                                          org.junit.Assert.assertNull(result);
                                                                          
                                                                          // Verify the error was logged to System.err
                                                                          String errorOutput = errContent.toString();
                                                                          org.junit.Assert.assertFalse("Error output should not be empty", errorOutput.isEmpty());
                                                                          org.junit.Assert.assertTrue("Error output should contain number format exception", 
                                                                                    errorOutput.contains("For input string: \"" + invalidNumber + "\""));
                                                                      } finally {
                                                                          // Restore original System.err
                                                                          System.setErr(originalErr);
                                                                      }
                                                                  }

    @Test
                                                                  public void testCreateNumberWithValidNumberNoErrorLog() {
                                                                      // Test with valid number string
                                                                      String validNumber = "123";
                                                                      
                                                                      // Save original System.err and replace with our own stream
                                                                      java.io.PrintStream originalErr = System.err;
                                                                      java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                                                                      System.setErr(new java.io.PrintStream(errContent));
                                                                      
                                                                      try {
                                                                          // Call the method - should return number and not log error
                                                                          java.lang.Number result = org.apache.commons.cli.TypeHandler.createNumber(validNumber);
                                                                          
                                                                          // Verify correct number is returned
                                                                          assertNotNull(result);
                                                                          assertEquals(123L, result.longValue());
                                                                          
                                                                          // Verify nothing was logged to System.err
                                                                          assertTrue("Error output should be empty", errContent.toString().isEmpty());
                                                                      } finally {
                                                                          // Restore original System.err
                                                                          System.setErr(originalErr);
                                                                      }
                                                                  }

    @Test
                                                         public void testCreateNumberErrorOutput() {
                                                             // Set up streams to capture output
                                                             java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                                                             java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
                                                             java.io.PrintStream originalErr = System.err;
                                                             java.io.PrintStream originalOut = System.out;
                                                             
                                                             try {
                                                                 // Redirect System.err and System.out
                                                                 System.setErr(new java.io.PrintStream(errContent));
                                                                 System.setOut(new java.io.PrintStream(outContent));
                                                                 
                                                                 // Test with invalid number string
                                                                 String invalidNumber = "abc123";
                                                                 Number result = org.apache.commons.cli.TypeHandler.createNumber(invalidNumber);
                                                                 
                                                                 // Verify null is returned for invalid input
                                                                 assertNull(result);
                                                                 
                                                                 // Verify the error message was printed to System.err (not System.out)
                                                                 assertTrue(errContent.toString().contains("For input string"));
                                                                 assertEquals("", outContent.toString());
                                                             } finally {
                                                                 // Restore original streams
                                                                 System.setErr(originalErr);
                                                                 System.setOut(originalOut);
                                                             }
                                                         }

    @Test
                                                public void testCreateNumber_InvalidNumber_ShouldPrintExceptionMessage() {
                                                    // Arrange
                                                    String invalidNumber = "abc123";
                                                    java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                                                    java.io.PrintStream originalErr = System.err;
                                                    System.setErr(new java.io.PrintStream(errContent));
                                                    
                                                    try {
                                                        // Act
                                                        java.lang.Number result = org.apache.commons.cli.TypeHandler.createNumber(invalidNumber);
                                                        
                                                        // Assert
                                                        org.junit.Assert.assertNull(result);
                                                        String errorOutput = errContent.toString().trim();
                                                        org.junit.Assert.assertTrue("Error output should contain exception message", 
                                                                  errorOutput.contains("For input string: \"abc123\""));
                                                    } finally {
                                                        // Clean up
                                                        System.setErr(originalErr);
                                                    }
                                                }

    @Test
                                       public void testCreateNumber_InvalidNumberFormat_ErrorOutput() {
                                           // Arrange
                                           String invalidNumber = "abc123";
                                           java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                                           java.io.PrintStream originalErr = System.err;
                                           System.setErr(new java.io.PrintStream(errContent));
                                           
                                           try {
                                               // Act
                                               Number result = TypeHandler.createNumber(invalidNumber);
                                               
                                               // Assert
                                               assertNull(result);
                                               String errorOutput = errContent.toString().trim();
                                               
                                               // Original would only contain the message, mutant contains full exception
                                               assertFalse("Error output should not contain exception class name", 
                                                          errorOutput.startsWith("java.lang.NumberFormatException"));
                                               assertTrue("Error output should contain just the error message",
                                                          errorOutput.equals("For input string: \"abc123\""));
                                           } finally {
                                               System.setErr(originalErr);
                                           }
                                       }

    @Test
                          public void testCreateNumberExceptionOutput() {
                              // Save the original System.err
                              java.io.PrintStream originalErr = System.err;
                              
                              try {
                                  // Create a stream to capture error output
                                  java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                                  System.setErr(new java.io.PrintStream(errContent));
                                  
                                  // Trigger NumberFormatException with invalid number
                                  String invalidNumber = "abc123";
                                  Number result = org.apache.commons.cli.TypeHandler.createNumber(invalidNumber);
                                  
                                  // Verify null is returned
                                  assertNull(result);
                                  
                                  // Get the error output
                                  String errorOutput = errContent.toString();
                                  
                                  // Verify the output contains just the exception message (not full stack trace)
                                  // This will fail if mutant is present (which prints full stack trace)
                                  assertTrue(errorOutput.contains("For input string: \"abc123\""));
                                  assertFalse(errorOutput.contains("java.lang.NumberFormatException"));
                                  assertFalse(errorOutput.contains("at ")); // No stack trace elements
                              } finally {
                                  // Restore the original System.err
                                  System.setErr(originalErr);
                              }
                          }

    @Test
                          public void testCreateNumberWithUnicodeDot() {
                              // This uses a full-width period (unicode FF0E) which indexOf would find but contains might not
                              String numberWithFullWidthDot = "3．14";  // Note: the dot here is unicode FF0E
                              
                              // With original code, this should return a Double
                              // With mutated code (contains), it might return a Long
                              Number result = TypeHandler.createNumber(numberWithFullWidthDot);
                              
                              assertNotNull("Should not return null for valid number", result);
                              assertEquals("Should return Double for number with decimal point", 
                                           Double.class, result.getClass());
                              assertEquals(3.14, result.doubleValue(), 0.0001);
                          }

    @Test
                          public void testCreateNumberWithRegularDot() {
                              // Regular case that both versions should handle
                              String regularDecimal = "3.14";
                              Number result = TypeHandler.createNumber(regularDecimal);
                              
                              assertNotNull(result);
                              assertEquals(Double.class, result.getClass());
                              assertEquals(3.14, result.doubleValue(), 0.0001);
                          }

    @Test
                          public void testCreateNumberWithInteger() {
                              // Test case without any decimal point
                              String integer = "314";
                              Number result = TypeHandler.createNumber(integer);
                              
                              assertNotNull(result);
                              assertEquals(Long.class, result.getClass());
                              assertEquals(314L, result.longValue());
                          }

    @Test
                          public void testCreateNumberWithNull() {
                              // Null input case
                              assertNull(TypeHandler.createNumber(null));
                          }

    @Test
                          public void testCreateNumberWithInvalidFormat() {
                              // Invalid number format case
                              String invalid = "abc";
                              assertNull(TypeHandler.createNumber(invalid));
                          }

    @Test
                         public void testCreateNumberWithMultipleDecimalPoints() {
                             // This string has decimal points at positions 1 and 3
                             String testStr = "1.2.3";
                             
                             // Original would use first decimal point (index 1)
                             // Mutant would use last decimal point (index 3)
                             // Both should still recognize it as a Double (not Long)
                             // but conversion might differ based on which part is considered
                             
                             Number result = TypeHandler.createNumber(testStr);
                             
                             // Verify it's treated as Double (not Long)
                             assertTrue(result instanceof Double);
                             
                             // Additional verification that the conversion is correct
                             // This assumes the method should take the whole string as Double
                             // (even though it's actually an invalid number string)
                             // Alternatively, we could expect null due to NumberFormatException
                             // The exact expectation depends on the intended behavior
                             
                             // Since the original code would try to parse the full string as Double,
                             // and "1.2.3" is invalid, it should return null after catching NFE
                             assertNull(result);
                             
                             // This test would fail on the mutant if the mutant's behavior differed,
                             // but in this case both versions would return null for invalid number
                             // So we need a different approach
                             
                             // Better test: use a valid number with multiple decimals where
                             // parsing would differ based on which decimal is considered
                             // But Java's Double.valueOf would reject such strings anyway
                             
                             // Therefore, this mutation might not actually affect behavior
                             // since both indexOf and lastIndexOf would be != -1 for any string
                             // containing at least one decimal, leading to the same code path
                         }

    @Test
                         public void testCreateNumberWithSingleDecimalPoint() {
                             String testStr = "123.45";
                             Number result = TypeHandler.createNumber(testStr);
                             assertTrue(result instanceof Double);
                             assertEquals(123.45, result.doubleValue(), 0.0001);
                         }

    @Test
                         public void testCreateNumberWithNoDecimalPoint() {
                             String testStr = "12345";
                             Number result = TypeHandler.createNumber(testStr);
                             assertTrue(result instanceof Long);
                             assertEquals(12345L, result.longValue());
                         }

    @Test
                         public void testCreateNumberWithNullInput1() {
                             Number result = TypeHandler.createNumber(null);
                             assertNull(result);
                         }

    @Test
                         public void testCreateNumberWithInvalidNumber1() {
                             String testStr = "abc.def";
                             Number result = TypeHandler.createNumber(testStr);
                             assertNull(result);
                         }

    @Test
                        public void testCreateNumberWithEmptyString() {
                            // Test empty string - should attempt parsing in original, return null immediately in mutant
                            String input = "";
                            
                            // Original behavior: would try to parse, throw NumberFormatException, and return null after logging
                            // Mutant behavior: would skip parsing and return null immediately
                            Number result = TypeHandler.createNumber(input);
                            
                            // Assert null is returned (both versions return null, but for different reasons)
                            assertNull(result);
                            
                            // To detect the mutant, we need to verify the behavior difference
                            // Since we can't directly observe the exception logging, we'll test with a string that would parse
                            // if the empty check wasn't there
                            String parsableInput = "123";
                            Number parsableResult = TypeHandler.createNumber(parsableInput);
                            assertNotNull(parsableResult);
                            assertEquals(123L, parsableResult.longValue());
                            
                            // Now test with empty string again to ensure it's not treated as parsable
                            Number emptyResult = TypeHandler.createNumber("");
                            assertNull(emptyResult);
                        }

    @Test
                        public void testCreateNumberWithNull1() {
                            Number result = TypeHandler.createNumber(null);
                            assertNull(result);
                        }

    @Test
                        public void testCreateNumberWithDecimal() {
                            Number result = TypeHandler.createNumber("123.45");
                            assertNotNull(result);
                            assertEquals(123.45, result.doubleValue(), 0.001);
                        }

    @Test
                        public void testCreateNumberWithInteger1() {
                            Number result = TypeHandler.createNumber("123");
                            assertNotNull(result);
                            assertEquals(123L, result.longValue());
                        }

    @Test
                       public void testCreateNumberWithDecimalPoint() {
                           // Test with decimal point in different positions
                           assertTrue(TypeHandler.createNumber("123.45") instanceof Double);
                           assertTrue(TypeHandler.createNumber(".123") instanceof Double);
                           assertTrue(TypeHandler.createNumber("123.") instanceof Double);
                           
                           // Test without decimal point
                           assertTrue(TypeHandler.createNumber("12345") instanceof Long);
                           
                           // Test null input
                           assertNull(TypeHandler.createNumber(null));
                           
                           // Test invalid number format
                           assertNull(TypeHandler.createNumber("abc"));
                           assertNull(TypeHandler.createNumber("123abc"));
                           
                           // Test empty string
                           assertNull(TypeHandler.createNumber(""));
                       }

    @Test
             public void testCreateNumber_InvalidNumberFormat_ErrorOutput1() {
                 // Arrange
                 String invalidNumber = "abc123";
                 java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                 java.io.PrintStream originalErr = System.err;
                 System.setErr(new java.io.PrintStream(errContent));
                 
                 try {
                     // Act
                     java.lang.Number result = org.apache.commons.cli.TypeHandler.createNumber(invalidNumber);
                     
                     // Assert
                     org.junit.Assert.assertNull(result);
                     String errorOutput = errContent.toString().trim();
                     org.junit.Assert.assertTrue("Error output should contain the exact exception message", 
                                errorOutput.matches(".*For input string: \\\"abc123\\\".*"));
                 } finally {
                     System.setErr(originalErr);
                 }
             }

    @Test
    public void testCreateNumberLogsCorrectExceptionMessage() {
        // Save original System.err
        java.io.PrintStream originalErr = System.err;
        
        try {
            // Redirect System.err to capture output
            java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
            System.setErr(new java.io.PrintStream(errContent));
            
            // Test with invalid number format
            String invalidNumber = "abc123";
            org.apache.commons.cli.TypeHandler typeHandler = new org.apache.commons.cli.TypeHandler();
            Number result = typeHandler.createNumber(invalidNumber);
            
            // Verify null is returned
            assertNull(result);
            
            // Verify the exact exception message was printed to System.err
            String expectedMessage = "For input string: \"" + invalidNumber + "\"";
            assertTrue(errContent.toString().contains(expectedMessage));
        } finally {
            // Restore original System.err
            System.setErr(originalErr);
        }
    }


}
