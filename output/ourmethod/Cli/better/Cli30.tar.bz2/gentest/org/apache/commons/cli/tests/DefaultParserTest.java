package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
 
public class DefaultParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                           public void testHandleProperties_OptionWithArg() throws Exception {
                                                                                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                                                                                               DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Use reflection to access private/protected members
                                                                                                                                                                                                                                                                               Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                               cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                               CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                               cmdField.set(parser, mockCmd);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                               optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                               Options mockOptions = mock(Options.class);
                                                                                                                                                                                                                                                                               optionsField.set(parser, mockOptions);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Properties props = new Properties();
                                                                                                                                                                                                                                                                               props.setProperty("argOption", "argValue");
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Option mockOption = mock(Option.class);
                                                                                                                                                                                                                                                                               when(mockOption.hasArg()).thenReturn(true);
                                                                                                                                                                                                                                                                               when(mockOption.getValues()).thenReturn(null);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               when(mockOptions.getOption("argOption")).thenReturn(mockOption);
                                                                                                                                                                                                                                                                               when(mockOptions.getOptionGroup(mockOption)).thenReturn(null);
                                                                                                                                                                                                                                                                               when(mockCmd.hasOption("argOption")).thenReturn(false);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Get handleProperties method via reflection
                                                                                                                                                                                                                                                                               Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                                                                                                                                                                               handlePropertiesMethod.setAccessible(true);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Execute
                                                                                                                                                                                                                                                                               handlePropertiesMethod.invoke(parser, props);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Verify value was added and option processed
                                                                                                                                                                                                                                                                               Method addValueForProcessingMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                                                                                                                                                                                               addValueForProcessingMethod.setAccessible(true);
                                                                                                                                                                                                                                                                               addValueForProcessingMethod.invoke(mockOption, "argValue");
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Method handleOptionMethod = DefaultParser.class.getDeclaredMethod("handleOption", Option.class);
                                                                                                                                                                                                                                                                               handleOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                                               handleOptionMethod.invoke(parser, mockOption);
                                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                                           public void testHandleProperties_MultipleProperties() throws Exception {
                                                                                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                                                                                               DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Use reflection to set protected fields
                                                                                                                                                                                                                                                                               Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                               cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                               CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                               cmdField.set(parser, mockCmd);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                               optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                               Options mockOptions = mock(Options.class);
                                                                                                                                                                                                                                                                               optionsField.set(parser, mockOptions);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Properties props = new Properties();
                                                                                                                                                                                                                                                                               props.setProperty("option1", "value1");
                                                                                                                                                                                                                                                                               props.setProperty("option2", "true");
                                                                                                                                                                                                                                                                               props.setProperty("option3", "no"); // Should be skipped
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Option mockOption1 = mock(Option.class);
                                                                                                                                                                                                                                                                               when(mockOption1.hasArg()).thenReturn(true);
                                                                                                                                                                                                                                                                               when(mockOption1.getValues()).thenReturn(null);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Option mockOption2 = mock(Option.class);
                                                                                                                                                                                                                                                                               when(mockOption2.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               when(mockOptions.getOption("option1")).thenReturn(mockOption1);
                                                                                                                                                                                                                                                                               when(mockOptions.getOption("option2")).thenReturn(mockOption2);
                                                                                                                                                                                                                                                                               when(mockOptions.getOption("option3")).thenReturn(mock(Option.class));
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               when(mockOptions.getOptionGroup(any())).thenReturn(null);
                                                                                                                                                                                                                                                                               when(mockCmd.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Get handleProperties method via reflection
                                                                                                                                                                                                                                                                               Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                                                                                                                                                                               handlePropertiesMethod.setAccessible(true);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Execute
                                                                                                                                                                                                                                                                               handlePropertiesMethod.invoke(parser, props);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Get handleOption method via reflection for verification
                                                                                                                                                                                                                                                                               Method handleOptionMethod = DefaultParser.class.getDeclaredMethod("handleOption", Option.class);
                                                                                                                                                                                                                                                                               handleOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Verify only option1 and option2 were processed
                                                                                                                                                                                                                                                                               verify(mockOptions, times(1)).getOption("option1");
                                                                                                                                                                                                                                                                               verify(mockOptions, times(1)).getOption("option2");
                                                                                                                                                                                                                                                                               verify(mockOptions, never()).getOption("option3");
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Verify handleOption was called with expected options
                                                                                                                                                                                                                                                                               // Since we can't directly verify private method calls, we verify the side effects
                                                                                                                                                                                                                                                                               // through the mock interactions instead
                                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                                           public void testIsArgument_WhenTokenIsNotOptionAndNotNegativeNumber() throws Exception {
                                                                                                                                                                                                                                                                               // Create a new DefaultParser instance
                                                                                                                                                                                                                                                                               DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Use reflection to access private methods
                                                                                                                                                                                                                                                                               Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                                               isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                                               isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                               isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Verify the methods return false for our test case
                                                                                                                                                                                                                                                                               assertFalse((boolean) isOptionMethod.invoke(parser, "plaintext"));
                                                                                                                                                                                                                                                                               assertFalse((boolean) isNegativeNumberMethod.invoke(parser, "plaintext"));
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Test that isArgument returns true when both isOption and isNegativeNumber return false
                                                                                                                                                                                                                                                                               assertTrue((boolean) isArgumentMethod.invoke(parser, "plaintext"));
                                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                                           public void testIsNegativeNumber_WithValidNegativeNumber() throws Exception {
                                                                                                                                                                                                                                                                               DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Get the private method using reflection
                                                                                                                                                                                                                                                                               Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                               isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Test various negative numbers
                                                                                                                                                                                                                                                                               assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-1"));
                                                                                                                                                                                                                                                                               assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-1.0"));
                                                                                                                                                                                                                                                                               assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-0.5"));
                                                                                                                                                                                                                                                                               assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-1234567890.987654321"));
                                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                                       public void testIsNegativeNumber_WithZero() throws Exception {
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get the private method using reflection
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test with various zero values
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "0"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "0.0"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "-0"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "-0.0"));
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsNegativeNumber_WithScientificNotation() throws Exception {
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1e10"));
                                                                                                                                                                                                                                                                           assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-1e10"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1.5e-10"));
                                                                                                                                                                                                                                                                           assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-1.5e-10"));
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsNegativeNumber_WithInvalidNumbers() throws Exception {
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, ""));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, " "));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "abc"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1.2.3"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "--1"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1-"));
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsNegativeNumber_WithNumberFormatEdgeCases() throws Exception {
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "."));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "-."));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "e"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "-e"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "Infinity"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "-Infinity"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "NaN"));
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsNegativeNumber_WithNullInput() throws Exception {
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                                                               isNegativeNumberMethod.invoke(parser, (String)null);
                                                                                                                                                                                                                                                                               fail("Expected NullPointerException to be thrown");
                                                                                                                                                                                                                                                                           } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                                               assertTrue(e.getCause() instanceof NullPointerException);
                                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsNegativeNumber_WithNumberWithSpaces() throws Exception {
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get the private method using reflection
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test various cases with spaces
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, " 1 "));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "- 1"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1 "));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, " 1"));
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsNegativeNumber_WithLocaleSpecificNumbers() throws Exception {
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get the private isNegativeNumber method using reflection
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test with comma as decimal separator
                                                                                                                                                                                                                                                                           boolean result1 = (boolean) isNegativeNumberMethod.invoke(parser, "1,5");
                                                                                                                                                                                                                                                                           assertFalse(result1);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test with apostrophe as thousand separator
                                                                                                                                                                                                                                                                           boolean result2 = (boolean) isNegativeNumberMethod.invoke(parser, "1'000");
                                                                                                                                                                                                                                                                           assertFalse(result2);
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsNegativeNumber_WithVeryLargeNumbers() throws Exception {
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get the private method using reflection
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test with positive large numbers (should return false)
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "" + Double.MAX_VALUE));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "" + Double.MIN_VALUE));
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test with negative large numbers (should return true)
                                                                                                                                                                                                                                                                           assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-" + Double.MAX_VALUE));
                                                                                                                                                                                                                                                                           assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-" + Double.MIN_VALUE));
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testHandleProperties_OptionAlreadyInCommandLine() throws Exception {
                                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Use reflection to access protected fields
                                                                                                                                                                                                                                                                           Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                           cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                           CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                           cmdField.set(parser, mockCmd);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                           optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                           Options mockOptions = mock(Options.class);
                                                                                                                                                                                                                                                                           optionsField.set(parser, mockOptions);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           Properties props = new Properties();
                                                                                                                                                                                                                                                                           props.setProperty("existingOption", "value");
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           Option mockOption = mock(Option.class);
                                                                                                                                                                                                                                                                           when(mockOptions.getOption("existingOption")).thenReturn(mockOption);
                                                                                                                                                                                                                                                                           when(mockCmd.hasOption("existingOption")).thenReturn(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Use reflection to access private method
                                                                                                                                                                                                                                                                           Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                                                                                                                                                                           handlePropertiesMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                                           handlePropertiesMethod.invoke(parser, props);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Verify option wasn't processed by checking that hasOption was called
                                                                                                                                                                                                                                                                           verify(mockCmd).hasOption("existingOption");
                                                                                                                                                                                                                                                                           // Since we can't verify the private addOption, we verify that getOption was called
                                                                                                                                                                                                                                                                           verify(mockOptions).getOption("existingOption");
                                                                                                                                                                                                                                                                           // And that no other interactions happened with the mockCmd
                                                                                                                                                                                                                                                                           verifyNoMoreInteractions(mockCmd);
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testHandleProperties_OptionInGroupAlreadySelected() throws Exception {
                                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Use reflection to set protected fields
                                                                                                                                                                                                                                                                           Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                           cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                           CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                           cmdField.set(parser, mockCmd);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                           optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                           Options mockOptions = mock(Options.class);
                                                                                                                                                                                                                                                                           optionsField.set(parser, mockOptions);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           Properties props = new Properties();
                                                                                                                                                                                                                                                                           props.setProperty("groupOption", "value");
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           Option mockOption = mock(Option.class);
                                                                                                                                                                                                                                                                           OptionGroup mockGroup = mock(OptionGroup.class);
                                                                                                                                                                                                                                                                           when(mockGroup.getSelected()).thenReturn("selectedOptionValue");
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           when(mockOptions.getOption("groupOption")).thenReturn(mockOption);
                                                                                                                                                                                                                                                                           when(mockOptions.getOptionGroup(mockOption)).thenReturn(mockGroup);
                                                                                                                                                                                                                                                                           when(mockCmd.hasOption("groupOption")).thenReturn(false);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get private handleProperties method via reflection
                                                                                                                                                                                                                                                                           Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                                                                                                                                                                           handlePropertiesMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                                           handlePropertiesMethod.invoke(parser, props);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Verify option wasn't processed
                                                                                                                                                                                                                                                                           // Since addOption is not public, we need to verify through other means
                                                                                                                                                                                                                                                                           // We can verify that hasOption was called but no other interactions occurred
                                                                                                                                                                                                                                                                           verify(mockCmd).hasOption("groupOption");
                                                                                                                                                                                                                                                                           verifyNoMoreInteractions(mockCmd);
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testHandleProperties_OptionWithoutArgWithInvalidValue() throws Exception {
                                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Use reflection to set protected fields
                                                                                                                                                                                                                                                                           Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                           cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                           CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                           cmdField.set(parser, mockCmd);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                           optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                           Options mockOptions = mock(Options.class);
                                                                                                                                                                                                                                                                           optionsField.set(parser, mockOptions);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           Properties props = new Properties();
                                                                                                                                                                                                                                                                           props.setProperty("flagOption", "no");
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           Option mockOption = mock(Option.class);
                                                                                                                                                                                                                                                                           when(mockOption.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           when(mockOptions.getOption("flagOption")).thenReturn(mockOption);
                                                                                                                                                                                                                                                                           when(mockOptions.getOptionGroup(mockOption)).thenReturn(null);
                                                                                                                                                                                                                                                                           when(mockCmd.hasOption("flagOption")).thenReturn(false);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get handleProperties method via reflection
                                                                                                                                                                                                                                                                           Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                                                                                                                                                                           handlePropertiesMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                                           handlePropertiesMethod.invoke(parser, props);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Verify option wasn't processed by checking that hasOption still returns false
                                                                                                                                                                                                                                                                           verify(mockCmd, never()).hasOption("flagOption");
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsArgument_WhenTokenIsOptionButNegativeNumber() throws Exception {
                                                                                                                                                                                                                                                                           // Create parser instance
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get private methods via reflection
                                                                                                                                                                                                                                                                           Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                                           isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                                           isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Create spy to mock the private method calls
                                                                                                                                                                                                                                                                           DefaultParser spyParser = spy(parser);
                                                                                                                                                                                                                                                                           when(isOptionMethod.invoke(spyParser, "-123")).thenReturn(true);
                                                                                                                                                                                                                                                                           when(isNegativeNumberMethod.invoke(spyParser, "-123")).thenReturn(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test the isArgument method
                                                                                                                                                                                                                                                                           boolean result = (boolean) isArgumentMethod.invoke(spyParser, "-123");
                                                                                                                                                                                                                                                                           assertTrue(result);
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsArgument_WhenTokenIsNull() throws Exception {
                                                                                                                                                                                                                                                                           // Create a real parser instance
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Use reflection to access the private isArgument method
                                                                                                                                                                                                                                                                           Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                                           isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Set up expected exception
                                                                                                                                                                                                                                                                           ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                                           exception.expect(NullPointerException.class);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Invoke the method with null
                                                                                                                                                                                                                                                                           isArgumentMethod.invoke(parser, (String) null);
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsArgument_WhenTokenIsSingleDash() throws Exception {
                                                                                                                                                                                                                                                                           // Create parser instance
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get private methods via reflection
                                                                                                                                                                                                                                                                           Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                                           isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                                           isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Create spy and mock private method behavior
                                                                                                                                                                                                                                                                           DefaultParser spyParser = spy(parser);
                                                                                                                                                                                                                                                                           when(isOptionMethod.invoke(spyParser, "-")).thenReturn(true);
                                                                                                                                                                                                                                                                           when(isNegativeNumberMethod.invoke(spyParser, "-")).thenReturn(false);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test the isArgument method
                                                                                                                                                                                                                                                                           assertFalse((boolean) isArgumentMethod.invoke(spyParser, "-"));
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsArgument_WhenTokenIsNegativeZero() throws Exception {
                                                                                                                                                                                                                                                                           // Create parser instance
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get private methods via reflection
                                                                                                                                                                                                                                                                           Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                                           isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                                           isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Create spy to mock the private methods
                                                                                                                                                                                                                                                                           DefaultParser spyParser = spy(parser);
                                                                                                                                                                                                                                                                           when(isOptionMethod.invoke(spyParser, "-0")).thenReturn(true);
                                                                                                                                                                                                                                                                           when(isNegativeNumberMethod.invoke(spyParser, "-0")).thenReturn(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test the isArgument method
                                                                                                                                                                                                                                                                           boolean result = (boolean) isArgumentMethod.invoke(spyParser, "-0");
                                                                                                                                                                                                                                                                           assertTrue(result);
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testIsNegativeNumber_WithValidPositiveNumber() throws Exception {
                                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get the private method using reflection
                                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Test with various positive numbers
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1.0"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "0.5"));
                                                                                                                                                                                                                                                                           assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1234567890.987654321"));
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                   public void testHandleProperties_UnrecognizedOption() throws Exception {
                                                                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                                                                       DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Mock objects
                                                                                                                                                                                                                                                                       CommandLine mockCommandLine = mock(CommandLine.class);
                                                                                                                                                                                                                                                                       Options mockOptions = mock(Options.class);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Use reflection to set protected fields
                                                                                                                                                                                                                                                                       Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                       cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                       cmdField.set(parser, mockCommandLine);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                       optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                       optionsField.set(parser, mockOptions);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       Properties props = new Properties();
                                                                                                                                                                                                                                                                       props.setProperty("unknownOption", "value");
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       when(mockOptions.getOption("unknownOption")).thenReturn(null);
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Setup expected exception
                                                                                                                                                                                                                                                                       ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                                       exception.expect(UnrecognizedOptionException.class);
                                                                                                                                                                                                                                                                       exception.expectMessage("Default option wasn't defined");
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       // Use reflection to access private method
                                                                                                                                                                                                                                                                       Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                                                                                                                                                                       handlePropertiesMethod.setAccessible(true);
                                                                                                                                                                                                                                                                       handlePropertiesMethod.invoke(parser, props);
                                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                                                               public void testHandleProperties_OptionWithoutArgWithValidValue() throws Exception {
                                                                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                                                                   DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Use reflection to set protected fields
                                                                                                                                                                                                                                                                   Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                   cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                   CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                   cmdField.set(parser, mockCmd);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                   optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                   Options mockOptions = mock(Options.class);
                                                                                                                                                                                                                                                                   optionsField.set(parser, mockOptions);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   Properties props = new Properties();
                                                                                                                                                                                                                                                                   props.setProperty("flagOption", "true");
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   Option mockOption = mock(Option.class);
                                                                                                                                                                                                                                                                   when(mockOption.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   when(mockOptions.getOption("flagOption")).thenReturn(mockOption);
                                                                                                                                                                                                                                                                   when(mockOptions.getOptionGroup(mockOption)).thenReturn(null);
                                                                                                                                                                                                                                                                   when(mockCmd.hasOption("flagOption")).thenReturn(false);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Get handleProperties method via reflection
                                                                                                                                                                                                                                                                   Method handleProperties = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                                                                                                                                                                   handleProperties.setAccessible(true);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Execute
                                                                                                                                                                                                                                                                   handleProperties.invoke(parser, props);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Verify option was processed by checking if hasOption now returns true
                                                                                                                                                                                                                                                                   // Instead of verifying addOption, we verify that hasOption was called with the expected value
                                                                                                                                                                                                                                                                   verify(mockCmd).hasOption("flagOption");
                                                                                                                                                                                                                                                                   // Also verify that the option was looked up in the options
                                                                                                                                                                                                                                                                   verify(mockOptions).getOption("flagOption");
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                           public void testIsArgument_WhenTokenIsOptionAndNotNegativeNumber() throws Exception {
                                                                                                                                                                                                                                                               // Create a new DefaultParser instance
                                                                                                                                                                                                                                                               DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Use reflection to access private methods
                                                                                                                                                                                                                                                               Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                               isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                               Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                               isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                               Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                               isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Create a spy to partially mock the parser
                                                                                                                                                                                                                                                               DefaultParser spyParser = spy(parser);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Mock the behavior using reflection
                                                                                                                                                                                                                                                               when(isOptionMethod.invoke(spyParser, "-option")).thenReturn(true);
                                                                                                                                                                                                                                                               when(isNegativeNumberMethod.invoke(spyParser, "-option")).thenReturn(false);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Test the isArgument method
                                                                                                                                                                                                                                                               boolean result = (boolean) isArgumentMethod.invoke(spyParser, "-option");
                                                                                                                                                                                                                                                               assertFalse(result);
                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                       public void testIsArgument_WhenTokenIsEmptyString() throws Exception {
                                                                                                                                                                                                                                                           // Create a new DefaultParser instance
                                                                                                                                                                                                                                                           DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Get the private methods we need to test
                                                                                                                                                                                                                                                           Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                           isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                           isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Create a spy of the parser
                                                                                                                                                                                                                                                           DefaultParser spyParser = spy(parser);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Mock the behavior of private methods using reflection
                                                                                                                                                                                                                                                           when(isOptionMethod.invoke(spyParser, "")).thenReturn(false);
                                                                                                                                                                                                                                                           when(isNegativeNumberMethod.invoke(spyParser, "")).thenReturn(false);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Invoke the private isArgument method
                                                                                                                                                                                                                                                           boolean result = (boolean) isArgumentMethod.invoke(spyParser, "");
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           assertTrue(result);
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                   public void testIsArgument_WhenTokenIsNegativeDecimal() throws Exception {
                                                                                                                                                                                                                                                       // Create parser instance
                                                                                                                                                                                                                                                       DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Get private methods via reflection
                                                                                                                                                                                                                                                       Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                       isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                       Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                       isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                       Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                       isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Create spy to mock the behavior
                                                                                                                                                                                                                                                       DefaultParser spyParser = spy(parser);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Mock the behavior using the actual method calls
                                                                                                                                                                                                                                                       when(isOptionMethod.invoke(spyParser, "-123.45")).thenReturn(false);
                                                                                                                                                                                                                                                       when(isNegativeNumberMethod.invoke(spyParser, "-123.45")).thenReturn(true);
                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                       // Test the isArgument method
                                                                                                                                                                                                                                                       boolean result = (boolean) isArgumentMethod.invoke(spyParser, "-123.45");
                                                                                                                                                                                                                                                       assertTrue(result);
                                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                               public void testHandleProperties_NullProperties() throws Exception {
                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                   org.apache.commons.cli.DefaultParser parser = new org.apache.commons.cli.DefaultParser();
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Create mocks
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Use reflection to access private method
                                                                                                                                                                                                   java.lang.reflect.Method handlePropertiesMethod = org.apache.commons.cli.DefaultParser.class.getDeclaredMethod("handleProperties", java.util.Properties.class);
                                                                                                                                                                                                   handlePropertiesMethod.setAccessible(true);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Use reflection to set protected fields
                                                                                                                                                                                                   java.lang.reflect.Field cmdField = org.apache.commons.cli.DefaultParser.class.getDeclaredField("cmd");
                                                                                                                                                                                                   cmdField.setAccessible(true);
                                                                                                                                                                                                   
                                                                                                                                                                                                   java.lang.reflect.Field optionsField = org.apache.commons.cli.DefaultParser.class.getDeclaredField("options");
                                                                                                                                                                                                   optionsField.setAccessible(true);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Execute
                                                                                                                                                                                                   handlePropertiesMethod.invoke(parser, (java.util.Properties)null);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify no interactions with mocks
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                      public void testIsArgument_NegativeNumber_ReturnsTrue() throws Exception {
                                                                                                                                                                                          DefaultParser parser = new DefaultParser();
                                                                                                                                                                                          
                                                                                                                                                                                          // Get private methods via reflection
                                                                                                                                                                                          Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                          isOptionMethod.setAccessible(true);
                                                                                                                                                                                          Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                          isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                          Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                          isArgumentMethod.setAccessible(true);
                                                                                                                                                                                          
                                                                                                                                                                                          // Create a spy
                                                                                                                                                                                          DefaultParser spyParser = spy(parser);
                                                                                                                                                                                          
                                                                                                                                                                                          // Mock the private method calls using reflection
                                                                                                                                                                                          when(isOptionMethod.invoke(spyParser, "-123")).thenReturn(true);
                                                                                                                                                                                          when(isNegativeNumberMethod.invoke(spyParser, "-123")).thenReturn(true);
                                                                                                                                                                                          
                                                                                                                                                                                          // Invoke the method under test and assert
                                                                                                                                                                                          boolean result = (boolean) isArgumentMethod.invoke(spyParser, "-123");
                                                                                                                                                                                          assertTrue(result);
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                      public void testIsArgument_RegularOption_ReturnsFalse() throws Exception {
                                                                                                                                                                                          DefaultParser parser = new DefaultParser();
                                                                                                                                                                                          
                                                                                                                                                                                          // Get private methods via reflection
                                                                                                                                                                                          Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                          isOptionMethod.setAccessible(true);
                                                                                                                                                                                          Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                          isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                          Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                          isArgumentMethod.setAccessible(true);
                                                                                                                                                                                          
                                                                                                                                                                                          // Create a spy to mock the private method calls
                                                                                                                                                                                          DefaultParser spyParser = spy(parser);
                                                                                                                                                                                          
                                                                                                                                                                                          // Mock the private method calls using the actual method objects
                                                                                                                                                                                          when(isOptionMethod.invoke(spyParser, "-a")).thenReturn(true);
                                                                                                                                                                                          when(isNegativeNumberMethod.invoke(spyParser, "-a")).thenReturn(false);
                                                                                                                                                                                          
                                                                                                                                                                                          // Test the isArgument method
                                                                                                                                                                                          boolean result = (boolean) isArgumentMethod.invoke(spyParser, "-a");
                                                                                                                                                                                          assertFalse(result);
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                  public void testIsArgument_NonOptionToken_ReturnsTrue() throws Exception {
                                                                                                                                                                                      DefaultParser parser = new DefaultParser();
                                                                                                                                                                                      
                                                                                                                                                                                      // Get the private isOption method
                                                                                                                                                                                      Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                      isOptionMethod.setAccessible(true);
                                                                                                                                                                                      
                                                                                                                                                                                      // Get the private isArgument method
                                                                                                                                                                                      Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                      isArgumentMethod.setAccessible(true);
                                                                                                                                                                                      
                                                                                                                                                                                      // Create a spy of the parser
                                                                                                                                                                                      DefaultParser spyParser = spy(parser);
                                                                                                                                                                                      
                                                                                                                                                                                      // Use reflection to set isOption to return false for our test case
                                                                                                                                                                                      // Since we can't mock private methods, we'll rely on the actual implementation
                                                                                                                                                                                      // but test with a token that we know will make isOption return false
                                                                                                                                                                                      String nonOptionToken = "nonOption";
                                                                                                                                                                                      
                                                                                                                                                                                      // Test that isArgument returns true for non-option token
                                                                                                                                                                                      assertTrue((boolean) isArgumentMethod.invoke(spyParser, nonOptionToken));
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                             public void testIsArgumentWithNegativeNumberOption() throws Exception {
                                                                                                                                                                                 // Create test instance
                                                                                                                                                                                 DefaultParser parser = new DefaultParser();
                                                                                                                                                                                 
                                                                                                                                                                                 // Get private methods via reflection
                                                                                                                                                                                 Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                 isOptionMethod.setAccessible(true);
                                                                                                                                                                                 Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                 isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                 Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                 isArgumentMethod.setAccessible(true);
                                                                                                                                                                                 
                                                                                                                                                                                 // Test case where token is both an option and negative number
                                                                                                                                                                                 String negativeOption = "-1";
                                                                                                                                                                                 
                                                                                                                                                                                 // Set up the parser's internal state to recognize -1 as both option and negative number
                                                                                                                                                                                 // This might require additional reflection to set internal fields if needed
                                                                                                                                                                                 
                                                                                                                                                                                 // Test the behavior
                                                                                                                                                                                 boolean result = (boolean) isArgumentMethod.invoke(parser, negativeOption);
                                                                                                                                                                                 assertTrue("Should return true for negative number even if it's an option", result);
                                                                                                                                                                             }

    @Test
                                                                                                                                                                        public void testIsArgumentDetectsMutant() throws Exception {
                                                                                                                                                                            // Setup test object
                                                                                                                                                                            DefaultParser parser = new DefaultParser();
                                                                                                                                                                            
                                                                                                                                                                            // Get private methods via reflection
                                                                                                                                                                            Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                            isOptionMethod.setAccessible(true);
                                                                                                                                                                            Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                            isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                            Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                            isArgumentMethod.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Case 1: Token is both an option and negative number
                                                                                                                                                                            // Original: true (because isNegativeNumber=true)
                                                                                                                                                                            // Mutant: false (because !isNegativeNumber=false and isOption=true)
                                                                                                                                                                            when(isOptionMethod.invoke(parser, "-1")).thenReturn(true);
                                                                                                                                                                            when(isNegativeNumberMethod.invoke(parser, "-1")).thenReturn(true);
                                                                                                                                                                            assertTrue("Should return true for option that's negative number", 
                                                                                                                                                                                       (Boolean) isArgumentMethod.invoke(parser, "-1"));
                                                                                                                                                                            
                                                                                                                                                                            // Case 2: Token is neither option nor negative number
                                                                                                                                                                            // Original: true (because !isOption=true)
                                                                                                                                                                            // Mutant: true (because !isNegativeNumber=true)
                                                                                                                                                                            when(isOptionMethod.invoke(parser, "plain")).thenReturn(false);
                                                                                                                                                                            when(isNegativeNumberMethod.invoke(parser, "plain")).thenReturn(false);
                                                                                                                                                                            assertTrue("Should return true for plain argument", 
                                                                                                                                                                                       (Boolean) isArgumentMethod.invoke(parser, "plain"));
                                                                                                                                                                            
                                                                                                                                                                            // Case 3: Token is option but not negative number
                                                                                                                                                                            // Original: false (because !isOption=false and isNegativeNumber=false)
                                                                                                                                                                            // Mutant: true (because isOption=true)
                                                                                                                                                                            when(isOptionMethod.invoke(parser, "-v")).thenReturn(true);
                                                                                                                                                                            when(isNegativeNumberMethod.invoke(parser, "-v")).thenReturn(false);
                                                                                                                                                                            assertFalse("Should return false for option that's not negative", 
                                                                                                                                                                                        (Boolean) isArgumentMethod.invoke(parser, "-v"));
                                                                                                                                                                            
                                                                                                                                                                            // Case 4: Token is not option but is negative number
                                                                                                                                                                            // Original: true (because isNegativeNumber=true)
                                                                                                                                                                            // Mutant: false (because !isNegativeNumber=false and isOption=false)
                                                                                                                                                                            when(isOptionMethod.invoke(parser, "-123")).thenReturn(false);
                                                                                                                                                                            when(isNegativeNumberMethod.invoke(parser, "-123")).thenReturn(true);
                                                                                                                                                                            assertTrue("Should return true for negative number that's not option", 
                                                                                                                                                                                       (Boolean) isArgumentMethod.invoke(parser, "-123"));
                                                                                                                                                                        }

    @Test
                                                                                                                                                               public void testIsArgumentWithNegativeNumberNotOption() throws Exception {
                                                                                                                                                                   // Setup
                                                                                                                                                                   DefaultParser parser = new DefaultParser();
                                                                                                                                                                   String negativeNumber = "-123";
                                                                                                                                                                   
                                                                                                                                                                   // Get private methods via reflection
                                                                                                                                                                   Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                   isOptionMethod.setAccessible(true);
                                                                                                                                                                   Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                   isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                   Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                   isArgumentMethod.setAccessible(true);
                                                                                                                                                                   
                                                                                                                                                                   // Mock the behavior of isOption and isNegativeNumber by creating a spy
                                                                                                                                                                   DefaultParser spyParser = spy(parser);
                                                                                                                                                                   when(isOptionMethod.invoke(spyParser, negativeNumber)).thenReturn(false);
                                                                                                                                                                   when(isNegativeNumberMethod.invoke(spyParser, negativeNumber)).thenReturn(true);
                                                                                                                                                                   
                                                                                                                                                                   // Test and verify
                                                                                                                                                                   assertTrue("Should return true for negative number that's not an option", 
                                                                                                                                                                             (Boolean) isArgumentMethod.invoke(spyParser, negativeNumber));
                                                                                                                                                                   
                                                                                                                                                                   // Verify interactions through reflection instead of direct verification
                                                                                                                                                                   isOptionMethod.invoke(spyParser, negativeNumber);
                                                                                                                                                                   isNegativeNumberMethod.invoke(spyParser, negativeNumber);
                                                                                                                                                               }

    @Test
                                                                                                                                                          public void testIsArgumentDetectsMutant1() throws Exception {
                                                                                                                                                              // Create instance of DefaultParser
                                                                                                                                                              DefaultParser parser = new DefaultParser();
                                                                                                                                                              
                                                                                                                                                              // Get private methods via reflection
                                                                                                                                                              Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                              Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                              Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                              
                                                                                                                                                              // Set methods accessible
                                                                                                                                                              isArgumentMethod.setAccessible(true);
                                                                                                                                                              isOptionMethod.setAccessible(true);
                                                                                                                                                              isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                              
                                                                                                                                                              // Create spy to mock the helper methods
                                                                                                                                                              DefaultParser spyParser = spy(parser);
                                                                                                                                                              
                                                                                                                                                              // Case 1: Not an option and not a negative number (should return true in original)
                                                                                                                                                              when(isOptionMethod.invoke(spyParser, "regularArg")).thenReturn(false);
                                                                                                                                                              when(isNegativeNumberMethod.invoke(spyParser, "regularArg")).thenReturn(false);
                                                                                                                                                              assertTrue("Should return true for non-option, non-negative number", 
                                                                                                                                                                  (Boolean) isArgumentMethod.invoke(spyParser, "regularArg"));
                                                                                                                                                              
                                                                                                                                                              // Case 2: Is an option and is a negative number (should return false in original)
                                                                                                                                                              when(isOptionMethod.invoke(spyParser, "-1")).thenReturn(true);
                                                                                                                                                              when(isNegativeNumberMethod.invoke(spyParser, "-1")).thenReturn(true);
                                                                                                                                                              assertFalse("Should return false for option that's negative number", 
                                                                                                                                                                  (Boolean) isArgumentMethod.invoke(spyParser, "-1"));
                                                                                                                                                              
                                                                                                                                                              // Case 3: Not an option but is negative number (should return true in both)
                                                                                                                                                              when(isOptionMethod.invoke(spyParser, "-123")).thenReturn(false);
                                                                                                                                                              when(isNegativeNumberMethod.invoke(spyParser, "-123")).thenReturn(true);
                                                                                                                                                              assertTrue("Should return true for negative number that's not an option", 
                                                                                                                                                                  (Boolean) isArgumentMethod.invoke(spyParser, "-123"));
                                                                                                                                                              
                                                                                                                                                              // Case 4: Is an option but not negative number (should return false in both)
                                                                                                                                                              when(isOptionMethod.invoke(spyParser, "-v")).thenReturn(true);
                                                                                                                                                              when(isNegativeNumberMethod.invoke(spyParser, "-v")).thenReturn(false);
                                                                                                                                                              assertFalse("Should return false for option that's not negative number", 
                                                                                                                                                                  (Boolean) isArgumentMethod.invoke(spyParser, "-v"));
                                                                                                                                                          }

    @Test
                                                                                                                                             public void testIsArgument_WhenTokenIsOptionAndNotNegativeNumber_ShouldReturnFalse() throws Exception {
                                                                                                                                                 // Setup
                                                                                                                                                 DefaultParser parser = new DefaultParser();
                                                                                                                                                 String token = "-option"; // This is an option but not a negative number
                                                                                                                                                 
                                                                                                                                                 // Get private methods via reflection
                                                                                                                                                 Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                 isOptionMethod.setAccessible(true);
                                                                                                                                                 Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                 isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                 Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                 isArgumentMethod.setAccessible(true);
                                                                                                                                                 
                                                                                                                                                 // Create spy to mock the private method calls
                                                                                                                                                 DefaultParser spyParser = spy(parser);
                                                                                                                                                 
                                                                                                                                                 // Mock the behavior of private methods using reflection
                                                                                                                                                 when(isOptionMethod.invoke(spyParser, token)).thenReturn(true);
                                                                                                                                                 when(isNegativeNumberMethod.invoke(spyParser, token)).thenReturn(false);
                                                                                                                                                 
                                                                                                                                                 // Test
                                                                                                                                                 boolean result = (boolean) isArgumentMethod.invoke(spyParser, token);
                                                                                                                                                 
                                                                                                                                                 // Verify
                                                                                                                                                 assertFalse("Should return false for option that's not negative number", result);
                                                                                                                                                 
                                                                                                                                                 // Verify interactions - we can't directly verify reflection calls, but we can verify the result
                                                                                                                                                 // which implicitly verifies the calls were made
                                                                                                                                             }

    @Test
                                                                                                                                    public void testIsArgumentWithNegativeNumberOption1() throws Exception {
                                                                                                                                        // Setup
                                                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                                                        String negativeOption = "-123"; // Example of negative number option
                                                                                                                                        
                                                                                                                                        // Get private methods via reflection
                                                                                                                                        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                        isOptionMethod.setAccessible(true);
                                                                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                        isArgumentMethod.setAccessible(true);
                                                                                                                                        
                                                                                                                                        // Create a spy to verify method calls (though we won't be able to verify private method calls)
                                                                                                                                        DefaultParser spyParser = spy(parser);
                                                                                                                                        
                                                                                                                                        // Instead of mocking, we'll use reflection to test the actual behavior
                                                                                                                                        // First, verify that isOption would return true for our negative number
                                                                                                                                        assertTrue((Boolean) isOptionMethod.invoke(spyParser, negativeOption));
                                                                                                                                        
                                                                                                                                        // Verify that isNegativeNumber would return true for our negative number
                                                                                                                                        assertTrue((Boolean) isNegativeNumberMethod.invoke(spyParser, negativeOption));
                                                                                                                                        
                                                                                                                                        // Test - should return true because it's a negative number, even though it's an option
                                                                                                                                        assertTrue((Boolean) isArgumentMethod.invoke(spyParser, negativeOption));
                                                                                                                                        
                                                                                                                                        // Note: We can't verify private method calls with Mockito, so those verify lines are removed
                                                                                                                                    }

    @Test
                                                                                                                               public void testIsArgumentWithNegativeNumberOption2() throws Exception {
                                                                                                                                   // Setup
                                                                                                                                   DefaultParser parser = new DefaultParser();
                                                                                                                                   String negativeNumberOption = "-1";
                                                                                                                                   
                                                                                                                                   // Get and invoke private method via reflection
                                                                                                                                   Method method = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                   method.setAccessible(true);
                                                                                                                                   boolean result = (Boolean) method.invoke(parser, negativeNumberOption);
                                                                                                                                   
                                                                                                                                   // Assert the expected behavior
                                                                                                                                   assertTrue(result);
                                                                                                                               }

    @Test
                                                                                                                          public void testIsArgumentWithRegularStringShouldReturnTrue() {
                                                                                                                              // Setup
                                                                                                                              DefaultParser parser = new DefaultParser();
                                                                                                                              Options options = new Options();
                                                                                                                              
                                                                                                                              // Add a simple option to ensure the parser has something to work with
                                                                                                                              options.addOption("h", "help", false, "display help");
                                                                                                                              
                                                                                                                              // This regular string should be treated as an argument (not an option)
                                                                                                                              String regularString = "hello";
                                                                                                                              String[] args = {regularString};
                                                                                                                              
                                                                                                                              try {
                                                                                                                                  // Test - parse should accept the regular string as an argument
                                                                                                                                  CommandLine cmd = parser.parse(options, args);
                                                                                                                                  
                                                                                                                                  // Verify the argument was accepted
                                                                                                                                  List<String> argList = cmd.getArgList();
                                                                                                                                  assertTrue(argList.contains(regularString));
                                                                                                                              } catch (ParseException e) {
                                                                                                                                  fail("Should not throw ParseException for regular string argument");
                                                                                                                              }
                                                                                                                          }

    @Test
                                                                                                                          public void testIsArgumentWithPositiveOptionShouldReturnFalse() throws Exception {
                                                                                                                              // Setup
                                                                                                                              DefaultParser parser = new DefaultParser();
                                                                                                                              
                                                                                                                              // Get private methods via reflection
                                                                                                                              Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                              Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                              Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                              
                                                                                                                              // Make methods accessible
                                                                                                                              isArgumentMethod.setAccessible(true);
                                                                                                                              isOptionMethod.setAccessible(true);
                                                                                                                              isNegativeNumberMethod.setAccessible(true);
                                                                                                                              
                                                                                                                              // Mock the behavior of private methods using reflection
                                                                                                                              // Since we can't mock private methods directly, we'll need to test the actual implementation
                                                                                                                              // or restructure our test approach
                                                                                                                              
                                                                                                                              String positiveOption = "1";
                                                                                                                              
                                                                                                                              // Test the actual behavior
                                                                                                                              boolean isOption = (boolean) isOptionMethod.invoke(parser, positiveOption);
                                                                                                                              boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, positiveOption);
                                                                                                                              boolean result = (boolean) isArgumentMethod.invoke(parser, positiveOption);
                                                                                                                              
                                                                                                                              // Verify the expected behavior
                                                                                                                              // The original test expected false when isOption=true and isNegativeNumber=false
                                                                                                                              // because isArgument = !isOption || isNegativeNumber
                                                                                                                              assertEquals(!isOption || isNegativeNumber, result);
                                                                                                                          }

    @Test
                                                                                                                      public void testIsArgumentWithNegativeOptionShouldReturnTrue() {
                                                                                                                          // Setup
                                                                                                                          DefaultParser parser = new DefaultParser();
                                                                                                                          Options options = new Options();
                                                                                                                          options.addOption("1", false, "");  // Using traditional option creation
                                                                                                                          
                                                                                                                          // Test - "-1" should be treated as an argument (negative number) 
                                                                                                                          // rather than an option, even though "1" is a valid option
                                                                                                                          try {
                                                                                                                              parser.parse(options, new String[] {"-1"});
                                                                                                                              fail("Expected MissingArgumentException");
                                                                                                                          } catch (MissingArgumentException e) {
                                                                                                                              // Expected - this proves "-1" was not treated as an option
                                                                                                                              // but rather as an argument to a non-existent option
                                                                                                                          } catch (ParseException e) {
                                                                                                                              fail("Unexpected exception: " + e.getMessage());
                                                                                                                          }
                                                                                                                      }

    @Test
                                                                                                     public void testIsArgumentWithNegativeNumber() {
                                                                                                         // Setup
                                                                                                         org.apache.commons.cli.DefaultParser parser = new org.apache.commons.cli.DefaultParser();
                                                                                                         org.apache.commons.cli.Options options = new org.apache.commons.cli.Options();
                                                                                                         // Add an option that takes an argument to ensure the negative number is treated as an argument
                                                                                                         options.addOption(new org.apache.commons.cli.Option("a", "arg", true, "argument option"));
                                                                                                         
                                                                                                         String[] args = {"-a", "-123"}; // -123 should be treated as an argument
                                                                                                         
                                                                                                         // Test
                                                                                                         try {
                                                                                                             org.apache.commons.cli.CommandLine cmd = parser.parse(options, args);
                                                                                                             // Verify that -123 was correctly parsed as an argument
                                                                                                             org.junit.Assert.assertEquals("-123", cmd.getOptionValue("a"));
                                                                                                         } catch (org.apache.commons.cli.ParseException e) {
                                                                                                             org.junit.Assert.fail("Should not throw ParseException for negative number argument");
                                                                                                         }
                                                                                                     }

    @Test
                                                                                                public void testIsArgumentDetectsMutant2() throws Exception {
                                                                                                    // Create instance of DefaultParser
                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                    
                                                                                                    // Get private methods via reflection
                                                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                    
                                                                                                    // Set methods accessible
                                                                                                    isArgumentMethod.setAccessible(true);
                                                                                                    isOptionMethod.setAccessible(true);
                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Test case 1: Token is neither option nor negative number
                                                                                                    // We can't mock private methods, so we'll test the actual implementation
                                                                                                    // For this test case, we expect "regular" to be an argument
                                                                                                    assertTrue("Should return true for non-option, non-negative", 
                                                                                                        (boolean) isArgumentMethod.invoke(parser, "regular"));
                                                                                                    // Mutant would return false
                                                                                                    
                                                                                                    // Test case 2: Token is option but not negative number
                                                                                                    // We need to verify that "-o" is detected as an option (not argument)
                                                                                                    assertFalse("Should return false for option that's not negative", 
                                                                                                        (boolean) isArgumentMethod.invoke(parser, "-o"));
                                                                                                    // Mutant would return true
                                                                                                    
                                                                                                    // Test case 3: Token is not option but is negative number
                                                                                                    // We need to verify that "-123" is detected as an argument (negative number)
                                                                                                    assertTrue("Should return true for negative number", 
                                                                                                        (boolean) isArgumentMethod.invoke(parser, "-123"));
                                                                                                    // Both original and mutant return true
                                                                                                    
                                                                                                    // Test case 4: Token is both option and negative number
                                                                                                    // We need to verify that "--123" is detected as an argument (negative number)
                                                                                                    assertTrue("Should return true for option that's negative number", 
                                                                                                        (boolean) isArgumentMethod.invoke(parser, "--123"));
                                                                                                    // Mutant would return false
                                                                                                }

    @Test
                                                                                       public void testIsArgumentWithPositiveNumberOptionShouldReturnFalse() throws Exception {
                                                                                           // Setup
                                                                                           DefaultParser parser = new DefaultParser();
                                                                                           
                                                                                           // Get private methods via reflection
                                                                                           Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                           isOptionMethod.setAccessible(true);
                                                                                           Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                           isNegativeNumberMethod.setAccessible(true);
                                                                                           Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                           isArgumentMethod.setAccessible(true);
                                                                                           
                                                                                           String positiveNumberOption = "123"; // positive number that is an option
                                                                                           
                                                                                           // Create a spy that will return our desired values for the private methods
                                                                                           DefaultParser spyParser = spy(parser);
                                                                                           when(isOptionMethod.invoke(spyParser, positiveNumberOption)).thenReturn(true);
                                                                                           when(isNegativeNumberMethod.invoke(spyParser, positiveNumberOption)).thenReturn(false);
                                                                                           
                                                                                           // Test and verify
                                                                                           assertFalse("Positive number option should not be considered an argument", 
                                                                                                     (Boolean) isArgumentMethod.invoke(spyParser, positiveNumberOption));
                                                                                           
                                                                                           // Verify interactions through reflection instead of direct method calls
                                                                                           verify(spyParser, times(1));
                                                                                           verify(spyParser, times(1));
                                                                                       }

    @Test
                                                                              public void testIsArgument_WithNegativeNumberOption_ShouldReturnTrue() {
                                                                                  // Arrange
                                                                                  DefaultParser parser = new DefaultParser();
                                                                                  Options options = new Options();
                                                                                  options.addOption(new Option("1", false, ""));
                                                                                  
                                                                                  // This test is tricky because isArgument is private
                                                                                  // We'll test it indirectly by seeing how the parser handles negative numbers
                                                                                  String[] args = {"-1", "value"};
                                                                                  
                                                                                  try {
                                                                                      // Act
                                                                                      CommandLine cmd = parser.parse(options, args, true);
                                                                                      
                                                                                      // Assert that "-1" was treated as an argument, not an option
                                                                                      // Since "-1" is a negative number, it should be treated as argument
                                                                                      assertFalse("Negative number should not be recognized as option", 
                                                                                                 cmd.getOptions().length > 0 && cmd.getOptions()[0].getOpt().equals("1"));
                                                                                      assertEquals("value", cmd.getArgList().get(0));
                                                                                  } catch (ParseException e) {
                                                                                      fail("Parsing should not throw exception for negative number argument");
                                                                                  }
                                                                              }

    @Test
                                                                     public void testIsArgumentWithNegativeNumberOption3() throws Exception {
                                                                         // Setup
                                                                         DefaultParser parser = new DefaultParser();
                                                                         String negativeNumberOption = "-1"; // This is both an option (starts with -) and a negative number
                                                                         
                                                                         // Get private methods via reflection
                                                                         Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                         isOptionMethod.setAccessible(true);
                                                                         Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                         isNegativeNumberMethod.setAccessible(true);
                                                                         Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                         isArgumentMethod.setAccessible(true);
                                                                         
                                                                         // Create spy parser
                                                                         DefaultParser spyParser = spy(parser);
                                                                         
                                                                         // Mock the behavior of private methods using reflection
                                                                         when(isOptionMethod.invoke(spyParser, negativeNumberOption)).thenReturn(true);
                                                                         when(isNegativeNumberMethod.invoke(spyParser, negativeNumberOption)).thenReturn(true);
                                                                         
                                                                         // Test - original should return true (because it's a negative number)
                                                                         // Mutant would return false (because it only checks isOption)
                                                                         boolean result = (boolean) isArgumentMethod.invoke(spyParser, negativeNumberOption);
                                                                         assertTrue("Should return true for negative number even if it's an option", result);
                                                                         
                                                                         // Verify interactions
                                                                         verify(spyParser, times(1)).getClass().getDeclaredMethod("isOption", String.class);
                                                                         verify(spyParser, times(1)).getClass().getDeclaredMethod("isNegativeNumber", String.class);
                                                                     }

    @Test
                                                                public void testIsArgumentWithNegativeNumber1() throws Exception {
                                                                    // Setup
                                                                    DefaultParser parser = new DefaultParser();
                                                                    String negativeNumber = "-123";
                                                                    
                                                                    // Get private methods via reflection
                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                    isOptionMethod.setAccessible(true);
                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                    isArgumentMethod.setAccessible(true);
                                                                    
                                                                    // Create spy parser
                                                                    DefaultParser spyParser = spy(parser);
                                                                    
                                                                    // Mock the behavior of helper methods using reflection
                                                                    when(isOptionMethod.invoke(spyParser, negativeNumber)).thenReturn(false);
                                                                    when(isNegativeNumberMethod.invoke(spyParser, negativeNumber)).thenReturn(true);
                                                                    
                                                                    // Test - should return true because it's a negative number
                                                                    boolean result = (boolean) isArgumentMethod.invoke(spyParser, negativeNumber);
                                                                    
                                                                    // Assert - both original and mutant would return true
                                                                    assertTrue("Negative number should be considered an argument", result);
                                                                }

    @Test
                                                    public void testIsArgumentWithOptionNonNegativeNumber() throws Exception {
                                                        // Setup
                                                        DefaultParser parser = new DefaultParser();
                                                        String optionNonNegative = "-option";
                                                        
                                                        // Create spy parser
                                                        DefaultParser spyParser = spy(parser);
                                                        
                                                        // Mock the behavior of private helper methods using reflection
                                                        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                        isOptionMethod.setAccessible(true);
                                                        when(isOptionMethod.invoke(spyParser, optionNonNegative)).thenReturn(true);
                                                        
                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                        isNegativeNumberMethod.setAccessible(true);
                                                        when(isNegativeNumberMethod.invoke(spyParser, optionNonNegative)).thenReturn(false);
                                                        
                                                        // Get the isArgument method
                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                        isArgumentMethod.setAccessible(true);
                                                        
                                                        // Test - should return false because it's an option and not negative
                                                        boolean result = (boolean) isArgumentMethod.invoke(spyParser, optionNonNegative);
                                                        
                                                        // Assert - both original and mutant would return false
                                                        assertFalse("Option that's not negative number should not be considered an argument", result);
                                                    }

    @Test
                                                public void testIsArgumentDetectsNonOptionNonNegativeNumber() {
                                                    // Setup
                                                    DefaultParser parser = new DefaultParser();
                                                    Options options = new Options();
                                                    String[] args = {"regularArgument"};  // non-option, non-negative number
                                                    
                                                    try {
                                                        // Test by parsing arguments - if it's treated as an argument, it will appear in the result
                                                        CommandLine cmd = parser.parse(options, args);
                                                        
                                                        // Assert that the argument was recognized
                                                        assertEquals(1, cmd.getArgList().size());
                                                        assertEquals("regularArgument", cmd.getArgList().get(0));
                                                    } catch (ParseException e) {
                                                        fail("Unexpected ParseException: " + e.getMessage());
                                                    }
                                                }

    @Test
                                           public void testIsArgumentWithRegularOption() throws Exception {
                                               DefaultParser parser = new DefaultParser();
                                               String regularOption = "-f";
                                               
                                               // Get private methods via reflection
                                               Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                               isOptionMethod.setAccessible(true);
                                               Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                               isNegativeNumberMethod.setAccessible(true);
                                               Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                               isArgumentMethod.setAccessible(true);
                                               
                                               // Mock the behavior by creating a spy
                                               DefaultParser spyParser = spy(parser);
                                               when(isOptionMethod.invoke(spyParser, regularOption)).thenReturn(true);
                                               when(isNegativeNumberMethod.invoke(spyParser, regularOption)).thenReturn(false);
                                               
                                               // Test the actual method
                                               boolean result = (boolean) isArgumentMethod.invoke(spyParser, regularOption);
                                               assertFalse("Should return false for regular option", result);
                                           }

    @Test
                                           public void testIsArgumentWithNonOption() throws Exception {
                                               DefaultParser parser = new DefaultParser();
                                               String nonOption = "filename";
                                               
                                               // Get private methods via reflection
                                               Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                               isOptionMethod.setAccessible(true);
                                               Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                               isNegativeNumberMethod.setAccessible(true);
                                               Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                               isArgumentMethod.setAccessible(true);
                                               
                                               // Mock the behavior by spying on the real object
                                               DefaultParser spyParser = spy(parser);
                                               when(isOptionMethod.invoke(spyParser, nonOption)).thenReturn(false);
                                               when(isNegativeNumberMethod.invoke(spyParser, nonOption)).thenReturn(false);
                                               
                                               // Test the actual method
                                               boolean result = (boolean) isArgumentMethod.invoke(spyParser, nonOption);
                                               assertTrue("Should return true for non-option", result);
                                           }

    @Test
                                           public void testIsArgumentWithNegativeNumberNonOption() throws Exception {
                                               DefaultParser parser = new DefaultParser();
                                               String negativeNonOption = "-123";
                                               
                                               Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                               isArgumentMethod.setAccessible(true);
                                               
                                               boolean result = (boolean) isArgumentMethod.invoke(parser, negativeNonOption);
                                               
                                               assertTrue("Should return true for negative number that's not an option", result);
                                           }

    @Test
                               public void testIsArgumentWithNegativeNumberOption4() throws Exception {
                                   // Create a parser instance using reflection since there are no public constructors
                                   Constructor<DefaultParser> constructor = DefaultParser.class.getDeclaredConstructor();
                                   constructor.setAccessible(true);
                                   DefaultParser parser = constructor.newInstance();
                                   
                                   // Setup the test case where token is both an option and negative number
                                   String negativeOption = "-123";
                                   
                                   // Create a spy of the parser
                                   DefaultParser spyParser = spy(parser);
                                   
                                   // Get the private methods we need to test
                                   Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                   isOptionMethod.setAccessible(true);
                                   
                                   Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                   isNegativeNumberMethod.setAccessible(true);
                                   
                                   // Mock the behavior of private methods using when/thenReturn with reflection
                                   when(isOptionMethod.invoke(spyParser, negativeOption)).thenReturn(true);
                                   when(isNegativeNumberMethod.invoke(spyParser, negativeOption)).thenReturn(true);
                                   
                                   // Call the method under test
                                   Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                   isArgumentMethod.setAccessible(true);
                                   boolean result = (boolean) isArgumentMethod.invoke(spyParser, negativeOption);
                                   
                                   // The original should return true (!true || true) -> (false || true) -> true
                                   // The mutant would return true (!true || !true) -> (false || false) -> false
                                   assertTrue("Should return true for negative number that is an option", result);
                               }

    @Test
                          public void testIsArgument_ShouldReturnFalseForPositiveNumberOption() throws Exception {
                              // Create a parser instance using reflection since there are no public constructors
                              Constructor<DefaultParser> constructor = DefaultParser.class.getDeclaredConstructor();
                              constructor.setAccessible(true);
                              DefaultParser parser = constructor.newInstance();
                              
                              // Setup the test case where:
                              // - token is an option (isOption returns true)
                              // - token is a positive number (isNegativeNumber returns false)
                              String positiveNumberOption = "123";
                              
                              // Get the private methods we need to test
                              Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                              isOptionMethod.setAccessible(true);
                              Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                              isNegativeNumberMethod.setAccessible(true);
                              Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                              isArgumentMethod.setAccessible(true);
                              
                              // Mock the behavior of the methods called by isArgument
                              // Since we can't mock private methods, we'll need to modify the test approach
                              // We'll assume that if isOption returns true and isNegativeNumber returns false,
                              // then isArgument should return false
                              
                              // First, verify that isOption returns true for our test case
                              // (This would normally be mocked, but since we're testing real methods, we'll
                              // just verify the expected behavior)
                              boolean isOption = (boolean) isOptionMethod.invoke(parser, positiveNumberOption);
                              boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, positiveNumberOption);
                              
                              // Now test the isArgument method
                              boolean result = (boolean) isArgumentMethod.invoke(parser, positiveNumberOption);
                              
                              // Verify the behavior
                              assertFalse("Should return false for positive number that is an option", result);
                          }

    @Test
                     public void testIsArgumentWithNegativeNumberOption5() throws Exception {
                         // Setup
                         DefaultParser parser = new DefaultParser();
                         String negativeNumberOption = "-123"; // This is both an option (starts with -) and negative number
                         
                         // Use reflection to test private methods
                         Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                         isArgumentMethod.setAccessible(true);
                         
                         Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                         isOptionMethod.setAccessible(true);
                         
                         Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                         isNegativeNumberMethod.setAccessible(true);
                         
                         // Verify the behavior of isOption and isNegativeNumber
                         boolean isOption = (boolean) isOptionMethod.invoke(parser, negativeNumberOption);
                         boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, negativeNumberOption);
                         
                         // Test isArgument
                         boolean result = (boolean) isArgumentMethod.invoke(parser, negativeNumberOption);
                         
                         // Assertions
                         assertTrue("Should return true for negative number that is also an option", result);
                         assertTrue("Should be recognized as an option", isOption);
                         assertTrue("Should be recognized as a negative number", isNegativeNumber);
                     }

    @Test
                public void testIsArgument_NonOptionNonNegative_ShouldReturnTrue() {
                    // Setup
                    DefaultParser parser = new DefaultParser();
                    String token = "regularArgument";
                    
                    // We can't directly test private methods, so we'll test through public behavior
                    // In this case, we'll test that the parser correctly handles a regular argument
                    // by parsing it in a context where it should be accepted
                    
                    Options options = new Options();
                    options.addOption("a", "option", false, "test option");
                    
                    // This should parse successfully with our regular argument
                    try {
                        CommandLine cmd = parser.parse(options, new String[] {token});
                        assertTrue(cmd.getArgList().contains(token));
                    } catch (ParseException e) {
                        fail("Should not throw exception for regular argument");
                    }
                }

    @Test
        public void testIsArgument_OptionNonNegative_ShouldReturnFalse() throws Exception {
            // Setup
            DefaultParser parser = new DefaultParser();
            String token = "-option";
            
            // Get private methods via reflection
            Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
            Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
            Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
            
            // Make methods accessible
            isArgumentMethod.setAccessible(true);
            isOptionMethod.setAccessible(true);
            isNegativeNumberMethod.setAccessible(true);
            
            // Mock the behavior of helper methods using a spy
            DefaultParser spyParser = spy(parser);
            when(isOptionMethod.invoke(spyParser, token)).thenReturn(true);
            when(isNegativeNumberMethod.invoke(spyParser, token)).thenReturn(false);
            
            // Test and verify
            assertFalse((Boolean) isArgumentMethod.invoke(spyParser, token));
            
            // Can't verify private method calls directly, so we rely on the behavior verification above
        }

    @Test
    public void testIsArgument_OptionButNegativeNumber_ShouldReturnTrue() {
        // Setup
        org.apache.commons.cli.DefaultParser parser = new org.apache.commons.cli.DefaultParser();
        org.apache.commons.cli.Options options = new org.apache.commons.cli.Options();
        // Add an option that would conflict with our negative number
        options.addOption(new org.apache.commons.cli.Option("1", "one", false, ""));
        
        // This token looks like an option (-123) but is actually a negative number
        String token = "-123";
        
        try {
            // Use reflection to access the private isArgument method
            java.lang.reflect.Method isArgumentMethod = org.apache.commons.cli.DefaultParser.class.getDeclaredMethod("isArgument", String.class);
            isArgumentMethod.setAccessible(true);
            
            // Invoke the method and verify the result
            boolean result = (boolean) isArgumentMethod.invoke(parser, token);
            assertTrue("Negative number should be treated as argument", result);
        } catch (Exception e) {
            fail("Exception occurred while testing isArgument: " + e.getMessage());
        }
    }


}
