package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                        public void testPrintWrapped_NullTextShouldThrowException() {
                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                            HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                            PrintWriter pw = mock(PrintWriter.class);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Expect exception
                                                                                                                                                                                                                                                            thrown.expect(NullPointerException.class);
                                                                                                                                                                                                                                                            thrown.expectMessage("text");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                            // Execute
                                                                                                                                                                                                                                                            formatter.printWrapped(pw, 80, 4, null);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testPrintWrapped_ZeroWidthShouldThrowException() {
                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                            HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                            PrintWriter pw = mock(PrintWriter.class);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Expect exception
                                                                                                                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                            thrown.expectMessage("width must be > 0");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                            // Execute
                                                                                                                                                                                                                                                            formatter.printWrapped(pw, 0, 4, "text");
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testPrintWrapped_NegativeWidthShouldThrowException() {
                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                            HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                            PrintWriter pw = mock(PrintWriter.class);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Expect exception
                                                                                                                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                            thrown.expectMessage("width must be > 0");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                            // Execute
                                                                                                                                                                                                                                                            formatter.printWrapped(pw, -10, 4, "text");
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testPrintWrapped_NegativeNextLineTabStopShouldThrowException() {
                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                            HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                            PrintWriter pw = mock(PrintWriter.class);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Expect exception
                                                                                                                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                            thrown.expectMessage("nextLineTabStop must be >= 0");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                            // Execute
                                                                                                                                                                                                                                                            formatter.printWrapped(pw, 80, -1, "text");
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testPrintWrapped_VerifyPrintWriterInteraction() {
                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                            HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                            PrintWriter pw = mock(PrintWriter.class);
                                                                                                                                                                                                                                                            String text = "Test text";
                                                                                                                                                                                                                                                            int width = 80;
                                                                                                                                                                                                                                                            int nextLineTabStop = 4;
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                            // Execute
                                                                                                                                                                                                                                                            formatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                            verify(pw).println("Test text");
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                public void testPrintWrapped_NullText() {
                                                                                                                                                                                                                                                    // Initialize required objects
                                                                                                                                                                                                                                                    PrintWriter printWriter = new PrintWriter(System.out);
                                                                                                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Set up expected exception
                                                                                                                                                                                                                                                    ExpectedException.none().expect(NullPointerException.class);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Test the method
                                                                                                                                                                                                                                                    helpFormatter.printWrapped(printWriter, 80, null);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testPrintWrapped_ZeroWidth() {
                                                                                                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                                                                                                    PrintWriter printWriter = new PrintWriter(System.out);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                    helpFormatter.printWrapped(printWriter, 0, "Some text");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    printWriter.close();
                                                                                                                                                                                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                                                public void testPrintWrapped_NegativeWidth() {
                                                                                                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                                                                                                    PrintWriter printWriter = new PrintWriter(System.out);
                                                                                                                                                                                                                                                    helpFormatter.printWrapped(printWriter, -10, "Some text");
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testPrintWrapped_NullPrintWriter() {
                                                                                                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    thrown.expect(NullPointerException.class);
                                                                                                                                                                                                                                                    helpFormatter.printWrapped(null, 80, "Some text");
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testPrintWrapped_EmptyText() {
                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                    org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                    java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                    String text = "";
                                                                                                                                                                                                                                                    int width = 80;
                                                                                                                                                                                                                                                    int nextLineTabStop = 4;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                                    formatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                                                                    pw.flush();
                                                                                                                                                                                                                                                    assertEquals("", stringWriter.toString());
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testPrintWrapped_ShortTextNoWrappingNeeded() {
                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                    org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                    java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                    String text = "Short text";
                                                                                                                                                                                                                                                    int width = 80;
                                                                                                                                                                                                                                                    int nextLineTabStop = 4;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                                    formatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                                                                    pw.flush();
                                                                                                                                                                                                                                                    assertEquals("Short text" + System.lineSeparator(), stringWriter.toString());
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testPrintWrapped_LongTextRequiresWrapping() {
                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                    org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                    java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                    String text = "This is a very long text that should be wrapped when it exceeds the specified width";
                                                                                                                                                                                                                                                    int width = 20;
                                                                                                                                                                                                                                                    int nextLineTabStop = 4;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                                    formatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                                                                    pw.flush();
                                                                                                                                                                                                                                                    String expected = "This is a very long" + System.lineSeparator() +
                                                                                                                                                                                                                                                                     "    text that should" + System.lineSeparator() +
                                                                                                                                                                                                                                                                     "    be wrapped when" + System.lineSeparator() +
                                                                                                                                                                                                                                                                     "    it exceeds the" + System.lineSeparator() +
                                                                                                                                                                                                                                                                     "    specified width" + System.lineSeparator();
                                                                                                                                                                                                                                                    org.junit.Assert.assertEquals(expected, stringWriter.toString());
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testPrintWrapped_TextWithNewlines() {
                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                    org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                    java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                    String text = "First line\nSecond line\nThird line";
                                                                                                                                                                                                                                                    int width = 80;
                                                                                                                                                                                                                                                    int nextLineTabStop = 4;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                                    formatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                                                                    pw.flush();
                                                                                                                                                                                                                                                    String expected = "First line" + System.lineSeparator() +
                                                                                                                                                                                                                                                                     "Second line" + System.lineSeparator() +
                                                                                                                                                                                                                                                                     "Third line" + System.lineSeparator();
                                                                                                                                                                                                                                                    org.junit.Assert.assertEquals(expected, stringWriter.toString());
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testPrintWrapped_TextWithVeryLongWord() {
                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                    org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                    java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                    String text = "ThisTextIsExtremelyLongAndCannotBeBrokenBySpacesSoItShouldBeForcedToWrap";
                                                                                                                                                                                                                                                    int width = 20;
                                                                                                                                                                                                                                                    int nextLineTabStop = 4;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                                    formatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                                                                    pw.flush();
                                                                                                                                                                                                                                                    String expected = "ThisTextIsExtremely" + System.lineSeparator() +
                                                                                                                                                                                                                                                                     "    LongAndCannotBeBr" + System.lineSeparator() +
                                                                                                                                                                                                                                                                     "    okenBySpacesSoItS" + System.lineSeparator() +
                                                                                                                                                                                                                                                                     "    houldBeForcedToWr" + System.lineSeparator() +
                                                                                                                                                                                                                                                                     "    ap" + System.lineSeparator();
                                                                                                                                                                                                                                                    org.junit.Assert.assertEquals(expected, stringWriter.toString());
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testRenderWrappedTextBlock_SingleLine() throws Exception {
                                                                                                                                                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                    formatter.setNewLine("\n");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    StringBuffer sb = new StringBuffer();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Use reflection to access the private method
                                                                                                                                                                                                                                                    Method method = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                                                                                                        "renderWrappedTextBlock", 
                                                                                                                                                                                                                                                        StringBuffer.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        String.class
                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    String result = ((StringBuffer)method.invoke(formatter, sb, 10, 2, "Hello World")).toString();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertEquals("Hello World", result);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testRenderWrappedTextBlock_MultipleLines() throws Exception {
                                                                                                                                                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                    formatter.setNewLine("\\n");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    StringBuffer sb = new StringBuffer();
                                                                                                                                                                                                                                                    String text = "Line1\\nLine2\\nLine3";
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                                                                                                    Method method = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                                                                                                        "renderWrappedTextBlock", 
                                                                                                                                                                                                                                                        StringBuffer.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        String.class
                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                                                                                    String result = ((StringBuffer)method.invoke(formatter, sb, 10, 2, text)).toString();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertEquals("Line1\\nLine2\\nLine3", result);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testRenderWrappedTextBlock_EmptyString() throws Exception {
                                                                                                                                                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                    formatter.setNewLine("\n");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    StringBuffer sb = new StringBuffer();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get the private method using reflection
                                                                                                                                                                                                                                                    Method method = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                                                                                                        "renderWrappedTextBlock", 
                                                                                                                                                                                                                                                        StringBuffer.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        String.class
                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Invoke the method
                                                                                                                                                                                                                                                    StringBuffer resultBuffer = (StringBuffer) method.invoke(
                                                                                                                                                                                                                                                        formatter, 
                                                                                                                                                                                                                                                        sb, 
                                                                                                                                                                                                                                                        10, 
                                                                                                                                                                                                                                                        2, 
                                                                                                                                                                                                                                                        ""
                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                    String result = resultBuffer.toString();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertEquals("", result);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testRenderWrappedTextBlock_NullText() throws Exception {
                                                                                                                                                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                    StringBuffer sb = new StringBuffer();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get the private method using reflection
                                                                                                                                                                                                                                                    Method method = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                                                                                                        "renderWrappedTextBlock", 
                                                                                                                                                                                                                                                        StringBuffer.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        String.class
                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Invoke the method
                                                                                                                                                                                                                                                    StringBuffer resultBuffer = (StringBuffer) method.invoke(formatter, sb, 10, 2, null);
                                                                                                                                                                                                                                                    String result = resultBuffer.toString();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertEquals("", result);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testRenderWrappedTextBlock_CustomNewLine() throws Exception {
                                                                                                                                                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                    formatter.setNewLine("\\r\\n");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    StringBuffer sb = new StringBuffer();
                                                                                                                                                                                                                                                    String text = "First\\nSecond";
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get the private method using reflection
                                                                                                                                                                                                                                                    Method method = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                                                                                                        "renderWrappedTextBlock", 
                                                                                                                                                                                                                                                        StringBuffer.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        String.class
                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Invoke the method
                                                                                                                                                                                                                                                    StringBuffer resultBuffer = (StringBuffer) method.invoke(
                                                                                                                                                                                                                                                        formatter, 
                                                                                                                                                                                                                                                        sb, 
                                                                                                                                                                                                                                                        10, 
                                                                                                                                                                                                                                                        2, 
                                                                                                                                                                                                                                                        text
                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                    String result = resultBuffer.toString();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertEquals("First\\r\\nSecond", result);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testRenderWrappedTextBlock_WithLeadingAndTrailingNewlines() throws Exception {
                                                                                                                                                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                    formatter.setNewLine("\n");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    StringBuffer sb = new StringBuffer();
                                                                                                                                                                                                                                                    String text = "\nFirst\nSecond\n";
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get the private method using reflection
                                                                                                                                                                                                                                                    Method method = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                                                                                                        "renderWrappedTextBlock", 
                                                                                                                                                                                                                                                        StringBuffer.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        String.class
                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Invoke the method
                                                                                                                                                                                                                                                    StringBuffer resultBuffer = (StringBuffer) method.invoke(formatter, sb, 10, 2, text);
                                                                                                                                                                                                                                                    String result = resultBuffer.toString();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertEquals("\nFirst\nSecond\n", result);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testRenderWrappedTextBlock_WithDifferentWidths() throws Exception {
                                                                                                                                                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                    formatter.setNewLine("\n");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get the private method using reflection
                                                                                                                                                                                                                                                    Method renderWrappedTextBlock = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                                                                                                        "renderWrappedTextBlock", 
                                                                                                                                                                                                                                                        StringBuffer.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        String.class
                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                    renderWrappedTextBlock.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    StringBuffer sb1 = new StringBuffer();
                                                                                                                                                                                                                                                    String text = "This is a long line that should wrap";
                                                                                                                                                                                                                                                    String result1 = ((StringBuffer) renderWrappedTextBlock.invoke(
                                                                                                                                                                                                                                                        formatter, sb1, 10, 2, text)).toString();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    StringBuffer sb2 = new StringBuffer();
                                                                                                                                                                                                                                                    String result2 = ((StringBuffer) renderWrappedTextBlock.invoke(
                                                                                                                                                                                                                                                        formatter, sb2, 20, 2, text)).toString();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertNotEquals(result1, result2);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testRenderWrappedTextBlock_AppendsToExistingBuffer() throws Exception {
                                                                                                                                                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                                                                                                    formatter.setNewLine("\\n");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    StringBuffer sb = new StringBuffer("Prefix ");
                                                                                                                                                                                                                                                    String text = "Line1\\nLine2";
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                                                                                                    Method method = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                                                                                                        "renderWrappedTextBlock", 
                                                                                                                                                                                                                                                        StringBuffer.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        int.class, 
                                                                                                                                                                                                                                                        String.class
                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                                                                                    StringBuffer resultBuffer = (StringBuffer) method.invoke(formatter, sb, 10, 2, text);
                                                                                                                                                                                                                                                    String result = resultBuffer.toString();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertEquals("Prefix Line1\\nLine2", result);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                            public void testPrintWrapped_EmptyText1() {
                                                                                                                                                                                                                                                org.apache.commons.cli.HelpFormatter helpFormatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                helpFormatter.printWrapped(printWriter, 80, "");
                                                                                                                                                                                                                                                printWriter.flush();
                                                                                                                                                                                                                                                org.junit.Assert.assertEquals("", stringWriter.toString());
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testPrintWrapped_TextShorterThanWidth() {
                                                                                                                                                                                                                                                org.apache.commons.cli.HelpFormatter helpFormatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                String text = "This is a short text";
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                helpFormatter.printWrapped(printWriter, 80, text);
                                                                                                                                                                                                                                                printWriter.flush();
                                                                                                                                                                                                                                                assertEquals(text + helpFormatter.getNewLine(), stringWriter.toString());
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testPrintWrapped_TextExactlyWidth() {
                                                                                                                                                                                                                                                org.apache.commons.cli.HelpFormatter helpFormatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                String text = "This text is exactly 20 characters long";
                                                                                                                                                                                                                                                helpFormatter.printWrapped(printWriter, 20, text);
                                                                                                                                                                                                                                                printWriter.flush();
                                                                                                                                                                                                                                                String expected = "This text is exactly" + helpFormatter.getNewLine() + 
                                                                                                                                                                                                                                                                  "20 characters long" + helpFormatter.getNewLine();
                                                                                                                                                                                                                                                org.junit.Assert.assertEquals(expected, stringWriter.toString());
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testPrintWrapped_TextWithNewlines1() {
                                                                                                                                                                                                                                                org.apache.commons.cli.HelpFormatter helpFormatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                String text = "First line\nSecond line\nThird line";
                                                                                                                                                                                                                                                helpFormatter.printWrapped(printWriter, 80, text);
                                                                                                                                                                                                                                                printWriter.flush();
                                                                                                                                                                                                                                                String expected = "First line" + helpFormatter.getNewLine() + 
                                                                                                                                                                                                                                                                  "Second line" + helpFormatter.getNewLine() + 
                                                                                                                                                                                                                                                                  "Third line" + helpFormatter.getNewLine();
                                                                                                                                                                                                                                                org.junit.Assert.assertEquals(expected, stringWriter.toString());
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testPrintWrapped_TextWithWordsLongerThanWidth() {
                                                                                                                                                                                                                                                org.apache.commons.cli.HelpFormatter helpFormatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                String text = "ThisTextIsWayTooLongForTheSpecifiedWidth";
                                                                                                                                                                                                                                                helpFormatter.printWrapped(printWriter, 10, text);
                                                                                                                                                                                                                                                printWriter.flush();
                                                                                                                                                                                                                                                String expected = "ThisTextIs" + helpFormatter.getNewLine() + 
                                                                                                                                                                                                                                                                  "WayTooLong" + helpFormatter.getNewLine() + 
                                                                                                                                                                                                                                                                  "ForTheSpec" + helpFormatter.getNewLine() + 
                                                                                                                                                                                                                                                                  "ifiedWidth" + helpFormatter.getNewLine();
                                                                                                                                                                                                                                                org.junit.Assert.assertEquals(expected, stringWriter.toString());
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testPrintWrapped_WithDefaultWidth() {
                                                                                                                                                                                                                                                org.apache.commons.cli.HelpFormatter helpFormatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                String text = "This text should use the default width for wrapping";
                                                                                                                                                                                                                                                helpFormatter.setWidth(30);
                                                                                                                                                                                                                                                helpFormatter.printWrapped(printWriter, helpFormatter.getWidth(), text);
                                                                                                                                                                                                                                                printWriter.flush();
                                                                                                                                                                                                                                                String expected = "This text should use the" + helpFormatter.getNewLine() + 
                                                                                                                                                                                                                                                                  "default width for wrapping" + helpFormatter.getNewLine();
                                                                                                                                                                                                                                                org.junit.Assert.assertEquals(expected, stringWriter.toString());
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testPrintWrapped_WithDifferentNewLineCharacter() {
                                                                                                                                                                                                                                                org.apache.commons.cli.HelpFormatter helpFormatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                                                                                                                java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                                                                java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                helpFormatter.setNewLine("\r\n");
                                                                                                                                                                                                                                                String text = "Text with custom newline";
                                                                                                                                                                                                                                                helpFormatter.printWrapped(printWriter, 80, text);
                                                                                                                                                                                                                                                printWriter.flush();
                                                                                                                                                                                                                                                assertEquals("Text with custom newline\r\n", stringWriter.toString());
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testRenderWrappedTextBlock_VerifyRenderWrappedTextCalled() throws Exception {
                                                                                                                                                                                                                                                HelpFormatter formatter = spy(new HelpFormatter());
                                                                                                                                                                                                                                                formatter.setNewLine("\n");
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                StringBuffer sb = new StringBuffer();
                                                                                                                                                                                                                                                String text = "Line1\nLine2";
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Get private renderWrappedTextBlock method via reflection
                                                                                                                                                                                                                                                Method renderWrappedTextBlock = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                                                                                                    "renderWrappedTextBlock", StringBuffer.class, int.class, int.class, String.class);
                                                                                                                                                                                                                                                renderWrappedTextBlock.setAccessible(true);
                                                                                                                                                                                                                                                renderWrappedTextBlock.invoke(formatter, sb, 10, 2, text);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Get protected renderWrappedText method via reflection
                                                                                                                                                                                                                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                                                                                                    "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                                                                                                                                                                                                renderWrappedText.setAccessible(true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify calls using reflection
                                                                                                                                                                                                                                                // First call with "Line1"
                                                                                                                                                                                                                                                renderWrappedText.invoke(
                                                                                                                                                                                                                                                    verify(formatter, times(1)), 
                                                                                                                                                                                                                                                    any(StringBuffer.class), 
                                                                                                                                                                                                                                                    eq(10), 
                                                                                                                                                                                                                                                    eq(2), 
                                                                                                                                                                                                                                                    eq("Line1")
                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Second call with "Line2"
                                                                                                                                                                                                                                                renderWrappedText.invoke(
                                                                                                                                                                                                                                                    verify(formatter, times(1)), 
                                                                                                                                                                                                                                                    any(StringBuffer.class), 
                                                                                                                                                                                                                                                    eq(10), 
                                                                                                                                                                                                                                                    eq(2), 
                                                                                                                                                                                                                                                    eq("Line2")
                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                        public void testPrintWrapped_TextLongerThanWidth() {
                                                                                                                                                                                                            // Setup test objects
                                                                                                                                                                                                            HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                                                                            java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test data
                                                                                                                                                                                                            String text = "This is a very long text that should be wrapped to multiple lines when printed";
                                                                                                                                                                                                            helpFormatter.printWrapped(printWriter, 20, text);
                                                                                                                                                                                                            printWriter.flush();
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Expected result
                                                                                                                                                                                                            String expected = "This is a very long" + helpFormatter.getNewLine() + 
                                                                                                                                                                                                                             "text that should be" + helpFormatter.getNewLine() + 
                                                                                                                                                                                                                             "wrapped to multiple" + helpFormatter.getNewLine() + 
                                                                                                                                                                                                                             "lines when printed" + helpFormatter.getNewLine();
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Assertion
                                                                                                                                                                                                            assertEquals(expected, stringWriter.toString());
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                    public void testPrintWrappedWithLargeTextDetectsBufferSizeMutation() {
                                                                                                                                                                        // Create mock PrintWriter
                                                                                                                                                                        PrintWriter pw = mock(PrintWriter.class);
                                                                                                                                                                        
                                                                                                                                                                        // Create a very large text (10KB) to stress the buffer allocation
                                                                                                                                                                        StringBuilder largeTextBuilder = new StringBuilder();
                                                                                                                                                                        for (int i = 0; i < 10000; i++) {
                                                                                                                                                                            largeTextBuilder.append("a");
                                                                                                                                                                        }
                                                                                                                                                                        String largeText = largeTextBuilder.toString();
                                                                                                                                                                        
                                                                                                                                                                        // Create instance and call method
                                                                                                                                                                        HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                        formatter.printWrapped(pw, 80, 0, largeText);
                                                                                                                                                                        
                                                                                                                                                                        // Verify the mock was called (indirectly tests buffer handling)
                                                                                                                                                                        verify(pw, atLeastOnce()).write(anyString());
                                                                                                                                                                        
                                                                                                                                                                        // The test will pass for both original and mutant,
                                                                                                                                                                        // but performance profiling would show the mutant is less efficient
                                                                                                                                                                        // To make this test fail for the mutant, we could add timing constraints
                                                                                                                                                                        // or memory usage checks if we had access to those metrics
                                                                                                                                                                    }

    @Test
                                                                                                                                                                public void testPrintWrappedStringBufferCapacity() {
                                                                                                                                                                    // Create test objects
                                                                                                                                                                    PrintWriter pw = mock(PrintWriter.class);
                                                                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                    int width = 80;
                                                                                                                                                                    int nextLineTabStop = 4;
                                                                                                                                                                    
                                                                                                                                                                    // Create a long text (longer than default StringBuffer capacity of 16)
                                                                                                                                                                    String longText = "This is a very long text that exceeds the default StringBuffer capacity";
                                                                                                                                                                    
                                                                                                                                                                    // Call the method
                                                                                                                                                                    formatter.printWrapped(pw, width, nextLineTabStop, longText);
                                                                                                                                                                    
                                                                                                                                                                    // Verify the PrintWriter was called with the correct string
                                                                                                                                                                    verify(pw).println(longText);
                                                                                                                                                                    
                                                                                                                                                                    // The key assertion - verify the StringBuffer was created with proper capacity
                                                                                                                                                                    // Since we can't directly observe the StringBuffer creation, we need to test the behavior
                                                                                                                                                                    // by checking if the method can handle large strings efficiently
                                                                                                                                                                    // We'll test with an extremely large string to potentially expose performance issues
                                                                                                                                                                    String veryLongText = new String(new char[10000]).replace('\0', 'x');
                                                                                                                                                                    long startTime = System.nanoTime();
                                                                                                                                                                    formatter.printWrapped(pw, width, nextLineTabStop, veryLongText);
                                                                                                                                                                    long duration = System.nanoTime() - startTime;
                                                                                                                                                                    
                                                                                                                                                                    // If the StringBuffer was created with proper initial capacity, the operation should be faster
                                                                                                                                                                    // than if it had to resize multiple times
                                                                                                                                                                    assertTrue("Operation took too long, possible StringBuffer resizing", duration < 1000000);
                                                                                                                                                                    
                                                                                                                                                                    // Alternative approach: use reflection to verify the StringBuffer capacity
                                                                                                                                                                    // This is more direct but uses reflection which isn't ideal
                                                                                                                                                                    try {
                                                                                                                                                                        Method method = HelpFormatter.class.getDeclaredMethod("renderWrappedTextBlock", 
                                                                                                                                                                            StringBuffer.class, int.class, int.class, String.class);
                                                                                                                                                                        method.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        StringBuffer sb = new StringBuffer();
                                                                                                                                                                        method.invoke(formatter, sb, width, nextLineTabStop, longText);
                                                                                                                                                                        
                                                                                                                                                                        // The original implementation would have created buffer with text.length() capacity
                                                                                                                                                                        // The mutant would use default capacity (16) and potentially resize
                                                                                                                                                                        // We can't directly test this, but we can verify the final capacity is at least text length
                                                                                                                                                                        assertTrue(sb.capacity() >= longText.length());
                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                    }
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testPrintWrappedWithLargeTextShouldNotCauseBufferOverflow() {
                                                                                                                                                                    // Arrange
                                                                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                                    PrintWriter pw = mock(PrintWriter.class);
                                                                                                                                                                    int width = 80;
                                                                                                                                                                    int nextLineTabStop = 4;
                                                                                                                                                                    
                                                                                                                                                                    // Create a very large text (bigger than default StringBuffer capacity)
                                                                                                                                                                    StringBuilder largeTextBuilder = new StringBuilder();
                                                                                                                                                                    for (int i = 0; i < 10000; i++) {
                                                                                                                                                                        largeTextBuilder.append("This is a long line of text that should test buffer capacity. ");
                                                                                                                                                                    }
                                                                                                                                                                    String largeText = largeTextBuilder.toString();
                                                                                                                                                                    
                                                                                                                                                                    // Act
                                                                                                                                                                    formatter.printWrapped(pw, width, nextLineTabStop, largeText);
                                                                                                                                                                    
                                                                                                                                                                    // Assert
                                                                                                                                                                    // Verify the PrintWriter was called with the complete text
                                                                                                                                                                    verify(pw).println(contains(largeText.substring(0, 100))); // Check first part
                                                                                                                                                                    verify(pw).println(contains(largeText.substring(largeText.length() - 100))); // Check last part
                                                                                                                                                                }

    @Test
                                                                                                                                                        public void testPrintWrappedWithLargeString() {
                                                                                                                                                            // Create test objects
                                                                                                                                                            org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                            java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                                                                            
                                                                                                                                                            // Create a very long string (10000 characters)
                                                                                                                                                            StringBuilder longTextBuilder = new StringBuilder();
                                                                                                                                                            for (int i = 0; i < 1000; i++) {
                                                                                                                                                                longTextBuilder.append("123456789 ");
                                                                                                                                                            }
                                                                                                                                                            String longText = longTextBuilder.toString();
                                                                                                                                                            
                                                                                                                                                            // Time the operation to detect performance impact
                                                                                                                                                            long startTime = System.nanoTime();
                                                                                                                                                            formatter.printWrapped(pw, 80, 0, longText);
                                                                                                                                                            long duration = System.nanoTime() - startTime;
                                                                                                                                                            
                                                                                                                                                            // Verify the output contains our text
                                                                                                                                                            String result = stringWriter.toString();
                                                                                                                                                            assertTrue(result.contains("123456789"));
                                                                                                                                                            
                                                                                                                                                            // If the StringBuffer was initialized with 0 capacity, this operation 
                                                                                                                                                            // would take significantly longer due to repeated resizing
                                                                                                                                                            // We set a reasonable threshold (10ms) that would be exceeded if resizing occurs
                                                                                                                                                            assertTrue("Operation took too long, possible StringBuffer resizing", 
                                                                                                                                                                      duration < 10_000_000); // 10ms in nanoseconds
                                                                                                                                                            
                                                                                                                                                            pw.close();
                                                                                                                                                        }

    @Test
                                                                                                                                                public void testPrintWrappedDetectsStartPosMutation() {
                                                                                                                                                    // Setup
                                                                                                                                                    org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                    java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                                                                    
                                                                                                                                                    // Test case designed to detect the startPos mutation
                                                                                                                                                    // The text starts with a space and has a word that fits exactly at width=5
                                                                                                                                                    String text = " hello world";
                                                                                                                                                    int width = 5;
                                                                                                                                                    
                                                                                                                                                    // Expected behavior (original): 
                                                                                                                                                    // Should wrap after first space (position 0) -> "\nhello world"
                                                                                                                                                    // Mutated behavior:
                                                                                                                                                    // Will start looking from position 1, might not wrap properly
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    formatter.printWrapped(pw, width, text);
                                                                                                                                                    pw.flush();
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    String result = stringWriter.toString();
                                                                                                                                                    // Original would wrap immediately at position 0 due to leading space
                                                                                                                                                    // Mutant would skip position 0 and might not wrap properly
                                                                                                                                                    assertTrue("Should handle leading space correctly", 
                                                                                                                                                              result.contains("\n") || result.trim().length() <= width);
                                                                                                                                                    
                                                                                                                                                    // More precise verification
                                                                                                                                                    String[] lines = result.split("\n");
                                                                                                                                                    assertTrue("Should wrap text into multiple lines", lines.length > 1);
                                                                                                                                                    assertTrue("First line should be empty due to leading space", 
                                                                                                                                                              lines[0].trim().isEmpty());
                                                                                                                                                }

    @Test
                                                                                                                                                public void testPrintWrappedDetectsFindWrapPosMutation() {
                                                                                                                                                    // Setup
                                                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                                    java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                                                                    
                                                                                                                                                    // Test case designed to detect startPos mutation
                                                                                                                                                    // Text where first character is a space and wrapping would differ between startPos=0 and startPos=1
                                                                                                                                                    String text = " abcdefghij"; // starts with space, total length 11
                                                                                                                                                    int width = 5; // Wrap at 5 characters
                                                                                                                                                    
                                                                                                                                                    // Expected behavior with original code (startPos=0):
                                                                                                                                                    // Would wrap at first space (position 0) resulting in empty first line
                                                                                                                                                    // Mutated behavior (startPos=1):
                                                                                                                                                    // Would skip first space and wrap at position 5
                                                                                                                                                    
                                                                                                                                                    // Execute
                                                                                                                                                    formatter.printWrapped(pw, width, 0, text);
                                                                                                                                                    pw.flush();
                                                                                                                                                    String result = stringWriter.toString();
                                                                                                                                                    
                                                                                                                                                    // Verify - original would split at position 0, resulting in empty first line
                                                                                                                                                    // The mutation would cause different wrapping
                                                                                                                                                    String expected = "\nabcde\nfghij"; // Expected with startPos=0
                                                                                                                                                    assertEquals("Wrapping should start from position 0", expected, result);
                                                                                                                                                    
                                                                                                                                                    // Additional check for line lengths
                                                                                                                                                    String[] lines = result.split("\n");
                                                                                                                                                    assertTrue("First line should be empty due to space at position 0", 
                                                                                                                                                              lines.length > 0 && lines[0].isEmpty());
                                                                                                                                                    assertTrue("Second line should not exceed width", 
                                                                                                                                                              lines.length > 1 && lines[1].length() <= width);
                                                                                                                                                }

    @Test
                                                                                                                                            public void testPrintWrappedDetectsWidthMutation() {
                                                                                                                                                // Setup
                                                                                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                                                                                PrintWriter pw = mock(PrintWriter.class);
                                                                                                                                                StringBuffer capturedOutput = new StringBuffer();
                                                                                                                                                
                                                                                                                                                // Mock the PrintWriter to capture output
                                                                                                                                                doAnswer(invocation -> {
                                                                                                                                                    capturedOutput.append(invocation.getArgument(0).toString());
                                                                                                                                                    return null;
                                                                                                                                                }).when(pw).println(anyString());
                                                                                                                                                
                                                                                                                                                // Test with text that would wrap differently at width vs width+1
                                                                                                                                                int width = 5;
                                                                                                                                                String text = "12345 67890"; // Should wrap after 5 chars (original) or 6 chars (mutant)
                                                                                                                                                
                                                                                                                                                // Execute
                                                                                                                                                formatter.printWrapped(pw, width, 0, text);
                                                                                                                                                
                                                                                                                                                // Verify - original would wrap after "12345", mutant would keep "12345 " on first line
                                                                                                                                                String firstLine = capturedOutput.toString().split(System.lineSeparator())[0];
                                                                                                                                                assertEquals("12345", firstLine); // Original behavior would pass, mutant would fail
                                                                                                                                                
                                                                                                                                                // Additional verification for complete output
                                                                                                                                                String expected = "12345" + System.lineSeparator() + "67890";
                                                                                                                                                assertEquals(expected, capturedOutput.toString());
                                                                                                                                            }

    @Test
                                                                                                                                        public void testPrintWrappedDetectsWidthMutation1() {
                                                                                                                                            // Setup
                                                                                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                            java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                                                                            org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                            
                                                                                                                                            // Create a string that has a space exactly at width+1 position
                                                                                                                                            int width = 10;
                                                                                                                                            String text = "123456789 123456789"; // Space at position 10 (0-based would be 9)
                                                                                                                                            
                                                                                                                                            // Execute
                                                                                                                                            formatter.printWrapped(printWriter, width, 0, text);
                                                                                                                                            printWriter.flush();
                                                                                                                                            
                                                                                                                                            // Verify
                                                                                                                                            String result = stringWriter.toString();
                                                                                                                                            String[] lines = result.split(System.lineSeparator());
                                                                                                                                            
                                                                                                                                            // Original would break at width (10), so first line should be "123456789"
                                                                                                                                            // Mutant would break at width+1 (11), so first line would be "123456789 1"
                                                                                                                                            assertEquals("First line should break at exact width", 
                                                                                                                                                         "123456789", 
                                                                                                                                                         lines[0].trim());
                                                                                                                                        }

    @Test
                                                                                                                                public void testPrintWrappedWithZeroPosShouldNotTriggerSpecialCase() {
                                                                                                                                    // Setup
                                                                                                                                    org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                    java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                                                    String text = "This is a test string that should wrap";
                                                                                                                                    int width = 10;
                                                                                                                                    int nextLineTabStop = 0; // This is the critical value
                                                                                                                                    
                                                                                                                                    // Execute
                                                                                                                                    formatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                                                    pw.flush();
                                                                                                                                    String result = stringWriter.toString();
                                                                                                                                    
                                                                                                                                    // Verify - in original, pos=0 should NOT trigger special case
                                                                                                                                    // If mutant is present (pos <= 0), it would trigger special case
                                                                                                                                    // So we check that the output is properly wrapped (not all on one line)
                                                                                                                                    String[] lines = result.split(System.lineSeparator());
                                                                                                                                    assertTrue("Output should be wrapped to multiple lines when pos=0", 
                                                                                                                                              lines.length > 1);
                                                                                                                                    
                                                                                                                                    // Additional verification that first line is not empty
                                                                                                                                    assertFalse("First line should not be empty", 
                                                                                                                                               lines[0].trim().isEmpty());
                                                                                                                                }

    @Test
                                                                                                                                public void testPrintWrappedWithNegativeOnePosShouldTriggerSpecialCase() {
                                                                                                                                    // Setup
                                                                                                                                    org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                    java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                                                    String text = "This is a test string that should wrap";
                                                                                                                                    int width = 10;
                                                                                                                                    int nextLineTabStop = -1; // Should trigger special case in both
                                                                                                                                    
                                                                                                                                    // Execute
                                                                                                                                    formatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                                                    pw.flush();
                                                                                                                                    String result = stringWriter.toString();
                                                                                                                                    
                                                                                                                                    // Verify - both original and mutant should trigger special case
                                                                                                                                    String[] lines = result.split(System.lineSeparator());
                                                                                                                                    assertTrue("Output should be wrapped to multiple lines when pos=-1", 
                                                                                                                                              lines.length > 1);
                                                                                                                                }

    @Test
                                                                                                                                public void testPrintWrapped_DetectsPosZeroMutation() {
                                                                                                                                    // Setup
                                                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                                    java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                                                    org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                                    
                                                                                                                                    // Test with text that would cause wrap position calculation to return 0
                                                                                                                                    // This could happen with very short text and specific width
                                                                                                                                    String text = "a b"; // Short text that might wrap at position 0
                                                                                                                                    int width = 1; // Very small width to force early wrapping
                                                                                                                                    int nextLineTabStop = 0;
                                                                                                                                    
                                                                                                                                    // Execute
                                                                                                                                    formatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                                                    pw.flush();
                                                                                                                                    
                                                                                                                                    // Verify the output doesn't contain unexpected behavior
                                                                                                                                    // The exact assertion depends on what correct behavior should be,
                                                                                                                                    // but we know mutation would treat pos=0 differently
                                                                                                                                    String result = stringWriter.toString();
                                                                                                                                    assertFalse("Output should not be empty", result.isEmpty());
                                                                                                                                    
                                                                                                                                    // More specific assertion based on expected behavior:
                                                                                                                                    // Original code would continue processing when pos=0,
                                                                                                                                    // while mutated code might treat it as special case
                                                                                                                                    assertTrue("Output should contain the input text", 
                                                                                                                                              result.contains(text.trim()));
                                                                                                                                }

    @Test
                                                                                                                            public void testPrintWrappedTrimsTrailingWhitespace() {
                                                                                                                                // Setup
                                                                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                                                                PrintWriter pw = mock(PrintWriter.class);
                                                                                                                                int width = 80;
                                                                                                                                int nextLineTabStop = 0;
                                                                                                                                String textWithTrailingSpaces = "Test text   "; // Text with 3 trailing spaces
                                                                                                                                
                                                                                                                                // Capture the output
                                                                                                                                final String[] capturedOutput = new String[1];
                                                                                                                                doAnswer(invocation -> {
                                                                                                                                    capturedOutput[0] = invocation.getArgument(0).toString();
                                                                                                                                    return null;
                                                                                                                                }).when(pw).println(anyString());
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                                formatter.printWrapped(pw, width, nextLineTabStop, textWithTrailingSpaces);
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                                // Original behavior should trim trailing spaces, so output should equal text without trailing spaces
                                                                                                                                assertEquals("Test text", capturedOutput[0]);
                                                                                                                                
                                                                                                                                // Additional verification that the output doesn't end with whitespace
                                                                                                                                assertFalse(capturedOutput[0].matches(".*\\s+$"));
                                                                                                                            }

    @Test
                                                                                                                        public void testPrintWrappedTrimsTrailingWhitespace1() {
                                                                                                                            // Setup
                                                                                                                            HelpFormatter formatter = new HelpFormatter();
                                                                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                            java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                                                            
                                                                                                                            // Input with trailing whitespace
                                                                                                                            String inputText = "Test text with trailing whitespace    ";
                                                                                                                            String expectedOutput = "Test text with trailing whitespace"; // After trimming
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            formatter.printWrapped(printWriter, 80, 0, inputText);
                                                                                                                            printWriter.flush();
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            String actualOutput = stringWriter.toString().trim(); // trim to handle any newlines
                                                                                                                            assertEquals("Trailing whitespace should be trimmed", 
                                                                                                                                         expectedOutput, 
                                                                                                                                         actualOutput);
                                                                                                                            
                                                                                                                            // Additional verification that no whitespace remains
                                                                                                                            assertFalse("Output should not end with whitespace",
                                                                                                                                       actualOutput.matches(".*\\s+$"));
                                                                                                                        }

    @Test
                                                                                                                    public void testPrintWrapped_DetectsNextLineTabStopMutation() throws Exception {
                                                                                                                        // Setup
                                                                                                                        HelpFormatter formatter = new HelpFormatter();
                                                                                                                        PrintWriter pw = mock(PrintWriter.class);
                                                                                                                        int width = 10;  // Small width to force wrapping
                                                                                                                        int nextLineTabStop = 1;  // Original value that should be used
                                                                                                                        String text = "This is a long text that should wrap";
                                                                                                                        
                                                                                                                        // Expected output would have continuation lines indented by 1 space
                                                                                                                        String expectedOutput = "This is a\n long text\n that\n should\n wrap";
                                                                                                                        
                                                                                                                        // Capture the actual output
                                                                                                                        final String[] actualOutput = new String[1];
                                                                                                                        doAnswer(invocation -> {
                                                                                                                            actualOutput[0] = invocation.getArgument(0).toString();
                                                                                                                            return null;
                                                                                                                        }).when(pw).println(anyString());
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        formatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        // Check that continuation lines are properly indented
                                                                                                                        String[] lines = actualOutput[0].split("\n");
                                                                                                                        for (int i = 1; i < lines.length; i++) {
                                                                                                                            assertTrue("Continuation line should be indented", 
                                                                                                                                       lines[i].startsWith(" "));
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Also verify the complete output matches expected formatting
                                                                                                                        assertEquals("Output formatting is incorrect", 
                                                                                                                                    expectedOutput, 
                                                                                                                                    actualOutput[0]);
                                                                                                                    }

    @Test
                                                                                                                public void testPrintWrapped_ShouldIndentContinuationLines() {
                                                                                                                    // Imports would normally be at class level:
                                                                                                                    // import java.io.StringWriter;
                                                                                                                    // import java.io.PrintWriter;
                                                                                                                    
                                                                                                                    // Setup
                                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                                    java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                                    
                                                                                                                    // Test input - text that will wrap at width 10
                                                                                                                    String text = "This is a long text that should wrap properly";
                                                                                                                    int width = 10;
                                                                                                                    int nextLineTabStop = 1; // This is what we're testing
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    formatter.printWrapped(printWriter, width, nextLineTabStop, text);
                                                                                                                    printWriter.flush();
                                                                                                                    
                                                                                                                    // Verify
                                                                                                                    String result = stringWriter.toString();
                                                                                                                    String[] lines = result.split(System.lineSeparator());
                                                                                                                    
                                                                                                                    // First line shouldn't be indented
                                                                                                                    assertTrue(lines[0].startsWith("This is a"));
                                                                                                                    
                                                                                                                    // Continuation lines should be indented by 1 space
                                                                                                                    for (int i = 1; i < lines.length; i++) {
                                                                                                                        assertTrue("Continuation line should be indented", 
                                                                                                                                  lines[i].startsWith(" "));
                                                                                                                        assertEquals("Indentation should be 1 space", 
                                                                                                                                    1, lines[i].length() - lines[i].trim().length());
                                                                                                                    }
                                                                                                                    
                                                                                                                    // The mutant would fail this test because it wouldn't indent continuation lines
                                                                                                                }

    @Test
                                                                                                    public void testPrintWrappedDetectsPosCheckMutant() {
                                                                                                        // Setup
                                                                                                        java.io.StringWriter sw = new java.io.StringWriter();
                                                                                                        java.io.PrintWriter pw = new java.io.PrintWriter(sw);
                                                                                                        HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                        int width = 10;
                                                                                                        int nextLineTabStop = 2;
                                                                                                        String text = "This is a long text that needs to be wrapped properly";
                                                                                                        
                                                                                                        // Execute
                                                                                                        helpFormatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                        pw.flush();
                                                                                                        
                                                                                                        // Verify
                                                                                                        String result = sw.toString();
                                                                                                        // Check that the text was properly wrapped (would fail if mutation affected wrapping)
                                                                                                        assertTrue(result.contains("This is a"));
                                                                                                        assertTrue(result.contains("long text"));
                                                                                                        assertTrue(result.contains("that needs"));
                                                                                                        assertTrue(result.contains("to be"));
                                                                                                        assertTrue(result.contains("wrapped"));
                                                                                                        assertTrue(result.contains("properly"));
                                                                                                        
                                                                                                        // Test with edge case where no wrapping should occur
                                                                                                        sw.getBuffer().setLength(0);
                                                                                                        String shortText = "short";
                                                                                                        helpFormatter.printWrapped(pw, width, nextLineTabStop, shortText);
                                                                                                        pw.flush();
                                                                                                        assertEquals("short", sw.toString().trim());
                                                                                                        
                                                                                                        // Test with empty string
                                                                                                        sw.getBuffer().setLength(0);
                                                                                                        helpFormatter.printWrapped(pw, width, nextLineTabStop, "");
                                                                                                        pw.flush();
                                                                                                        assertEquals("", sw.toString().trim());
                                                                                                    }

    @Test
                                                                                                public void testPrintWrappedWithNegativeWrapPos() throws Exception {
                                                                                                    // Setup
                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                                    java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                                    String text = "test text";
                                                                                                    int width = 10;
                                                                                                    int nextLineTabStop = 0;
                                                                                                    
                                                                                                    // Use reflection to access protected findWrapPos method
                                                                                                    java.lang.reflect.Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Create a spy that will return -2 for findWrapPos
                                                                                                    HelpFormatter spyFormatter = spy(formatter);
                                                                                                    when(findWrapPosMethod.invoke(spyFormatter, eq(text), eq(width), anyInt()))
                                                                                                        .thenReturn(-2); // Simulate a case where findWrapPos returns -2
                                                                                                    
                                                                                                    // Execute
                                                                                                    spyFormatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                                    
                                                                                                    // Verify behavior - original would not handle -2 specially, mutant would
                                                                                                    // If the mutant exists (pos < 0), it would trigger different wrapping behavior
                                                                                                    // We verify the interaction with PrintWriter would differ
                                                                                                    verify(pw, atLeastOnce()).write(anyString());
                                                                                                    
                                                                                                    // Additional verification could check the exact output if we knew expected behavior
                                                                                                    // Since we don't have the exact implementation, we verify at least some output was written
                                                                                                    // The key point is that with pos=-2, original and mutant behave differently
                                                                                                }

    @Test
                                                                                                public void testPrintWrapped_TextLengthExactlyEqualsWidth_ShouldNotWrap() {
                                                                                                    // Setup
                                                                                                    PrintWriter pw = mock(PrintWriter.class);
                                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                                    int width = 10;
                                                                                                    String text = "1234567890"; // Exactly 10 characters
                                                                                                    
                                                                                                    // Exercise
                                                                                                    formatter.printWrapped(pw, width, 0, text);
                                                                                                    
                                                                                                    // Verify
                                                                                                    // Original behavior: should write text as-is without splitting
                                                                                                    // Mutant behavior: would try to wrap even though length equals width
                                                                                                    verify(pw).write(text, 0, text.length());
                                                                                                    verify(pw, never()).write(anyString(), anyInt(), anyInt()); // No additional writes
                                                                                                }

    @Test
                                                                                        public void testPrintWrapped_ExactWidthText_ShouldNotWrap() {
                                                                                            // Setup
                                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                            java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                                            org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                            
                                                                                            // Test with text length exactly equal to width
                                                                                            int width = 10;
                                                                                            String text = "1234567890"; // exactly 10 characters
                                                                                            
                                                                                            // Execute
                                                                                            formatter.printWrapped(pw, width, 0, text);
                                                                                            pw.flush();
                                                                                            
                                                                                            // Verify - original would output same string, mutant would try to wrap
                                                                                            String output = stringWriter.toString();
                                                                                            assertEquals("Text with length equal to width should not be wrapped", 
                                                                                                        text + System.lineSeparator(), output);
                                                                                        }

    @Test
                                                                                        public void testPrintWrappedDetectsWidthMutation2() {
                                                                                            // Setup
                                                                                            HelpFormatter formatter = new HelpFormatter();
                                                                                            PrintWriter pw = mock(PrintWriter.class);
                                                                                            int width = 10;
                                                                                            int nextLineTabStop = 2;
                                                                                            
                                                                                            // Test case designed to detect the width-1 mutation
                                                                                            // The text is exactly width+1 characters long to force a wrap
                                                                                            String text = "1234567890a"; // 11 characters
                                                                                            
                                                                                            // Expected behavior: should wrap after 10th character (position 10)
                                                                                            // Mutated behavior: would wrap after 9th character (position 9)
                                                                                            String expectedOutput = "1234567890\na"; // Correct wrap
                                                                                            String mutatedOutput = "123456789\na0"; // Wrong wrap from mutation
                                                                                            
                                                                                            // Capture the actual output
                                                                                            final String[] actualOutput = new String[1];
                                                                                            doAnswer(invocation -> {
                                                                                                actualOutput[0] = invocation.getArgument(0).toString();
                                                                                                return null;
                                                                                            }).when(pw).println(anyString());
                                                                                            
                                                                                            // Execute
                                                                                            formatter.printWrapped(pw, width, nextLineTabStop, text);
                                                                                            
                                                                                            // Verify
                                                                                            // This assertion will fail if the mutation is present
                                                                                            assertEquals("Text should wrap at exact width position", 
                                                                                                        expectedOutput, actualOutput[0]);
                                                                                            
                                                                                            // Additional check to ensure we're testing the right thing
                                                                                            assertNotEquals("Test should detect width-1 mutation", 
                                                                                                           mutatedOutput, actualOutput[0]);
                                                                                        }

    @Test
                                                                                public void testPrintWrapped_ExactWidthWordShouldNotWrap() {
                                                                                    // Setup
                                                                                    org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                    java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                    
                                                                                    // Test with a word that exactly matches the width
                                                                                    int width = 5;
                                                                                    String testText = "12345"; // Exactly 5 characters
                                                                                    
                                                                                    // Execute
                                                                                    formatter.printWrapped(printWriter, width, 0, testText);
                                                                                    printWriter.flush();
                                                                                    
                                                                                    // Verify - should not wrap since word exactly fits width
                                                                                    String result = stringWriter.toString();
                                                                                    org.junit.Assert.assertEquals("The text should not be wrapped when it exactly matches the width", 
                                                                                                     "12345", result.trim());
                                                                                }

    @Test
                                                                                public void testPrintWrapped_WordLongerThanWidthShouldWrap() {
                                                                                    // Setup
                                                                                    // import java.io.StringWriter;  // This would be at the top of the file
                                                                                    // import java.io.PrintWriter;   // This would be at the top of the file
                                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                    java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                                    
                                                                                    // Test with a word longer than width
                                                                                    int width = 5;
                                                                                    String testText = "123456"; // 6 characters
                                                                                    
                                                                                    // Execute
                                                                                    formatter.printWrapped(printWriter, width, 0, testText);
                                                                                    printWriter.flush();
                                                                                    
                                                                                    // Verify - should wrap after 5 characters
                                                                                    String result = stringWriter.toString();
                                                                                    assertEquals("The text should be wrapped at the exact width", 
                                                                                                "12345\n6", result.trim());
                                                                                }

    @Test
                                                                        public void testPrintWrapped_DetectsRtrimMutation() {
                                                                            // Setup
                                                                            HelpFormatter formatter = new HelpFormatter();
                                                                            formatter.setWidth(10); // Force wrapping at 10 characters
                                                                            formatter.setNewLine("\n"); // Set predictable newline
                                                                            
                                                                            // Create input with trailing whitespace that will be wrapped
                                                                            String inputText = "Hello     World"; // 5 spaces after "Hello"
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                            
                                                                            // Expected behavior: trailing spaces should be trimmed in the wrapped line
                                                                            String expectedOutput = "Hello\nWorld\n"; // spaces after Hello should be trimmed
                                                                            
                                                                            // Execute
                                                                            formatter.printWrapped(printWriter, 10, 0, inputText);
                                                                            printWriter.flush();
                                                                            
                                                                            // Verify
                                                                            assertEquals("Wrapped output should have trailing whitespace trimmed", 
                                                                                         expectedOutput, 
                                                                                         stringWriter.toString());
                                                                            
                                                                            // The mutant would produce "Hello     \nWorld\n" instead
                                                                            // This assertion will fail for the mutant but pass for original
                                                                            assertFalse("Output should not contain trailing spaces after wrapped words",
                                                                                       stringWriter.toString().contains("     \n"));
                                                                        }

    @Test
                                                                    public void testPrintWrappedTrimsTrailingWhitespace2() {
                                                                        // Setup
                                                                        HelpFormatter formatter = new HelpFormatter();
                                                                        formatter.setNewLine("\n"); // Use public method instead of direct field access
                                                                        
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                                                                        
                                                                        // Input with trailing whitespace that should be trimmed
                                                                        String text = "This line has trailing spaces    ";
                                                                        int width = text.length(); // Wide enough to fit the whole line
                                                                        
                                                                        // Execute
                                                                        formatter.printWrapped(pw, width, text);
                                                                        pw.flush();
                                                                        
                                                                        // Verify
                                                                        String result = stringWriter.toString();
                                                                        // Original behavior would trim trailing spaces before newline
                                                                        String expected = "This line has trailing spaces\n";
                                                                        assertEquals("Trailing whitespace should be trimmed", expected, result);
                                                                        
                                                                        // Additional check - verify no whitespace before newline
                                                                        assertTrue("No whitespace before newline", 
                                                                            result.substring(0, result.length()-1).trim().length() == 
                                                                            result.substring(0, result.length()-1).length());
                                                                    }

    @Test
                                                            public void testPrintWrappedPreservesWhitespace() {
                                                                // Setup
                                                                org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                                                                
                                                                // Text with leading and trailing whitespace
                                                                String textWithWhitespace = "  This text has spaces  ";
                                                                int width = 80;
                                                                int nextLineTabStop = 0;
                                                                
                                                                // Execute
                                                                formatter.printWrapped(printWriter, width, nextLineTabStop, textWithWhitespace);
                                                                printWriter.flush();
                                                                
                                                                // Verify
                                                                String result = stringWriter.toString();
                                                                // Original should preserve spaces, mutant would trim
                                                                assertTrue("Leading whitespace not preserved", result.startsWith("  "));
                                                                assertTrue("Trailing whitespace not preserved", result.trim().endsWith("spaces  "));
                                                                
                                                                // Also verify the core content is present
                                                                assertTrue("Core content missing", result.contains("This text has spaces"));
                                                            }

    @Test
                                public void testPrintWrappedPreservesWhitespace1() {
                                    // Setup
                                    org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                    java.io.PrintWriter pw = new java.io.PrintWriter(System.out); // Replaced mock with real PrintWriter
                                    int width = 80;
                                    int nextLineTabStop = 0;
                                    String textWithWhitespace = "   This text has spaces   ";
                                    
                                    // Create a StringWriter to capture output
                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                    pw = new java.io.PrintWriter(stringWriter);
                                    
                                    // Test
                                    formatter.printWrapped(pw, width, nextLineTabStop, textWithWhitespace);
                                    pw.flush();
                                    
                                    // Get the printed text
                                    String printedText = stringWriter.toString();
                                    
                                    // Assert that leading/trailing spaces are preserved
                                    assertTrue(printedText.startsWith("   "));
                                    assertTrue(printedText.endsWith("spaces   "));
                                    
                                    // Additional check for exact content preservation
                                    assertEquals("   This text has spaces   ", printedText.trim());
                                }

    @Test
                        public void testPrintWrapped_ShouldNotThrowNullPointerException() {
                            // Setup
                            org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                            java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                            int width = 20;
                            int nextLineTabStop = 0;
                            
                            // Test with empty string
                            formatter.printWrapped(pw, width, nextLineTabStop, "");
                            assertNotNull(stringWriter.toString());
                            
                            // Test with short text that doesn't need wrapping
                            stringWriter.getBuffer().setLength(0); // clear buffer
                            formatter.printWrapped(pw, width, nextLineTabStop, "short text");
                            assertNotNull(stringWriter.toString());
                            assertTrue(stringWriter.toString().contains("short text"));
                            
                            // Test with long text that needs wrapping
                            stringWriter.getBuffer().setLength(0);
                            String longText = "This is a very long text that should be wrapped when printed";
                            formatter.printWrapped(pw, width, nextLineTabStop, longText);
                            String result = stringWriter.toString();
                            assertNotNull(result);
                            assertTrue(result.contains("This is a very"));
                            assertTrue(result.contains("long text that"));
                            assertTrue(result.contains("should be wrapped"));
                            
                            // Verify no NullPointerException occurred
                            pw.flush();
                        }

    @Test
                        public void testPrintWrappedWithEmptyString() {
                            // Setup
                            org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                            java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                            int width = 80;
                            int nextLineTabStop = 4;
                            String emptyText = "";
                            
                            // Execute
                            formatter.printWrapped(pw, width, nextLineTabStop, emptyText);
                            pw.flush();
                            
                            // Verify
                            String result = stringWriter.toString();
                            assertEquals("", result);  // Should handle empty string without NPE
                        }

    @Test
                        public void testPrintWrappedWithNullString() {
                            // Setup
                            org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                            java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
                            int width = 80;
                            int nextLineTabStop = 4;
                            String nullText = null;
                            
                            // Execute
                            try {
                                formatter.printWrapped(pw, width, nextLineTabStop, nullText);
                                pw.flush();
                                fail("Expected NullPointerException");
                            } catch (NullPointerException e) {
                                // Expected behavior for null input
                            }
                        }

    @Test
                    public void testPrintWrapped_ShouldUseConfiguredNewLine() {
                        // Setup
                        HelpFormatter formatter = new HelpFormatter();
                        formatter.setNewLine("\r\n");  // Set custom newline
                        
                        PrintWriter pw = mock(PrintWriter.class);
                        StringBuffer capturedOutput = new StringBuffer();
                        
                        // Mock PrintWriter to capture output
                        doAnswer(invocation -> {
                            capturedOutput.append(invocation.getArgument(0).toString());
                            return null;
                        }).when(pw).println(anyString());
                        
                        // Test data
                        int width = 80;
                        int nextLineTabStop = 4;
                        String text = "This is a test text that should wrap";
                        
                        // Execute
                        formatter.printWrapped(pw, width, nextLineTabStop, text);
                        
                        // Verify
                        // Check that the output contains the custom newline, not just "\n"
                        assertTrue("Output should contain configured newline", 
                                   capturedOutput.toString().contains("\r\n"));
                        assertFalse("Output should not contain plain newline", 
                                    capturedOutput.toString().contains("\n") && 
                                    !capturedOutput.toString().contains("\r\n"));
                    }

    @Test
                public void testPrintWrapped_ShouldUseConfiguredNewLine1() {
                    // Setup
                    HelpFormatter formatter = new HelpFormatter();
                    formatter.setNewLine("CUSTOM_NEWLINE"); // Set custom newline
                    
                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                    java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
                    
                    String text = "This is a long text that should be wrapped";
                    int width = 10;
                    int nextLineTabStop = 2;
                    
                    // Execute
                    formatter.printWrapped(printWriter, width, nextLineTabStop, text);
                    printWriter.flush();
                    
                    // Verify
                    String result = stringWriter.toString();
                    assertTrue("Output should contain custom newline", 
                              result.contains("CUSTOM_NEWLINE"));
                    
                    // Additional verification that it's not using hardcoded "\n"
                    assertFalse("Output should not contain standard newline", 
                               result.contains("\n"));
                }

    @Test
        public void testPrintWrapped_DetectsNextLineTabStopMutation1() {
            // Setup
            HelpFormatter formatter = new HelpFormatter();
            java.io.StringWriter stringWriter = new java.io.StringWriter();
            java.io.PrintWriter pw = new java.io.PrintWriter(stringWriter);
            
            // Input parameters
            int width = 10;
            int nextLineTabStop = 0; // Will be mutated to width if mutant is present
            String text = "This is a long text that should wrap multiple times";
            
            // Expected: Wrapped text with 1 space indent for continuation lines
            String expected = "This is a\n long text\n that\n should\n wrap\n multiple\n times";
            
            // Execute
            formatter.printWrapped(pw, width, nextLineTabStop, text);
            pw.flush();
            
            // Verify
            String actual = stringWriter.toString().trim();
            String[] lines = actual.split("\n");
            
            // Check first line is not indented
            assertEquals("This is a", lines[0].trim());
            
            // Check subsequent lines are indented by 1 space (not full width)
            for (int i = 1; i < lines.length; i++) {
                assertTrue("Line should be indented by 1 space", 
                           lines[i].startsWith(" "));
                assertTrue("Line should not be indented by full width",
                           lines[i].length() < width || 
                           !lines[i].substring(0, width).trim().isEmpty());
            }
            
            // Additional check for exact match if possible
            assertTrue("Wrapped text should match expected pattern", 
                      actual.contains(" long text"));
        }

    @Test
    public void testPrintWrapped_ShouldUseSmallIndentForWrappedLines() {
        // Setup
        org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
        java.io.StringWriter stringWriter = new java.io.StringWriter();
        java.io.PrintWriter printWriter = new java.io.PrintWriter(stringWriter);
        
        // Input that will force wrapping at width 10
        int width = 10;
        String text = "This is a long text that should wrap";
        
        // Expected behavior: wrapped lines should be indented by 1 space
        String expectedOutput = "This is a\n long text\n that\n should\n wrap";
        
        // Execute
        formatter.printWrapped(printWriter, width, 1, text);
        printWriter.flush();
        
        // Verify
        String actualOutput = stringWriter.toString().trim();
        assertEquals("Wrapped lines should be indented by 1 space", 
                    expectedOutput, 
                    actualOutput);
        
        // Additional verification that no line is indented by full width
        String[] lines = actualOutput.split("\n");
        for (int i = 1; i < lines.length; i++) {
            assertTrue("Continuation line should not be indented by full width",
                      lines[i].length() <= width && 
                      lines[i].startsWith(" "));
        }
    }


}
