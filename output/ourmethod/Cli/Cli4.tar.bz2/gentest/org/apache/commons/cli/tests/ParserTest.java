package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;
 
public class ParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                            public void testCheckRequiredOptions_EmptyList_NoExceptionThrown() throws Exception {
                                                                                                                // Setup
                                                                                                                // Since Parser is abstract, we need to use a concrete subclass - BasicParser is commonly available in CLI
                                                                                                                Parser parser = new BasicParser();
                                                                                                                
                                                                                                                // Use reflection to set private requiredOptions field
                                                                                                                Field requiredOptionsField = Parser.class.getDeclaredField("requiredOptions");
                                                                                                                requiredOptionsField.setAccessible(true);
                                                                                                                requiredOptionsField.set(parser, new ArrayList<>()); // Empty list
                                                                                                                
                                                                                                                // Use reflection to access private checkRequiredOptions method
                                                                                                                Method checkRequiredOptionsMethod = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                                                                checkRequiredOptionsMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Execution - should not throw exception
                                                                                                                checkRequiredOptionsMethod.invoke(parser);
                                                                                                                
                                                                                                                // No assertion needed as we're verifying no exception is thrown
                                                                                                            }

    @Test
                                                                                                            public void testCheckRequiredOptions_SingleRequiredOption_ThrowsExceptionWithCorrectMessage() throws Exception {
                                                                                                                // Setup
                                                                                                                // Since Parser is abstract, we need to use a concrete subclass - BasicParser is commonly available in CLI
                                                                                                                Parser parser = new BasicParser();
                                                                                                                
                                                                                                                // Set requiredOptions using reflection
                                                                                                                List<String> requiredOptions = new ArrayList<>();
                                                                                                                requiredOptions.add("inputFile");
                                                                                                                Field requiredOptionsField = Parser.class.getDeclaredField("requiredOptions");
                                                                                                                requiredOptionsField.setAccessible(true);
                                                                                                                requiredOptionsField.set(parser, requiredOptions);
                                                                                                                
                                                                                                                // Expect exception
                                                                                                                thrown.expect(MissingOptionException.class);
                                                                                                                thrown.expectMessage("Missing required option: inputFile");
                                                                                                                
                                                                                                                // Get and invoke checkRequiredOptions using reflection
                                                                                                                Method checkRequiredOptionsMethod = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                                                                checkRequiredOptionsMethod.setAccessible(true);
                                                                                                                checkRequiredOptionsMethod.invoke(parser);
                                                                                                            }

    @Test
                                                                                                            public void testCheckRequiredOptions_MultipleRequiredOptions_ThrowsExceptionWithCorrectMessage() throws Exception {
                                                                                                                // Setup
                                                                                                                // Since Parser is abstract, we need to use an anonymous subclass
                                                                                                                Parser parser = new Parser() {
                                                                                                                    @Override
                                                                                                                    protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                        return new String[0];
                                                                                                                    }
                                                                                                                };
                                                                                                                
                                                                                                                List<String> requiredOptions = new ArrayList<>();
                                                                                                                requiredOptions.add("inputFile");
                                                                                                                requiredOptions.add("outputFile");
                                                                                                                requiredOptions.add("format");
                                                                                                                
                                                                                                                // Use reflection to set private requiredOptions field
                                                                                                                Field requiredOptionsField = Parser.class.getDeclaredField("requiredOptions");
                                                                                                                requiredOptionsField.setAccessible(true);
                                                                                                                requiredOptionsField.set(parser, requiredOptions);
                                                                                                                
                                                                                                                // Expect exception
                                                                                                                thrown.expect(MissingOptionException.class);
                                                                                                                thrown.expectMessage("Missing required options: inputFileoutputFileformat");
                                                                                                                
                                                                                                                // Use reflection to access private checkRequiredOptions method
                                                                                                                Method checkRequiredOptionsMethod = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                                                                checkRequiredOptionsMethod.setAccessible(true);
                                                                                                                checkRequiredOptionsMethod.invoke(parser);
                                                                                                            }

    @Test
                                                                                                            public void testCheckRequiredOptions_NullRequiredOptionsList_ThrowsNullPointerException() throws Exception {
                                                                                                                // Setup
                                                                                                                Parser parser = new BasicParser(); // Using concrete subclass since Parser is abstract
                                                                                                                Field requiredOptionsField = Parser.class.getDeclaredField("requiredOptions");
                                                                                                                requiredOptionsField.setAccessible(true);
                                                                                                                requiredOptionsField.set(parser, null);
                                                                                                                
                                                                                                                // Expect exception
                                                                                                                thrown.expect(NullPointerException.class);
                                                                                                                
                                                                                                                // Execution
                                                                                                                Method checkRequiredOptionsMethod = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                                                                checkRequiredOptionsMethod.setAccessible(true);
                                                                                                                checkRequiredOptionsMethod.invoke(parser);
                                                                                                            }

    @Test
                                                                                                            public void testCheckRequiredOptions_EmptyStringInRequiredOptions_ThrowsExceptionWithCorrectMessage() throws Exception {
                                                                                                                // Setup
                                                                                                                // Since Parser is abstract, we need to use a concrete subclass - BasicParser is commonly available in CLI
                                                                                                                Parser parser = new BasicParser();
                                                                                                                
                                                                                                                // Use reflection to set private requiredOptions field
                                                                                                                List<String> requiredOptions = new ArrayList<>();
                                                                                                                requiredOptions.add("");
                                                                                                                
                                                                                                                Field requiredOptionsField = Parser.class.getDeclaredField("requiredOptions");
                                                                                                                requiredOptionsField.setAccessible(true);
                                                                                                                requiredOptionsField.set(parser, requiredOptions);
                                                                                                                
                                                                                                                // Expect exception
                                                                                                                thrown.expect(MissingOptionException.class);
                                                                                                                thrown.expectMessage("Missing required option: ");
                                                                                                                
                                                                                                                // Use reflection to access private checkRequiredOptions method
                                                                                                                Method checkRequiredOptionsMethod = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                                                                checkRequiredOptionsMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Execution
                                                                                                                checkRequiredOptionsMethod.invoke(parser);
                                                                                                            }

    @Test
                                                                                                            public void testCheckRequiredOptions_SpecialCharactersInOptions_ThrowsExceptionWithCorrectMessage() throws Exception {
                                                                                                                // Setup
                                                                                                                Parser parser = new BasicParser(); // Using concrete subclass instead of abstract Parser
                                                                                                                List<String> requiredOptions = new ArrayList<>();
                                                                                                                requiredOptions.add("option@1");
                                                                                                                requiredOptions.add("option#2");
                                                                                                                
                                                                                                                // Use reflection to set private requiredOptions field
                                                                                                                Field requiredOptionsField = Parser.class.getDeclaredField("requiredOptions");
                                                                                                                requiredOptionsField.setAccessible(true);
                                                                                                                requiredOptionsField.set(parser, requiredOptions);
                                                                                                                
                                                                                                                // Expect exception
                                                                                                                thrown.expect(MissingOptionException.class);
                                                                                                                thrown.expectMessage("Missing required options: option@1option#2");
                                                                                                                
                                                                                                                // Use reflection to call private checkRequiredOptions method
                                                                                                                Method checkRequiredOptionsMethod = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                                                                checkRequiredOptionsMethod.setAccessible(true);
                                                                                                                checkRequiredOptionsMethod.invoke(parser);
                                                                                                            }

    @Test
                                                                                                public void testCheckRequiredOptionsWithEmptyList() {
                                                                                                    // Should not throw exception when list is empty
                                                                                                    // Using BasicParser as a concrete implementation (adjust if using a different subclass)
                                                                                                    Parser parser = new BasicParser(); 
                                                                                                    
                                                                                                    try {
                                                                                                        // Use reflection to call private method
                                                                                                        java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                                                        method.setAccessible(true);
                                                                                                        method.invoke(parser);
                                                                                                    } catch (Exception e) {
                                                                                                        fail("Should not throw exception when requiredOptions is empty");
                                                                                                    }
                                                                                                }

    @Test
                                                                                                public void testCheckRequiredOptionsWithNegativeSizeList() {
                                                                                                    // Test with a mocked list that returns negative size
                                                                                                    // This would catch the mutant since >0 and !=0 behave differently for negative
                                                                                                    List<String> mockList = mock(List.class);
                                                                                                    List<String> requiredOptions = new ArrayList<>(); // Define requiredOptions
                                                                                                    Parser parser = new Parser() {
                                                                                                        @Override
                                                                                                        protected String[] flatten(Options options, String[] arguments, boolean stopAtNonOption) {
                                                                                                            return new String[0];
                                                                                                        }
                                                                                                    }; // Create anonymous Parser instance
                                                                                                    
                                                                                                    when(mockList.size()).thenReturn(-1);
                                                                                                    when(mockList.iterator()).thenReturn(requiredOptions.iterator());
                                                                                                    
                                                                                                    try {
                                                                                                        // Set the mock list
                                                                                                        java.lang.reflect.Field field = Parser.class.getDeclaredField("requiredOptions");
                                                                                                        field.setAccessible(true);
                                                                                                        field.set(parser, mockList);
                                                                                                        
                                                                                                        // Call the method
                                                                                                        java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                                                        method.setAccessible(true);
                                                                                                        method.invoke(parser);
                                                                                                        
                                                                                                        // If we get here, the mutant was caught (original would throw, mutant wouldn't)
                                                                                                        fail("Should throw exception for any non-zero size, including negative");
                                                                                                    } catch (Exception e) {
                                                                                                        // Expected if original code
                                                                                                        assertTrue(e.getCause() instanceof MissingOptionException);
                                                                                                    }
                                                                                                }

    @Test
                                                                                            public void testCheckRequiredOptionsWithNonEmptyList() throws Exception {
                                                                                                // Create parser instance using anonymous class since Parser is abstract
                                                                                                Parser parser = new Parser() {
                                                                                                    @Override
                                                                                                    protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                        return new String[0];
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                List<String> requiredOptions = new ArrayList<String>();
                                                                                                
                                                                                                // Add required options
                                                                                                requiredOptions.add("option1");
                                                                                                requiredOptions.add("option2");
                                                                                                
                                                                                                // Set required options to parser (using reflection since it's likely a private field)
                                                                                                Field requiredOptionsField = Parser.class.getDeclaredField("requiredOptions");
                                                                                                requiredOptionsField.setAccessible(true);
                                                                                                requiredOptionsField.set(parser, requiredOptions);
                                                                                                
                                                                                                // Use reflection to call private method
                                                                                                java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                                                method.setAccessible(true);
                                                                                                method.invoke(parser);
                                                                                            }

    @Test
                                                                                    public void testCheckRequiredOptions_ThrowsExceptionWhenRequiredOptionsNotEmpty() {
                                                                                        // Setup
                                                                                        // Create a concrete subclass of Parser since it's abstract
                                                                                        Parser parser = new Parser() {
                                                                                            @Override
                                                                                            protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                return new String[0];
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        List<String> requiredOptions = new ArrayList<>();
                                                                                        requiredOptions.add("option1");
                                                                                        requiredOptions.add("option2");
                                                                                    
                                                                                        // Use reflection to set the private requiredOptions field
                                                                                        try {
                                                                                            java.lang.reflect.Field field = Parser.class.getDeclaredField("requiredOptions");
                                                                                            field.setAccessible(true);
                                                                                            field.set(parser, requiredOptions);
                                                                                        } catch (Exception e) {
                                                                                            throw new RuntimeException("Failed to set requiredOptions field", e);
                                                                                        }
                                                                                    
                                                                                        // Use reflection to access the private checkRequiredOptions method
                                                                                        try {
                                                                                            java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                                            method.setAccessible(true);
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(MissingOptionException.class);
                                                                                            thrown.expectMessage("Missing required options: option1option2");
                                                                                            
                                                                                            // Execute
                                                                                            method.invoke(parser);
                                                                                        } catch (Exception e) {
                                                                                            throw new RuntimeException("Failed to invoke checkRequiredOptions", e);
                                                                                        }
                                                                                    }

    @Test
                                                                            public void testCheckRequiredOptions_ShouldThrowExceptionWhenRequiredOptionsExist() throws Exception {
                                                                                // Setup
                                                                                // Create anonymous subclass of Parser since it's abstract
                                                                                Parser parser = new Parser() {
                                                                                    @Override
                                                                                    protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                        return new String[0];
                                                                                    }
                                                                                };
                                                                                
                                                                                List<String> requiredOptions = Arrays.asList("option1", "option2");
                                                                                
                                                                                // Use reflection to set the private requiredOptions field
                                                                                java.lang.reflect.Field field = Parser.class.getDeclaredField("requiredOptions");
                                                                                field.setAccessible(true);
                                                                                field.set(parser, requiredOptions);
                                                                            
                                                                                // Expect exception
                                                                                thrown.expect(MissingOptionException.class);
                                                                                thrown.expectMessage("Missing required options: option1option2");
                                                                            
                                                                                // Execute
                                                                                java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                                method.setAccessible(true);
                                                                                method.invoke(parser);
                                                                            }

    @Test(expected = MissingOptionException.class)
                                                                public void testCheckRequiredOptions_ThrowsMissingOptionExceptionWhenOptionsMissing() throws MissingOptionException {
                                                                    // This will test the original behavior where MissingOptionException is thrown
                                                                    // The mutated version would throw NullPointerException instead
                                                                    
                                                                    // Create a parser instance (using a concrete implementation since Parser is abstract)
                                                                    Parser parser = new BasicParser();
                                                                    
                                                                    // Use reflection to call the private method
                                                                    try {
                                                                        java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                                        method.setAccessible(true);
                                                                        method.invoke(parser);
                                                                    } catch (java.lang.reflect.InvocationTargetException e) {
                                                                        // Check if the cause is MissingOptionException
                                                                        if (e.getCause() instanceof MissingOptionException) {
                                                                            throw (MissingOptionException) e.getCause();
                                                                        }
                                                                        fail("Expected MissingOptionException but got: " + e.getCause().getClass());
                                                                    } catch (Exception e) {
                                                                        fail("Failed to invoke checkRequiredOptions method");
                                                                    }
                                                                }

    @Test
                                                        public void testCheckRequiredOptions_ErrorMessageStartsWithCorrectText() throws Exception {
                                                            // Setup
                                                            // Create anonymous subclass of Parser since it's abstract
                                                            Parser parser = new Parser() {
                                                                @Override
                                                                protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                    return new String[0]; // dummy implementation
                                                                }
                                                            };
                                                            
                                                            List<String> requiredOptions = Arrays.asList("option1", "option2");
                                                            
                                                            // Use reflection to set private field since there's no constructor/setter
                                                            java.lang.reflect.Field field = Parser.class.getDeclaredField("requiredOptions");
                                                            field.setAccessible(true);
                                                            field.set(parser, requiredOptions);
                                                        
                                                            // Expect exception
                                                            thrown.expect(MissingOptionException.class);
                                                            thrown.expectMessage("Missing required options: option1option2");
                                                        
                                                            // Execute
                                                            java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                            method.setAccessible(true);
                                                            method.invoke(parser);
                                                        }

    @Test
                                                public void testCheckRequiredOptions_ErrorMessagePrefix() throws Exception {
                                                    // Setup
                                                    // Create an anonymous subclass of Parser since it's abstract
                                                    Parser parser = new Parser() {
                                                        @Override
                                                        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                            return new String[0]; // dummy implementation
                                                        }
                                                    };
                                                    
                                                    List<String> requiredOptions = Arrays.asList("opt1", "opt2");
                                                    
                                                    // Use reflection to set the private requiredOptions field since we don't have a setter
                                                    java.lang.reflect.Field field = Parser.class.getDeclaredField("requiredOptions");
                                                    field.setAccessible(true);
                                                    field.set(parser, requiredOptions);
                                                
                                                    // Expect exception
                                                    thrown.expect(MissingOptionException.class);
                                                    thrown.expectMessage("Missing required options: opt1opt2");
                                                
                                                    // Execute
                                                    java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                    method.setAccessible(true);
                                                    method.invoke(parser);
                                                }

    @Test
                                        public void testCheckRequiredOptions_SingleMissingOption_ShouldUseSingularForm() {
                                            // Setup
                                            Parser parser = new BasicParser();  // Using concrete subclass instead of abstract Parser
                                            List<String> requiredOptions = new ArrayList<>();
                                            requiredOptions.add("option1");
                                            
                                            // Use reflection to set private field since no constructor/setter
                                            try {
                                                Field field = Parser.class.getDeclaredField("requiredOptions");
                                                field.setAccessible(true);
                                                field.set(parser, requiredOptions);
                                            } catch (Exception e) {
                                                fail("Failed to set requiredOptions field via reflection");
                                            }
                                         
                                            // Test & Verify
                                            try {
                                                Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                                method.setAccessible(true);
                                                method.invoke(parser);
                                                fail("Expected MissingOptionException");
                                            } catch (InvocationTargetException e) {
                                                assertTrue(e.getCause() instanceof MissingOptionException);
                                                String message = e.getCause().getMessage();
                                                // Original: "Missing required option: option1"
                                                // Mutant:   "Missing required options: option1" (incorrect plural)
                                                assertFalse("Message should not contain plural 's' for single option", 
                                                           message.contains("options"));
                                                assertTrue("Message should contain singular 'option'", 
                                                          message.contains("option"));
                                            } catch (Exception e) {
                                                fail("Unexpected exception: " + e.getClass().getName());
                                            }
                                        }

    @Test
                                public void testCheckRequiredOptions_SingularFormWhenSingleOptionMissing() throws Exception {
                                    // Create parser instance
                                    Parser parser = new PosixParser(); // Assuming PosixParser extends Parser
                                    
                                    // Set up required options with single item
                                    List<String> requiredOptions = Arrays.asList("option1");
                                    try {
                                        java.lang.reflect.Field field = Parser.class.getDeclaredField("requiredOptions");
                                        field.setAccessible(true);
                                        field.set(parser, requiredOptions);
                                    } catch (Exception e) {
                                        throw new RuntimeException(e);
                                    }
                                    
                                    // Set up exception expectation
                                    ExpectedException thrown = ExpectedException.none();
                                    thrown.expect(MissingOptionException.class);
                                    thrown.expectMessage("Missing required option: option1");
                                    
                                    // Call the method - should throw exception
                                    Method checkRequiredOptions = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                    checkRequiredOptions.setAccessible(true);
                                    checkRequiredOptions.invoke(parser);
                                }

    @Test
                            public void testCheckRequiredOptions_PluralFormWhenMultipleOptionsMissing() throws Exception {
                                // Create parser instance - using BasicParser as it's available in commons-cli
                                Parser parser = new BasicParser();
                                
                                // Set up required options with multiple items
                                List<String> requiredOptions = Arrays.asList("option1", "option2");
                                try {
                                    // Set requiredOptions field via reflection
                                    java.lang.reflect.Field field = Parser.class.getDeclaredField("requiredOptions");
                                    field.setAccessible(true);
                                    field.set(parser, requiredOptions);
                                } catch (Exception e) {
                                    throw new RuntimeException(e);
                                }
                                
                                // Set up exception expectation
                                ExpectedException thrown = ExpectedException.none();
                                thrown.expect(MissingOptionException.class);
                                thrown.expectMessage("Missing required options: option1option2");
                                
                                // Call the private method via reflection
                                try {
                                    java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                                    method.setAccessible(true);
                                    method.invoke(parser);
                                } catch (Exception e) {
                                    throw new RuntimeException(e);
                                }
                            }

    @Test
                    public void testCheckRequiredOptions_ErrorMessageFormat() throws Exception {
                        // Setup - using BasicParser as concrete implementation
                        Parser parser = new BasicParser();
                        List<String> requiredOptions = Arrays.asList("option1", "option2");
                        
                        // Use reflection to set private field since no constructor/setter
                        java.lang.reflect.Field field = Parser.class.getDeclaredField("requiredOptions");
                        field.setAccessible(true);
                        field.set(parser, requiredOptions);
                    
                        // Expect exception with specific message format
                        thrown.expect(MissingOptionException.class);
                        thrown.expectMessage("Missing required options: option1option2");
                    
                        // Execute
                        java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                        method.setAccessible(true);
                        method.invoke(parser);
                    }

    @Test
            public void testCheckRequiredOptionsMessageFormat() throws Exception {
                // Setup
                // Create anonymous subclass of Parser since it's abstract
                Parser parser = new Parser() {
                    @Override
                    protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                        return new String[0]; // dummy implementation
                    }
                };
                
                List<String> requiredOptions = Arrays.asList("option1", "option2");
                
                // Use reflection to set private field since no setter is available
                java.lang.reflect.Field field = Parser.class.getDeclaredField("requiredOptions");
                field.setAccessible(true);
                field.set(parser, requiredOptions);
            
                // Expect exception with specific message format
                thrown.expect(MissingOptionException.class);
                thrown.expectMessage("Missing required options: option1option2");
            
                // Execute
                java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
                method.setAccessible(true);
                method.invoke(parser);
            }

    @Test
    public void testCheckRequiredOptions_ErrorMessageFormat1() {
        // Setup
        Parser parser = new PosixParser(); // Using concrete implementation
        List<String> requiredOptions = Arrays.asList("opt1", "opt2");
        
        // Use reflection to set the private requiredOptions field
        try {
            java.lang.reflect.Field field = Parser.class.getDeclaredField("requiredOptions");
            field.setAccessible(true);
            field.set(parser, requiredOptions);
        } catch (Exception e) {
            fail("Failed to set requiredOptions field via reflection");
        }
        
        // Test and verify
        try {
            // Use reflection to call the private method
            java.lang.reflect.Method method = Parser.class.getDeclaredMethod("checkRequiredOptions");
            method.setAccessible(true);
            method.invoke(parser);
            fail("Expected MissingOptionException to be thrown");
        } catch (Exception e) {
            // Get the root cause which should be our MissingOptionException
            Throwable cause = e.getCause();
            assertTrue(cause instanceof MissingOptionException);
            
            String expectedMessageStart = "Missing required options: ";
            String actualMessage = cause.getMessage();
            
            // Verify message starts with correct prefix including colon and space
            assertTrue("Exception message should start with '" + expectedMessageStart + "'", 
                      actualMessage.startsWith(expectedMessageStart));
            
            // Verify options are listed after the separator
            assertTrue("Message should contain first option", actualMessage.contains("opt1"));
            assertTrue("Message should contain second option", actualMessage.contains("opt2"));
        }
    }


}
