package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.List;
 
public class GnuParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                    public void testFlatten_EmptyArguments() throws Exception {
                                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                                                                                            "flatten", Options.class, String[].class, boolean.class);
                                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(
                                                                                                                                                                            parser, options, new String[]{}, false);
                                                                                                                                                                        
                                                                                                                                                                        assertNotNull(result);
                                                                                                                                                                        assertEquals(0, result.length);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testFlatten_SimpleArguments() throws Exception {
                                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                        String[] args = {"file1", "file2"};
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                                                                                            "flatten", Options.class, String[].class, boolean.class);
                                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                                                                                                        
                                                                                                                                                                        assertArrayEquals(args, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testFlatten_DoubleDashTerminator() throws Exception {
                                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                        String[] args = {"--", "file1", "-option"};
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                                                                                            "flatten", 
                                                                                                                                                                            Options.class, 
                                                                                                                                                                            String[].class, 
                                                                                                                                                                            boolean.class
                                                                                                                                                                        );
                                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                                                                                                        
                                                                                                                                                                        String[] expected = {"--", "file1", "-option"};
                                                                                                                                                                        assertArrayEquals(expected, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testFlatten_SingleDash() throws Exception {
                                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                        String[] args = {"-", "file"};
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                                                                                            "flatten", Options.class, String[].class, boolean.class);
                                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                                                                                                        
                                                                                                                                                                        String[] expected = {"-", "file"};
                                                                                                                                                                        assertArrayEquals(expected, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testFlatten_RecognizedOption() throws Exception {
                                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                        when(options.hasOption("f")).thenReturn(true);
                                                                                                                                                                        String[] args = {"-f", "value"};
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                                                                                                        
                                                                                                                                                                        String[] expected = {"-f", "value"};
                                                                                                                                                                        assertArrayEquals(expected, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testFlatten_UnrecognizedOptionWithoutEquals() throws Exception {
                                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                        when(options.hasOption("x")).thenReturn(false);
                                                                                                                                                                        String[] args = {"-x", "value"};
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                                                                                                        
                                                                                                                                                                        String[] expected = {"-x", "value"};
                                                                                                                                                                        assertArrayEquals(expected, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testFlatten_OptionWithEquals() throws Exception {
                                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                        when(options.hasOption("f")).thenReturn(true);
                                                                                                                                                                        String[] args = {"--file=name.txt"};
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                                                                                                        
                                                                                                                                                                        String[] expected = {"--file", "name.txt"};
                                                                                                                                                                        assertArrayEquals(expected, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testFlatten_SpecialPropertyOption() throws Exception {
                                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                        when(options.hasOption("D")).thenReturn(true);
                                                                                                                                                                        String[] args = {"-Dproperty=value"};
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                                                                                                        
                                                                                                                                                                        String[] expected = {"-D", "property=value"};
                                                                                                                                                                        assertArrayEquals(expected, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testFlatten_StopAtNonOption() throws Exception {
                                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                        when(options.hasOption("f")).thenReturn(false);
                                                                                                                                                                        String[] args = {"-f", "file1", "file2"};
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, args, true);
                                                                                                                                                                        
                                                                                                                                                                        String[] expected = {"-f", "file1", "file2"};
                                                                                                                                                                        assertArrayEquals(expected, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testFlatten_MixedArguments() throws Exception {
                                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                        when(options.hasOption("f")).thenReturn(true);
                                                                                                                                                                        when(options.hasOption("D")).thenReturn(true);
                                                                                                                                                                        String[] args = {"-f", "--file=name.txt", "-Dprop=val", "--", "-x", "file"};
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected method
                                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                                                                                            "flatten", Options.class, String[].class, boolean.class);
                                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                                                                                                                        
                                                                                                                                                                        String[] expected = {"-f", "--file", "name.txt", "-D", "prop=val", "--", "-x", "file"};
                                                                                                                                                                        assertArrayEquals(expected, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testFlatten_NullArguments() throws Exception {
                                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                        
                                                                                                                                                                        ExpectedException exception = ExpectedException.none();
                                                                                                                                                                        exception.expect(NullPointerException.class);
                                                                                                                                                                        
                                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                                                                                            "flatten", Options.class, String[].class, boolean.class);
                                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                                        flattenMethod.invoke(parser, options, null, false);
                                                                                                                                                                    }

    @Test
                                                                                                                                                            public void testFlatten_OptionWithEquals_KeepsFullOptionName() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                Options options = mock(Options.class);
                                                                                                                                                                when(options.hasOption("foo")).thenReturn(true);
                                                                                                                                                                when(options.hasOption(anyString())).thenReturn(false); // default for other options
                                                                                                                                                                when(options.hasOption("f")).thenReturn(true); // for any other potential checks
                                                                                                                                                                
                                                                                                                                                                String[] arguments = {"--foo=bar"};
                                                                                                                                                                boolean stopAtNonOption = false;
                                                                                                                                                                
                                                                                                                                                                GnuParser parser = new GnuParser();
                                                                                                                                                                
                                                                                                                                                                // Get the protected flatten method using reflection
                                                                                                                                                                Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                                                                                    "flatten", 
                                                                                                                                                                    Options.class, 
                                                                                                                                                                    String[].class, 
                                                                                                                                                                    boolean.class
                                                                                                                                                                );
                                                                                                                                                                flattenMethod.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals(2, result.length);
                                                                                                                                                                assertEquals("--foo", result[0]);  // This will fail if mutant is present (would get "-foo")
                                                                                                                                                                assertEquals("bar", result[1]);
                                                                                                                                                            }

    @Test
                                                                                                                                                    public void testFlatten_OptionWithEqualsSign_CorrectTokenization() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                        when(options.hasOption("foo")).thenReturn(true);
                                                                                                                                                        String[] arguments = {"--foo=bar"};
                                                                                                                                                        boolean stopAtNonOption = false;
                                                                                                                                                        
                                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                                        
                                                                                                                                                        // Get the protected flatten method
                                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                                                                            "flatten", 
                                                                                                                                                            Options.class, 
                                                                                                                                                            String[].class, 
                                                                                                                                                            boolean.class
                                                                                                                                                        );
                                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Execute
                                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertEquals(2, result.length);
                                                                                                                                                        assertEquals("--foo", result[0]);  // This will fail if mutant is present (would get "--foo=")
                                                                                                                                                        assertEquals("bar", result[1]);
                                                                                                                                                    }

    @Test
                                                                                                                                            public void testFlatten_OptionWithEqualsSign_SplitsOptionAndValue() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                Options options = mock(Options.class);
                                                                                                                                                when(options.hasOption("foo")).thenReturn(true);
                                                                                                                                                String[] arguments = {"--foo=bar"};
                                                                                                                                                boolean stopAtNonOption = false;
                                                                                                                                                
                                                                                                                                                // Test
                                                                                                                                                GnuParser parser = new GnuParser();
                                                                                                                                                Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                                                                                                flattenMethod.setAccessible(true);
                                                                                                                                                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                assertEquals(2, result.length); // Should be split into 2 tokens
                                                                                                                                                assertEquals("--foo", result[0]); // First part should be the option
                                                                                                                                                assertEquals("bar", result[1]); // Second part should be the value
                                                                                                                                                
                                                                                                                                                // Additional verification that the option part was checked
                                                                                                                                                verify(options).hasOption("foo");
                                                                                                                                            }

    @Test
                                                                                                                                    public void testFlatten_OptionWithEqualsSign_CorrectTokenAdded() throws Exception {
                                                                                                                                        // Setup
                                                                                                                                        Options options = new Options();
                                                                                                                                        options.addOption("foo", false, "test option");
                                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                                        String[] arguments = {"--foo=bar"};
                                                                                                                                        
                                                                                                                                        // Get the protected flatten method using reflection
                                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                                                            "flatten", 
                                                                                                                                            Options.class, 
                                                                                                                                            String[].class, 
                                                                                                                                            boolean.class
                                                                                                                                        );
                                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                                        
                                                                                                                                        // Execute
                                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, false);
                                                                                                                                        
                                                                                                                                        // Verify
                                                                                                                                        assertEquals("First token should be option name before =", "--foo", result[0]);
                                                                                                                                        assertEquals("Second token should be value after =", "bar", result[1]);
                                                                                                                                        assertEquals("Should have exactly 2 tokens", 2, result.length);
                                                                                                                                    }

    @Test
                                                                                                                            public void testFlatten_KeyValueArgument_ValueExtraction() throws Exception {
                                                                                                                                // Setup
                                                                                                                                Options options = mock(Options.class);
                                                                                                                                when(options.hasOption("foo")).thenReturn(true);
                                                                                                                                when(options.hasOption(anyString())).thenReturn(false);
                                                                                                                                
                                                                                                                                GnuParser parser = new GnuParser();
                                                                                                                                String[] arguments = {"--foo=bar"};
                                                                                                                                
                                                                                                                                // Get the protected flatten method using reflection
                                                                                                                                Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                                                                                flattenMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, false);
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                                assertEquals("Expected 2 tokens for key=value format", 2, result.length);
                                                                                                                                assertEquals("Key should be properly extracted", "--foo", result[0]);
                                                                                                                                assertEquals("Value should not contain '=' character", "bar", result[1]);
                                                                                                                            }

    @Test
                                                                                                                    public void testFlatten_DetectsValueExtractionMutant() throws Exception {
                                                                                                                        // Setup
                                                                                                                        Options options = mock(Options.class);
                                                                                                                        when(options.hasOption("foo")).thenReturn(true);
                                                                                                                        when(options.hasOption(anyString())).thenReturn(false);
                                                                                                                        
                                                                                                                        String[] arguments = {"--foo=bar"};
                                                                                                                        GnuParser parser = new GnuParser();
                                                                                                                        
                                                                                                                        // Get the protected flatten method using reflection
                                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                                            "flatten", 
                                                                                                                            Options.class, 
                                                                                                                            String[].class, 
                                                                                                                            boolean.class
                                                                                                                        );
                                                                                                                        flattenMethod.setAccessible(true);
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, false);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(2, result.length);
                                                                                                                        assertEquals("--foo", result[0]);
                                                                                                                        // This assertion will fail with the mutant, catching it
                                                                                                                        assertEquals("bar", result[1]); 
                                                                                                                        
                                                                                                                        // The mutant would make result[1] be "--foo=bar" instead of "bar"
                                                                                                                    }

    @Test
                                                                                                            public void testFlatten_SplitsOptionWithEqualsSign() throws Exception {
                                                                                                                // Setup
                                                                                                                Options options = mock(Options.class);
                                                                                                                when(options.hasOption("foo")).thenReturn(true);
                                                                                                                when(options.hasOption("D")).thenReturn(true);
                                                                                                                
                                                                                                                GnuParser parser = new GnuParser();
                                                                                                                String[] arguments = {"--foo=bar", "-Dkey=value"};
                                                                                                                
                                                                                                                // Get the protected flatten method using reflection
                                                                                                                Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                                    "flatten", Options.class, String[].class, boolean.class);
                                                                                                                flattenMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Execute
                                                                                                                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, false);
                                                                                                                
                                                                                                                // Verify
                                                                                                                // For --foo=bar
                                                                                                                assertEquals("--foo", result[0]);
                                                                                                                assertEquals("bar", result[1]);  // This would fail with the mutant which would give "--foo=bar"
                                                                                                                
                                                                                                                // For -Dkey=value
                                                                                                                assertEquals("-D", result[2]);
                                                                                                                assertEquals("key=value", result[3]);
                                                                                                                
                                                                                                                // Additional verification
                                                                                                                assertEquals(4, result.length);
                                                                                                            }

    @Test
                                                                                                    public void testFlatten_KeyValueArgument_ShouldPreserveValue() throws Exception {
                                                                                                        // Setup
                                                                                                        Options options = mock(Options.class);
                                                                                                        when(options.hasOption("foo")).thenReturn(true);
                                                                                                        when(options.hasOption(anyString())).thenReturn(false);
                                                                                                        
                                                                                                        String[] arguments = {"--foo=bar"};
                                                                                                        boolean stopAtNonOption = false;
                                                                                                        
                                                                                                        GnuParser parser = new GnuParser();
                                                                                                        
                                                                                                        // Get the protected flatten method using reflection
                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                            "flatten", 
                                                                                                            Options.class, 
                                                                                                            String[].class, 
                                                                                                            boolean.class
                                                                                                        );
                                                                                                        flattenMethod.setAccessible(true);
                                                                                                        
                                                                                                        // Execute
                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals(2, result.length);
                                                                                                        assertEquals("--foo", result[0]);
                                                                                                        assertEquals("bar", result[1]); // This assertion would fail with the mutant
                                                                                                    }

    @Test
                                                                                                    public void testFlatten_ShortKeyValueArgument_ShouldPreserveValue() throws Exception {
                                                                                                        // Setup
                                                                                                        Options options = mock(Options.class);
                                                                                                        when(options.hasOption("f")).thenReturn(true);
                                                                                                        when(options.hasOption(anyString())).thenReturn(false);
                                                                                                        
                                                                                                        String[] arguments = {"-f=value"};
                                                                                                        boolean stopAtNonOption = false;
                                                                                                        
                                                                                                        GnuParser parser = new GnuParser();
                                                                                                        
                                                                                                        // Get the protected flatten method using reflection
                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                            "flatten", 
                                                                                                            Options.class, 
                                                                                                            String[].class, 
                                                                                                            boolean.class
                                                                                                        );
                                                                                                        flattenMethod.setAccessible(true);
                                                                                                        
                                                                                                        // Execute
                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals(2, result.length);
                                                                                                        assertEquals("-f", result[0]);
                                                                                                        assertEquals("value", result[1]); // This assertion would fail with the mutant
                                                                                                    }

    @Test
                                                                                                    public void testFlatten_MultipleKeyValueArguments_ShouldPreserveAllValues() throws Exception {
                                                                                                        // Setup
                                                                                                        Options options = mock(Options.class);
                                                                                                        when(options.hasOption("foo")).thenReturn(true);
                                                                                                        when(options.hasOption("bar")).thenReturn(true);
                                                                                                        when(options.hasOption(anyString())).thenReturn(false);
                                                                                                        
                                                                                                        String[] arguments = {"--foo=value1", "--bar=value2"};
                                                                                                        boolean stopAtNonOption = false;
                                                                                                        
                                                                                                        GnuParser parser = new GnuParser();
                                                                                                        
                                                                                                        // Get the protected flatten method using reflection
                                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                            "flatten", Options.class, String[].class, boolean.class);
                                                                                                        flattenMethod.setAccessible(true);
                                                                                                        
                                                                                                        // Execute
                                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals(4, result.length);
                                                                                                        assertEquals("--foo", result[0]);
                                                                                                        assertEquals("value1", result[1]); // Would fail with mutant
                                                                                                        assertEquals("--bar", result[2]);
                                                                                                        assertEquals("value2", result[3]); // Would fail with mutant
                                                                                                    }

    @Test
                                                                                            public void testFlatten_DetectsSpecialPropertyOptionWithCorrectPrefixLength() throws Exception {
                                                                                                // Create test data
                                                                                                String[] arguments = {"-Dproperty=value"};
                                                                                                boolean stopAtNonOption = false;
                                                                                                
                                                                                                // Mock Options to return:
                                                                                                // - false for hasOption("-") (substring 0,1)
                                                                                                // - true for hasOption("-D") (substring 0,2)
                                                                                                Options options = mock(Options.class);
                                                                                                when(options.hasOption("-")).thenReturn(false);
                                                                                                when(options.hasOption("-D")).thenReturn(true);
                                                                                                
                                                                                                // Get the protected flatten method using reflection
                                                                                                GnuParser parser = new GnuParser();
                                                                                                Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                                    "flatten", Options.class, String[].class, boolean.class);
                                                                                                flattenMethod.setAccessible(true);
                                                                                                
                                                                                                // Call the method using reflection
                                                                                                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                                                
                                                                                                // Verify the correct behavior:
                                                                                                // Original code should split into ["-D", "property=value"]
                                                                                                // Mutated code would keep as ["-Dproperty=value"]
                                                                                                assertEquals(2, result.length);
                                                                                                assertEquals("-D", result[0]);
                                                                                                assertEquals("property=value", result[1]);
                                                                                                
                                                                                                // Verify mock interactions
                                                                                                verify(options).hasOption("-D");
                                                                                                // Note: The mutated version would call hasOption("-") which we set to return false
                                                                                            }

    @Test
                                                                                    public void testFlatten_DetectsSpecialPropertyOptionMutation() throws Exception {
                                                                                        // Setup
                                                                                        Options options = mock(Options.class);
                                                                                        when(options.hasOption(anyString())).thenReturn(false);
                                                                                        // Mock hasOption to return true when checking for "-D"
                                                                                        when(options.hasOption("-D")).thenReturn(true);
                                                                                        
                                                                                        String[] arguments = {"-Dkey=value"};
                                                                                        boolean stopAtNonOption = false;
                                                                                        
                                                                                        GnuParser parser = new GnuParser();
                                                                                        
                                                                                        // Get the protected flatten method using reflection
                                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                            "flatten", 
                                                                                            Options.class, 
                                                                                            String[].class, 
                                                                                            boolean.class
                                                                                        );
                                                                                        flattenMethod.setAccessible(true);
                                                                                        
                                                                                        // Execute
                                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                                        
                                                                                        // Verify
                                                                                        // The first token should be "-D" (2 characters)
                                                                                        assertEquals("-D", result[0]);
                                                                                        // The second token should be "key=value"
                                                                                        assertEquals("key=value", result[1]);
                                                                                        // Verify we got exactly 2 tokens
                                                                                        assertEquals(2, result.length);
                                                                                    }

    @Test
                                                                            public void testFlatten_DetectsSpecialPropertyOptionFormat() throws Exception {
                                                                                // Setup
                                                                                Options options = mock(Options.class);
                                                                                when(options.hasOption(anyString())).thenReturn(false);
                                                                                when(options.hasOption("-D")).thenReturn(true);
                                                                                
                                                                                String[] arguments = {"-Dproperty=value"};
                                                                                boolean stopAtNonOption = false;
                                                                                
                                                                                GnuParser parser = new GnuParser();
                                                                                
                                                                                // Get the protected flatten method using reflection
                                                                                Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                                    "flatten", 
                                                                                    Options.class, 
                                                                                    String[].class, 
                                                                                    boolean.class
                                                                                );
                                                                                flattenMethod.setAccessible(true);
                                                                                
                                                                                // Execute
                                                                                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                                
                                                                                // Verify
                                                                                assertEquals(2, result.length);
                                                                                assertEquals("-D", result[0]);  // This will fail with the mutant which would return "Dp"
                                                                                assertEquals("property=value", result[1]);
                                                                            }

    @Test
                                                                    public void testFlatten_DetectsSpecialPropertyOptionMutation1() throws Exception {
                                                                        // Setup
                                                                        Options options = mock(Options.class);
                                                                        when(options.hasOption("-D")).thenReturn(true);
                                                                        String[] arguments = {"-Dkey=value"};
                                                                        boolean stopAtNonOption = false;
                                                                        
                                                                        GnuParser parser = new GnuParser();
                                                                        
                                                                        // Get the protected flatten method using reflection
                                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                            "flatten", 
                                                                            Options.class, 
                                                                            String[].class, 
                                                                            boolean.class
                                                                        );
                                                                        flattenMethod.setAccessible(true);
                                                                        
                                                                        // Execute
                                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                        
                                                                        // Verify
                                                                        assertEquals(2, result.length);
                                                                        assertEquals("-D", result[0]);  // This would fail with the mutant
                                                                        assertEquals("key=value", result[1]);  // This would also fail with the mutant
                                                                        
                                                                        // Verify mock interaction
                                                                        verify(options).hasOption("-D");
                                                                    }

    @Test
                                                            public void testFlatten_DetectsSpecialPropertyOption() throws Exception {
                                                                // Setup
                                                                Options options = mock(Options.class);
                                                                when(options.hasOption("-D")).thenReturn(true);
                                                                String[] arguments = {"-Dkey=value"};
                                                                boolean stopAtNonOption = false;
                                                                
                                                                // Create instance
                                                                GnuParser parser = new GnuParser();
                                                                
                                                                // Get the protected flatten method using reflection
                                                                Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                                    "flatten", 
                                                                    Options.class, 
                                                                    String[].class, 
                                                                    boolean.class
                                                                );
                                                                flattenMethod.setAccessible(true);
                                                                
                                                                // Execute
                                                                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                                
                                                                // Verify
                                                                assertEquals(2, result.length);
                                                                assertEquals("-D", result[0]);  // This will fail with the mutant which would produce ""
                                                                assertEquals("key=value", result[1]);
                                                                
                                                                // Verify mock interactions
                                                                verify(options).hasOption("-D");
                                                            }

    @Test
                                                    public void testFlatten_DetectsSpecialPropertyOptionMutation2() throws Exception {
                                                        // Setup
                                                        Options options = mock(Options.class);
                                                        when(options.hasOption("D")).thenReturn(true); // -D is a valid option
                                                        String[] arguments = {"-Dkey=value"};
                                                        boolean stopAtNonOption = false;
                                                        
                                                        GnuParser parser = new GnuParser();
                                                        
                                                        // Get the protected flatten method using reflection
                                                        Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                            "flatten", 
                                                            Options.class, 
                                                            String[].class, 
                                                            boolean.class
                                                        );
                                                        flattenMethod.setAccessible(true);
                                                        
                                                        // Execute
                                                        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                        
                                                        // Verify
                                                        assertEquals(2, result.length);
                                                        assertEquals("-D", result[0]); // First token should be -D
                                                        assertEquals("key=value", result[1]); // Second token should be key=value (without the D)
                                                        
                                                        // This assertion would fail with the mutant which would return "Dkey=value"
                                                    }

    @Test
                                            public void testFlatten_DetectsSpecialPropertyOptionWithSubstringMutation() throws Exception {
                                                // Setup
                                                Options options = mock(Options.class);
                                                when(options.hasOption(anyString())).thenReturn(false);
                                                when(options.hasOption("D")).thenReturn(true); // For -D case
                                                
                                                GnuParser parser = new GnuParser();
                                                String[] arguments = {"-Dproperty=value"};
                                                boolean stopAtNonOption = false;
                                                
                                                // Get the protected flatten method using reflection
                                                Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                                    "flatten", 
                                                    Options.class, 
                                                    String[].class, 
                                                    boolean.class
                                                );
                                                flattenMethod.setAccessible(true);
                                                
                                                // Execute
                                                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                                
                                                // Verify
                                                assertEquals(3, result.length); // Should be [-D, property=value] + original?
                                                assertEquals("-D", result[0]);
                                                // This assertion will catch the mutant - expects "property=value" but mutant would return "roperty=value"
                                                assertEquals("property=value", result[1]);
                                                
                                                // Additional verification for the specific case
                                                String originalArg = arguments[0];
                                                String expectedValuePart = originalArg.substring(2); // property=value
                                                assertEquals(expectedValuePart, result[1]);
                                            }

    @Test
                                    public void testFlatten_DetectsPropertyOptionSplitMutation() throws Exception {
                                        // Setup
                                        Options options = mock(Options.class);
                                        when(options.hasOption("D")).thenReturn(true);
                                        String[] arguments = {"-Dkey=value"};
                                        boolean stopAtNonOption = false;
                                        
                                        // Expected behavior: should split into ["-D", "key=value"]
                                        String[] expected = {"-D", "key=value"};
                                        
                                        // Test
                                        GnuParser parser = new GnuParser();
                                        Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                        flattenMethod.setAccessible(true);
                                        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                        
                                        // Verify
                                        assertArrayEquals("Property option should be properly split", expected, result);
                                    }

    @Test
                            public void testFlatten_DetectsPropertyValueMutation() throws Exception {
                                // Setup test data
                                Options options = mock(Options.class);
                                when(options.hasOption("-D")).thenReturn(true);
                                String[] arguments = {"-Dkey=value"};
                                boolean stopAtNonOption = false;
                                
                                // Create parser and get the flatten method via reflection
                                GnuParser parser = new GnuParser();
                                Method flattenMethod = GnuParser.class.getDeclaredMethod(
                                    "flatten", 
                                    Options.class, 
                                    String[].class, 
                                    boolean.class
                                );
                                flattenMethod.setAccessible(true);
                                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                
                                // Verify the -D property was processed correctly
                                assertEquals(2, result.length);
                                assertEquals("-D", result[0]);
                                assertEquals("key=value", result[1]); // This will fail with the mutant
                            }

    @Test
                            public void testFlatten_DetectsPropertyValueMutationWithMultipleProperties() throws Exception {
                                // Setup test data
                                Options options = mock(Options.class);
                                when(options.hasOption("-D")).thenReturn(true);
                                String[] arguments = {"-Dkey1=value1", "-Dkey2=value2"};
                                boolean stopAtNonOption = false;
                                
                                // Create parser and get the flatten method via reflection
                                GnuParser parser = new GnuParser();
                                Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                flattenMethod.setAccessible(true);
                                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                                
                                // Verify both -D properties were processed correctly
                                assertEquals(4, result.length);
                                assertEquals("-D", result[0]);
                                assertEquals("key1=value1", result[1]);
                                assertEquals("-D", result[2]);
                                assertEquals("key2=value2", result[3]); // This will fail with the mutant
                            }

    @Test
                    public void testFlatten_DetectsOptionWithEqualsSignMutation() throws Exception {
                        // Setup test data
                        Options options = mock(Options.class);
                        when(options.hasOption("foo")).thenReturn(true);
                        when(options.hasOption("oo")).thenReturn(false); // This would make the mutant fail
                        
                        String[] arguments = {"-foo=bar"};
                        boolean stopAtNonOption = false;
                        
                        // Create parser and test using reflection
                        GnuParser parser = new GnuParser();
                        Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                        flattenMethod.setAccessible(true);
                        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                        
                        // Verify results
                        assertEquals(2, result.length);
                        assertEquals("-foo", result[0]); // Original would keep "-foo", mutant would fail this
                        assertEquals("bar", result[1]);
                        
                        // Verify mock interactions
                        verify(options).hasOption("foo");
                        verify(options, never()).hasOption("oo");
                    }

    @Test
            public void testFlatten_OptionWithEqualsSign_ShouldSplitWhenOptionNameValid() throws Exception {
                // Setup
                Options options = mock(Options.class);
                when(options.hasOption("foo")).thenReturn(true);
                when(options.hasOption("foo=")).thenReturn(false);
                String[] arguments = {"--foo=bar"};
                boolean stopAtNonOption = false;
                
                // Test
                GnuParser parser = new GnuParser();
                Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                flattenMethod.setAccessible(true);
                String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
                
                // Verify
                assertEquals(2, result.length);
                assertEquals("--foo", result[0]);
                assertEquals("bar", result[1]);
            }

    @Test
    public void testFlatten_DetectsSpecialPropertyOptionCorrectly() throws Exception {
        // Setup
        GnuParser parser = new GnuParser();
        Options options = new Options();
        options.addOption("D", false, "Special property option");
        
        String[] arguments = {"-Dproperty=value"};
        boolean stopAtNonOption = false;
        
        // Expected behavior: should split into ["-D", "property=value"]
        String[] expected = {"-D", "property=value"};
        
        // Get the protected flatten method using reflection
        Method flattenMethod = GnuParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
        flattenMethod.setAccessible(true);
        
        // Execute
        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
        
        // Verify
        assertArrayEquals("Special property option should be split correctly", expected, result);
    }

    @Test
    public void testFlatten_DetectsMutationForSpecialPropertyOption() throws Exception {
        // Setup
        GnuParser parser = new GnuParser();
        Options options = new Options();
        // Only add the 2-character option, not the full string
        options.addOption("D", false, "Special property option");
        
        String[] arguments = {"-Dproperty=value"};
        boolean stopAtNonOption = false;
        
        // Get the protected flatten method using reflection
        Method flattenMethod = GnuParser.class.getDeclaredMethod(
            "flatten", 
            Options.class, 
            String[].class, 
            boolean.class
        );
        flattenMethod.setAccessible(true);
        
        // Execute
        String[] result = (String[]) flattenMethod.invoke(parser, options, arguments, stopAtNonOption);
        
        // Verify the correct behavior (should fail if mutation exists)
        assertNotEquals("Mutation should be detected - result should not be the whole string", 
                       arguments[0], result[0]);
        assertEquals("Should have split into two tokens", 2, result.length);
        assertEquals("First token should be -D", "-D", result[0]);
    }


}
