package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
 
public class UtilTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testStripLeadingHyphens_NullInput() throws Exception {
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                    stripLeadingHyphens.setAccessible(true);
                    
                    String result = (String) stripLeadingHyphens.invoke(null, (String) null);
                    assertNull("Null input should return null", result);
                }

    @Test
                public void testStripLeadingHyphens_EmptyString() throws Exception {
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                    stripLeadingHyphens.setAccessible(true);
                    
                    String result = (String) stripLeadingHyphens.invoke(null, "");
                    assertEquals("Empty string should return empty string", "", result);
                }

    @Test
                public void testStripLeadingHyphens_NoHyphens() throws Exception {
                    String input = "testString";
                    
                    // Get the Util class and method using reflection
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                    stripLeadingHyphens.setAccessible(true);
                    
                    // Invoke the method
                    String result = (String) stripLeadingHyphens.invoke(null, input);
                    
                    assertEquals("String without hyphens should return unchanged", input, result);
                }

    @Test
                public void testStripLeadingHyphens_SingleHyphen() throws Exception {
                    String input = "-test";
                    String expected = "test";
                    
                    // Get the method using reflection
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    Method stripMethod = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                    stripMethod.setAccessible(true);
                    
                    // Invoke the method
                    String result = (String) stripMethod.invoke(null, input);
                    
                    assertEquals("Single leading hyphen should be removed", expected, result);
                }

    @Test
                public void testStripLeadingHyphens_MultipleHyphens() throws Exception {
                    String input = "---test";
                    String expected = "-test";
                    
                    // Get the stripLeadingHyphens method using reflection
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                    stripLeadingHyphens.setAccessible(true);
                    
                    // Invoke the method
                    String result = (String) stripLeadingHyphens.invoke(null, input);
                    
                    assertEquals("Only two hyphens should be removed from triple hyphens", expected, result);
                }

    @Test
                public void testStripLeadingHyphens_HyphenOnly() throws Exception {
                    String input = "-";
                    String expected = "";
                    
                    // Get the stripLeadingHyphens method using reflection
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                    stripLeadingHyphens.setAccessible(true);
                    
                    // Invoke the method
                    String result = (String) stripLeadingHyphens.invoke(null, input);
                    assertEquals("Single hyphen should return empty string", expected, result);
                }

    @Test
                public void testStripLeadingHyphens_DoubleHyphenOnly() throws Exception {
                    String input = "--";
                    String expected = "";
                    
                    // Use reflection to access the non-public method
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                    stripLeadingHyphens.setAccessible(true);
                    String result = (String) stripLeadingHyphens.invoke(null, input);
                    
                    assertEquals("Double hyphens should return empty string", expected, result);
                }

    @Test
                public void testStripLeadingHyphens_HyphenInMiddle() throws Exception {
                    String input = "test-string";
                    String expected = "test-string";
                    
                    // Use reflection to access the non-public Util class
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                    stripLeadingHyphens.setAccessible(true);
                    String result = (String) stripLeadingHyphens.invoke(null, input);
                    
                    assertEquals("Hyphen in middle should not be removed", expected, result);
                }

    @Test
                public void testStripLeadingHyphens_HyphenAtEnd() throws Exception {
                    String input = "test-";
                    String expected = "test-";
                    
                    // Use reflection to access the private Util class
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                    stripLeadingHyphens.setAccessible(true);
                    String result = (String) stripLeadingHyphens.invoke(null, input);
                    
                    assertEquals("Hyphen at end should not be removed", expected, result);
                }

    @Test
                public void testStripLeadingHyphens_WhitespaceBeforeHyphen() throws Exception {
                    String input = " -test";
                    String expected = " -test";
                    
                    // Get the stripLeadingHyphens method using reflection
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                    stripLeadingHyphens.setAccessible(true);
                    
                    // Invoke the method
                    String result = (String) stripLeadingHyphens.invoke(null, input);
                    assertEquals("Whitespace before hyphen should prevent removal", expected, result);
                }

    @Test
                public void testStripLeadingHyphens_UnicodeCharacters() throws Exception {
                    String input = "--tëst";
                    String expected = "tëst";
                    
                    // Get the Util class using reflection
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    // Get the stripLeadingHyphens method
                    java.lang.reflect.Method method = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                    // Make the method accessible
                    method.setAccessible(true);
                    // Invoke the method
                    String result = (String) method.invoke(null, input);
                    
                    assertEquals("Should handle unicode characters correctly", expected, result);
                }

    @Test
            public void testStripLeadingHyphens_DoubleHyphen() throws Exception {
                String input = "--test";
                String expected = "test";
                
                // Get the stripLeadingHyphens method via reflection
                Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                stripLeadingHyphens.setAccessible(true);
                
                // Invoke the method
                String result = (String) stripLeadingHyphens.invoke(null, input);
                assertEquals("Double leading hyphens should be removed", expected, result);
            }

    @Test
    public void testStripLeadingHyphensWithNullInput() throws Exception {
        // Arrange
        String input = null;
        
        // Get the stripLeadingHyphens method via reflection
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
        stripLeadingHyphens.setAccessible(true);
        
        // Act
        String result = (String) stripLeadingHyphens.invoke(null, input);
        
        // Assert
        assertNull("Method should return null when input is null", result);
    }


}
