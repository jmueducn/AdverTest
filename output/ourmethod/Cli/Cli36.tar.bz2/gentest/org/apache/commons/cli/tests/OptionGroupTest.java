package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
 
public class OptionGroupTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                        public void testAddOption_SingleOption() {
                                                            // Create test objects
                                                            OptionGroup optionGroup = new OptionGroup();
                                                            Option option1 = new Option("key1", "description1");
                                                            
                                                            OptionGroup result = optionGroup.addOption(option1);
                                                            
                                                            // Verify the option was added to the map
                                                            Collection<Option> options = optionGroup.getOptions();
                                                            assertEquals(1, options.size());
                                                            assertTrue(options.contains(option1));
                                                            
                                                            // Verify method chaining works
                                                            assertSame(optionGroup, result);
                                                        }

    @Test
                                                        public void testAddOption_MultipleOptions() {
                                                            OptionGroup optionGroup = new OptionGroup();
                                                            Option option1 = new Option("key1", "description1");
                                                            Option option2 = new Option("key2", "description2");
                                                            
                                                            optionGroup.addOption(option1);
                                                            OptionGroup result = optionGroup.addOption(option2);
                                                            
                                                            Collection<Option> options = optionGroup.getOptions();
                                                            assertEquals(2, options.size());
                                                            assertTrue(options.contains(option1));
                                                            assertTrue(options.contains(option2));
                                                            assertSame(optionGroup, result);
                                                        }

    @Test
                                                        public void testAddOption_NullOption() {
                                                            OptionGroup optionGroup = new OptionGroup();
                                                            ExpectedException exception = ExpectedException.none();
                                                            
                                                            exception.expect(NullPointerException.class);
                                                            exception.expectMessage("Option cannot be null");
                                                            
                                                            optionGroup.addOption(null);
                                                        }

    @Test
                                                        public void testAddOption_DuplicateOptions() {
                                                            OptionGroup optionGroup = new OptionGroup();
                                                            Option option1 = mock(Option.class);
                                                            Option duplicateOption = mock(Option.class);
                                                            
                                                            // Using reflection to access getKey() since it's not public
                                                            try {
                                                                Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                getKeyMethod.setAccessible(true);
                                                                when(getKeyMethod.invoke(option1)).thenReturn("key1");
                                                                when(getKeyMethod.invoke(duplicateOption)).thenReturn("key1");
                                                            } catch (Exception e) {
                                                                fail("Failed to access getKey method via reflection");
                                                            }
                                                            
                                                            optionGroup.addOption(option1);
                                                            optionGroup.addOption(duplicateOption);
                                                            
                                                            Collection<Option> options = optionGroup.getOptions();
                                                            assertEquals(1, options.size());
                                                            assertTrue(options.contains(duplicateOption));
                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                    public void testAddOption_OptionWithNullKey() {
                                                        // Setup
                                                        OptionGroup optionGroup = new OptionGroup();
                                                        Option optionWithNullKey = new Option(null, "description");
                                                        
                                                        // Test
                                                        try {
                                                            optionGroup.addOption(optionWithNullKey);
                                                            fail("Expected IllegalArgumentException to be thrown");
                                                        } catch (IllegalArgumentException e) {
                                                            assertEquals("Option key cannot be null", e.getMessage());
                                                            throw e;
                                                        }
                                                    }

    @Test
                                            public void testAddOptionShouldStoreOptionWithItsKeyNotNull() throws Exception {
                                                // Setup
                                                OptionGroup optionGroup = new OptionGroup();
                                                Option option = mock(Option.class);
                                                
                                                // Use reflection to access getKey() since it's not public
                                                Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                getKeyMethod.setAccessible(true);
                                                when(getKeyMethod.invoke(option)).thenReturn("testKey");
                                                
                                                // Get the internal collection (getOptions() returns Collection<Option>)
                                                Collection<Option> optionsBefore = optionGroup.getOptions();
                                                int initialSize = optionsBefore.size();
                                                
                                                // Execute
                                                OptionGroup result = optionGroup.addOption(option);
                                                
                                                // Verify
                                                // 1. Check the returned object is the same instance (builder pattern)
                                                assertSame(optionGroup, result);
                                                
                                                // 2. Check the option was added to the collection
                                                Collection<Option> optionsAfter = optionGroup.getOptions();
                                                assertEquals(initialSize + 1, optionsAfter.size());
                                                
                                                // Verify the option is in the collection by checking its key via reflection
                                                boolean found = false;
                                                for (Option opt : optionsAfter) {
                                                    String key = (String) getKeyMethod.invoke(opt);
                                                    if ("testKey".equals(key)) {
                                                        found = true;
                                                        assertSame(option, opt);
                                                        break;
                                                    }
                                                }
                                                assertTrue(found);
                                                
                                                // 3. Ensure no option was stored with null key
                                                boolean hasNullKey = false;
                                                for (Option opt : optionsAfter) {
                                                    String key = (String) getKeyMethod.invoke(opt);
                                                    if (key == null) {
                                                        hasNullKey = true;
                                                        break;
                                                    }
                                                }
                                                assertFalse(hasNullKey);
                                            }

    @Test
                                    public void testAddOptionPreservesKeyCase() throws Exception {
                                        // Setup
                                        OptionGroup optionGroup = new OptionGroup();
                                        Option option = mock(Option.class);
                                        
                                        // Use reflection to set up the mock for getKey()
                                        Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                        getKeyMethod.setAccessible(true);
                                        when(getKeyMethod.invoke(option)).thenReturn("MixedCaseKey");
                                        
                                        // Execute
                                        OptionGroup result = optionGroup.addOption(option);
                                        
                                        // Verify
                                        assertEquals("Should return self for chaining", optionGroup, result);
                                        
                                        // Get the internal map
                                        Collection<String> keys = optionGroup.getNames();
                                        
                                        // Original behavior: key should be "MixedCaseKey"
                                        // Mutant behavior: key would be "mixedcasekey"
                                        assertTrue("Key should maintain original case", 
                                                  keys.contains("MixedCaseKey"));
                                        
                                        // Additional check to ensure the mutant would fail
                                        assertFalse("Key should not be lowercase (this would fail for mutant)", 
                                                   keys.contains("mixedcasekey"));
                                    }

    @Test
                            public void testAddOptionShouldCallPutExactlyOnce() throws Exception {
                                // Create mock dependencies
                                Map<String, Option> mockOptionMap = mock(Map.class);
                                Option mockOption = mock(Option.class);
                                
                                // Use reflection to mock getKey() since it's not public
                                Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                getKeyMethod.setAccessible(true);
                                when(getKeyMethod.invoke(mockOption)).thenReturn("testKey");
                                
                                // Create instance
                                OptionGroup optionGroup = new OptionGroup();
                                
                                // Use reflection to inject mock into private optionMap field
                                Field optionMapField = OptionGroup.class.getDeclaredField("optionMap");
                                optionMapField.setAccessible(true);
                                optionMapField.set(optionGroup, mockOptionMap);
                                
                                // Call the method
                                optionGroup.addOption(mockOption);
                                
                                // Verify the interaction - should be exactly one put call
                                verify(mockOptionMap, times(1)).put(eq("testKey"), eq(mockOption));
                                
                                // The mutant would call put twice and fail this verification
                            }

    @Test
                            public void testAddOptionShouldCallPutExactlyOnce1() throws Exception {
                                // Create mock dependencies
                                Map<String, Option> mockOptionMap = mock(Map.class);
                                Option mockOption = mock(Option.class);
                                
                                // Create instance
                                OptionGroup optionGroup = new OptionGroup();
                                
                                // Inject mock map using reflection
                                Field optionMapField = OptionGroup.class.getDeclaredField("optionMap");
                                optionMapField.setAccessible(true);
                                optionMapField.set(optionGroup, mockOptionMap);
                                
                                // Call the method
                                optionGroup.addOption(mockOption);
                                
                                // Verify the interaction - we don't need to know the exact key,
                                // just that put was called exactly once with the mockOption
                                verify(mockOptionMap, times(1)).put(anyString(), eq(mockOption));
                            }

    @Test
                    public void testAddOptionReturnValue() {
                        // Setup
                        OptionGroup optionGroup = new OptionGroup();
                        Option mockOption = mock(Option.class);
                        
                        // Exercise
                        OptionGroup returnedValue = optionGroup.addOption(mockOption);
                        
                        // Verify
                        assertNotNull("Returned value should not be null", returnedValue);
                        assertSame("Returned value should be the same instance as the OptionGroup", 
                                  optionGroup, returnedValue);
                        
                        // Additional verification that the option was actually added
                        assertTrue("Option should be added to the optionMap", 
                                  optionGroup.getOptions().contains(mockOption));
                    }

    @Test
            public void testAddOptionReturnValue1() {
                // Setup
                OptionGroup optionGroup = new OptionGroup();
                Option mockOption = mock(Option.class);
                
                // Exercise
                OptionGroup result = optionGroup.addOption(mockOption);
                
                // Verify
                assertNotNull("Return value should not be null", result);
                assertSame("Method should return 'this' for method chaining", optionGroup, result);
                
                // Additional verification that the option was actually added
                assertTrue("Option should be added to the map", 
                    optionGroup.getOptions().contains(mockOption));
            }

    @Test
    public void testAddOptionReturnsThis() {
        // Setup
        OptionGroup optionGroup = new OptionGroup();
        Option option = mock(Option.class);
        
        // Execute
        OptionGroup result = optionGroup.addOption(option);
        
        // Verify
        assertSame("addOption should return the same instance (this)", optionGroup, result);
        assertNotNull("Returned value should never be null", result);
    }


}
