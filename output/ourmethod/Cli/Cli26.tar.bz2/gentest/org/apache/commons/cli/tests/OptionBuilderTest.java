package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
 
public class OptionBuilderTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testCreate_WithShortOptOnly() {
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertNotNull(option);
                                                assertEquals("t", option.getOpt());
                                                assertNull(option.getLongOpt());
                                                assertEquals(0, option.getArgs());
                                                assertFalse(option.isRequired());
                                                assertNull(option.getDescription());
                                                assertNull(option.getArgName());
                                                assertEquals('=', option.getValueSeparator());
                                                assertFalse(option.hasOptionalArg());
                                            }

    @Test
                                            public void testCreate_WithLongOpt() {
                                                OptionBuilder.withLongOpt("test");
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertEquals("test", option.getLongOpt());
                                            }

    @Test
                                            public void testCreate_WithDescription() {
                                                OptionBuilder.withDescription("test description");
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertEquals("test description", option.getDescription());
                                            }

    @Test
                                            public void testCreate_WithArgName() {
                                                OptionBuilder.withArgName("argname");
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertEquals("argname", option.getArgName());
                                            }

    @Test
                                            public void testCreate_WhenRequired() {
                                                OptionBuilder.isRequired();
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertTrue(option.isRequired());
                                            }

    @Test
                                            public void testCreate_WithSingleArg() {
                                                OptionBuilder.hasArg();
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertEquals(1, option.getArgs());
                                            }

    @Test
                                            public void testCreate_WithMultipleArgs() {
                                                OptionBuilder.hasArgs(3);
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertEquals(3, option.getArgs());
                                            }

    @Test
                                            public void testCreate_WithUnlimitedArgs() {
                                                OptionBuilder.hasArgs();
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertEquals(Option.UNLIMITED_VALUES, option.getArgs());
                                            }

    @Test
                                            public void testCreate_WithOptionalArg() {
                                                OptionBuilder.hasOptionalArg();
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertTrue(option.hasOptionalArg());
                                                assertEquals(1, option.getArgs());
                                            }

    @Test
                                            public void testCreate_WithOptionalArgs() {
                                                OptionBuilder.hasOptionalArgs(2);
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertTrue(option.hasOptionalArg());
                                                assertEquals(2, option.getArgs());
                                            }

    @Test
                                            public void testCreate_WithValueSeparator() {
                                                OptionBuilder.withValueSeparator(':');
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertEquals(':', option.getValueSeparator());
                                            }

    @Test
                                            public void testCreate_WithDefaultValueSeparator() {
                                                OptionBuilder.withValueSeparator();
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertEquals('=', option.getValueSeparator());
                                            }

    @Test
                                            public void testCreate_WithType() {
                                                Object type = new Object();
                                                OptionBuilder.withType(type);
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertEquals(type, option.getType());
                                            }

    @Test
                                            public void testCreate_WithAllProperties() {
                                                Object type = new Object();
                                                OptionBuilder.withLongOpt("longopt")
                                                             .withDescription("description")
                                                             .withArgName("argname")
                                                             .isRequired()
                                                             .hasArgs(2)
                                                             .withValueSeparator(':')
                                                             .withType(type);
                                                
                                                Option option = OptionBuilder.create('t');
                                                
                                                assertEquals("t", option.getOpt());
                                                assertEquals("longopt", option.getLongOpt());
                                                assertEquals("description", option.getDescription());
                                                assertEquals("argname", option.getArgName());
                                                assertTrue(option.isRequired());
                                                assertEquals(2, option.getArgs());
                                                assertEquals(':', option.getValueSeparator());
                                                assertEquals(type, option.getType());
                                            }

    @Test
                                            public void testCreate_WithMinimumProperties() {
                                                char opt = 'm';
                                                
                                                Option option = OptionBuilder.create(opt);
                                                
                                                assertEquals(opt, option.getOpt());
                                                assertNull(option.getLongOpt());
                                                assertNull(option.getDescription());
                                                assertFalse(option.isRequired());
                                                assertEquals(1, option.getArgs()); // Default for hasArg() is 1
                                                assertNull(option.getType());
                                                assertEquals(0, option.getValueSeparator()); // Default is 0 (not set)
                                                assertNull(option.getArgName());
                                                assertFalse(option.hasOptionalArg());
                                            }

    @Test
                                            public void testCreate_WithOptionalArgs1() {
                                                char opt = 'o';
                                                int numArgs = 3;
                                                
                                                OptionBuilder.hasOptionalArgs(numArgs);
                                                Option option = OptionBuilder.create(opt);
                                                
                                                assertEquals(opt, option.getOpt());
                                                assertTrue(option.hasOptionalArg());
                                                assertEquals(numArgs, option.getArgs());
                                            }

    @Test
                                            public void testCreate_WithValueSeparatorNoArg() {
                                                char opt = 's';
                                                
                                                OptionBuilder.withValueSeparator();
                                                Option option = OptionBuilder.create(opt);
                                                
                                                assertEquals('=', option.getValueSeparator()); // Default separator
                                            }

    @Test
                                            public void testCreate_WithDifferentTypes() {
                                                char opt = 'y';
                                                Object[] types = {Integer.class, Boolean.class, Double.class};
                                                
                                                for (Object type : types) {
                                                    OptionBuilder.withType(type);
                                                    Option option = OptionBuilder.create(opt);
                                                    assertEquals(type, option.getType());
                                                }
                                            }

    @Test
                                            public void testCreate_WithStringOption() {
                                                String opt = "file";
                                                
                                                Option option = OptionBuilder.create(opt);
                                                
                                                assertEquals(opt, option.getOpt());
                                            }

    @Test
                                            public void testCreate_VerifiesResetCalled() {
                                                // Set some properties
                                                OptionBuilder.withLongOpt("test").withDescription("desc").isRequired(true);
                                                
                                                // Create should reset the builder
                                                Option option = OptionBuilder.create('r');
                                                
                                                // Verify subsequent create has no properties set
                                                Option option2 = OptionBuilder.create('s');
                                                assertNull(option2.getLongOpt());
                                                assertNull(option2.getDescription());
                                                assertFalse(option2.isRequired());
                                            }

    @Test
                                            public void testCreate_WithNegativeNumberOfArgs() {
                                                char opt = 'n';
                                                OptionBuilder.hasArgs(-1);
                                                
                                                Option option = OptionBuilder.create(opt);
                                                
                                                assertEquals(Option.UNLIMITED_VALUES, option.getArgs());
                                            }

    @Test
                                    public void testCreate_WhenLongOptIsNull_ShouldThrowIllegalArgumentException() throws Exception {
                                        // Setup
                                        // Use reflection to reset OptionBuilder
                                        Method resetMethod = OptionBuilder.class.getDeclaredMethod("reset");
                                        resetMethod.setAccessible(true);
                                        resetMethod.invoke(null);
                                        
                                        // Use reflection to set longopt to null
                                        Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
                                        longoptField.setAccessible(true);
                                        longoptField.set(null, null);
                                        
                                        // Setup exception expectations
                                        ExpectedException exception = ExpectedException.none();
                                        exception.expect(IllegalArgumentException.class);
                                        exception.expectMessage("must specify longopt");
                                        
                                        // Test
                                        OptionBuilder.create();
                                    }

    @Test
                                    public void testCreate_WhenLongOptIsNotNull_ShouldCallCreateWithNullOpt() throws Exception {
                                        // Setup
                                        // Use reflection to call private reset() method
                                        Method resetMethod = OptionBuilder.class.getDeclaredMethod("reset");
                                        resetMethod.setAccessible(true);
                                        resetMethod.invoke(null);
                                        
                                        // Use reflection to set private longopt field
                                        String expectedLongOpt = "testLongOpt";
                                        Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
                                        longoptField.setAccessible(true);
                                        longoptField.set(null, expectedLongOpt);
                                        
                                        // Mock the Option that would be returned by create(String)
                                        Option mockOption = mock(Option.class);
                                        
                                        // Spy on OptionBuilder to verify create(String) call
                                        OptionBuilder spyBuilder = spy(OptionBuilder.class);
                                        doReturn(mockOption).when(spyBuilder).create((String)null);
                                        
                                        // Test
                                        Option result = spyBuilder.create();
                                        
                                        // Verify
                                        verify(spyBuilder).create((String)null);
                                        assertEquals(mockOption, result);
                                    }

    @Test
                                    public void testCreate_WhenLongOptIsNotNull_ShouldResetBuilder() throws Exception {
                                        // Setup
                                        // Use reflection to reset OptionBuilder
                                        Method resetMethod = OptionBuilder.class.getDeclaredMethod("reset");
                                        resetMethod.setAccessible(true);
                                        resetMethod.invoke(null);
                                        
                                        String expectedLongOpt = "testLongOpt";
                                        // Set private fields using reflection
                                        Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
                                        longoptField.setAccessible(true);
                                        longoptField.set(null, expectedLongOpt);
                                        
                                        Field descriptionField = OptionBuilder.class.getDeclaredField("description");
                                        descriptionField.setAccessible(true);
                                        descriptionField.set(null, "testDescription");
                                        
                                        Field requiredField = OptionBuilder.class.getDeclaredField("required");
                                        requiredField.setAccessible(true);
                                        requiredField.set(null, true);
                                        
                                        // Mock the Option that would be returned by create(String)
                                        Option mockOption = mock(Option.class);
                                        
                                        // Spy on OptionBuilder to verify reset is called
                                        OptionBuilder spyBuilder = spy(OptionBuilder.class);
                                        doReturn(mockOption).when(spyBuilder).create((String)null);
                                        
                                        // Test
                                        spyBuilder.create();
                                        
                                        // Verify that reset was called (indirectly by checking fields are cleared)
                                        assertNull(longoptField.get(null));
                                        assertNull(descriptionField.get(null));
                                        assertFalse(requiredField.getBoolean(null));
                                    }

    @Test
                                    public void testCreate_WithAllPropertiesSet() {
                                        // Setup test data
                                        char opt = 't';
                                        String longOpt = "test";
                                        String description = "Test option";
                                        boolean required = true;
                                        boolean optionalArg = false;
                                        int numberOfArgs = 2;
                                        Object type = String.class;
                                        char valueSep = '=';
                                        String argName = "testArg";
                                        
                                        // Set OptionBuilder properties
                                        OptionBuilder.withLongOpt(longOpt);
                                        OptionBuilder.withDescription(description);
                                        OptionBuilder.isRequired(required);
                                        OptionBuilder.hasArgs(numberOfArgs);
                                        OptionBuilder.withType(type);
                                        OptionBuilder.withValueSeparator(valueSep);
                                        OptionBuilder.withArgName(argName);
                                        // hasOptionalArg(boolean) not available, using hasOptionalArg() instead
                                        if (optionalArg) {
                                            OptionBuilder.hasOptionalArg();
                                        }
                                        
                                        // Call the method
                                        Option option = OptionBuilder.create(opt);
                                        
                                        // Verify the Option properties
                                        assertEquals(opt, option.getOpt());
                                        assertEquals(longOpt, option.getLongOpt());
                                        assertEquals(description, option.getDescription());
                                        assertEquals(required, option.isRequired());
                                        assertEquals(numberOfArgs, option.getArgs());
                                        assertEquals(type, option.getType());
                                        assertEquals(valueSep, option.getValueSeparator());
                                        assertEquals(argName, option.getArgName());
                                        assertEquals(optionalArg, option.hasOptionalArg());
                                        
                                        // Verify reset was called (indirectly by checking properties are cleared)
                                        assertNull(OptionBuilder.create('x').getLongOpt());
                                    }

    @Test(expected = IllegalArgumentException.class)
                                    public void testCreate_WithEmptyOption() {
                                        OptionBuilder.create();
                                    }

    @Test
                                    public void testCreate_WithEmptyStringOption() {
                                        ExpectedException exception = ExpectedException.none();
                                        exception.expect(IllegalArgumentException.class);
                                        OptionBuilder.create("");
                                    }

    @Test
                                    public void testCreate_WithNullStringOption() {
                                        ExpectedException exception = ExpectedException.none();
                                        exception.expect(IllegalArgumentException.class);
                                        OptionBuilder.create((String)null);
                                    }

    @Test
                                public void testCreate_WithInvalidShortOpt() {
                                    ExpectedException exception = ExpectedException.none();
                                    exception.expect(IllegalArgumentException.class);
                                    OptionBuilder.create('\0'); // null character as char
                                }

    @Test
                public void testCreateWithNullLongOptShouldCallResetExactlyOnce() throws Exception {
                    // Setup - clear any existing state
                    Method resetMethod = OptionBuilder.class.getDeclaredMethod("reset");
                    resetMethod.setAccessible(true);
                    resetMethod.invoke(null);
                    
                    // Set some state that should be cleared by reset()
                    OptionBuilder.withLongOpt("test");
                    
                    try {
                        OptionBuilder.withLongOpt(null);  // This should trigger create() internally
                        fail("Expected IllegalArgumentException");
                    } catch (IllegalArgumentException e) {
                        // Verify state was cleared by checking longopt is null
                        Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
                        longoptField.setAccessible(true);
                        assertNull(longoptField.get(null));
                    }
                }

    @Test
        public void testCreateShouldCallResetExactlyOnce1() throws Exception {
            // Set some state to verify it gets reset
            OptionBuilder.withLongOpt("test");
            OptionBuilder.isRequired(true);
            OptionBuilder.hasArg();
            
            // Call the method under test
            Option option = OptionBuilder.create('t');
            
            // Verify the state was actually reset by checking the created option
            assertNull(option.getLongOpt());  // Should be null as reset clears longopt
            assertFalse(option.isRequired()); // Should be false as reset clears required
            assertEquals(0, option.getArgs()); // Should be 0 as reset clears numberOfArgs
            
            // Verify the option has the correct opt value
            assertEquals("t", option.getOpt());
        }

    @Test
    public void testCreateShouldCallResetExactlyOnce() throws Exception {
        // Set some state to verify it gets reset
        OptionBuilder.withLongOpt("test");
        OptionBuilder.isRequired(true);
        OptionBuilder.hasArg();
        
        // Call the method under test
        Option option = OptionBuilder.create('t');
        
        // Verify the state was actually reset by checking the created option
        assertNull(option.getLongOpt());  // Should be null as reset clears longopt
        assertFalse(option.isRequired()); // Should be false as reset clears required
        assertEquals(0, option.getArgs()); // Should be 0 as reset clears numberOfArgs
        
        // Verify the option has the correct opt value
        assertEquals("t", option.getOpt());
    }


}
