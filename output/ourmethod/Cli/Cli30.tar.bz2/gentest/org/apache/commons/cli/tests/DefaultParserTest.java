package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
 
public class DefaultParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                public void testIsArgument_WhenTokenIsNotOptionAndNotNegativeNumber() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Use reflection to access private methods
                                                                                                                                                                                                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                    isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                    isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Mock the behavior using reflection
                                                                                                                                                                                                                                                    DefaultParser spyParser = spy(parser);
                                                                                                                                                                                                                                                    when(isOptionMethod.invoke(spyParser, "regularToken")).thenReturn(false);
                                                                                                                                                                                                                                                    when(isNegativeNumberMethod.invoke(spyParser, "regularToken")).thenReturn(false);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertTrue((Boolean) isArgumentMethod.invoke(spyParser, "regularToken"));
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testIsArgument_WhenTokenIsOptionButNegativeNumber() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get private methods via reflection
                                                                                                                                                                                                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                    isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                    isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Mock the behavior using reflection
                                                                                                                                                                                                                                                    // Note: We can't actually mock these methods since they're private
                                                                                                                                                                                                                                                    // Instead, we'll test the actual implementation with our input
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // The test assumes that "-123" is both an option and a negative number
                                                                                                                                                                                                                                                    // In reality, we need to verify the actual behavior
                                                                                                                                                                                                                                                    boolean isOption = (boolean) isOptionMethod.invoke(parser, "-123");
                                                                                                                                                                                                                                                    boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, "-123");
                                                                                                                                                                                                                                                    boolean isArgument = (boolean) isArgumentMethod.invoke(parser, "-123");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // The assertion depends on the actual implementation logic
                                                                                                                                                                                                                                                    // If isArgument should return true when it's both an option and negative number
                                                                                                                                                                                                                                                    assertTrue(isArgument);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testIsArgument_WhenTokenIsOptionAndNotNegativeNumber() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Use reflection to access private methods
                                                                                                                                                                                                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                    isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                    isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Mock the behavior using reflection
                                                                                                                                                                                                                                                    DefaultParser spyParser = spy(parser);
                                                                                                                                                                                                                                                    when(isOptionMethod.invoke(spyParser, "-option")).thenReturn(true);
                                                                                                                                                                                                                                                    when(isNegativeNumberMethod.invoke(spyParser, "-option")).thenReturn(false);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertFalse((Boolean) isArgumentMethod.invoke(spyParser, "-option"));
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testIsArgument_WhenTokenIsNotOptionButNegativeNumber() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get private methods via reflection
                                                                                                                                                                                                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                    isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                    isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Create spy after setting methods accessible
                                                                                                                                                                                                                                                    DefaultParser spyParser = spy(parser);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Mock the private method calls
                                                                                                                                                                                                                                                    when(isOptionMethod.invoke(spyParser, "-456")).thenReturn(false);
                                                                                                                                                                                                                                                    when(isNegativeNumberMethod.invoke(spyParser, "-456")).thenReturn(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertTrue((Boolean) isArgumentMethod.invoke(spyParser, "-456"));
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testIsArgument_WhenTokenIsEmptyString() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get private methods via reflection
                                                                                                                                                                                                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                    isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                    isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Mock the behavior of private methods using reflection
                                                                                                                                                                                                                                                    DefaultParser spyParser = spy(parser);
                                                                                                                                                                                                                                                    when(isOptionMethod.invoke(spyParser, "")).thenReturn(false);
                                                                                                                                                                                                                                                    when(isNegativeNumberMethod.invoke(spyParser, "")).thenReturn(false);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Verify the result
                                                                                                                                                                                                                                                    assertTrue((Boolean) isArgumentMethod.invoke(spyParser, ""));
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testIsArgument_WhenTokenIsPositiveNumber() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get private methods via reflection
                                                                                                                                                                                                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                                    isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                    isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Mock the behavior of private methods using reflection
                                                                                                                                                                                                                                                    DefaultParser spyParser = spy(parser);
                                                                                                                                                                                                                                                    when(isOptionMethod.invoke(spyParser, "123")).thenReturn(false);
                                                                                                                                                                                                                                                    when(isNegativeNumberMethod.invoke(spyParser, "123")).thenReturn(false);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Verify the result
                                                                                                                                                                                                                                                    assertTrue((Boolean) isArgumentMethod.invoke(spyParser, "123"));
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testIsNegativeNumber_ValidNegativeNumbers() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-1"));
                                                                                                                                                                                                                                                    assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-0.5"));
                                                                                                                                                                                                                                                    assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-123.456"));
                                                                                                                                                                                                                                                    assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-1e10"));
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testIsNegativeNumber_ValidPositiveNumbers() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get the private method using reflection
                                                                                                                                                                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Test with positive numbers (should return false)
                                                                                                                                                                                                                                                    assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1"));
                                                                                                                                                                                                                                                    assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "0.5"));
                                                                                                                                                                                                                                                    assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "123.456"));
                                                                                                                                                                                                                                                    assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1e10"));
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testIsNegativeNumber_ZeroValues() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "0"));
                                                                                                                                                                                                                                                    assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "0.0"));
                                                                                                                                                                                                                                                    assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-0"));
                                                                                                                                                                                                                                                    assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-0.0"));
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testIsNegativeNumber_InvalidNumberStrings() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "abc"));
                                                                                                                                                                                                                                                    assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "123abc"));
                                                                                                                                                                                                                                                    assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "--1"));
                                                                                                                                                                                                                                                    assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1-"));
                                                                                                                                                                                                                                                    assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1.2.3"));
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testIsNegativeNumber_EmptyString() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                                    boolean result = (boolean) isNegativeNumberMethod.invoke(parser, "");
                                                                                                                                                                                                                                                    assertFalse(result);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testIsNegativeNumber_NullString() throws Exception {
                                                                                                                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                    Method method = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                                                                                    thrown.expect(NullPointerException.class);
                                                                                                                                                                                                                                                    method.invoke(parser, (String) null);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                            public void testIsArgument_WhenTokenIsNull() throws Exception {
                                                                                                                                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                                                expectedException.expect(NullPointerException.class);
                                                                                                                                                                                                                                                isArgumentMethod.invoke(parser, (String) null);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                    public void testIsArgumentDetectsMutant() throws Exception {
                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Get private methods via reflection
                                                                                                                                                                                                                                        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                        isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                        isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Case 1: Regular option (should return false in original, true in mutant)
                                                                                                                                                                                                                                        when((Boolean) isOptionMethod.invoke(parser, "-a")).thenReturn(true);
                                                                                                                                                                                                                                        when((Boolean) isNegativeNumberMethod.invoke(parser, "-a")).thenReturn(false);
                                                                                                                                                                                                                                        assertFalse("Regular option should not be considered argument", 
                                                                                                                                                                                                                                                   (Boolean) isArgumentMethod.invoke(parser, "-a"));
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Case 2: Negative number (should return true in both)
                                                                                                                                                                                                                                        when((Boolean) isOptionMethod.invoke(parser, "-1")).thenReturn(false);
                                                                                                                                                                                                                                        when((Boolean) isNegativeNumberMethod.invoke(parser, "-1")).thenReturn(true);
                                                                                                                                                                                                                                        assertTrue("Negative number should be considered argument", 
                                                                                                                                                                                                                                                  (Boolean) isArgumentMethod.invoke(parser, "-1"));
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Case 3: Non-option argument (should return true in original, false in mutant)
                                                                                                                                                                                                                                        when((Boolean) isOptionMethod.invoke(parser, "arg")).thenReturn(false);
                                                                                                                                                                                                                                        when((Boolean) isNegativeNumberMethod.invoke(parser, "arg")).thenReturn(false);
                                                                                                                                                                                                                                        assertTrue("Non-option should be considered argument", 
                                                                                                                                                                                                                                                  (Boolean) isArgumentMethod.invoke(parser, "arg"));
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Case 4: Option that's also negative number (edge case)
                                                                                                                                                                                                                                        when((Boolean) isOptionMethod.invoke(parser, "-1")).thenReturn(true);
                                                                                                                                                                                                                                        when((Boolean) isNegativeNumberMethod.invoke(parser, "-1")).thenReturn(true);
                                                                                                                                                                                                                                        assertTrue("Option that's negative number should be considered argument", 
                                                                                                                                                                                                                                                  (Boolean) isArgumentMethod.invoke(parser, "-1"));
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                            public void testIsArgumentDetectsMutant1() throws Exception {
                                                                                                                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Get private methods via reflection
                                                                                                                                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Set methods accessible
                                                                                                                                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                                isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Case 1: Token is not an option but not a negative number
                                                                                                                                                                                                                                // We can't mock private methods, so we have to rely on actual implementation
                                                                                                                                                                                                                                // This assumes the actual implementation behaves as expected for these cases
                                                                                                                                                                                                                                assertTrue("Should return true for non-option tokens", 
                                                                                                                                                                                                                                    (boolean) isArgumentMethod.invoke(parser, "plaintext"));
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Case 2: Token is an option but is a negative number
                                                                                                                                                                                                                                assertTrue("Should return true for negative number options", 
                                                                                                                                                                                                                                    (boolean) isArgumentMethod.invoke(parser, "-1"));
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Case 3: Token is both not an option and a negative number
                                                                                                                                                                                                                                assertTrue("Should return true for negative non-option numbers", 
                                                                                                                                                                                                                                    (boolean) isArgumentMethod.invoke(parser, "-123"));
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Case 4: Token is neither (an option and not a negative number)
                                                                                                                                                                                                                                assertFalse("Should return false for regular options", 
                                                                                                                                                                                                                                    (boolean) isArgumentMethod.invoke(parser, "-option"));
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                    public void testIsArgumentDetectsMutant2() throws Exception {
                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Get private methods via reflection
                                                                                                                                                                                                                        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                                                        isOptionMethod.setAccessible(true);
                                                                                                                                                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                                                        isArgumentMethod.setAccessible(true);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Case 1: Non-option token (should be true in original, false in mutant)
                                                                                                                                                                                                                        String nonOption = "filename";
                                                                                                                                                                                                                        when((Boolean) isOptionMethod.invoke(parser, nonOption)).thenReturn(false);
                                                                                                                                                                                                                        when((Boolean) isNegativeNumberMethod.invoke(parser, nonOption)).thenReturn(false);
                                                                                                                                                                                                                        assertTrue("Non-option token should be considered argument", 
                                                                                                                                                                                                                                  (Boolean) isArgumentMethod.invoke(parser, nonOption));
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Case 2: Negative number that's not an option (should be true in original, false in mutant)
                                                                                                                                                                                                                        String negativeNumber = "-123";
                                                                                                                                                                                                                        when((Boolean) isOptionMethod.invoke(parser, negativeNumber)).thenReturn(false);
                                                                                                                                                                                                                        when((Boolean) isNegativeNumberMethod.invoke(parser, negativeNumber)).thenReturn(true);
                                                                                                                                                                                                                        assertTrue("Negative number should be considered argument", 
                                                                                                                                                                                                                                  (Boolean) isArgumentMethod.invoke(parser, negativeNumber));
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Case 3: Regular option (should be false in both)
                                                                                                                                                                                                                        String regularOption = "-f";
                                                                                                                                                                                                                        when((Boolean) isOptionMethod.invoke(parser, regularOption)).thenReturn(true);
                                                                                                                                                                                                                        when((Boolean) isNegativeNumberMethod.invoke(parser, regularOption)).thenReturn(false);
                                                                                                                                                                                                                        assertFalse("Regular option should not be considered argument", 
                                                                                                                                                                                                                                   (Boolean) isArgumentMethod.invoke(parser, regularOption));
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Case 4: Option that's a negative number (true in both - won't detect mutant)
                                                                                                                                                                                                                        String negativeOption = "-123";
                                                                                                                                                                                                                        when((Boolean) isOptionMethod.invoke(parser, negativeOption)).thenReturn(true);
                                                                                                                                                                                                                        when((Boolean) isNegativeNumberMethod.invoke(parser, negativeOption)).thenReturn(true);
                                                                                                                                                                                                                        assertTrue("Negative number option should be considered argument", 
                                                                                                                                                                                                                                  (Boolean) isArgumentMethod.invoke(parser, negativeOption));
                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                            public void testIsArgumentWithNegativeNumberOption() throws Exception {
                                                                                                                                                                                // Setup
                                                                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                                                                String negativeNumberOption = "-1"; // This could be both an option and negative number
                                                                                                                                                                                
                                                                                                                                                                                // Get private methods via reflection
                                                                                                                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                                                isOptionMethod.setAccessible(true);
                                                                                                                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                                                                                
                                                                                                                                                                                // Create spy
                                                                                                                                                                                DefaultParser spyParser = spy(parser);
                                                                                                                                                                                
                                                                                                                                                                                // Mock the behavior by using reflection to invoke the private methods
                                                                                                                                                                                when(isOptionMethod.invoke(spyParser, negativeNumberOption)).thenReturn(true);
                                                                                                                                                                                when(isNegativeNumberMethod.invoke(spyParser, negativeNumberOption)).thenReturn(true);
                                                                                                                                                                                
                                                                                                                                                                                // Test
                                                                                                                                                                                boolean result = (boolean) isArgumentMethod.invoke(spyParser, negativeNumberOption);
                                                                                                                                                                                assertTrue("Should return true for negative number even when it's an option", result);
                                                                                                                                                                            }

    @Test
                                                                                                                                                                    public void testIsArgument_NonOptionNonNegativeNumber_ShouldReturnTrue() throws Exception {
                                                                                                                                                                        // Arrange
                                                                                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                                                                                        String testToken = "regularArgument";
                                                                                                                                                                        
                                                                                                                                                                        // Get private method via reflection
                                                                                                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                                        isArgumentMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // We can't directly mock private methods, so we'll assume the implementation
                                                                                                                                                                        // correctly calls isOption() and isNegativeNumber() internally
                                                                                                                                                                        
                                                                                                                                                                        // Act
                                                                                                                                                                        boolean result = (boolean) isArgumentMethod.invoke(parser, testToken);
                                                                                                                                                                        
                                                                                                                                                                        // Assert
                                                                                                                                                                        assertTrue("Should return true for non-option, non-negative number", result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testIsArgumentWithNegativeNumberOption1() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                                                                        String negativeOption = "-1";
                                                                                                                                                        
                                                                                                                                                        // Get private methods via reflection
                                                                                                                                                        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                        isOptionMethod.setAccessible(true);
                                                                                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                        isArgumentMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Create spy to mock the behavior of private methods
                                                                                                                                                        DefaultParser spyParser = spy(parser);
                                                                                                                                                        when(isOptionMethod.invoke(spyParser, negativeOption)).thenReturn(true);
                                                                                                                                                        when(isNegativeNumberMethod.invoke(spyParser, negativeOption)).thenReturn(true);
                                                                                                                                                        
                                                                                                                                                        // Test and verify
                                                                                                                                                        assertTrue("Should return true for negative number option", 
                                                                                                                                                                  (Boolean) isArgumentMethod.invoke(spyParser, negativeOption));
                                                                                                                                                        
                                                                                                                                                        // Remove the verify calls for private methods as they can't be verified directly
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testIsArgumentWithPositiveNumberOption() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                                                                        String positiveOption = "1";
                                                                                                                                                        
                                                                                                                                                        // Get private methods via reflection
                                                                                                                                                        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                                        isOptionMethod.setAccessible(true);
                                                                                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                                        isArgumentMethod.setAccessible(true);
                                                                                                                                                        
                                                                                                                                                        // Create spy to mock the behavior of private methods
                                                                                                                                                        DefaultParser spyParser = spy(parser);
                                                                                                                                                        when(isOptionMethod.invoke(spyParser, positiveOption)).thenReturn(true);
                                                                                                                                                        when(isNegativeNumberMethod.invoke(spyParser, positiveOption)).thenReturn(false);
                                                                                                                                                        
                                                                                                                                                        // Test
                                                                                                                                                        boolean result = (boolean) isArgumentMethod.invoke(spyParser, positiveOption);
                                                                                                                                                        
                                                                                                                                                        // Verify
                                                                                                                                                        assertFalse("Should return false for positive number option", result);
                                                                                                                                                        
                                                                                                                                                        // Verify interactions through reflection
                                                                                                                                                        verify(spyParser, times(1));
                                                                                                                                                        isOptionMethod.invoke(spyParser, positiveOption);
                                                                                                                                                        isNegativeNumberMethod.invoke(spyParser, positiveOption);
                                                                                                                                                    }

    @Test
                                                                                                                            public void testIsArgumentWithNonOption() throws Exception {
                                                                                                                                // Setup
                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                String nonOption = "regularArgument";
                                                                                                                                
                                                                                                                                // Get private methods via reflection
                                                                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                                isOptionMethod.setAccessible(true);
                                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // Create spy after setting methods accessible
                                                                                                                                DefaultParser spyParser = spy(parser);
                                                                                                                                
                                                                                                                                // Mock the behavior using reflection invocation
                                                                                                                                when(isOptionMethod.invoke(spyParser, nonOption)).thenReturn(false);
                                                                                                                                when(isNegativeNumberMethod.invoke(spyParser, nonOption)).thenReturn(false);
                                                                                                                                
                                                                                                                                // Test and verify
                                                                                                                                assertTrue("Should return true for non-option token", 
                                                                                                                                          (Boolean) isArgumentMethod.invoke(spyParser, nonOption));
                                                                                                                                
                                                                                                                                // Remove the verification of private methods as they can't be verified directly
                                                                                                                                // The test still validates the behavior through the reflection invocation
                                                                                                                            }

    @Test
                                                                                                                    public void testIsArgumentDetectsMutant3() throws Exception {
                                                                                                                        // Create instance of DefaultParser
                                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                                        
                                                                                                                        // Get private methods via reflection
                                                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                        
                                                                                                                        // Set methods accessible
                                                                                                                        isArgumentMethod.setAccessible(true);
                                                                                                                        isOptionMethod.setAccessible(true);
                                                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                                                        
                                                                                                                        // Create a spy to mock the private method calls
                                                                                                                        DefaultParser spyParser = spy(parser);
                                                                                                                        
                                                                                                                        // Case 1: Not an option, not negative number - original returns true, mutant returns false
                                                                                                                        when(isOptionMethod.invoke(spyParser, "plaintext")).thenReturn(false);
                                                                                                                        when(isNegativeNumberMethod.invoke(spyParser, "plaintext")).thenReturn(false);
                                                                                                                        assertTrue("Non-option should be argument", (Boolean) isArgumentMethod.invoke(spyParser, "plaintext"));
                                                                                                                        
                                                                                                                        // Case 2: Not an option, is negative number - original returns true, mutant returns false
                                                                                                                        when(isOptionMethod.invoke(spyParser, "-123")).thenReturn(false);
                                                                                                                        when(isNegativeNumberMethod.invoke(spyParser, "-123")).thenReturn(true);
                                                                                                                        assertTrue("Negative number should be argument", (Boolean) isArgumentMethod.invoke(spyParser, "-123"));
                                                                                                                        
                                                                                                                        // Case 3: Is an option, not negative number - original returns false, mutant returns true
                                                                                                                        when(isOptionMethod.invoke(spyParser, "-f")).thenReturn(true);
                                                                                                                        when(isNegativeNumberMethod.invoke(spyParser, "-f")).thenReturn(false);
                                                                                                                        assertFalse("Option should not be argument", (Boolean) isArgumentMethod.invoke(spyParser, "-f"));
                                                                                                                        
                                                                                                                        // Case 4: Is an option, is negative number - original returns true, mutant returns false
                                                                                                                        // This is the key test that will detect the mutant
                                                                                                                        when(isOptionMethod.invoke(spyParser, "-123")).thenReturn(true);
                                                                                                                        when(isNegativeNumberMethod.invoke(spyParser, "-123")).thenReturn(true);
                                                                                                                        assertTrue("Negative number option should be argument", (Boolean) isArgumentMethod.invoke(spyParser, "-123"));
                                                                                                                    }

    @Test
                                                                                                            public void testIsArgument_ShouldReturnFalseForOptionThatIsNotNegativeNumber() throws Exception {
                                                                                                                // Setup
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Get private methods via reflection
                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                
                                                                                                                // Make methods accessible
                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                isOptionMethod.setAccessible(true);
                                                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                                                
                                                                                                                String optionToken = "-option";
                                                                                                                
                                                                                                                // Mock the behavior by stubbing the private methods
                                                                                                                // Since we can't mock private methods directly, we'll need to test the actual behavior
                                                                                                                // First verify isOption returns true and isNegativeNumber returns false for our token
                                                                                                                boolean isOption = (boolean) isOptionMethod.invoke(parser, optionToken);
                                                                                                                boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, optionToken);
                                                                                                                
                                                                                                                // Then test isArgument
                                                                                                                boolean result = (boolean) isArgumentMethod.invoke(parser, optionToken);
                                                                                                                
                                                                                                                // Verify the expected behavior
                                                                                                                assertTrue("Token should be recognized as option", isOption);
                                                                                                                assertFalse("Token should not be recognized as negative number", isNegativeNumber);
                                                                                                                assertFalse("Should return false for option that is not negative number", result);
                                                                                                            }

    @Test
                                                                                                    public void testIsArgumentWithNonOptionShouldReturnTrue() throws Exception {
                                                                                                        // Setup
                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                        String nonOptionToken = "regularArgument";
                                                                                                        
                                                                                                        // Get private method via reflection
                                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                        isArgumentMethod.setAccessible(true);
                                                                                                        
                                                                                                        // Test - should return true for non-option argument
                                                                                                        boolean result = (Boolean) isArgumentMethod.invoke(parser, nonOptionToken);
                                                                                                        assertTrue(result);
                                                                                                        
                                                                                                        // Note: Can't verify private method calls without reflection, which would be too intrusive
                                                                                                        // The original test's verification of internal calls is not practical for private methods
                                                                                                    }

    @Test
                                                                                                    public void testIsArgumentWithPositiveOptionShouldReturnFalse() throws Exception {
                                                                                                        // Setup
                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                        String optionToken = "-a";
                                                                                                        
                                                                                                        // Get private methods via reflection
                                                                                                        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                        isOptionMethod.setAccessible(true);
                                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                        isArgumentMethod.setAccessible(true);
                                                                                                        
                                                                                                        // Create spy and mock behavior
                                                                                                        DefaultParser spyParser = spy(parser);
                                                                                                        when(isOptionMethod.invoke(spyParser, optionToken)).thenReturn(true);
                                                                                                        when(isNegativeNumberMethod.invoke(spyParser, optionToken)).thenReturn(false);
                                                                                                        
                                                                                                        // Test and verify
                                                                                                        assertFalse((Boolean) isArgumentMethod.invoke(spyParser, optionToken));
                                                                                                    }

    @Test
                                                                                        public void testIsArgumentWithNegativeNumberShouldReturnTrue() throws Exception {
                                                                                            // Setup
                                                                                            DefaultParser parser = new DefaultParser();
                                                                                            String negativeNumberToken = "-123";
                                                                                            
                                                                                            // Get private methods via reflection
                                                                                            Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                            Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                            Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                            
                                                                                            // Make methods accessible
                                                                                            isArgumentMethod.setAccessible(true);
                                                                                            isOptionMethod.setAccessible(true);
                                                                                            isNegativeNumberMethod.setAccessible(true);
                                                                                            
                                                                                            // Create spy and mock behavior
                                                                                            DefaultParser spyParser = spy(parser);
                                                                                            when(isOptionMethod.invoke(spyParser, negativeNumberToken)).thenReturn(false);
                                                                                            when(isNegativeNumberMethod.invoke(spyParser, negativeNumberToken)).thenReturn(true);
                                                                                            
                                                                                            // Test and verify
                                                                                            assertTrue((Boolean) isArgumentMethod.invoke(spyParser, negativeNumberToken));
                                                                                            
                                                                                            // Verify interactions through reflection
                                                                                            verify(spyParser, times(1)).parse(any(Options.class), any(String[].class)); // Verify some public method was called
                                                                                            // Alternative verification through reflection
                                                                                            assertEquals(false, isOptionMethod.invoke(spyParser, negativeNumberToken));
                                                                                            assertEquals(true, isNegativeNumberMethod.invoke(spyParser, negativeNumberToken));
                                                                                        }

    @Test
                                                                                public void testIsArgument_NonOptionToken_ShouldReturnTrue() throws Exception {
                                                                                    // Setup
                                                                                    DefaultParser parser = new DefaultParser();
                                                                                    String nonOptionToken = "plainArgument";
                                                                                    
                                                                                    // Get private methods via reflection
                                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                    isOptionMethod.setAccessible(true);
                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                    isArgumentMethod.setAccessible(true);
                                                                                    
                                                                                    // Since we can't mock private methods, we'll test the actual implementation
                                                                                    // with the knowledge that isOption and isNegativeNumber will return false for "plainArgument"
                                                                                    boolean result = (boolean) isArgumentMethod.invoke(parser, nonOptionToken);
                                                                                    assertTrue(result);
                                                                                }

    @Test
                                                                                public void testIsArgument_NegativeNumber_ShouldReturnTrue() throws Exception {
                                                                                    // Setup
                                                                                    DefaultParser parser = new DefaultParser();
                                                                                    String negativeNumber = "-123";
                                                                                    
                                                                                    // Get private methods via reflection
                                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                    isOptionMethod.setAccessible(true);
                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                    isArgumentMethod.setAccessible(true);
                                                                                    
                                                                                    // Create spy parser
                                                                                    DefaultParser spyParser = spy(parser);
                                                                                    
                                                                                    // Mock the behavior using reflection-invoked methods
                                                                                    when(isOptionMethod.invoke(spyParser, negativeNumber)).thenReturn(true);
                                                                                    when(isNegativeNumberMethod.invoke(spyParser, negativeNumber)).thenReturn(true);
                                                                                    
                                                                                    // Test
                                                                                    assertTrue((Boolean) isArgumentMethod.invoke(spyParser, negativeNumber));
                                                                                }

    @Test
                                                                                public void testIsArgument_OptionToken_ShouldReturnFalse() throws Exception {
                                                                                    // Setup
                                                                                    DefaultParser parser = new DefaultParser();
                                                                                    String optionToken = "-a";
                                                                                    
                                                                                    // Get private methods via reflection
                                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                    isOptionMethod.setAccessible(true);
                                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                    isArgumentMethod.setAccessible(true);
                                                                                    
                                                                                    // Create spy and mock behavior using reflection
                                                                                    DefaultParser spyParser = spy(parser);
                                                                                    when(isOptionMethod.invoke(spyParser, optionToken)).thenReturn(true);
                                                                                    when(isNegativeNumberMethod.invoke(spyParser, optionToken)).thenReturn(false);
                                                                                    
                                                                                    // Test
                                                                                    assertFalse((Boolean) isArgumentMethod.invoke(spyParser, optionToken));
                                                                                }

    @Test
                                                                        public void testIsArgumentWithNegativeNumber() throws Exception {
                                                                            // Setup
                                                                            DefaultParser parser = new DefaultParser();
                                                                            String negativeNumberToken = "-123";
                                                                            
                                                                            // Get private methods via reflection
                                                                            Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                            isOptionMethod.setAccessible(true);
                                                                            Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                            isNegativeNumberMethod.setAccessible(true);
                                                                            Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                            isArgumentMethod.setAccessible(true);
                                                                            
                                                                            // Test and verify
                                                                            boolean isOption = (boolean) isOptionMethod.invoke(parser, negativeNumberToken);
                                                                            boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, negativeNumberToken);
                                                                            boolean isArgument = (boolean) isArgumentMethod.invoke(parser, negativeNumberToken);
                                                                            
                                                                            // Assert that it's not an option but is a negative number
                                                                            assertFalse("Should not be an option", isOption);
                                                                            assertTrue("Should be a negative number", isNegativeNumber);
                                                                            assertTrue("Should return true for negative numbers", isArgument);
                                                                        }

    @Test
                                                                public void testIsArgument_ShouldReturnFalseForOptionThatIsNotNegativeNumber1() throws Exception {
                                                                    // Setup
                                                                    DefaultParser parser = new DefaultParser();
                                                                    String token = "-option";
                                                                    
                                                                    // Get private methods via reflection
                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                    
                                                                    // Make methods accessible
                                                                    isArgumentMethod.setAccessible(true);
                                                                    isOptionMethod.setAccessible(true);
                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                    
                                                                    // Verify the behavior of isOption and isNegativeNumber
                                                                    boolean isOption = (boolean) isOptionMethod.invoke(parser, token);
                                                                    boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, token);
                                                                    
                                                                    // Test isArgument
                                                                    boolean result = (boolean) isArgumentMethod.invoke(parser, token);
                                                                    
                                                                    // Assertions
                                                                    assertTrue("Token should be recognized as option", isOption);
                                                                    assertFalse("Token should not be recognized as negative number", isNegativeNumber);
                                                                    assertFalse("Should return false for option that's not negative number", result);
                                                                }

    @Test
                                                    public void testIsArgumentWithNegativeNumberOption2() throws Exception {
                                                        // Setup
                                                        DefaultParser parser = new DefaultParser();
                                                        
                                                        // Get private methods via reflection
                                                        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                        isOptionMethod.setAccessible(true);
                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                        isNegativeNumberMethod.setAccessible(true);
                                                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                        isArgumentMethod.setAccessible(true);
                                                        
                                                        String negativeOption = "-123"; // Example negative number option
                                                        
                                                        // Create spy after setting methods accessible
                                                        DefaultParser spyParser = spy(parser);
                                                        
                                                        // Mock the private method calls
                                                        when(isOptionMethod.invoke(spyParser, negativeOption)).thenReturn(true);
                                                        when(isNegativeNumberMethod.invoke(spyParser, negativeOption)).thenReturn(true);
                                                        
                                                        // Test - should return true for negative number options
                                                        assertTrue((Boolean) isArgumentMethod.invoke(spyParser, negativeOption));
                                                        
                                                        // Verify interactions through reflection
                                                        verify(spyParser, times(1)).parse(any(Options.class), any(String[].class)); // Verify some public method was called
                                                        // Alternative verification through reflection
                                                        assertTrue((Boolean) isOptionMethod.invoke(spyParser, negativeOption));
                                                        assertTrue((Boolean) isNegativeNumberMethod.invoke(spyParser, negativeOption));
                                                    }

    @Test
                                            public void testIsArgumentWithNegativeNumberOption3() throws Exception {
                                                // Setup
                                                DefaultParser parser = new DefaultParser();
                                                
                                                // Create a token that is both an option and a negative number
                                                String negativeOption = "-1";
                                                
                                                // Get the private isArgument method using reflection
                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                isArgumentMethod.setAccessible(true);
                                                
                                                // Invoke the private method
                                                boolean result = (boolean) isArgumentMethod.invoke(parser, negativeOption);
                                                
                                                // Assert the expected behavior
                                                assertTrue("Should return true for negative number that is also an option", result);
                                                
                                                // Reset accessibility (good practice)
                                                isArgumentMethod.setAccessible(false);
                                            }

    @Test
                                    public void testIsArgumentWithNegativeOption() {
                                        // Create test objects
                                        DefaultParser parser = new DefaultParser();
                                        
                                        // Test case where token is both an option and negative number
                                        String negativeOptionToken = "-1";
                                        
                                        // Since we can't test private methods directly, we'll test the behavior
                                        // through the public parse method with a simple options setup
                                        Options options = new Options();
                                        options.addOption("1", false, "Test option");
                                        
                                        try {
                                            // This should parse successfully if -1 is treated as an argument (option)
                                            parser.parse(options, new String[]{negativeOptionToken});
                                            
                                            // If we get here, the token was accepted as an argument (option)
                                            // We can't directly verify the private method calls, but we can
                                            // verify the end result behavior
                                        } catch (ParseException e) {
                                            fail("Parser should accept negative number as option");
                                        }
                                    }

    @Test
                    public void testIsArgumentWithNegativeNumberThatIsAlsoOption() throws Exception {
                        // Setup
                        DefaultParser parser = new DefaultParser();
                        String negativeOption = "-1"; // Could be both negative number and option
                        
                        // Get private methods via reflection
                        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                        
                        // Make methods accessible
                        isArgumentMethod.setAccessible(true);
                        isOptionMethod.setAccessible(true);
                        isNegativeNumberMethod.setAccessible(true);
                        
                        // Mock the behavior by creating a spy and setting up the method calls
                        DefaultParser spyParser = spy(parser);
                        when(isOptionMethod.invoke(spyParser, negativeOption)).thenReturn(true);
                        when(isNegativeNumberMethod.invoke(spyParser, negativeOption)).thenReturn(true);
                        
                        // Test - should return true because it's a negative number, regardless of being an option
                        assertTrue((Boolean) isArgumentMethod.invoke(spyParser, negativeOption));
                        
                        // Verify interactions through reflection instead of direct verification
                        verify(spyParser, times(1));
                        isOptionMethod.invoke(spyParser, negativeOption);
                        isNegativeNumberMethod.invoke(spyParser, negativeOption);
                    }

    @Test
            public void testIsArgumentWithNegativeNumberNonOption() throws Exception {
                // Setup
                DefaultParser parser = new DefaultParser();
                String negativeNumber = "-123";
                
                // Get private methods via reflection
                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                isOptionMethod.setAccessible(true);
                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                isNegativeNumberMethod.setAccessible(true);
                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                isArgumentMethod.setAccessible(true);
                
                // Verify the negative number is not an option but is a negative number
                assertFalse("Negative number should not be considered option", 
                    (boolean) isOptionMethod.invoke(parser, negativeNumber));
                assertTrue("Negative number should be detected as negative", 
                    (boolean) isNegativeNumberMethod.invoke(parser, negativeNumber));
                
                // Test - should return true for both original and mutant
                boolean result = (boolean) isArgumentMethod.invoke(parser, negativeNumber);
                
                // Assert
                assertTrue("Negative number should be considered argument", result);
            }

    @Test
            public void testIsArgumentWithPositiveNumber() throws Exception {
                // Setup
                DefaultParser parser = new DefaultParser();
                String positiveNumber = "123";
                
                // Get private methods via reflection
                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                isOptionMethod.setAccessible(true);
                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                isNegativeNumberMethod.setAccessible(true);
                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                isArgumentMethod.setAccessible(true);
                
                // Mock the behavior by creating a spy and setting up the private method returns
                DefaultParser spyParser = spy(parser);
                when(isOptionMethod.invoke(spyParser, positiveNumber)).thenReturn(false);
                when(isNegativeNumberMethod.invoke(spyParser, positiveNumber)).thenReturn(false);
                
                // Test
                boolean result = (boolean) isArgumentMethod.invoke(spyParser, positiveNumber);
                
                // Assert
                assertFalse("Positive number should not be considered argument", result);
            }

    @Test
    public void testIsArgumentWithNegativeNumberOption4() throws Exception {
        // Setup
        DefaultParser parser = new DefaultParser();
        String negativeNumberOption = "-1";
        
        // Get private methods via reflection
        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
        isOptionMethod.setAccessible(true);
        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
        isNegativeNumberMethod.setAccessible(true);
        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
        isArgumentMethod.setAccessible(true);
        
        // Verify the methods return expected values
        boolean isOption = (boolean) isOptionMethod.invoke(parser, negativeNumberOption);
        boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, negativeNumberOption);
        
        // Test the actual method
        boolean result = (boolean) isArgumentMethod.invoke(parser, negativeNumberOption);
        
        // Assert - this will fail for the mutant
        assertTrue("Negative number option should be considered argument", result);
    }


}
