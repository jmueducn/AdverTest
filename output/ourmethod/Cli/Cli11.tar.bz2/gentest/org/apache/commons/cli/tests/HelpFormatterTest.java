package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testAppendOption_ShortOptNotRequiredWithArg() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                StringBuffer buff = new StringBuffer();
                Option option = mock(Option.class);
                when(option.getOpt()).thenReturn("f");
                when(option.getLongOpt()).thenReturn(null);
                when(option.hasArg()).thenReturn(true);
                when(option.hasArgName()).thenReturn(true);
                when(option.getArgName()).thenReturn("file");
            
                // Get the private method using reflection
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class
                );
                appendOptionMethod.setAccessible(true);
            
                // Execute
                appendOptionMethod.invoke(formatter, buff, option, false);
            
                // Verify
                assertEquals("[-f <file>]", buff.toString());
            }

    @Test
            public void testAppendOption_LongOptRequiredWithArg() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                StringBuffer buff = new StringBuffer();
                Option option = mock(Option.class);
                when(option.getOpt()).thenReturn(null);
                when(option.getLongOpt()).thenReturn("file");
                when(option.hasArg()).thenReturn(true);
                when(option.hasArgName()).thenReturn(true);
                when(option.getArgName()).thenReturn("path");
            
                // Get the private method via reflection
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
            
                // Execute
                appendOptionMethod.invoke(null, buff, option, true);
            
                // Verify
                assertEquals("--file <path>", buff.toString());
            }

    @Test
            public void testAppendOption_ShortOptNotRequiredNoArg() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                StringBuffer buff = new StringBuffer();
                Option option = mock(Option.class);
                when(option.getOpt()).thenReturn("v");
                when(option.getLongOpt()).thenReturn(null);
                when(option.hasArg()).thenReturn(false);
            
                // Get the private method using reflection
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
            
                // Execute
                appendOptionMethod.invoke(null, buff, option, false);
            
                // Verify
                assertEquals("[-v]", buff.toString());
            }

    @Test
            public void testAppendOption_LongOptRequiredNoArg() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                StringBuffer buff = new StringBuffer();
                Option option = mock(Option.class);
                when(option.getOpt()).thenReturn(null);
                when(option.getLongOpt()).thenReturn("verbose");
                when(option.hasArg()).thenReturn(false);
            
                // Get the private method using reflection
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
            
                // Execute
                appendOptionMethod.invoke(null, buff, option, true);
            
                // Verify
                assertEquals("--verbose", buff.toString());
            }

    @Test
            public void testAppendOption_ShortAndLongOptNotRequiredWithArg() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                StringBuffer buff = new StringBuffer();
                Option option = mock(Option.class);
                when(option.getOpt()).thenReturn("f");
                when(option.getLongOpt()).thenReturn("file");
                when(option.hasArg()).thenReturn(true);
                when(option.hasArgName()).thenReturn(true);
                when(option.getArgName()).thenReturn("filename");
            
                // Get private method via reflection
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
            
                // Execute
                appendOptionMethod.invoke(null, buff, option, false);
            
                // Verify
                assertEquals("[-f <filename>]", buff.toString());
            }

    @Test
            public void testAppendOption_OptionWithArgButNoArgName() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                StringBuffer buff = new StringBuffer();
                Option option = mock(Option.class);
                when(option.getOpt()).thenReturn("D");
                when(option.hasArg()).thenReturn(true);
                when(option.hasArgName()).thenReturn(false);
            
                // Get the private method via reflection
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
            
                // Execute
                appendOptionMethod.invoke(null, buff, option, true);
            
                // Verify
                assertEquals("-D", buff.toString());
            }

    @Test
            public void testAppendOption_NullOptionThrowsException() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                StringBuffer buff = new StringBuffer();
                
                // Expect exception
                ExpectedException exception = ExpectedException.none();
                exception.expect(NullPointerException.class);
                exception.expectMessage("option");
                
                // Get private method via reflection
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
                
                // Execute
                appendOptionMethod.invoke(null, buff, null, true);
            }

    @Test
            public void testAppendOption_NullBufferThrowsException() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                Option option = mock(Option.class);
                
                // Get the private method using reflection
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
                
                // Expect exception
                try {
                    appendOptionMethod.invoke(formatter, null, option, true);
                    fail("Expected NullPointerException to be thrown");
                } catch (InvocationTargetException e) {
                    Throwable cause = e.getCause();
                    assertTrue(cause instanceof NullPointerException);
                    assertEquals("buff", cause.getMessage());
                }
            }

    @Test
            public void testAppendOption_EmptyOption() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                StringBuffer buff = new StringBuffer();
                Option option = mock(Option.class);
                when(option.getOpt()).thenReturn("");
                when(option.getLongOpt()).thenReturn("");
                when(option.hasArg()).thenReturn(false);
            
                // Get the private method via reflection
                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                appendOptionMethod.setAccessible(true);
            
                // Execute
                appendOptionMethod.invoke(null, buff, option, true);
            
                // Verify
                assertEquals("-", buff.toString());
            }

    @Test
    public void testAppendOption_ShouldNotAppendArgWhenOptionHasArgNameButNoArg() throws Exception {
        // Setup
        StringBuffer buff = new StringBuffer();
        Option option = mock(Option.class);
        
        // Configure the mock option
        when(option.getOpt()).thenReturn("f");
        when(option.getLongOpt()).thenReturn(null);
        when(option.hasArg()).thenReturn(false);  // Important: option doesn't require argument
        when(option.hasArgName()).thenReturn(true);  // But has argument name
        when(option.getArgName()).thenReturn("file");
        
        boolean required = false;
        
        // Expected behavior: original would not append argument info, mutant would
        String expected = "[-f]";
        
        // Use reflection to access private method
        Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
            "appendOption", StringBuffer.class, Option.class, boolean.class);
        appendOptionMethod.setAccessible(true);
        
        // Execute
        appendOptionMethod.invoke(null, buff, option, required);
        
        // Verify
        assertEquals("Option with argName but no arg should not show argument info", 
                    expected, buff.toString());
        
        // Verify mock interactions
        verify(option).hasArg();
        verify(option).hasArgName();
    }

    @Test
    public void testAppendOption_ShouldAppendArgWhenOptionHasArgAndArgName() throws Exception {
        // Setup
        StringBuffer buff = new StringBuffer();
        Option option = mock(Option.class);
        
        // Configure the mock option
        when(option.getOpt()).thenReturn("f");
        when(option.getLongOpt()).thenReturn(null);
        when(option.hasArg()).thenReturn(true);  // Requires argument
        when(option.hasArgName()).thenReturn(true);  // Has argument name
        when(option.getArgName()).thenReturn("file");
        
        boolean required = false;
        
        // Expected behavior: both original and mutant would append argument info
        String expected = "[-f <file>]";
        
        // Use reflection to access private method
        Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
            "appendOption", StringBuffer.class, Option.class, boolean.class);
        appendOptionMethod.setAccessible(true);
        
        // Execute
        appendOptionMethod.invoke(null, buff, option, required);
        
        // Verify
        assertEquals("Option with arg and argName should show argument info", 
                    expected, buff.toString());
    }

    @Test
    public void testAppendOption_ShouldNotAppendArgWhenOptionHasNoArgAndNoArgName() throws Exception {
        // Setup
        StringBuffer buff = new StringBuffer();
        Option option = mock(Option.class);
        
        // Configure the mock option
        when(option.getOpt()).thenReturn("f");
        when(option.getLongOpt()).thenReturn(null);
        when(option.hasArg()).thenReturn(false);  // No argument
        when(option.hasArgName()).thenReturn(false);  // No argument name
        
        boolean required = false;
        
        // Expected behavior: both original and mutant would not append argument info
        String expected = "[-f]";
        
        // Get the private method using reflection
        Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
            "appendOption", StringBuffer.class, Option.class, boolean.class);
        appendOptionMethod.setAccessible(true);
        
        // Execute
        appendOptionMethod.invoke(null, buff, option, required);
        
        // Verify
        assertEquals("Option with no arg and no argName should not show argument info", 
                    expected, buff.toString());
    }


}
