package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
 
public class UtilTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                    public void testStripLeadingAndTrailingQuotes_WithSurroundingQuotes() throws Exception {
                                                        String input = "\"hello\"";
                                                        String expected = "hello";
                                                        
                                                        // Get the Util class
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        // Get the method
                                                        Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        // Make it accessible
                                                        method.setAccessible(true);
                                                        // Invoke the method
                                                        String actual = (String) method.invoke(null, input);
                                                        
                                                        assertEquals(expected, actual);
                                                    }

    @Test
                                                    public void testStripLeadingAndTrailingQuotes_NoSurroundingQuotes() throws Exception {
                                                        String input = "hello";
                                                        String expected = "hello";
                                                        
                                                        // Get the method using reflection
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        stripMethod.setAccessible(true);
                                                        
                                                        // Invoke the method
                                                        String actual = (String) stripMethod.invoke(null, input);
                                                        
                                                        assertEquals(expected, actual);
                                                    }

    @Test
                                                    public void testStripLeadingAndTrailingQuotes_OnlyStartQuote() throws Exception {
                                                        String input = "\"hello";
                                                        String expected = "\"hello";
                                                        
                                                        // Get the Util class
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        // Get the stripLeadingAndTrailingQuotes method
                                                        Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        // Make the method accessible
                                                        method.setAccessible(true);
                                                        // Invoke the method
                                                        String actual = (String) method.invoke(null, input);
                                                        
                                                        assertEquals(expected, actual);
                                                    }

    @Test
                                                    public void testStripLeadingAndTrailingQuotes_OnlyEndQuote() throws Exception {
                                                        String input = "hello\"";
                                                        String expected = "hello\"";
                                                        
                                                        // Get the method via reflection
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        method.setAccessible(true);
                                                        
                                                        // Invoke the method
                                                        String actual = (String) method.invoke(null, input);
                                                        assertEquals(expected, actual);
                                                    }

    @Test
                                                    public void testStripLeadingAndTrailingQuotes_EmptyString() throws Exception {
                                                        String input = "";
                                                        String expected = "";
                                                        
                                                        // Get the method using reflection
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        stripMethod.setAccessible(true);
                                                        
                                                        // Invoke the method
                                                        String actual = (String) stripMethod.invoke(null, input);
                                                        assertEquals(expected, actual);
                                                    }

    @Test
                                                    public void testStripLeadingAndTrailingQuotes_SingleQuoteString() throws Exception {
                                                        String input = "\"";
                                                        String expected = "\"";
                                                        
                                                        // Get the Util class using reflection
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        // Get the method
                                                        java.lang.reflect.Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        // Make it accessible
                                                        method.setAccessible(true);
                                                        // Invoke the method
                                                        String actual = (String) method.invoke(null, input);
                                                        
                                                        assertEquals(expected, actual);
                                                    }

    @Test
                                                    public void testStripLeadingAndTrailingQuotes_QuotesInsideString() throws Exception {
                                                        String input = "\"he\"llo\"";
                                                        String expected = "\"he\"llo\"";
                                                        
                                                        // Get the Util class
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        // Get the stripLeadingAndTrailingQuotes method
                                                        Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        // Make the method accessible
                                                        method.setAccessible(true);
                                                        // Invoke the method
                                                        String actual = (String) method.invoke(null, input);
                                                        
                                                        assertEquals(expected, actual);
                                                    }

    @Test
                                                    public void testStripLeadingAndTrailingQuotes_MultipleQuotesAtEnds() throws Exception {
                                                        String input = "\"\"hello\"\"";
                                                        String expected = "\"\"hello\"\"";
                                                        
                                                        // Get the method using reflection
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        stripMethod.setAccessible(true);
                                                        
                                                        // Invoke the method
                                                        String actual = (String) stripMethod.invoke(null, input);
                                                        assertEquals(expected, actual);
                                                    }

    @Test
                                                    public void testStripLeadingAndTrailingQuotes_NullInput() throws Exception {
                                                        // Set up exception rule
                                                        org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                        exceptionRule.expect(NullPointerException.class);
                                                        
                                                        // Use reflection to access the package-private Util class
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        java.lang.reflect.Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        method.setAccessible(true);
                                                        method.invoke(null, (String)null);
                                                    }

    @Test
                                                    public void testStripLeadingAndTrailingQuotes_WhitespaceInsideQuotes() throws Exception {
                                                        String input = "\"  hello  \"";
                                                        String expected = "  hello  ";
                                                        
                                                        // Get the Util class
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        // Get the method
                                                        Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        // Make it accessible
                                                        method.setAccessible(true);
                                                        // Invoke the method
                                                        String actual = (String) method.invoke(null, input);
                                                        
                                                        assertEquals(expected, actual);
                                                    }

    @Test
                                                    public void testStripLeadingAndTrailingQuotes_SpecialCharactersInsideQuotes() throws Exception {
                                                        String input = "\"h@llo!123\"";
                                                        String expected = "h@llo!123";
                                                        
                                                        // Get the Util class using reflection
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        // Get the stripLeadingAndTrailingQuotes method
                                                        java.lang.reflect.Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        // Make the method accessible
                                                        method.setAccessible(true);
                                                        // Invoke the method
                                                        String actual = (String) method.invoke(null, input);
                                                        
                                                        assertEquals(expected, actual);
                                                    }

    @Test
                                                public void testStripLeadingAndTrailingQuotes_QuotesWithSingleCharacter() throws Exception {
                                                    String input = "\"a\"";
                                                    String expected = "a";
                                                    
                                                    // Get the method via reflection
                                                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                    Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                    stripMethod.setAccessible(true);
                                                    
                                                    // Invoke the method
                                                    String actual = (String) stripMethod.invoke(null, input);
                                                    
                                                    assertEquals(expected, actual);
                                                }

    @Test
                                        public void testStripLeadingAndTrailingQuotes_ReturnsSameObjectWhenNoQuotes() throws Exception {
                                            // Arrange
                                            String input = "hello world"; // Doesn't meet any modification criteria
                                            
                                            // Get the method via reflection
                                            Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                            Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                            stripMethod.setAccessible(true);
                                            
                                            // Act
                                            String result = (String) stripMethod.invoke(null, input);
                                            
                                            // Assert
                                            // Original should return same object, mutant will return new object
                                            assertSame("Should return same string object when no quotes to strip", 
                                                      input, result);
                                        }

    @Test
                                        public void testStripLeadingAndTrailingQuotes_RemovesQuotesWhenPresent() throws Exception {
                                            // Arrange
                                            String input = "\"quoted\"";
                                            String expected = "quoted";
                                            
                                            // Get the method via reflection
                                            Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                            Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                            stripMethod.setAccessible(true);
                                            
                                            // Act
                                            String result = (String) stripMethod.invoke(null, input);
                                            
                                            // Assert
                                            assertEquals("Should remove surrounding quotes", expected, result);
                                        }

    @Test
                                    public void testStripLeadingAndTrailingQuotes_DoesNotModifyWhenInnerQuotes() throws Exception {
                                        // Arrange
                                        String input = "\"quo\"ted\"";
                                        
                                        // Get the method via reflection
                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                        stripMethod.setAccessible(true);
                                        
                                        // Act
                                        String result = (String) stripMethod.invoke(null, input);
                                        
                                        // Assert
                                        assertEquals("Should not modify when inner quotes exist", input, result);
                                    }

    @Test
                            public void testStripLeadingAndTrailingQuotes_ReturnsSameObjectWhenNoModificationNeeded() throws Exception {
                                // Arrange
                                String input = "hello";
                                String expected = input;  // We expect the exact same object, not a new one
                                
                                // Get the method via reflection
                                Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                stripMethod.setAccessible(true);
                                
                                // Act
                                String result = (String) stripMethod.invoke(null, input);
                                
                                // Assert
                                assertSame("Method should return the same string object when no modification is needed", 
                                          expected, result);
                            }

    @Test
                            public void testStripLeadingAndTrailingQuotes_EmptyString1() throws Exception {
                                // Arrange
                                String input = "";
                                String expected = input;
                                
                                // Get the method via reflection
                                Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                stripMethod.setAccessible(true);
                                
                                // Act
                                String result = (String) stripMethod.invoke(null, input);
                                
                                // Assert
                                assertSame("Method should return the same string object for empty string", 
                                          expected, result);
                            }

    @Test
                            public void testStripLeadingAndTrailingQuotes_SingleCharacter() throws Exception {
                                // Arrange
                                String input = "a";
                                String expected = input;
                                
                                // Get the method via reflection
                                Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                stripMethod.setAccessible(true);
                                
                                // Act
                                String result = (String) stripMethod.invoke(null, input);
                                
                                // Assert
                                assertSame("Method should return the same string object for single character", 
                                          expected, result);
                            }

    @Test
                        public void testStripLeadingAndTrailingQuotes_QuotedString() throws Exception {
                            // Arrange
                            String input = "\"quoted\"";
                            String expected = "quoted";
                            
                            // Get the method via reflection
                            Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                            Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                            stripMethod.setAccessible(true);
                            
                            // Act
                            String result = (String) stripMethod.invoke(null, input);
                            
                            // Assert
                            assertEquals("Method should strip quotes when properly quoted", 
                                       expected, result);
                            assertNotSame("Method should return a new string when stripping quotes", 
                                         input, result);
                        }

    @Test
                public void testStripLeadingAndTrailingQuotes_basicCases() throws Exception {
                    // Get the Util class and method using reflection
                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                    Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                    stripMethod.setAccessible(true);
                    
                    // Test cases
                    assertEquals("test", stripMethod.invoke(null, "\"test\""));
                    assertEquals("\"test", stripMethod.invoke(null, "\"test"));
                    assertEquals("test\"", stripMethod.invoke(null, "test\""));
                    assertEquals("te\"st", stripMethod.invoke(null, "\"te\"st\""));
                    assertEquals("", stripMethod.invoke(null, "\"\""));
                    assertEquals("t", stripMethod.invoke(null, "\"t\""));
                }

    @Test
            public void testStripLeadingAndTrailingQuotes_withCustomStringSubclass() {
                // Create a custom String-like class that implements CharSequence
                class CustomString implements CharSequence {
                    private final String value;
                    
                    public CustomString(String value) {
                        this.value = value;
                    }
                    
                    @Override
                    public String toString() {
                        return "modified_" + value;
                    }
                    
                    @Override
                    public int length() {
                        return value.length();
                    }
                    
                    @Override
                    public char charAt(int index) {
                        return value.charAt(index);
                    }
                    
                    @Override
                    public CharSequence subSequence(int start, int end) {
                        return value.subSequence(start, end);
                    }
                    
                    public boolean startsWith(String prefix) {
                        return value.startsWith(prefix);
                    }
                    
                    public boolean endsWith(String suffix) {
                        return value.endsWith(suffix);
                    }
                    
                    public String substring(int beginIndex, int endIndex) {
                        return value.substring(beginIndex, endIndex);
                    }
                    
                    public int indexOf(int ch) {
                        return value.indexOf(ch);
                    }
                }
                
                CustomString input = new CustomString("\"test\"");
                String expected = "test";  // Original method would return this
                String mutatedExpected = "modified_test";  // Mutated method would return this
                
                try {
                    // Use reflection to access the private static method
                    Method method = Class.forName("org.apache.commons.cli.Util")
                                       .getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                    method.setAccessible(true);
                    String result = (String) method.invoke(null, input.toString());
                    assertEquals(expected, result);
                } catch (Exception e) {
                    fail("Failed to invoke stripLeadingAndTrailingQuotes method: " + e.getMessage());
                }
            }

    @Test
    public void testStripLeadingAndTrailingQuotes_ReturnsSameObjectWhenNoQuotes1() throws Exception {
        // Arrange
        String input = "hello world"; // Doesn't start/end with quotes
        
        // Get the method via reflection
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
        stripMethod.setAccessible(true);
        
        // Act
        String result = (String) stripMethod.invoke(null, input);
        
        // Assert
        // Original behavior would return same object reference
        // Mutant would return new String object
        assertSame("Should return same string object when no quotes to strip", 
                  input, result);
    }

    @Test
    public void testStripLeadingAndTrailingQuotes_ReturnsNewObjectWhenQuotesStripped() throws Exception {
        // Arrange
        String input = "\"quoted string\"";
        
        // Get the method via reflection
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
        stripMethod.setAccessible(true);
        
        // Act
        String result = (String) stripMethod.invoke(null, input);
        
        // Assert
        assertNotSame("Should return new string object when quotes are stripped",
                     input, result);
        assertEquals("quoted string", result);
    }


}
