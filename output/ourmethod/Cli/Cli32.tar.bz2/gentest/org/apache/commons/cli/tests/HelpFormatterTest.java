package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                public void testFindWrapPos_NewLineBeforeWidth() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "This is a\ntest string";
                                                                                                                                                                    int width = 20;
                                                                                                                                                                    int startPos = 0;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(9, result); // Position right after '\n'
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_TabBeforeWidth() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "This is a\ttest string";
                                                                                                                                                                    int width = 20;
                                                                                                                                                                    int startPos = 0;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(9, result); // Position right after '\t'
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_EndOfString() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "Short string";
                                                                                                                                                                    int width = 20;
                                                                                                                                                                    int startPos = 0;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(-1, result); // Entire string fits within width
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_FindLastWhitespace() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "This is a test string that needs to be wrapped";
                                                                                                                                                                    int width = 15;
                                                                                                                                                                    int startPos = 0;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(10, result); // Position of last space before width
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_NoWhitespaceFound() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "ThisIsAStringWithoutSpaces";
                                                                                                                                                                    int width = 10;
                                                                                                                                                                    int startPos = 0;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(10, result); // Forced to break at width position
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_StartPosNotZero() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "This is a test string with multiple words";
                                                                                                                                                                    int width = 10;
                                                                                                                                                                    int startPos = 5;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(10, result); // Should find space at position 10
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_ExactWidthMatch() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "Exactly ten ";
                                                                                                                                                                    int width = 10;
                                                                                                                                                                    int startPos = 0;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(10, result); // Space at exactly width position
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_CarriageReturn() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "Line with\\r carriage return";
                                                                                                                                                                    int width = 20;
                                                                                                                                                                    int startPos = 0;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(11, result); // Position right after '\r'
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_EmptyString() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "";
                                                                                                                                                                    int width = 10;
                                                                                                                                                                    int startPos = 0;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(-1, result); // Empty string should return -1
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_NullTextThrowsException() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    Method method = HelpFormatter.class.getDeclaredMethod("findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                    thrown.expect(NullPointerException.class);
                                                                                                                                                                    method.invoke(helpFormatter, null, 10, 0);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_NegativeWidthThrowsException() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    Method method = HelpFormatter.class.getDeclaredMethod("findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                    method.invoke(helpFormatter, "text", -1, 0);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_StartPosGreaterThanTextLength() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "short";
                                                                                                                                                                    int width = 10;
                                                                                                                                                                    int startPos = 10;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(-1, result); // Should return -1 when startPos >= text.length()
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_StartPosPlusWidthGreaterThanTextLength() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "This is a test";
                                                                                                                                                                    int width = 20;
                                                                                                                                                                    int startPos = 5;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(-1, result); // Entire remaining text fits within width
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testFindWrapPos_OnlyWhitespaceAtWidth() throws Exception {
                                                                                                                                                                    HelpFormatter helpFormatter = new HelpFormatter();
                                                                                                                                                                    String text = "This is   a test";
                                                                                                                                                                    int width = 8;
                                                                                                                                                                    int startPos = 0;
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access protected method
                                                                                                                                                                    Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                                                                        "findWrapPos", String.class, int.class, int.class);
                                                                                                                                                                    findWrapPosMethod.setAccessible(true);
                                                                                                                                                                    int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                                                                                                                                                    
                                                                                                                                                                    assertEquals(8, result); // Should break at the space at position 8
                                                                                                                                                                }

    @Test
                                                                                                                    public void testFindWrapPosWithNonZeroStartPos() throws Exception {
                                                                                                                        HelpFormatter formatter = new HelpFormatter();
                                                                                                                        String text = "This is a test string for wrapping";
                                                                                                                        int width = 10;
                                                                                                                        int startPos = 5;
                                                                                                                        
                                                                                                                        // Get the protected method using reflection
                                                                                                                        Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                            "findWrapPos", String.class, int.class, int.class);
                                                                                                                        findWrapPosMethod.setAccessible(true);
                                                                                                                        
                                                                                                                        // Original behavior should find wrap position relative to startPos (5 + 10 = 15)
                                                                                                                        // Looking for last whitespace before position 15 ("for" space at position 14)
                                                                                                                        int expectedPos = 14;
                                                                                                                        int actualPos = (Integer) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                                                                                        
                                                                                                                        assertEquals("Wrap position should be relative to startPos", expectedPos, actualPos);
                                                                                                                        
                                                                                                                        // Mutant behavior would return 10 (just 'width') which would be incorrect
                                                                                                                        // This assertion will fail if the mutant is present
                                                                                                                    }

    @Test
                                                                                                            public void testFindWrapPos_WhenPositionExceedsTextLength() throws Exception {
                                                                                                                // Setup
                                                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                                                String text = "short text";
                                                                                                                int width = 20; // large enough to make startPos + width > text.length()
                                                                                                                int startPos = 0;
                                                                                                                
                                                                                                                // Get the protected method using reflection
                                                                                                                Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                                    "findWrapPos", String.class, int.class, int.class);
                                                                                                                findWrapPosMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Execute
                                                                                                                int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                                                                                
                                                                                                                // Verify - original would return text.length(), mutant would return -1
                                                                                                                assertEquals("Should return text length when position exceeds it", 
                                                                                                                             text.length(), 
                                                                                                                             result);
                                                                                                                
                                                                                                                // Additional verification that it's not -1 (which mutant would return)
                                                                                                                assertNotEquals("Should not return -1 when position exceeds text length",
                                                                                                                               -1,
                                                                                                                               result);
                                                                                                            }

    @Test
                                                                                                    public void testFindWrapPos_EndOfText() throws Exception {
                                                                                                        // Setup
                                                                                                        HelpFormatter formatter = new HelpFormatter();
                                                                                                        String text = "ThisIsALongStringWithNoSpaces";
                                                                                                        int width = text.length();
                                                                                                        int startPos = 0;
                                                                                                        
                                                                                                        // Get the protected method using reflection
                                                                                                        Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                                            "findWrapPos", String.class, int.class, int.class);
                                                                                                        findWrapPosMethod.setAccessible(true);
                                                                                                        
                                                                                                        // Invoke the method
                                                                                                        int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                                                                        
                                                                                                        // Verify - original returns -1, mutant would return 0
                                                                                                        assertEquals("Should return -1 when wrap position equals text length", 
                                                                                                                    -1, result);
                                                                                                        
                                                                                                        // Additional verification that it's not returning 0
                                                                                                        assertTrue("Should not return 0 for this case", result != 0);
                                                                                                    }

    @Test
                                                                                            public void testFindWrapPos_EndOfText1() throws Exception {
                                                                                                // Setup
                                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                                String text = "short text";
                                                                                                int width = text.length(); // width equals text length
                                                                                                int startPos = 0;
                                                                                                
                                                                                                // Get the protected method using reflection
                                                                                                Class<?> formatterClass = formatter.getClass();
                                                                                                Method findWrapPosMethod = formatterClass.getDeclaredMethod("findWrapPos", String.class, int.class, int.class);
                                                                                                findWrapPosMethod.setAccessible(true);
                                                                                                
                                                                                                // Execute
                                                                                                int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                                                                
                                                                                                // Verify
                                                                                                // Original should return -1 when reaching end of text
                                                                                                // Mutant will return 1 instead
                                                                                                assertEquals("Should return -1 when position reaches end of text", -1, result);
                                                                                                
                                                                                                // Additional verification that it's not returning the mutated value
                                                                                                assertNotEquals("Should not return 1 when position reaches end of text", 1, result);
                                                                                            }

    @Test
                                                                                    public void testFindWrapPos_ExactTextLength() throws Exception {
                                                                                        // Setup
                                                                                        HelpFormatter formatter = new HelpFormatter();
                                                                                        String text = "12345";  // length = 5
                                                                                        int width = 5;
                                                                                        int startPos = 0;
                                                                                        
                                                                                        // Get the protected method via reflection
                                                                                        Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                            "findWrapPos", String.class, int.class, int.class);
                                                                                        findWrapPosMethod.setAccessible(true);
                                                                                        
                                                                                        // Test - when startPos + width equals text length
                                                                                        int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                                                        
                                                                                        // Verify - should return -1 for original, mutant would return 5
                                                                                        assertEquals("Should return -1 when position equals text length", -1, result);
                                                                                        
                                                                                        // Additional test case where position is just before text length
                                                                                        width = 4;
                                                                                        result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                                                        assertEquals("Should return position when before text length", 4, result);
                                                                                    }

    @Test
                                                                            public void testFindWrapPosWithNonZeroStartPos1() throws Exception {
                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                String text = "This is a test string for wrapping";
                                                                                int width = 10;
                                                                                int startPos = 5; // Non-zero start position
                                                                                
                                                                                // Get the protected findWrapPos method using reflection
                                                                                Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                    "findWrapPos", String.class, int.class, int.class);
                                                                                findWrapPosMethod.setAccessible(true);
                                                                                
                                                                                // Original behavior should search from position 15 (5+10)
                                                                                // Mutant would search from position 10 (width only)
                                                                                int expectedPos = 14; // Space between "test" and "string"
                                                                                int actualPos = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                                                
                                                                                assertEquals("Wrap position should be calculated from startPos+width", 
                                                                                            expectedPos, actualPos);
                                                                                
                                                                                // Additional check with different startPos
                                                                                startPos = 8;
                                                                                expectedPos = 18; // Space between "string" and "for"
                                                                                actualPos = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                                                assertEquals("Wrap position should adjust with different startPos",
                                                                                            expectedPos, actualPos);
                                                                                
                                                                                // Edge case where startPos+width exceeds text length
                                                                                startPos = text.length() - 3;
                                                                                expectedPos = -1; // Should return -1 when at end of text
                                                                                actualPos = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                                                assertEquals("Should return -1 when startPos+width exceeds text length",
                                                                                            expectedPos, actualPos);
                                                                            }

    @Test
                                                                    public void testFindWrapPos_WhenPosExceedsTextLength_ShouldNotReturnNegativeOne() throws Exception {
                                                                        // Setup
                                                                        HelpFormatter formatter = new HelpFormatter();
                                                                        String text = "abcdefghij"; // length = 10
                                                                        int width = 15; // larger than text length
                                                                        int startPos = 0;
                                                                        
                                                                        // Get the protected method using reflection
                                                                        Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                            "findWrapPos", String.class, int.class, int.class);
                                                                        findWrapPosMethod.setAccessible(true);
                                                                        
                                                                        // Execute
                                                                        int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                                        
                                                                        // Verify - original would return 10 (text length), mutant would return -1
                                                                        assertEquals("Should return text length when pos equals text length", 
                                                                                     text.length(), result);
                                                                        
                                                                        // Additional test case where pos would be greater than text length
                                                                        startPos = 5;
                                                                        width = 10; // 5 + 10 = 15 > text length (10)
                                                                        result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                                        
                                                                        // Verify - original would return 10, mutant would return -1
                                                                        assertEquals("Should return text length even when startPos + width exceeds text length",
                                                                                     text.length(), result);
                                                                    }

    @Test
                                                            public void testFindWrapPos_ExactWidth() throws Exception {
                                                                // Setup
                                                                HelpFormatter formatter = new HelpFormatter();
                                                                String text = "Exactly10"; // length = 8
                                                                int width = 8; // same as text length
                                                                int startPos = 0;
                                                                
                                                                // Get the protected method using reflection
                                                                java.lang.reflect.Method method = HelpFormatter.class.getDeclaredMethod(
                                                                    "findWrapPos", String.class, int.class, int.class);
                                                                method.setAccessible(true);
                                                                
                                                                // Execute
                                                                int result = (int) method.invoke(formatter, text, width, startPos);
                                                                
                                                                // Verify - original should return -1, mutant would return 0
                                                                assertEquals("Should return -1 when position equals text length", -1, result);
                                                            }

    @Test
                                                    public void testFindWrapPos_EndOfText2() throws Exception {
                                                        HelpFormatter formatter = new HelpFormatter();
                                                        
                                                        // Get the protected findWrapPos method using reflection
                                                        java.lang.reflect.Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                            "findWrapPos", String.class, int.class, int.class);
                                                        findWrapPosMethod.setAccessible(true);
                                                        
                                                        // Case 1: Exact end of text
                                                        String text1 = "exact";
                                                        int width1 = 5;
                                                        int startPos1 = 0;
                                                        assertEquals(-1, findWrapPosMethod.invoke(formatter, text1, width1, startPos1));
                                                        
                                                        // Case 2: Beyond end of text
                                                        String text2 = "short";
                                                        int width2 = 10;
                                                        int startPos2 = 0;
                                                        assertEquals(-1, findWrapPosMethod.invoke(formatter, text2, width2, startPos2));
                                                        
                                                        // Case 3: Not at end (should return position, not -1 or 1)
                                                        String text3 = "long enough text";
                                                        int width3 = 4;
                                                        int startPos3 = 0;
                                                        int result3 = (Integer) findWrapPosMethod.invoke(formatter, text3, width3, startPos3);
                                                        assertTrue(result3 > 0 && result3 <= width3);
                                                    }

    @Test
                                            public void testFindWrapPos_ExactTextLength1() throws Exception {
                                                HelpFormatter formatter = new HelpFormatter();
                                                String text = "abcdef"; // length = 6
                                                int width = 6;
                                                int startPos = 0;
                                                
                                                // Get the protected findWrapPos method using reflection
                                                Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                    "findWrapPos", String.class, int.class, int.class);
                                                findWrapPosMethod.setAccessible(true);
                                                
                                                // Invoke the method
                                                int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                                
                                                // When startPos + width equals text length and no whitespace found,
                                                // should return -1 (original) vs text.length() (mutant)
                                                assertEquals(-1, result);
                                                
                                                // Additional assertion to verify the exact text length case
                                                assertEquals(6, text.length());
                                                assertEquals(width, text.length() - startPos);
                                            }

    @Test
                                    public void testFindWrapPos_NoNaturalBreaks_ShouldRespectStartPos() throws Exception {
                                        // Setup
                                        HelpFormatter formatter = new HelpFormatter();
                                        String text = "ThisIsALongTextWithNoNaturalBreakPoints";
                                        int width = 10;
                                        int startPos = 5;
                                        
                                        // Get the protected method using reflection
                                        Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                            "findWrapPos", String.class, int.class, int.class);
                                        findWrapPosMethod.setAccessible(true);
                                        
                                        // Execute
                                        int result = (Integer) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                        
                                        // Verify
                                        assertEquals("Should return startPos + width when no natural breaks found", 
                                                    startPos + width, result);
                                        
                                        // Additional verification that we're not just getting width
                                        assertNotEquals("Should not return just width when startPos > 0",
                                                       width, result);
                                    }

    @Test
                            public void testFindWrapPos_PosGreaterThanTextLength() throws Exception {
                                HelpFormatter formatter = new HelpFormatter();
                                
                                // Setup test where:
                                // - No newlines/tabs in text
                                // - startPos + width > text.length()
                                // - No whitespace found when searching backward
                                // - pos will be startPos + width which is > text.length()
                                String text = "abcdef";
                                int width = 10;
                                int startPos = 2; // startPos + width = 12 > text.length()=6
                                
                                // Use reflection to access protected method
                                Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                    "findWrapPos", String.class, int.class, int.class);
                                findWrapPosMethod.setAccessible(true);
                                
                                // Original behavior should return pos (12)
                                // Mutant will return -1 because pos >= text.length()
                                int result = (Integer) findWrapPosMethod.invoke(formatter, text, width, startPos);
                                
                                // Assert we get the position (12) not -1
                                assertEquals(12, result);
                            }

    @Test
                    public void testFindWrapPos_AtStringEnd_ShouldReturnNegativeOne() throws Exception {
                        // Setup
                        HelpFormatter formatter = new HelpFormatter();
                        String text = "This is a test string";
                        int width = text.length(); // width equals string length
                        int startPos = 0;
                        
                        // Get the protected method using reflection
                        Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                            "findWrapPos", String.class, int.class, int.class);
                        findWrapPosMethod.setAccessible(true);
                        
                        // Execute
                        int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                        
                        // Verify
                        assertEquals("When position is at string end, should return -1", -1, result);
                    }

    @Test
            public void testFindWrapPos_AtEndOfString() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                String text = "ThisIsATestStringWithNoSpaces";
                int width = text.length();
                int startPos = 0;
                
                // Get the protected method using reflection
                Class<?> formatterClass = formatter.getClass();
                Method findWrapPosMethod = formatterClass.getDeclaredMethod("findWrapPos", String.class, int.class, int.class);
                findWrapPosMethod.setAccessible(true);
                
                // Execute - case where startPos + width equals text length
                int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                
                // Verify - should return -1 when at end of string
                assertEquals("Should return -1 when position equals text length", -1, result);
            }

    @Test
    public void testFindWrapPos_WhenPosEqualsTextLength_ShouldReturnNegativeOne() throws Exception {
        // Setup
        HelpFormatter formatter = new HelpFormatter();
        String text = "exactlength"; // length = 11
        int width = 5;
        int startPos = 6; // 6 + 5 = 11 (text length)
        
        // Get the protected method using reflection
        Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
            "findWrapPos", String.class, int.class, int.class);
        findWrapPosMethod.setAccessible(true);
        
        // Execute
        int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
        
        // Verify
        assertEquals("When pos equals text length should return -1", -1, result);
    }


}
