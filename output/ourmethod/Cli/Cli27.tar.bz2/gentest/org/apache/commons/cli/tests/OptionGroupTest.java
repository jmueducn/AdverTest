package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
 
public class OptionGroupTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testSetSelected_NullOption() {
                                                    // Setup
                                                    OptionGroup optionGroup = new OptionGroup();
                                                    try {
                                                        optionGroup.setSelected(mock(Option.class)); // Set some initial selection
                                                    } catch (AlreadySelectedException e) {
                                                        fail("Unexpected AlreadySelectedException");
                                                    }
                                                    
                                                    // Test
                                                    try {
                                                        optionGroup.setSelected(null);
                                                    } catch (AlreadySelectedException e) {
                                                        fail("Unexpected AlreadySelectedException when setting null option");
                                                    }
                                                    
                                                    // Verify
                                                    assertNull(optionGroup.getSelected());
                                                }

    @Test
                                                public void testSetSelected_InitialSelection() throws AlreadySelectedException {
                                                    // Setup
                                                    OptionGroup optionGroup = new OptionGroup();
                                                    Option option = mock(Option.class);
                                                    when(option.toString()).thenReturn("testKey");
                                                    
                                                    // Test
                                                    optionGroup.setSelected(option);
                                                    
                                                    // Verify
                                                    assertEquals("testKey", optionGroup.getSelected());
                                                }

    @Test(expected = AlreadySelectedException.class)
                                                public void testSetSelected_ReselectSameOption() throws AlreadySelectedException {
                                                    // Setup
                                                    OptionGroup optionGroup = new OptionGroup();
                                                    Option option = mock(Option.class);
                                                    // Instead of trying to access option.getKey(), we'll rely on OptionGroup's behavior
                                                    optionGroup.addOption(option); // Add the option to the group first
                                                    optionGroup.setSelected(option); // Initial selection
                                                    
                                                    // Test - should throw AlreadySelectedException
                                                    optionGroup.setSelected(option); // Reselect same option
                                                }

    @Test
                                                public void testSetSelected_DifferentOptionWhenAlreadySelected_ThrowsException() {
                                                    // Setup
                                                    OptionGroup optionGroup = new OptionGroup();
                                                    Option option1 = mock(Option.class);
                                                    when(option1.getOpt()).thenReturn("firstKey");
                                                    Option option2 = mock(Option.class);
                                                    when(option2.getOpt()).thenReturn("secondKey");
                                                    
                                                    try {
                                                        optionGroup.setSelected(option1); // Initial selection
                                                    } catch (AlreadySelectedException e) {
                                                        fail("Unexpected AlreadySelectedException on initial selection");
                                                    }
                                                    
                                                    // Expect exception
                                                    try {
                                                        optionGroup.setSelected(option2);
                                                        fail("Expected AlreadySelectedException");
                                                    } catch (AlreadySelectedException e) {
                                                        assertTrue(e.getMessage().contains("secondKey"));
                                                    }
                                                }

    @Test
                                                public void testSetSelected_AfterReset() throws AlreadySelectedException {
                                                    // Setup
                                                    OptionGroup optionGroup = new OptionGroup();
                                                    Option option1 = mock(Option.class);
                                                    Option option2 = mock(Option.class);
                                                    
                                                    // Instead of using getKey(), we'll verify the selection through OptionGroup's getSelected()
                                                    optionGroup.addOption(option1);
                                                    optionGroup.addOption(option2);
                                                    
                                                    optionGroup.setSelected(option1); // Initial selection
                                                    optionGroup.setSelected(null);    // Reset
                                                    
                                                    // Test
                                                    optionGroup.setSelected(option2); // New selection after reset
                                                    
                                                    // Verify
                                                    // This assumes getSelected() returns the value/name of the selected option
                                                    // If it returns something else, adjust accordingly
                                                    assertNotNull(optionGroup.getSelected());
                                                }

    @Test
                                                public void testSetSelected_MultipleOperations() throws AlreadySelectedException {
                                                    // Setup
                                                    OptionGroup optionGroup = new OptionGroup();
                                                    Option option1 = new Option("firstKey", null);
                                                    Option option2 = new Option("secondKey", null);
                                                    
                                                    // Test sequence
                                                    optionGroup.setSelected(option1);
                                                    assertEquals("firstKey", optionGroup.getSelected());
                                                    
                                                    optionGroup.setSelected(null);
                                                    assertNull(optionGroup.getSelected());
                                                    
                                                    optionGroup.setSelected(option2);
                                                    assertEquals("secondKey", optionGroup.getSelected());
                                                    
                                                    optionGroup.setSelected(option2); // Reselect same
                                                    assertEquals("secondKey", optionGroup.getSelected());
                                                }

    @Test
                                    public void testSetSelected_shouldThrowExceptionWhenSelectingDifferentOption() {
                                        // Setup
                                        OptionGroup optionGroup = new OptionGroup();
                                        Option option1 = mock(Option.class);
                                        Option option2 = mock(Option.class);
                                        
                                        // Mock toString() to distinguish options instead of getKey()
                                        when(option1.toString()).thenReturn("opt1");
                                        when(option2.toString()).thenReturn("opt2");
                                        
                                        // First selection should work
                                        try {
                                            optionGroup.setSelected(option1);
                                        } catch (AlreadySelectedException e) {
                                            fail("First selection should not throw exception");
                                        }
                                        
                                        try {
                                            // Second selection with different option should throw exception
                                            optionGroup.setSelected(option2);
                                            fail("Expected an exception to be thrown");
                                        } catch (AlreadySelectedException e) {
                                            // Verify the selected value didn't change (additional check for mutant)
                                            assertEquals(option1.toString(), optionGroup.getSelected());
                                        }
                                    }

    @Test
                                    public void testSetSelected_shouldAllowReselectingSameOption() throws AlreadySelectedException {
                                        // Setup
                                        OptionGroup optionGroup = new OptionGroup();
                                        Option option = mock(Option.class);
                                        
                                        // First selection
                                        optionGroup.setSelected(option);
                                        
                                        // Reselect same option
                                        optionGroup.setSelected(option);
                                        
                                        // Verify selection remains by comparing the selected option
                                        assertEquals(option, optionGroup.getSelected());
                                    }

    @Test
                        public void testSetSelected_ShouldThrowWhenSelectingDifferentOption() {
                            // Setup
                            OptionGroup optionGroup = new OptionGroup();
                            
                            // Create initial option
                            Option initialOption = new Option("opt1", "description1");
                            
                            // Create different option
                            Option differentOption = new Option("opt2", "description2");
                            
                            // First select an option
                            try {
                                optionGroup.setSelected(initialOption);
                            } catch (AlreadySelectedException e) {
                                fail("Unexpected exception when making initial selection");
                            }
                            
                            // Verify initial selection was set
                            assertEquals("opt1", optionGroup.getSelected());
                            
                            // Try to select a different option - should throw
                            try {
                                optionGroup.setSelected(differentOption);
                                fail("Expected an exception when selecting a different option");
                            } catch (AlreadySelectedException e) {
                                // Expected behavior
                            }
                            
                            // Verify selection didn't change
                            assertEquals("opt1", optionGroup.getSelected());
                        }

    @Test
                public void testSetSelectedWithNullKeyShouldThrowAlreadySelectedException() throws Exception {
                    // Setup
                    OptionGroup optionGroup = new OptionGroup();
                    Option mockOption = mock(Option.class);
                    Option mockExistingOption = mock(Option.class);
                    
                    // Use reflection to access getKey() method
                    Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                    getKeyMethod.setAccessible(true);
                    
                    // First select an option to set 'selected' to non-null
                    when(getKeyMethod.invoke(mockExistingOption)).thenReturn("existing");
                    optionGroup.setSelected(mockExistingOption);
                    
                    // Now test with option that returns null key
                    when(getKeyMethod.invoke(mockOption)).thenReturn(null);
                    
                    // This should throw AlreadySelectedException in original code
                    // Would throw NullPointerException in mutated code
                    optionGroup.setSelected(mockOption);
                }

    @Test
    public void testSetSelectedWithEqualButDifferentStringObjects() throws AlreadySelectedException {
        // Setup
        OptionGroup optionGroup = new OptionGroup();
        
        // Create options with different String objects but same value
        String key1 = new String("testKey");
        String key2 = new String("testKey");
        
        // Verify they are different objects but equal in value
        assertNotSame(key1, key2);
        assertEquals(key1, key2);
        
        // Create options with these keys
        Option option1 = new Option(null, key1);
        Option option2 = new Option(null, key2);
        
        // First selection should work
        optionGroup.setSelected(option1);
        
        // Second selection with different String object but same value
        // Should work in original code (equals comparison)
        // Should throw exception in mutated code (== comparison)
        optionGroup.setSelected(option2);
        
        // Verify the selected value is maintained
        assertEquals(key2, optionGroup.getSelected());
    }


}
