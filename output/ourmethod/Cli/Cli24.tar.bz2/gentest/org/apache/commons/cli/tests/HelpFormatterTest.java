package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                        public void testRenderWrappedText_WithDifferentNewLineSetting() throws Exception {
                                                            HelpFormatter formatter = new HelpFormatter();
                                                            formatter.setNewLine("\r\n"); // Change newline setting
                                                            
                                                            StringBuffer sb = new StringBuffer();
                                                            String text = "Text with custom newline characters";
                                                            
                                                            // Use reflection to access protected method
                                                            Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                "renderWrappedText", 
                                                                StringBuffer.class, 
                                                                int.class, 
                                                                int.class, 
                                                                String.class
                                                            );
                                                            renderWrappedText.setAccessible(true);
                                                            StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                                formatter, 
                                                                sb, 
                                                                15, 
                                                                4, 
                                                                text
                                                            );
                                                            
                                                            String expected = "Text with custom\r\n    newline\r\n    characters";
                                                            assertEquals(expected, result.toString());
                                                        }

    @Test
                                                    public void testRenderWrappedText_NoWrapNeeded() throws Exception {
                                                        HelpFormatter helpFormatter = new HelpFormatter();
                                                        StringBuffer sb = new StringBuffer();
                                                        String text = "Short text";
                                                        
                                                        // Use reflection to access protected method
                                                        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                            "renderWrappedText", 
                                                            StringBuffer.class, 
                                                            int.class, 
                                                            int.class, 
                                                            String.class
                                                        );
                                                        renderWrappedText.setAccessible(true);
                                                        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                            helpFormatter, 
                                                            sb, 
                                                            50, 
                                                            10, 
                                                            text
                                                        );
                                                        
                                                        assertEquals("Short text", result.toString());
                                                        assertSame(sb, result); // Should return the same StringBuffer
                                                    }

    @Test
                                                    public void testRenderWrappedText_SingleWrap() throws Exception {
                                                        HelpFormatter helpFormatter = new HelpFormatter();
                                                        StringBuffer sb = new StringBuffer();
                                                        String text = "This is a longer text that needs wrapping";
                                                        
                                                        // Use reflection to access protected method
                                                        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                            "renderWrappedText", 
                                                            StringBuffer.class, 
                                                            int.class, 
                                                            int.class, 
                                                            String.class
                                                        );
                                                        renderWrappedText.setAccessible(true);
                                                        StringBuffer result = (StringBuffer) renderWrappedText.invoke(helpFormatter, sb, 20, 4, text);
                                                        
                                                        String expected = "This is a longer\ntext that needs\nwrapping";
                                                        assertEquals(expected, result.toString());
                                                    }

    @Test
                                                    public void testRenderWrappedText_MultipleWrapsWithPadding() throws Exception {
                                                        HelpFormatter helpFormatter = new HelpFormatter();
                                                        StringBuffer sb = new StringBuffer();
                                                        String text = "Very long text that requires multiple wrapping operations to fit within the specified width";
                                                        
                                                        // Use reflection to access the protected method
                                                        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                        renderWrappedText.setAccessible(true);
                                                        StringBuffer result = (StringBuffer) renderWrappedText.invoke(helpFormatter, sb, 30, 5, text);
                                                        
                                                        String expected = "Very long text that requires\n     multiple wrapping\n     operations to fit\n     within the specified\n     width";
                                                        assertEquals(expected, result.toString());
                                                    }

    @Test
                                                    public void testRenderWrappedText_EdgeCaseWidth() throws Exception {
                                                        HelpFormatter helpFormatter = new HelpFormatter();
                                                        StringBuffer sb = new StringBuffer();
                                                        String text = "Exactly fits";
                                                        
                                                        // Get the protected method using reflection
                                                        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                            "renderWrappedText", 
                                                            StringBuffer.class, 
                                                            int.class, 
                                                            int.class, 
                                                            String.class
                                                        );
                                                        renderWrappedText.setAccessible(true);
                                                        
                                                        // Invoke the method
                                                        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                            helpFormatter, 
                                                            sb, 
                                                            text.length(), 
                                                            4, 
                                                            text
                                                        );
                                                        
                                                        assertEquals(text, result.toString());
                                                    }

    @Test
                                                    public void testRenderWrappedText_NextLineTabStopLargerThanWidth() throws Exception {
                                                        HelpFormatter helpFormatter = new HelpFormatter();
                                                        StringBuffer sb = new StringBuffer();
                                                        String text = "Text with tab stop larger than width";
                                                        
                                                        // Use reflection to access protected method
                                                        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                        renderWrappedText.setAccessible(true);
                                                        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                            helpFormatter, sb, 20, 25, text);
                                                        
                                                        // Should adjust nextLineTabStop to width - 1
                                                        String expected = "Text with tab stop\nlarger than width";
                                                        assertEquals(expected, result.toString());
                                                    }

    @Test
                                                    public void testRenderWrappedText_EmptyString() throws Exception {
                                                        HelpFormatter helpFormatter = new HelpFormatter();
                                                        StringBuffer sb = new StringBuffer();
                                                        String text = "";
                                                        
                                                        // Get the protected method using reflection
                                                        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                            "renderWrappedText", 
                                                            StringBuffer.class, 
                                                            int.class, 
                                                            int.class, 
                                                            String.class
                                                        );
                                                        renderWrappedText.setAccessible(true);
                                                        
                                                        // Invoke the method
                                                        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                            helpFormatter, 
                                                            sb, 
                                                            30, 
                                                            4, 
                                                            text
                                                        );
                                                        
                                                        assertEquals("", result.toString());
                                                    }

    @Test
                                                    public void testRenderWrappedText_NullStringBuffer() throws Exception {
                                                        org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                        thrown.expect(NullPointerException.class);
                                                        HelpFormatter helpFormatter = new HelpFormatter();
                                                        
                                                        // Use reflection to access the protected method
                                                        java.lang.reflect.Method method = HelpFormatter.class.getDeclaredMethod(
                                                            "renderWrappedText", 
                                                            StringBuffer.class, 
                                                            int.class, 
                                                            int.class, 
                                                            String.class
                                                        );
                                                        method.setAccessible(true);
                                                        method.invoke(helpFormatter, null, 30, 4, "Some text");
                                                    }

    @Test
                                                    public void testRenderWrappedText_NullText() throws Exception {
                                                        HelpFormatter helpFormatter = new HelpFormatter();
                                                        Method method = HelpFormatter.class.getDeclaredMethod(
                                                            "renderWrappedText", 
                                                            StringBuffer.class, 
                                                            int.class, 
                                                            int.class, 
                                                            String.class
                                                        );
                                                        method.setAccessible(true);
                                                        
                                                        try {
                                                            method.invoke(helpFormatter, new StringBuffer(), 30, 4, null);
                                                            fail("Expected NullPointerException to be thrown");
                                                        } catch (InvocationTargetException e) {
                                                            assertTrue(e.getCause() instanceof NullPointerException);
                                                        }
                                                    }

    @Test
                                                    public void testRenderWrappedText_WithExistingBufferContent() throws Exception {
                                                        HelpFormatter helpFormatter = new HelpFormatter();
                                                        StringBuffer sb = new StringBuffer("Prefix ");
                                                        String text = "This should be wrapped";
                                                        
                                                        // Use reflection to access protected method
                                                        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                            "renderWrappedText", 
                                                            StringBuffer.class, 
                                                            int.class, 
                                                            int.class, 
                                                            String.class
                                                        );
                                                        renderWrappedText.setAccessible(true);
                                                        StringBuffer result = (StringBuffer) renderWrappedText.invoke(helpFormatter, sb, 15, 3, text);
                                                        
                                                        String expected = "Prefix This should\n   be wrapped";
                                                        assertEquals(expected, result.toString());
                                                    }

    @Test
                                                    public void testRenderWrappedText_SpecialCasePosEqualsTabStopMinusOne() throws Exception {
                                                        HelpFormatter helpFormatter = new HelpFormatter();
                                                        StringBuffer sb = new StringBuffer();
                                                        // Create a scenario where pos == nextLineTabStop - 1
                                                        String text = "This is a very specific test case that triggers the special condition in the code";
                                                        
                                                        // Use reflection to access the protected method
                                                        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                        renderWrappedText.setAccessible(true);
                                                        StringBuffer result = (StringBuffer) renderWrappedText.invoke(helpFormatter, sb, 20, 5, text);
                                                        
                                                        // The special condition should force pos = width in this case
                                                        String expected = "This is a very\n     specific test\n     case that\n     triggers the\n     special\n     condition in\n     the code";
                                                        assertEquals(expected, result.toString());
                                                    }

    @Test
                    public void testRenderWrappedText_WhenNextLineTabStopEqualsWidth_ShouldAdjustTabStop() throws Exception {
                        // Setup
                        HelpFormatter formatter = new HelpFormatter();
                        
                        // Use reflection to set the defaultNewLine field since it's likely protected
                        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                        defaultNewLineField.setAccessible(true);
                        defaultNewLineField.set(formatter, "\n");
                        
                        int width = 10;
                        int nextLineTabStop = 10; // Equal to width
                        String text = "This is a long text that needs to be wrapped properly";
                        StringBuffer sb = new StringBuffer();
                        
                        // Create a spy
                        HelpFormatter spyFormatter = spy(formatter);
                        
                        // Mock findWrapPos using reflection and method invocation
                        Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod("findWrapPos", 
                            String.class, int.class, int.class);
                        findWrapPosMethod.setAccessible(true);
                        when(findWrapPosMethod.invoke(spyFormatter, anyString(), anyInt(), anyInt())).thenReturn(5);
                        
                        // Mock createPadding using reflection and method invocation
                        Method createPaddingMethod = HelpFormatter.class.getDeclaredMethod("createPadding", int.class);
                        createPaddingMethod.setAccessible(true);
                        when(createPaddingMethod.invoke(spyFormatter, anyInt())).thenAnswer(invocation -> {
                            int len = (Integer) invocation.getArguments()[0];
                            char[] spaces = new char[len];
                            java.util.Arrays.fill(spaces, ' ');
                            return new String(spaces);
                        });
                        
                        // Execute using reflection
                        Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod("renderWrappedText", 
                            StringBuffer.class, int.class, int.class, String.class);
                        renderWrappedTextMethod.setAccessible(true);
                        StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(spyFormatter, sb, width, nextLineTabStop, text);
                        
                        // Instead of directly verifying the protected method call, we verify its effect
                        // by checking the output contains the expected padding
                        assertNotNull(result);
                        assertTrue(result.toString().contains("\n"));
                        
                        // Verify the padding was applied correctly by checking substring positions
                        String[] lines = result.toString().split("\n");
                        assertTrue(lines.length > 1);
                        assertTrue(lines[1].startsWith("         ")); // 9 spaces (width-1 padding)
                    }

    @Test
            public void testRenderWrappedText_NextLineTabStopAdjustment() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                // Use reflection to set private fields
                java.lang.reflect.Field widthField = HelpFormatter.class.getDeclaredField("defaultWidth");
                widthField.setAccessible(true);
                widthField.set(formatter, 10);
                
                java.lang.reflect.Field newLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                newLineField.setAccessible(true);
                newLineField.set(formatter, "\n");
                
                StringBuffer sb = new StringBuffer();
                int width = 10;
                int nextLineTabStop = 15; // This will trigger the adjustment
                String text = "This is a long text that needs to be wrapped properly";
                
                // Execute using reflection
                java.lang.reflect.Method method = HelpFormatter.class.getDeclaredMethod(
                    "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                method.setAccessible(true);
                StringBuffer result = (StringBuffer) method.invoke(formatter, sb, width, nextLineTabStop, text);
                
                // Verify the adjustment was made correctly
                // The original would set nextLineTabStop to width-1 (9)
                // The mutant would set it to width-2 (8)
                // We can verify by checking the padding in the output
                
                // Split the output into lines
                String output = result.toString();
                String[] lines = output.split("\n");
                
                // The second line should have padding equal to original nextLineTabStop adjustment (9 spaces)
                if (lines.length > 1) {
                    String secondLine = lines[1];
                    // Count leading spaces
                    int leadingSpaces = 0;
                    while (leadingSpaces < secondLine.length() && secondLine.charAt(leadingSpaces) == ' ') {
                        leadingSpaces++;
                    }
                    
                    // Original code would have 9 spaces (width-1)
                    // Mutant would have 8 spaces (width-2)
                    assertEquals("Should have adjusted nextLineTabStop to width-1 (9 spaces)", 
                                 9, leadingSpaces);
                } else {
                    fail("Output should have multiple lines to test wrapping behavior");
                }
                
                // Additional check to ensure no infinite loop occurred
                assertTrue("Output should not be empty", output.length() > 0);
            }

    @Test
    public void testRenderWrappedText_NextLineTabStopGreaterThanWidth() {
        // Setup
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n"); // Ensure consistent line endings
        StringBuffer sb = new StringBuffer();
        int width = 10;
        int nextLineTabStop = 15; // Greater than width
        String text = "This is a long text that needs to be wrapped properly with correct padding";
        
        // Create padding using reflection since createPadding is protected
        String expectedPadding;
        try {
            java.lang.reflect.Method createPaddingMethod = HelpFormatter.class.getDeclaredMethod("createPadding", int.class);
            createPaddingMethod.setAccessible(true);
            expectedPadding = (String) createPaddingMethod.invoke(formatter, width - 1);
        } catch (Exception e) {
            throw new RuntimeException("Failed to access createPadding method", e);
        }
        
        // Execute using reflection since renderWrappedText is protected
        StringBuffer result;
        try {
            java.lang.reflect.Method renderMethod = HelpFormatter.class.getDeclaredMethod(
                "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
            renderMethod.setAccessible(true);
            result = (StringBuffer) renderMethod.invoke(formatter, sb, width, nextLineTabStop, text);
        } catch (Exception e) {
            throw new RuntimeException("Failed to access renderWrappedText method", e);
        }
        
        // Verify
        String output = result.toString();
        // Check that the second line starts with proper padding
        String[] lines = output.split("\n");
        assertTrue(lines.length > 1); // Ensure wrapping occurred
        assertTrue("Second line should start with proper padding", 
                   lines[1].startsWith(expectedPadding));
        
        // Additional check for the padding length
        int paddingLength = 0;
        while (paddingLength < lines[1].length() && 
               lines[1].charAt(paddingLength) == ' ') {
            paddingLength++;
        }
        assertEquals("Padding length should be width-1", 
                    width - 1, paddingLength);
    }


}
