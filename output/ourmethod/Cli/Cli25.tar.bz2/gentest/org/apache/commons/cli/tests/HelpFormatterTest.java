package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                            public void testRenderWrappedText_NoWrapNeeded() throws Exception {
                                                                HelpFormatter helpFormatter = new HelpFormatter();
                                                                StringBuffer sb = new StringBuffer();
                                                                String text = "Short text";
                                                                
                                                                // Use reflection to access protected method
                                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                    "renderWrappedText", 
                                                                    StringBuffer.class, 
                                                                    int.class, 
                                                                    int.class, 
                                                                    String.class
                                                                );
                                                                renderWrappedText.setAccessible(true);
                                                                StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                                    helpFormatter, 
                                                                    sb, 
                                                                    50, 
                                                                    4, 
                                                                    text
                                                                );
                                                                
                                                                assertEquals("Short text", result.toString());
                                                            }

    @Test
                                                            public void testRenderWrappedText_SingleWrap() throws Exception {
                                                                HelpFormatter helpFormatter = new HelpFormatter();
                                                                StringBuffer sb = new StringBuffer();
                                                                String text = "This is a longer text that needs wrapping";
                                                                
                                                                // Use reflection to access protected method
                                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                    "renderWrappedText", 
                                                                    StringBuffer.class, 
                                                                    int.class, 
                                                                    int.class, 
                                                                    String.class
                                                                );
                                                                renderWrappedText.setAccessible(true);
                                                                StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                                    helpFormatter, 
                                                                    sb, 
                                                                    20, 
                                                                    4, 
                                                                    text
                                                                );
                                                                
                                                                String expected = "This is a longer\ntext that needs\nwrapping";
                                                                assertEquals(expected, result.toString());
                                                            }

    @Test
                                                            public void testRenderWrappedText_MultipleWrapsWithIndent() throws Exception {
                                                                HelpFormatter helpFormatter = new HelpFormatter();
                                                                StringBuffer sb = new StringBuffer();
                                                                String text = "This is a very long text that will require multiple wraps with proper indentation";
                                                                
                                                                // Use reflection to access the protected method
                                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                    "renderWrappedText", 
                                                                    StringBuffer.class, 
                                                                    int.class, 
                                                                    int.class, 
                                                                    String.class
                                                                );
                                                                renderWrappedText.setAccessible(true);
                                                                StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                                    helpFormatter, 
                                                                    sb, 
                                                                    30, 
                                                                    4, 
                                                                    text
                                                                );
                                                                
                                                                String expected = "This is a very long text\n    that will require\n    multiple wraps with\n    proper indentation";
                                                                assertEquals(expected, result.toString());
                                                            }

    @Test
                                                            public void testRenderWrappedText_EdgeCaseWidth() throws Exception {
                                                                HelpFormatter helpFormatter = new HelpFormatter();
                                                                StringBuffer sb = new StringBuffer();
                                                                String text = "Exactly twenty characters";
                                                                
                                                                // Use reflection to access the protected method
                                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                    "renderWrappedText", 
                                                                    StringBuffer.class, 
                                                                    int.class, 
                                                                    int.class, 
                                                                    String.class
                                                                );
                                                                renderWrappedText.setAccessible(true);
                                                                StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                                    helpFormatter, 
                                                                    sb, 
                                                                    20, 
                                                                    4, 
                                                                    text
                                                                );
                                                                
                                                                assertEquals("Exactly twenty\ncharacters", result.toString());
                                                            }

    @Test
                                                            public void testRenderWrappedText_NextLineTabStopLargerThanWidth() throws Exception {
                                                                HelpFormatter helpFormatter = new HelpFormatter();
                                                                StringBuffer sb = new StringBuffer();
                                                                String text = "Text with nextLineTabStop larger than width";
                                                                
                                                                // Use reflection to access protected method
                                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                    "renderWrappedText", 
                                                                    StringBuffer.class, 
                                                                    int.class, 
                                                                    int.class, 
                                                                    String.class
                                                                );
                                                                renderWrappedText.setAccessible(true);
                                                                renderWrappedText.invoke(helpFormatter, sb, 10, 15, text);
                                                                
                                                                // Verify the nextLineTabStop was adjusted to 1
                                                                String result = sb.toString();
                                                                assertTrue(result.contains("\n"));
                                                                assertFalse(result.contains("\n               ")); // Shouldn't have 15 spaces
                                                            }

    @Test
                                                            public void testRenderWrappedText_EmptyString() throws Exception {
                                                                HelpFormatter helpFormatter = new HelpFormatter();
                                                                StringBuffer sb = new StringBuffer();
                                                                String text = "";
                                                                
                                                                // Get the protected method using reflection
                                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                    "renderWrappedText", 
                                                                    StringBuffer.class, 
                                                                    int.class, 
                                                                    int.class, 
                                                                    String.class
                                                                );
                                                                renderWrappedText.setAccessible(true);
                                                                
                                                                // Invoke the method
                                                                StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                                    helpFormatter, 
                                                                    sb, 
                                                                    50, 
                                                                    4, 
                                                                    text
                                                                );
                                                                
                                                                assertEquals("", result.toString());
                                                            }

    @Test
                                                            public void testRenderWrappedText_NullTextThrowsException() {
                                                                HelpFormatter helpFormatter = new HelpFormatter();
                                                                StringBuffer sb = new StringBuffer();
                                                                
                                                                try {
                                                                    Method method = HelpFormatter.class.getDeclaredMethod(
                                                                        "renderWrappedText", 
                                                                        StringBuffer.class, 
                                                                        int.class, 
                                                                        int.class, 
                                                                        String.class
                                                                    );
                                                                    method.setAccessible(true);
                                                                    method.invoke(helpFormatter, sb, 50, 4, null);
                                                                    fail("Expected NullPointerException to be thrown");
                                                                } catch (InvocationTargetException e) {
                                                                    assertTrue(e.getCause() instanceof NullPointerException);
                                                                } catch (Exception e) {
                                                                    fail("Unexpected exception: " + e.getClass().getSimpleName());
                                                                }
                                                            }

    @Test
                                                            public void testRenderWrappedText_ZeroWidth() throws Exception {
                                                                String text = "Should handle zero width";
                                                                HelpFormatter helpFormatter = new HelpFormatter();
                                                                StringBuffer sb = new StringBuffer();
                                                                
                                                                // Use reflection to access protected method
                                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                    "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                renderWrappedText.setAccessible(true);
                                                                StringBuffer result = (StringBuffer) renderWrappedText.invoke(helpFormatter, sb, 0, 4, text);
                                                                
                                                                // Behavior might be undefined, but shouldn't throw exception
                                                                assertNotNull(result);
                                                            }

    @Test
                                                            public void testRenderWrappedText_SpecialCasePosEqualsTabStopMinusOne() throws Exception {
                                                                HelpFormatter helpFormatter = new HelpFormatter();
                                                                StringBuffer sb = new StringBuffer();
                                                                String text = "This text is designed to trigger the special case where pos equals nextLineTabStop-1";
                                                                
                                                                // Get the protected method using reflection
                                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                    "renderWrappedText", 
                                                                    StringBuffer.class, 
                                                                    int.class, 
                                                                    int.class, 
                                                                    String.class
                                                                );
                                                                renderWrappedText.setAccessible(true);
                                                                
                                                                // Invoke the method
                                                                StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                                    helpFormatter, 
                                                                    sb, 
                                                                    5, 
                                                                    4, 
                                                                    text
                                                                );
                                                                
                                                                // Verify the special case handling (pos = width)
                                                                assertTrue(result.toString().contains("\nThis"));
                                                            }

    @Test
                                                            public void testRenderWrappedText_PreservesExistingBufferContent() throws Exception {
                                                                HelpFormatter helpFormatter = new HelpFormatter();
                                                                StringBuffer sb = new StringBuffer();
                                                                sb.append("Prefix ");
                                                                String text = "text to wrap";
                                                                
                                                                // Use reflection to access protected method
                                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                    "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                renderWrappedText.setAccessible(true);
                                                                StringBuffer result = (StringBuffer) renderWrappedText.invoke(helpFormatter, sb, 10, 4, text);
                                                                
                                                                assertEquals("Prefix text to\n    wrap", result.toString());
                                                            }

    @Test
                                                            public void testRenderWrappedText_WithDifferentNewLineCharacter() throws Exception {
                                                                HelpFormatter helpFormatter = new HelpFormatter();
                                                                helpFormatter.setNewLine("\r\n");
                                                                StringBuffer sb = new StringBuffer();
                                                                String text = "Text with custom newline characters";
                                                                
                                                                // Use reflection to access protected method
                                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                    "renderWrappedText", 
                                                                    StringBuffer.class, 
                                                                    int.class, 
                                                                    int.class, 
                                                                    String.class
                                                                );
                                                                renderWrappedText.setAccessible(true);
                                                                StringBuffer result = (StringBuffer) renderWrappedText.invoke(helpFormatter, sb, 10, 4, text);
                                                                
                                                                assertTrue(result.toString().contains("\r\n"));
                                                            }

    @Test
                                                    public void testRenderWrappedText_WhenNextLineTabStopEqualsWidth_ShouldResetTabStop() throws Exception {
                                                        // Setup
                                                        HelpFormatter formatter = new HelpFormatter();
                                                        // Use reflection to set private fields
                                                        Field widthField = HelpFormatter.class.getDeclaredField("defaultWidth");
                                                        widthField.setAccessible(true);
                                                        widthField.set(formatter, 10);
                                                        
                                                        Field newLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                        newLineField.setAccessible(true);
                                                        newLineField.set(formatter, "\n");
                                                        
                                                        StringBuffer sb = new StringBuffer();
                                                        int width = 10;
                                                        int nextLineTabStop = 10; // Equal to width
                                                        String text = "This is a long text that needs to be wrapped properly";
                                                        
                                                        // Get the protected method via reflection
                                                        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                        renderWrappedText.setAccessible(true);
                                                        
                                                        // Execute
                                                        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                            formatter, sb, width, nextLineTabStop, text);
                                                        
                                                        // Verify
                                                        // The key assertion is that the test completes (no infinite loop)
                                                        // Also verify some basic formatting occurred
                                                        assertNotNull(result);
                                                        assertTrue(result.length() > 0);
                                                        
                                                        // Check that the text was actually wrapped (not just appended as-is)
                                                        String output = result.toString();
                                                        assertTrue(output.contains("\n"));
                                                        
                                                        // Verify the first line is within width
                                                        int firstNewLine = output.indexOf('\n');
                                                        assertTrue(firstNewLine <= width);
                                                        
                                                        // Verify subsequent lines have proper indentation
                                                        // Since nextLineTabStop was equal to width, it should have been reset to 1
                                                        // So second line should have 1 space indent
                                                        String secondLine = output.substring(firstNewLine + 1);
                                                        if (secondLine.length() > 0) {
                                                            assertTrue(secondLine.startsWith(" "));
                                                            assertFalse(secondLine.startsWith("  ")); // Should only be 1 space
                                                        }
                                                    }

    @Test
                                            public void testRenderWrappedText_NextLineTabStopAdjustment() throws Exception {
                                                // Setup
                                                HelpFormatter formatter = new HelpFormatter();
                                                
                                                // Use reflection to set protected field
                                                java.lang.reflect.Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                defaultNewLineField.setAccessible(true);
                                                defaultNewLineField.set(formatter, "\n");
                                                
                                                // Create a scenario where nextLineTabStop >= width
                                                int width = 10;
                                                int nextLineTabStop = 15; // Greater than width
                                                String text = "This is a long text that needs to be wrapped properly";
                                                StringBuffer sb = new StringBuffer();
                                                
                                                // Use reflection to access protected method
                                                java.lang.reflect.Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                    "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                renderWrappedText.setAccessible(true);
                                                
                                                // Execute
                                                StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
                                                
                                                // Verify the padding was adjusted correctly (should be 1, mutant would make it 0)
                                                // Find the first newline after initial line
                                                String output = result.toString();
                                                int firstNewline = output.indexOf('\n');
                                                assertTrue(firstNewline > 0); // Ensure we have wrapping
                                                
                                                // Get the next line
                                                String secondLine = output.substring(firstNewline + 1);
                                                assertTrue(secondLine.length() > 0);
                                                
                                                // Check that padding was applied (should start with at least one space)
                                                assertTrue("Wrapped line should start with padding space", 
                                                    secondLine.charAt(0) == ' ');
                                                
                                                // Verify padding length is not 0 (would happen with mutant)
                                                int paddingLength = 0;
                                                while (paddingLength < secondLine.length() && 
                                                       secondLine.charAt(paddingLength) == ' ') {
                                                    paddingLength++;
                                                }
                                                assertTrue("Padding should be at least 1 space (mutant would make it 0)",
                                                    paddingLength > 0);
                                            }

    @Test
                                    public void testRenderWrappedText_NextLineTabStopReset() throws Exception {
                                        // Setup
                                        HelpFormatter formatter = new HelpFormatter();
                                        // Use reflection to set the protected field
                                        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                        defaultNewLineField.setAccessible(true);
                                        defaultNewLineField.set(formatter, "\n");
                                        
                                        StringBuffer sb = new StringBuffer();
                                        int width = 10;
                                        int nextLineTabStop = 10; // This will trigger the reset condition
                                        String text = "This is a long text that needs to be wrapped properly";
                                        
                                        // Use reflection to access the protected method
                                        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                        renderWrappedText.setAccessible(true);
                                        
                                        // Execute
                                        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                            formatter, sb, width, nextLineTabStop, text);
                                        
                                        // Verify the padding was reset to 1 (not 2)
                                        // The second line should be indented with exactly 1 space
                                        String[] lines = result.toString().split("\n");
                                        if (lines.length > 1) {
                                            assertTrue("Second line should start with exactly 1 space", 
                                                      lines[1].startsWith(" "));
                                            assertEquals("Second line should have exactly 1 space indent", 
                                                         ' ', lines[1].charAt(0));
                                            assertNotEquals("Second line should not start with 2 spaces", 
                                                           "  ", lines[1].substring(0, 2));
                                        }
                                        
                                        // Additional verification for the reset value
                                        // We can check the padding by examining the wrapped lines
                                        boolean foundSingleSpaceIndent = false;
                                        for (int i = 1; i < lines.length; i++) {
                                            if (lines[i].startsWith(" ") && !lines[i].startsWith("  ")) {
                                                foundSingleSpaceIndent = true;
                                                break;
                                            }
                                        }
                                        assertTrue("Should find at least one line with single space indent", 
                                                   foundSingleSpaceIndent);
                                    }

    @Test
            public void testRenderWrappedText_NextLineTabStopEqualsWidth() throws Exception {
                // Setup
                HelpFormatter formatter = new HelpFormatter();
                Field defaultWidthField = HelpFormatter.class.getDeclaredField("defaultWidth");
                defaultWidthField.setAccessible(true);
                defaultWidthField.set(formatter, 10);
                
                Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                defaultNewLineField.setAccessible(true);
                defaultNewLineField.set(formatter, "\n");
                
                StringBuffer sb = new StringBuffer();
                String text = "This is a long text that needs to be wrapped";
                int width = 10;
                int nextLineTabStop = 10;  // Exactly equals width
                
                // Create a spy that will use reflection to call protected methods
                HelpFormatter spyFormatter = spy(formatter);
                
                // Mock findWrapPos using reflection
                Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod("findWrapPos", 
                    String.class, int.class, int.class);
                findWrapPosMethod.setAccessible(true);
                when(findWrapPosMethod.invoke(spyFormatter, anyString(), eq(width), eq(0)))
                    .thenReturn(8)
                    .thenReturn(18)
                    .thenReturn(-1);
                
                // Mock createPadding using reflection
                Method createPaddingMethod = HelpFormatter.class.getDeclaredMethod("createPadding", int.class);
                createPaddingMethod.setAccessible(true);
                when(createPaddingMethod.invoke(spyFormatter, anyInt()))
                    .thenReturn("    ");
                
                // Mock rtrim using reflection
                Method rtrimMethod = HelpFormatter.class.getDeclaredMethod("rtrim", String.class);
                rtrimMethod.setAccessible(true);
                when(rtrimMethod.invoke(spyFormatter, anyString()))
                    .thenAnswer(invocation -> invocation.getArguments()[0]);
                
                // Execute
                Method renderMethod = HelpFormatter.class.getDeclaredMethod("renderWrappedText", 
                    StringBuffer.class, int.class, int.class, String.class);
                renderMethod.setAccessible(true);
                StringBuffer result = (StringBuffer) renderMethod.invoke(spyFormatter, sb, width, nextLineTabStop, text);
                
                // Verify createPadding was called by checking the result contains the padding
                assertTrue(result.toString().contains("    "));
                
                // Additional assertions to verify overall behavior
                assertTrue(result.toString().contains("\n"));
                assertTrue(result.toString().length() > text.length());
            }

    @Test
    public void testRenderWrappedText_NextLineTabStopBoundary() throws Exception {
        // Setup
        HelpFormatter formatter = new HelpFormatter();
        formatter.setWidth(10);
        formatter.setNewLine("\n");
        
        StringBuffer sb = new StringBuffer();
        String text = "This is a long text that needs wrapping";
        
        // Get protected methods via reflection
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
        renderWrappedText.setAccessible(true);
        
        Method createPadding = HelpFormatter.class.getDeclaredMethod(
            "createPadding", int.class);
        createPadding.setAccessible(true);
        
        // Test case where nextLineTabStop equals width (10)
        // Original should reset to 1, mutant would also reset
        StringBuffer result1 = (StringBuffer) renderWrappedText.invoke(formatter, sb, 10, 10, text);
        String padding1 = (String) createPadding.invoke(formatter, 1); // Should be 1 space if reset
        
        // Test case where nextLineTabStop equals width-1 (9)
        // Original should NOT reset, mutant would reset
        StringBuffer sb2 = new StringBuffer();
        StringBuffer result2 = (StringBuffer) renderWrappedText.invoke(formatter, sb2, 10, 9, text);
        String padding2 = (String) createPadding.invoke(formatter, 9); // Should be 9 spaces if not reset
        
        // Verify
        // For width case (10), both original and mutant reset, so just verify behavior
        assertTrue(result1.toString().contains(padding1));
        
        // For width-1 case (9), this is where we catch the mutant
        // Original would use 9 spaces, mutant would use 1 space
        assertTrue(result2.toString().contains(padding2));
        
        // Additional verification that padding is indeed 9 spaces
        assertEquals("         ", padding2); // 9 spaces
    }


}
