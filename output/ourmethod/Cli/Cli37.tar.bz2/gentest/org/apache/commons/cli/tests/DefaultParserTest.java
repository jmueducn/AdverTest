package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
 
public class DefaultParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                public void testIsShortOption_EmptyStringReturnsFalse() throws Exception {
                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                    isShortOptionMethod.setAccessible(true);
                                                                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "");
                                                                                                    assertFalse(result);
                                                                                                }

    @Test
                                                                                                public void testIsShortOption_NonOptionStringReturnsFalse() throws Exception {
                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                    isShortOptionMethod.setAccessible(true);
                                                                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "filename");
                                                                                                    assertFalse(result);
                                                                                                }

    @Test
                                                                                                public void testIsShortOption_LongOptionFormatReturnsFalse() throws Exception {
                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                    isShortOptionMethod.setAccessible(true);
                                                                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "--file");
                                                                                                    assertFalse(result);
                                                                                                }

    @Test
                                                                                                public void testIsShortOption_OptionWithEmptyNameReturnsFalse() throws Exception {
                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                    isShortOptionMethod.setAccessible(true);
                                                                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "-=");
                                                                                                    assertFalse(result);
                                                                                                }

    @Test
                                                                                            public void testIsShortOption_ValidShortOptionWithoutValue() {
                                                                                                // Create mock Options
                                                                                                Options options = mock(Options.class);
                                                                                                when(options.hasShortOption("f")).thenReturn(true);
                                                                                                
                                                                                                // Create parser instance (assuming DefaultParser)
                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                
                                                                                                // Use reflection to set the private options field in parser
                                                                                                try {
                                                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                    optionsField.setAccessible(true);
                                                                                                    optionsField.set(parser, options);
                                                                                                } catch (Exception e) {
                                                                                                    fail("Failed to set options field via reflection");
                                                                                                }
                                                                                                
                                                                                                // Use reflection to access the private isShortOption method
                                                                                                try {
                                                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                    isShortOptionMethod.setAccessible(true);
                                                                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "-f");
                                                                                                    assertTrue(result);
                                                                                                } catch (Exception e) {
                                                                                                    fail("Failed to invoke isShortOption method via reflection");
                                                                                                }
                                                                                                
                                                                                                verify(options).hasShortOption("f");
                                                                                            }

    @Test
                                                                                            public void testIsShortOption_ValidShortOptionWithValue() throws Exception {
                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                
                                                                                                // Get the private method using reflection
                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                
                                                                                                // Invoke the method
                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, "-f=file.txt");
                                                                                                
                                                                                                assertTrue(result);
                                                                                            }

    @Test
                                                                                            public void testIsShortOption_InvalidShortOption() throws Exception {
                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                
                                                                                                // Use reflection to access the private method
                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                
                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, "-x");
                                                                                                assertFalse(result);
                                                                                            }

    @Test
                                                                                            public void testIsShortOption_SingleDashReturnsFalse() throws Exception {
                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, "-");
                                                                                                assertFalse(result);
                                                                                            }

    @Test
                                                                                            public void testIsShortOption_MultipleShortOptions() throws Exception {
                                                                                                // Setup mock objects - though they won't be used directly in this test
                                                                                                Options options = mock(Options.class);
                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                
                                                                                                // Get the private method using reflection
                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                
                                                                                                // Test the parser with different options using reflection
                                                                                                assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-a"));
                                                                                                assertFalse((Boolean) isShortOptionMethod.invoke(parser, "-b"));
                                                                                                assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-c"));
                                                                                                
                                                                                                // Verify the interactions - though these won't actually happen since we're bypassing the normal flow
                                                                                                verify(options, never()).hasShortOption("a");
                                                                                                verify(options, never()).hasShortOption("b");
                                                                                                verify(options, never()).hasShortOption("c");
                                                                                            }

    @Test(expected = NullPointerException.class)
                                                                                            public void testIsShortOption_NullInputThrowsException() throws Exception {
                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                Method method = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                method.setAccessible(true);
                                                                                                method.invoke(parser, (Object) null);
                                                                                            }

    @Test
                                                                                            public void testIsShortOption_OptionWithOnlyEqualsReturnsFalse() throws Exception {
                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, "-=value");
                                                                                                assertFalse(result);
                                                                                            }

    @Test
                                                                                public void testIsShortOptionWithMultipleEquals() {
                                                                                    // Setup
                                                                                    DefaultParser parser = new DefaultParser();
                                                                                    Options options = mock(Options.class);
                                                                                    
                                                                                    // Use reflection to set the private options field
                                                                                    try {
                                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                        optionsField.setAccessible(true);
                                                                                        optionsField.set(parser, options);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to set options field through reflection");
                                                                                    }
                                                                                    
                                                                                    // Token with multiple "=", where the option name is between first "-" and first "="
                                                                                    String token = "-opt=part1=part2";
                                                                                    
                                                                                    // Original behavior should look for "opt" as option name
                                                                                    // Mutated behavior would look for "opt=part1" as option name
                                                                                    when(options.hasShortOption("opt")).thenReturn(true);
                                                                                    when(options.hasShortOption("opt=part1")).thenReturn(false);
                                                                                    
                                                                                    // Use reflection to invoke the private method
                                                                                    try {
                                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                        isShortOptionMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                                                        
                                                                                        // Test and verify
                                                                                        assertTrue(result);
                                                                                        verify(options).hasShortOption("opt");
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to invoke isShortOption method through reflection");
                                                                                    }
                                                                                }

    @Test
                                                                                public void testIsShortOptionWithSingleEquals() throws Exception {
                                                                                    // Setup
                                                                                    DefaultParser parser = new DefaultParser();
                                                                                    
                                                                                    // Get protected options field and set mock
                                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                    optionsField.setAccessible(true);
                                                                                    Options mockOptions = mock(Options.class);
                                                                                    optionsField.set(parser, mockOptions);
                                                                                    
                                                                                    // Token with single "="
                                                                                    String token = "-opt=value";
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(mockOptions.hasShortOption("opt")).thenReturn(true);
                                                                                    
                                                                                    // Get private isShortOption method
                                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                    isShortOptionMethod.setAccessible(true);
                                                                                    
                                                                                    // Test and verify
                                                                                    assertTrue((Boolean) isShortOptionMethod.invoke(parser, token));
                                                                                    verify(mockOptions).hasShortOption("opt");
                                                                                }

    @Test
                                                                                public void testIsShortOptionWithoutEquals() throws Exception {
                                                                                    // Setup
                                                                                    DefaultParser parser = new DefaultParser();
                                                                                    Options options = mock(Options.class);
                                                                                    
                                                                                    // Use reflection to set protected field
                                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                    optionsField.setAccessible(true);
                                                                                    optionsField.set(parser, options);
                                                                                    
                                                                                    // Token without "="
                                                                                    String token = "-opt";
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(options.hasShortOption("opt")).thenReturn(true);
                                                                                    
                                                                                    // Use reflection to access private method
                                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                    isShortOptionMethod.setAccessible(true);
                                                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                                                    
                                                                                    // Test and verify
                                                                                    assertTrue(result);
                                                                                    verify(options).hasShortOption("opt");
                                                                                }

    @Test
                                                                        public void testIsShortOption_WithEqualsSign_ShouldExtractCorrectOptionName() throws Exception {
                                                                            // Setup
                                                                            DefaultParser parser = new DefaultParser();
                                                                            Options mockOptions = mock(Options.class);
                                                                            
                                                                            // Use reflection to set the protected options field
                                                                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                            optionsField.setAccessible(true);
                                                                            optionsField.set(parser, mockOptions);
                                                                            
                                                                            // Test token with "=" sign
                                                                            String tokenWithValue = "-f=value";
                                                                            
                                                                            // Mock behavior - should be called with just "f" (not "f=value")
                                                                            when(mockOptions.hasShortOption("f")).thenReturn(true);
                                                                            
                                                                            // Use reflection to access the private isShortOption method
                                                                            Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                            isShortOptionMethod.setAccessible(true);
                                                                            boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithValue);
                                                                            
                                                                            // Verify
                                                                            assertTrue("Should recognize valid short option with value", result);
                                                                            verify(mockOptions).hasShortOption("f");
                                                                        }

    @Test
                                                                        public void testIsShortOption_WithoutEqualsSign_ShouldWorkNormally() throws Exception {
                                                                            // Setup
                                                                            DefaultParser parser = new DefaultParser();
                                                                            Options mockOptions = mock(Options.class);
                                                                            
                                                                            // Use reflection to set protected field
                                                                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                            optionsField.setAccessible(true);
                                                                            optionsField.set(parser, mockOptions);
                                                                            
                                                                            // Test token without "=" sign
                                                                            String simpleToken = "-f";
                                                                            
                                                                            // Mock behavior
                                                                            when(mockOptions.hasShortOption("f")).thenReturn(true);
                                                                            
                                                                            // Use reflection to call private method
                                                                            Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                            isShortOptionMethod.setAccessible(true);
                                                                            boolean result = (boolean) isShortOptionMethod.invoke(parser, simpleToken);
                                                                            
                                                                            // Verify
                                                                            assertTrue("Should recognize valid simple short option", result);
                                                                            verify(mockOptions).hasShortOption("f");
                                                                        }

    @Test
                                                                public void testIsShortOption_WithEqualsSign_ShouldOnlyCheckPartBeforeEquals() throws Exception {
                                                                    // Setup
                                                                    DefaultParser parser = new DefaultParser();
                                                                    Options mockOptions = mock(Options.class);
                                                                    
                                                                    // Use reflection to set protected options field
                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                    optionsField.setAccessible(true);
                                                                    optionsField.set(parser, mockOptions);
                                                                    
                                                                    // Configure mock behavior
                                                                    when(mockOptions.hasShortOption("f")).thenReturn(true);
                                                                    when(mockOptions.hasShortOption("f=value")).thenReturn(false);
                                                                    
                                                                    // Test case that will detect the mutant
                                                                    String tokenWithEquals = "-f=value";
                                                                    
                                                                    // Use reflection to call private isShortOption method
                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                    isShortOptionMethod.setAccessible(true);
                                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithEquals);
                                                                    
                                                                    // This should pass in original code (checks "f") but fail in mutated code (checks "f=value")
                                                                    assertTrue(result);
                                                                    
                                                                    // Verify mock interactions
                                                                    verify(mockOptions).hasShortOption("f");
                                                                    verify(mockOptions, never()).hasShortOption("f=value");
                                                                }

    @Test
                                                                public void testIsShortOption_WithoutEqualsSign_ShouldCheckEntireOption() throws Exception {
                                                                    // Setup
                                                                    DefaultParser parser = new DefaultParser();
                                                                    
                                                                    // Use reflection to access and modify protected 'options' field
                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                    optionsField.setAccessible(true);
                                                                    Options mockOptions = mock(Options.class);
                                                                    optionsField.set(parser, mockOptions);
                                                                    
                                                                    // Configure mock behavior
                                                                    when(mockOptions.hasShortOption("f")).thenReturn(true);
                                                                    
                                                                    // Test case without equals sign
                                                                    String tokenWithoutEquals = "-f";
                                                                    
                                                                    // Use reflection to access private 'isShortOption' method
                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                    isShortOptionMethod.setAccessible(true);
                                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithoutEquals);
                                                                    
                                                                    // Assertion
                                                                    assertTrue(result);
                                                                    
                                                                    // Verify mock interaction
                                                                    verify(mockOptions).hasShortOption("f");
                                                                }

    @Test
                                                        public void testIsShortOption_WithEqualsSign_ShouldExcludeDashFromOptionName() throws Exception {
                                                            // Setup
                                                            DefaultParser parser = new DefaultParser();
                                                            
                                                            // Use reflection to access and mock the protected options field
                                                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                            optionsField.setAccessible(true);
                                                            Options mockedOptions = mock(Options.class);
                                                            optionsField.set(parser, mockedOptions);
                                                            
                                                            // Configure mock to return true only for correct option name "f"
                                                            when(mockedOptions.hasShortOption("f")).thenReturn(true);
                                                            when(mockedOptions.hasShortOption("-f")).thenReturn(false);
                                                            
                                                            // Use reflection to access the private isShortOption method
                                                            Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                            isShortOptionMethod.setAccessible(true);
                                                            
                                                            // Test with token that has equals sign
                                                            String tokenWithEquals = "-f=value";
                                                            
                                                            // Verify
                                                            assertTrue("Method should return true for valid short option with value",
                                                                      (Boolean) isShortOptionMethod.invoke(parser, tokenWithEquals));
                                                            
                                                            // Verify mock interactions
                                                            verify(mockedOptions).hasShortOption("f");
                                                            verify(mockedOptions, never()).hasShortOption("-f");
                                                        }

    @Test
                                                        public void testIsShortOption_WithoutEqualsSign_ShouldExcludeDash() throws Exception {
                                                            // Setup
                                                            DefaultParser parser = new DefaultParser();
                                                            
                                                            // Use reflection to set protected options field
                                                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                            optionsField.setAccessible(true);
                                                            Options mockOptions = mock(Options.class);
                                                            optionsField.set(parser, mockOptions);
                                                            
                                                            // Configure mock to return true only for correct option name "f"
                                                            when(mockOptions.hasShortOption("f")).thenReturn(true);
                                                            when(mockOptions.hasShortOption("-f")).thenReturn(false);
                                                            
                                                            // Use reflection to access private isShortOption method
                                                            Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                            isShortOptionMethod.setAccessible(true);
                                                            
                                                            // Test with simple short option
                                                            String simpleToken = "-f";
                                                            
                                                            // Verify
                                                            assertTrue("Method should return true for valid short option",
                                                                      (Boolean) isShortOptionMethod.invoke(parser, simpleToken));
                                                            
                                                            // Verify mock interactions
                                                            verify(mockOptions).hasShortOption("f");
                                                            verify(mockOptions, never()).hasShortOption("-f");
                                                        }

    @Test
                                            public void testIsShortOptionWithEqualsSign() {
                                                // Create mock Options
                                                Options options = mock(Options.class);
                                                // Create parser instance (assuming DefaultParser)
                                                DefaultParser parser = new DefaultParser();
                                                
                                                // Use reflection to set private options field in parser
                                                try {
                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                    optionsField.setAccessible(true);
                                                    optionsField.set(parser, options);
                                                } catch (Exception e) {
                                                    fail("Failed to set options field via reflection");
                                                }
                                                
                                                // Setup mock behavior
                                                when(options.hasShortOption("abc")).thenReturn(true);
                                                
                                                // Test with token that has = sign ("-abc=value")
                                                String token = "-abc=value";
                                                
                                                // Use reflection to invoke private isShortOption method
                                                boolean result;
                                                try {
                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                    isShortOptionMethod.setAccessible(true);
                                                    result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                } catch (Exception e) {
                                                    fail("Failed to invoke isShortOption method via reflection");
                                                    return;
                                                }
                                                
                                                // Verify the correct substring was used
                                                verify(options).hasShortOption("abc");
                                                assertTrue(result);
                                                
                                                // Additional verification that wrong substring isn't used
                                                verify(options, never()).hasShortOption("bc");
                                            }

    @Test
                                    public void testIsShortOption_WithEqualsSign_ShouldExcludeEqualsFromOptionName() throws Exception {
                                        // Setup
                                        DefaultParser parser = new DefaultParser();
                                        Options mockOptions = mock(Options.class);
                                        
                                        // Use reflection to set protected options field
                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                        optionsField.setAccessible(true);
                                        optionsField.set(parser, mockOptions);
                                        
                                        // Configure mock to return true for "o" but false for "o="
                                        when(mockOptions.hasShortOption("o")).thenReturn(true);
                                        when(mockOptions.hasShortOption("o=")).thenReturn(false);
                                        
                                        // Test token with equals sign
                                        String tokenWithEquals = "-o=value";
                                        
                                        // Use reflection to call private isShortOption method
                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                        isShortOptionMethod.setAccessible(true);
                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithEquals);
                                        
                                        // Assertions
                                        assertTrue("Method should return true for valid short option with value", result);
                                        
                                        // Verify mock interaction - should check for "o" not "o="
                                        verify(mockOptions).hasShortOption("o");
                                        verify(mockOptions, never()).hasShortOption("o=");
                                    }

    @Test
                                    public void testIsShortOption_WithoutEqualsSign_ShouldWorkNormally1() throws Exception {
                                        // Setup
                                        DefaultParser parser = new DefaultParser();
                                        
                                        // Use reflection to access protected options field
                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                        optionsField.setAccessible(true);
                                        Options mockOptions = mock(Options.class);
                                        optionsField.set(parser, mockOptions);
                                        
                                        // Configure mock
                                        when(mockOptions.hasShortOption("o")).thenReturn(true);
                                        
                                        // Test simple short option
                                        String simpleToken = "-o";
                                        
                                        // Use reflection to access private method
                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                        isShortOptionMethod.setAccessible(true);
                                        
                                        // Verify the method returns true
                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, simpleToken);
                                        
                                        // Assertions
                                        assertTrue("Method should return true for valid short option", result);
                                        verify(mockOptions).hasShortOption("o");
                                    }

    @Test
                            public void testIsShortOption_WithValueAssignment_ShouldReturnTrueForValidOption() throws Exception {
                                // Setup
                                DefaultParser parser = new DefaultParser();
                                Options mockOptions = mock(Options.class);
                                
                                // Use reflection to set protected options field
                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                optionsField.setAccessible(true);
                                optionsField.set(parser, mockOptions);
                                
                                // Test a short option with value assignment
                                String tokenWithValue = "-f=value";
                                
                                // Mock the options to return true for the correct option name "f"
                                when(mockOptions.hasShortOption("f")).thenReturn(true);
                                
                                // Use reflection to call private isShortOption method
                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                isShortOptionMethod.setAccessible(true);
                                boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithValue);
                                
                                // Execute and verify
                                assertTrue(result);
                                
                                // Verify the mock was called with the correct option name
                                verify(mockOptions).hasShortOption("f");
                            }

    @Test
                    public void testIsShortOption_WithNonExistingOption_ShouldReturnFalse() throws Exception {
                        // Setup
                        DefaultParser parser = new DefaultParser();
                        Options mockOptions = mock(Options.class);
                        
                        // Use reflection to set protected options field
                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                        optionsField.setAccessible(true);
                        optionsField.set(parser, mockOptions);
                        
                        // Configure mock to return false for any option check
                        when(mockOptions.hasShortOption(anyString())).thenReturn(false);
                        
                        // Test with a valid short option format that doesn't exist in options
                        String testToken = "-x";
                        
                        // Use reflection to access private isShortOption method
                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                        isShortOptionMethod.setAccessible(true);
                        boolean result = (boolean) isShortOptionMethod.invoke(parser, testToken);
                        
                        // Verify
                        assertFalse("Method should return false for non-existing option", result);
                        
                        // Verify mock interaction
                        verify(mockOptions).hasShortOption("x");
                    }

    @Test
            public void testIsShortOption_ValidSingleCharOption_ShouldReturnTrue() throws Exception {
                // Setup
                DefaultParser parser = new DefaultParser();
                Options mockOptions = mock(Options.class);
                
                // Use reflection to set protected options field
                Field optionsField = DefaultParser.class.getDeclaredField("options");
                optionsField.setAccessible(true);
                optionsField.set(parser, mockOptions);
                
                // Mock the options to return true for short option "a"
                when(mockOptions.hasShortOption("a")).thenReturn(true);
                
                // Use reflection to call private isShortOption method
                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                isShortOptionMethod.setAccessible(true);
                
                // Test with valid single-character option "-a"
                String token = "-a";
                boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                
                // Verify
                assertTrue("Valid single-character option should return true", result);
                verify(mockOptions).hasShortOption("a");
            }

    @Test
            public void testIsShortOption_SingleDash_ShouldReturnFalse() throws Exception {
                // Setup
                DefaultParser parser = new DefaultParser();
                Options mockOptions = mock(Options.class);
                
                // Set protected options field using reflection
                Field optionsField = DefaultParser.class.getDeclaredField("options");
                optionsField.setAccessible(true);
                optionsField.set(parser, mockOptions);
                
                // Get private isShortOption method using reflection
                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                isShortOptionMethod.setAccessible(true);
                
                // Test with single dash "-"
                String token = "-";
                boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                
                // Verify
                assertFalse("Single dash should return false", result);
                verify(mockOptions, never()).hasShortOption(anyString());
            }

    @Test
    public void testIsShortOption_WithEqualsSign_ShouldSplitCorrectly() throws Exception {
        // Setup
        DefaultParser parser = new DefaultParser();
        
        // Use reflection to access and set the protected options field
        Field optionsField = DefaultParser.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        Options mockOptions = mock(Options.class);
        optionsField.set(parser, mockOptions);
        
        // Create a test token with value: "-option=value"
        String tokenWithValue = "-option=value";
        
        // Mock the behavior of hasShortOption
        when(mockOptions.hasShortOption("option")).thenReturn(true);
        when(mockOptions.hasShortOption("option=value")).thenReturn(false);
        
        // Use reflection to access the private isShortOption method
        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
        isShortOptionMethod.setAccessible(true);
        boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithValue);
        
        // Verify - original would call with "option", mutant with "option=value"
        assertTrue("Method should return true for valid short option with value", result);
        
        // Verify the correct interaction
        verify(mockOptions).hasShortOption("option");
        verify(mockOptions, never()).hasShortOption("option=value");
    }


}
