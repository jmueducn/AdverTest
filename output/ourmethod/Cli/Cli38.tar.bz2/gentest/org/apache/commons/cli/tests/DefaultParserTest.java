package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
 
public class DefaultParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                public void testIsShortOption_NonOptionToken() throws Exception {
                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                                    isShortOptionMethod.setAccessible(true);
                                                                                                                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "token");
                                                                                                                                                    assertFalse(result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsShortOption_EmptyString() throws Exception {
                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                                    isShortOptionMethod.setAccessible(true);
                                                                                                                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "");
                                                                                                                                                    assertFalse(result);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsShortOption_MultipleDashes() throws Exception {
                                                                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                                    isShortOptionMethod.setAccessible(true);
                                                                                                                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "--f");
                                                                                                                                                    assertFalse(result);
                                                                                                                                                }

    @Test
                                                                                                                                            public void testIsShortOption_SingleDash() throws Exception {
                                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, "-");
                                                                                                                                                assertFalse(result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testIsShortOption_ValidShortOption() throws Exception {
                                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, "-f");
                                                                                                                                                assertTrue(result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testIsShortOption_ShortOptionWithValue() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                Options options = mock(Options.class);
                                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                                when(options.hasShortOption("f")).thenReturn(true);
                                                                                                                                                
                                                                                                                                                // Use reflection to access private method
                                                                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                                                                
                                                                                                                                                // Invoke the method and assert
                                                                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, "-f=value");
                                                                                                                                                assertTrue(result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testIsShortOption_ConcatenatedValidOptions() {
                                                                                                                                                // Create mock Options
                                                                                                                                                Options options = mock(Options.class);
                                                                                                                                                when(options.hasShortOption("a")).thenReturn(false);
                                                                                                                                                when(options.hasShortOption("b")).thenReturn(true);
                                                                                                                                                when(options.hasShortOption("c")).thenReturn(true);
                                                                                                                                                
                                                                                                                                                // Create parser instance (assuming DefaultParser)
                                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                                
                                                                                                                                                // Use reflection to set the private options field in parser
                                                                                                                                                try {
                                                                                                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                                    optionsField.setAccessible(true);
                                                                                                                                                    optionsField.set(parser, options);
                                                                                                                                                    
                                                                                                                                                    // Get the private isShortOption method
                                                                                                                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                                    isShortOptionMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // First character is invalid, but second is valid
                                                                                                                                                    assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-ab"));
                                                                                                                                                    
                                                                                                                                                    // First character is valid
                                                                                                                                                    assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-bc"));
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    fail("Failed to access private field or method via reflection: " + e.getMessage());
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                                                            public void testIsShortOption_InvalidShortOption() throws Exception {
                                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, "-x");
                                                                                                                                                assertFalse(result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testIsShortOption_NullInput() throws Exception {
                                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                                Method method = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                                method.setAccessible(true);
                                                                                                                                                
                                                                                                                                                try {
                                                                                                                                                    method.invoke(parser, (String) null);
                                                                                                                                                    fail("Expected NullPointerException to be thrown");
                                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                                    assertTrue(e.getCause() instanceof NullPointerException);
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                                                            public void testIsShortOption_ConcatenatedWithFirstValid() throws Exception {
                                                                                                                                                Options options = mock(Options.class);
                                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                                when(options.hasShortOption("a")).thenReturn(true);
                                                                                                                                                when(options.hasShortOption("b")).thenReturn(false);
                                                                                                                                                
                                                                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, "-ab");
                                                                                                                                                
                                                                                                                                                assertTrue(result);
                                                                                                                                            }

    @Test
                                                                                                                                            public void testIsShortOption_OptionWithEmptyValue() throws Exception {
                                                                                                                                                Options options = mock(Options.class);
                                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                                when(options.hasShortOption("f")).thenReturn(true);
                                                                                                                                                
                                                                                                                                                // Use reflection to access private method
                                                                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, "-f=");
                                                                                                                                                
                                                                                                                                                assertTrue(result);
                                                                                                                                            }

    @Test
                                                                                                                                    public void testIsShortOptionWithMultipleEqualsSigns() throws Exception {
                                                                                                                                        // Setup
                                                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                                                        
                                                                                                                                        // Create mock Options and set it using reflection
                                                                                                                                        Options mockOptions = mock(Options.class);
                                                                                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                        optionsField.setAccessible(true);
                                                                                                                                        optionsField.set(parser, mockOptions);
                                                                                                                                        
                                                                                                                                        // Token with multiple '=' signs - value contains '=' in it
                                                                                                                                        String token = "-option=value=with=equals";
                                                                                                                                        
                                                                                                                                        // Original behavior would extract "option" (first '=')
                                                                                                                                        // Mutated behavior would extract "option=value=with" (last '=')
                                                                                                                                        when(mockOptions.hasShortOption("option")).thenReturn(true);
                                                                                                                                        
                                                                                                                                        // Get and invoke the private isShortOption method using reflection
                                                                                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                        isShortOptionMethod.setAccessible(true);
                                                                                                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                                                                                                        
                                                                                                                                        // Test and verify
                                                                                                                                        assertTrue(result);
                                                                                                                                        
                                                                                                                                        // Verify the mock was called with the correct argument
                                                                                                                                        verify(mockOptions).hasShortOption("option");
                                                                                                                                    }

    @Test
                                                                                                                                    public void testIsShortOptionWithMultipleEqualsSigns_Concatenated() throws Exception {
                                                                                                                                        // Setup
                                                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                                                        
                                                                                                                                        // Get and set the protected options field using reflection
                                                                                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                        optionsField.setAccessible(true);
                                                                                                                                        Options optionsMock = mock(Options.class);
                                                                                                                                        optionsField.set(parser, optionsMock);
                                                                                                                                        
                                                                                                                                        // Token with multiple '=' signs and concatenated options
                                                                                                                                        String token = "-abc=value=with=equals";
                                                                                                                                        
                                                                                                                                        // Original behavior would check for "abc" and then "a"
                                                                                                                                        // Mutated behavior would check for "abc=value=with" and then "a"
                                                                                                                                        when(optionsMock.hasShortOption("abc")).thenReturn(false);
                                                                                                                                        when(optionsMock.hasShortOption("a")).thenReturn(true);
                                                                                                                                        
                                                                                                                                        // Get and invoke the private isShortOption method using reflection
                                                                                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                        isShortOptionMethod.setAccessible(true);
                                                                                                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                                                                                                        
                                                                                                                                        // Test and verify
                                                                                                                                        assertTrue(result);
                                                                                                                                        
                                                                                                                                        // Verify the mock was called with the correct arguments
                                                                                                                                        verify(optionsMock).hasShortOption("abc");
                                                                                                                                        verify(optionsMock).hasShortOption("a");
                                                                                                                                    }

    @Test
                                                                                                                            public void testIsShortOptionWithEqualsSign() throws Exception {
                                                                                                                                // Setup
                                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                                Options mockOptions = mock(Options.class);
                                                                                                                                
                                                                                                                                // Use reflection to set protected options field
                                                                                                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                                optionsField.setAccessible(true);
                                                                                                                                optionsField.set(parser, mockOptions);
                                                                                                                                
                                                                                                                                // Token with equals sign
                                                                                                                                String tokenWithEquals = "-f=value";
                                                                                                                                
                                                                                                                                // Mock the behavior of options.hasShortOption
                                                                                                                                when(mockOptions.hasShortOption("f")).thenReturn(true);
                                                                                                                                
                                                                                                                                // Use reflection to call private isShortOption method
                                                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithEquals);
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                                assertTrue("The method should return true for a valid short option with equals sign", result);
                                                                                                                                
                                                                                                                                // Verify that the correct option name was extracted and checked
                                                                                                                                verify(mockOptions).hasShortOption("f");
                                                                                                                            }

    @Test
                                                                                                                    public void testIsShortOptionWithEqualsSign1() throws Exception {
                                                                                                                        // Setup
                                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                                        Options options = mock(Options.class);
                                                                                                                        
                                                                                                                        // Set protected options field using reflection
                                                                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                        optionsField.setAccessible(true);
                                                                                                                        optionsField.set(parser, options);
                                                                                                                        
                                                                                                                        // Get private isShortOption method using reflection
                                                                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                        isShortOptionMethod.setAccessible(true);
                                                                                                                        
                                                                                                                        // Mock behavior - option "f" exists, "x" doesn't
                                                                                                                        when(options.hasShortOption("f")).thenReturn(true);
                                                                                                                        when(options.hasShortOption("x")).thenReturn(false);
                                                                                                                        
                                                                                                                        // Test case where mutation would cause different behavior
                                                                                                                        // Original: "-f=value" → extracts "f" → returns true
                                                                                                                        // Mutant: "-f=value" → extracts "" (empty string) → returns false
                                                                                                                        assertTrue("Should recognize valid short option with value", 
                                                                                                                                  (Boolean) isShortOptionMethod.invoke(parser, "-f=value"));
                                                                                                                        
                                                                                                                        // Additional test cases for thorough coverage
                                                                                                                        // Simple short option
                                                                                                                        assertTrue("Should recognize valid short option", 
                                                                                                                                  (Boolean) isShortOptionMethod.invoke(parser, "-f"));
                                                                                                                        
                                                                                                                        // Invalid short option
                                                                                                                        assertFalse("Should reject invalid short option", 
                                                                                                                                   (Boolean) isShortOptionMethod.invoke(parser, "-x"));
                                                                                                                        
                                                                                                                        // Concatenated short options
                                                                                                                        when(options.hasShortOption("a")).thenReturn(true);
                                                                                                                        assertTrue("Should recognize first of concatenated options", 
                                                                                                                                  (Boolean) isShortOptionMethod.invoke(parser, "-abc"));
                                                                                                                        
                                                                                                                        // Not a short option (doesn't start with -)
                                                                                                                        assertFalse("Should reject non-option token", 
                                                                                                                                   (Boolean) isShortOptionMethod.invoke(parser, "filename"));
                                                                                                                        
                                                                                                                        // Invalid format (just "-")
                                                                                                                        assertFalse("Should reject single '-'", 
                                                                                                                                   (Boolean) isShortOptionMethod.invoke(parser, "-"));
                                                                                                                    }

    @Test
                                                                                                            public void testIsShortOption_WithEqualSign_DetectsMutant() throws Exception {
                                                                                                                // Setup
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Create mock Options and set it to parser using reflection
                                                                                                                Options mockOptions = mock(Options.class);
                                                                                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                optionsField.setAccessible(true);
                                                                                                                optionsField.set(parser, mockOptions);
                                                                                                                
                                                                                                                // Token with "=" where the option exists before "="
                                                                                                                String tokenWithEqual = "-f=value";
                                                                                                                
                                                                                                                // Mock behavior - option "f" exists
                                                                                                                when(mockOptions.hasShortOption("f")).thenReturn(true);
                                                                                                                
                                                                                                                // Get the private isShortOption method using reflection
                                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Original should return true (f is a valid option)
                                                                                                                // Mutant would check "f=value" which presumably doesn't exist
                                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithEqual);
                                                                                                                assertTrue(result);
                                                                                                                
                                                                                                                // Verify the mock was called with the correct argument
                                                                                                                verify(mockOptions).hasShortOption("f");
                                                                                                            }

    @Test
                                                                                                            public void testIsShortOption_WithoutEqualSign_DetectsMutant() throws Exception {
                                                                                                                // Setup
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                Options mockOptions = mock(Options.class);
                                                                                                                
                                                                                                                // Use reflection to set the protected options field
                                                                                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                optionsField.setAccessible(true);
                                                                                                                optionsField.set(parser, mockOptions);
                                                                                                                
                                                                                                                // Token without "="
                                                                                                                String tokenWithoutEqual = "-f";
                                                                                                                
                                                                                                                // Mock behavior - option "f" exists
                                                                                                                when(mockOptions.hasShortOption("f")).thenReturn(true);
                                                                                                                
                                                                                                                // Use reflection to access the private isShortOption method
                                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Original should return true (f is a valid option)
                                                                                                                // Mutant would check empty string which doesn't exist
                                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithoutEqual);
                                                                                                                assertTrue(result);
                                                                                                                
                                                                                                                // Verify the mock was called with the correct argument
                                                                                                                verify(mockOptions).hasShortOption("f");
                                                                                                            }

    @Test
                                                                                                    public void testIsShortOption_DetectsSubstringMutation() throws Exception {
                                                                                                        // Setup
                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                        
                                                                                                        // Get protected options field and set mock
                                                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                        optionsField.setAccessible(true);
                                                                                                        Options mockOptions = mock(Options.class);
                                                                                                        optionsField.set(parser, mockOptions);
                                                                                                        
                                                                                                        // Test case where token is "-o" (valid short option)
                                                                                                        String token = "-o";
                                                                                                        
                                                                                                        // Mock options to return true for "o" but false for "-o"
                                                                                                        when(mockOptions.hasShortOption("o")).thenReturn(true);
                                                                                                        when(mockOptions.hasShortOption("-o")).thenReturn(false);
                                                                                                        
                                                                                                        // Get private isShortOption method
                                                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                        isShortOptionMethod.setAccessible(true);
                                                                                                        
                                                                                                        // Test original behavior (should return true)
                                                                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                                                                        assertTrue("Original method should recognize -o as valid short option", result);
                                                                                                        
                                                                                                        // If mutated (using substring(0)), it would look for "-o" instead of "o" and return false
                                                                                                        // This assertion verifies we're testing the right behavior
                                                                                                        assertFalse("Mutated version would fail here", mockOptions.hasShortOption("-o"));
                                                                                                    }

    @Test
                                                                                            public void testIsShortOption_WithEqualsSign_ShouldDetectMutant() throws Exception {
                                                                                                // Setup
                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                Options options = mock(Options.class);
                                                                                                
                                                                                                // Use reflection to set protected field
                                                                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                optionsField.setAccessible(true);
                                                                                                optionsField.set(parser, options);
                                                                                                
                                                                                                // Mock behavior - return true for "a" but false for "-a"
                                                                                                when(options.hasShortOption("a")).thenReturn(true);
                                                                                                when(options.hasShortOption("-a")).thenReturn(false);
                                                                                                
                                                                                                // Test with token that has equals sign
                                                                                                String tokenWithValue = "-a=value";
                                                                                                
                                                                                                // Use reflection to access private method
                                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                                isShortOptionMethod.setAccessible(true);
                                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithValue);
                                                                                                
                                                                                                // Original should return true (valid short option)
                                                                                                // Mutated will return false because it checks for "-a" which we mocked to return false
                                                                                                assertTrue(result);
                                                                                                
                                                                                                // Verify mock interactions
                                                                                                verify(options).hasShortOption("a");
                                                                                                verify(options, never()).hasShortOption("-a");
                                                                                            }

    @Test
                                                                                    public void testIsShortOptionWithEqualsSign2() throws Exception {
                                                                                        // Setup
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        
                                                                                        // Use reflection to access and mock the protected options field
                                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                        optionsField.setAccessible(true);
                                                                                        Options mockedOptions = mock(Options.class);
                                                                                        optionsField.set(parser, mockedOptions);
                                                                                        
                                                                                        // Test case where option has a value (contains "=")
                                                                                        String tokenWithValue = "-f=value";
                                                                                        
                                                                                        // Mock the options to return true when asked for short option "f"
                                                                                        when(mockedOptions.hasShortOption("f")).thenReturn(true);
                                                                                        
                                                                                        // Use reflection to access the private isShortOption method
                                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                        isShortOptionMethod.setAccessible(true);
                                                                                        
                                                                                        // The original code should return true since it checks "f"
                                                                                        // The mutant would check "f=" which shouldn't match
                                                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, tokenWithValue);
                                                                                        
                                                                                        // Verify the correct behavior
                                                                                        assertTrue(result);
                                                                                        
                                                                                        // Verify the mock was called with the correct parameter ("f" not "f=")
                                                                                        verify(mockedOptions).hasShortOption("f");
                                                                                        
                                                                                        // Additional check for concatenated options
                                                                                        when(mockedOptions.hasShortOption("f")).thenReturn(false);
                                                                                        when(mockedOptions.hasShortOption("b")).thenReturn(true);
                                                                                        String concatenatedOptions = "-fb=value";
                                                                                        assertTrue((boolean) isShortOptionMethod.invoke(parser, concatenatedOptions));
                                                                                        verify(mockedOptions).hasShortOption("f");
                                                                                        verify(mockedOptions).hasShortOption("b");
                                                                                    }

    @Test
                                                                            public void testIsShortOption_WithExistingOption_ShouldReturnTrue() throws Exception {
                                                                                // Setup
                                                                                String token = "-f=value";
                                                                                Options options = mock(Options.class);
                                                                                when(options.hasShortOption("f")).thenReturn(true);
                                                                                
                                                                                // Create parser instance and set options via reflection
                                                                                DefaultParser parser = new DefaultParser();
                                                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                optionsField.setAccessible(true);
                                                                                optionsField.set(parser, options);
                                                                                
                                                                                // Get the private method via reflection
                                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                isShortOptionMethod.setAccessible(true);
                                                                                
                                                                                // Test
                                                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                                                
                                                                                // Verify
                                                                                assertTrue("Method should return true for existing short option", result);
                                                                                verify(options).hasShortOption("f");
                                                                            }

    @Test
                                                                    public void testIsShortOption_CaseSensitiveCheck() throws Exception {
                                                                        // Setup
                                                                        DefaultParser parser = new DefaultParser();
                                                                        Options options = mock(Options.class);
                                                                        
                                                                        // Use reflection to set protected options field
                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                        optionsField.setAccessible(true);
                                                                        optionsField.set(parser, options);
                                                                        
                                                                        // Create a short option with uppercase letter
                                                                        Option testOption = Option.builder("A").build();
                                                                        when(options.hasShortOption("A")).thenReturn(true);
                                                                        when(options.hasShortOption("a")).thenReturn(false);
                                                                        
                                                                        // Test with lowercase version of the option
                                                                        String token = "-a";
                                                                        
                                                                        // Use reflection to access private isShortOption method
                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                        isShortOptionMethod.setAccessible(true);
                                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                                        
                                                                        // Assertions
                                                                        assertFalse("Method should be case-sensitive and return false for wrong case", result);
                                                                        
                                                                        // Verify mock interactions
                                                                        verify(options).hasShortOption("a");
                                                                    }

    @Test
                                                                    public void testIsShortOption_DetectCaseInsensitiveMutant() throws Exception {
                                                                        // Setup
                                                                        DefaultParser parser = new DefaultParser();
                                                                        Options options = mock(Options.class);
                                                                        
                                                                        // Use reflection to set protected options field
                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                        optionsField.setAccessible(true);
                                                                        optionsField.set(parser, options);
                                                                        
                                                                        // Configure options to only have uppercase "A" as valid short option
                                                                        when(options.hasShortOption("A")).thenReturn(true);
                                                                        when(options.hasShortOption("a")).thenReturn(false);
                                                                        
                                                                        // Test with lowercase option that only mutated version would match
                                                                        String token = "-a";
                                                                        
                                                                        // Use reflection to call private isShortOption method
                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                        isShortOptionMethod.setAccessible(true);
                                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                                        
                                                                        // Assert - original should return false, mutant would return true
                                                                        assertFalse("Method should be case-sensitive and not match 'a' to 'A'", result);
                                                                        
                                                                        // Verify the mock was called with exact case (not lowercase)
                                                                        verify(options).hasShortOption("a");
                                                                    }

    @Test
                                                                    public void testIsShortOption_DetectCaseInsensitiveMutant1() throws Exception {
                                                                        // Setup
                                                                        DefaultParser parser = new DefaultParser();
                                                                        Options options = mock(Options.class);
                                                                        
                                                                        // Use reflection to set protected field
                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                        optionsField.setAccessible(true);
                                                                        optionsField.set(parser, options);
                                                                        
                                                                        // Configure options mock behavior
                                                                        // Original code checks for exact match of "A"
                                                                        // Mutant would check for "A".toLowerCase() which is "a"
                                                                        when(options.hasShortOption("A")).thenReturn(true);
                                                                        when(options.hasShortOption("a")).thenReturn(false);
                                                                        
                                                                        // Get private method via reflection
                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                        isShortOptionMethod.setAccessible(true);
                                                                        
                                                                        // Test token that would only pass in mutant
                                                                        String token = "-A";
                                                                        
                                                                        // Execute
                                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                                        
                                                                        // Assert - both versions should return true in this case
                                                                        // Need a different approach to catch the mutant
                                                                        
                                                                        // Better test: use a token with mixed case
                                                                        token = "-Ab";
                                                                        when(options.hasShortOption("Ab")).thenReturn(false);
                                                                        when(options.hasShortOption("ab")).thenReturn(true); // mutant would find this
                                                                        
                                                                        result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                                        assertFalse("Method should be case-sensitive", result);
                                                                        
                                                                        // Verify mock interaction
                                                                        verify(options).hasShortOption("Ab");
                                                                        // Mutant would have called hasShortOption("ab") instead
                                                                    }

    @Test
                                                                    public void testIsShortOption_DetectCaseInsensitiveMutant2() throws Exception {
                                                                        // Setup
                                                                        DefaultParser parser = new DefaultParser();
                                                                        Options options = mock(Options.class);
                                                                        
                                                                        // Use reflection to set protected options field
                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                        optionsField.setAccessible(true);
                                                                        optionsField.set(parser, options);
                                                                        
                                                                        // Configure options to return true only for exact case match
                                                                        when(options.hasShortOption("Test")).thenReturn(true);
                                                                        when(options.hasShortOption("test")).thenReturn(false);
                                                                        
                                                                        // Test token with different case
                                                                        String token = "-test";
                                                                        
                                                                        // Use reflection to access private isShortOption method
                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                        isShortOptionMethod.setAccessible(true);
                                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                                        
                                                                        // Execute and verify
                                                                        assertFalse(result);
                                                                        
                                                                        // Verify mock was called with exact case
                                                                        verify(options).hasShortOption("test");
                                                                        verify(options, never()).hasShortOption("Test");
                                                                    }

    @Test
                                                            public void testIsShortOption_ShouldBeCaseSensitive_DetectsMutant() throws Exception {
                                                                // Setup
                                                                DefaultParser parser = new DefaultParser();
                                                                
                                                                // Get protected options field and set mock
                                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                optionsField.setAccessible(true);
                                                                Options mockOptions = mock(Options.class);
                                                                optionsField.set(parser, mockOptions);
                                                                
                                                                // Configure options to have a lowercase short option 'a' but not 'A'
                                                                when(mockOptions.hasShortOption("a")).thenReturn(true);
                                                                when(mockOptions.hasShortOption("A")).thenReturn(false);
                                                                when(mockOptions.hasShortOption("b")).thenReturn(false);
                                                                
                                                                // Get private isShortOption method
                                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                isShortOptionMethod.setAccessible(true);
                                                                
                                                                // Test case where option name matches exactly (should pass in both original and mutant)
                                                                assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-a"));
                                                                
                                                                // Test case where option name differs in case (should fail in original but pass in mutant)
                                                                // This is the test that detects the mutant
                                                                assertFalse("Method should be case-sensitive for full option names", 
                                                                           (Boolean) isShortOptionMethod.invoke(parser, "-A"));
                                                                
                                                                // Test case with non-existent option (should fail in both)
                                                                assertFalse((Boolean) isShortOptionMethod.invoke(parser, "-b"));
                                                                
                                                                // Test concatenated options (unchanged by this mutation)
                                                                when(mockOptions.hasShortOption("c")).thenReturn(true);
                                                                assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-cde"));
                                                            }

    @Test
                                                    public void testIsShortOptionWithEmptyOptionName() throws Exception {
                                                        // Setup
                                                        DefaultParser parser = new DefaultParser();
                                                        Options mockOptions = mock(Options.class);
                                                        
                                                        // Use reflection to set protected options field
                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                        optionsField.setAccessible(true);
                                                        optionsField.set(parser, mockOptions);
                                                        
                                                        // Test case where optName is empty (token is "-=")
                                                        String token = "-=";
                                                        
                                                        // Use reflection to call private isShortOption method
                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                        isShortOptionMethod.setAccessible(true);
                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                        
                                                        // Assert that the method returns false for empty option name
                                                        assertFalse(result);
                                                        
                                                        // Verify that hasShortOption was not called (since optName is empty)
                                                        verify(mockOptions, never()).hasShortOption(anyString());
                                                    }

    @Test
                                            public void testIsShortOptionWithSingleCharOption() throws Exception {
                                                // Setup
                                                DefaultParser parser = new DefaultParser();
                                                
                                                // Get protected options field and set mock
                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                optionsField.setAccessible(true);
                                                Options mockOptions = mock(Options.class);
                                                optionsField.set(parser, mockOptions);
                                                
                                                // The token represents a single-character short option ("-a")
                                                String token = "-a";
                                                
                                                // Mock the behavior of options.hasShortOption()
                                                when(mockOptions.hasShortOption("a")).thenReturn(true);
                                                
                                                // Get private isShortOption method
                                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                isShortOptionMethod.setAccessible(true);
                                                
                                                // Test
                                                boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                                
                                                // Verify
                                                assertTrue("The method should return true for a valid single-character short option", result);
                                                
                                                // Verify that hasShortOption was called with the correct argument
                                                verify(mockOptions).hasShortOption("a");
                                            }

    @Test
                                    public void testIsShortOption_ConcatenatedOptions_ShouldCheckFirstCharOnly() throws Exception {
                                        // Setup
                                        DefaultParser parser = new DefaultParser();
                                        
                                        // Use reflection to access and mock the protected options field
                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                        optionsField.setAccessible(true);
                                        Options mockedOptions = mock(Options.class);
                                        optionsField.set(parser, mockedOptions);
                                        
                                        // Mock behavior - first char is valid option, full string is not
                                        when(mockedOptions.hasShortOption("a")).thenReturn(true);
                                        when(mockedOptions.hasShortOption("abc")).thenReturn(false);
                                        
                                        // Use reflection to access the private isShortOption method
                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                        isShortOptionMethod.setAccessible(true);
                                        
                                        // Test concatenated short options "-abc"
                                        String token = "-abc";
                                        
                                        // Verify
                                        assertTrue((Boolean) isShortOptionMethod.invoke(parser, token));
                                        
                                        // Verify mock interactions - should only check first character
                                        verify(mockedOptions).hasShortOption("a");
                                        verify(mockedOptions, never()).hasShortOption("abc");
                                    }

    @Test
                            public void testIsShortOptionWithConcatenatedOptions() throws Exception {
                                // Setup
                                DefaultParser parser = new DefaultParser();
                                
                                // Use reflection to access and mock the protected options field
                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                optionsField.setAccessible(true);
                                Options mockedOptions = mock(Options.class);
                                optionsField.set(parser, mockedOptions);
                                
                                // Mock behavior - exact option doesn't exist, but first character does
                                when(mockedOptions.hasShortOption("abc")).thenReturn(false);
                                when(mockedOptions.hasShortOption("a")).thenReturn(true);
                                
                                // Use reflection to access the private isShortOption method
                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                isShortOptionMethod.setAccessible(true);
                                
                                // Test concatenated short option "-abc"
                                String token = "-abc";
                                boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                
                                // Verify - original would return true, mutant returns false
                                assertTrue("Should return true for concatenated short options", result);
                                
                                // Verify interactions
                                verify(mockedOptions).hasShortOption("abc");
                                verify(mockedOptions).hasShortOption("a");
                            }

    @Test
                    public void testIsShortOptionWithConcatenatedOptions1() throws Exception {
                        // Setup
                        DefaultParser parser = new DefaultParser();
                        
                        // Get protected options field and set mock
                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                        optionsField.setAccessible(true);
                        Options mockOptions = mock(Options.class);
                        optionsField.set(parser, mockOptions);
                        
                        // Mock behavior - first character 'a' is a valid short option
                        when(mockOptions.hasShortOption("abc")).thenReturn(false); // full option not present
                        when(mockOptions.hasShortOption("a")).thenReturn(true); // first character is valid
                        
                        // Get private isShortOption method
                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                        isShortOptionMethod.setAccessible(true);
                        
                        // Test with concatenated short options "-abc"
                        String token = "-abc";
                        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                        
                        // Verify
                        assertTrue("Method should return true for valid concatenated short options", result);
                        
                        // Verify interactions
                        verify(mockOptions).hasShortOption("abc");
                        verify(mockOptions).hasShortOption("a");
                    }

    @Test
            public void testIsShortOption_ConcatenatedOptions_DetectsMutant() throws Exception {
                // Setup
                DefaultParser parser = new DefaultParser();
                Options mockOptions = mock(Options.class);
                
                // Use reflection to set protected options field
                Field optionsField = DefaultParser.class.getDeclaredField("options");
                optionsField.setAccessible(true);
                optionsField.set(parser, mockOptions);
                
                // Mock behavior - full option not present, but first character is present
                when(mockOptions.hasShortOption("abc")).thenReturn(false);
                when(mockOptions.hasShortOption("a")).thenReturn(true);
                
                // Use reflection to access private isShortOption method
                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                isShortOptionMethod.setAccessible(true);
                
                // Test concatenated short option "-abc"
                String token = "-abc";
                boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                
                // Verify - original should return true, mutant will return false
                assertTrue("Should return true for concatenated options where first character is valid", result);
                
                // Verify mock interactions
                verify(mockOptions).hasShortOption("abc");
                verify(mockOptions).hasShortOption("a");
            }

    @Test
    public void testIsShortOption_ShouldBeCaseSensitiveForConcatenatedOptions() throws Exception {
        // Setup
        DefaultParser parser = new DefaultParser();
        
        // Get the options field and make it accessible
        Field optionsField = DefaultParser.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        
        // Create mock Options and set it to parser
        Options mockOptions = mock(Options.class);
        optionsField.set(parser, mockOptions);
        
        // Mock options.hasShortOption() behavior
        when(mockOptions.hasShortOption("A")).thenReturn(true);  // Uppercase exists
        when(mockOptions.hasShortOption("a")).thenReturn(false); // Lowercase doesn't
        
        // Get the isShortOption method and make it accessible
        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
        isShortOptionMethod.setAccessible(true);
        
        // Test with concatenated options where first character is uppercase
        String token = "-AB=value";
        
        // Verify original behavior (should be case-sensitive)
        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
        
        // Assert that it returns false because "a" doesn't exist (case-sensitive check)
        // This will catch the mutant which would convert to lowercase and return true
        assertFalse(result);
        
        // Verify interaction
        verify(mockOptions).hasShortOption("AB");
        verify(mockOptions).hasShortOption("A");
    }

    @Test
    public void testIsShortOption_ShouldWorkForSingleCaseSensitiveOption() throws Exception {
        // Setup
        DefaultParser parser = new DefaultParser();
        
        // Use reflection to access protected options field
        Field optionsField = DefaultParser.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        Options options = mock(Options.class);
        optionsField.set(parser, options);
        
        // Mock options.hasShortOption() behavior
        when(options.hasShortOption("A")).thenReturn(true);
        when(options.hasShortOption("a")).thenReturn(false);
        
        // Test with single uppercase option
        String token = "-A=value";
        
        // Use reflection to access private isShortOption method
        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
        isShortOptionMethod.setAccessible(true);
        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
        
        // Should return true because "A" exists
        assertTrue(result);
        
        // Verify interaction
        verify(options).hasShortOption("A");
    }


}
