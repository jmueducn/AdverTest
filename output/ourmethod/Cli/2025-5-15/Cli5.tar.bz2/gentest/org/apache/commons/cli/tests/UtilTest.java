package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
 
public class UtilTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                          public void testStripLeadingHyphens_NullInput() throws Exception {
                              Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                              Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                              stripLeadingHyphens.setAccessible(true);
                              String result = (String) stripLeadingHyphens.invoke(null, (String) null);
                              assertNull(result);
                          }

    @Test
                          public void testStripLeadingHyphens_EmptyString() throws Exception {
                              Class<?> clazz = Class.forName("org.apache.commons.cli.Util");
                              Method method = clazz.getDeclaredMethod("stripLeadingHyphens", String.class);
                              method.setAccessible(true);
                              String result = (String) method.invoke(null, "");
                              assertEquals("", result);
                          }

    @Test
                          public void testStripLeadingHyphens_SingleHyphen() throws Exception {
                              Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                              Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                              stripLeadingHyphens.setAccessible(true);
                              String result = (String) stripLeadingHyphens.invoke(null, "-test");
                              assertEquals("test", result);
                          }

    @Test
                          public void testStripLeadingHyphens_DoubleHyphen() throws Exception {
                              Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                              Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                              stripLeadingHyphens.setAccessible(true);
                              String result = (String) stripLeadingHyphens.invoke(null, "--test");
                              assertEquals("test", result);
                          }

    @Test
                          public void testStripLeadingHyphens_MultipleHyphens() throws Exception {
                              Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                              Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                              stripLeadingHyphens.setAccessible(true);
                              
                              String result = (String) stripLeadingHyphens.invoke(null, "-----test");
                              assertEquals("---test", result);
                          }

    @Test
                          public void testStripLeadingHyphens_NoHyphen() throws Exception {
                              Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                              Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                              stripLeadingHyphens.setAccessible(true);
                              
                              String input = "test";
                              String result = (String) stripLeadingHyphens.invoke(null, input);
                              assertEquals("test", result);
                          }

    @Test
                          public void testStripLeadingHyphens_HyphenOnly() throws Exception {
                              Class<?> clazz = Class.forName("org.apache.commons.cli.Util");
                              Method method = clazz.getDeclaredMethod("stripLeadingHyphens", String.class);
                              method.setAccessible(true);
                              String result = (String) method.invoke(null, "-");
                              assertEquals("", result);
                          }

    @Test
                          public void testStripLeadingHyphens_DoubleHyphenOnly() throws Exception {
                              Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                              Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                              stripLeadingHyphens.setAccessible(true);
                              String result = (String) stripLeadingHyphens.invoke(null, "--");
                              assertEquals("", result);
                          }

    @Test
                          public void testStripLeadingHyphens_WhitespaceWithHyphen() throws Exception {
                              Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                              Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                              stripLeadingHyphens.setAccessible(true);
                              
                              String result = (String) stripLeadingHyphens.invoke(null, "-  test");
                              assertEquals("  test", result);
                          }

    @Test
                          public void testStripLeadingHyphens_HyphenInMiddle() throws Exception {
                              Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                              Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                              stripLeadingHyphens.setAccessible(true);
                              
                              String result = (String) stripLeadingHyphens.invoke(null, "test-test");
                              assertEquals("test-test", result);
                          }

    @Test
              public void testStripLeadingHyphens_HyphenAtEnd() throws Exception {
                  String input = "test-";
                  Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                  Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
                  stripLeadingHyphens.setAccessible(true);
                  String result = (String) stripLeadingHyphens.invoke(null, input);
                  assertEquals("test-", result);
              }

    @Test
         public void testStripLeadingHyphensWithNullInput() {
             // Test that null input returns null
             String input = null;
             String result = null;
             try {
                 Class<?> clazz = Class.forName("org.apache.commons.cli.Util");
                 Method method = clazz.getDeclaredMethod("stripLeadingHyphens", String.class);
                 method.setAccessible(true);
                 result = (String) method.invoke(null, input);
             } catch (Exception e) {
                 fail("Failed to invoke stripLeadingHyphens method: " + e.getMessage());
             }
             
             // Original behavior: should return null
             // Mutant behavior: will return the input (null) as string
             assertNull("Method should return null for null input", result);
         }

    @Test
         public void testStripLeadingHyphensWithDoubleHyphen() throws Exception {
             String input = "--test";
             Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
             Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
             stripLeadingHyphens.setAccessible(true);
             String result = (String) stripLeadingHyphens.invoke(null, input);
             assertEquals("Should remove both hyphens", "test", result);
         }

    @Test
         public void testStripLeadingHyphensWithSingleHyphen() throws Exception {
             String input = "-test";
             Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
             Method stripMethod = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
             stripMethod.setAccessible(true);
             String result = (String) stripMethod.invoke(null, input);
             assertEquals("Should remove single hyphen", "test", result);
         }

    @Test
         public void testStripLeadingHyphensWithNoHyphen() throws Exception {
             String input = "test";
             Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
             Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
             stripLeadingHyphens.setAccessible(true);
             String result = (String) stripLeadingHyphens.invoke(null, input);
             assertEquals("Should return same string", "test", result);
         }

    @Test
    public void testStripLeadingHyphens_DoubleHyphen1() {
        // This test will catch the mutant by checking behavior with "--" prefix
        String input = "--abc";
        
        // Original behavior should remove only "--"
        String expected = "abc";
        
        try {
            // Get the Util class and its stripLeadingHyphens method using reflection
            Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
            java.lang.reflect.Method method = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
            method.setAccessible(true);
            
            // Call the method using reflection
            String actual = (String) method.invoke(null, input);
            
            assertEquals("Should remove only two hyphens from '--abc'", expected, actual);
        } catch (Exception e) {
            fail("Failed to invoke stripLeadingHyphens method via reflection: " + e.getMessage());
        }
    }

    @Test
    public void testStripLeadingHyphens_NullInput1() throws Exception {
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
        stripLeadingHyphens.setAccessible(true);
        
        assertNull("Null input should return null", stripLeadingHyphens.invoke(null, (String)null));
    }

    @Test
    public void testStripLeadingHyphens_SingleHyphen1() {
        try {
            Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
            Method stripLeadingHyphens = utilClass.getDeclaredMethod("stripLeadingHyphens", String.class);
            stripLeadingHyphens.setAccessible(true);
            String result = (String) stripLeadingHyphens.invoke(null, "-abc");
            assertEquals("Should remove single hyphen", "abc", result);
        } catch (Exception e) {
            fail("Failed to test stripLeadingHyphens due to reflection error: " + e.getMessage());
        }
    }

    @Test
    public void testStripLeadingHyphens_NoHyphen1() {
        try {
            Class<?> cliClass = Class.forName("org.apache.commons.cli.Util");
            Method method = cliClass.getDeclaredMethod("stripLeadingHyphens", String.class);
            method.setAccessible(true);
            String result = (String) method.invoke(null, "abc");
            assertEquals("Should return same string", "abc", result);
        } catch (Exception e) {
            fail("Failed to test stripLeadingHyphens due to reflection error: " + e.getMessage());
        }
    }


}
