package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
 
public class OptionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                                                                                          public void testGetId_WithSingleCharacterOpt() {
                                                                                                                              Option option = new Option("a", "description");
                                                                                                                              assertEquals('a', option.getId());
                                                                                                                          }

 @Test
                                                                                                                          public void testGetId_WithMultiCharacterOpt() {
                                                                                                                              Option option = new Option("abc", "description");
                                                                                                                              assertEquals('a', option.getId());
                                                                                                                          }

 @Test
                                                                                                                          public void testGetId_WithSpecialCharacters() {
                                                                                                                              Option option1 = new Option("@", "description");
                                                                                                                              assertEquals('@', option1.getId());
                                                                                                                              
                                                                                                                              Option option2 = new Option("$test", "description");
                                                                                                                              assertEquals('$', option2.getId());
                                                                                                                          }

 @Test
                                                                                                                          public void testGetId_WithWhitespace() {
                                                                                                                              Option option1 = new Option(" test", "description");
                                                                                                                              assertEquals(' ', option1.getId());
                                                                                                                              
                                                                                                                              Option option2 = new Option("\ttest", "description");
                                                                                                                              assertEquals('\t', option2.getId());
                                                                                                                          }

 @Test
                                                                                                                          public void testGetId_WithUnicodeCharacters() {
                                                                                                                              Option option1 = new Option("日本語", "description");
                                                                                                                              assertEquals('日', option1.getId());
                                                                                                                              
                                                                                                                              Option option2 = new Option("☕", "description");
                                                                                                                              assertEquals('☕', option2.getId());
                                                                                                                          }

 @Test
                                                                                                                          public void testGetOpt_ReturnsNullWhenOptionNotSet() {
                                                                                                                              // Test when opt is null (though constructor validation should prevent this)
                                                                                                                              try {
                                                                                                                                  Option nullOption = new Option(null, "null option");
                                                                                                                                  fail("Expected IllegalArgumentException");
                                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                                  // Expected - OptionValidator should prevent null options
                                                                                                                              }
                                                                                                                          }

 @Test
                                                                                                                          public void testGetOpt_WithEmptyStringOption() {
                                                                                                                              // Test with empty string option (should be invalid)
                                                                                                                              try {
                                                                                                                                  Option emptyOption = new Option("", "empty option");
                                                                                                                                  fail("Expected IllegalArgumentException");
                                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                                  // Expected - OptionValidator should prevent empty options
                                                                                                                              }
                                                                                                                          }

 @Test
                                                                                                                          public void testGetOpt_WithSingleCharacterOption() {
                                                                                                                              // Test single character options
                                                                                                                              Option singleCharOption = new Option("a", "single char");
                                                                                                                              assertEquals("a", singleCharOption.getOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testGetOpt_WithMultiCharacterOption() {
                                                                                                                              // Test multi-character options (if allowed)
                                                                                                                              try {
                                                                                                                                  Option multiCharOption = new Option("abc", "multi char");
                                                                                                                                  // Depending on OptionValidator implementation, this might be allowed
                                                                                                                                  assertEquals("abc", multiCharOption.getOpt());
                                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                                  // If OptionValidator restricts to single character options
                                                                                                                                  // This is acceptable behavior
                                                                                                                              }
                                                                                                                          }

 @Test
                                                                                                                          public void testGetOpt_AfterOptionModificationThroughReflection() throws Exception {
                                                                                                                              // Test that getOpt returns the current value even if modified through reflection
                                                                                                                              Option option = new Option("x", "test option");
                                                                                                                              
                                                                                                                              // Use reflection to change the opt field
                                                                                                                              java.lang.reflect.Field field = Option.class.getDeclaredField("opt");
                                                                                                                              field.setAccessible(true);
                                                                                                                              field.set(option, "y");
                                                                                                                              
                                                                                                                              assertEquals("y", option.getOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testGetOpt_WithSpecialCharacters() {
                                                                                                                              // Test with special characters (if allowed by OptionValidator)
                                                                                                                              try {
                                                                                                                                  Option specialCharOption = new Option("@", "special char");
                                                                                                                                  assertEquals("@", specialCharOption.getOpt());
                                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                                  // If OptionValidator restricts certain characters
                                                                                                                              }
                                                                                                                          }

 @Test
                                                                                                                          public void testGetOpt_ConsistencyWithMultipleCalls() {
                                                                                                                              // Verify multiple calls return the same value
                                                                                                                              Option option = new Option("c", "consistent option");
                                                                                                                              String firstCall = option.getOpt();
                                                                                                                              String secondCall = option.getOpt();
                                                                                                                              String thirdCall = option.getOpt();
                                                                                                                              
                                                                                                                              assertEquals(firstCall, secondCall);
                                                                                                                              assertEquals(secondCall, thirdCall);
                                                                                                                              assertEquals("c", firstCall);
                                                                                                                          }

 @Test
                                                                                                                          public void testGetOpt_WithDifferentConstructors() {
                                                                                                                              // Test with different constructors
                                                                                                                              Option opt1 = new Option("a", "desc");
                                                                                                                              Option opt2 = new Option("b", true, "desc");
                                                                                                                              Option opt3 = new Option("c", "longOpt", true, "desc");
                                                                                                                              
                                                                                                                              assertEquals("a", opt1.getOpt());
                                                                                                                              assertEquals("b", opt2.getOpt());
                                                                                                                              assertEquals("c", opt3.getOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetType_WithValidClass() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              Class<?> expectedType = String.class;
                                                                                                                              
                                                                                                                              option.setType(expectedType);
                                                                                                                              assertEquals("Type should be set to String.class", 
                                                                                                                                           expectedType, option.getType());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetType_WithNull() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              option.setType(Integer.class); // Set initial value
                                                                                                                              
                                                                                                                              option.setType(null);
                                                                                                                              assertNull("Type should be set to null", option.getType());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetType_WithPrimitiveClass() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              Class<?> expectedType = int.class;
                                                                                                                              
                                                                                                                              option.setType(expectedType);
                                                                                                                              assertEquals("Type should be set to int.class", 
                                                                                                                                           expectedType, option.getType());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetType_WithArrayClass() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              Class<?> expectedType = String[].class;
                                                                                                                              
                                                                                                                              option.setType(expectedType);
                                                                                                                              assertEquals("Type should be set to String[].class", 
                                                                                                                                           expectedType, option.getType());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetType_WithInterface() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              Class<?> expectedType = List.class;
                                                                                                                              
                                                                                                                              option.setType(expectedType);
                                                                                                                              assertEquals("Type should be set to List.class", 
                                                                                                                                           expectedType, option.getType());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetType_WithDifferentTypes() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              
                                                                                                                              // Test with first type
                                                                                                                              Class<?> firstType = Double.class;
                                                                                                                              option.setType(firstType);
                                                                                                                              assertEquals(firstType, option.getType());
                                                                                                                              
                                                                                                                              // Test changing to different type
                                                                                                                              Class<?> secondType = Boolean.class;
                                                                                                                              option.setType(secondType);
                                                                                                                              assertEquals(secondType, option.getType());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetType_WithAnonymousClass() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              Runnable anonymousRunnable = new Runnable() {
                                                                                                                                  @Override
                                                                                                                                  public void run() {}
                                                                                                                              };
                                                                                                                              Class<?> expectedType = anonymousRunnable.getClass();
                                                                                                                              
                                                                                                                              option.setType(expectedType);
                                                                                                                              assertEquals("Type should be set to anonymous class type", 
                                                                                                                                           expectedType, option.getType());
                                                                                                                          }

 @Test
                                                                                                                          public void testGetLongOpt_WhenLongOptIsNull() {
                                                                                                                              // Arrange
                                                                                                                              Option nullLongOptOption = new Option("o", false, "description");
                                                                                                                              String expected = null;
                                                                                                                              
                                                                                                                              // Act
                                                                                                                              String actual = nullLongOptOption.getLongOpt();
                                                                                                                              
                                                                                                                              // Assert
                                                                                                                              assertNull("Should return null when long option is not set", actual);
                                                                                                                          }

 @Test
                                                                                                                          public void testSetLongOpt_NormalValue() {
                                                                                                                              Option option = new Option("o", "description");
                                                                                                                              option.setLongOpt("longOption");
                                                                                                                              assertEquals("longOption", option.getLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetLongOpt_NullValue() {
                                                                                                                              Option option = new Option("o", "description");
                                                                                                                              option.setLongOpt(null);
                                                                                                                              assertNull(option.getLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetLongOpt_EmptyString() {
                                                                                                                              Option option = new Option("o", "description");
                                                                                                                              option.setLongOpt("");
                                                                                                                              assertEquals("", option.getLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetLongOpt_WithSpaces() {
                                                                                                                              Option option = new Option("o", "description");
                                                                                                                              option.setLongOpt("  long option  ");
                                                                                                                              assertEquals("  long option  ", option.getLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetLongOpt_SpecialCharacters() {
                                                                                                                              Option option = new Option("o", "description");
                                                                                                                              option.setLongOpt("long-option_with$special#chars");
                                                                                                                              assertEquals("long-option_with$special#chars", option.getLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetLongOpt_UnicodeCharacters() {
                                                                                                                              Option option = new Option("o", "description");
                                                                                                                              option.setLongOpt("日本語オプション");
                                                                                                                              assertEquals("日本語オプション", option.getLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetLongOpt_VerifyHasLongOpt() {
                                                                                                                              Option option = new Option("o", "description");
                                                                                                                              option.setLongOpt("longOption");
                                                                                                                              assertTrue(option.hasLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetLongOpt_VerifyHasLongOptAfterNull() {
                                                                                                                              Option option = new Option("o", "description");
                                                                                                                              option.setLongOpt("longOption");
                                                                                                                              assertTrue(option.hasLongOpt());
                                                                                                                              option.setLongOpt(null);
                                                                                                                              assertFalse(option.hasLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetLongOpt_VerifyHasLongOptAfterEmptyString() {
                                                                                                                              Option option = new Option("o", "description");
                                                                                                                              option.setLongOpt("");
                                                                                                                              assertFalse(option.hasLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetLongOpt_MultipleCalls() {
                                                                                                                              Option option = new Option("o", "description");
                                                                                                                              option.setLongOpt("first");
                                                                                                                              assertEquals("first", option.getLongOpt());
                                                                                                                              option.setLongOpt("second");
                                                                                                                              assertEquals("second", option.getLongOpt());
                                                                                                                              option.setLongOpt("third");
                                                                                                                              assertEquals("third", option.getLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetLongOpt_AfterConstructionWithLongOpt() {
                                                                                                                              Option option = new Option("o", "existingLongOpt", false, "description");
                                                                                                                              assertEquals("existingLongOpt", option.getLongOpt());
                                                                                                                              option.setLongOpt("newLongOpt");
                                                                                                                              assertEquals("newLongOpt", option.getLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasOptionalArg_WithDifferentConstructors() {
                                                                                                                              // Test with different constructor variations
                                                                                                                              Option opt1 = new Option("a", "description");
                                                                                                                              assertFalse(opt1.hasOptionalArg());
                                                                                                                      
                                                                                                                              Option opt2 = new Option("b", true, "description");
                                                                                                                              assertFalse(opt2.hasOptionalArg()); // Note: constructor doesn't set optionalArg
                                                                                                                      
                                                                                                                              Option opt3 = new Option("c", "long", true, "description");
                                                                                                                              assertFalse(opt3.hasOptionalArg()); // Note: constructor doesn't set optionalArg
                                                                                                                          }

 @Test
                                                                                                                          public void testHasLongOpt_WhenLongOptIsNull() {
                                                                                                                              // Create option with null longOpt
                                                                                                                              Option option = new Option("o", null, false, "description");
                                                                                                                              
                                                                                                                              assertFalse("Should return false when longOpt is null", option.hasLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasLongOpt_WhenLongOptIsEmptyString() {
                                                                                                                              // Create option with empty string as longOpt
                                                                                                                              Option option = new Option("o", "", false, "description");
                                                                                                                              
                                                                                                                              assertTrue("Should return true when longOpt is empty string", option.hasLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasLongOpt_WhenLongOptIsNonEmptyString() {
                                                                                                                              // Create option with non-empty longOpt
                                                                                                                              Option option = new Option("o", "option", false, "description");
                                                                                                                              
                                                                                                                              assertTrue("Should return true when longOpt is non-empty", option.hasLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasLongOpt_AfterSettingLongOptToNull() {
                                                                                                                              // Create option with longOpt and then set it to null
                                                                                                                              Option option = new Option("o", "option", false, "description");
                                                                                                                              option.setLongOpt(null);
                                                                                                                              
                                                                                                                              assertFalse("Should return false after setting longOpt to null", option.hasLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasLongOpt_AfterSettingLongOptToValue() {
                                                                                                                              // Create option without longOpt and then set it
                                                                                                                              Option option = new Option("o", null, false, "description");
                                                                                                                              option.setLongOpt("option");
                                                                                                                              
                                                                                                                              assertTrue("Should return true after setting longOpt to a value", option.hasLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasLongOpt_AfterChangingLongOpt() {
                                                                                                                              // Create option with longOpt and then change it
                                                                                                                              Option option = new Option("o", "oldOption", false, "description");
                                                                                                                              assertTrue("Initial longOpt should exist", option.hasLongOpt());
                                                                                                                              
                                                                                                                              option.setLongOpt("newOption");
                                                                                                                              assertTrue("Should still return true after changing longOpt", option.hasLongOpt());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasArg_WhenNumberOfArgsIsZero() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              option.setArgs(0);
                                                                                                                              assertFalse(option.hasArg());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasArg_WhenNumberOfArgsIsOne() {
                                                                                                                              Option option = new Option("t", true, "test option");
                                                                                                                              assertTrue(option.hasArg());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasArg_WhenNumberOfArgsIsGreaterThanOne() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              option.setArgs(2);
                                                                                                                              assertTrue(option.hasArg());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasArg_WhenNumberOfArgsIsUnlimited() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                              assertTrue(option.hasArg());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasArg_WhenNumberOfArgsIsNegative() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              option.setArgs(-1);
                                                                                                                              assertFalse(option.hasArg());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasArg_WhenNumberOfArgsIsUninitialized() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              // Default constructor sets numberOfArgs to UNINITIALIZED if hasArg is false
                                                                                                                              assertEquals(Option.UNINITIALIZED, option.getArgs());
                                                                                                                              assertFalse(option.hasArg());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasArg_AfterChangingNumberOfArgs() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              assertFalse(option.hasArg());
                                                                                                                              
                                                                                                                              option.setArgs(1);
                                                                                                                              assertTrue(option.hasArg());
                                                                                                                              
                                                                                                                              option.setArgs(0);
                                                                                                                              assertFalse(option.hasArg());
                                                                                                                              
                                                                                                                              option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                              assertTrue(option.hasArg());
                                                                                                                          }

 @Test
                                                                                                                          public void testHasArg_WithConstructorSettingHasArg() {
                                                                                                                              Option option1 = new Option("t", false, "test option");
                                                                                                                              assertFalse(option1.hasArg());
                                                                                                                              
                                                                                                                              Option option2 = new Option("t", true, "test option");
                                                                                                                              assertTrue(option2.hasArg());
                                                                                                                          }

 @Test
                                                                                                                          public void testIsRequired_WithDifferentConstructorVariations() {
                                                                                                                              // Test with different constructor variations
                                                                                                                              Option opt1 = new Option("a", "description");
                                                                                                                              assertFalse(opt1.isRequired());
                                                                                                                      
                                                                                                                              Option opt2 = new Option("b", true, "description");
                                                                                                                              assertFalse(opt2.isRequired());
                                                                                                                      
                                                                                                                              Option opt3 = new Option("c", "long", true, "description");
                                                                                                                              assertFalse(opt3.isRequired());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetRequired_True() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              option.setRequired(true);
                                                                                                                              assertTrue("Option should be required after setting to true", 
                                                                                                                                        option.isRequired());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetRequired_False() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              option.setRequired(false);
                                                                                                                              assertFalse("Option should not be required after setting to false", 
                                                                                                                                         option.isRequired());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetRequired_MultipleChanges() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              
                                                                                                                              // Initial state (default)
                                                                                                                              assertFalse("Option should not be required by default", 
                                                                                                                                         option.isRequired());
                                                                                                                              
                                                                                                                              // Change to true
                                                                                                                              option.setRequired(true);
                                                                                                                              assertTrue("Option should be required after first change", 
                                                                                                                                        option.isRequired());
                                                                                                                              
                                                                                                                              // Change back to false
                                                                                                                              option.setRequired(false);
                                                                                                                              assertFalse("Option should not be required after second change", 
                                                                                                                                         option.isRequired());
                                                                                                                              
                                                                                                                              // Change to true again
                                                                                                                              option.setRequired(true);
                                                                                                                              assertTrue("Option should be required after third change", 
                                                                                                                                        option.isRequired());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetRequired_AfterOtherOperations() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              option.setLongOpt("test");
                                                                                                                              option.setDescription("new description");
                                                                                                                              option.setArgName("arg");
                                                                                                                              
                                                                                                                              // Verify other properties are unchanged after setting required
                                                                                                                              option.setRequired(true);
                                                                                                                              assertEquals("Long option should remain unchanged", 
                                                                                                                                          "test", option.getLongOpt());
                                                                                                                              assertEquals("Description should remain unchanged", 
                                                                                                                                          "new description", option.getDescription());
                                                                                                                              assertEquals("Arg name should remain unchanged", 
                                                                                                                                          "arg", option.getArgName());
                                                                                                                              assertTrue("Option should be required", option.isRequired());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetRequired_WithDifferentConstructors() {
                                                                                                                              // Test with different constructor variants
                                                                                                                              Option option1 = new Option("a", "description a");
                                                                                                                              Option option2 = new Option("b", true, "description b");
                                                                                                                              Option option3 = new Option("c", "longC", true, "description c");
                                                                                                                              
                                                                                                                              option1.setRequired(true);
                                                                                                                              option2.setRequired(false);
                                                                                                                              option3.setRequired(true);
                                                                                                                              
                                                                                                                              assertTrue("Option1 should be required", option1.isRequired());
                                                                                                                              assertFalse("Option2 should not be required", option2.isRequired());
                                                                                                                              assertTrue("Option3 should be required", option3.isRequired());
                                                                                                                          }

 @Test
                                                                                                                          public void testSetRequired_DoesNotAffectOtherFlags() {
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              option.setOptionalArg(true);
                                                                                                                              option.setArgs(2);
                                                                                                                              option.setValueSeparator(',');
                                                                                                                              
                                                                                                                              option.setRequired(true);
                                                                                                                              
                                                                                                                              assertTrue("Optional arg flag should remain true", 
                                                                                                                                        option.hasOptionalArg());
                                                                                                                              assertEquals("Number of args should remain 2", 
                                                                                                                                          2, option.getArgs());
                                                                                                                              assertEquals("Value separator should remain ','", 
                                                                                                                                          ',', option.getValueSeparator());
                                                                                                                              assertTrue("Required flag should be true", option.isRequired());
                                                                                                                          }

 @Test
                                                                                                                          public void testToString_ShortOptionOnly() {
                                                                                                                              Option option = new Option("f", "file option");
                                                                                                                              String expected = "[ option: f :: file option ]";
                                                                                                                              assertEquals(expected, option.toString());
                                                                                                                          }

 @Test
                                                                                                                          public void testToString_WithLongOption() {
                                                                                                                              Option option = new Option("f", "file", false, "file option");
                                                                                                                              String expected = "[ option: f file :: file option ]";
                                                                                                                              assertEquals(expected, option.toString());
                                                                                                                          }

 @Test
                                                                                                                          public void testToString_WithSingleArg() {
                                                                                                                              Option option = new Option("f", "file", true, "file option");
                                                                                                                              String expected = "[ option: f file [ARG] :: file option ]";
                                                                                                                              assertEquals(expected, option.toString());
                                                                                                                          }

 @Test
                                                                                                                          public void testToString_WithMultipleArgs() {
                                                                                                                              Option option = new Option("f", "file", false, "file option");
                                                                                                                              option.setArgs(2); // Set to accept 2 arguments
                                                                                                                              String expected = "[ option: f file [ARG...] :: file option ]";
                                                                                                                              assertEquals(expected, option.toString());
                                                                                                                          }

 @Test
                                                                                                                          public void testToString_WithType() {
                                                                                                                              Option option = new Option("f", "file", false, "file option");
                                                                                                                              option.setType(String.class);
                                                                                                                              String expected = "[ option: f file :: file option :: class java.lang.String ]";
                                                                                                                              assertEquals(expected, option.toString());
                                                                                                                          }

 @Test
                                                                                                                          public void testToString_WithAllFeatures() {
                                                                                                                              Option option = new Option("f", "file", true, "file option");
                                                                                                                              option.setType(String.class);
                                                                                                                              String expected = "[ option: f file [ARG] :: file option :: class java.lang.String ]";
                                                                                                                              assertEquals(expected, option.toString());
                                                                                                                          }

 @Test
                                                                                                                          public void testToString_WithUnlimitedArgs() {
                                                                                                                              Option option = new Option("f", "file", false, "file option");
                                                                                                                              option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                                              String expected = "[ option: f file [ARG...] :: file option ]";
                                                                                                                              assertEquals(expected, option.toString());
                                                                                                                          }

 @Test
                                                                                                                          public void testToString_WithNullDescription() {
                                                                                                                              Option option = new Option("f", null, false, null);
                                                                                                                              String expected = "[ option: f :: null ]";
                                                                                                                              assertEquals(expected, option.toString());
                                                                                                                          }

 @Test
                                                                                                                          public void testToString_WithEmptyDescription() {
                                                                                                                              Option option = new Option("f", null, false, "");
                                                                                                                              String expected = "[ option: f ::  ]";
                                                                                                                              assertEquals(expected, option.toString());
                                                                                                                          }

 @Test
                                                                                                                          public void testToString_WithNullLongOpt() {
                                                                                                                              Option option = new Option("f", null, false, "description");
                                                                                                                              String expected = "[ option: f :: description ]";
                                                                                                                              assertEquals(expected, option.toString());
                                                                                                                          }

 @Test
                                                                                                                          public void testToString_WithEmptyLongOpt() {
                                                                                                                              Option option = new Option("f", "", false, "description");
                                                                                                                              String expected = "[ option: f  :: description ]";
                                                                                                                              assertEquals(expected, option.toString());
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_Reflexive() {
                                                                                                                              Option option = new Option("a", "description");
                                                                                                                              assertTrue(option.equals(option));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_Symmetric() {
                                                                                                                              Option option1 = new Option("a", "description");
                                                                                                                              Option option2 = new Option("a", "description");
                                                                                                                              assertTrue(option1.equals(option2));
                                                                                                                              assertTrue(option2.equals(option1));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_NullComparison() {
                                                                                                                              Option option = new Option("a", "description");
                                                                                                                              assertFalse(option.equals(null));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_DifferentClass() {
                                                                                                                              Option option = new Option("a", "description");
                                                                                                                              Object other = new Object();
                                                                                                                              assertFalse(option.equals(other));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_SameOptAndLongOpt() {
                                                                                                                              Option option1 = new Option("a", "long", true, "description");
                                                                                                                              Option option2 = new Option("a", "long", true, "different description");
                                                                                                                              assertTrue(option1.equals(option2));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_DifferentOpt() {
                                                                                                                              Option option1 = new Option("a", "description");
                                                                                                                              Option option2 = new Option("b", "description");
                                                                                                                              assertFalse(option1.equals(option2));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_DifferentLongOpt() {
                                                                                                                              Option option1 = new Option("a", "long1", true, "description");
                                                                                                                              Option option2 = new Option("a", "long2", true, "description");
                                                                                                                              assertFalse(option1.equals(option2));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_OneOptNull() {
                                                                                                                              Option option1 = new Option(null, "description");
                                                                                                                              Option option2 = new Option("a", "description");
                                                                                                                              assertFalse(option1.equals(option2));
                                                                                                                              assertFalse(option2.equals(option1));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_BothOptNull() {
                                                                                                                              Option option1 = new Option(null, "long", true, "description");
                                                                                                                              Option option2 = new Option(null, "long", true, "description");
                                                                                                                              assertTrue(option1.equals(option2));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_OneLongOptNull() {
                                                                                                                              Option option1 = new Option("a", null, true, "description");
                                                                                                                              Option option2 = new Option("a", "long", true, "description");
                                                                                                                              assertFalse(option1.equals(option2));
                                                                                                                              assertFalse(option2.equals(option1));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_BothLongOptNull() {
                                                                                                                              Option option1 = new Option("a", null, true, "description");
                                                                                                                              Option option2 = new Option("a", null, true, "description");
                                                                                                                              assertTrue(option1.equals(option2));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_AllFieldsNull() {
                                                                                                                              Option option1 = new Option(null, null, true, "description");
                                                                                                                              Option option2 = new Option(null, null, true, "description");
                                                                                                                              assertTrue(option1.equals(option2));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_OptEqualsButLongOptDifferent() {
                                                                                                                              Option option1 = new Option("a", "long1", true, "description");
                                                                                                                              Option option2 = new Option("a", "long2", true, "description");
                                                                                                                              assertFalse(option1.equals(option2));
                                                                                                                          }

 @Test
                                                                                                                          public void testEquals_LongOptEqualsButOptDifferent() {
                                                                                                                              Option option1 = new Option("a", "long", true, "description");
                                                                                                                              Option option2 = new Option("b", "long", true, "description");
                                                                                                                              assertFalse(option1.equals(option2));
                                                                                                                          }

 @Test
                                                                                                                          public void testHashCode_BothFieldsNull() {
                                                                                                                              // Arrange
                                                                                                                              Option option = new Option(null, null, false, null);
                                                                                                                              
                                                                                                                              // Act
                                                                                                                              int result = option.hashCode();
                                                                                                                              
                                                                                                                              // Assert
                                                                                                                              assertEquals(0, result);
                                                                                                                          }

 @Test
                                                                                                                          public void testHashCode_OptNotNullLongOptNull() {
                                                                                                                              // Arrange
                                                                                                                              String testOpt = "test";
                                                                                                                              Option option = new Option(testOpt, null, false, null);
                                                                                                                              int expected = 31 * testOpt.hashCode();
                                                                                                                              
                                                                                                                              // Act
                                                                                                                              int result = option.hashCode();
                                                                                                                              
                                                                                                                              // Assert
                                                                                                                              assertEquals(expected, result);
                                                                                                                          }

 @Test
                                                                                                                          public void testHashCode_OptNullLongOptNotNull() {
                                                                                                                              // Arrange
                                                                                                                              String testLongOpt = "longTest";
                                                                                                                              Option option = new Option(null, testLongOpt, false, null);
                                                                                                                              int expected = testLongOpt.hashCode();
                                                                                                                              
                                                                                                                              // Act
                                                                                                                              int result = option.hashCode();
                                                                                                                              
                                                                                                                              // Assert
                                                                                                                              assertEquals(expected, result);
                                                                                                                          }

 @Test
                                                                                                                          public void testHashCode_BothFieldsNotNull() {
                                                                                                                              // Arrange
                                                                                                                              String testOpt = "test";
                                                                                                                              String testLongOpt = "longTest";
                                                                                                                              Option option = new Option(testOpt, testLongOpt, false, null);
                                                                                                                              int expected = 31 * testOpt.hashCode() + testLongOpt.hashCode();
                                                                                                                              
                                                                                                                              // Act
                                                                                                                              int result = option.hashCode();
                                                                                                                              
                                                                                                                              // Assert
                                                                                                                              assertEquals(expected, result);
                                                                                                                          }

 @Test
                                                                                                                          public void testHashCode_Consistency() {
                                                                                                                              // Arrange
                                                                                                                              String testOpt = "test";
                                                                                                                              String testLongOpt = "longTest";
                                                                                                                              Option option = new Option(testOpt, testLongOpt, false, null);
                                                                                                                              
                                                                                                                              // Act & Assert
                                                                                                                              int firstHash = option.hashCode();
                                                                                                                              int secondHash = option.hashCode();
                                                                                                                              assertEquals(firstHash, secondHash);
                                                                                                                          }

 @Test
                                                                                                                          public void testHashCode_EqualsObjectsSameHashCode() {
                                                                                                                              // Arrange
                                                                                                                              Option option1 = new Option("a", "b", false, null);
                                                                                                                              Option option2 = new Option("a", "b", false, null);
                                                                                                                              
                                                                                                                              // Act & Assert
                                                                                                                              assertEquals(option1.hashCode(), option2.hashCode());
                                                                                                                          }

 @Test
                                                                                                                          public void testAddValue_ShouldThrowUnsupportedOperationException() {
                                                                                                                              // Arrange
                                                                                                                              Option option = new Option("t", "test option");
                                                                                                                              String testValue = "testValue";
                                                                                                                              
                                                                                                                              // Set up expectation for the exception
                                                                                                                              thrown.expect(UnsupportedOperationException.class);
                                                                                                                              thrown.expectMessage("The addValue method is not intended for client use. "
                                                                                                                                      + "Subclasses should use the addValueForProcessing method instead.");
                                                                                                                              
                                                                                                                              // Act
                                                                                                                              option.addValue(testValue);
                                                                                                                          }

 @Test
                                                                                                                  public void testGetId_WithLongOptOnly() {
                                                                                                                      Option option = new Option(null, "longOpt", true, "description");
                                                                                                                      assertEquals('l', option.getId());
                                                                                                                  }

 @Test
                                                                                                                  public void testGetId_ConsistencyWithMultipleCalls() {
                                                                                                                      Option option = new Option("xyz", "description");
                                                                                                                      int firstCall = option.getId();
                                                                                                                      int secondCall = option.getId();
                                                                                                                      assertEquals(firstCall, secondCall);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetOpt_ReturnsCorrectShortOption() {
                                                                                                                      // Test with standard short option
                                                                                                                      Option option = new Option("t", "test option");
                                                                                                                      assertEquals("t", option.getOpt());
                                                                                                                      
                                                                                                                      // Test with different short option
                                                                                                                      Option anotherOption = new Option("f", "file option");
                                                                                                                      assertEquals("f", anotherOption.getOpt());
                                                                                                                  }

 @Test
                                                                                                                  public void testGetType_WhenTypeNotSet_ShouldReturnNull() {
                                                                                                                      // Arrange - type is not set by default
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      Class<?> result = (Class<?>) option.getType();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertNull("Type should be null when not set", result);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetType_WhenTypeSetToString_ShouldReturnStringClass() {
                                                                                                                      // Arrange
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      option.setType(String.class);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      Class<?> result = (Class<?>) option.getType();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals("Type should be String.class", String.class, result);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetType_WhenTypeSetToInteger_ShouldReturnIntegerClass() {
                                                                                                                      // Arrange
                                                                                                                      Option option = new Option("t", "test option");
                                                                                                                      option.setType(Integer.class);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      Class<?> result = (Class<?>) option.getType();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals("Type should be Integer.class", Integer.class, result);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetType_WhenTypeChangedMultipleTimes_ShouldReturnLastSetType() {
                                                                                                                      // Arrange
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      option.setType(String.class);
                                                                                                                      option.setType(Integer.class);
                                                                                                                      option.setType(Boolean.class);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      Class<?> result = (Class<?>) option.getType();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals("Type should be Boolean.class", Boolean.class, result);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetType_WhenTypeSetToCustomClass_ShouldReturnCorrectClass() {
                                                                                                                      // Arrange
                                                                                                                      class CustomClass {}
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      option.setType(CustomClass.class);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      Class<?> result = (Class<?>) option.getType();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals("Type should be CustomClass.class", CustomClass.class, result);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetType_AfterClone_ShouldReturnSameType() {
                                                                                                                      // Arrange
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      option.setType(Double.class);
                                                                                                                      Option clonedOption = (Option) option.clone();
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      Class<?> originalType = (Class<?>) option.getType();
                                                                                                                      Class<?> clonedType = (Class<?>) clonedOption.getType();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals("Cloned option should have same type as original", 
                                                                                                                                   originalType, clonedType);
                                                                                                                  }

 @Test
                                                                                                                  public void testSetType_WithEnumClass() {
                                                                                                                      Option option = new Option("t", "test option");
                                                                                                                      Class<?> expectedType = Thread.State.class; // Using standard Java enum
                                                                                                                      
                                                                                                                      option.setType(expectedType);
                                                                                                                      assertEquals("Type should be set to enum type", 
                                                                                                                                   expectedType, option.getType());
                                                                                                                  }

 @Test
                                                                                                                  public void testGetLongOpt_WhenLongOptIsSet() {
                                                                                                                      // Arrange
                                                                                                                      String expected = "option";
                                                                                                                      Option option = new Option("o", expected, false, "description");
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      String actual = option.getLongOpt();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals("Should return the set long option", expected, actual);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetLongOpt_AfterSettingNewValue() {
                                                                                                                      // Arrange
                                                                                                                      String opt = "o";
                                                                                                                      String description = "description";
                                                                                                                      Option option = new Option(opt, description);
                                                                                                                      String newLongOpt = "newOption";
                                                                                                                      option.setLongOpt(newLongOpt);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      String actual = option.getLongOpt();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals("Should return the newly set long option", newLongOpt, actual);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetLongOpt_AfterSettingToNull() {
                                                                                                                      // Arrange
                                                                                                                      Option option = new Option("a", "description");
                                                                                                                      option.setLongOpt(null);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      String actual = option.getLongOpt();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertNull("Should return null after setting long option to null", actual);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetLongOpt_WithEmptyString() {
                                                                                                                      // Arrange
                                                                                                                      String emptyString = "";
                                                                                                                      Option option = new Option("a", null, false, "description");
                                                                                                                      option.setLongOpt(emptyString);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      String actual = option.getLongOpt();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals("Should return empty string when set", emptyString, actual);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetLongOpt_WithWhitespaceString() {
                                                                                                                      // Arrange
                                                                                                                      String whitespaceString = "   ";
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      option.setLongOpt(whitespaceString);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      String actual = option.getLongOpt();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals("Should return whitespace string when set", whitespaceString, actual);
                                                                                                                  }

 @Test
                                                                                                                  public void testSetOptionalArg_True() {
                                                                                                                      // Create an Option object using one of the constructors
                                                                                                                      Option option = new Option("t", "test option");
                                                                                                                      
                                                                                                                      // Test setting optionalArg to true
                                                                                                                      option.setOptionalArg(true);
                                                                                                                      assertTrue("optionalArg should be true after setting to true", 
                                                                                                                                option.hasOptionalArg());
                                                                                                                  }

 @Test
                                                                                                                  public void testSetOptionalArg_False() {
                                                                                                                      // Create an Option object for testing
                                                                                                                      Option option = new Option("t", "test option");
                                                                                                                      
                                                                                                                      // Test setting optionalArg to false
                                                                                                                      option.setOptionalArg(false);
                                                                                                                      assertFalse("optionalArg should be false after setting to false", 
                                                                                                                                 option.hasOptionalArg());
                                                                                                                  }

 @Test
                                                                                                                  public void testSetOptionalArg_ToggleValues() {
                                                                                                                      // Create an Option object for testing
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      
                                                                                                                      // Test toggling the optionalArg value multiple times
                                                                                                                      option.setOptionalArg(true);
                                                                                                                      assertTrue("First toggle to true should work", option.hasOptionalArg());
                                                                                                                      
                                                                                                                      option.setOptionalArg(false);
                                                                                                                      assertFalse("Second toggle to false should work", option.hasOptionalArg());
                                                                                                                      
                                                                                                                      option.setOptionalArg(true);
                                                                                                                      assertTrue("Third toggle to true should work", option.hasOptionalArg());
                                                                                                                  }

 @Test
                                                                                                                  public void testSetOptionalArg_DefaultValue() {
                                                                                                                      // Create a new Option object for testing
                                                                                                                      Option option = new Option("t", "test option");
                                                                                                                      
                                                                                                                      // Test the default value (should be false based on typical Java defaults)
                                                                                                                      assertFalse("optionalArg should be false by default", 
                                                                                                                                  option.hasOptionalArg());
                                                                                                                  }

 @Test
                                                                                                                  public void testSetOptionalArg_ConsistencyWithHasOptionalArg() {
                                                                                                                      // Create a new Option object for testing
                                                                                                                      Option option = new Option("t", "test option");
                                                                                                                      
                                                                                                                      // Test that setOptionalArg and hasOptionalArg work consistently
                                                                                                                      option.setOptionalArg(true);
                                                                                                                      assertTrue("hasOptionalArg should return true after setOptionalArg(true)",
                                                                                                                                option.hasOptionalArg());
                                                                                                                      
                                                                                                                      option.setOptionalArg(false);
                                                                                                                      assertFalse("hasOptionalArg should return false after setOptionalArg(false)",
                                                                                                                                 option.hasOptionalArg());
                                                                                                                  }

 @Test
                                                                                                                  public void testHasOptionalArg_WhenOptionalArgIsFalse() {
                                                                                                                      // Create a basic Option object
                                                                                                                      Option option = new Option("t", "test description");
                                                                                                                      // Default should be false
                                                                                                                      assertFalse(option.hasOptionalArg());
                                                                                                                  }

 @Test
                                                                                                                  public void testHasOptionalArg_WhenOptionalArgIsTrue() {
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      option.setOptionalArg(true);
                                                                                                                      assertTrue(option.hasOptionalArg());
                                                                                                                  }

 @Test
                                                                                                                  public void testHasOptionalArg_AfterChangingValueMultipleTimes() {
                                                                                                                      // Create a new Option object for testing
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      
                                                                                                                      // Test toggling the value multiple times
                                                                                                                      option.setOptionalArg(true);
                                                                                                                      assertTrue(option.hasOptionalArg());
                                                                                                                      
                                                                                                                      option.setOptionalArg(false);
                                                                                                                      assertFalse(option.hasOptionalArg());
                                                                                                                      
                                                                                                                      option.setOptionalArg(true);
                                                                                                                      assertTrue(option.hasOptionalArg());
                                                                                                                  }

 @Test
                                                                                                                  public void testHasOptionalArg_AfterClone() throws CloneNotSupportedException {
                                                                                                                      Option option = new Option("test", "description");
                                                                                                                      option.setOptionalArg(true);
                                                                                                                      Option clonedOption = (Option) option.clone();
                                                                                                                      assertTrue(clonedOption.hasOptionalArg());
                                                                                                                  }

 @Test
                                                                                                                  public void testGetDescription_WhenDescriptionIsNull() {
                                                                                                                      // Arrange
                                                                                                                      Option option = new Option("t", null, false, null);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      String result = option.getDescription();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertNull(result);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetDescription_WhenDescriptionIsEmpty() {
                                                                                                                      // Arrange
                                                                                                                      Option option = new Option("t", null, false, "");
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      String result = option.getDescription();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals("", result);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetDescription_WithNormalDescription() {
                                                                                                                      // Arrange
                                                                                                                      String expectedDescription = "Test description";
                                                                                                                      Option option = new Option("t", "longT", false, expectedDescription);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      String result = option.getDescription();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals(expectedDescription, result);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetDescription_AfterSettingNewDescription() {
                                                                                                                      // Arrange
                                                                                                                      Option option = new Option("t", "longT", false, "Initial description");
                                                                                                                      String newDescription = "Updated description";
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      option.setDescription(newDescription);
                                                                                                                      String result = option.getDescription();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals(newDescription, result);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetDescription_WithSpecialCharacters() {
                                                                                                                      // Arrange
                                                                                                                      String specialDescription = "Description with special chars: !@#$%^&*()";
                                                                                                                      Option option = new Option("t", null, false, specialDescription);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      String result = option.getDescription();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals(specialDescription, result);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetDescription_WithLongDescription() {
                                                                                                                      // Arrange
                                                                                                                      String longDescription = "This is a very long description that might test the " +
                                                                                                                          "handling of longer strings in the Option class. It contains multiple " +
                                                                                                                          "sentences and various punctuation marks to ensure proper handling.";
                                                                                                                      Option option = new Option("t", longDescription);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      String result = option.getDescription();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals(longDescription, result);
                                                                                                                  }

 @Test
                                                                                                                  public void testGetDescription_WithUnicodeCharacters() {
                                                                                                                      // Arrange
                                                                                                                      String unicodeDescription = "Description with unicode: 日本語, русский, 中文";
                                                                                                                      Option option = new Option("t", null, false, unicodeDescription);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      String result = option.getDescription();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertEquals(unicodeDescription, result);
                                                                                                                  }

 @Test
                                                                                                                  public void testSetDescription_NormalString() {
                                                                                                                      Option option = new Option("test", "initial description");
                                                                                                                      String description = "This is a normal description";
                                                                                                                      option.setDescription(description);
                                                                                                                      assertEquals("Description should be set correctly", 
                                                                                                                                  description, option.getDescription());
                                                                                                                  }

 @Test
                                                                                                              public void testSetDescription_EmptyString() {
                                                                                                                  String description = "";
                                                                                                                  Option option = new Option("t", "test description");
                                                                                                                  option.setDescription(description);
                                                                                                                  assertEquals("Empty description should be set correctly", 
                                                                                                                              description, option.getDescription());
                                                                                                              }

 @Test
                                                                                                              public void testSetDescription_NullString() {
                                                                                                                  String description = null;
                                                                                                                  Option option = new Option("test", "initial description");
                                                                                                                  option.setDescription(description);
                                                                                                                  assertNull("Null description should be set correctly", 
                                                                                                                            option.getDescription());
                                                                                                              }

 @Test
                                                                                                              public void testSetDescription_LongString() {
                                                                                                                  String description = "This is a very long description that might exceed " +
                                                                                                                                     "typical length limits but should still be accepted " +
                                                                                                                                     "by the method. The method should handle strings " +
                                                                                                                                     "of any length without issues.";
                                                                                                                  Option option = new Option("test", "initial description");
                                                                                                                  option.setDescription(description);
                                                                                                                  assertEquals("Long description should be set correctly", 
                                                                                                                              description, option.getDescription());
                                                                                                              }

 @Test
                                                                                                              public void testSetDescription_SpecialCharacters() {
                                                                                                                  Option option = new Option("test", "initial description");
                                                                                                                  String description = "Description with special chars: !@#$%^&*()_+-=[]{};':\\\",./<>?";
                                                                                                                  option.setDescription(description);
                                                                                                                  assertEquals("Description with special characters should be set correctly", 
                                                                                                                              description, option.getDescription());
                                                                                                              }

 @Test
                                                                                                              public void testSetDescription_UnicodeCharacters() {
                                                                                                                  Option option = new Option("test", "initial description");
                                                                                                                  String description = "Description with unicode: こんにちは, Привет, 你好";
                                                                                                                  option.setDescription(description);
                                                                                                                  assertEquals("Unicode description should be set correctly", 
                                                                                                                              description, option.getDescription());
                                                                                                              }

 @Test
                                                                                                              public void testSetDescription_MultipleCalls() {
                                                                                                                  Option option = new Option("test", "initial description");
                                                                                                                  String firstDescription = "First description";
                                                                                                                  String secondDescription = "Second description";
                                                                                                                  
                                                                                                                  option.setDescription(firstDescription);
                                                                                                                  assertEquals("First description should be set correctly", 
                                                                                                                              firstDescription, option.getDescription());
                                                                                                                  
                                                                                                                  option.setDescription(secondDescription);
                                                                                                                  assertEquals("Second description should override the first one", 
                                                                                                                              secondDescription, option.getDescription());
                                                                                                              }

 @Test
                                                                                                              public void testSetDescription_AfterOtherOperations() {
                                                                                                                  Option option = new Option("opt", "longOption", true, "initial description");
                                                                                                                  option.setRequired(true);
                                                                                                                  option.setLongOpt("longOption");
                                                                                                                  
                                                                                                                  String description = "Description after other operations";
                                                                                                                  option.setDescription(description);
                                                                                                                  
                                                                                                                  assertEquals("Description should be set correctly after other operations", 
                                                                                                                              description, option.getDescription());
                                                                                                                  assertTrue("Other properties should remain unchanged", 
                                                                                                                            option.isRequired());
                                                                                                                  assertEquals("Other properties should remain unchanged", 
                                                                                                                              "longOption", option.getLongOpt());
                                                                                                              }

 @Test
                                                                                                              public void testIsRequired_WhenRequiredIsFalse() {
                                                                                                                  // Default should be false
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  assertFalse(option.isRequired());
                                                                                                              }

 @Test
                                                                                                              public void testIsRequired_WhenRequiredIsTrue() {
                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                  option.setRequired(true);
                                                                                                                  assertTrue(option.isRequired());
                                                                                                              }

 @Test
                                                                                                              public void testIsRequired_AfterChangingRequiredMultipleTimes() {
                                                                                                                  // Test toggling the required flag multiple times
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  option.setRequired(true);
                                                                                                                  assertTrue(option.isRequired());
                                                                                                                  
                                                                                                                  option.setRequired(false);
                                                                                                                  assertFalse(option.isRequired());
                                                                                                                  
                                                                                                                  option.setRequired(true);
                                                                                                                  assertTrue(option.isRequired());
                                                                                                              }

 @Test
                                                                                                              public void testIsRequired_AfterClone() throws CloneNotSupportedException {
                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                  option.setRequired(true);
                                                                                                                  Option clonedOption = (Option) option.clone();
                                                                                                                  assertTrue(clonedOption.isRequired());
                                                                                                                  
                                                                                                                  clonedOption.setRequired(false);
                                                                                                                  // Original should remain unchanged
                                                                                                                  assertTrue(option.isRequired());
                                                                                                                  assertFalse(clonedOption.isRequired());
                                                                                                              }

 @Test
                                                                                                              public void testSetArgName_NormalValue() {
                                                                                                                  String argName = "filename";
                                                                                                                  Option option = new Option("f", "file option");
                                                                                                                  option.setArgName(argName);
                                                                                                                  assertEquals("Setting normal arg name should work", 
                                                                                                                               argName, option.getArgName());
                                                                                                                  assertTrue("hasArgName should return true after setting arg name", 
                                                                                                                             option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testSetArgName_NullValue() {
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  option.setArgName(null);
                                                                                                                  assertNull("Setting null arg name should work", option.getArgName());
                                                                                                                  assertFalse("hasArgName should return false for null arg name", 
                                                                                                                              option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testSetArgName_EmptyString() {
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  option.setArgName("");
                                                                                                                  assertEquals("Setting empty string arg name should work", 
                                                                                                                               "", option.getArgName());
                                                                                                                  assertTrue("hasArgName should return true for empty string", 
                                                                                                                            option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testSetArgName_WhitespaceString() {
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  String whitespace = "   ";
                                                                                                                  option.setArgName(whitespace);
                                                                                                                  assertEquals("Setting whitespace string arg name should work", 
                                                                                                                               whitespace, option.getArgName());
                                                                                                                  assertTrue("hasArgName should return true for whitespace string", 
                                                                                                                            option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testSetArgName_OverwriteExistingValue() {
                                                                                                                  // Create new Option object for testing
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  
                                                                                                                  // Set initial value
                                                                                                                  option.setArgName("initial");
                                                                                                                  assertEquals("initial", option.getArgName());
                                                                                                                  
                                                                                                                  // Overwrite with new value
                                                                                                                  String newValue = "updated";
                                                                                                                  option.setArgName(newValue);
                                                                                                                  assertEquals("Should overwrite existing arg name", 
                                                                                                                               newValue, option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testSetArgName_SpecialCharacters() {
                                                                                                                  String specialChars = "arg-name_with.special@chars!";
                                                                                                                  Option option = new Option("test", "description"); // Create Option object with required parameters
                                                                                                                  option.setArgName(specialChars);
                                                                                                                  assertEquals("Special characters in arg name should be preserved", 
                                                                                                                               specialChars, option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testSetArgName_LongString() {
                                                                                                                  String longString = "aVeryLongArgumentNameThatExceedsTypicalLengths" +
                                                                                                                                     "AndGoesOnForQuiteABitToTestBoundaryConditions";
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  option.setArgName(longString);
                                                                                                                  assertEquals("Long arg names should be handled correctly", 
                                                                                                                               longString, option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testGetArgName_WhenArgNameIsNull() {
                                                                                                                  // Create a new Option object with required parameters
                                                                                                                  Option option = new Option("t", "test description");
                                                                                                                  
                                                                                                                  // Default argName should be null after construction
                                                                                                                  assertNull(option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testGetArgName_AfterSettingArgName() {
                                                                                                                  String expectedArgName = "filename";
                                                                                                                  Option option = new Option("f", "file option");
                                                                                                                  option.setArgName(expectedArgName);
                                                                                                                  assertEquals(expectedArgName, option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testGetArgName_AfterSettingEmptyArgName() {
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  option.setArgName("");
                                                                                                                  assertEquals("", option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testGetArgName_AfterSettingWhitespaceArgName() {
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  option.setArgName("   ");
                                                                                                                  assertEquals("   ", option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testGetArgName_AfterSettingNullArgName() {
                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                  option.setArgName("test");
                                                                                                                  option.setArgName(null); // Explicitly set to null
                                                                                                                  assertNull(option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testGetArgName_AfterSettingSpecialCharacters() {
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  String specialChars = "arg@name#123";
                                                                                                                  option.setArgName(specialChars);
                                                                                                                  assertEquals(specialChars, option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testGetArgName_AfterSettingLongArgName() {
                                                                                                                  String longArgName = "aVeryLongArgumentNameThatExceedsTypicalLengthsForTestingPurposes";
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  option.setArgName(longArgName);
                                                                                                                  assertEquals(longArgName, option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testGetArgName_AfterMultipleSetOperations() {
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  option.setArgName("first");
                                                                                                                  option.setArgName("second");
                                                                                                                  option.setArgName("third");
                                                                                                                  assertEquals("third", option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testGetArgName_WithUnicodeCharacters() {
                                                                                                                  String unicodeArgName = "arg\u00E9name"; // é character
                                                                                                                  Option option = new Option("test", "description"); // Initialize Option object
                                                                                                                  option.setArgName(unicodeArgName);
                                                                                                                  assertEquals(unicodeArgName, option.getArgName());
                                                                                                              }

 @Test
                                                                                                              public void testHasArgName_WhenArgNameIsNull() {
                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                  option.setArgName(null);
                                                                                                                  assertFalse(option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testHasArgName_WhenArgNameIsEmpty() {
                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                  option.setArgName("");
                                                                                                                  assertFalse(option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testHasArgName_WhenArgNameIsBlank() {
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  option.setArgName("   ");
                                                                                                                  assertFalse(option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testHasArgName_WhenArgNameHasSingleCharacter() {
                                                                                                                  Option option = new Option("a", "description");
                                                                                                                  option.setArgName("a");
                                                                                                                  assertTrue(option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testHasArgName_WhenArgNameHasMultipleCharacters() {
                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                  option.setArgName("argument");
                                                                                                                  assertTrue(option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testHasArgName_WhenArgNameIsSetThenCleared() {
                                                                                                                  // Create an Option object for testing
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  
                                                                                                                  // First set a valid argName
                                                                                                                  option.setArgName("valid");
                                                                                                                  assertTrue(option.hasArgName());
                                                                                                                  
                                                                                                                  // Then clear it
                                                                                                                  option.setArgName(null);
                                                                                                                  assertFalse(option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testHasArgName_WhenArgNameContainsSpecialCharacters() {
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  option.setArgName("arg-name_with.special@chars!");
                                                                                                                  assertTrue(option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testHasArgName_WhenArgNameIsVeryLong() {
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  String longName = new String(new char[1000]).replace("\0", "x");
                                                                                                                  option.setArgName(longName);
                                                                                                                  assertTrue(option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testHasArgName_AfterConstruction() {
                                                                                                                  // Create an Option object for testing
                                                                                                                  Option option = new Option("test", "description");
                                                                                                                  
                                                                                                                  // Verify initial state after construction
                                                                                                                  assertFalse(option.hasArgName());
                                                                                                                  
                                                                                                                  // Set argName and verify
                                                                                                                  option.setArgName("newArg");
                                                                                                                  assertTrue(option.hasArgName());
                                                                                                              }

 @Test
                                                                                                              public void testHasArgs_WhenNumberOfArgsIsZero_ShouldReturnFalse() {
                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                  option.setArgs(0);
                                                                                                                  assertFalse(option.hasArgs());
                                                                                                              }

 @Test
                                                                                                              public void testHasArgs_WhenNumberOfArgsIsOne_ShouldReturnFalse() {
                                                                                                                  Option option = new Option("t", "test option");
                                                                                                                  option.setArgs(1);
                                                                                                                  assertFalse(option.hasArgs());
                                                                                                              }

 @Test
                                                                                                          public void testHasArgs_WhenNumberOfArgsIsTwo_ShouldReturnTrue() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setArgs(2);
                                                                                                              assertTrue(option.hasArgs());
                                                                                                          }

 @Test
                                                                                                          public void testHasArgs_WhenNumberOfArgsIsGreaterThanOne_ShouldReturnTrue() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setArgs(5);
                                                                                                              assertTrue(option.hasArgs());
                                                                                                          }

 @Test
                                                                                                          public void testHasArgs_WhenNumberOfArgsIsUnlimitedValues_ShouldReturnTrue() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                              assertTrue(option.hasArgs());
                                                                                                          }

 @Test
                                                                                                          public void testHasArgs_WhenNumberOfArgsIsNegative_ShouldReturnFalse() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setArgs(-1);
                                                                                                              assertFalse(option.hasArgs());
                                                                                                          }

 @Test
                                                                                                          public void testHasArgs_WhenNumberOfArgsIsUninitialized_ShouldReturnFalse() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              // Using -1 to represent uninitialized state (common convention)
                                                                                                              option.setArgs(-1);
                                                                                                              assertFalse(option.hasArgs());
                                                                                                          }

 @Test
                                                                                                          public void testHasArgs_AfterChangingNumberOfArgs_ShouldReflectNewValue() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              
                                                                                                              option.setArgs(0);
                                                                                                              assertFalse(option.hasArgs());
                                                                                                              
                                                                                                              option.setArgs(2);
                                                                                                              assertTrue(option.hasArgs());
                                                                                                              
                                                                                                              option.setArgs(1);
                                                                                                              assertFalse(option.hasArgs());
                                                                                                          }

 @Test
                                                                                                          public void testSetArgs_WithPositiveNumber() {
                                                                                                              Option option = new Option("t", "test option");
                                                                                                              option.setArgs(5);
                                                                                                              assertEquals(5, option.getArgs());
                                                                                                          }

 @Test
                                                                                                          public void testSetArgs_WithZero() {
                                                                                                              Option option = new Option("t", "test option");
                                                                                                              option.setArgs(0);
                                                                                                              assertEquals(0, option.getArgs());
                                                                                                          }

 @Test
                                                                                                          public void testSetArgs_WithNegativeNumber() {
                                                                                                              Option option = new Option("t", "test option");
                                                                                                              option.setArgs(-3);
                                                                                                              assertEquals(-3, option.getArgs());
                                                                                                          }

 @Test
                                                                                                          public void testSetArgs_WithUnlimitedValuesConstant() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                              assertEquals(Option.UNLIMITED_VALUES, option.getArgs());
                                                                                                          }

 @Test
                                                                                                          public void testSetArgs_WithUninitializedConstant() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setArgs(-1); // Using -1 as the typical uninitialized value
                                                                                                              assertEquals(-1, option.getArgs());
                                                                                                          }

 @Test
                                                                                                          public void testSetArgs_WithMaxIntegerValue() {
                                                                                                              Option option = new Option("t", "test option");
                                                                                                              option.setArgs(Integer.MAX_VALUE);
                                                                                                              assertEquals(Integer.MAX_VALUE, option.getArgs());
                                                                                                          }

 @Test
                                                                                                          public void testSetArgs_WithMinIntegerValue() {
                                                                                                              Option option = new Option("t", "test option");
                                                                                                              option.setArgs(Integer.MIN_VALUE);
                                                                                                              assertEquals(Integer.MIN_VALUE, option.getArgs());
                                                                                                          }

 @Test
                                                                                                          public void testSetArgs_OverwritesPreviousValue() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setArgs(10);
                                                                                                              assertEquals(10, option.getArgs());
                                                                                                              
                                                                                                              option.setArgs(20);
                                                                                                              assertEquals(20, option.getArgs());
                                                                                                          }

 @Test
                                                                                                          public void testSetArgs_DoesNotAffectOtherProperties() {
                                                                                                              // Create an Option object with some initial values
                                                                                                              Option option = new Option("t", "test", true, "test description");
                                                                                                              option.setRequired(true);
                                                                                                              
                                                                                                              String originalDescription = option.getDescription();
                                                                                                              boolean originalRequired = option.isRequired();
                                                                                                              String originalLongOpt = option.getLongOpt();
                                                                                                              
                                                                                                              option.setArgs(7);
                                                                                                              
                                                                                                              assertEquals(7, option.getArgs());
                                                                                                              assertEquals(originalDescription, option.getDescription());
                                                                                                              assertEquals(originalRequired, option.isRequired());
                                                                                                              assertEquals(originalLongOpt, option.getLongOpt());
                                                                                                          }

 @Test
                                                                                                          public void testSetValueSeparator_WithRegularCharacter() {
                                                                                                              // Test setting a regular character as separator
                                                                                                              Option option = new Option("test", "description");
                                                                                                              char testSeparator = '=';
                                                                                                              option.setValueSeparator(testSeparator);
                                                                                                              assertEquals("Separator should be set to '='", 
                                                                                                                           testSeparator, option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testSetValueSeparator_WithSpecialCharacter() {
                                                                                                              // Test setting a special character as separator
                                                                                                              char testSeparator = '@';
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setValueSeparator(testSeparator);
                                                                                                              assertEquals("Separator should be set to '@'", 
                                                                                                                           testSeparator, option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testSetValueSeparator_WithWhitespaceCharacter() {
                                                                                                              // Create an Option object for testing
                                                                                                              Option option = new Option("test", "description");
                                                                                                              
                                                                                                              // Test setting whitespace as separator
                                                                                                              char testSeparator = ' ';
                                                                                                              option.setValueSeparator(testSeparator);
                                                                                                              assertEquals("Separator should be set to space", 
                                                                                                                           testSeparator, option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testSetValueSeparator_WithNonPrintableCharacter() {
                                                                                                              // Test setting a non-printable character as separator
                                                                                                              Option option = new Option("test", "description");
                                                                                                              char testSeparator = '\t';
                                                                                                              option.setValueSeparator(testSeparator);
                                                                                                              assertEquals("Separator should be set to tab", 
                                                                                                                           testSeparator, option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testSetValueSeparator_WithUnicodeCharacter() {
                                                                                                              // Test setting a Unicode character as separator
                                                                                                              Option option = new Option("test", "description");
                                                                                                              char testSeparator = '¶';
                                                                                                              option.setValueSeparator(testSeparator);
                                                                                                              assertEquals("Separator should be set to Unicode character", 
                                                                                                                           testSeparator, option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testSetValueSeparator_WithNullCharacter() {
                                                                                                              // Create an Option object for testing
                                                                                                              Option option = new Option("test", "description");
                                                                                                              
                                                                                                              // Test setting null character as separator
                                                                                                              char testSeparator = '\0';
                                                                                                              option.setValueSeparator(testSeparator);
                                                                                                              assertEquals("Separator should be set to null character", 
                                                                                                                           testSeparator, option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testSetValueSeparator_WithDigitCharacter() {
                                                                                                              // Test setting a digit as separator
                                                                                                              Option option = new Option("test", "description");
                                                                                                              char testSeparator = '7';
                                                                                                              option.setValueSeparator(testSeparator);
                                                                                                              assertEquals("Separator should be set to digit", 
                                                                                                                           testSeparator, option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testSetValueSeparator_VerifyHasValueSeparator() {
                                                                                                              // Test that hasValueSeparator returns true after setting a separator
                                                                                                              Option option = new Option("test", "description");
                                                                                                              char testSeparator = '=';
                                                                                                              option.setValueSeparator(testSeparator);
                                                                                                              assertTrue("hasValueSeparator should return true", 
                                                                                                                         option.hasValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testSetValueSeparator_VerifyDefaultNoSeparator() {
                                                                                                              // Test that a new option has no separator by default
                                                                                                              Option option = new Option("test", "description");
                                                                                                              assertFalse("New option should not have value separator", 
                                                                                                                         option.hasValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testSetValueSeparator_VerifyMultipleSets() {
                                                                                                              // Test that setting separator multiple times works correctly
                                                                                                              Option option = new Option("test", "description");
                                                                                                              char firstSeparator = '=';
                                                                                                              char secondSeparator = ':';
                                                                                                              
                                                                                                              option.setValueSeparator(firstSeparator);
                                                                                                              assertEquals("First separator should be set", 
                                                                                                                           firstSeparator, option.getValueSeparator());
                                                                                                              
                                                                                                              option.setValueSeparator(secondSeparator);
                                                                                                              assertEquals("Second separator should override first", 
                                                                                                                           secondSeparator, option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testGetValueSeparator_DefaultValue() {
                                                                                                              // Default value should be '\0' (null character)
                                                                                                              Option option = new Option("test", "description");
                                                                                                              assertEquals('\0', option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testGetValueSeparator_AfterSettingSeparator() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setValueSeparator('=');
                                                                                                              assertEquals('=', option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testGetValueSeparator_AfterSettingAndClearing() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setValueSeparator('=');
                                                                                                              option.setValueSeparator('\0');
                                                                                                              assertEquals('\0', option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testGetValueSeparator_NonPrintableCharacter() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setValueSeparator('\t');
                                                                                                              assertEquals('\t', option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testGetValueSeparator_UnicodeCharacter() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setValueSeparator('€');
                                                                                                              assertEquals('€', option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testGetValueSeparator_AfterMultipleChanges() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setValueSeparator('=');
                                                                                                              assertEquals('=', option.getValueSeparator());
                                                                                                              
                                                                                                              option.setValueSeparator(':');
                                                                                                              assertEquals(':', option.getValueSeparator());
                                                                                                              
                                                                                                              option.setValueSeparator(' ');
                                                                                                              assertEquals(' ', option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testGetValueSeparator_WithHasValueSeparator() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              assertFalse(option.hasValueSeparator());
                                                                                                              assertEquals('\0', option.getValueSeparator());
                                                                                                              
                                                                                                              option.setValueSeparator('=');
                                                                                                              assertTrue(option.hasValueSeparator());
                                                                                                              assertEquals('=', option.getValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testHasValueSeparator_WhenNoSeparatorSet_ShouldReturnFalse() {
                                                                                                              // Default case where no separator is set
                                                                                                              Option option = new Option("test", "description");
                                                                                                              assertFalse(option.hasValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testHasValueSeparator_WhenSeparatorIsSpace_ShouldReturnTrue() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setValueSeparator(' ');
                                                                                                              assertTrue(option.hasValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testHasValueSeparator_WhenSeparatorIsNonPrintableCharacter_ShouldReturnTrue() {
                                                                                                              Option option = new Option("t", "test option");
                                                                                                              option.setValueSeparator('\t');
                                                                                                              assertTrue(option.hasValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testHasValueSeparator_WhenSeparatorIsZero_ShouldReturnFalse() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setValueSeparator('\0');
                                                                                                              assertFalse(option.hasValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testHasValueSeparator_WhenSeparatorIsPositiveCharacter_ShouldReturnTrue() {
                                                                                                              Option option = new Option("test", "description");
                                                                                                              option.setValueSeparator('=');
                                                                                                              assertTrue(option.hasValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testHasValueSeparator_AfterClearingSeparator_ShouldReturnFalse() {
                                                                                                              // Create an Option object for testing
                                                                                                              Option option = new Option("test", "description");
                                                                                                              
                                                                                                              // First set a separator
                                                                                                              option.setValueSeparator('=');
                                                                                                              assertTrue(option.hasValueSeparator());
                                                                                                              
                                                                                                              // Then set it to 0 (clear it)
                                                                                                              option.setValueSeparator('\0');
                                                                                                              assertFalse(option.hasValueSeparator());
                                                                                                          }

 @Test
                                                                                                          public void testHasValueSeparator_WithMultipleSeparatorChanges() {
                                                                                                              // Create Option object
                                                                                                              Option option = new Option("test", "description");
                                                                                                              
                                                                                                              // Initial state
                                                                                                              assertFalse(option.hasValueSeparator());
                                                                                                              
                                                                                                              // Set first separator
                                                                                                              option.setValueSeparator(':');
                                                                                                              assertTrue(option.hasValueSeparator());
                                                                                                              
                                                                                                              // Change to different separator
                                                                                                              option.setValueSeparator('|');
                                                                                                              assertTrue(option.hasValueSeparator());
                                                                                                              
                                                                                                              // Clear separator
                                                                                                              option.setValueSeparator('\0');
                                                                                                              assertFalse(option.hasValueSeparator());
                                                                                                              
                                                                                                              // Set again
                                                                                                              option.setValueSeparator(';');
                                                                                                              assertTrue(option.hasValueSeparator());
                                                                                                          }

 @Test
                                                                                                      public void testGetArgs_WhenInitializedWithNoArgs() {
                                                                                                          Option option = new Option("t", "test description");
                                                                                                          assertEquals("Should return UNINITIALIZED when no args specified", 
                                                                                                                       Option.UNINITIALIZED, option.getArgs());
                                                                                                      }

 @Test
                                                                                                      public void testGetArgs_WhenInitializedWithHasArgTrue() {
                                                                                                          Option option = new Option("t", true, "test description");
                                                                                                          assertEquals("Should return 1 when hasArg is true in constructor", 
                                                                                                                       1, option.getArgs());
                                                                                                      }

 @Test
                                                                                                      public void testGetArgs_WhenSetArgsCalledWithPositiveNumber() {
                                                                                                          Option option = new Option("t", "test description");
                                                                                                          option.setArgs(3);
                                                                                                          assertEquals("Should return the number set by setArgs", 
                                                                                                                       3, option.getArgs());
                                                                                                      }

 @Test
                                                                                                      public void testGetArgs_WhenSetArgsCalledWithUnlimitedValues() {
                                                                                                          Option option = new Option("t", "test description");
                                                                                                          option.setArgs(Option.UNLIMITED_VALUES);
                                                                                                          assertEquals("Should return UNLIMITED_VALUES when set", 
                                                                                                                       Option.UNLIMITED_VALUES, option.getArgs());
                                                                                                      }

 @Test(expected = IllegalArgumentException.class)
                                                                                                      public void testGetArgs_WhenSetArgsCalledWithNegativeNumber() {
                                                                                                          Option option = new Option("t", "test description");
                                                                                                          option.setArgs(-2);
                                                                                                      }

 @Test
                                                                                                      public void testGetArgs_AfterCloneOperation() throws CloneNotSupportedException {
                                                                                                          Option option = new Option("t", true, "test description");
                                                                                                          Option clonedOption = (Option) option.clone();
                                                                                                          assertEquals("Cloned option should have same number of args", 
                                                                                                                       option.getArgs(), clonedOption.getArgs());
                                                                                                      }

 @Test
                                                                                                      public void testGetArgs_WhenInitializedWithLongOptAndHasArg() {
                                                                                                          Option option = new Option("t", "testOpt", true, "test description");
                                                                                                          assertEquals("Should return 1 when hasArg is true in constructor with longOpt", 
                                                                                                                       1, option.getArgs());
                                                                                                      }

 @Test
                                                                                                      public void testGetArgs_WhenSetArgsCalledWithZero() {
                                                                                                          Option option = new Option("t", "test description");
                                                                                                          option.setArgs(0);
                                                                                                          assertEquals("Should return 0 when setArgs(0) is called", 
                                                                                                                       0, option.getArgs());
                                                                                                      }

 @Test
                                                                                                      public void testAddValueForProcessing_WhenUninitialized_ShouldThrowException() {
                                                                                                          // Arrange
                                                                                                          Option option = new Option("t", "test option");
                                                                                                          // Use reflection to set numberOfArgs to UNINITIALIZED since it's private
                                                                                                          try {
                                                                                                              java.lang.reflect.Field field = Option.class.getDeclaredField("numberOfArgs");
                                                                                                              field.setAccessible(true);
                                                                                                              field.set(option, Option.UNINITIALIZED);
                                                                                                          } catch (Exception e) {
                                                                                                              throw new RuntimeException("Failed to set numberOfArgs via reflection", e);
                                                                                                          }
                                                                                                          
                                                                                                          // Expect exception
                                                                                                          ExpectedException thrown = ExpectedException.none();
                                                                                                          thrown.expect(RuntimeException.class);
                                                                                                          thrown.expectMessage("NO_ARGS_ALLOWED");
                                                                                                          
                                                                                                          // Act
                                                                                                          try {
                                                                                                              java.lang.reflect.Method method = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                              method.setAccessible(true);
                                                                                                              method.invoke(option, "testValue");
                                                                                                          } catch (Exception e) {
                                                                                                              throw new RuntimeException("Failed to invoke addValueForProcessing via reflection", e);
                                                                                                          }
                                                                                                      }

 @Test
                                                                                                      public void testAddValueForProcessing_WithDifferentArgCounts_ShouldCallProcessValue() throws Exception {
                                                                                                          // Test with different valid numberOfArgs values
                                                                                                          Option option1 = new Option("t", true, "test option"); // numberOfArgs = 1
                                                                                                          Option option2 = new Option("t", "test option");
                                                                                                          
                                                                                                          // Set numberOfArgs to UNLIMITED_VALUES via reflection
                                                                                                          try {
                                                                                                              java.lang.reflect.Field field = Option.class.getDeclaredField("numberOfArgs");
                                                                                                              field.setAccessible(true);
                                                                                                              field.set(option2, Option.UNLIMITED_VALUES);
                                                                                                          } catch (Exception e) {
                                                                                                              throw new RuntimeException("Failed to set numberOfArgs via reflection", e);
                                                                                                          }
                                                                                                      
                                                                                                          String testValue = "testValue";
                                                                                                      
                                                                                                          // Use reflection to call addValueForProcessing
                                                                                                          Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                          addValueMethod.setAccessible(true);
                                                                                                          
                                                                                                          // Act for option1
                                                                                                          addValueMethod.invoke(option1, testValue);
                                                                                                          // Verify value was added by checking internal state
                                                                                                          Method getValuesMethod = Option.class.getDeclaredMethod("getValues");
                                                                                                          getValuesMethod.setAccessible(true);
                                                                                                          String[] values1 = (String[]) getValuesMethod.invoke(option1);
                                                                                                          assertEquals(1, values1.length);
                                                                                                          assertEquals(testValue, values1[0]);
                                                                                                      
                                                                                                          // Act for option2
                                                                                                          addValueMethod.invoke(option2, testValue);
                                                                                                          // Verify value was added by checking internal state
                                                                                                          String[] values2 = (String[]) getValuesMethod.invoke(option2);
                                                                                                          assertEquals(1, values2.length);
                                                                                                          assertEquals(testValue, values2[0]);
                                                                                                      }

 @Test
                                                                                                      public void testAdd_WhenAcceptsArgIsTrue_ShouldAddValueToList() throws Exception {
                                                                                                          // Arrange
                                                                                                          Option option = new Option("test", "description");
                                                                                                          option.setArgs(1); // Make it accept arguments
                                                                                                          
                                                                                                          // Use reflection to access private values field
                                                                                                          Field valuesField = Option.class.getDeclaredField("values");
                                                                                                          valuesField.setAccessible(true);
                                                                                                          @SuppressWarnings("unchecked")
                                                                                                          List<String> values = (List<String>) valuesField.get(option);
                                                                                                          
                                                                                                          String testValue = "testValue";
                                                                                                          
                                                                                                          // Act - use public method that internally calls add()
                                                                                                          boolean result = option.addValue(testValue);
                                                                                                          
                                                                                                          // Assert
                                                                                                          assertTrue(result);
                                                                                                          assertEquals(1, values.size());
                                                                                                          assertEquals(testValue, values.get(0));
                                                                                                      }

 @Test
                                                                                                      public void testAdd_WhenAcceptsArgIsFalse_ShouldThrowRuntimeException() throws Exception {
                                                                                                          // Arrange
                                                                                                          Option option = new Option("test", "description");
                                                                                                          String testValue = "testValue";
                                                                                                          
                                                                                                          // Use reflection to mock acceptsArg() to return false
                                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                                          
                                                                                                          Option spyOption = spy(option);
                                                                                                          when(acceptsArgMethod.invoke(spyOption)).thenReturn(false);
                                                                                                          
                                                                                                          // Act & Assert
                                                                                                          try {
                                                                                                              Method addMethod = Option.class.getDeclaredMethod("add", String.class);
                                                                                                              addMethod.setAccessible(true);
                                                                                                              addMethod.invoke(spyOption, testValue);
                                                                                                              fail("Expected RuntimeException");
                                                                                                          } catch (InvocationTargetException e) {
                                                                                                              assertEquals(RuntimeException.class, e.getCause().getClass());
                                                                                                              assertEquals("Cannot add value, list full.", e.getCause().getMessage());
                                                                                                          }
                                                                                                      }

 @Test
                                                                                                      public void testAdd_WhenValueIsNull_ShouldAddNullValueToList() throws Exception {
                                                                                                          // Arrange
                                                                                                          Option option = new Option("test", "description");
                                                                                                          
                                                                                                          // Use reflection to modify private acceptsArg field
                                                                                                          Field hasArgField = Option.class.getDeclaredField("hasArg");
                                                                                                          hasArgField.setAccessible(true);
                                                                                                          hasArgField.set(option, true);
                                                                                                          
                                                                                                          // Act
                                                                                                          option.addValue(null);
                                                                                                          
                                                                                                          // Assert
                                                                                                          List<String> values = option.getValuesList();
                                                                                                          assertEquals(1, values.size());
                                                                                                          assertNull(values.get(0));
                                                                                                      }

 @Test
                                                                                                  public void testGetValue_WhenValuesListIsEmpty_ShouldReturnNull() {
                                                                                                      // Setup
                                                                                                      Option option = new Option("test", "description");
                                                                                                      List<String> emptyList = new ArrayList<>();
                                                                                                      
                                                                                                      // Using reflection to set the private values field for this edge case
                                                                                                      try {
                                                                                                          java.lang.reflect.Field field = Option.class.getDeclaredField("values");
                                                                                                          field.setAccessible(true);
                                                                                                          field.set(option, emptyList);
                                                                                                      } catch (Exception e) {
                                                                                                          fail("Failed to set values field via reflection");
                                                                                                      }
                                                                                                      
                                                                                                      // Execute & Verify
                                                                                                      assertNull(option.getValue());
                                                                                                  }

 @Test
                                                                                                  public void testGetValue_WhenValuesListIsNull_ShouldReturnNull() {
                                                                                                      // Setup
                                                                                                      Option option = new Option("test", "description");
                                                                                                      
                                                                                                      // Using reflection to set the private values field to null
                                                                                                      try {
                                                                                                          java.lang.reflect.Field field = Option.class.getDeclaredField("values");
                                                                                                          field.setAccessible(true);
                                                                                                          field.set(option, null);
                                                                                                      } catch (Exception e) {
                                                                                                          fail("Failed to set values field via reflection");
                                                                                                      }
                                                                                                      
                                                                                                      // Execute & Verify
                                                                                                      assertNull(option.getValue());
                                                                                                  }

 @Test
                                                                                                  public void testGetValue_WhenNoValuesExist_ShouldReturnNull() throws Exception {
                                                                                                      // Setup - create option and clear its values
                                                                                                      Option option = new Option("test", "description");
                                                                                                      
                                                                                                      // Use reflection to access and clear the private values list
                                                                                                      Field valuesField = Option.class.getDeclaredField("values");
                                                                                                      valuesField.setAccessible(true);
                                                                                                      List<String> values = (List<String>) valuesField.get(option);
                                                                                                      values.clear();
                                                                                                      
                                                                                                      // Test & Verify
                                                                                                      assertNull(option.getValue(0));
                                                                                                      assertNull(option.getValue(1));
                                                                                                  }

 @Test
                                                                                                  public void testGetValue_WithValidIndex_ShouldReturnCorrectValue() throws Exception {
                                                                                                      // Setup
                                                                                                      Option option = new Option("test", "description");
                                                                                                      
                                                                                                      // Use reflection to access private values field
                                                                                                      Field valuesField = Option.class.getDeclaredField("values");
                                                                                                      valuesField.setAccessible(true);
                                                                                                      List<String> values = new ArrayList<>();
                                                                                                      values.add("value1");
                                                                                                      values.add("value2");
                                                                                                      values.add("value3");
                                                                                                      valuesField.set(option, values);
                                                                                                      
                                                                                                      // Test & Verify
                                                                                                      assertEquals("value1", option.getValue(0));
                                                                                                      assertEquals("value2", option.getValue(1));
                                                                                                      assertEquals("value3", option.getValue(2));
                                                                                                  }

 @Test
                                                                                                  public void testGetValue_WithNegativeIndex_ShouldThrowIndexOutOfBoundsException() {
                                                                                                      // Setup
                                                                                                      Option option = new Option("test", "description");
                                                                                                      option.addValue("value1");
                                                                                                      
                                                                                                      // Expect exception
                                                                                                      ExpectedException thrown = ExpectedException.none();
                                                                                                      thrown.expect(IndexOutOfBoundsException.class);
                                                                                                      
                                                                                                      // Test
                                                                                                      option.getValue(-1);
                                                                                                  }

 @Test
                                                                                                  public void testGetValue_WithIndexEqualToSize_ShouldThrowIndexOutOfBoundsException() throws Exception {
                                                                                                      // Setup
                                                                                                      Option option = new Option("test", "description");
                                                                                                      List<String> values = new ArrayList<>();
                                                                                                      values.add("value1");
                                                                                                      values.add("value2");
                                                                                                      
                                                                                                      // Use reflection to set private values field
                                                                                                      Field valuesField = Option.class.getDeclaredField("values");
                                                                                                      valuesField.setAccessible(true);
                                                                                                      valuesField.set(option, values);
                                                                                                  
                                                                                                      // Expect exception
                                                                                                      thrown.expect(IndexOutOfBoundsException.class);
                                                                                                      
                                                                                                      // Test
                                                                                                      option.getValue(2); // size is 2, so index 2 is out of bounds
                                                                                                  }

 @Test
                                                                                                  public void testGetValue_WithNullValueInList_ShouldReturnNull() throws Exception {
                                                                                                      // Setup
                                                                                                      Option option = new Option("test", "description");
                                                                                                      List<String> values = new ArrayList<>();
                                                                                                      values.add("value1");
                                                                                                      values.add(null);
                                                                                                      values.add("value3");
                                                                                                      
                                                                                                      // Use reflection to set private values field
                                                                                                      Field valuesField = Option.class.getDeclaredField("values");
                                                                                                      valuesField.setAccessible(true);
                                                                                                      valuesField.set(option, values);
                                                                                                      
                                                                                                      // Test & Verify
                                                                                                      assertEquals("value1", option.getValue(0));
                                                                                                      assertNull(option.getValue(1));
                                                                                                      assertEquals("value3", option.getValue(2));
                                                                                                  }

 @Test
                                                                                                  public void testGetValue_WithEmptyStringInList_ShouldReturnEmptyString() {
                                                                                                      // Setup
                                                                                                      Option option = new Option("test", "description");
                                                                                                      List<String> mockValues = new ArrayList<>();
                                                                                                      mockValues.add("");
                                                                                                      mockValues.add("value");
                                                                                                      
                                                                                                      try {
                                                                                                          Field valuesField = Option.class.getDeclaredField("values");
                                                                                                          valuesField.setAccessible(true);
                                                                                                          valuesField.set(option, mockValues);
                                                                                                      } catch (Exception e) {
                                                                                                          fail("Failed to set values field via reflection");
                                                                                                      }
                                                                                                  
                                                                                                      // Test & Verify
                                                                                                      assertEquals("", option.getValue(0));
                                                                                                      assertEquals("value", option.getValue(1));
                                                                                                  }

 @Test
                                                                                                  public void testGetValue_WithValuesListNotInitialized_ShouldReturnNull() {
                                                                                                      // Setup - create option and set values to null
                                                                                                      Option option = new Option("test", "description");
                                                                                                      try {
                                                                                                          java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                                          valuesField.setAccessible(true);
                                                                                                          valuesField.set(option, null);
                                                                                                      } catch (Exception e) {
                                                                                                          throw new RuntimeException("Failed to set values field to null for testing", e);
                                                                                                      }
                                                                                                      
                                                                                                      // Test & Verify
                                                                                                      assertNull(option.getValue(0));
                                                                                                  }

 @Test
                                                                                                  public void testGetValue_WhenNoValueSet_ShouldReturnNull() {
                                                                                                      // Create a new Option with no values set
                                                                                                      Option option = new Option("test", "description");
                                                                                                      
                                                                                                      // When no values are set, getValue() should return null
                                                                                                      assertNull(option.getValue());
                                                                                                  }

 @Test
                                                                                                  public void testGetValues_WhenNoValuesExist_ShouldReturnNull() {
                                                                                                      // Setup - no values added
                                                                                                      Option option = new Option("test", "description");
                                                                                                      assertNull(option.getValues());
                                                                                                  }

 @Test
                                                                                                  public void testGetValues_WhenValuesListIsEmpty_ShouldReturnNull() {
                                                                                                      // Setup - create an Option with no values
                                                                                                      Option option = new Option("test", "description");
                                                                                                      
                                                                                                      // Test
                                                                                                      String[] result = option.getValues();
                                                                                                      
                                                                                                      // Verify
                                                                                                      assertNull(result);
                                                                                                  }

 @Test
                                                                                                  public void testGetValuesList_WhenNoValuesSet_ShouldReturnNull() {
                                                                                                      // Given - no values set (default state)
                                                                                                      Option option = new Option("test", "description");
                                                                                                      
                                                                                                      // When
                                                                                                      List<String> result = option.getValuesList();
                                                                                                      
                                                                                                      // Then
                                                                                                      assertNull("Values list should be null when no values are set", result);
                                                                                                  }

 @Test
                                                                                                  public void testGetValuesList_WhenSingleValueAdded_ShouldReturnListWithOneValue() {
                                                                                                      // Given
                                                                                                      String testValue = "testValue";
                                                                                                      Option option = new Option("test", "description");
                                                                                                      option.addValue(testValue);
                                                                                                      
                                                                                                      // When
                                                                                                      List<String> result = option.getValuesList();
                                                                                                      
                                                                                                      // Then
                                                                                                      assertNotNull("Values list should not be null after adding value", result);
                                                                                                      assertEquals("Values list should contain one value", 1, result.size());
                                                                                                      assertEquals("Values list should contain the added value", testValue, result.get(0));
                                                                                                  }

 @Test
                                                                                              public void testGetValuesList_ShouldReturnDefensiveCopy() {
                                                                                                  // Given
                                                                                                  Option option = new Option("test", "description");
                                                                                                  option.addValue("originalValue");
                                                                                                  
                                                                                                  // When
                                                                                                  List<String> result = option.getValuesList();
                                                                                                  result.add("modifiedValue");
                                                                                                  
                                                                                                  // Then
                                                                                                  List<String> secondResult = option.getValuesList();
                                                                                                  assertEquals("Original values list should not be modified", 1, secondResult.size());
                                                                                                  assertEquals("Original values list should not be modified", "originalValue", secondResult.get(0));
                                                                                              }

 @Test
                                                                                              public void testClone_WithNullValues() throws Exception {
                                                                                                  Option original = new Option("n", null, false, "null option");
                                                                                                  
                                                                                                  // Use reflection to set private values field to null
                                                                                                  Field valuesField = Option.class.getDeclaredField("values");
                                                                                                  valuesField.setAccessible(true);
                                                                                                  valuesField.set(original, null);
                                                                                                  
                                                                                                  Option cloned = (Option) original.clone();
                                                                                                  
                                                                                                  // Use public method to verify values
                                                                                                  assertNull(cloned.getValuesList());
                                                                                              }

 @Test
                                                                                              public void testClone_VerifyIndependentState() throws Exception {
                                                                                                  Option original = new Option("d", "debug", false, "debug option");
                                                                                                  original.addValue("debug1");
                                                                                                  
                                                                                                  Option cloned = (Option) original.clone();
                                                                                                  
                                                                                                  // Modify clone and verify original is unaffected
                                                                                                  cloned.addValue("debug2");
                                                                                                  assertEquals(1, original.getValuesList().size());
                                                                                                  assertEquals(2, cloned.getValuesList().size());
                                                                                              }

 @Test
                                                                                              public void testClone_WithAllFieldsSet() throws Exception {
                                                                                                  Option original = new Option("a", "all", true, "all fields option");
                                                                                                  original.setArgName("arg");
                                                                                                  original.setDescription("full description");
                                                                                                  original.setRequired(false);
                                                                                                  original.setOptionalArg(true);
                                                                                                  original.setArgs(Option.UNLIMITED_VALUES);
                                                                                                  original.setValueSeparator(';');
                                                                                                  original.addValue("one");
                                                                                                  original.addValue("two");
                                                                                                  
                                                                                                  Option cloned = (Option) original.clone();
                                                                                                  
                                                                                                  // Verify all fields are properly cloned
                                                                                                  assertEquals(original.getOpt(), cloned.getOpt());
                                                                                                  assertEquals(original.getLongOpt(), cloned.getLongOpt());
                                                                                                  assertEquals(original.getArgName(), cloned.getArgName());
                                                                                                  assertEquals(original.getDescription(), cloned.getDescription());
                                                                                                  assertEquals(original.isRequired(), cloned.isRequired());
                                                                                                  assertEquals(original.hasOptionalArg(), cloned.hasOptionalArg());
                                                                                                  assertEquals(original.getArgs(), cloned.getArgs());
                                                                                                  assertEquals(original.getValueSeparator(), cloned.getValueSeparator());
                                                                                                  assertEquals(original.getValuesList(), cloned.getValuesList());
                                                                                                  assertNotSame(original.getValuesList(), cloned.getValuesList());
                                                                                              }

 @Test
                                                                                              public void testAcceptsArg_WhenHasArgTrue() {
                                                                                                  // Case: hasArg is true
                                                                                                  Option argOption = new Option("a", true, "Option with arg");
                                                                                                  try {
                                                                                                      Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                                      acceptsArgMethod.setAccessible(true);
                                                                                                      boolean result = (boolean) acceptsArgMethod.invoke(argOption);
                                                                                                      assertTrue(result);
                                                                                                  } catch (Exception e) {
                                                                                                      fail("Failed to test acceptsArg method: " + e.getMessage());
                                                                                                  }
                                                                                              }

 @Test
                                                                                          public void testAcceptsArg_WhenHasArgButValuesFull() throws Exception {
                                                                                              // Case: hasArg is true but values list is full
                                                                                              Option argOption = new Option("a", true, "Option with arg");
                                                                                              
                                                                                              // Use reflection to access private addValueForProcessing method
                                                                                              Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                              addValueMethod.setAccessible(true);
                                                                                              addValueMethod.invoke(argOption, "value");
                                                                                              
                                                                                              // Use reflection to access private acceptsArg method
                                                                                              Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                              acceptsArgMethod.setAccessible(true);
                                                                                              boolean result = (boolean) acceptsArgMethod.invoke(argOption);
                                                                                              
                                                                                              assertFalse(result);
                                                                                          }

 @Test
                                                                                          public void testRequiresArg_WhenNumberOfArgsIsNotUnlimited_DelegatesToAcceptsArg() throws Exception {
                                                                                              // Create a real Option object
                                                                                              Option option = new Option("test", "description");
                                                                                              
                                                                                              // Use reflection to access private methods
                                                                                              Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                              requiresArgMethod.setAccessible(true);
                                                                                              Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                              acceptsArgMethod.setAccessible(true);
                                                                                              
                                                                                              // Set up the object state for testing when acceptsArg returns true
                                                                                              Field optionalArgField = Option.class.getDeclaredField("optionalArg");
                                                                                              optionalArgField.setAccessible(true);
                                                                                              optionalArgField.set(option, false);
                                                                                              
                                                                                              Field numberOfArgsField = Option.class.getDeclaredField("numberOfArgs");
                                                                                              numberOfArgsField.setAccessible(true);
                                                                                              numberOfArgsField.set(option, 1); // Not unlimited
                                                                                              
                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                              valuesField.setAccessible(true);
                                                                                              @SuppressWarnings("unchecked")
                                                                                              List<String> values = (List<String>) valuesField.get(option);
                                                                                              values.clear();
                                                                                              
                                                                                              // Mock the behavior of acceptsArg() to return true
                                                                                              Option spyOption = spy(option);
                                                                                              when(acceptsArgMethod.invoke(spyOption)).thenReturn(true);
                                                                                              
                                                                                              assertTrue((Boolean) requiresArgMethod.invoke(spyOption));
                                                                                              
                                                                                              // Test when acceptsArg returns false
                                                                                              when(acceptsArgMethod.invoke(spyOption)).thenReturn(false);
                                                                                              assertFalse((Boolean) requiresArgMethod.invoke(spyOption));
                                                                                          }

 @Test
                                                                                          public void testGetId_WithEmptyOpt() throws Exception {
                                                                                              // This case shouldn't happen due to validation in constructor
                                                                                              // but we'll test it anyway for robustness
                                                                                              Option option = new Option("", "description");
                                                                                              
                                                                                              // Use reflection to access private getKey() method
                                                                                              Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                              getKeyMethod.setAccessible(true);
                                                                                              getKeyMethod.invoke(option);  // This will set the key to empty string
                                                                                              
                                                                                              ExpectedException exception = ExpectedException.none();
                                                                                              exception.expect(StringIndexOutOfBoundsException.class);
                                                                                              option.getId();
                                                                                          }

 @Test
                                                                                          public void testGetKey_WhenOptIsNull_ReturnsLongOpt() throws Exception {
                                                                                              // Arrange
                                                                                              String expectedLongOpt = "long-option";
                                                                                              Option option = new Option(null, expectedLongOpt, false, "description");
                                                                                              
                                                                                              // Use reflection to access the private getKey() method
                                                                                              Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                              getKeyMethod.setAccessible(true);
                                                                                              
                                                                                              // Act
                                                                                              String actual = (String) getKeyMethod.invoke(option);
                                                                                              
                                                                                              // Assert
                                                                                              assertEquals(expectedLongOpt, actual);
                                                                                          }

 @Test
                                                                                          public void testGetKey_WhenOptIsNotNull_ReturnsOpt() {
                                                                                              // Arrange
                                                                                              String expectedOpt = "o";
                                                                                              Option option = new Option(expectedOpt, "long-option", false, "description");
                                                                                              
                                                                                              // Act
                                                                                              String actual = option.getOpt();
                                                                                              
                                                                                              // Assert
                                                                                              assertEquals(expectedOpt, actual);
                                                                                          }

 @Test
                                                                                          public void testGetKey_WhenBothOptAndLongOptAreNull_ReturnsNull() throws Exception {
                                                                                              // Arrange
                                                                                              Option option = new Option(null, null, false, "description");
                                                                                              
                                                                                              // Use reflection to access the package-private getKey() method
                                                                                              Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                              getKeyMethod.setAccessible(true);
                                                                                              
                                                                                              // Act
                                                                                              String actual = (String) getKeyMethod.invoke(option);
                                                                                              
                                                                                              // Assert
                                                                                              assertNull(actual);
                                                                                          }

 @Test
                                                                                          public void testGetKey_WhenOptIsEmptyString_ReturnsEmptyString() {
                                                                                              // Arrange
                                                                                              String expectedOpt = "";
                                                                                              Option option = new Option(expectedOpt, "long-option", false, "description");
                                                                                              
                                                                                              // Act
                                                                                              String actual = option.getOpt();
                                                                                              
                                                                                              // Assert
                                                                                              assertEquals(expectedOpt, actual);
                                                                                          }

 @Test
                                                                                          public void testGetKey_WhenLongOptIsEmptyStringAndOptIsNull_ReturnsEmptyString() throws Exception {
                                                                                              // Arrange
                                                                                              String expectedLongOpt = "";
                                                                                              Option option = new Option(null, expectedLongOpt, false, "description");
                                                                                              
                                                                                              // Use reflection to access the private getKey() method
                                                                                              Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                              getKeyMethod.setAccessible(true);
                                                                                              
                                                                                              // Act
                                                                                              String actual = (String) getKeyMethod.invoke(option);
                                                                                              
                                                                                              // Assert
                                                                                              assertEquals(expectedLongOpt, actual);
                                                                                          }

 @Test
                                                                                          public void testGetKey_AfterChangingOptValue_ReturnsNewOptValue() {
                                                                                              // Arrange
                                                                                              Option option = new Option("old", "long-option", false, "description");
                                                                                              String newOpt = "new";
                                                                                              
                                                                                              // Act - change the opt value through reflection since there's no setter
                                                                                              try {
                                                                                                  java.lang.reflect.Field field = Option.class.getDeclaredField("opt");
                                                                                                  field.setAccessible(true);
                                                                                                  field.set(option, newOpt);
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to set opt field via reflection");
                                                                                              }
                                                                                              
                                                                                              // Assert - using getOpt() instead of getKey() since it's public
                                                                                              assertEquals(newOpt, option.getOpt());
                                                                                          }

 @Test
                                                                                          public void testGetKey_AfterChangingLongOptValueWhenOptIsNull_ReturnsNewLongOptValue() throws Exception {
                                                                                              // Arrange
                                                                                              Option option = new Option(null, "old-long", false, "description");
                                                                                              String newLongOpt = "new-long";
                                                                                              
                                                                                              // Act - change the longOpt value through the setter
                                                                                              option.setLongOpt(newLongOpt);
                                                                                              
                                                                                              // Assert - use reflection to access the private getKey() method
                                                                                              Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                              getKeyMethod.setAccessible(true);
                                                                                              String actualKey = (String) getKeyMethod.invoke(option);
                                                                                              assertEquals(newLongOpt, actualKey);
                                                                                          }

 @Test
                                                                                          public void testGetKey_WithSpecialCharactersInOpt_ReturnsCorrectValue() {
                                                                                              // Arrange
                                                                                              String specialOpt = "-@#$%^&*()";
                                                                                              Option option = new Option(specialOpt, "long-option", false, "description");
                                                                                              
                                                                                              // Act
                                                                                              String actual = option.getOpt();
                                                                                              
                                                                                              // Assert
                                                                                              assertEquals(specialOpt, actual);
                                                                                          }

 @Test
                                                                                          public void testGetKey_WithSpecialCharactersInLongOpt_ReturnsCorrectValue() throws Exception {
                                                                                              // Arrange
                                                                                              String specialLongOpt = "-@#$%^&*()";
                                                                                              Option option = new Option(null, specialLongOpt, false, "description");
                                                                                              
                                                                                              // Use reflection to access the private getKey() method
                                                                                              Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                              getKeyMethod.setAccessible(true);
                                                                                              
                                                                                              // Act
                                                                                              String actual = (String) getKeyMethod.invoke(option);
                                                                                              
                                                                                              // Assert
                                                                                              assertEquals(specialLongOpt, actual);
                                                                                          }

 @Test
                                                                                          public void testGetKey_WithVeryLongStringInOpt_ReturnsCorrectValue() {
                                                                                              // Arrange
                                                                                              String longOptValue = new String(new char[10000]).replace('\0', 'a');
                                                                                              Option option = new Option(longOptValue, "long-option", false, "description");
                                                                                              
                                                                                              // Act
                                                                                              String actual = option.getOpt();
                                                                                              
                                                                                              // Assert
                                                                                              assertEquals(longOptValue, actual);
                                                                                          }

 @Test
                                                                                          public void testGetType_AfterClearValues_ShouldNotAffectType() {
                                                                                              // Arrange
                                                                                              Option option = new Option("test", "description");
                                                                                              option.setType(Float.class);
                                                                                              
                                                                                              // Act - Use reflection to call clearValues()
                                                                                              try {
                                                                                                  Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                  clearValuesMethod.setAccessible(true);
                                                                                                  clearValuesMethod.invoke(option);
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to invoke clearValues method via reflection: " + e.getMessage());
                                                                                              }
                                                                                              
                                                                                              Class<?> result = (Class<?>) option.getType();
                                                                                              
                                                                                              // Assert
                                                                                              assertEquals("Type should remain Float.class after clearValues", 
                                                                                                          Float.class, result);
                                                                                          }

 @Test
                                                                                          public void testIsRequired_AfterClearValues() throws Exception {
                                                                                              Option option = new Option("t", "test option");
                                                                                              option.setRequired(true);
                                                                                              
                                                                                              // Use reflection to access the private clearValues() method
                                                                                              Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                              clearValuesMethod.setAccessible(true);
                                                                                              clearValuesMethod.invoke(option);
                                                                                              
                                                                                              // Clearing values shouldn't affect the required flag
                                                                                              assertTrue(option.isRequired());
                                                                                          }

 @Test
                                                                                          public void testGetArgs_AfterClearValuesOperation() throws Exception {
                                                                                              Option option = new Option("t", true, "test description");
                                                                                              // Use reflection to access private clearValues() method
                                                                                              Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                              clearValuesMethod.setAccessible(true);
                                                                                              clearValuesMethod.invoke(option);
                                                                                              assertEquals("clearValues should not affect numberOfArgs", 
                                                                                                           1, option.getArgs());
                                                                                          }

 @Test
                                                                                          public void testProcessValue_NoSeparator() {
                                                                                              // Setup
                                                                                              Option option = new Option("test", "description");
                                                                                              option.setArgs(1); // Expecting 1 argument
                                                                                              option.setValueSeparator(','); // Set separator but won't be used
                                                                                              
                                                                                              // Execute
                                                                                              option.addValue("simplevalue");
                                                                                              
                                                                                              // Verify
                                                                                              assertEquals(1, option.getValuesList().size());
                                                                                              assertEquals("simplevalue", option.getValue());
                                                                                          }

 @Test
                                                                                          public void testProcessValue_SingleSeparator() {
                                                                                              // Setup
                                                                                              Option option = new Option("test", "description");
                                                                                              option.setArgs(2); // Expecting 2 arguments
                                                                                              option.setValueSeparator(',');
                                                                                              
                                                                                              // Execute
                                                                                              option.addValue("val1,val2");
                                                                                              
                                                                                              // Verify
                                                                                              List<String> values = option.getValuesList();
                                                                                              assertEquals(2, values.size());
                                                                                              assertEquals("val1", values.get(0));
                                                                                              assertEquals("val2", values.get(1));
                                                                                          }

 @Test
                                                                                          public void testProcessValue_MultipleSeparators() {
                                                                                              // Setup
                                                                                              Option option = new Option("test", "description");
                                                                                              option.setArgs(Option.UNLIMITED_VALUES);
                                                                                              option.setValueSeparator(';');
                                                                                              
                                                                                              // Execute
                                                                                              try {
                                                                                                  Method method = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                  method.setAccessible(true);
                                                                                                  method.invoke(option, "a;b;c;d");
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to invoke addValueForProcessing via reflection");
                                                                                              }
                                                                                              
                                                                                              // Verify
                                                                                              List<String> values = option.getValuesList();
                                                                                              assertEquals(4, values.size());
                                                                                              assertEquals("a", values.get(0));
                                                                                              assertEquals("b", values.get(1));
                                                                                              assertEquals("c", values.get(2));
                                                                                              assertEquals("d", values.get(3));
                                                                                          }

 @Test
                                                                                          public void testProcessValue_ReachesArgumentLimit() throws Exception {
                                                                                              // Setup
                                                                                              Option option = new Option("test", true, "description");
                                                                                              option.setArgs(3); // Expecting 3 arguments max
                                                                                              option.setValueSeparator('|');
                                                                                              
                                                                                              // Get the addValueForProcessing method via reflection
                                                                                              Method method = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                              method.setAccessible(true);
                                                                                              
                                                                                              // Execute
                                                                                              method.invoke(option, "one|two|three|four|five");
                                                                                              
                                                                                              // Verify
                                                                                              List<String> values = option.getValuesList();
                                                                                              assertEquals(3, values.size());
                                                                                              assertEquals("one", values.get(0));
                                                                                              assertEquals("two", values.get(1));
                                                                                              assertEquals("three|four|five", values.get(2)); // Remainder is kept as last value
                                                                                          }

 @Test
                                                                                          public void testProcessValue_EmptyString() {
                                                                                              // Setup
                                                                                              Option option = new Option("t", "test option");
                                                                                              option.setArgs(1);
                                                                                              option.setValueSeparator(',');
                                                                                              
                                                                                              // Execute
                                                                                              option.addValue("");
                                                                                              
                                                                                              // Verify
                                                                                              assertEquals(1, option.getValuesList().size());
                                                                                              assertEquals("", option.getValue());
                                                                                          }

 @Test
                                                                                          public void testProcessValue_SeparatorAtStart() {
                                                                                              // Setup
                                                                                              Option option = new Option("test", "description");
                                                                                              option.setArgs(2);
                                                                                              option.setValueSeparator(':');
                                                                                              
                                                                                              // Execute
                                                                                              option.addValue(":value");
                                                                                              
                                                                                              // Verify
                                                                                              List<String> values = option.getValuesList();
                                                                                              assertEquals(2, values.size());
                                                                                              assertEquals("", values.get(0));
                                                                                              assertEquals("value", values.get(1));
                                                                                          }

 @Test
                                                                                          public void testProcessValue_SeparatorAtEnd() {
                                                                                              // Setup
                                                                                              Option option = new Option("test", "description");
                                                                                              option.setArgs(2);
                                                                                              option.setValueSeparator(' ');
                                                                                              
                                                                                              // Execute
                                                                                              option.addValue("value ");
                                                                                              
                                                                                              // Verify
                                                                                              List<String> values = option.getValuesList();
                                                                                              assertEquals(2, values.size());
                                                                                              assertEquals("value", values.get(0));
                                                                                              assertEquals("", values.get(1));
                                                                                          }

 @Test
                                                                                          public void testProcessValue_ConsecutiveSeparators() {
                                                                                              // Setup
                                                                                              Option option = new Option("test", "description");
                                                                                              option.setArgs(Option.UNLIMITED_VALUES);
                                                                                              option.setValueSeparator('.');
                                                                                              
                                                                                              // Execute
                                                                                              // Using public addValue() method instead of package-private addValueForProcessing()
                                                                                              option.addValue("a..b.c...d");
                                                                                              
                                                                                              // Verify
                                                                                              List<String> values = option.getValuesList();
                                                                                              assertEquals(7, values.size());
                                                                                              assertEquals("a", values.get(0));
                                                                                              assertEquals("", values.get(1));
                                                                                              assertEquals("b", values.get(2));
                                                                                              assertEquals("c", values.get(3));
                                                                                              assertEquals("", values.get(4));
                                                                                              assertEquals("", values.get(5));
                                                                                              assertEquals("d", values.get(6));
                                                                                          }

 @Test
                                                                                          public void testProcessValue_NoValueSeparatorSet() {
                                                                                              // Setup - don't set value separator
                                                                                              Option option = new Option("test", "description");
                                                                                              option.setArgs(2);
                                                                                              
                                                                                              // Execute
                                                                                              option.addValue("should,not,split");
                                                                                              
                                                                                              // Verify
                                                                                              assertEquals(1, option.getValuesList().size());
                                                                                              assertEquals("should,not,split", option.getValue());
                                                                                          }

 @Test
                                                                                          public void testAdd_WhenCalledMultipleTimes_ShouldAddAllValues() throws Exception {
                                                                                              // Arrange
                                                                                              Option option = new Option("test", "description");
                                                                                              
                                                                                              String value1 = "value1";
                                                                                              String value2 = "value2";
                                                                                              String value3 = "value3";
                                                                                              
                                                                                              // Get the private values field using reflection
                                                                                              Field valuesField = Option.class.getDeclaredField("values");
                                                                                              valuesField.setAccessible(true);
                                                                                              
                                                                                              // Act - use reflection to call the private add method
                                                                                              Method addMethod = Option.class.getDeclaredMethod("add", String.class);
                                                                                              addMethod.setAccessible(true);
                                                                                              
                                                                                              addMethod.invoke(option, value1);
                                                                                              addMethod.invoke(option, value2);
                                                                                              addMethod.invoke(option, value3);
                                                                                              
                                                                                              // Assert
                                                                                              @SuppressWarnings("unchecked")
                                                                                              List<String> values = (List<String>) valuesField.get(option);
                                                                                              assertEquals(3, values.size());
                                                                                              assertEquals(value1, values.get(0));
                                                                                              assertEquals(value2, values.get(1));
                                                                                              assertEquals(value3, values.get(2));
                                                                                          }

 @Test
                                                                                          public void testAdd_WhenValuesListIsShared_ShouldNotAffectOtherInstances() {
                                                                                              // Arrange
                                                                                              Option option1 = new Option("a", true, "option a");
                                                                                              Option option2 = new Option("b", true, "option b");
                                                                                              
                                                                                              // Use reflection to set private values field for both options
                                                                                              try {
                                                                                                  java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                                  valuesField.setAccessible(true);
                                                                                                  valuesField.set(option1, new ArrayList<>());
                                                                                                  valuesField.set(option2, new ArrayList<>());
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                              }
                                                                                              
                                                                                              // Act - Use reflection to call private add() method
                                                                                              try {
                                                                                                  java.lang.reflect.Method addMethod = Option.class.getDeclaredMethod("add", String.class);
                                                                                                  addMethod.setAccessible(true);
                                                                                                  addMethod.invoke(option1, "option1Value");
                                                                                                  addMethod.invoke(option2, "option2Value");
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to invoke add method due to reflection error: " + e.getMessage());
                                                                                              }
                                                                                              
                                                                                              // Assert
                                                                                              try {
                                                                                                  java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                                  valuesField.setAccessible(true);
                                                                                                  assertEquals(1, ((List<?>) valuesField.get(option1)).size());
                                                                                                  assertEquals(1, ((List<?>) valuesField.get(option2)).size());
                                                                                                  assertEquals("option1Value", ((List<?>) valuesField.get(option1)).get(0));
                                                                                                  assertEquals("option2Value", ((List<?>) valuesField.get(option2)).get(0));
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to verify test due to reflection error: " + e.getMessage());
                                                                                              }
                                                                                          }

 @Test
                                                                                          public void testGetValue_WhenNoValuesExist_ShouldReturnNull1() {
                                                                                              // Setup - create option (newly created option should have no values)
                                                                                              Option option = new Option("test", "description");
                                                                                              
                                                                                              // Execute & Verify
                                                                                              assertNull(option.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_WhenSingleValueExists_ShouldReturnFirstValue() {
                                                                                              // Setup
                                                                                              Option option = new Option("test", "description");
                                                                                              String expectedValue = "testValue";
                                                                                              option.addValue(expectedValue);
                                                                                              
                                                                                              // Execute & Verify
                                                                                              assertEquals(expectedValue, option.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_WhenMultipleValuesExist_ShouldReturnFirstValue() {
                                                                                              // Setup
                                                                                              String firstValue = "first";
                                                                                              String secondValue = "second";
                                                                                              Option option = new Option("test", "description");
                                                                                              option.addValue(firstValue);
                                                                                              option.addValue(secondValue);
                                                                                              
                                                                                              // Execute & Verify
                                                                                              assertEquals(firstValue, option.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_WhenValueIsNull_ShouldReturnNull() {
                                                                                              // Setup
                                                                                              Option option = new Option("test", "description");
                                                                                              option.addValue(null);
                                                                                              
                                                                                              // Execute & Verify
                                                                                              assertNull(option.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_AfterClearingValues_ShouldReturnNull() {
                                                                                              // Setup
                                                                                              Option option = new Option("test", "description");
                                                                                              option.addValue("value"); // Using public method instead of addValueForProcessing
                                                                                              
                                                                                              try {
                                                                                                  // Use reflection to call clearValues()
                                                                                                  Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                  clearValuesMethod.setAccessible(true);
                                                                                                  clearValuesMethod.invoke(option);
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to clear values using reflection: " + e.getMessage());
                                                                                              }
                                                                                              
                                                                                              // Execute & Verify
                                                                                              assertNull(option.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_WithIndexGreaterThanSize_ShouldThrowIndexOutOfBoundsException() {
                                                                                              // Setup
                                                                                              Option option = new Option("test", "description");
                                                                                              option.addValue("value1"); // size is now 1
                                                                                              
                                                                                              // Expect exception
                                                                                              thrown.expect(IndexOutOfBoundsException.class);
                                                                                              
                                                                                              // Test
                                                                                              option.getValue(5); // size is 1, so index 5 is out of bounds
                                                                                          }

 @Test
                                                                                          public void testGetValue_WhenSingleValueSet_ShouldReturnValue() {
                                                                                              // Create an option that can accept arguments
                                                                                              Option option = new Option("test", true, "description");
                                                                                              
                                                                                              try {
                                                                                                  // Use reflection to access the private addValueForProcessing method
                                                                                                  Method method = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                                  method.setAccessible(true);
                                                                                                  // Add a single value
                                                                                                  method.invoke(option, "testValue");
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to set value using reflection: " + e.getMessage());
                                                                                              }
                                                                                              
                                                                                              assertEquals("testValue", option.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_WhenMultipleValuesSet_ShouldReturnFirstValue() {
                                                                                              // Create an Option object that can accept values
                                                                                              Option option = new Option("test", true, "description");
                                                                                              
                                                                                              // Add multiple values using public method
                                                                                              option.addValue("first");
                                                                                              option.addValue("second");
                                                                                              option.addValue("third");
                                                                                              
                                                                                              // Should return the first value
                                                                                              assertEquals("first", option.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_AfterClearValues_ShouldReturnNull() {
                                                                                              // Create an Option instance
                                                                                              Option option = new Option("t", "test option");
                                                                                              
                                                                                              // Add a value using public method
                                                                                              option.addValue("test");
                                                                                              
                                                                                              // Clear values using reflection
                                                                                              try {
                                                                                                  Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                                  clearValuesMethod.setAccessible(true);
                                                                                                  clearValuesMethod.invoke(option);
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to clear values using reflection: " + e.getMessage());
                                                                                              }
                                                                                              
                                                                                              assertNull(option.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_WhenEmptyStringValueSet_ShouldReturnEmptyString() {
                                                                                              // Empty string is a valid value
                                                                                              Option option = new Option("t", "test option");
                                                                                              option.addValue("");
                                                                                              
                                                                                              assertEquals("", option.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_WhenNullValueAdded_ShouldReturnNull() {
                                                                                              // Create an option object first
                                                                                              Option option = new Option("test", "description");
                                                                                              
                                                                                              // Explicitly adding null should return null
                                                                                              option.addValue(null);
                                                                                              
                                                                                              assertNull(option.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_WithValueSeparator_ShouldReturnFirstValue() {
                                                                                              // Create option object
                                                                                              Option option = new Option("test", "description");
                                                                                              
                                                                                              // Set value separator and add values
                                                                                              option.setValueSeparator(',');
                                                                                              option.addValue("val1,val2,val3");
                                                                                              
                                                                                              // Should return the first value before separator
                                                                                              assertEquals("val1", option.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_AfterClone_ShouldReturnSameValue() throws CloneNotSupportedException {
                                                                                              // Create option object
                                                                                              Option option = new Option("o", "description");
                                                                                              
                                                                                              // Add value and clone
                                                                                              option.addValue("original");
                                                                                              Option clonedOption = (Option) option.clone();
                                                                                              
                                                                                              assertEquals("original", clonedOption.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValue_WithDifferentValueTypes_ShouldReturnStringRepresentation() {
                                                                                              // Test with String number
                                                                                              Option option1 = new Option("test", "Test option");
                                                                                              option1.addValue("123");
                                                                                              assertEquals("123", option1.getValue());
                                                                                              
                                                                                              // Test with String boolean
                                                                                              Option option2 = new Option("test", "Test option");
                                                                                              option2.addValue("true");
                                                                                              assertEquals("true", option2.getValue());
                                                                                          }

 @Test
                                                                                          public void testGetValues_WhenSingleValueExists_ShouldReturnArrayWithOneElement() {
                                                                                              // Setup
                                                                                              Option option = new Option("test", "description");
                                                                                              option.addValue("value1");
                                                                                              
                                                                                              // Test
                                                                                              String[] result = option.getValues();
                                                                                              
                                                                                              // Verify
                                                                                              assertNotNull(result);
                                                                                              assertEquals(1, result.length);
                                                                                              assertEquals("value1", result[0]);
                                                                                          }

 @Test
                                                                                      public void testGetValues_WhenMultipleValuesExist_ShouldReturnArrayWithAllElements() {
                                                                                          // Setup
                                                                                          Option option = new Option("test", "description");
                                                                                          option.addValue("value1");
                                                                                          option.addValue("value2");
                                                                                          option.addValue("value3");
                                                                                          
                                                                                          // Test
                                                                                          String[] result = option.getValues();
                                                                                          
                                                                                          // Verify
                                                                                          assertNotNull(result);
                                                                                          assertEquals(3, result.length);
                                                                                          assertArrayEquals(new String[]{"value1", "value2", "value3"}, result);
                                                                                      }

 @Test
                                                                                      public void testGetValues_AfterClearingValues_ShouldReturnNull() {
                                                                                          // Setup
                                                                                          Option option = new Option("test", "description");
                                                                                          option.addValue("value1");
                                                                                          option.addValue("value2");
                                                                                          
                                                                                          try {
                                                                                              // Use reflection to access the clearValues() method
                                                                                              Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                              clearValuesMethod.setAccessible(true);
                                                                                              clearValuesMethod.invoke(option);
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to clear values using reflection: " + e.getMessage());
                                                                                          }
                                                                                          
                                                                                          // Test
                                                                                          String[] result = option.getValues();
                                                                                          
                                                                                          // Verify
                                                                                          assertNull(result);
                                                                                      }

 @Test
                                                                                      public void testGetValues_WhenValuesContainNull_ShouldReturnArrayIncludingNull() {
                                                                                          // Setup
                                                                                          Option option = new Option("test", "description");
                                                                                          option.addValue("value1");
                                                                                          option.addValue(null);
                                                                                          option.addValue("value3");
                                                                                          
                                                                                          // Test
                                                                                          String[] result = option.getValues();
                                                                                          
                                                                                          // Verify
                                                                                          assertNotNull(result);
                                                                                          assertEquals(3, result.length);
                                                                                          assertArrayEquals(new String[]{"value1", null, "value3"}, result);
                                                                                      }

 @Test
                                                                                      public void testGetValues_ReturnsNewArrayInstanceEachTime() {
                                                                                          // Setup
                                                                                          Option option = new Option("test", "description");
                                                                                          option.addValue("value1");
                                                                                          option.addValue("value2");
                                                                                          
                                                                                          // Test
                                                                                          String[] firstCall = option.getValues();
                                                                                          String[] secondCall = option.getValues();
                                                                                          
                                                                                          // Verify
                                                                                          assertNotSame(firstCall, secondCall);
                                                                                          assertArrayEquals(firstCall, secondCall);
                                                                                      }

 @Test
                                                                                      public void testGetValues_AfterModifyingReturnedArray_ShouldNotAffectInternalState() {
                                                                                          // Setup
                                                                                          Option option = new Option("test", "description");
                                                                                          option.addValue("value1");
                                                                                          option.addValue("value2");
                                                                                          
                                                                                          // Test
                                                                                          String[] result = option.getValues();
                                                                                          result[0] = "modified";
                                                                                          
                                                                                          // Verify original values unchanged
                                                                                          String[] newResult = option.getValues();
                                                                                          assertEquals("value1", newResult[0]);
                                                                                      }

 @Test
                                                                                      public void testGetValuesList_WhenEmptyValuesSet_ShouldReturnEmptyList() {
                                                                                          // Given
                                                                                          Option option = new Option("test", "description");
                                                                                          // Don't add any values to keep it empty
                                                                                          
                                                                                          // When
                                                                                          List<String> result = option.getValuesList();
                                                                                          
                                                                                          // Then
                                                                                          assertNotNull("Values list should not be null for new Option", result);
                                                                                          assertTrue("Values list should be empty for new Option", result.isEmpty());
                                                                                      }

 @Test
                                                                                      public void testGetValuesList_AfterClearValues_ShouldReturnNull() {
                                                                                          // Given
                                                                                          Option option = new Option("test", "description");
                                                                                          option.addValue("value1");
                                                                                          option.addValue("value2");
                                                                                          
                                                                                          try {
                                                                                              // Use reflection to access the package-private clearValues() method
                                                                                              Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                              clearValuesMethod.setAccessible(true);
                                                                                              clearValuesMethod.invoke(option);
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to invoke clearValues() method via reflection");
                                                                                          }
                                                                                          
                                                                                          // When
                                                                                          List<String> result = option.getValuesList();
                                                                                          
                                                                                          // Then
                                                                                          assertNull("Values list should be null after clearValues()", result);
                                                                                      }

 @Test
                                                                                      public void testGetValuesList_WhenValueSeparatorUsed_ShouldReturnAllSeparatedValues() {
                                                                                          // Given
                                                                                          Option option = new Option("test", "description");
                                                                                          option.setValueSeparator(',');
                                                                                          
                                                                                          // Use reflection to access the private addValueForProcessing method
                                                                                          try {
                                                                                              Method method = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                              method.setAccessible(true);
                                                                                              method.invoke(option, "value1,value2,value3");
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to invoke addValueForProcessing via reflection: " + e.getMessage());
                                                                                          }
                                                                                          
                                                                                          // When
                                                                                          List<String> result = option.getValuesList();
                                                                                          
                                                                                          // Then
                                                                                          assertNotNull("Values list should not be null after processing separated values", result);
                                                                                          assertEquals("Should contain all separated values", 3, result.size());
                                                                                          assertEquals("First value should be correct", "value1", result.get(0));
                                                                                          assertEquals("Second value should be correct", "value2", result.get(1));
                                                                                          assertEquals("Third value should be correct", "value3", result.get(2));
                                                                                      }

 @Test
                                                                                      public void testHasNoValues_WhenValuesIsNull() {
                                                                                          // Create an Option object to test
                                                                                          Option option = new Option("test", "description");
                                                                                          
                                                                                          // Using reflection to set values to null since it's private
                                                                                          try {
                                                                                              // Set values field to null
                                                                                              java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                              valuesField.setAccessible(true);
                                                                                              valuesField.set(option, null);
                                                                                              
                                                                                              // Get and invoke the private hasNoValues method
                                                                                              java.lang.reflect.Method hasNoValuesMethod = Option.class.getDeclaredMethod("hasNoValues");
                                                                                              hasNoValuesMethod.setAccessible(true);
                                                                                              boolean result = (boolean) hasNoValuesMethod.invoke(option);
                                                                                              
                                                                                              assertTrue(result);
                                                                                          } catch (Exception e) {
                                                                                              fail("Reflection failed: " + e.getMessage());
                                                                                          }
                                                                                      }

 @Test
                                                                                      public void testHasNoValues_WhenValuesIsEmpty() {
                                                                                          // Create an Option object
                                                                                          org.apache.commons.cli.Option option = new org.apache.commons.cli.Option("test", "description");
                                                                                          
                                                                                          // Using reflection to set empty list since values is private
                                                                                          try {
                                                                                              java.lang.reflect.Field valuesField = org.apache.commons.cli.Option.class.getDeclaredField("values");
                                                                                              valuesField.setAccessible(true);
                                                                                              valuesField.set(option, new ArrayList<>());
                                                                                              
                                                                                              // Using reflection to access private hasNoValues method
                                                                                              java.lang.reflect.Method hasNoValuesMethod = org.apache.commons.cli.Option.class.getDeclaredMethod("hasNoValues");
                                                                                              hasNoValuesMethod.setAccessible(true);
                                                                                              boolean result = (boolean) hasNoValuesMethod.invoke(option);
                                                                                              
                                                                                              assertTrue(result);
                                                                                          } catch (Exception e) {
                                                                                              fail("Reflection failed: " + e.getMessage());
                                                                                          }
                                                                                      }

 @Test
                                                                                      public void testHasNoValues_WhenValuesHasOneElement() {
                                                                                          // Create an Option object
                                                                                          Option option = new Option("test", "description");
                                                                                          
                                                                                          // Using reflection to set values with one element and test hasNoValues()
                                                                                          try {
                                                                                              // Set the private values field
                                                                                              java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                              valuesField.setAccessible(true);
                                                                                              valuesField.set(option, java.util.Arrays.asList("value1"));
                                                                                              
                                                                                              // Get the private hasNoValues method
                                                                                              java.lang.reflect.Method hasNoValuesMethod = Option.class.getDeclaredMethod("hasNoValues");
                                                                                              hasNoValuesMethod.setAccessible(true);
                                                                                              
                                                                                              // Invoke the method and assert
                                                                                              boolean result = (boolean) hasNoValuesMethod.invoke(option);
                                                                                              assertFalse(result);
                                                                                          } catch (Exception e) {
                                                                                              fail("Reflection failed: " + e.getMessage());
                                                                                          }
                                                                                      }

 @Test
                                                                                      public void testHasNoValues_WhenValuesHasMultipleElements() {
                                                                                          // Create an Option object
                                                                                          org.apache.commons.cli.Option option = new org.apache.commons.cli.Option("test", "description");
                                                                                          
                                                                                          // Using reflection to set values with multiple elements
                                                                                          try {
                                                                                              java.lang.reflect.Field valuesField = org.apache.commons.cli.Option.class.getDeclaredField("values");
                                                                                              valuesField.setAccessible(true);
                                                                                              valuesField.set(option, java.util.Arrays.asList("value1", "value2", "value3"));
                                                                                              
                                                                                              // Using reflection to access private hasNoValues method
                                                                                              java.lang.reflect.Method hasNoValuesMethod = org.apache.commons.cli.Option.class.getDeclaredMethod("hasNoValues");
                                                                                              hasNoValuesMethod.setAccessible(true);
                                                                                              boolean result = (boolean) hasNoValuesMethod.invoke(option);
                                                                                              
                                                                                              assertFalse(result);
                                                                                          } catch (Exception e) {
                                                                                              fail("Reflection failed: " + e.getMessage());
                                                                                          }
                                                                                      }

 @Test
                                                                                      public void testHasNoValues_AfterClearingValues() {
                                                                                          // Create an Option object
                                                                                          Option option = new Option("test", "description");
                                                                                          
                                                                                          // First add some values
                                                                                          try {
                                                                                              // Get and set values field
                                                                                              java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                              valuesField.setAccessible(true);
                                                                                              valuesField.set(option, new java.util.ArrayList<>(java.util.Arrays.asList("value1", "value2")));
                                                                                              
                                                                                              // Clear values using reflection
                                                                                              java.lang.reflect.Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                              clearValuesMethod.setAccessible(true);
                                                                                              clearValuesMethod.invoke(option);
                                                                                              
                                                                                              // Verify no values remain by checking the values field directly
                                                                                              @SuppressWarnings("unchecked")
                                                                                              java.util.List<String> values = (java.util.List<String>) valuesField.get(option);
                                                                                              assertTrue(values.isEmpty());
                                                                                          } catch (Exception e) {
                                                                                              fail("Reflection failed: " + e.getMessage());
                                                                                          }
                                                                                      }

 @Test
                                                                                      public void testHasNoValues_AfterAddingAndRemovingValues() {
                                                                                          // Test the behavior when values are added and then removed
                                                                                          Option option = new Option("test", "description");
                                                                                          try {
                                                                                              // Get the private values field
                                                                                              java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                              valuesField.setAccessible(true);
                                                                                              List<String> values = new ArrayList<>();
                                                                                              valuesField.set(option, values);
                                                                                              
                                                                                              // Get the private hasNoValues method
                                                                                              java.lang.reflect.Method hasNoValuesMethod = Option.class.getDeclaredMethod("hasNoValues");
                                                                                              hasNoValuesMethod.setAccessible(true);
                                                                                              
                                                                                              // Initially empty
                                                                                              assertTrue((boolean) hasNoValuesMethod.invoke(option));
                                                                                              
                                                                                              // Add a value
                                                                                              values.add("test");
                                                                                              assertFalse((boolean) hasNoValuesMethod.invoke(option));
                                                                                              
                                                                                              // Remove the value
                                                                                              values.clear();
                                                                                              assertTrue((boolean) hasNoValuesMethod.invoke(option));
                                                                                          } catch (Exception e) {
                                                                                              fail("Reflection failed: " + e.getMessage());
                                                                                          }
                                                                                      }

 @Test
                                                                                      public void testClone_CreatesDeepCopy() throws Exception {
                                                                                          // Setup original object with values
                                                                                          Option original = new Option("t", "test", true, "description");
                                                                                          original.setRequired(true);
                                                                                          original.setOptionalArg(false);
                                                                                          original.setArgs(2);
                                                                                          original.setValueSeparator(',');
                                                                                          // Use public method to add values
                                                                                          original.addValue("val1");
                                                                                          original.addValue("val2");
                                                                                          
                                                                                          // Clone the object
                                                                                          Option cloned = (Option) original.clone();
                                                                                          
                                                                                          // Verify all fields are copied
                                                                                          assertEquals(original.getOpt(), cloned.getOpt());
                                                                                          assertEquals(original.getLongOpt(), cloned.getLongOpt());
                                                                                          assertEquals(original.getDescription(), cloned.getDescription());
                                                                                          assertEquals(original.isRequired(), cloned.isRequired());
                                                                                          assertEquals(original.hasOptionalArg(), cloned.hasOptionalArg());
                                                                                          assertEquals(original.getArgs(), cloned.getArgs());
                                                                                          assertEquals(original.getValueSeparator(), cloned.getValueSeparator());
                                                                                          
                                                                                          // Verify values list is deep copied (not same reference)
                                                                                          assertNotSame(original.getValuesList(), cloned.getValuesList());
                                                                                          assertEquals(original.getValuesList(), cloned.getValuesList());
                                                                                          
                                                                                          // Modify original's values and verify clone is unaffected
                                                                                          original.addValue("val3");
                                                                                          assertFalse(cloned.getValuesList().contains("val3"));
                                                                                      }

 @Test
                                                                                      public void testClone_WithEmptyValues() throws Exception {
                                                                                          Option original = new Option("f", "file", true, "file option");
                                                                                          // Clear values using public API by getting the list and verifying it's empty
                                                                                          // Since we can't call clearValues() directly, we'll verify the list is empty
                                                                                          // after construction (assuming new Option starts with empty values)
                                                                                          
                                                                                          Option cloned = (Option) original.clone();
                                                                                          
                                                                                          assertTrue(cloned.getValuesList().isEmpty());
                                                                                          // Use reflection to verify the lists are different instances
                                                                                          Field valuesField = Option.class.getDeclaredField("values");
                                                                                          valuesField.setAccessible(true);
                                                                                          List<?> originalValues = (List<?>) valuesField.get(original);
                                                                                          List<?> clonedValues = (List<?>) valuesField.get(cloned);
                                                                                          assertNotSame(originalValues, clonedValues);
                                                                                      }

 @Test
                                                                                      public void testClearValues_WhenListIsEmpty() throws Exception {
                                                                                          // Given - create an option with empty values list
                                                                                          Option option = new Option("test", "description");
                                                                                          assertTrue(option.getValuesList().isEmpty());
                                                                                          
                                                                                          // When - use reflection to access the clearValues method
                                                                                          Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                          clearValuesMethod.setAccessible(true);
                                                                                          clearValuesMethod.invoke(option);
                                                                                          
                                                                                          // Then
                                                                                          assertTrue(option.getValuesList().isEmpty());
                                                                                      }

 @Test
                                                                                      public void testClearValues_WhenListHasSingleValue() {
                                                                                          // Given
                                                                                          Option option = new Option("test", "description");
                                                                                          option.addValue("value1");
                                                                                          assertEquals(1, option.getValuesList().size());
                                                                                          
                                                                                          // When
                                                                                          try {
                                                                                              Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                              clearValuesMethod.setAccessible(true);
                                                                                              clearValuesMethod.invoke(option);
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to invoke clearValues method via reflection: " + e.getMessage());
                                                                                          }
                                                                                          
                                                                                          // Then
                                                                                          assertTrue(option.getValuesList().isEmpty());
                                                                                      }

 @Test
                                                                                      public void testClearValues_WhenListHasMultipleValues() {
                                                                                          // Given
                                                                                          Option option = new Option("test", "description");
                                                                                          option.addValue("value1");
                                                                                          option.addValue("value2");
                                                                                          option.addValue("value3");
                                                                                          assertEquals(3, option.getValuesList().size());
                                                                                          
                                                                                          // When
                                                                                          try {
                                                                                              Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                              clearValuesMethod.setAccessible(true);
                                                                                              clearValuesMethod.invoke(option);
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to invoke clearValues method: " + e.getMessage());
                                                                                          }
                                                                                          
                                                                                          // Then
                                                                                          assertTrue(option.getValuesList().isEmpty());
                                                                                      }

 @Test
                                                                                      public void testClearValues_VerifyOtherFieldsNotAffected() throws Exception {
                                                                                          // Given
                                                                                          Option option = new Option("testOpt", "test description");
                                                                                          option.setLongOpt("testLongOpt");
                                                                                          option.setRequired(true);
                                                                                          option.addValue("value1");
                                                                                          
                                                                                          String originalOpt = option.getOpt();
                                                                                          String originalLongOpt = option.getLongOpt();
                                                                                          String originalDescription = option.getDescription();
                                                                                          boolean originalRequired = option.isRequired();
                                                                                          
                                                                                          // When - Use reflection to access package-private clearValues method
                                                                                          Method clearValuesMethod = Option.class.getDeclaredMethod("clearValues");
                                                                                          clearValuesMethod.setAccessible(true);
                                                                                          clearValuesMethod.invoke(option);
                                                                                          
                                                                                          // Then
                                                                                          assertEquals(originalOpt, option.getOpt());
                                                                                          assertEquals(originalLongOpt, option.getLongOpt());
                                                                                          assertEquals(originalDescription, option.getDescription());
                                                                                          assertEquals(originalRequired, option.isRequired());
                                                                                      }

 @Test
                                                                                      public void testClearValues_AfterMultipleOperations() throws Exception {
                                                                                          // Given
                                                                                          Option option = new Option("test", "description");
                                                                                          option.addValue("value1");
                                                                                          
                                                                                          // Use reflection to access clearValues()
                                                                                          Method clearValues = Option.class.getDeclaredMethod("clearValues");
                                                                                          clearValues.setAccessible(true);
                                                                                          clearValues.invoke(option);
                                                                                          
                                                                                          option.addValue("value2");
                                                                                          option.addValue("value3");
                                                                                          assertEquals(2, option.getValuesList().size());
                                                                                          
                                                                                          // When
                                                                                          clearValues.invoke(option);
                                                                                          
                                                                                          // Then
                                                                                          assertTrue(option.getValuesList().isEmpty());
                                                                                          
                                                                                          // Additional operation
                                                                                          option.addValue("value4");
                                                                                          assertEquals(1, option.getValuesList().size());
                                                                                          clearValues.invoke(option);
                                                                                          assertTrue(option.getValuesList().isEmpty());
                                                                                      }

 @Test
                                                                                      public void testAcceptsArg_WhenNoArgConfigurations() throws Exception {
                                                                                          // Case: No argument configurations (hasArg=false, hasArgs=false, hasOptionalArg=false)
                                                                                          Option option = new Option("t", "test option");
                                                                                          option.setArgs(0);
                                                                                          option.setOptionalArg(false);
                                                                                          
                                                                                          // Use reflection to access private acceptsArg() method
                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                          
                                                                                          assertFalse(result);
                                                                                      }

 @Test
                                                                                      public void testAcceptsArg_WhenHasArgsTrue() throws Exception {
                                                                                          // Case: hasArgs is true (numberOfArgs > 1)
                                                                                          Option option = new Option("test", "description");
                                                                                          option.setArgs(2);
                                                                                          
                                                                                          // Use reflection to access the package-private acceptsArg() method
                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                          
                                                                                          assertTrue(result);
                                                                                      }

 @Test
                                                                                      public void testAcceptsArg_WhenHasOptionalArgTrue() throws Exception {
                                                                                          // Case: hasOptionalArg is true
                                                                                          Option option = new Option("test", "description");
                                                                                          option.setOptionalArg(true);
                                                                                          
                                                                                          // Use reflection to access the package-private acceptsArg() method
                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                          
                                                                                          assertTrue(result);
                                                                                      }

 @Test
                                                                                      public void testAcceptsArg_WhenNumberOfArgsExceedsValuesSize() throws Exception {
                                                                                          // Case: numberOfArgs > 0 and values.size() < numberOfArgs
                                                                                          Option option = new Option("test", "description");
                                                                                          option.setArgs(2);
                                                                                          
                                                                                          // Use reflection to call addValueForProcessing
                                                                                          Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                          addValueMethod.setAccessible(true);
                                                                                          addValueMethod.invoke(option, "value1");
                                                                                          
                                                                                          // Use reflection to call acceptsArg
                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                          
                                                                                          assertTrue(result);
                                                                                      }

 @Test
                                                                                      public void testAcceptsArg_WhenNumberOfArgsEqualsValuesSize() {
                                                                                          // Case: numberOfArgs > 0 and values.size() == numberOfArgs
                                                                                          Option option = new Option("test", "description");
                                                                                          option.setArgs(1);
                                                                                          
                                                                                          try {
                                                                                              // Use reflection to access addValueForProcessing
                                                                                              Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                              addValueMethod.setAccessible(true);
                                                                                              addValueMethod.invoke(option, "value1");
                                                                                              
                                                                                              // Use reflection to access acceptsArg
                                                                                              Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                              acceptsArgMethod.setAccessible(true);
                                                                                              boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                              
                                                                                              assertFalse(result);
                                                                                          } catch (Exception e) {
                                                                                              fail("Reflection failed: " + e.getMessage());
                                                                                          }
                                                                                      }

 @Test
                                                                                      public void testAcceptsArg_WhenUnlimitedValues() throws Exception {
                                                                                          // Case: numberOfArgs is UNLIMITED_VALUES
                                                                                          Option option = new Option("test", "description");
                                                                                          option.setArgs(Option.UNLIMITED_VALUES);
                                                                                          
                                                                                          // Use public method to add values
                                                                                          option.addValue("value1");
                                                                                          option.addValue("value2");
                                                                                          
                                                                                          // Use reflection to test acceptsArg()
                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                          
                                                                                          assertTrue(result);
                                                                                      }

 @Test
                                                                                      public void testAcceptsArg_WhenNoValuesButOptionalArg() throws Exception {
                                                                                          // Case: optionalArg is true and no values
                                                                                          Option option = new Option("t", "test option");
                                                                                          option.setOptionalArg(true);
                                                                                          option.setArgs(1);
                                                                                          
                                                                                          // Use reflection to access the package-private acceptsArg() method
                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                          
                                                                                          assertTrue(result);
                                                                                      }

 @Test
                                                                                      public void testAcceptsArg_WhenValuesSizeExceedsNumberOfArgs() throws Exception {
                                                                                          // Case: values.size() > numberOfArgs (shouldn't normally happen)
                                                                                          Option option = new Option("test", true, "description");
                                                                                          option.setArgs(1);
                                                                                          
                                                                                          // Use reflection to access private addValueForProcessing method
                                                                                          Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                          addValueMethod.setAccessible(true);
                                                                                          addValueMethod.invoke(option, "value1");
                                                                                          addValueMethod.invoke(option, "value2");
                                                                                          
                                                                                          // Use reflection to access private acceptsArg method
                                                                                          Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                          acceptsArgMethod.setAccessible(true);
                                                                                          boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                          
                                                                                          assertFalse(result);
                                                                                      }

 @Test
                                                                                      public void testAcceptsArg_WhenNumberOfArgsIsZero() {
                                                                                          // Case: numberOfArgs is 0 (should behave same as no arg)
                                                                                          Option option = new Option("t", "test option");
                                                                                          option.setArgs(0);
                                                                                          
                                                                                          try {
                                                                                              Method acceptsArgMethod = Option.class.getDeclaredMethod("acceptsArg");
                                                                                              acceptsArgMethod.setAccessible(true);
                                                                                              boolean result = (boolean) acceptsArgMethod.invoke(option);
                                                                                              assertFalse(result);
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to invoke acceptsArg method via reflection: " + e.getMessage());
                                                                                          }
                                                                                      }

 @Test
                                                                                      public void testAcceptsArg_AfterClearingValues() {
                                                                                          // Case: After clearing values, should accept args again
                                                                                          Option option = new Option("t", "test option");
                                                                                          option.setArgs(1);
                                                                                          option.addValue("value");
                                                                                          // Verify value was added
                                                                                          assertNotNull(option.getValue());
                                                                                          // Clear values by adding null (simulating clear)
                                                                                          option.addValue(null);
                                                                                          // Verify values were cleared
                                                                                          assertNull(option.getValue());
                                                                                          // Verify option can still accept args
                                                                                          assertTrue(option.hasArgs() || option.getArgs() > 0);
                                                                                      }

 @Test
                                                                                      public void testRequiresArg_WhenOptionalArgIsTrue_ReturnsFalse() throws Exception {
                                                                                          Option option = new Option("t", "test option");
                                                                                          option.setOptionalArg(true);
                                                                                          
                                                                                          // Use reflection to access the private requiresArg() method
                                                                                          Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                          requiresArgMethod.setAccessible(true);
                                                                                          boolean result = (boolean) requiresArgMethod.invoke(option);
                                                                                          
                                                                                          assertFalse(result);
                                                                                      }

 @Test
                                                                                      public void testRequiresArg_WhenNumberOfArgsIsUnlimitedAndNoValues_ReturnsTrue() {
                                                                                          Option option = new Option("test", "description");
                                                                                          try {
                                                                                              // Set numberOfArgs to UNLIMITED_VALUES using reflection
                                                                                              java.lang.reflect.Field numberOfArgsField = Option.class.getDeclaredField("numberOfArgs");
                                                                                              numberOfArgsField.setAccessible(true);
                                                                                              numberOfArgsField.set(option, Option.UNLIMITED_VALUES);
                                                                                              
                                                                                              // Access requiresArg() method using reflection
                                                                                              java.lang.reflect.Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                              requiresArgMethod.setAccessible(true);
                                                                                              boolean result = (boolean) requiresArgMethod.invoke(option);
                                                                                              
                                                                                              assertTrue(result);
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to test requiresArg due to reflection error: " + e.getMessage());
                                                                                          }
                                                                                      }

 @Test
                                                                                      public void testRequiresArg_WhenNumberOfArgsIsUnlimitedAndHasValues_ReturnsFalse() {
                                                                                          Option option = new Option("test", "description");
                                                                                          List<String> values = new ArrayList<>();
                                                                                          
                                                                                          try {
                                                                                              // Set numberOfArgs to UNLIMITED_VALUES using reflection
                                                                                              java.lang.reflect.Field numberOfArgsField = Option.class.getDeclaredField("numberOfArgs");
                                                                                              numberOfArgsField.setAccessible(true);
                                                                                              numberOfArgsField.set(option, Option.UNLIMITED_VALUES);
                                                                                              
                                                                                              // Add values and set them using reflection
                                                                                              values.add("value1");
                                                                                              java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                              valuesField.setAccessible(true);
                                                                                              valuesField.set(option, values);
                                                                                              
                                                                                              // Use reflection to call requiresArg()
                                                                                              java.lang.reflect.Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                              requiresArgMethod.setAccessible(true);
                                                                                              boolean result = (boolean) requiresArgMethod.invoke(option);
                                                                                              
                                                                                              assertFalse(result);
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to set test values or call method due to reflection error");
                                                                                          }
                                                                                      }

 @Test
                                                                                      public void testRequiresArg_WhenNumberOfArgsIsOneAndNoValues_ReturnsTrue() throws Exception {
                                                                                          Option option = new Option("t", "test option");
                                                                                          option.setArgs(1);
                                                                                          
                                                                                          // Use reflection to access private requiresArg() method
                                                                                          Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                          requiresArgMethod.setAccessible(true);
                                                                                          boolean result = (boolean) requiresArgMethod.invoke(option);
                                                                                          
                                                                                          assertTrue(result);
                                                                                      }

 @Test
                                                                                      public void testRequiresArg_WhenNumberOfArgsIsOneAndHasValue_ReturnsFalse() {
                                                                                          Option option = new Option("test", "description");
                                                                                          List<String> values = new ArrayList<>();
                                                                                          
                                                                                          option.setArgs(1);
                                                                                          values.add("value1");
                                                                                          
                                                                                          try {
                                                                                              java.lang.reflect.Field valuesField = Option.class.getDeclaredField("values");
                                                                                              valuesField.setAccessible(true);
                                                                                              valuesField.set(option, values);
                                                                                              
                                                                                              java.lang.reflect.Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                              requiresArgMethod.setAccessible(true);
                                                                                              boolean result = (boolean) requiresArgMethod.invoke(option);
                                                                                              
                                                                                              assertFalse(result);
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to test requiresArg due to reflection error: " + e.getMessage());
                                                                                          }
                                                                                      }

 @Test
                                                                                      public void testRequiresArg_WhenNumberOfArgsIsZero_ReturnsFalse() throws Exception {
                                                                                          Option option = new Option("t", "test option");
                                                                                          option.setArgs(0);
                                                                                          
                                                                                          // Use reflection to access the private requiresArg() method
                                                                                          Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                          requiresArgMethod.setAccessible(true);
                                                                                          boolean result = (boolean) requiresArgMethod.invoke(option);
                                                                                          
                                                                                          assertFalse(result);
                                                                                      }

 @Test
                                                                                      public void testRequiresArg_WhenNumberOfArgsIsNegative_ReturnsFalse() throws Exception {
                                                                                          Option option = new Option("test", "description");
                                                                                          option.setArgs(-1);
                                                                                          
                                                                                          // Use reflection to access the private method
                                                                                          Method requiresArgMethod = Option.class.getDeclaredMethod("requiresArg");
                                                                                          requiresArgMethod.setAccessible(true);
                                                                                          boolean result = (boolean) requiresArgMethod.invoke(option);
                                                                                          
                                                                                          assertFalse(result);
                                                                                      }

 @Test
                                                                                  public void testGetValuesList_WhenMultipleValuesAdded_ShouldReturnAllValuesInOrder() {
                                                                                      // Given
                                                                                      org.apache.commons.cli.Option option = new org.apache.commons.cli.Option("test", "description");
                                                                                      java.util.List<String> testValues = java.util.Arrays.asList("value1", "value2", "value3");
                                                                                      for (String value : testValues) {
                                                                                          option.addValue(value);
                                                                                      }
                                                                                      
                                                                                      // When
                                                                                      java.util.List<String> result = option.getValuesList();
                                                                                      
                                                                                      // Then
                                                                                      assertNotNull("Values list should not be null after adding values", result);
                                                                                      assertEquals("Values list should contain all added values", testValues.size(), result.size());
                                                                                      assertEquals("Values should be in the same order as added", testValues, result);
                                                                                  }

 @Test
                                                                                  public void testClone_ThrowsRuntimeExceptionOnCloneFailure() {
                                                                                      // Create a mock Option that throws CloneNotSupportedException
                                                                                      Option failingOption = new Option("x", "fail", false, "failing option") {
                                                                                          @Override
                                                                                          public Object clone() {
                                                                                              throw new RuntimeException(new CloneNotSupportedException("Test exception"));
                                                                                          }
                                                                                      };
                                                                                      
                                                                                      ExpectedException exceptionRule = ExpectedException.none();
                                                                                      exceptionRule.expect(RuntimeException.class);
                                                                                      exceptionRule.expectMessage("A CloneNotSupportedException was thrown: Test exception");
                                                                                      
                                                                                      failingOption.clone();
                                                                                  }

 @Test
                                                                                  public void testGetId_WithNullOpt() throws Exception {
                                                                                      // This case shouldn't happen due to validation in constructor
                                                                                      // but we'll test it anyway for robustness
                                                                                      Option option = mock(Option.class);
                                                                                      
                                                                                      // Set up expected exception
                                                                                      ExpectedException expectedException = ExpectedException.none();
                                                                                      expectedException.expect(NullPointerException.class);
                                                                                      
                                                                                      // Use reflection to access the private getKey() method
                                                                                      Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                                      getKeyMethod.setAccessible(true);
                                                                                      
                                                                                      // Mock the behavior to return null when getKey() is called
                                                                                      when(getKeyMethod.invoke(option)).thenReturn(null);
                                                                                      
                                                                                      // Make getId() call the real method
                                                                                      when(option.getId()).thenCallRealMethod();
                                                                                      
                                                                                      option.getId();
                                                                                  }

 @Test
                                                                              public void testAddValueForProcessing_WhenInitialized_ShouldCallProcessValue() throws Exception {
                                                                                  // Arrange
                                                                                  Option option = new Option("t", true, "test option");
                                                                                  String testValue = "testValue";
                                                                                  
                                                                                  // Use reflection to access private processValue method for verification
                                                                                  Method processValueMethod = Option.class.getDeclaredMethod("processValue", String.class);
                                                                                  processValueMethod.setAccessible(true);
                                                                                  
                                                                                  // Spy on the option to verify value processing
                                                                                  Option spyOption = spy(option);
                                                                                  
                                                                                  // Act
                                                                                  // Use reflection to access package-private addValueForProcessing method
                                                                                  Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                                                                  addValueMethod.setAccessible(true);
                                                                                  addValueMethod.invoke(spyOption, testValue);
                                                                                  
                                                                                  // Assert
                                                                                  // Verify the value was processed by checking the result
                                                                                  assertNotNull(spyOption.getValue());
                                                                                  assertEquals(testValue, spyOption.getValue());
                                                                              }

 @Test
                                      public void testAddValueForProcessing_WithNullValue_ShouldCallProcessValueWithNull() throws Exception {
                                          // Arrange
                                          Option option = new Option("t", true, "test option");
                                          
                                          // Use reflection to access private values field to verify the result
                                          Field valuesField = Option.class.getDeclaredField("values");
                                          valuesField.setAccessible(true);
                                          
                                          // Create a spy to verify the method call
                                          Option testOption = new Option("t", true, "test option");
                                          Option spyOption = spy(testOption);
                                          
                                          // Act - call the package-private method via reflection
                                          Method addValueMethod = Option.class.getDeclaredMethod("addValueForProcessing", String.class);
                                          addValueMethod.setAccessible(true);
                                          addValueMethod.invoke(spyOption, (String)null);
                                          
                                          // Assert - verify the value was added to internal processing
                                          List<String> values = (List<String>) valuesField.get(spyOption);
                                          assertEquals(1, values.size());
                                          assertNull(values.get(0));
                                      }

 @Test
                                      public void testConstructorWithNullOptShouldThrowIllegalArgumentException() {
                                          // Expect IllegalArgumentException for null opt parameter
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("opt cannot be null");
                                          
                                          // Test with null opt and valid description
                                          new Option(null, "description");
                                      }

 @Test
                                      public void testConstructorWithNullDescriptionShouldNotThrowException() {
                                          // Description can be null in original implementation
                                          // This test ensures the mutant doesn't throw NullPointerException for null description
                                          Option option = new Option("opt", null);
                                          
                                          // Verify the description was set to null
                                          assertEquals(null, option.getDescription());
                                      }

 @Test
                                      public void testConstructorWithNullOptThrowsIllegalArgumentException() {
                                          // Arrange
                                          String nullOpt = null;
                                          String description = "description";
                                          
                                          // Expect
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("opt cannot be null");
                                          
                                          // Act
                                          new Option(nullOpt, description);
                                      }

 @Test
                                      public void testConstructorWithNullDescriptionThrowsIllegalArgumentException() {
                                          // Arrange
                                          String opt = "o";
                                          String nullDescription = null;
                                          
                                          // Expect
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("description cannot be null");
                                          
                                          // Act
                                          new Option(opt, nullDescription);
                                      }

 @Test
                                      public void testConstructorWithNullArgumentsThrowsIllegalArgumentException() {
                                          // Arrange
                                          String nullOpt = null;
                                          String nullDescription = null;
                                          
                                          // Expect
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("opt and description cannot be null");
                                          
                                          // Act
                                          new Option(nullOpt, nullDescription);
                                      }

 @Test
                                      public void testConstructorWithNullOptShouldThrowIllegalArgumentException1() {
                                          // Arrange
                                          String nullOpt = null;
                                          String description = "description";
                                          
                                          // Expect
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("opt");
                                          
                                          // Act
                                          new Option(nullOpt, description);
                                      }

 @Test
                                      public void testConstructorWithNullDescriptionShouldThrowIllegalArgumentException() {
                                          // Arrange
                                          String opt = "o";
                                          String nullDescription = null;
                                          
                                          // Expect
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("description");
                                          
                                          // Act
                                          new Option(opt, nullDescription);
                                      }

 @Test
                                     public void testConstructorWithInvalidOptShouldThrowException() {
                                         // The mutation removed the throws declaration but the behavior should still throw
                                         // We expect the exception to be thrown even though it's not declared
                                         thrown.expect(IllegalArgumentException.class);
                                         
                                         // Test with invalid option string that should trigger exception
                                         // For command-line options, empty string or null is typically invalid
                                         new Option(null, "description");
                                     }

 @Test
                                     public void testConstructorWithEmptyOptShouldThrowException() {
                                         thrown.expect(IllegalArgumentException.class);
                                         new Option("", "description");
                                     }

 @Test
                                     public void testConstructorWithValidOptShouldNotThrowException() {
                                         // Valid case should work normally
                                         Option option = new Option("v", "verbose");
                                         
                                         // Verify the object was properly initialized
                                         assertEquals("v", option.getOpt());
                                         assertEquals("verbose", option.getDescription());
                                         assertFalse(option.isRequired());
                                         assertNull(option.getLongOpt());
                                     }

 @Test
                                     public void testConstructorWithNullOptShouldThrowException() {
                                         thrown.expect(IllegalArgumentException.class);
                                         thrown.expectMessage("opt cannot be null");
                                         new Option(null, "description");
                                     }

 @Test
                                     public void testConstructorWithEmptyOptShouldThrowException1() {
                                         thrown.expect(IllegalArgumentException.class);
                                         thrown.expectMessage("opt cannot be empty");
                                         new Option("", "description");
                                     }

 @Test
                                     public void testConstructorWithInvalidSingleCharOptShouldThrowException() {
                                         thrown.expect(IllegalArgumentException.class);
                                         thrown.expectMessage("opt contains illegal characters");
                                         new Option("?", "description");
                                     }

 @Test
                                     public void testConstructorWithInvalidOptionShouldThrowException() {
                                         // Arrange
                                         String invalidOpt = "@"; // Invalid option character
                                         String description = "test description";
                                         
                                         // Expect
                                         thrown.expect(IllegalArgumentException.class);
                                         
                                         // Act
                                         new Option(invalidOpt, description);
                                     }

 @Test
                                     public void testConstructorWithNullOptionShouldThrowException() {
                                         // Arrange
                                         String nullOpt = null;
                                         String description = "test description";
                                         
                                         // Expect
                                         thrown.expect(IllegalArgumentException.class);
                                         
                                         // Act
                                         new Option(nullOpt, description);
                                     }

 @Test
                                     public void testConstructorWithEmptyOptionShouldThrowException() {
                                         // Arrange
                                         String emptyOpt = "";
                                         String description = "test description";
                                         
                                         // Expect
                                         thrown.expect(IllegalArgumentException.class);
                                         
                                         // Act
                                         new Option(emptyOpt, description);
                                     }

 @Test
                                public void testConstructorWithNullLongOptShouldNotHaveLongOpt() {
                                    // Arrange
                                    String opt = "testOpt";
                                    String description = "test description";
                                    
                                    // Act - This would use the original constructor with null longOpt
                                    Option option = new Option(opt, null, false, description);
                                    
                                    // Assert
                                    assertFalse("Option with null longOpt should not have long option", 
                                               option.hasLongOpt());
                                    assertNull("Long option should be null", option.getLongOpt());
                                }

 @Test
                                public void testConstructorWithEmptyLongOptShouldHaveLongOpt() {
                                    // Arrange
                                    String opt = "testOpt";
                                    String description = "test description";
                                    
                                    // Act - This would use the mutated constructor with empty string longOpt
                                    Option option = new Option(opt, "", false, description);
                                    
                                    // Assert
                                    assertTrue("Option with empty string longOpt should have long option", 
                                              option.hasLongOpt());
                                    assertEquals("Long option should be empty string", 
                                                "", option.getLongOpt());
                                }

 @Test
                                    public void testConstructorWithNullLongOpt() {
                                        // Setup test data
                                        String opt = "t";
                                        boolean hasArg = false;
                                        String description = "test option";
                                        
                                        // Create option with original constructor (null longOpt)
                                        Option option = new Option(opt, null, hasArg, description);
                                        
                                        // Verify longOpt is null (original behavior)
                                        assertNull("Long option should be null", option.getLongOpt());
                                        
                                        // Verify hasLongOpt returns false
                                        assertFalse("Should not have long option", option.hasLongOpt());
                                        
                                        // Verify toString doesn't contain long option
                                        String str = option.toString();
                                        assertFalse("String representation shouldn't contain long option", 
                                                   str.contains("--") || str.contains("long"));
                                    }

 @Test
                                    public void testConstructorWithEmptyStringLongOpt() {
                                        // Setup test data
                                        String opt = "t";
                                        boolean hasArg = false;
                                        String description = "test option";
                                        
                                        // Create option with mutated constructor ("" longOpt)
                                        Option option = new Option(opt, "", hasArg, description);
                                        
                                        // Verify longOpt is empty string (mutated behavior)
                                        assertEquals("Long option should be empty string", "", option.getLongOpt());
                                        
                                        // Verify hasLongOpt returns false (same as original)
                                        assertFalse("Should not have long option", option.hasLongOpt());
                                        
                                        // Verify toString doesn't contain long option
                                        String str = option.toString();
                                        assertFalse("String representation shouldn't contain long option", 
                                                   str.contains("--") || str.contains("long"));
                                    }

 @Test
                                public void testConstructorLongOptNullVsEmptyString() {
                                    // Test with original behavior (longOpt = null)
                                    Option optionWithNull = new Option("a", null, false, "description");
                                    assertFalse("Option with null longOpt should return false for hasLongOpt", 
                                               optionWithNull.hasLongOpt());
                                    
                                    // Test with mutated behavior (longOpt = "")
                                    // This would catch the mutant where null is replaced with ""
                                    Option optionWithEmpty = new Option("a", "", false, "description");
                                    assertTrue("Option with empty string longOpt should return true for hasLongOpt", 
                                              optionWithEmpty.hasLongOpt());
                                    
                                    // Additional assertions to ensure other fields are set correctly
                                    assertEquals("a", optionWithEmpty.getOpt());
                                    assertEquals("", optionWithEmpty.getLongOpt());
                                    assertEquals("description", optionWithEmpty.getDescription());
                                    assertEquals(0, optionWithEmpty.getArgs()); // since hasArg is false
                                }

 @Test
                               public void testConstructorWithNullLongOpt1() {
                                   // Arrange
                                   String opt = "testOpt";
                                   String description = "test description";
                                   
                                   // Act - This would be the original constructor call
                                   Option option = new Option(opt, null, false, description);
                                   
                                   // Assert - Verify behavior with null longOpt
                                   assertFalse("Option should not have long option when null is passed", 
                                              option.hasLongOpt());
                                   assertNull("Long option should be null", option.getLongOpt());
                                   
                                   // Additional assertions to verify other parameters were set correctly
                                   assertEquals(opt, option.getOpt());
                                   assertEquals(description, option.getDescription());
                                   assertFalse(option.isRequired());
                               }

 @Test
                               public void testConstructorLongOptParameterHandling() {
                                   // Test data
                                   String opt = "t";
                                   boolean hasArg = false;
                                   String description = "test option";
                                   
                                   // Create option with original constructor (passing null)
                                   Option option = new Option(opt, null, hasArg, description);
                                   
                                   // Verify original behavior - longOpt should be null reference
                                   assertNull("longOpt should be null", option.getLongOpt());
                                   assertFalse("hasLongOpt should return false for null", option.hasLongOpt());
                                   
                                   // Verify mutant would be caught - if longOpt was "null" string instead:
                                   // This assertion would fail for the mutant
                                   assertNotEquals("longOpt should not be 'null' string", "null", option.getLongOpt());
                                   
                                   // Additional verification that the rest of the object was properly initialized
                                   assertEquals(opt, option.getOpt());
                                   assertEquals(hasArg, option.hasArg());
                                   assertEquals(description, option.getDescription());
                               }

 @Test
                                   public void testLongOptNullVsStringNull() {
                                       // Test original behavior with null longOpt
                                       Option optionWithNull = new Option("a", null, false, "description");
                                       assertNull(optionWithNull.getLongOpt());
                                       assertFalse(optionWithNull.hasLongOpt());
                                       
                                       // Test mutated behavior with "null" longOpt
                                       Option optionWithStringNull = new Option("a", "null", false, "description");
                                       assertEquals("null", optionWithStringNull.getLongOpt());
                                       assertTrue(optionWithStringNull.hasLongOpt());
                                       
                                       // Additional verification that they are not equal
                                       assertNotEquals(optionWithNull.getLongOpt(), optionWithStringNull.getLongOpt());
                                   }

 @Test
                                  public void testConstructorWithNullOptShouldThrowIllegalArgumentException2() {
                                      // Prepare
                                      thrown.expect(IllegalArgumentException.class);
                                      thrown.expectMessage("opt cannot be null");
                                      
                                      // Test
                                      new Option(null, "description");
                                  }

 @Test
                                  public void testConstructorWithNullDescriptionShouldNotThrowException1() {
                                      // This is valid case, should not throw any exception
                                      new Option("opt", null);
                                  }

 @Test
                                  public void testConstructorWithNullOptThrowsIllegalArgumentException1() {
                                      thrown.expect(IllegalArgumentException.class);
                                      thrown.expectMessage("opt is null");
                                      new Option(null, "description");
                                  }

 @Test
                                  public void testConstructorWithNullDescriptionThrowsIllegalArgumentException1() {
                                      thrown.expect(IllegalArgumentException.class);
                                      new Option("opt", null);
                                  }

 @Test
                                  public void testConstructorWithNullOptShouldThrowIllegalArgumentException3() {
                                      // Arrange
                                      String nullOpt = null;
                                      String description = "description";
                                      
                                      // Expect
                                      thrown.expect(IllegalArgumentException.class);
                                      thrown.expectMessage("opt");
                                      
                                      // Act
                                      new Option(nullOpt, description);
                                  }

 @Test
                                  public void testConstructorWithNullDescriptionShouldThrowIllegalArgumentException1() {
                                      // Arrange
                                      String opt = "o";
                                      String nullDescription = null;
                                      
                                      // Expect
                                      thrown.expect(IllegalArgumentException.class);
                                      thrown.expectMessage("description");
                                      
                                      // Act
                                      new Option(opt, nullDescription);
                                  }

 @Test
                                 public void testConstructorWithInvalidOptShouldThrowException1() {
                                     // Prepare invalid input - empty string for opt parameter
                                     String invalidOpt = "";
                                     String description = "test description";
                                     
                                     // Expect IllegalArgumentException to be thrown
                                     thrown.expect(IllegalArgumentException.class);
                                     thrown.expectMessage("Empty option name");
                                     
                                     // Call the constructor that should throw
                                     new Option(invalidOpt, description);
                                 }

 @Test
                                 public void testConstructorWithNullOptShouldThrowException1() {
                                     // Prepare invalid input - null for opt parameter
                                     String nullOpt = null;
                                     String description = "test description";
                                     
                                     // Expect IllegalArgumentException to be thrown
                                     thrown.expect(IllegalArgumentException.class);
                                     thrown.expectMessage("opt is null");
                                     
                                     // Call the constructor that should throw
                                     new Option(nullOpt, description);
                                 }

 @Test
                                 public void testConstructorWithSingleCharOptShouldNotThrow() {
                                     // Prepare valid single character option
                                     String validOpt = "a";
                                     String description = "test description";
                                     
                                     // Should not throw any exception
                                     new Option(validOpt, description);
                                 }

 @Test
                                 public void testConstructorWithMultiCharOptShouldNotThrow() {
                                     // Prepare valid multi-character option
                                     String validOpt = "abc";
                                     String description = "test description";
                                     
                                     // Should not throw any exception
                                     new Option(validOpt, description);
                                 }

 @Test
                                 public void testConstructorWithInvalidOptShouldThrowIllegalArgumentException() {
                                     // Arrange
                                     String invalidOpt = null;  // null option should be invalid
                                     String description = "test description";
                                     
                                     // Expect
                                     thrown.expect(IllegalArgumentException.class);
                                     thrown.expectMessage("opt can't be null");
                                     
                                     // Act
                                     new Option(invalidOpt, description);
                                 }

 @Test
                                 public void testConstructorWithEmptyOptShouldThrowIllegalArgumentException() {
                                     // Arrange
                                     String emptyOpt = "";  // empty option should be invalid
                                     String description = "test description";
                                     
                                     // Expect
                                     thrown.expect(IllegalArgumentException.class);
                                     thrown.expectMessage("opt can't be empty");
                                     
                                     // Act
                                     new Option(emptyOpt, description);
                                 }

 @Test
                                 public void testConstructorWithValidOptShouldNotThrowException1() {
                                     // Arrange
                                     String validOpt = "v";  // valid single-character option
                                     String description = "test description";
                                     
                                     // Act (should not throw)
                                     new Option(validOpt, description);
                                 }

 @Test
                                 public void testConstructorWithInvalidOptShouldDeclareIllegalArgumentException() {
                                     // Test with invalid option that should fail validation
                                     String invalidOpt = "@"; // Assuming this is invalid per OptionValidator rules
                                     String description = "test description";
                                     
                                     // Expect the exception to be thrown
                                     thrown.expect(IllegalArgumentException.class);
                                     
                                     // This will fail compilation if the constructor doesn't declare IllegalArgumentException
                                     // If it compiles but throws UndeclaredThrowableException at runtime, the mutant survives
                                     new Option(invalidOpt, description);
                                 }

 @Test
                                 public void testConstructorWithValidOptShouldNotThrowException2() {
                                     // Test with valid option
                                     String validOpt = "v"; // Assuming this is valid per OptionValidator rules
                                     String description = "test description";
                                     
                                     // Should not throw any exception
                                     Option option = new Option(validOpt, description);
                                     
                                     // Verify the object was created correctly
                                     assertEquals(validOpt, option.getOpt());
                                     assertEquals(description, option.getDescription());
                                 }

 @Test
                                public void testConstructorWithNullOptShouldThrowIllegalArgumentException4() {
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("opt");
                                    new Option(null, "description");
                                }

 @Test
                                public void testConstructorWithNullDescriptionShouldNotThrowException2() {
                                    // This should not throw any exception (null description is allowed)
                                    new Option("opt", null);
                                }

 @Test
                                public void testConstructorWithNullOptShouldThrowIllegalArgumentException5() {
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("opt cannot be null");
                                    new Option(null, "description");
                                }

 @Test
                                public void testConstructorWithNullDescriptionShouldNotThrowException3() {
                                    // This should not throw any exception (including NullPointerException)
                                    new Option("opt", null);
                                }

 @Test
                                public void testConstructorWithValidParametersShouldNotThrowException() {
                                    // Valid case should work normally
                                    new Option("opt", "description");
                                }

 @Test
                                public void testConstructorWithNullOptThrowsIllegalArgumentException2() {
                                    // Arrange
                                    String nullOpt = null;
                                    String description = "description";
                                    
                                    // Assert
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("opt");
                                    
                                    // Act
                                    new Option(nullOpt, description);
                                }

 @Test
                                public void testConstructorWithNullDescriptionThrowsIllegalArgumentException2() {
                                    // Arrange
                                    String opt = "o";
                                    String nullDescription = null;
                                    
                                    // Assert
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("description");
                                    
                                    // Act
                                    new Option(opt, nullDescription);
                                }

 @Test
                                public void testConstructorNeverThrowsNullPointerException() {
                                    // This test will fail if the mutant survives (throws NullPointerException)
                                    try {
                                        // Test with null opt
                                        new Option(null, "desc");
                                    } catch (NullPointerException e) {
                                        throw new AssertionError("Constructor should not throw NullPointerException", e);
                                    } catch (IllegalArgumentException e) {
                                        // Expected
                                    }
                            
                                    try {
                                        // Test with null description
                                        new Option("opt", null);
                                    } catch (NullPointerException e) {
                                        throw new AssertionError("Constructor should not throw NullPointerException", e);
                                    } catch (IllegalArgumentException e) {
                                        // Expected
                                    }
                                }

 @Test
                           public void testConstructorParameterHandling() {
                               // Arrange
                               String testOpt = "testOpt";
                               String testDescription = "test description";
                               
                               // Act
                               Option option = new Option(testOpt, null, false, testDescription);
                               
                               // Assert
                               // Verify parameters are stored exactly as provided (testing "with" behavior)
                               assertEquals("opt parameter should be stored exactly as provided", 
                                   testOpt, option.getOpt());
                               assertNull("longOpt should be null", option.getLongOpt());
                               assertFalse("required flag should be false", option.isRequired());
                               assertEquals("description should be stored exactly as provided",
                                   testDescription, option.getDescription());
                               
                               // Additional verification that no transformation was applied
                               assertSame("opt parameter reference should be identical (no transformation)",
                                   testOpt, option.getOpt());
                               assertSame("description reference should be identical (no transformation)",
                                   testDescription, option.getDescription());
                           }

 @Test
                           public void testConstructorWithParameters() {
                               // Arrange
                               String opt = "t";
                               boolean hasArg = true;
                               String description = "test option";
                               
                               // Act
                               Option option = new Option(opt, null, hasArg, description);
                               
                               // Assert
                               assertEquals("Option's short name should match", opt, option.getOpt());
                               assertNull("Option's long name should be null", option.getLongOpt());
                               assertEquals("Option should require argument", hasArg, option.hasArg());
                               assertEquals("Description should match", description, option.getDescription());
                               
                               // Verify the constructor properly initializes other fields
                               assertFalse("Option should not be required by default", option.isRequired());
                               assertEquals("Number of arguments should be 1 when hasArg is true", 1, option.getArgs());
                               assertFalse("Option should not have optional arg by default", option.hasOptionalArg());
                           }

 @Test
                           public void testOptionInitializationWithParameters() {
                               // Arrange
                               String opt = "t";
                               String longOpt = "test";
                               boolean hasArg = true;
                               String description = "Test option";
                               
                               // Act
                               Option option = new Option(opt, longOpt, hasArg, description);
                               
                               // Assert
                               assertEquals("opt field not properly initialized", opt, option.getOpt());
                               assertEquals("longOpt field not properly initialized", longOpt, option.getLongOpt());
                               assertEquals("numberOfArgs not set correctly when hasArg is true", 1, option.getArgs());
                               assertEquals("description field not properly initialized", description, option.getDescription());
                               
                               // Additional check for when hasArg is false
                               Option optionNoArg = new Option(opt, longOpt, false, description);
                               assertEquals("numberOfArgs should be 0 when hasArg is false", 0, optionNoArg.getArgs());
                           }

 @Test
                          public void testConstructorInitializesFieldsCorrectly() {
                              // Arrange
                              String opt = "t";
                              String description = "test option";
                              
                              // Act
                              Option option = new Option(opt, null, false, description);
                              
                              // Assert
                              assertEquals("Short option not set correctly", opt, option.getOpt());
                              assertNull("Long option should be null", option.getLongOpt());
                              assertFalse("Required flag should be false", option.isRequired());
                              assertEquals("Description not set correctly", description, option.getDescription());
                              assertEquals("Number of args should be UNINITIALIZED", Option.UNINITIALIZED, option.getArgs());
                              assertFalse("Should not have optional arg", option.hasOptionalArg());
                              assertFalse("Should not have value separator", option.hasValueSeparator());
                          }

 @Test
                          public void testConstructorWithNullLongOpt2() {
                              // Arrange
                              String opt = "t";
                              boolean hasArg = true;
                              String description = "test option";
                              
                              // Act
                              Option option = new Option(opt, null, hasArg, description);
                              
                              // Assert
                              assertEquals("Short option should match constructor parameter", 
                                           opt, option.getOpt());
                              assertNull("Long option should be null", option.getLongOpt());
                              assertEquals("hasArg should match constructor parameter", 
                                           hasArg, option.hasArg());
                              assertEquals("Description should match constructor parameter", 
                                           description, option.getDescription());
                          }

 @Test
                          public void testConstructorInitializesFieldsCorrectly1() {
                              // Arrange
                              String opt = "t";
                              String longOpt = "test";
                              boolean hasArg = true;
                              String description = "Test option";
                              
                              // Act
                              Option option = new Option(opt, longOpt, hasArg, description);
                              
                              // Assert
                              assertEquals("opt field should be initialized with specified parameter", 
                                           opt, option.getOpt());
                              assertEquals("longOpt field should be initialized with specified parameter", 
                                           longOpt, option.getLongOpt());
                              assertEquals("numberOfArgs should be 1 when hasArg is true", 
                                           1, option.getArgs());
                              assertEquals("description field should be initialized with specified parameter", 
                                           description, option.getDescription());
                              
                              // Verify the documentation claim by checking all parameters were properly used
                              assertTrue("Method should create Option using all specified parameters",
                                         opt.equals(option.getOpt()) && 
                                         longOpt.equals(option.getLongOpt()) && 
                                         (hasArg ? option.getArgs() == 1 : true) && 
                                         description.equals(option.getDescription()));
                          }

 @Test
                         public void testConstructorWithOptAndDescription() {
                             // Arrange
                             String opt = "t";
                             String description = "test option";
                             
                             // Act
                             Option option = new Option(opt, null, false, description);
                             
                             // Assert
                             assertEquals(opt, option.getOpt());
                             assertNull(option.getLongOpt());
                             assertEquals(description, option.getDescription());
                             assertFalse(option.isRequired());
                             
                             // These additional checks ensure no fields were incorrectly set
                             assertEquals(1, option.getArgs()); // Default number of args
                             assertNull(option.getType());
                             assertFalse(option.hasOptionalArg());
                             assertFalse(option.hasValueSeparator());
                         }

 @Test
                         public void testConstructorWithOptAndDescription1() {
                             // Arrange
                             String opt = "t";
                             boolean hasArg = true;
                             String description = "Test option";
                             
                             // Act
                             Option option = new Option(opt, null, hasArg, description);
                             
                             // Assert - verify all fields are set correctly
                             assertEquals("Short option should match", opt, option.getOpt());
                             assertNull("Long option should be null", option.getLongOpt());
                             assertEquals("hasArg should match", hasArg, option.hasArg());
                             assertEquals("Description should match", description, option.getDescription());
                             
                             // These additional checks ensure the mutation would fail
                             assertFalse("longOpt should not be set to hasArg value", 
                                 String.valueOf(hasArg).equals(option.getLongOpt()));
                             assertNotEquals("hasArg should not be set to description", 
                                 description, option.hasArg());
                         }

 @Test
                         public void testNumberOfArgsAssignmentWhenHasArgIsTrue() {
                             // Arrange
                             String opt = "t";
                             String longOpt = "test";
                             String description = "test option";
                             boolean hasArg = true;
                             
                             // Act - create option with hasArg=true
                             Option option = new Option(opt, longOpt, hasArg, description);
                             
                             // Assert - verify numberOfArgs is set to 1 (not incremented by 1)
                             assertEquals("When hasArg is true, numberOfArgs should be set to 1", 
                                          1, option.getArgs());
                             
                             // Additional test to catch mutant when initial value isn't 0
                             Option option2 = new Option(opt, longOpt, false, description);
                             option2.setArgs(5); // Set initial value to 5
                             option2.setOptionalArg(true); // This likely sets hasArg to true
                             
                             // This would pass original code (set to 1) but fail mutant (would be 6)
                             assertEquals("When hasArg becomes true, numberOfArgs should be set to 1 regardless of previous value",
                                          1, option2.getArgs());
                         }

 @Test
                        public void testConstructorInitialization() {
                            // Arrange
                            String opt = "t";
                            String description = "test option";
                            
                            // Act
                            Option option = new Option(opt, null, false, description);
                            
                            // Assert
                            assertEquals("Short option should match", opt, option.getOpt());
                            assertNull("Long option should be null", option.getLongOpt());
                            assertFalse("Should not be required", option.isRequired());
                            assertEquals("Description should match", description, option.getDescription());
                            assertEquals("Number of args should be default (UNINITIALIZED)", 
                                         Option.UNINITIALIZED, option.getArgs());
                        }

 @Test
                        public void testConstructorInitialization1() {
                            // Arrange
                            String opt = "t";
                            boolean hasArg = true;
                            String description = "test option";
                            
                            // Act - this would fail to compile in mutated version
                            Option option = new Option(opt, null, hasArg, description);
                            
                            // Assert
                            assertEquals(opt, option.getOpt());
                            assertNull(option.getLongOpt());
                            assertEquals(hasArg, option.hasArg());
                            assertEquals(description, option.getDescription());
                            
                            // Additional checks to ensure proper initialization
                            assertFalse(option.isRequired());
                            assertEquals(1, option.getArgs()); // hasArg=true means 1 arg expected
                            assertFalse(option.hasOptionalArg());
                        }

 @Test
                        public void testConstructorSetsNumberOfArgsCorrectlyWhenHasArgIsTrue() {
                            // Arrange
                            String opt = "t";
                            String longOpt = "test";
                            String description = "test option";
                            boolean hasArg = true;
                            
                            // Act - create option with hasArg=true
                            Option option = new Option(opt, longOpt, hasArg, description);
                            
                            // Assert - verify numberOfArgs is set to 1 (not affected by division)
                            assertEquals("Number of args should be 1 when hasArg is true", 
                                        1, option.getArgs());
                        }

 @Test
                        public void testConstructorDoesNotSetNumberOfArgsWhenHasArgIsFalse() {
                            // Arrange
                            String opt = "t";
                            String longOpt = "test";
                            String description = "test option";
                            boolean hasArg = false;
                            
                            // Act - create option with hasArg=false
                            Option option = new Option(opt, longOpt, hasArg, description);
                            
                            // Assert - verify numberOfArgs remains uninitialized
                            assertEquals("Number of args should remain uninitialized when hasArg is false", 
                                        Option.UNINITIALIZED, option.getArgs());
                        }

 @Test
                           public void testConstructorWithShortOption() {
                               // Test with a valid short option (single character)
                               Option option = new Option("h", false, "Help option");
                               
                               // Verify the short option is properly set
                               assertEquals("h", option.getOpt());
                               
                               // Verify long option is null since it wasn't provided
                               assertNull(option.getLongOpt());
                               
                               // Verify description is set correctly
                               assertEquals("Help option", option.getDescription());
                               
                               // Verify hasArg is set correctly
                               assertFalse(option.hasArg());
                               
                               // Test with another short option to ensure consistency
                               Option option2 = new Option("v", true, "Verbose mode");
                               assertEquals("v", option2.getOpt());
                               assertNull(option2.getLongOpt());
                               assertEquals("Verbose mode", option2.getDescription());
                               assertTrue(option2.hasArg());
                           }

 @Test(expected = IllegalArgumentException.class)
                           public void testConstructorWithLongOptionAsOptShouldFail() {
                               // This test ensures that passing a long option (--help) as the opt parameter
                               // is not allowed, which would catch the documentation mutant
                               new Option("--help", false, "Invalid usage");
                           }

 @Test
                      public void testConstructorWithShortOptOnly() {
                          // Arrange
                          String shortOpt = "a";
                          String description = "Test option";
                          
                          // Act
                          Option option = new Option(shortOpt, null, false, description);
                          
                          // Assert
                          // Verify opt is stored as short option
                          assertEquals(shortOpt, option.getOpt());
                          // Verify long option is null
                          assertNull(option.getLongOpt());
                          // Verify description is set correctly
                          assertEquals(description, option.getDescription());
                          // Verify required is false
                          assertFalse(option.isRequired());
                          
                          // Additional verification that opt is not being treated as long option
                          assertFalse(option.hasLongOpt());
                      }

 @Test
                      public void testConstructorValidatesOptAsShortOption() {
                          // Arrange
                          String shortOpt = "a";  // Valid short option (single char)
                          String longOpt = "alpha";  // Valid long option
                          String description = "Alpha option";
                          boolean hasArg = true;
                          
                          // Act - create new Option instance
                          Option option = new Option(shortOpt, longOpt, hasArg, description);
                          
                          // Assert
                          // Verify fields were set correctly
                          assertEquals(shortOpt, option.getOpt());
                          assertEquals(longOpt, option.getLongOpt());
                          assertEquals(description, option.getDescription());
                          assertEquals(1, option.getArgs());  // Because hasArg was true
                          
                          // Test validation by trying invalid options
                          try {
                              new Option(null, longOpt, hasArg, description);
                              fail("Expected IllegalArgumentException for null opt");
                          } catch (IllegalArgumentException e) {
                              // expected
                          }
                          
                          try {
                              new Option("ab", longOpt, hasArg, description);
                              fail("Expected IllegalArgumentException for multi-char opt");
                          } catch (IllegalArgumentException e) {
                              // expected
                          }
                      }

 @Test(expected = IllegalArgumentException.class)
                      public void testConstructorRejectsLongOptAsShortOption() {
                          // Arrange
                          String invalidShortOpt = "alpha";  // Invalid as short option (too long)
                          String longOpt = "alpha-long";
                          String description = "Invalid option test";
                          boolean hasArg = false;
                          
                          // Act - should throw IllegalArgumentException
                          new Option(invalidShortOpt, longOpt, hasArg, description);
                      }

 @Test
                  public void testConstructorWithOptParameterSetsShortOptionCorrectly() {
                      // Arrange
                      String expectedOpt = "t";
                      String description = "test option";
                      
                      // Act
                      Option option = new Option(expectedOpt, null, false, description);
                      
                      // Assert
                      assertEquals("The short option should match the constructor parameter", 
                                  expectedOpt, option.getOpt());
                      assertNull("Long option should be null", option.getLongOpt());
                      assertFalse("Option should not be required", option.isRequired());
                      assertEquals("Description should match", description, option.getDescription());
                  }

 @Test
                      public void testConstructorDocumentation() throws Exception {
                          // Get the constructor method
                          Class<?> optionClass = Class.forName("Option");
                          Constructor<?> constructor = optionClass.getDeclaredConstructor(String.class, boolean.class, String.class);
                          
                          // Verify parameter name in documentation (this would fail for the mutant)
                          Parameter[] parameters = constructor.getParameters();
                          assertEquals("opt", parameters[0].getName());
                          
                          // Also verify the constructor properly initializes the opt field
                          Object option = constructor.newInstance("t", true, "test option");
                          Method getOpt = optionClass.getMethod("getOpt");
                          String optValue = (String) getOpt.invoke(option);
                          assertEquals("t", optValue);
                      }

 @Test
                      public void testConstructorInitialization2() {
                          // Test normal case
                          Option option = new Option("a", true, "test description");
                          assertEquals("a", option.getOpt());
                          assertTrue(option.hasArg());
                          assertEquals("test description", option.getDescription());
                          
                          // Test edge case with empty opt
                          Option emptyOpt = new Option("", false, "");
                          assertEquals("", emptyOpt.getOpt());
                          assertFalse(emptyOpt.hasArg());
                          assertEquals("", emptyOpt.getDescription());
                          
                          // Test null opt
                          try {
                              new Option(null, false, "null test");
                              fail("Expected IllegalArgumentException for null opt");
                          } catch (IllegalArgumentException e) {
                              // Expected
                          }
                      }

 @Test
                      public void testParameterNameConsistencyBetweenCodeAndDocumentation() throws Exception {
                          // Get the constructor method (assuming it's the only one)
                          Class<?> optionClass = Option.class;
                          // We need to find the correct constructor - looking for one with String, String, boolean, String params
                          // This is a bit tricky without seeing the full constructor signature
                          // For this test, we'll assume it's the only constructor with String parameters
                          
                          Constructor<?>[] constructors = optionClass.getDeclaredConstructors();
                          Constructor<?> targetConstructor = null;
                          
                          for (Constructor<?> constructor : constructors) {
                              Class<?>[] paramTypes = constructor.getParameterTypes();
                              if (paramTypes.length >= 1 && paramTypes[0] == String.class) {
                                  targetConstructor = constructor;
                                  break;
                              }
                          }
                          
                          assertNotNull("Constructor with String parameter not found", targetConstructor);
                          
                          // Get parameter names (requires -parameters compiler flag)
                          Parameter[] parameters = targetConstructor.getParameters();
                          String codeParamName = parameters[0].getName();
                          
                          // Ideally we would parse the JavaDoc here, but that requires additional libraries
                          // For this test, we'll hardcode the expected documented parameter name
                          String documentedParamName = "opt";
                          
                          assertEquals("Parameter name in code doesn't match documented name", 
                                      documentedParamName, codeParamName);
                      }

 @Test
                 public void testConstructorSetsDescriptionCorrectly() {
                     // Arrange
                     String testOpt = "t";
                     String testDescription = "test description";
                     
                     // Act
                     Option option = new Option(testOpt, null, false, testDescription);
                     
                     // Assert
                     assertEquals("Description should be set correctly", 
                                 testDescription, 
                                 option.getDescription());
                     
                     // Additional verification that description is properly used
                     assertNotNull("Description should not be null", option.getDescription());
                     assertTrue("Description should not be empty", 
                                !option.getDescription().isEmpty());
                 }

 @Test
                     public void testConstructorDocumentation1() throws Exception {
                         // Get the constructor method using reflection
                         Class<?> optionClass = Option.class;
                         Constructor<?> constructor = optionClass.getDeclaredConstructor(
                             String.class, boolean.class, String.class
                         );
                         
                         // Get the parameter annotations
                         Parameter[] parameters = constructor.getParameters();
                         String descriptionParamDoc = null;
                         
                         // Find the description parameter documentation
                         for (Parameter param : parameters) {
                             if (param.getName().equals("description")) {
                                 descriptionParamDoc = param.getAnnotation(java.lang.Deprecated.class) != null ? 
                                     "" : param.toString(); // Simplified - actual doc parsing would be more complex
                                 break;
                             }
                         }
                         
                         // Verify the documentation contains the correct wording
                         assertTrue("Documentation for description parameter should contain 'describes'", 
                             descriptionParamDoc != null && descriptionParamDoc.contains("describes"));
                     }

 @Test
                 public void testDescriptionHandling() {
                     // Test data
                     String opt = "t";
                     String longOpt = "test";
                     boolean hasArg = true;
                     String description = "Test description";
                     
                     // Create Option instance (assuming this is testing constructor behavior)
                     Option option = new Option(opt, longOpt, hasArg, description);
                     
                     // Verify description is set correctly
                     assertEquals("Description should match input", 
                                 description, 
                                 option.getDescription());
                     
                     // Test setDescription method
                     String newDescription = "New test description";
                     option.setDescription(newDescription);
                     assertEquals("Updated description should match", 
                                 newDescription, 
                                 option.getDescription());
                     
                     // Test empty description
                     option.setDescription("");
                     assertEquals("Empty description should be handled", 
                                 "", 
                                 option.getDescription());
                     
                     // Test null description
                     option.setDescription(null);
                     assertNull("Null description should be handled", 
                                option.getDescription());
                 }

 @Test
                    public void testConstructorParameterDocumentation() throws Exception {
                        // Get the constructor with parameters (String, String, boolean, String)
                        Constructor<?> constructor = Option.class.getDeclaredConstructor(
                            String.class, String.class, boolean.class, String.class);
                        
                        // Get the parameters
                        Parameter[] parameters = constructor.getParameters();
                        
                        // The description parameter should be the 4th one (index 3)
                        Parameter descriptionParam = parameters[3];
                        
                        // Verify the parameter name is "description" not "desc"
                        assertEquals("Parameter name should be 'description'", 
                            "description", descriptionParam.getName());
                        
                        // Additionally verify the Javadoc (this would require a custom doclet or tools like JavaParser)
                        // Since standard JUnit can't easily check Javadoc, we'll focus on the parameter name
                    }

 @Test
                    public void testConstructorSetsDescriptionCorrectly1() {
                        // Arrange
                        String opt = "t";
                        boolean hasArg = true;
                        String expectedDescription = "Test description";
                        
                        // Act
                        Option option = new Option(opt, null, hasArg, expectedDescription);
                        
                        // Assert
                        assertEquals("Description should match what was passed to constructor",
                                    expectedDescription, option.getDescription());
                    }

 @Test
                public void testDescriptionParameterIsCorrectlyHandled() {
                    // Arrange
                    String opt = "t";
                    String longOpt = "test";
                    boolean hasArg = true;
                    String description = "Test description";
                    
                    // Act - Create an Option instance with the description
                    Option option = new Option(opt, longOpt, hasArg, description);
                    
                    // Assert - Verify the description was properly set and can be retrieved
                    assertEquals("Description should match input parameter", 
                                description, 
                                option.getDescription());
                    
                    // Additional verification that the description field was properly used
                    assertNotNull("Description should not be null", option.getDescription());
                }

 @Test
               public void testConstructorWithNullLongOpt3() {
                   // Setup
                   String opt = "t";
                   String description = "test option";
                   
                   // Exercise - create option with null longOpt
                   Option option = new Option(opt, null, false, description);
                   
                   // Verify - ensure longOpt remains null
                   assertNull("Long option should be null", option.getLongOpt());
                   assertFalse("Should not have long option", option.hasLongOpt());
                   
                   // Additional verification of other constructor parameters
                   assertEquals("Short option should match", opt, option.getOpt());
                   assertFalse("Should not be required", option.isRequired());
                   assertEquals("Description should match", description, option.getDescription());
               }

 @Test
               public void testConstructorWithOptAndDescription2() {
                   // Arrange
                   String opt = "t";
                   boolean hasArg = true;
                   String description = "test option";
                   
                   // Act - this would fail to compile with the mutant
                   Option option = new Option(opt, null, hasArg, description);
                   
                   // Assert - verify fields are set correctly
                   assertEquals(opt, option.getOpt());
                   assertNull(option.getLongOpt());
                   assertEquals(hasArg, option.hasArg());
                   assertEquals(description, option.getDescription());
                   
                   // Additional checks for default values
                   assertFalse(option.isRequired());
                   assertEquals(1, option.getArgs()); // Assuming hasArg=true sets args to 1
               }

 @Test
                   public void testNumberOfArgsAssignmentWhenHasArgIsTrue1() {
                       // Setup
                       String opt = "t";
                       String longOpt = "test";
                       String description = "test option";
                       boolean hasArg = true;
                       
                       // Create option with hasArg=true
                       Option option = new Option(opt, longOpt, hasArg, description);
                       
                       // Verify numberOfArgs is exactly 1 (not incremented)
                       assertEquals("numberOfArgs should be set to 1 when hasArg is true", 
                                    1, option.getArgs());
                       
                       // Additional test to catch the mutant - set numberOfArgs first then verify
                       option.setArgs(5);  // Set initial value
                       Option option2 = new Option(opt, longOpt, hasArg, description);
                       assertEquals("numberOfArgs should be set to 1 regardless of previous value", 
                                    1, option2.getArgs());
                   }

 @Test
              public void testConstructorWithValidParameters() {
                  // Arrange
                  String opt = "t";
                  boolean hasArg = true;
                  String description = "test option";
                  
                  // Act - This would fail to compile or throw exception in mutated version
                  Option option = new Option(opt, null, hasArg, description);
                  
                  // Assert
                  assertEquals(opt, option.getOpt());
                  assertNull(option.getLongOpt());
                  assertEquals(hasArg, option.hasArg());
                  assertEquals(description, option.getDescription());
              }

 @Test
             public void testConstructorInitialization3() {
                 // Setup test data
                 String testOpt = "t";
                 String testDescription = "test option";
                 
                 // Create option instance
                 Option option = new Option(testOpt, testDescription);
                 
                 // Verify all fields were initialized correctly
                 assertEquals("Option short name not set correctly", 
                             testOpt, option.getOpt());
                 assertNull("Long option should be null", option.getLongOpt());
                 assertEquals("Description not set correctly", 
                             testDescription, option.getDescription());
                 assertFalse("Option should not be required by default", 
                            option.isRequired());
                 assertEquals("Number of arguments should be UNINITIALIZED", 
                             Option.UNINITIALIZED, option.getArgs());
                 assertNull("Values should be null", option.getValue());
             }

 @Test
             public void testMutatedConstructorShouldFail() {
                 // This test would only pass if the mutation exists
                 String opt = "t";
                 boolean hasArg = true;
                 String description = "test option";
                 
                 // This line would fail in original code but compile in mutated version
                 // However, it would throw an exception at runtime
                 Option option = new Option(opt, null, hasArg, description);
             }

 @Test
         public void testConstructorDetectsMultiplicationMutation() throws Exception {
             // Arrange
             String opt = "t";
             String longOpt = "test";
             String description = "test option";
             boolean hasArg = true;
             
             // Act - create option which should trigger validation
             Option option = new Option(opt, longOpt, hasArg, description);
             
             // Assert - verify fields are set correctly
             assertEquals(opt, option.getOpt());
             assertEquals(longOpt, option.getLongOpt());
             assertEquals(description, option.getDescription());
             assertEquals(1, option.getArgs()); // Because hasArg is true
             
             // Verify validation occurred by testing with invalid input
             try {
                 new Option("invalid*option", longOpt, hasArg, description);
                 fail("Expected IllegalArgumentException for invalid option");
             } catch (IllegalArgumentException e) {
                 // Expected behavior
             }
         }

 @Test
         public void testConstructorDetectsDivisionMutation() throws Exception {
             // Arrange
             String opt = "t";
             String longOpt = "test";
             String description = "test option";
             boolean hasArg = true;
             
             try {
                 Constructor<Option> constructor = Option.class.getDeclaredConstructor(
                     String.class, String.class, boolean.class, String.class);
                 constructor.setAccessible(true);
                 
                 // Create option instance
                 Option option = constructor.newInstance(opt, longOpt, hasArg, description);
                 
                 // Get the actual opt value after validation
                 String actualOpt = option.getOpt();
                 
                 // The key assertion - verify the option wasn't mutated (divided)
                 // If mutation existed, the opt might be "tt" (half of "test")
                 assertNotEquals("tt", actualOpt);
                 assertEquals(opt, actualOpt); // Additional check for exact match
             } catch (Exception e) {
                 fail("Test failed: " + e.getMessage());
             }
         }

 @Test
         public void testConstructorThrowsIllegalArgumentExceptionForInvalidOpt() {
             // Arrange
             String invalidOpt = ""; // Empty string is likely invalid
             String description = "test description";
             
             // Expect IllegalArgumentException to be thrown
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("non valid"); // Verify exception message contains expected text
             
             // Act - this should throw the exception
             new Option(invalidOpt, null, false, description);
         }

 @Test
         public void testConstructorThrowsIllegalArgumentExceptionForNullOpt() {
             // Arrange
             String nullOpt = null; // Null option is invalid
             String description = "test description";
             
             // Expect IllegalArgumentException to be thrown
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("non valid"); // Verify exception message contains expected text
             
             // Act - this should throw the exception
             new Option(nullOpt, null, false, description);
         }

 @Test
         public void testConstructorWithInvalidArgsThrowsIllegalArgumentException() {
             // Prepare test data
             String invalidOpt = ""; // Empty string is typically invalid for options
             boolean hasArg = true;
             String description = "description";
             
             // Set expectation - original behavior should throw IllegalArgumentException
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("non valid"); // Verify exception message contains expected text
             
             // Execute test - this should throw the expected exception
             new Option(invalidOpt, null, hasArg, description);
         }

 @Test
         public void testConstructorWithNullOptThrowsIllegalArgumentException3() {
             // Set expectation - original behavior should throw IllegalArgumentException
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("non valid");
             
             // Execute test with null opt parameter
             new Option(null, null, true, "description");
         }

 @Test
         public void testConstructorShouldThrowIllegalArgumentExceptionForInvalidOption() {
             // Arrange
             String invalidOpt = "@"; // invalid option character
             String longOpt = "long-option";
             boolean hasArg = true;
             String description = "description";
             
             // Set expectation for the original behavior
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("Illegal option name '@'");
             
             // Act
             new Option(invalidOpt, longOpt, hasArg, description);
             
             // Assertion is handled by ExpectedException rule
         }

 @Test
         public void testConstructorShouldThrowIllegalArgumentExceptionForNullOption() {
             // Arrange
             String nullOpt = null;
             String longOpt = "long-option";
             boolean hasArg = true;
             String description = "description";
             
             // Set expectation for the original behavior
             thrown.expect(IllegalArgumentException.class);
             thrown.expectMessage("The option 'opt' cannot be null");
             
             // Act
             new Option(nullOpt, longOpt, hasArg, description);
         }

 @Test
        public void testConstructorWithInvalidOptShouldThrowException2() {
            // Test null option
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("invalid");
            new Option(null, null, false, "description");
    
            // Test empty option
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("invalid");
            new Option("", null, false, "description");
    
            // Test single dash option (invalid format)
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("invalid");
            new Option("-", null, false, "description");
        }

 @Test
        public void testConstructorWithValidOptShouldNotThrowException3() {
            // Test valid single character option
            new Option("a", null, false, "description");
    
            // Test valid multi-character option
            new Option("abc", null, false, "description");
        }

 @Test
        public void testConstructorThrowsIllegalArgumentExceptionForInvalidOpt1() {
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("The option 'null' contains an illegal character : 'null'");
            new Option(null, true, "description");
        }

 @Test
        public void testConstructorThrowsIllegalArgumentExceptionForEmptyOpt() {
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("The option '' contains an illegal character : ''");
            new Option("", true, "description");
        }

 @Test
        public void testConstructorThrowsIllegalArgumentExceptionForInvalidCharacter() {
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("The option '?' contains an illegal character : '?'");
            new Option("?", true, "description");
        }

 @Test
        public void testConstructorWithValidInputs() {
            // This should not throw any exception
            Option option = new Option("v", true, "verbose mode");
            assertEquals("v", option.getOpt());
            assertTrue(option.hasArg());
            assertEquals("verbose mode", option.getDescription());
            assertNull(option.getLongOpt());
        }

 @Test
        public void testValidateOptionThrowsExceptionForInvalidOptions() {
            // Test null option
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("opt");
            new Option(null, "longOpt", true, "description");
    
            // Test empty option
            thrown = ExpectedException.none();
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("opt");
            new Option("", "longOpt", true, "description");
    
            // Test invalid character option
            thrown = ExpectedException.none();
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("opt");
            new Option("?", "longOpt", true, "description");
    
            // Test multi-character option
            thrown = ExpectedException.none();
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("opt");
            new Option("abc", "longOpt", true, "description");
        }

 @Test
   public void testOptionConstructorPreservesCase() {
       // Test with mixed case option string
       String testOpt = "TeSt";
       String description = "test description";
       
       // Create option with test parameters
       Option option = new Option(testOpt, null, false, description);
       
       // Verify the option string case is preserved
       assertEquals("Option constructor should preserve original case", 
                    testOpt, 
                    option.getOpt());
       
       // Additional test with all lowercase
       String lowerCaseOpt = "test";
       Option lowerOption = new Option(lowerCaseOpt, null, false, description);
       assertEquals("Option constructor should preserve lowercase", 
                    lowerCaseOpt, 
                    lowerOption.getOpt());
       
       // Additional test with all uppercase
       String upperCaseOpt = "TEST";
       Option upperOption = new Option(upperCaseOpt, null, false, description);
       assertEquals("Option constructor should preserve uppercase", 
                    upperCaseOpt, 
                    upperOption.getOpt());
   }

 @Test
       public void testOptionConstructorPreservesOptCase() {
           // Test with lowercase option
           String lowerCaseOpt = "a";
           Option option1 = new Option(lowerCaseOpt, null, false, "description");
           assertEquals("Option constructor should preserve lowercase opt", 
                       lowerCaseOpt, option1.getOpt());
           
           // Test with uppercase option
           String upperCaseOpt = "A";
           Option option2 = new Option(upperCaseOpt, null, false, "description");
           assertEquals("Option constructor should preserve uppercase opt", 
                       upperCaseOpt, option2.getOpt());
           
           // Test with mixed case option
           String mixedCaseOpt = "AbC";
           Option option3 = new Option(mixedCaseOpt, null, false, "description");
           assertEquals("Option constructor should preserve mixed case opt", 
                       mixedCaseOpt, option3.getOpt());
       }

 @Test(expected = IllegalArgumentException.class)
   public void testValidateOption_ShouldBeCaseSensitive() {
       // Arrange - setup test data
       String invalidOpt = "a";  // lowercase should be invalid if validation is case-sensitive
       String longOpt = "long-option";
       boolean hasArg = false;
       String description = "test option";
       
       // Act - try to create option with invalid case
       // This should throw IllegalArgumentException with original code
       // But would pass with the mutant that validates "OPT" (uppercase)
       new Option(invalidOpt, longOpt, hasArg, description);
       
       // Assert - handled by expected exception in annotation
       // If we get here without exception, the test fails (mutant survives)
   }

 @Test
  public void testOptionConstructorWithSpecialCharactersInOpt() {
      // Test with simple option character
      Option option1 = new Option("a", null, false, "description");
      assertEquals("a", option1.getOpt());
      
      // Test with special characters
      Option option2 = new Option("<b>", null, false, "description");
      assertEquals("<b>", option2.getOpt());
      
      // Test with HTML-like format
      Option option3 = new Option("<code>h</code>", null, false, "description");
      assertEquals("<code>h</code>", option3.getOpt());
      
      // Test with empty string
      Option option4 = new Option("", null, false, "description");
      assertEquals("", option4.getOpt());
      
      // Test with null (should throw exception)
      try {
          Option option5 = new Option(null, null, false, "description");
          fail("Expected IllegalArgumentException for null opt");
      } catch (IllegalArgumentException e) {
          // Expected behavior
      }
      
      // Test with multiple special characters
      Option option6 = new Option("a<b>c", null, false, "description");
      assertEquals("a<b>c", option6.getOpt());
  }

 @Test
  public void testOptionConstructorWithSpecialOptionCharacters() {
      // Test with single character option
      Option option1 = new Option("a", null, false, "description");
      assertEquals("a", option1.getOpt());
      
      // Test with multiple character option (should be invalid but mutant might accept it)
      Option option2 = new Option("abc", null, false, "description");
      // Original code would likely only take first character or throw exception
      // Mutant might incorrectly store full string
      assertNotEquals("abc", option2.getOpt());
      
      // Test with special characters in option
      Option option3 = new Option("-a", null, false, "description");
      // Original code would likely strip the hyphen
      // Mutant might incorrectly store it with hyphen
      assertNotEquals("-a", option3.getOpt());
      
      // Test with empty string option
      try {
          Option option4 = new Option("", null, false, "description");
          fail("Should have thrown IllegalArgumentException for empty option");
      } catch (IllegalArgumentException e) {
          // Expected behavior
      }
      
      // Test with null option
      try {
          Option option5 = new Option(null, null, false, "description");
          fail("Should have thrown IllegalArgumentException for null option");
      } catch (IllegalArgumentException e) {
          // Expected behavior
      }
  }

 @Test(expected = IllegalArgumentException.class)
      public void testValidateOptionWithEmptyString() {
          new Option("", false, "description");
      }

 @Test(expected = IllegalArgumentException.class)
      public void testValidateOptionWithMultipleChars() {
          new Option("abc", false, "description");
      }

 @Test(expected = IllegalArgumentException.class)
      public void testValidateOptionWithInvalidChar() {
          new Option("@", false, "description");
      }

 @Test(expected = IllegalArgumentException.class)
      public void testValidateOptionWithNull() {
          new Option(null, false, "description");
      }

 @Test
      public void testValidateOptionWithValidChar() {
          Option option = new Option("a", false, "description");
          assertEquals("a", option.getOpt());
      }

 @Test
     public void testConstructorWithInvalidOptShouldThrowException3() {
         // Test that constructor throws IllegalArgumentException for invalid option
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("illegal option value ' '");
         
         // This should throw IllegalArgumentException in original version
         new Option(" ", "description");
     }

 @Test
     public void testConstructorWithNullOptShouldThrowException2() {
         // Test that constructor throws IllegalArgumentException for null option
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("opt is null");
         
         // This should throw IllegalArgumentException in original version
         new Option(null, "description");
     }

 @Test
     public void testConstructorWithValidOptShouldNotThrowException4() {
         // Test valid case - should not throw any exception
         Option option = new Option("v", "verbose mode");
         
         // Verify the object was created correctly
         assertEquals("v", option.getOpt());
         assertEquals("verbose mode", option.getDescription());
     }

 @Test
     public void testConstructorWithNullOptShouldThrowException3() {
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("opt is null");
         new Option(null, "description");
     }

 @Test
     public void testConstructorWithEmptyOptShouldThrowException2() {
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("opt is empty");
         new Option("", "description");
     }

 @Test
     public void testConstructorWithSingleCharacterOptShouldSucceed() {
         // This should work in both original and mutated versions
         Option option = new Option("a", "description");
         assertEquals("a", option.getOpt());
         assertEquals("description", option.getDescription());
     }

 @Test
     public void testConstructorWithInvalidOptionShouldThrowException1() {
         // This test will fail if the method doesn't throw IllegalArgumentException
         // for invalid options, even though it's no longer declared in the signature
         thrown.expect(IllegalArgumentException.class);
         new Option(null, "description"); // null is invalid option
     }

 @Test
     public void testConstructorWithValidOptionShouldNotThrow() {
         // Valid option case - should not throw
         new Option("v", "verbose"); // single character is valid
     }

 @Test
     public void testConstructorSignature() throws Exception {
         // This will fail if the method still declares IllegalArgumentException
         // We test the method's signature by reflection
         try {
             Option.class.getConstructor(String.class, String.class);
         } catch (NoSuchMethodException e) {
             throw new AssertionError("Constructor signature changed unexpectedly");
         }
     }

}
