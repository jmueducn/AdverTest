package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                       public void testRenderWrappedText_NoWrapNeeded() throws Exception {
                                           HelpFormatter helpFormatter = new HelpFormatter();
                                           StringBuffer sb = new StringBuffer();
                                           String text = "Short text";
                                           
                                           // Use reflection to access protected method
                                           Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                               "renderWrappedText", 
                                               StringBuffer.class, 
                                               int.class, 
                                               int.class, 
                                               String.class
                                           );
                                           renderWrappedText.setAccessible(true);
                                           StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                               helpFormatter, 
                                               sb, 
                                               50, 
                                               4, 
                                               text
                                           );
                                           
                                           assertEquals("Short text", result.toString());
                                       }

    @Test
                                       public void testRenderWrappedText_SingleWrap() throws Exception {
                                           String text = "This is a longer text that needs wrapping";
                                           StringBuffer sb = new StringBuffer();
                                           HelpFormatter helpFormatter = new HelpFormatter();
                                           
                                           // Use reflection to access protected method
                                           Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                               "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                           renderWrappedText.setAccessible(true);
                                           StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                               helpFormatter, sb, 20, 4, text);
                                           
                                           String expected = "This is a longer\ntext that needs\nwrapping";
                                           assertEquals(expected, result.toString());
                                       }

    @Test
                                       public void testRenderWrappedText_MultipleWrapsWithPadding() throws Exception {
                                           String text = "This is a very long text that will require multiple wraps to fit within the specified width";
                                           StringBuffer sb = new StringBuffer();
                                           HelpFormatter helpFormatter = new HelpFormatter();
                                           
                                           // Use reflection to access protected method
                                           Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                               "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                           renderWrappedText.setAccessible(true);
                                           StringBuffer result = (StringBuffer) renderWrappedText.invoke(helpFormatter, sb, 30, 4, text);
                                           
                                           String expected = "This is a very long text\n    that will require\n    multiple wraps to\n    fit within the\n    specified width";
                                           assertEquals(expected, result.toString());
                                       }

    @Test
                                       public void testRenderWrappedText_EmptyString() throws Exception {
                                           String text = "";
                                           StringBuffer sb = new StringBuffer();
                                           HelpFormatter helpFormatter = new HelpFormatter();
                                           
                                           // Get the protected method using reflection
                                           Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                               "renderWrappedText", 
                                               StringBuffer.class, 
                                               int.class, 
                                               int.class, 
                                               String.class
                                           );
                                           renderWrappedText.setAccessible(true);
                                           
                                           // Invoke the method
                                           StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                               helpFormatter, 
                                               sb, 
                                               30, 
                                               4, 
                                               text
                                           );
                                           
                                           assertEquals("", result.toString());
                                       }

    @Test
                                       public void testRenderWrappedText_NullString() throws Exception {
                                           HelpFormatter helpFormatter = new HelpFormatter();
                                           StringBuffer sb = new StringBuffer();
                                           
                                           try {
                                               Method method = HelpFormatter.class.getDeclaredMethod(
                                                   "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                               method.setAccessible(true);
                                               method.invoke(helpFormatter, sb, 30, 4, null);
                                               fail("Expected NullPointerException");
                                           } catch (InvocationTargetException e) {
                                               assertTrue(e.getCause() instanceof NullPointerException);
                                           }
                                       }

    @Test
                                       public void testRenderWrappedText_WidthTooSmall() throws Exception {
                                           String text = "Testing";
                                           StringBuffer sb = new StringBuffer();
                                           HelpFormatter helpFormatter = new HelpFormatter();
                                           
                                           // Use reflection to access protected method
                                           Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                               "renderWrappedText", 
                                               StringBuffer.class, 
                                               int.class, 
                                               int.class, 
                                               String.class
                                           );
                                           renderWrappedText.setAccessible(true);
                                           StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                               helpFormatter, 
                                               sb, 
                                               1, 
                                               0, 
                                               text
                                           );
                                           
                                           assertEquals("Testing", result.toString());
                                       }

    @Test
                                       public void testRenderWrappedText_NextLineTabStopLargerThanWidth() throws Exception {
                                           HelpFormatter helpFormatter = new HelpFormatter();
                                           StringBuffer sb = new StringBuffer();
                                           String text = "This text will test the case where nextLineTabStop is larger than width";
                                           
                                           // Use reflection to access protected method
                                           Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                               "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                           renderWrappedText.setAccessible(true);
                                           StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                               helpFormatter, sb, 20, 25, text);
                                           
                                           // Should adjust nextLineTabStop to width-1 (19)
                                           String expected = "This text will test\n                   the case where\n                   nextLineTabStop\n                   is larger than\n                   width";
                                           assertEquals(expected, result.toString());
                                       }

    @Test
                                       public void testRenderWrappedText_ExactWidthFit() throws Exception {
                                           String text = "Exactly fits";
                                           StringBuffer sb = new StringBuffer();
                                           HelpFormatter helpFormatter = new HelpFormatter();
                                           
                                           // Use reflection to access protected method
                                           Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                               "renderWrappedText", 
                                               StringBuffer.class, 
                                               int.class, 
                                               int.class, 
                                               String.class
                                           );
                                           renderWrappedText.setAccessible(true);
                                           StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                               helpFormatter, 
                                               sb, 
                                               12, 
                                               4, 
                                               text
                                           );
                                           
                                           assertEquals("Exactly fits", result.toString());
                                       }

    @Test
                                       public void testRenderWrappedText_WithLeadingAndTrailingSpaces() throws Exception {
                                           HelpFormatter helpFormatter = new HelpFormatter();
                                           StringBuffer sb = new StringBuffer();
                                           String text = "   Text with spaces around   ";
                                           
                                           // Use reflection to access protected method
                                           Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                               "renderWrappedText", 
                                               StringBuffer.class, 
                                               int.class, 
                                               int.class, 
                                               String.class
                                           );
                                           renderWrappedText.setAccessible(true);
                                           StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                               helpFormatter, 
                                               sb, 
                                               15, 
                                               4, 
                                               text
                                           );
                                           
                                           String expected = "Text with\n    spaces around";
                                           assertEquals(expected, result.toString());
                                       }

    @Test
                                       public void testRenderWrappedText_SpecialCasePosEqualsTabStopMinusOne() throws Exception {
                                           // This tests the special case where pos == nextLineTabStop - 1
                                           String text = "This is a text that will trigger the special case in the wrapping logic";
                                           // Set width and tabstop to force the special condition
                                           StringBuffer sb = new StringBuffer();
                                           HelpFormatter helpFormatter = new HelpFormatter();
                                           
                                           // Use reflection to access protected method
                                           Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                               "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                           renderWrappedText.setAccessible(true);
                                           StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                               helpFormatter, sb, 20, 5, text);
                                           
                                           String expected = "This is a text that\n     will trigger the\n     special case in\n     the wrapping\n     logic";
                                           assertEquals(expected, result.toString());
                                       }

    @Test
                                       public void testRenderWrappedText_VeryLongWord() throws Exception {
                                           String text = "ThisTextHasAnExtremelyLongWordThatCannotBeBrokenAndExceedsTheWidth";
                                           StringBuffer sb = new StringBuffer();
                                           HelpFormatter helpFormatter = new HelpFormatter();
                                           
                                           // Use reflection to access protected method
                                           Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                               "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                           renderWrappedText.setAccessible(true);
                                           StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                               helpFormatter, sb, 10, 2, text);
                                           
                                           // Should still display the full word even if it exceeds width
                                           assertEquals(text, result.toString());
                                       }

    @Test
                                  public void testRenderWrappedTextWhenNextLineTabStopEqualsWidth() throws Exception {
                                      // Setup
                                      HelpFormatter formatter = new HelpFormatter();
                                      // Use reflection to set the protected defaultNewLine field
                                      Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                      defaultNewLineField.setAccessible(true);
                                      defaultNewLineField.set(formatter, "\n"); // Ensure consistent line endings for test
                                      
                                      // Test case where nextLineTabStop equals width (boundary case)
                                      StringBuffer sb = new StringBuffer();
                                      int width = 10;
                                      int nextLineTabStop = 10; // Equal to width
                                      String text = "This is a long text that should be wrapped at 10 characters";
                                      
                                      // Get the protected method via reflection
                                      Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                          "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                      renderWrappedText.setAccessible(true);
                                      
                                      // Call method via reflection
                                      StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                          formatter, sb, width, nextLineTabStop, text);
                                      
                                      // Verify the behavior
                                      String output = result.toString();
                                      String[] lines = output.split("\n");
                                      
                                      // Check that second line is indented by width-1 (9) spaces
                                      // If mutant is present, it would be indented by 10 spaces
                                      if (lines.length > 1) {
                                          String secondLine = lines[1];
                                          assertTrue("Second line should start with 9 spaces when nextLineTabStop equals width",
                                                    secondLine.startsWith("         ")); // 9 spaces
                                          assertEquals(9, secondLine.indexOf(text.trim().substring("This is a".length())));
                                      }
                                      
                                      // Also verify the entire output matches expected wrapping
                                      String expected = 
                                          "This is a\n" +  // First line
                                          "         long\n" +  // Second line indented by 9 spaces
                                          "         text\n" +
                                          "         that\n" +
                                          "         should\n" +
                                          "         be\n" +
                                          "         wrapped\n" +
                                          "         at 10\n" +
                                          "         characters";
                                      assertEquals(expected, output.trim());
                                  }

    @Test
                             public void testRenderWrappedText_NextLineTabStopEqualsWidth() throws Exception {
                                 // Setup
                                 HelpFormatter formatter = new HelpFormatter();
                                 formatter.setNewLine("\n");
                                 
                                 StringBuffer sb = new StringBuffer();
                                 int width = 10;
                                 int nextLineTabStop = 10; // Exactly equals width
                                 String text = "This is a long text that needs to be wrapped";
                                 
                                 // Get the protected method via reflection
                                 Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                     "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                 renderWrappedText.setAccessible(true);
                                 
                                 // Execute
                                 StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                     formatter, sb, width, nextLineTabStop, text);
                                 
                                 // Verify the behavior
                                 // The key verification is that nextLineTabStop was adjusted to width-1
                                 // because in original code, nextLineTabStop >= width condition would trigger
                                 // but in mutant, nextLineTabStop != width would NOT trigger when they're equal
                                 
                                 // Check that the padding was created with width-1 (9) spaces
                                 // This verifies the adjustment happened (original behavior)
                                 String expectedPadding = "         "; // 9 spaces
                                 assertTrue(result.toString().contains(expectedPadding));
                                 
                                 // Also verify the wrapping worked as expected
                                 String[] lines = result.toString().split("\n");
                                 for (String line : lines) {
                                     assertTrue(line.length() <= width);
                                 }
                             }

    @Test
                        public void testRenderWrappedText_NextLineTabStopLessThanWidth() throws Exception {
                            // Setup
                            HelpFormatter formatter = new HelpFormatter();
                            
                            // Use reflection to set defaultNewLine since it might be protected
                            Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                            defaultNewLineField.setAccessible(true);
                            defaultNewLineField.set(formatter, "\n");
                            
                            StringBuffer sb = new StringBuffer();
                            int width = 20;
                            int nextLineTabStop = 10; // Explicitly less than width
                            String text = "This is a long text that should be wrapped properly";
                            
                            // Use reflection to call protected renderWrappedText method
                            Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                            renderWrappedText.setAccessible(true);
                            StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
                            
                            // Use reflection to call protected createPadding method
                            Method createPadding = HelpFormatter.class.getDeclaredMethod("createPadding", int.class);
                            createPadding.setAccessible(true);
                            String padding = (String) createPadding.invoke(formatter, nextLineTabStop);
                            
                            String expectedFirstLine = text.substring(0, text.indexOf(" ", width));
                            String expectedSecondLineStart = padding + text.substring(text.indexOf(" ", width)).trim();
                            
                            // Check the first line was properly wrapped
                            assertTrue(result.toString().contains(expectedFirstLine));
                            
                            // Check subsequent lines start with correct padding (original nextLineTabStop)
                            assertTrue(result.toString().contains(expectedSecondLineStart));
                            
                            // Verify the padding length matches original nextLineTabStop
                            int actualPaddingLength = result.toString().split("\n")[1].length() - 
                                                    result.toString().split("\n")[1].trim().length();
                            assertEquals(nextLineTabStop, actualPaddingLength);
                        }

    @Test
                   public void testRenderWrappedText_DetectsNextLineTabStopMutation() throws Exception {
                       // Setup
                       HelpFormatter formatter = new HelpFormatter();
                       Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                       defaultNewLineField.setAccessible(true);
                       defaultNewLineField.set(formatter, "\n");
                       
                       // Create a scenario where nextLineTabStop >= width
                       int width = 5;
                       int nextLineTabStop = 10; // Larger than width
                       String text = "This is a test string that needs wrapping";
                       StringBuffer sb = new StringBuffer();
                       
                       // Get protected methods via reflection
                       Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                       renderWrappedText.setAccessible(true);
                       
                       Method createPadding = HelpFormatter.class.getDeclaredMethod("createPadding", int.class);
                       createPadding.setAccessible(true);
                       
                       // Execute
                       StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                           formatter, sb, width, nextLineTabStop, text);
                       
                       // Verify the padding adjustment
                       // Original would set nextLineTabStop to width-1 (4)
                       // Mutant would set it to width-2 (3)
                       // Check that wrapped lines don't exceed width
                       String[] lines = result.toString().split("\n");
                       for (int i = 1; i < lines.length; i++) {
                           // First line is special case, check subsequent lines
                           assertTrue("Line should not exceed width", 
                                     lines[i].length() <= width);
                           
                           // Verify padding is correct (should be width-1 spaces)
                           // This will fail with mutant which would use width-2 spaces
                           String expectedPadding = (String) createPadding.invoke(formatter, width - 1);
                           assertTrue("Line should have correct padding",
                                     lines[i].startsWith(expectedPadding));
                       }
                       
                       // Additional verification for complete output
                       assertNotNull("Result should not be null", result);
                       assertTrue("Result should contain original text", 
                                 result.toString().contains("This") && 
                                 result.toString().contains("test"));
                   }

    @Test
              public void testRenderWrappedText_NextLineTabStopGreaterThanWidth() throws Exception {
                  // Setup
                  HelpFormatter formatter = new HelpFormatter();
                  // Use reflection to set the protected field
                  Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                  defaultNewLineField.setAccessible(true);
                  defaultNewLineField.set(formatter, "\n"); // Ensure consistent line endings for test
                  
                  StringBuffer sb = new StringBuffer();
                  
                  // Test case where nextLineTabStop > width
                  int width = 10;
                  int nextLineTabStop = 15; // Greater than width
                  String text = "This is a long text that needs to be wrapped properly";
                  
                  // Get the protected method via reflection
                  Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                      "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                  renderWrappedText.setAccessible(true);
                  
                  // Execute
                  StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
                  
                  // Verify the wrapped lines
                  String[] lines = result.toString().split("\n");
                  
                  // First line shouldn't be indented
                  assertEquals("This is a", lines[0]);
                  
                  // Subsequent lines should be indented with width-1 spaces (9 spaces)
                  String expectedIndent = "         "; // 9 spaces
                  assertTrue(lines[1].startsWith(expectedIndent));
                  
                  // Verify the mutant would fail this test (0 spaces indentation)
                  assertNotEquals("", lines[1].substring(0, 9));
                  
                  // Verify the text was properly wrapped
                  assertTrue(lines[1].trim().length() > 0);
              }

    @Test
         public void testRenderWrappedText_DetectsNextLineTabStopMutation1() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             
             // Use reflection to set the protected defaultNewLine field
             Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
             defaultNewLineField.setAccessible(true);
             defaultNewLineField.set(formatter, "\n");
             
             StringBuffer sb = new StringBuffer();
             int width = 20;
             int nextLineTabStop = 25; // This is > width to trigger the condition
             String text = "This is a long text that should be wrapped properly with correct padding";
             
             // Use reflection to access the protected method
             Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                 "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
             renderWrappedText.setAccessible(true);
             
             // Execute
             StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
             
             // Verify the mutation was caught
             String output = result.toString();
             String[] lines = output.split("\n");
             
             // First line should be normal width
             assertTrue(lines[0].length() <= width);
             
             // Subsequent lines should have padding based on width-1 (original behavior)
             // With the mutant (nextLineTabStop=1), padding would be much shorter
             for (int i = 1; i < lines.length; i++) {
                 // Check padding length - should be width-1 spaces (19 in this case)
                 // If mutant is present, padding would be just 1 space
                 assertTrue(lines[i].startsWith("                   ")); // 19 spaces
                 assertTrue(lines[i].length() <= width);
             }
             
             // Additional check - count the spaces at start of second line
             int paddingSpaces = 0;
             while (paddingSpaces < lines[1].length() && lines[1].charAt(paddingSpaces) == ' ') {
                 paddingSpaces++;
             }
             assertEquals(width - 1, paddingSpaces); // Should be 19, would be 1 with mutant
         }

    @Test
    public void testRenderWrappedText_NextLineTabStopAdjustment() throws Exception {
        // Setup
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");
        
        // Create a scenario where nextLineTabStop >= width
        int width = 10;
        int nextLineTabStop = 15; // This will trigger the adjustment
        String text = "This is a long text that needs to be wrapped properly";
        StringBuffer sb = new StringBuffer();
        
        // Use reflection to access protected method
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
        renderWrappedText.setAccessible(true);
        
        // Execute
        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
            formatter, sb, width, nextLineTabStop, text);
        
        // Verify the padding was adjusted correctly
        // Original code would set padding to width-1 (9 spaces)
        // Mutant would set it to width/2 (5 spaces)
        // Check if any line has more than 5 spaces at start (would fail for mutant)
        String[] lines = result.toString().split("\n");
        
        // First line shouldn't have padding
        assertEquals("This is a", lines[0].trim());
        
        // Second line should have padding
        // Original would have 9 spaces, mutant would have 5
        assertTrue(lines[1].startsWith("         ") || lines[1].startsWith("     "));
        
        // Specifically check the padding length is correct (9 for original)
        // This will fail for the mutant which would have 5
        assertEquals(9, lines[1].indexOf('T'));
    }


}
