package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
 
public class PosixParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                         public void testProcess_WithNullValue() throws Exception {
                                                                                                             // Create parser instance
                                                                                                             PosixParser parser = new PosixParser();
                                                                                                             
                                                                                                             // Initialize tokens list using reflection
                                                                                                             Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                             tokensField.setAccessible(true);
                                                                                                             @SuppressWarnings("unchecked")
                                                                                                             List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                             
                                                                                                             // Test null value handling
                                                                                                             Method processMethod = PosixParser.class.getDeclaredMethod("process", String.class);
                                                                                                             processMethod.setAccessible(true);
                                                                                                             processMethod.invoke(parser, (String) null);
                                                                                                             
                                                                                                             // Verify null was added to tokens
                                                                                                             assertEquals(2, tokens.size());
                                                                                                             assertEquals("--", tokens.get(0));
                                                                                                             assertNull(tokens.get(1));
                                                                                                         }

    @Test
                                                                                                         public void testProcessOptionToken_WhenOptionExists() throws Exception {
                                                                                                             // Setup
                                                                                                             String token = "-f";
                                                                                                             Options options = mock(Options.class);
                                                                                                             Option mockOption = mock(Option.class);
                                                                                                             when(options.hasOption(token)).thenReturn(true);
                                                                                                             when(options.getOption(token)).thenReturn(mockOption);
                                                                                                             
                                                                                                             PosixParser parser = new PosixParser();
                                                                                                             
                                                                                                             // Use reflection to set private fields
                                                                                                             Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                             optionsField.setAccessible(true);
                                                                                                             optionsField.set(parser, options);
                                                                                                             
                                                                                                             Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                             tokensField.setAccessible(true);
                                                                                                             List<String> tokens = new ArrayList<>();
                                                                                                             tokensField.set(parser, tokens);
                                                                                                             
                                                                                                             // Execute
                                                                                                             Method method = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                                                                             method.setAccessible(true);
                                                                                                             method.invoke(parser, token, false);
                                                                                                             
                                                                                                             // Verify
                                                                                                             Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                                                             currentOptionField.setAccessible(true);
                                                                                                             Option currentOption = (Option) currentOptionField.get(parser);
                                                                                                             assertSame(mockOption, currentOption);
                                                                                                             
                                                                                                             assertTrue(tokens.contains(token));
                                                                                                             
                                                                                                             Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                                                             eatTheRestField.setAccessible(true);
                                                                                                             boolean eatTheRest = eatTheRestField.getBoolean(parser);
                                                                                                             assertFalse(eatTheRest);
                                                                                                         }

    @Test
                                                                                                         public void testProcessOptionToken_WithEmptyToken() throws Exception {
                                                                                                             // Setup
                                                                                                             String token = "";
                                                                                                             Options options = mock(Options.class);
                                                                                                             when(options.hasOption(token)).thenReturn(false);
                                                                                                             
                                                                                                             PosixParser parser = new PosixParser();
                                                                                                             Field optionsField = parser.getClass().getDeclaredField("options");
                                                                                                             optionsField.setAccessible(true);
                                                                                                             optionsField.set(parser, options);
                                                                                                             
                                                                                                             Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                                                             tokensField.setAccessible(true);
                                                                                                             List<String> tokens = new ArrayList<>();
                                                                                                             tokensField.set(parser, tokens);
                                                                                                             
                                                                                                             // Execute
                                                                                                             Method method = parser.getClass().getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                                                                             method.setAccessible(true);
                                                                                                             method.invoke(parser, token, true);
                                                                                                             
                                                                                                             // Verify
                                                                                                             Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                                                                                             currentOptionField.setAccessible(true);
                                                                                                             assertNull(currentOptionField.get(parser));
                                                                                                             
                                                                                                             assertTrue(tokens.contains(token));
                                                                                                             
                                                                                                             Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                                                                                             eatTheRestField.setAccessible(true);
                                                                                                             assertTrue((Boolean) eatTheRestField.get(parser));
                                                                                                         }

    @Test
                                                                                                         public void testProcessOptionToken_WhenOptionExistsAndStopAtNonOptionTrue() throws Exception {
                                                                                                             // Setup
                                                                                                             String token = "-v";
                                                                                                             Options options = mock(Options.class);
                                                                                                             Option mockOption = mock(Option.class);
                                                                                                             PosixParser parser = new PosixParser();
                                                                                                             
                                                                                                             // Use reflection to access private fields
                                                                                                             Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                             optionsField.setAccessible(true);
                                                                                                             optionsField.set(parser, options);
                                                                                                             
                                                                                                             Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                             tokensField.setAccessible(true);
                                                                                                             @SuppressWarnings("unchecked")
                                                                                                             List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                             
                                                                                                             when(options.hasOption(token)).thenReturn(true);
                                                                                                             when(options.getOption(token)).thenReturn(mockOption);
                                                                                                             
                                                                                                             // Execute
                                                                                                             Method method = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                                                                             method.setAccessible(true);
                                                                                                             method.invoke(parser, token, true);
                                                                                                             
                                                                                                             // Verify
                                                                                                             Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                                                             currentOptionField.setAccessible(true);
                                                                                                             Option currentOption = (Option) currentOptionField.get(parser);
                                                                                                             
                                                                                                             Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                                                             eatTheRestField.setAccessible(true);
                                                                                                             boolean eatTheRest = eatTheRestField.getBoolean(parser);
                                                                                                             
                                                                                                             assertSame(mockOption, currentOption);
                                                                                                             assertTrue(tokens.contains(token));
                                                                                                             assertFalse(eatTheRest); // Should not set eatTheRest when option exists
                                                                                                         }

    @Test
                                                                 public void testFlatten_EmptyArguments() throws Exception {
                                                                     PosixParser parser = new PosixParser();
                                                                     Options options = new Options();
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod("flatten", Options.class, String[].class, boolean.class);
                                                                     flattenMethod.setAccessible(true);
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, new String[]{}, false);
                                                                     assertNotNull(result);
                                                                     assertEquals(0, result.length);
                                                                 }

    @Test
                                                                 public void testFlatten_SimpleArguments() throws Exception {
                                                                     Options options = new Options();
                                                                     PosixParser parser = new PosixParser();
                                                                     String[] args = {"arg1", "arg2", "arg3"};
                                                                     
                                                                     // Use reflection to access protected method
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", Options.class, String[].class, boolean.class);
                                                                     flattenMethod.setAccessible(true);
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                     
                                                                     assertArrayEquals(args, result);
                                                                 }

    @Test
                                                                 public void testFlatten_LongOptionWithEquals() throws Exception {
                                                                     Options options = new Options();
                                                                     options.addOption("option", true, "test option");
                                                                     PosixParser parser = new PosixParser();
                                                                     String[] args = {"--option=value"};
                                                                     
                                                                     // Use reflection to access protected method
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", Options.class, String[].class, boolean.class);
                                                                     flattenMethod.setAccessible(true);
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                     
                                                                     assertArrayEquals(new String[]{"--option", "value"}, result);
                                                                 }

    @Test
                                                                 public void testFlatten_LongOptionWithoutEquals() throws Exception {
                                                                     PosixParser parser = new PosixParser();
                                                                     Options options = new Options();
                                                                     String[] args = {"--option", "value"};
                                                                     
                                                                     // Use reflection to access protected method
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", 
                                                                         Options.class, 
                                                                         String[].class, 
                                                                         boolean.class
                                                                     );
                                                                     flattenMethod.setAccessible(true);
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                     
                                                                     assertArrayEquals(args, result);
                                                                 }

    @Test
                                                                 public void testFlatten_SingleHyphen() throws Exception {
                                                                     PosixParser parser = new PosixParser();
                                                                     Options options = new Options();
                                                                     String[] args = {"-"};
                                                                     
                                                                     // Use reflection to access protected method
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", 
                                                                         Options.class, 
                                                                         String[].class, 
                                                                         boolean.class
                                                                     );
                                                                     flattenMethod.setAccessible(true);
                                                                     
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                     assertArrayEquals(args, result);
                                                                 }

    @Test
                                                                 public void testFlatten_ShortOptionSingleChar() throws Exception {
                                                                     Options options = mock(Options.class);
                                                                     PosixParser parser = new PosixParser();
                                                                     when(options.hasOption("-a")).thenReturn(false);
                                                                     String[] args = {"-a"};
                                                                     
                                                                     // Use reflection to access protected method
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", Options.class, String[].class, boolean.class);
                                                                     flattenMethod.setAccessible(true);
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                     
                                                                     assertArrayEquals(new String[]{"-a"}, result);
                                                                 }

    @Test
                                                                 public void testFlatten_ShortOptionMultipleChars() throws Exception {
                                                                     // Create mock Options
                                                                     Options options = mock(Options.class);
                                                                     when(options.hasOption("-abc")).thenReturn(false);
                                                                     when(options.hasOption("-a")).thenReturn(false);
                                                                     when(options.hasOption("-b")).thenReturn(false);
                                                                     when(options.hasOption("-c")).thenReturn(false);
                                                                     
                                                                     // Create parser instance
                                                                     PosixParser parser = new PosixParser();
                                                                     
                                                                     // Get the protected flatten method via reflection
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", Options.class, String[].class, boolean.class);
                                                                     flattenMethod.setAccessible(true);
                                                                     
                                                                     String[] args = {"-abc"};
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                     assertArrayEquals(new String[]{"-a", "-b", "-c"}, result);
                                                                 }

    @Test
                                                                 public void testFlatten_StopAtNonOption() throws Exception {
                                                                     // Create necessary objects locally
                                                                     PosixParser parser = new PosixParser();
                                                                     Options options = new Options();
                                                                     
                                                                     String[] args = {"-a", "nonOption", "-b"};
                                                                     
                                                                     // Use reflection to access protected method
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", Options.class, String[].class, boolean.class);
                                                                     flattenMethod.setAccessible(true);
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, true);
                                                                     
                                                                     // Should stop processing at "nonOption"
                                                                     assertArrayEquals(new String[]{"-a", "nonOption"}, result);
                                                                 }

    @Test
                                                                 public void testFlatten_MixedArguments() throws Exception {
                                                                     // Create mock Options
                                                                     Options options = mock(Options.class);
                                                                     when(options.hasOption("-f")).thenReturn(false);
                                                                     when(options.hasOption("-v")).thenReturn(false);
                                                                     
                                                                     // Create parser instance
                                                                     PosixParser parser = new PosixParser();
                                                                     
                                                                     String[] args = {"--config=file.cfg", "-fv", "input.txt", "--", "-notAnOption"};
                                                                     
                                                                     // Use reflection to access protected flatten method
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", 
                                                                         Options.class, 
                                                                         String[].class, 
                                                                         boolean.class
                                                                     );
                                                                     flattenMethod.setAccessible(true);
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                     
                                                                     assertArrayEquals(
                                                                         new String[]{"--config", "file.cfg", "-f", "-v", "input.txt", "--", "-notAnOption"}, 
                                                                         result
                                                                     );
                                                                 }

    @Test
                                                                 public void testFlatten_NullArguments() throws Exception {
                                                                     PosixParser parser = new PosixParser();
                                                                     Options options = new Options();
                                                                     
                                                                     // Use reflection to access the protected method
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", 
                                                                         Options.class, 
                                                                         String[].class, 
                                                                         boolean.class
                                                                     );
                                                                     flattenMethod.setAccessible(true);
                                                                     flattenMethod.invoke(parser, options, null, false);
                                                                 }

    @Test
                                                                 public void testFlatten_NullOptions() throws Exception {
                                                                     PosixParser parser = new PosixParser();
                                                                     String[] arguments = new String[]{"-a"};
                                                                     
                                                                     // Get the protected flatten method via reflection
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", 
                                                                         Options.class, 
                                                                         String[].class, 
                                                                         boolean.class
                                                                     );
                                                                     flattenMethod.setAccessible(true);
                                                                     
                                                                     // Verify NullPointerException is thrown
                                                                     try {
                                                                         flattenMethod.invoke(parser, null, arguments, false);
                                                                         fail("Expected NullPointerException");
                                                                     } catch (InvocationTargetException e) {
                                                                         assertTrue(e.getCause() instanceof NullPointerException);
                                                                     }
                                                                 }

    @Test
                                                                 public void testFlatten_OptionWithEmptyValue() throws Exception {
                                                                     PosixParser parser = new PosixParser();
                                                                     Options options = new Options();
                                                                     String[] args = {"--option="};
                                                                     
                                                                     // Use reflection to access protected method
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", Options.class, String[].class, boolean.class);
                                                                     flattenMethod.setAccessible(true);
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                     
                                                                     assertArrayEquals(new String[]{"--option", ""}, result);
                                                                 }

    @Test
                                                                 public void testFlatten_ComplexOptionGrouping() throws Exception {
                                                                     // Create mock Options
                                                                     Options options = mock(Options.class);
                                                                     when(options.hasOption("-x")).thenReturn(false);
                                                                     when(options.hasOption("-y")).thenReturn(false);
                                                                     when(options.hasOption("-z")).thenReturn(false);
                                                                     
                                                                     // Create parser instance
                                                                     PosixParser parser = new PosixParser();
                                                                     
                                                                     // Get the protected flatten method via reflection
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", Options.class, String[].class, boolean.class);
                                                                     flattenMethod.setAccessible(true);
                                                                     
                                                                     String[] args = {"-xyz=value"};
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                     
                                                                     assertArrayEquals(new String[]{"-x", "-y", "-z=value"}, result);
                                                                 }

    @Test
                                                                 public void testFlatten_OptionWithMultipleEquals() throws Exception {
                                                                     PosixParser parser = new PosixParser();
                                                                     Options options = new Options();
                                                                     String[] args = {"--option=value=more"};
                                                                     
                                                                     // Use reflection to access protected method
                                                                     Method flattenMethod = PosixParser.class.getDeclaredMethod(
                                                                         "flatten", 
                                                                         Options.class, 
                                                                         String[].class, 
                                                                         boolean.class
                                                                     );
                                                                     flattenMethod.setAccessible(true);
                                                                     
                                                                     String[] result = (String[]) flattenMethod.invoke(parser, options, args, false);
                                                                     assertArrayEquals(new String[]{"--option", "value=more"}, result);
                                                                 }

    @Test
                                                                 public void testProcess_WithCurrentOptionHavingArg() {
                                                                     // Setup
                                                                     PosixParser parser = new PosixParser();
                                                                     List<String> tokens = new ArrayList<>();
                                                                     
                                                                     try {
                                                                         // Set tokens field in parser
                                                                         java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                         tokensField.setAccessible(true);
                                                                         tokensField.set(parser, tokens);
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                     
                                                                     Option mockOption = mock(Option.class);
                                                                     when(mockOption.hasArg()).thenReturn(true);
                                                                     when(mockOption.hasArgs()).thenReturn(false);
                                                                     
                                                                     try {
                                                                         java.lang.reflect.Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                         currentOptionField.setAccessible(true);
                                                                         currentOptionField.set(parser, mockOption);
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                     
                                                                     // Test
                                                                     try {
                                                                         java.lang.reflect.Method processMethod = PosixParser.class.getDeclaredMethod("process", String.class);
                                                                         processMethod.setAccessible(true);
                                                                         processMethod.invoke(parser, "testValue");
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                     
                                                                     // Verify
                                                                     assertEquals(1, tokens.size());
                                                                     assertEquals("testValue", tokens.get(0));
                                                                     
                                                                     // Verify currentOption was set to null
                                                                     try {
                                                                         java.lang.reflect.Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                         currentOptionField.setAccessible(true);
                                                                         assertNull(currentOptionField.get(parser));
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                 }

    @Test
                                                                 public void testProcess_WithCurrentOptionHavingArgs() {
                                                                     // Setup
                                                                     PosixParser parser = new PosixParser();
                                                                     List<String> tokens = new ArrayList<>();
                                                                     
                                                                     // Use reflection to set the private tokens field
                                                                     try {
                                                                         java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                         tokensField.setAccessible(true);
                                                                         tokensField.set(parser, tokens);
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                     
                                                                     Option mockOption = mock(Option.class);
                                                                     when(mockOption.hasArg()).thenReturn(false);
                                                                     when(mockOption.hasArgs()).thenReturn(true);
                                                                     
                                                                     try {
                                                                         java.lang.reflect.Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                         currentOptionField.setAccessible(true);
                                                                         currentOptionField.set(parser, mockOption);
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                     
                                                                     // Test - use reflection to call private process method
                                                                     try {
                                                                         java.lang.reflect.Method processMethod = PosixParser.class.getDeclaredMethod("process", String.class);
                                                                         processMethod.setAccessible(true);
                                                                         processMethod.invoke(parser, "testValue");
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                     
                                                                     // Verify
                                                                     assertEquals(1, tokens.size());
                                                                     assertEquals("testValue", tokens.get(0));
                                                                     
                                                                     // Verify currentOption remains unchanged
                                                                     try {
                                                                         java.lang.reflect.Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                         currentOptionField.setAccessible(true);
                                                                         assertNotNull(currentOptionField.get(parser));
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                 }

    @Test
                                                                 public void testProcess_WithNoCurrentOption() {
                                                                     // Setup
                                                                     PosixParser parser = new PosixParser();
                                                                     List<String> tokens;
                                                                     
                                                                     try {
                                                                         // Get tokens field
                                                                         java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                         tokensField.setAccessible(true);
                                                                         tokens = (List<String>) tokensField.get(parser);
                                                                         
                                                                         // Set currentOption to null
                                                                         java.lang.reflect.Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                         currentOptionField.setAccessible(true);
                                                                         currentOptionField.set(parser, null);
                                                                         
                                                                         // Get and invoke the private process method
                                                                         java.lang.reflect.Method processMethod = PosixParser.class.getDeclaredMethod("process", String.class);
                                                                         processMethod.setAccessible(true);
                                                                         processMethod.invoke(parser, "testValue");
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                         return;
                                                                     }
                                                                     
                                                                     // Verify
                                                                     assertEquals(2, tokens.size());
                                                                     assertEquals("--", tokens.get(0));
                                                                     assertEquals("testValue", tokens.get(1));
                                                                     
                                                                     // Verify eatTheRest was set to true
                                                                     try {
                                                                         java.lang.reflect.Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                         eatTheRestField.setAccessible(true);
                                                                         assertTrue((boolean) eatTheRestField.get(parser));
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                 }

    @Test
                                                                 public void testProcess_WithCurrentOptionHavingNoArgs() {
                                                                     // Setup
                                                                     PosixParser parser = new PosixParser();
                                                                     List<String> tokens = new ArrayList<>();
                                                                     
                                                                     // Use reflection to set the tokens field
                                                                     try {
                                                                         java.lang.reflect.Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                         tokensField.setAccessible(true);
                                                                         tokensField.set(parser, tokens);
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                     
                                                                     Option mockOption = mock(Option.class);
                                                                     when(mockOption.hasArg()).thenReturn(false);
                                                                     when(mockOption.hasArgs()).thenReturn(false);
                                                                     
                                                                     try {
                                                                         java.lang.reflect.Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                         currentOptionField.setAccessible(true);
                                                                         currentOptionField.set(parser, mockOption);
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                     
                                                                     // Test - use reflection to call private process method
                                                                     try {
                                                                         java.lang.reflect.Method processMethod = PosixParser.class.getDeclaredMethod("process", String.class);
                                                                         processMethod.setAccessible(true);
                                                                         processMethod.invoke(parser, "testValue");
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                     
                                                                     // Verify behavior falls into the else case
                                                                     assertEquals(2, tokens.size());
                                                                     assertEquals("--", tokens.get(0));
                                                                     assertEquals("testValue", tokens.get(1));
                                                                     
                                                                     // Verify eatTheRest was set to true
                                                                     try {
                                                                         java.lang.reflect.Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                         eatTheRestField.setAccessible(true);
                                                                         assertTrue((boolean) eatTheRestField.get(parser));
                                                                     } catch (Exception e) {
                                                                         fail("Reflection failed: " + e.getMessage());
                                                                     }
                                                                 }

    @Test
                                                                 public void testProcessOptionToken_WhenOptionDoesNotExistAndStopAtNonOptionFalse() throws Exception {
                                                                     // Setup
                                                                     String token = "-x";
                                                                     Options options = mock(Options.class);
                                                                     when(options.hasOption(token)).thenReturn(false);
                                                                     
                                                                     PosixParser parser = new PosixParser();
                                                                     Field optionsField = parser.getClass().getDeclaredField("options");
                                                                     optionsField.setAccessible(true);
                                                                     optionsField.set(parser, options);
                                                                     
                                                                     Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                     tokensField.setAccessible(true);
                                                                     @SuppressWarnings("unchecked")
                                                                     List<String> tokens = (List<String>) tokensField.get(parser);
                                                                     
                                                                     // Get and invoke the private method using reflection
                                                                     Method processOptionToken = parser.getClass().getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                                     processOptionToken.setAccessible(true);
                                                                     processOptionToken.invoke(parser, token, false);
                                                                     
                                                                     // Verify
                                                                     Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                                                     currentOptionField.setAccessible(true);
                                                                     assertNull(currentOptionField.get(parser));
                                                                     
                                                                     assertFalse(tokens.contains(token));
                                                                     
                                                                     Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                                                     eatTheRestField.setAccessible(true);
                                                                     assertFalse(eatTheRestField.getBoolean(parser));
                                                                 }

    @Test
                                                                 public void testProcessOptionToken_WhenOptionDoesNotExistAndStopAtNonOptionTrue() throws Exception {
                                                                     // Setup
                                                                     String token = "-x";
                                                                     Options options = mock(Options.class);
                                                                     when(options.hasOption(token)).thenReturn(false);
                                                                     
                                                                     PosixParser parser = new PosixParser();
                                                                     Field optionsField = parser.getClass().getDeclaredField("options");
                                                                     optionsField.setAccessible(true);
                                                                     optionsField.set(parser, options);
                                                                     
                                                                     Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                     tokensField.setAccessible(true);
                                                                     @SuppressWarnings("unchecked")
                                                                     List<String> tokens = (List<String>) tokensField.get(parser);
                                                                     
                                                                     // Get and invoke the private method using reflection
                                                                     Method processOptionToken = parser.getClass().getDeclaredMethod("processOptionToken", String.class, boolean.class);
                                                                     processOptionToken.setAccessible(true);
                                                                     processOptionToken.invoke(parser, token, true);
                                                                     
                                                                     // Verify
                                                                     Field currentOptionField = parser.getClass().getDeclaredField("currentOption");
                                                                     currentOptionField.setAccessible(true);
                                                                     assertNull(currentOptionField.get(parser));
                                                                     
                                                                     assertTrue(tokens.contains(token));
                                                                     
                                                                     Field eatTheRestField = parser.getClass().getDeclaredField("eatTheRest");
                                                                     eatTheRestField.setAccessible(true);
                                                                     assertTrue((Boolean) eatTheRestField.get(parser));
                                                                 }

    @Test
                        public void testProcessOptionToken_NonOptionWithStopAtNonOptionFalse_ShouldNotModifyState() throws Exception {
                            // Setup
                            PosixParser parser = new PosixParser();
                            Options options = mock(Options.class);
                            String token = "invalidToken";
                            
                            // Mock behavior - token doesn't exist in options
                            when(options.hasOption(token)).thenReturn(false);
                            
                            // Set initial state using reflection
                            Field optionsField = PosixParser.class.getDeclaredField("options");
                            optionsField.setAccessible(true);
                            optionsField.set(parser, options);
                            
                            Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                            eatTheRestField.setAccessible(true);
                            eatTheRestField.set(parser, false);
                            
                            Field tokensField = PosixParser.class.getDeclaredField("tokens");
                            tokensField.setAccessible(true);
                            tokensField.set(parser, new ArrayList<>());
                            
                            // Test with stopAtNonOption=false (should not enter else-if block)
                            Method processOptionTokenMethod = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                            processOptionTokenMethod.setAccessible(true);
                            processOptionTokenMethod.invoke(parser, token, false);
                            
                            // Verify behavior using reflection
                            assertFalse("eatTheRest should remain false", (boolean) eatTheRestField.get(parser));
                            assertTrue("tokens should remain empty", ((List<?>) tokensField.get(parser)).isEmpty());
                            
                            Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                            currentOptionField.setAccessible(true);
                            assertNull("currentOption should remain null", currentOptionField.get(parser));
                            
                            // Additional verification that we didn't interact with options beyond hasOption
                            verify(options, times(1)).hasOption(token);
                            verifyNoMoreInteractions(options);
                        }

    @Test
                   public void testProcessOptionToken_NonOptionWithStopAtNonOptionFalse() {
                       // Setup
                       PosixParser parser = new PosixParser();
                       Options options = mock(Options.class);
                       String token = "invalidOption";
                       
                       // Mock behavior
                       when(options.hasOption(token)).thenReturn(false);
                       
                       // Use reflection to set private fields since no constructor
                       try {
                           Field optionsField = PosixParser.class.getDeclaredField("options");
                           optionsField.setAccessible(true);
                           optionsField.set(parser, options);
                           
                           Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                           eatTheRestField.setAccessible(true);
                           eatTheRestField.set(parser, false); // initial value
                           
                           Field tokensField = PosixParser.class.getDeclaredField("tokens");
                           tokensField.setAccessible(true);
                           tokensField.set(parser, new ArrayList<String>());
                           
                           // Get and invoke the private method
                           Method processOptionTokenMethod = PosixParser.class.getDeclaredMethod(
                               "processOptionToken", String.class, boolean.class);
                           processOptionTokenMethod.setAccessible(true);
                           processOptionTokenMethod.invoke(parser, token, false);
                       } catch (Exception e) {
                           fail("Failed to set up test via reflection");
                       }
                       
                       // Verify
                       try {
                           Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                           eatTheRestField.setAccessible(true);
                           boolean eatTheRestValue = (boolean) eatTheRestField.get(parser);
                           
                           // Original behavior: eatTheRest should remain false
                           // Mutated behavior: eatTheRest would be set to false (same as stopAtNonOption)
                           // This assertion catches the mutant because it verifies no change occurred
                           assertFalse("eatTheRest should remain false when stopAtNonOption is false", 
                                      eatTheRestValue);
                           
                           // Also verify token was added
                           Field tokensField = PosixParser.class.getDeclaredField("tokens");
                           tokensField.setAccessible(true);
                           @SuppressWarnings("unchecked")
                           List<String> tokens = (List<String>) tokensField.get(parser);
                           assertEquals(1, tokens.size());
                           assertEquals(token, tokens.get(0));
                       } catch (Exception e) {
                           fail("Failed to verify test results");
                       }
                   }

    @Test
              public void testProcessOptionToken_NonOptionTokenWithStopAtNonOptionFalse() throws Exception {
                  // Setup
                  PosixParser parser = new PosixParser();
                  Options options = mock(Options.class);
                  String token = "nonOptionToken";
                  
                  // Mock behavior
                  when(options.hasOption(token)).thenReturn(false);
                  
                  // Set parser state using reflection
                  Field optionsField = PosixParser.class.getDeclaredField("options");
                  optionsField.setAccessible(true);
                  optionsField.set(parser, options);
                  
                  Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                  eatTheRestField.setAccessible(true);
                  eatTheRestField.set(parser, false);
                  
                  Field tokensField = PosixParser.class.getDeclaredField("tokens");
                  tokensField.setAccessible(true);
                  tokensField.set(parser, new ArrayList<>());
                  
                  // Call method with stopAtNonOption=false using reflection
                  Method processOptionToken = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
                  processOptionToken.setAccessible(true);
                  processOptionToken.invoke(parser, token, false);
                  
                  // Verify behavior - should NOT process the token
                  assertFalse("eatTheRest should remain false", (boolean) eatTheRestField.get(parser));
                  assertTrue("tokens should remain empty", ((List<?>) tokensField.get(parser)).isEmpty());
                  
                  // Also verify options interaction
                  verify(options).hasOption(token);
                  verifyNoMoreInteractions(options);
              }

    @Test
         public void testProcessOptionToken_EatTheRestBehavior() throws Exception {
             // Setup
             PosixParser parser = new PosixParser();
             Options options = mock(Options.class);
             
             // Set private options field using reflection
             Field optionsField = PosixParser.class.getDeclaredField("options");
             optionsField.setAccessible(true);
             optionsField.set(parser, options);
             
             String nonOptionToken = "nonOption";
             when(options.hasOption(nonOptionToken)).thenReturn(false);
             
             // Get private eatTheRest field for access
             Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
             eatTheRestField.setAccessible(true);
             
             // Get private tokens field for verification
             Field tokensField = PosixParser.class.getDeclaredField("tokens");
             tokensField.setAccessible(true);
             
             // Get private processOptionToken method
             Method processOptionToken = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
             processOptionToken.setAccessible(true);
             
             // Test case 1: Initial state (eatTheRest false)
             eatTheRestField.set(parser, false);
             processOptionToken.invoke(parser, nonOptionToken, true);
             // Original would set to true, mutant would flip false->true
             assertTrue((boolean) eatTheRestField.get(parser)); // Both pass
             
             // Test case 2: eatTheRest already true
             eatTheRestField.set(parser, true);
             processOptionToken.invoke(parser, nonOptionToken, true);
             // Original keeps true, mutant flips true->false
             assertTrue((boolean) eatTheRestField.get(parser)); // Fails for mutant
             
             // Verify token was added
             @SuppressWarnings("unchecked")
             List<String> tokens = (List<String>) tokensField.get(parser);
             assertTrue(tokens.contains(nonOptionToken));
         }

    @Test
    public void testProcessOptionToken_NonOptionWithStopAtNonOptionTrue() throws NoSuchFieldException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        // Setup
        PosixParser parser = new PosixParser();
        String token = "invalidOption";
        
        // Mock options to return false for hasOption
        Options optionsMock = mock(Options.class);
        when(optionsMock.hasOption(token)).thenReturn(false);
        
        // Use reflection to set private fields since no constructor
        Field optionsField = PosixParser.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        optionsField.set(parser, optionsMock);
        
        Field tokensField = PosixParser.class.getDeclaredField("tokens");
        tokensField.setAccessible(true);
        List<String> tokens = new ArrayList<>();
        tokensField.set(parser, tokens);
        
        // Test with stopAtNonOption = true
        Method method = PosixParser.class.getDeclaredMethod("processOptionToken", String.class, boolean.class);
        method.setAccessible(true);
        method.invoke(parser, token, true);
        
        // Verify eatTheRest was set to true
        Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
        eatTheRestField.setAccessible(true);
        assertTrue((boolean) eatTheRestField.get(parser));
        
        // Verify token was added to tokens list
        assertEquals(1, tokens.size());
        assertEquals(token, tokens.get(0));
        
        // Verify currentOption was not set (should remain null)
        Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
        currentOptionField.setAccessible(true);
        assertNull(currentOptionField.get(parser));
    }


}
