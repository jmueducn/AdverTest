package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                      public void testRenderWrappedText_NegativeWidth() throws Exception {
                                                                                                                          String text = "Should handle negative width";
                                                                                                                          java.lang.StringBuffer sb = new java.lang.StringBuffer();
                                                                                                                          org.apache.commons.cli.HelpFormatter helpFormatter = new org.apache.commons.cli.HelpFormatter();
                                                                                                                          
                                                                                                                          // Use reflection to access protected method
                                                                                                                          java.lang.reflect.Method renderWrappedText = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                                                                                                              "renderWrappedText", java.lang.StringBuffer.class, int.class, int.class, String.class);
                                                                                                                          renderWrappedText.setAccessible(true);
                                                                                                                          
                                                                                                                          // Invoke with negative width
                                                                                                                          String result = ((java.lang.StringBuffer)renderWrappedText.invoke(
                                                                                                                              helpFormatter, sb, -5, 2, text)).toString();
                                                                                                                          
                                                                                                                          // Verify the method handles negative width (implementation might ignore it or throw exception)
                                                                                                                          // Since we don't know the exact behavior, we'll just verify it doesn't throw exception
                                                                                                                          assertNotNull(result);
                                                                                                                      }

    @Test
                                                                 public void testRenderWrappedText_CustomNewLineCharacter() throws Exception {
                                                                     // Import required classes at the top of your test file:
                                                                     // import org.apache.commons.cli.HelpFormatter;
                                                                     
                                                                     HelpFormatter helpFormatter = new HelpFormatter();
                                                                     helpFormatter.setNewLine("\r\n");
                                                                     StringBuffer sb = new StringBuffer();
                                                                     String text = "This text should wrap";
                                                                     
                                                                     // Use reflection to access protected method
                                                                     Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                         "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                     renderWrappedText.setAccessible(true);
                                                                     StringBuffer resultBuffer = (StringBuffer)renderWrappedText.invoke(
                                                                         helpFormatter, sb, 10, 2, text);
                                                                     String result = resultBuffer.toString();
                                                                     
                                                                     assertEquals("This text\r\n  should\r\n  wrap", result);
                                                                 }

    @Test
                                                                 public void testRenderWrappedText_DetectsTrimMutant() throws Exception {
                                                                     // Setup
                                                                     org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                     // Access protected field via reflection
                                                                     java.lang.reflect.Field newLineField = org.apache.commons.cli.HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                                     newLineField.setAccessible(true);
                                                                     newLineField.set(formatter, "\n");
                                                                     
                                                                     StringBuffer sb = new StringBuffer();
                                                                     int width = 10;
                                                                     int nextLineTabStop = 4;
                                                                     
                                                                     // Create text that will trigger the specific condition:
                                                                     // - Length > width
                                                                     // - pos == nextLineTabStop - 1
                                                                     // - Contains whitespace that would be trimmed
                                                                     String text = "   1234567890  "; // 4 spaces + 10 chars + 2 spaces
                                                                     
                                                                     // The mutation would trim the spaces, so we need to verify they're preserved
                                                                     String expected = "   1234567890  "; // Should preserve all spaces
                                                                     
                                                                     // Execute using reflection to access protected method
                                                                     java.lang.reflect.Method method = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                                                         "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                     method.setAccessible(true);
                                                                     StringBuffer result = (StringBuffer) method.invoke(formatter, sb, width, nextLineTabStop, text);
                                                                     
                                                                     // Verify
                                                                     // The mutated version would trim to "1234567890"
                                                                     assertTrue("Mutant not detected - whitespace was trimmed", 
                                                                                result.toString().contains(expected));
                                                                     
                                                                     // Additional verification that the output contains the exact expected string
                                                                     assertEquals("Output should preserve all whitespace", 
                                                                                 expected, 
                                                                                 result.toString()); // Removed trim() to properly test whitespace preservation
                                                                 }

    @Test
                                                                 public void testRenderWrappedText_DetectsMutantAppend() throws Exception {
                                                                     // Setup
                                                                     HelpFormatter formatter = new HelpFormatter();
                                                                     StringBuffer sb = new StringBuffer();
                                                                     int width = 10;
                                                                     int nextLineTabStop = 5;
                                                                     
                                                                     // Create a text that will trigger the special condition:
                                                                     // - Length > width (11 > 10)
                                                                     // - Wrap position will be nextLineTabStop-1 (4)
                                                                     String text = "1234 67890a";
                                                                     
                                                                     // Expected behavior: should append full text "1234 67890a"
                                                                     // Mutated behavior: would append just "1"
                                                                     
                                                                     // Get the protected method via reflection
                                                                     Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                         "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                     renderWrappedText.setAccessible(true);
                                                                     
                                                                     // Execute
                                                                     renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
                                                                     String result = sb.toString();
                                                                     
                                                                     // Verify
                                                                     // Check the full string was appended (not just first character)
                                                                     assertTrue(result.contains("1234 67890a"));
                                                                     // Also verify the exact output matches expected
                                                                     assertEquals("1234 67890a", result);
                                                                     
                                                                     // Additional verification that we hit the right code path
                                                                     assertTrue(text.length() > width);
                                                                     // In a real test, we'd need to verify pos was nextLineTabStop-1,
                                                                     // but since findWrapPos is protected, we trust the test setup
                                                                 }

    @Test
                                                                 public void testRenderWrappedText_DetectsMutantAppendingEmptyString() throws Exception {
                                                                     // Setup
                                                                     org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                     
                                                                     // Use reflection to access the protected defaultNewLine field
                                                                     java.lang.reflect.Field defaultNewLineField = org.apache.commons.cli.HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                                     defaultNewLineField.setAccessible(true);
                                                                     defaultNewLineField.set(formatter, "\n");
                                                                     
                                                                     // Get the protected renderWrappedText method
                                                                     java.lang.reflect.Method renderWrappedText = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                                                         "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                     renderWrappedText.setAccessible(true);
                                                                     
                                                                     // Case 1: Test when pos == -1 (no wrap needed)
                                                                     StringBuffer sb1 = new StringBuffer();
                                                                     String text1 = "short text";
                                                                     String expected1 = "short text";
                                                                     StringBuffer result1 = (StringBuffer) renderWrappedText.invoke(formatter, sb1, 100, 4, text1);
                                                                     org.junit.Assert.assertEquals("Should contain full text when no wrapping needed", 
                                                                                                 expected1, result1.toString());
                                                                     
                                                                     // Case 2: Test when text.length() > width and pos == nextLineTabStop - 1
                                                                     StringBuffer sb2 = new StringBuffer();
                                                                     String text2 = "This is a long text that exceeds width and has special condition";
                                                                     // Set width small enough to trigger wrapping
                                                                     // and nextLineTabStop such that pos will equal nextLineTabStop-1
                                                                     StringBuffer result2 = (StringBuffer) renderWrappedText.invoke(formatter, sb2, 10, 5, text2);
                                                                     // Verify the result contains the actual text, not empty string
                                                                     org.junit.Assert.assertTrue("Should contain actual text in special condition case",
                                                                                               result2.toString().contains("This is a long text"));
                                                                     org.junit.Assert.assertFalse("Should not be empty", result2.toString().isEmpty());
                                                                     
                                                                     // Additional edge case: empty input
                                                                     StringBuffer sb3 = new StringBuffer();
                                                                     String text3 = "";
                                                                     StringBuffer result3 = (StringBuffer) renderWrappedText.invoke(formatter, sb3, 10, 4, text3);
                                                                     org.junit.Assert.assertEquals("Should handle empty string correctly", 
                                                                                                 "", result3.toString());
                                                                 }

    @Test
                                                                 public void testRenderWrappedText_NoWrap_NoExtraSpace() {
                                                                     // Setup
                                                                     HelpFormatter formatter = new HelpFormatter();
                                                                     try {
                                                                         // Set defaultNewLine through reflection since it's likely protected/private
                                                                         Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                                         defaultNewLineField.setAccessible(true);
                                                                         defaultNewLineField.set(formatter, "\n");
                                                                     } catch (Exception e) {
                                                                         fail("Failed to set defaultNewLine: " + e.getMessage());
                                                                     }
                                                                     
                                                                     StringBuffer sb = new StringBuffer();
                                                                     String text = "Short text that won't wrap";
                                                                     int width = 100; // Large enough to prevent wrapping
                                                                     int nextLineTabStop = 4;
                                                                     
                                                                     // Expected behavior - should append text without adding extra space
                                                                     String expected = text;
                                                                     
                                                                     // Execute using reflection
                                                                     StringBuffer result = null;
                                                                     try {
                                                                         Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                             "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                         renderWrappedText.setAccessible(true);
                                                                         result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
                                                                     } catch (Exception e) {
                                                                         fail("Failed to invoke renderWrappedText: " + e.getMessage());
                                                                         return;
                                                                     }
                                                                     
                                                                     // Verify
                                                                     assertEquals("Text should be appended without extra space", 
                                                                                 expected, 
                                                                                 result.toString());
                                                                     
                                                                     // Additional check for exact string length
                                                                     assertEquals("Result length should match input text length",
                                                                                 text.length(),
                                                                                 result.length());
                                                                 }

    @Test
                                                                 public void testRenderWrappedTextReturnsSameBuffer() throws Exception {
                                                                     // Setup
                                                                     HelpFormatter formatter = new HelpFormatter();
                                                                     // Access the protected defaultNewLine field using reflection
                                                                     Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                                     defaultNewLineField.setAccessible(true);
                                                                     defaultNewLineField.set(formatter, "\n");
                                                                     
                                                                     StringBuffer inputBuffer = new StringBuffer("Prefix ");
                                                                     String textToWrap = "This is a long text that should be wrapped";
                                                                     int width = 10;
                                                                     int nextLineTabStop = 4;
                                                                     
                                                                     // Expected result after wrapping
                                                                     String expected = "Prefix This is a\n    long\n    text\n    that\n    should\n    be\n    wrapped";
                                                                     
                                                                     // Get the protected method using reflection
                                                                     Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                         "renderWrappedText", 
                                                                         StringBuffer.class, 
                                                                         int.class, 
                                                                         int.class, 
                                                                         String.class
                                                                     );
                                                                     renderWrappedText.setAccessible(true);
                                                                     
                                                                     // Execute
                                                                     StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                                         formatter, 
                                                                         inputBuffer, 
                                                                         width, 
                                                                         nextLineTabStop, 
                                                                         textToWrap
                                                                     );
                                                                     
                                                                     // Verify
                                                                     // Check if returned buffer is the same object we passed in
                                                                     assertSame("Method should return the same StringBuffer instance", inputBuffer, result);
                                                                     
                                                                     // Check if content is properly wrapped
                                                                     assertEquals("Wrapped text should match expected output", expected, result.toString());
                                                                 }

    @Test
                                                                 public void testRenderWrappedText_ShouldNotReturnNull() throws Exception {
                                                                     // Setup
                                                                     org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                                                     StringBuffer sb = new StringBuffer();
                                                                     int width = 10;
                                                                     int nextLineTabStop = 4;
                                                                     
                                                                     // Get the protected method via reflection
                                                                     Method renderWrappedText = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                                                         "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                     renderWrappedText.setAccessible(true);
                                                                     
                                                                     // Test case 1: When pos == -1 (no wrap position found)
                                                                     String text1 = "short";
                                                                     StringBuffer result1 = (StringBuffer) renderWrappedText.invoke(
                                                                         formatter, sb, width, nextLineTabStop, text1);
                                                                     assertNotNull("Method should not return null when pos == -1", result1);
                                                                     assertEquals("Text should be properly appended", "short", result1.toString());
                                                                     
                                                                     // Reset buffer for next test
                                                                     sb = new StringBuffer();
                                                                     
                                                                     // Test case 2: When text.length() > width && pos == nextLineTabStop - 1
                                                                     String text2 = "longtextthatwontwrapbutmeetsspecialcondition";
                                                                     StringBuffer result2 = (StringBuffer) renderWrappedText.invoke(
                                                                         formatter, sb, width, nextLineTabStop, text2);
                                                                     assertNotNull("Method should not return null when special condition met", result2);
                                                                     assertTrue("Text should be properly appended", 
                                                                                result2.toString().contains(text2));
                                                                     
                                                                     // Additional test case with multiple lines
                                                                     sb = new StringBuffer();
                                                                     String text3 = "This is a longer text that should wrap multiple times";
                                                                     StringBuffer result3 = (StringBuffer) renderWrappedText.invoke(
                                                                         formatter, sb, width, nextLineTabStop, text3);
                                                                     assertNotNull("Method should not return null for multi-line text", result3);
                                                                     assertTrue("Should contain original text content", 
                                                                                result3.toString().contains("This is a longer text"));
                                                                 }

    @Test
                                                                 public void testRenderWrappedText_DetectsSpaceAppendingMutant() throws Exception {
                                                                     // Setup
                                                                     HelpFormatter formatter = new HelpFormatter();
                                                                     
                                                                     // Use reflection to set defaultNewLine since it might be protected/private
                                                                     Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                                     defaultNewLineField.setAccessible(true);
                                                                     defaultNewLineField.set(formatter, "\n");
                                                                     
                                                                     // Get protected methods via reflection
                                                                     Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                                                                         "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                     renderWrappedTextMethod.setAccessible(true);
                                                                     
                                                                     Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                                                         "findWrapPos", String.class, int.class, int.class);
                                                                     findWrapPosMethod.setAccessible(true);
                                                                 
                                                                     // Test case 1: When pos == -1 (no wrapping needed)
                                                                     StringBuffer sb1 = new StringBuffer();
                                                                     String text1 = "short text";
                                                                     StringBuffer result1 = (StringBuffer) renderWrappedTextMethod.invoke(formatter, sb1, 100, 4, text1);
                                                                     
                                                                     // Verify no extra space was added
                                                                     assertEquals("short text", result1.toString());
                                                                     assertEquals(text1.length(), result1.length());
                                                                     
                                                                     // Test case 2: When special condition is met (text.length() > width && pos == nextLineTabStop - 1)
                                                                     StringBuffer sb2 = new StringBuffer();
                                                                     String text2 = "longtextthatexceedswidthandhasspecialcondition";
                                                                     final int width = 10;
                                                                     final int nextLineTabStop = 5;
                                                                     
                                                                     // Create a subclass to test protected method behavior
                                                                     HelpFormatter testFormatter = new HelpFormatter() {
                                                                         @Override
                                                                         protected int findWrapPos(String text, int width, int startPos) {
                                                                             return nextLineTabStop - 1; // Return the special condition value
                                                                         }
                                                                     };
                                                                     
                                                                     StringBuffer result2 = (StringBuffer) renderWrappedTextMethod.invoke(testFormatter, sb2, width, nextLineTabStop, text2);
                                                                     
                                                                     // Verify no extra space was added
                                                                     assertEquals(text2, result2.toString());
                                                                     assertEquals(text2.length(), result2.length());
                                                                 }

    @Test
                                                         public void testRenderWrappedText_DetectsNextLineTabStopMinusOneCondition() throws Exception {
                                                             // Setup
                                                             HelpFormatter formatter = new HelpFormatter() {
                                                                 private int callCount = 0;
                                                                 
                                                                 @Override
                                                                 protected int findWrapPos(String text, int width, int startPos) {
                                                                     if (callCount++ == 0) {
                                                                         return 8; // First wrap position
                                                                     } else {
                                                                         return 4; // Second wrap position (nextLineTabStop - 1)
                                                                     }
                                                                 }
                                                             };
                                                             
                                                             // Use reflection to set defaultNewLine since it's likely protected
                                                             Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                             defaultNewLineField.setAccessible(true);
                                                             defaultNewLineField.set(formatter, "\n");
                                                             
                                                             // Create a scenario where:
                                                             // - text length > width
                                                             // - next wrap position is exactly nextLineTabStop - 1
                                                             int width = 10;
                                                             int nextLineTabStop = 5;
                                                             String text = "123456789 123456789"; // Will need to wrap
                                                             
                                                             // Execute using reflection to call protected renderWrappedText
                                                             Method renderMethod = HelpFormatter.class.getDeclaredMethod(
                                                                 "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                             renderMethod.setAccessible(true);
                                                             
                                                             StringBuffer sb = new StringBuffer();
                                                             StringBuffer result = (StringBuffer) renderMethod.invoke(formatter, sb, width, nextLineTabStop, text);
                                                             
                                                             // Verify
                                                             // Original behavior would append remaining text and return when pos == nextLineTabStop-1
                                                             // Mutant would continue processing
                                                             String output = result.toString();
                                                             String[] lines = output.split("\n");
                                                             
                                                             // Original should have 2 lines (initial wrap + termination at nextLineTabStop-1)
                                                             // Mutant would have 3+ lines
                                                             assertTrue("Should terminate early when pos equals nextLineTabStop-1", lines.length <= 2);
                                                             
                                                             // Additional verification that the remaining text was appended
                                                             assertTrue("Should contain remaining text", output.contains("123456789"));
                                                         }

    @Test
                                                    public void testRenderWrappedText_DetectsMutantWhenTextShorterThanWidth() throws Exception {
                                                        // Setup
                                                        HelpFormatter formatter = new HelpFormatter();
                                                        
                                                        // Create a subclass to access protected methods
                                                        class TestableHelpFormatter extends HelpFormatter {
                                                            public StringBuffer testRenderWrappedText(StringBuffer sb, int width, int nextLineTabStop, String text) {
                                                                return renderWrappedText(sb, width, nextLineTabStop, text);
                                                            }
                                                            
                                                            public int testFindWrapPos(String text, int width, int startPos) {
                                                                return findWrapPos(text, width, startPos);
                                                            }
                                                        }
                                                        
                                                        TestableHelpFormatter spyFormatter = spy(new TestableHelpFormatter());
                                                        spyFormatter.defaultNewLine = "\n";
                                                        StringBuffer sb = new StringBuffer();
                                                        int width = 10;
                                                        int nextLineTabStop = 5;
                                                        
                                                        // Create text that's shorter than width but where pos equals tab stop - 1
                                                        String text = "1234"; // Length 4 < width 10
                                                        
                                                        // Mock findWrapPos to return tab stop - 1 (4) on second call
                                                        doReturn(-1, nextLineTabStop - 1).when(spyFormatter)
                                                            .testFindWrapPos(anyString(), eq(width), eq(0));
                                                        
                                                        // Execute
                                                        StringBuffer result = spyFormatter.testRenderWrappedText(sb, width, nextLineTabStop, text);
                                                        
                                                        // Verify - original would continue wrapping, mutant would stop
                                                        String expected = text + "\n    " + text;
                                                        assertNotEquals("Mutant not detected - output matches original", 
                                                                       expected, result.toString());
                                                        
                                                        // Additional verification that we hit the condition
                                                        verify(spyFormatter, times(2)).testFindWrapPos(anyString(), eq(width), eq(0));
                                                    }

    @Test
                                               public void testRenderWrappedTextPreservesCase() throws Exception {
                                                   // Setup
                                                   HelpFormatter formatter = new HelpFormatter();
                                                   formatter.setNewLine("\n");
                                                   
                                                   // Get the protected method via reflection
                                                   Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                       "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                   renderWrappedText.setAccessible(true);
                                               
                                                   // Test case 1: Text doesn't need wrapping (pos == -1)
                                                   StringBuffer sb1 = new StringBuffer();
                                                   String shortText = "short text";
                                                   StringBuffer result1 = (StringBuffer) renderWrappedText.invoke(formatter, sb1, 20, 0, shortText);
                                                   assertEquals("Text case should be preserved when no wrapping needed", 
                                                               shortText, 
                                                               result1.toString().trim());
                                                   
                                                   // Test case 2: Text length > width and pos == nextLineTabStop-1
                                                   StringBuffer sb2 = new StringBuffer();
                                                   String longText = "ThisIsALongTextThatExceedsWidthAndWillTriggerTheCondition";
                                                   // Set width small enough to force wrapping, and nextLineTabStop to make pos equal to it-1
                                                   StringBuffer result2 = (StringBuffer) renderWrappedText.invoke(formatter, sb2, 10, 5, longText);
                                                   // Extract the last line (where the mutation would occur)
                                                   String[] lines = result2.toString().split("\n");
                                                   String lastLine = lines[lines.length - 1];
                                                   assertFalse("Text case should be preserved", 
                                                              lastLine.equals(lastLine.toUpperCase()));
                                                   
                                                   // Additional edge case: mixed case text
                                                   StringBuffer sb3 = new StringBuffer();
                                                   String mixedCaseText = "MiXeD cAsE tExT";
                                                   StringBuffer result3 = (StringBuffer) renderWrappedText.invoke(formatter, sb3, 5, 2, mixedCaseText);
                                                   String[] mixedLines = result3.toString().split("\n");
                                                   for (String line : mixedLines) {
                                                       assertEquals("Each line should preserve original case",
                                                                   line.trim(), 
                                                                   mixedCaseText.substring(mixedCaseText.indexOf(line.trim()), 
                                                                                        mixedCaseText.indexOf(line.trim()) + line.trim().length()));
                                                   }
                                               }

    @Test
                                          public void testRenderWrappedText_DetectSpaceReplacementMutant() throws Exception {
                                              // Setup
                                              HelpFormatter formatter = new HelpFormatter();
                                              StringBuffer sb = new StringBuffer();
                                              int width = 10;
                                              int nextLineTabStop = 5;
                                              
                                              // Create text that will trigger the special case:
                                              // - Length > width (11 > 10)
                                              // - pos will equal nextLineTabStop - 1 (4)
                                              // - Contains spaces that would be mutated
                                              String text = "1234 567 89";
                                              
                                              // Use reflection to access protected method
                                              Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                  "renderWrappedText", 
                                                  StringBuffer.class, 
                                                  int.class, 
                                                  int.class, 
                                                  String.class
                                              );
                                              renderWrappedText.setAccessible(true);
                                              
                                              // Execute
                                              StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                  formatter, 
                                                  sb, 
                                                  width, 
                                                  nextLineTabStop, 
                                                  text
                                              );
                                              
                                              // Verify - mutant would replace space with underscore
                                              String expected = "1234 567 89";  // Original should preserve spaces
                                              assertEquals("Spaces should be preserved in output", 
                                                          expected, 
                                                          result.toString());
                                              
                                              // Additional verification that we hit the right code path
                                              assertTrue("Test should verify the special case path was taken",
                                                        text.length() > width);
                                          }

    @Test
                                     public void testRenderWrappedText_DetectsTextTruncationMutant() throws Exception {
                                         // Setup
                                         HelpFormatter formatter = new HelpFormatter();
                                         // Access protected field via reflection
                                         Field newLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                         newLineField.setAccessible(true);
                                         newLineField.set(formatter, "\n");
                                         
                                         StringBuffer sb = new StringBuffer();
                                         int width = 10;
                                         int nextLineTabStop = 4;
                                         
                                         // Create test text
                                         String text = "1234567890 1234567890"; // 21 chars total
                                         
                                         // Create a subclass to access protected methods
                                         class TestableHelpFormatter extends HelpFormatter {
                                             public StringBuffer testRenderWrappedText(StringBuffer sb, int width, int nextLineTabStop, String text) {
                                                 return renderWrappedText(sb, width, nextLineTabStop, text);
                                             }
                                             
                                             @Override
                                             protected int findWrapPos(String text, int width, int startPos) {
                                                 // Mock behavior: first call returns 10, second returns -1
                                                 if (text.startsWith("1234567890 1234567890")) {
                                                     return 10;
                                                 }
                                                 return -1;
                                             }
                                         }
                                         
                                         TestableHelpFormatter testFormatter = new TestableHelpFormatter();
                                         
                                         // Execute
                                         StringBuffer result = testFormatter.testRenderWrappedText(sb, width, nextLineTabStop, text);
                                         
                                         // Verify
                                         String expected = "1234567890\n    1234567890";
                                         assertEquals("Mutant should be detected by full text comparison", 
                                                    expected, 
                                                    result.toString());
                                         
                                         // Additional verification that the full text was appended
                                         assertTrue("Output should contain full padded text",
                                                   result.toString().contains("    1234567890"));
                                     }

    @Test
                                public void testRenderWrappedText_DetectsTextDuplicationMutant() throws Exception {
                                    // Setup
                                    HelpFormatter formatter = new HelpFormatter();
                                    Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                    defaultNewLineField.setAccessible(true);
                                    defaultNewLineField.set(formatter, "\n");
                                    
                                    StringBuffer sb = new StringBuffer();
                                    int width = 10;
                                    int nextLineTabStop = 5;
                                    
                                    // Create text that will trigger the special case:
                                    // - Length > width (11 > 10)
                                    // - Wrap position will be exactly nextLineTabStop - 1 (4)
                                    String text = "1234 567890";
                                    
                                    // Get the protected method via reflection
                                    Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                        "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                    renderWrappedText.setAccessible(true);
                                    
                                    // Execute
                                    StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                        formatter, sb, width, nextLineTabStop, text);
                                    
                                    // Verify
                                    // Original behavior should append text once, mutant would append twice
                                    String expected = "1234\n     567890";
                                    assertEquals("Text should not be duplicated", expected, result.toString());
                                    
                                    // Additional verification of length to catch mutant
                                    assertEquals("Result length should match expected", expected.length(), result.length());
                                }

    @Test
                           public void testRenderWrappedTextDetectsReverseMutant() throws Exception {
                               // Setup
                               HelpFormatter formatter = new HelpFormatter();
                               
                               // Use reflection to access the protected field
                               Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                               defaultNewLineField.setAccessible(true);
                               defaultNewLineField.set(formatter, "\n");
                               
                               // Get the protected method via reflection
                               Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                   "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                               renderWrappedText.setAccessible(true);
                           
                               // Test case 1: Single line text (tests first return statement)
                               StringBuffer sb1 = new StringBuffer();
                               String text1 = "Short text";
                               StringBuffer result1 = (StringBuffer) renderWrappedText.invoke(formatter, sb1, 50, 4, text1);
                               assertEquals("Original text should be returned as-is", 
                                           "Short text", 
                                           result1.toString());
                               assertSame("Should return same StringBuffer instance", sb1, result1);
                               
                               // Test case 2: Multi-line text (tests second return statement)
                               StringBuffer sb2 = new StringBuffer();
                               String text2 = "This is a longer text that should wrap to multiple lines when the width is small";
                               StringBuffer result2 = (StringBuffer) renderWrappedText.invoke(formatter, sb2, 20, 4, text2);
                               String expected2 = "This is a longer\n    text that should\n    wrap to multiple\n    lines when the\n    width is small";
                               assertEquals("Text should be properly wrapped", expected2, result2.toString());
                               assertSame("Should return same StringBuffer instance", sb2, result2);
                               
                               // Test case 3: Edge case (tests third return statement)
                               StringBuffer sb3 = new StringBuffer();
                               String text3 = "A verylongwordthatexceedswidth and some more";
                               StringBuffer result3 = (StringBuffer) renderWrappedText.invoke(formatter, sb3, 10, 4, text3);
                               String expected3 = "A\n    verylongwordthatexceedswidth\n    and some\n    more";
                               assertEquals("Edge case should be handled properly", expected3, result3.toString());
                               assertSame("Should return same StringBuffer instance", sb3, result3);
                           }

    @Test
                      public void testRenderWrappedText_NoWrapNeeded_ShouldNotAddExtraNewline() throws Exception {
                          // Setup
                          HelpFormatter formatter = new HelpFormatter();
                          // Use reflection to set the protected field
                          Field newLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                          newLineField.setAccessible(true);
                          newLineField.set(formatter, "\n");
                          
                          StringBuffer sb = new StringBuffer();
                          String text = "short text";  // Text that doesn't need wrapping
                          int width = 100;  // Large enough to prevent wrapping
                          int nextLineTabStop = 4;
                          
                          // Get the protected method using reflection
                          Method renderMethod = HelpFormatter.class.getDeclaredMethod(
                              "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                          renderMethod.setAccessible(true);
                          
                          // Execute
                          StringBuffer result = (StringBuffer) renderMethod.invoke(formatter, sb, width, nextLineTabStop, text);
                          
                          // Verify
                          // Original behavior: should just return the text without extra newline
                          // Mutant behavior: would add extra newline at end
                          assertEquals("short text", result.toString());
                          assertEquals(text.length(), result.length());  // Extra assertion to ensure no newline
                      }

    @Test
              public void testRenderWrappedText_SpecialCase_ShouldNotAddExtraNewline() throws Exception {
                  // Setup
                  HelpFormatter formatter = new HelpFormatter() {
                      // Expose protected method for testing
                      @Override
                      public int findWrapPos(String text, int width, int startPos) {
                          return 3; // Mocked return value for this test case
                      }
                  };
                  
                  formatter.setNewLine("\n");
                  StringBuffer sb = new StringBuffer();
                  // Create text that triggers special case:
                  // length > width AND pos == nextLineTabStop - 1
                  String text = "1234567890";
                  int width = 5;  // Text is longer than width
                  int nextLineTabStop = 4;  // Will cause pos to be 3 (nextLineTabStop-1)
                  
                  // Use reflection to access protected method
                  Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                      "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                  renderWrappedText.setAccessible(true);
                  
                  // Execute
                  StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                      formatter, sb, width, nextLineTabStop, text);
                  
                  // Verify
                  // Original behavior: should return full text without extra newline
                  // Mutant behavior: would add extra newline at end
                  assertEquals("1234567890", result.toString());
                  assertEquals(text.length(), result.length());
              }

    @Test
         public void testRenderWrappedText_ReturnsSameBufferInstance() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             
             // Use reflection to set protected field
             Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
             defaultNewLineField.setAccessible(true);
             defaultNewLineField.set(formatter, "\n");
             
             // Test case that requires multiple wraps
             StringBuffer sb = new StringBuffer();
             String text = "This is a long text that needs to be wrapped multiple times to test the buffer accumulation";
             int width = 20;
             int nextLineTabStop = 4;
             
             // Get the protected method using reflection
             Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                 "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
             renderWrappedText.setAccessible(true);
             
             // Execute
             StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
             
             // Verify same instance is returned
             assertSame("Method should return the same StringBuffer instance", sb, result);
             
             // Verify content contains all wrapped lines
             String output = result.toString();
             assertTrue("Output should contain first part of text", output.contains("This is a long"));
             assertTrue("Output should contain second part of text", output.contains("text that needs"));
             assertTrue("Output should contain third part of text", output.contains("to be wrapped"));
             
             // Count newlines to verify wrapping occurred
             long lineCount = output.chars().filter(ch -> ch == '\n').count();
             assertTrue("Should have multiple lines", lineCount > 1);
         }

    @Test
    public void testRenderWrappedText_DetectsRtrimMutation() throws Exception {
        // Setup
        HelpFormatter formatter = new HelpFormatter();
        // Use reflection to set the protected defaultNewLine field
        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
        defaultNewLineField.setAccessible(true);
        defaultNewLineField.set(formatter, "\n");
        
        StringBuffer sb = new StringBuffer();
        int width = 10;
        int nextLineTabStop = 4;
        
        // Input text with trailing whitespace that would be wrapped
        String text = "Hello world   ";  // Note trailing spaces
        
        // Expected behavior - trailing spaces should be trimmed
        String expected = "Hello\n    world";  // Note no trailing spaces after "Hello"
        
        // Get the protected method via reflection
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
        renderWrappedText.setAccessible(true);
        
        // Execute
        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
            formatter, sb, width, nextLineTabStop, text);
        
        // Verify
        String output = result.toString();
        // Check the first line doesn't end with whitespace
        assertFalse("First line should not have trailing whitespace", 
                   output.substring(0, output.indexOf('\n')).endsWith(" "));
        // Check the exact output matches expected
        assertEquals("Wrapped text should match expected format", expected, output);
        
        // Additional check for any line having trailing whitespace
        String[] lines = output.split("\n");
        for (String line : lines) {
            assertFalse("No line should have trailing whitespace", 
                       line.length() > 0 && line.charAt(line.length()-1) == ' ');
        }
    }


}
