package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                               public void testRenderWrappedText_SingleWrap() throws Exception {
                                                                                   // Create HelpFormatter instance
                                                                                   HelpFormatter formatter = new HelpFormatter();
                                                                                   
                                                                                   // Set defaultNewLine using reflection
                                                                                   try {
                                                                                       java.lang.reflect.Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                                                       defaultNewLineField.setAccessible(true);
                                                                                       defaultNewLineField.set(formatter, "\n");
                                                                                   } catch (Exception e) {
                                                                                       fail("Failed to set defaultNewLine via reflection: " + e.getMessage());
                                                                                   }
                                                                                   
                                                                                   StringBuffer sb = new StringBuffer();
                                                                                   String text = "This is a longer text that needs wrapping";
                                                                                   
                                                                                   // Get and invoke the protected method using reflection
                                                                                   try {
                                                                                       java.lang.reflect.Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                                           "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                                       renderWrappedText.setAccessible(true);
                                                                                       renderWrappedText.invoke(formatter, sb, 10, 2, text);
                                                                                       
                                                                                       String expected = "This is a\n  longer\n  text\n  that\n  needs\n  wrapping";
                                                                                       assertEquals(expected, sb.toString());
                                                                                   } catch (Exception e) {
                                                                                       fail("Failed to invoke renderWrappedText via reflection: " + e.getMessage());
                                                                                   }
                                                                               }

    @Test
                                                                          public void testRenderWrappedText_WhenNextLineTabStopEqualsWidth_ShouldResetTabStop() throws Exception {
                                                                              // Setup
                                                                              HelpFormatter formatter = new HelpFormatter();
                                                                              formatter.setNewLine("\n"); // Ensure consistent line endings
                                                                              StringBuffer sb = new StringBuffer();
                                                                              int width = 10;
                                                                              int nextLineTabStop = 10; // Equal to width - boundary case
                                                                              String text = "This is a long text that needs to be wrapped properly";
                                                                              
                                                                              // Get the protected method via reflection
                                                                              Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                                  "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                              renderWrappedText.setAccessible(true);
                                                                              
                                                                              // Execute
                                                                              StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                                                  formatter, sb, width, nextLineTabStop, text);
                                                                              
                                                                              // Verify the padding was reset to 1 (original behavior)
                                                                              // We can verify this by checking the indentation of subsequent lines
                                                                              String[] lines = result.toString().split("\n");
                                                                              if (lines.length > 1) {
                                                                                  // Second line should be indented by 1 space (not 10)
                                                                                  assertTrue("Second line should start with 1 space", 
                                                                                            lines[1].startsWith(" "));
                                                                                  assertEquals("Second line should have exactly 1 space indent", 
                                                                                              1, lines[1].indexOf(lines[1].trim()));
                                                                              }
                                                                              
                                                                              // Additional verification that text was properly wrapped
                                                                              for (String line : lines) {
                                                                                  assertTrue("No line should exceed width", 
                                                                                            line.length() <= width || line.trim().length() <= width);
                                                                              }
                                                                          }

    @Test
                                                                     public void testRenderWrappedText_NextLineTabStopGreaterThanWidth() throws Exception {
                                                                         // Setup
                                                                         HelpFormatter formatter = new HelpFormatter();
                                                                         // Use reflection to set the protected defaultNewLine field
                                                                         Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                                         defaultNewLineField.setAccessible(true);
                                                                         defaultNewLineField.set(formatter, "\n");
                                                                         
                                                                         // Create a long text that will need wrapping
                                                                         String text = "This is a very long text that needs to be wrapped to fit within the specified width";
                                                                         int width = 10;
                                                                         int nextLineTabStop = 15; // Greater than width
                                                                         
                                                                         // Get the protected method via reflection
                                                                         Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                             "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                         renderWrappedText.setAccessible(true);
                                                                         
                                                                         // Call method using reflection
                                                                         StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                                             formatter, new StringBuffer(), width, nextLineTabStop, text);
                                                                         
                                                                         // Verify the text was wrapped (not empty and contains newlines)
                                                                         assertNotNull(result);
                                                                         assertFalse(result.toString().isEmpty());
                                                                         assertTrue(result.toString().contains("\n"));
                                                                         
                                                                         // Verify the method didn't infinite loop by checking reasonable line lengths
                                                                         String[] lines = result.toString().split("\n");
                                                                         for (String line : lines) {
                                                                             assertTrue(line.length() <= width + nextLineTabStop);
                                                                         }
                                                                         
                                                                         // Verify subsequent lines have proper indentation (1 space, since nextLineTabStop should have been reset)
                                                                         for (int i = 1; i < lines.length; i++) {
                                                                             assertTrue(lines[i].startsWith(" ")); // Should be indented with 1 space
                                                                             assertFalse(lines[i].startsWith("               ")); // Should NOT be indented with 15 spaces
                                                                         }
                                                                     }

    @Test
                                                                public void testRenderWrappedText_NextLineTabStopGreaterThanWidth1() throws Exception {
                                                                    // Setup
                                                                    HelpFormatter formatter = new HelpFormatter();
                                                                    // Use reflection to set the protected defaultNewLine field
                                                                    Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                                    defaultNewLineField.setAccessible(true);
                                                                    defaultNewLineField.set(formatter, "\n");
                                                                    
                                                                    // Create a case where nextLineTabStop >= width
                                                                    int width = 10;
                                                                    int nextLineTabStop = 15; // Greater than width
                                                                    String text = "This is a long text that needs to be wrapped properly";
                                                                    StringBuffer sb = new StringBuffer();
                                                                    
                                                                    // Get the protected method via reflection
                                                                    Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                        "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                                    renderWrappedText.setAccessible(true);
                                                                    
                                                                    // Execute
                                                                    StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
                                                                    
                                                                    // Verify
                                                                    String output = result.toString();
                                                                    String[] lines = output.split("\n");
                                                                    
                                                                    // Check that we have multiple lines (wrapping occurred)
                                                                    assertTrue(lines.length > 1);
                                                                    
                                                                    // Check that subsequent lines are indented with 1 space (not nextLineTabStop spaces)
                                                                    for (int i = 1; i < lines.length; i++) {
                                                                        assertTrue(lines[i].startsWith(" "));
                                                                        assertTrue(lines[i].length() - lines[i].trim().length() == 1);
                                                                    }
                                                                    
                                                                    // Verify no infinite loop occurred (test completes)
                                                                }

    @Test
                                                           public void testRenderWrappedText_DetectsNextLineTabStopMutation() throws Exception {
                                                               // Setup
                                                               HelpFormatter formatter = new HelpFormatter();
                                                               // Use reflection to set the protected field
                                                               Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                               defaultNewLineField.setAccessible(true);
                                                               defaultNewLineField.set(formatter, "\n");
                                                               
                                                               StringBuffer sb = new StringBuffer();
                                                               int width = 10;
                                                               int nextLineTabStop = 20; // This will trigger the mutated condition
                                                               String text = "This is a long text that needs to be wrapped multiple times to test the padding behavior";
                                                               
                                                               // Get the protected method via reflection
                                                               Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                                   "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                               renderWrappedText.setAccessible(true);
                                                               
                                                               // Execute
                                                               StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
                                                               
                                                               // Verify the padding was properly set (should be at least 1 space)
                                                               // Look for lines after the first one to check padding
                                                               String output = result.toString();
                                                               String[] lines = output.split("\n");
                                                               
                                                               // First line shouldn't have padding
                                                               assertTrue(lines[0].startsWith("This is a"));
                                                               
                                                               // Subsequent lines should have padding (at least 1 space)
                                                               for (int i = 1; i < lines.length; i++) {
                                                                   assertTrue("Line should start with padding", 
                                                                             lines[i].startsWith(" ") || lines[i].isEmpty());
                                                                   if (!lines[i].isEmpty()) {
                                                                       assertTrue("Padding should be at least 1 space", 
                                                                                 lines[i].charAt(0) == ' ');
                                                                   }
                                                               }
                                                               
                                                               // Additional check for the specific mutation case
                                                               // The mutated version would have no padding (nextLineTabStop=0)
                                                               assertNotEquals("", lines[1].replaceAll("[^ ].*", ""));
                                                           }

    @Test
                                                      public void testRenderWrappedText_NextLineTabStopReset() throws Exception {
                                                          // Setup
                                                          HelpFormatter formatter = new HelpFormatter();
                                                          // Use reflection to set the protected field
                                                          Field newLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                          newLineField.setAccessible(true);
                                                          newLineField.set(formatter, "\n");
                                                          
                                                          // Create a scenario where nextLineTabStop >= width
                                                          int width = 10;
                                                          int nextLineTabStop = 15; // Greater than width
                                                          String text = "This is a long text that needs to be wrapped properly";
                                                          StringBuffer sb = new StringBuffer();
                                                          
                                                          // Use reflection to call the protected method
                                                          Method renderMethod = HelpFormatter.class.getDeclaredMethod(
                                                              "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                          renderMethod.setAccessible(true);
                                                          StringBuffer result = (StringBuffer) renderMethod.invoke(formatter, sb, width, nextLineTabStop, text);
                                                          
                                                          // Verify the indentation of wrapped lines
                                                          String[] lines = result.toString().split("\n");
                                                          
                                                          // First line shouldn't be indented
                                                          assertFalse(lines[0].startsWith(" "));
                                                          
                                                          // Subsequent lines should be indented with 1 space (original behavior)
                                                          // If the mutation is present, they would be indented with 'width' spaces
                                                          for (int i = 1; i < lines.length; i++) {
                                                              assertTrue("Line " + i + " should be indented with 1 space", 
                                                                        lines[i].startsWith(" "));
                                                              assertFalse("Line " + i + " should not be indented with full width",
                                                                         lines[i].startsWith(String.format("%" + width + "s", "")));
                                                          }
                                                          
                                                          // Also verify no infinite loop occurred
                                                          assertTrue(lines.length > 1); // Ensure wrapping happened
                                                          assertTrue(lines.length < 10); // Sanity check for infinite loop
                                                      }

    @Test
                                                 public void testRenderWrappedText_DetectsNextLineTabStopMutation1() throws Exception {
                                                     // Setup
                                                     HelpFormatter formatter = new HelpFormatter();
                                                     // Use reflection to set the protected field
                                                     Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                     defaultNewLineField.setAccessible(true);
                                                     defaultNewLineField.set(formatter, "\n"); // Set newline for predictable output
                                                     
                                                     // Create input where nextLineTabStop >= width to trigger the condition
                                                     StringBuffer sb = new StringBuffer();
                                                     int width = 10;
                                                     int nextLineTabStop = 15; // Larger than width
                                                     String text = "This is a long text that needs to be wrapped properly";
                                                     
                                                     // Expected padding would be based on 1 space (original behavior)
                                                     String expectedPadding = " "; // createPadding(1)
                                                     String expectedFirstLine = "This is a\n"; // Wrapped at width 10
                                                     String expectedSecondLine = expectedPadding + "long text\n"; // Should have 1 space padding
                                                     
                                                     // Get the protected method via reflection
                                                     Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                         "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                     renderWrappedText.setAccessible(true);
                                                     
                                                     // Execute
                                                     StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                         formatter, sb, width, nextLineTabStop, text);
                                                     
                                                     // Verify
                                                     String output = result.toString();
                                                     String[] lines = output.split("\n");
                                                     
                                                     // Check that second line has correct padding (1 space)
                                                     assertTrue("Second line should have proper padding", 
                                                                lines[1].startsWith(expectedPadding));
                                                     
                                                     // Check that the padding is only 1 character (would be 15 in mutant)
                                                     assertEquals("Padding length should be 1", 
                                                                  1, lines[1].length() - lines[1].trim().length());
                                                     
                                                     // Additional verification for the complete output
                                                     assertTrue("Output should start with first line", 
                                                                output.startsWith(expectedFirstLine));
                                                     assertTrue("Output should contain properly padded second line", 
                                                                output.contains(expectedSecondLine));
                                                 }

    @Test
                                            public void testRenderWrappedText_NextLineTabStopReset1() throws Exception {
                                                // Setup
                                                HelpFormatter formatter = new HelpFormatter();
                                                // Use reflection to set the protected field
                                                Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                                defaultNewLineField.setAccessible(true);
                                                defaultNewLineField.set(formatter, "\n");
                                                
                                                // Create a scenario where nextLineTabStop >= width
                                                int width = 10;
                                                int nextLineTabStop = 15; // Greater than width
                                                String text = "This is a long text that needs to be wrapped properly";
                                                StringBuffer sb = new StringBuffer();
                                                
                                                // Get the protected method via reflection
                                                Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                                    "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                                renderWrappedText.setAccessible(true);
                                                
                                                // Execute
                                                StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                                    formatter, sb, width, nextLineTabStop, text);
                                                
                                                // Verify the padding was properly reset (not negative)
                                                // Look for the second line which should have padding
                                                String[] lines = result.toString().split("\n");
                                                if (lines.length > 1) {
                                                    String secondLine = lines[1];
                                                    // Check that padding is valid (not negative)
                                                    assertTrue("Second line should start with padding", 
                                                        secondLine.startsWith(" ")); // Should be at least one space
                                                    assertTrue("Padding should be reasonable length", 
                                                        secondLine.indexOf(text.trim()) > 0); // Text should be after padding
                                                }
                                                
                                                // Additional verification that the output is properly wrapped
                                                for (String line : lines) {
                                                    assertTrue("Line should not exceed width", 
                                                        line.length() <= width || line.trim().length() <= width);
                                                }
                                            }

    @Test
                                       public void testRenderWrappedText_NextLineTabStopAdjustment() throws Exception {
                                           // Setup
                                           HelpFormatter formatter = new HelpFormatter();
                                           // Use reflection to set the protected field
                                           Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                           defaultNewLineField.setAccessible(true);
                                           defaultNewLineField.set(formatter, "\n"); // Ensure consistent newline for testing
                                           
                                           // Create a scenario where nextLineTabStop >= width
                                           int width = 10;
                                           int nextLineTabStop = 15; // Larger than width
                                           String text = "This is a long text that needs to be wrapped properly";
                                           StringBuffer sb = new StringBuffer();
                                           
                                           // Get the protected method via reflection
                                           Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                               "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                           renderWrappedText.setAccessible(true);
                                           
                                           // Execute
                                           StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
                                           
                                           // Verify the padding was properly adjusted (should be 1 space, not width+1 spaces)
                                           String[] lines = result.toString().split("\n");
                                           
                                           // First line should be normal
                                           assertEquals("This is a", lines[0].trim());
                                           
                                           // Second line should have 1 space padding (original behavior)
                                           // If mutant survives, it would have width+1 (11) spaces
                                           assertTrue(lines[1].startsWith(" "));
                                           assertEquals(1, lines[1].indexOf("long")); // Should be at position 1
                                           
                                           // Verify subsequent lines also have correct padding
                                           for (int i = 1; i < lines.length; i++) {
                                               String line = lines[i];
                                               if (!line.isEmpty()) {
                                                   // Check padding is exactly 1 space (original behavior)
                                                   assertEquals(1, line.indexOf(line.trim()));
                                               }
                                           }
                                           
                                           // Verify the entire text was properly wrapped
                                           assertTrue(result.toString().contains("This is a"));
                                           assertTrue(result.toString().contains("long text"));
                                           assertTrue(result.toString().contains("that needs"));
                                           assertTrue(result.toString().contains("to be"));
                                           assertTrue(result.toString().contains("wrapped"));
                                           assertTrue(result.toString().contains("properly"));
                                       }

    @Test
                                  public void testRenderWrappedText_NextLineTabStopReset2() throws Exception {
                                      // Setup
                                      HelpFormatter formatter = new HelpFormatter();
                                      // Use reflection to set the protected field
                                      Field newLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                      newLineField.setAccessible(true);
                                      newLineField.set(formatter, "\n");
                                      
                                      StringBuffer sb = new StringBuffer();
                                      String text = "This is a long text that needs to be wrapped properly";
                                      int width = 10;
                                      int nextLineTabStop = width; // Critical value that triggers the mutation
                                      
                                      // Use reflection to access protected method
                                      Method renderMethod = HelpFormatter.class.getDeclaredMethod(
                                          "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                      renderMethod.setAccessible(true);
                                      StringBuffer result = (StringBuffer) renderMethod.invoke(formatter, sb, width, nextLineTabStop, text);
                                      
                                      // Verify padding in subsequent lines
                                      String output = result.toString();
                                      String[] lines = output.split("\n");
                                      
                                      // First line should be normal
                                      assertTrue(lines[0].length() <= width);
                                      
                                      // Second line should have 1 space padding (original behavior)
                                      // Mutant would have width+1 spaces
                                      if (lines.length > 1) {
                                          int paddingSpaces = 0;
                                          while (paddingSpaces < lines[1].length() && lines[1].charAt(paddingSpaces) == ' ') {
                                              paddingSpaces++;
                                          }
                                          assertEquals(1, paddingSpaces); // Original behavior expects 1
                                      }
                                      
                                      // Also verify no infinite loop occurred
                                      assertTrue(lines.length < 10); // Sanity check for reasonable line count
                                  }

    @Test
                             public void testRenderWrappedText_NextLineTabStopEqualsWidth() throws Exception {
                                 // Setup
                                 HelpFormatter formatter = new HelpFormatter();
                                 // Use reflection to set the protected field
                                 Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                                 defaultNewLineField.setAccessible(true);
                                 defaultNewLineField.set(formatter, "\n");
                                 
                                 StringBuffer sb = new StringBuffer();
                                 int width = 10;
                                 int nextLineTabStop = 10; // Exactly equals width
                                 String text = "This is a long text that needs to be wrapped";
                                 
                                 // Use reflection to access the protected method
                                 Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                     "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                 renderWrappedText.setAccessible(true);
                                 StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, width, nextLineTabStop, text);
                                 
                                 // Verify padding was created with 1 (original behavior)
                                 // If mutant survives, padding would be created with 10
                                 // We can verify this by checking the indentation of subsequent lines
                                 String[] lines = result.toString().split("\n");
                                 if (lines.length > 1) {
                                     String secondLine = lines[1];
                                     // Original would indent by 1 space, mutant by 10
                                     assertTrue("Second line should be indented by 1 space", 
                                               secondLine.startsWith(" "));
                                     assertTrue("Second line should not be indented by 10 spaces",
                                               !secondLine.startsWith("          ")); // 10 spaces
                                 }
                                 
                                 // Additional verification that text was properly wrapped
                                 assertTrue(result.length() > 0);
                                 assertTrue(result.toString().contains("\n"));
                             }

    @Test
                        public void testRenderWrappedText_DetectsRtrimMutation() throws Exception {
                            // Setup
                            HelpFormatter formatter = new HelpFormatter();
                            
                            // Use reflection to set the protected field
                            Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                            defaultNewLineField.setAccessible(true);
                            defaultNewLineField.set(formatter, "\n");
                            
                            // Create input with trailing whitespace that doesn't need wrapping
                            String inputText = "Short text with spaces at end    ";
                            StringBuffer sb = new StringBuffer();
                            int width = 100; // Wide enough to not wrap
                            int nextLineTabStop = 4;
                            
                            // Expected behavior - should trim trailing spaces
                            String expected = "Short text with spaces at end";
                            
                            // Get the protected method via reflection
                            Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
                                "renderWrappedText", 
                                StringBuffer.class, 
                                int.class, 
                                int.class, 
                                String.class
                            );
                            renderWrappedTextMethod.setAccessible(true);
                            
                            // Execute
                            StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
                                formatter, 
                                sb, 
                                width, 
                                nextLineTabStop, 
                                inputText
                            );
                            
                            // Verify
                            // Check the entire buffer content matches expected trimmed string
                            assertEquals("Output should have trailing whitespace trimmed", 
                                        expected, 
                                        result.toString().trim());
                            
                            // Additional check to ensure no newline was added (since text didn't wrap)
                            assertFalse("Should not contain newline for short text", 
                                       result.toString().contains("\n"));
                        }

    @Test
                   public void testRenderWrappedText_AppendVsInsertMutation() throws Exception {
                       // Setup
                       HelpFormatter formatter = new HelpFormatter();
                       
                       // Use reflection to set the protected field
                       Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                       defaultNewLineField.setAccessible(true);
                       defaultNewLineField.set(formatter, "\n");
                       
                       // Create a buffer with existing content
                       StringBuffer sb = new StringBuffer("Existing content");
                       String text = "This text cannot be wrapped";
                       int width = 100; // Large enough so text won't wrap
                       int nextLineTabStop = 4;
                       
                       // Get the protected method via reflection
                       Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                           "renderWrappedText", 
                           StringBuffer.class, 
                           int.class, 
                           int.class, 
                           String.class
                       );
                       renderWrappedText.setAccessible(true);
                       
                       // Execute
                       StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                           formatter, 
                           sb, 
                           width, 
                           nextLineTabStop, 
                           text
                       );
                       
                       // Verify
                       // Original behavior: "Existing content" + "This text cannot be wrapped"
                       // Mutant behavior: "This text cannot be wrapped" + "Existing content"
                       assertEquals("Existing contentThis text cannot be wrapped", result.toString());
                       
                       // Additional verification that the original buffer was modified correctly
                       assertSame(sb, result);
                   }

    @Test
              public void testRenderWrappedTextReturnsStringBufferWhenNoWrapNeeded() throws Exception {
                  // Setup
                  HelpFormatter formatter = new HelpFormatter();
                  StringBuffer sb = new StringBuffer();
                  String text = "short text";  // Text shorter than width
                  int width = 20;              // Width larger than text length
                  int nextLineTabStop = 4;
                  
                  // Set defaultNewLine since it's used in the method
                  Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
                  defaultNewLineField.setAccessible(true);
                  defaultNewLineField.set(formatter, "\n");
                  
                  // Get the protected method via reflection
                  Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                      "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                  renderWrappedText.setAccessible(true);
                  
                  // Execute
                  StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                      formatter, sb, width, nextLineTabStop, text);
                  
                  // Verify
                  assertNotNull("Method should not return null when no wrapping is needed", result);
                  assertEquals("Returned StringBuffer should be the same as input buffer", sb, result);
                  assertTrue("StringBuffer should contain the original text", 
                             sb.toString().contains(text));
                  
                  // Additional verification for text content
                  assertEquals("Text should be unchanged when no wrapping needed", 
                              text + "\n", sb.toString());
              }

    @Test
         public void testRenderWrappedText_DetectsWidthMutant() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             formatter.setWidth(10);  // Set width to 10 for testing
             formatter.setNewLine("\n");
             
             // Create a scenario where:
             // - text length > width (11 > 10)
             // - nextLineTabStop is 2 (so nextLineTabStop-1 = 1)
             // - The natural wrap position would be at 1
             StringBuffer sb = new StringBuffer();
             String text = "a bcdefghijk";  // length=11, natural wrap after 'a' (pos=1)
             int nextLineTabStop = 2;
             
             // Get the protected method via reflection
             Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                 "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
             renderWrappedText.setAccessible(true);
             
             // Execute
             StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                 formatter, sb, 10, nextLineTabStop, text);
             
             // Verify the first line is exactly width characters (should be "a" + padding)
             String[] lines = result.toString().split("\n");
             assertEquals("First line should be properly wrapped", 
                         "a", 
                         lines[0]);
             
             // Verify the second line starts with proper padding (1 space)
             assertTrue("Second line should start with padding",
                       lines[1].startsWith(" "));
                         
             // Verify the second line content (should be "bcdefghijk")
             assertEquals("Second line content should be correct",
                         " bcdefghijk",
                         lines[1]);
             
             // Verify total length of first line doesn't exceed width
             assertTrue("First line should not exceed width",
                       lines[0].length() <= 10);
         }

    @Test
    public void testRenderWrappedTextDetectsPosZeroMutant() throws Exception {
        // Setup
        HelpFormatter formatter = new HelpFormatter();
        // Access the protected defaultNewLine field via reflection
        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
        defaultNewLineField.setAccessible(true);
        defaultNewLineField.set(formatter, "\n");
        
        StringBuffer sb = new StringBuffer();
        int width = 10;
        int nextLineTabStop = 5; // This is important for triggering the condition
        
        // Create text that will trigger the special condition:
        // - Length > width (11 > 10)
        // - First wrap position will be at nextLineTabStop - 1 (4)
        String text = "1234 67890 1";
        
        // Expected behavior: should wrap at width (10) when condition met
        String expected = "1234 67890\n     1"; // Note the 5 spaces padding
        
        // Get the protected method via reflection
        Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
        renderWrappedText.setAccessible(true);
        
        // Execute
        StringBuffer result = (StringBuffer) renderWrappedText.invoke(
            formatter, sb, width, nextLineTabStop, text);
        
        // Verify
        String output = result.toString();
        assertFalse("Output contains empty line due to pos=0 mutation", 
                   output.contains("\n\n")); // Check for empty lines
        assertEquals("Wrapping position incorrect", expected, output);
        
        // Additional check for line lengths
        String[] lines = output.split("\n");
        for (String line : lines) {
            assertTrue("Line exceeds width", 
                      line.length() <= width || line.startsWith("     "));
        }
    }


}
