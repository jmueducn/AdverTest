package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
         public void testAppendOption_OptionalWithShortOptNoArg() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             StringBuffer buff = new StringBuffer();
             Option option = mock(Option.class);
             when(option.getOpt()).thenReturn("f");
             when(option.getLongOpt()).thenReturn(null);
             when(option.hasArg()).thenReturn(false);
             
             // Get the private method using reflection
             Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                 "appendOption", StringBuffer.class, Option.class, boolean.class);
             appendOptionMethod.setAccessible(true);
             
             // Execute
             appendOptionMethod.invoke(formatter, buff, option, false);
             
             // Verify
             assertEquals("[-f]", buff.toString());
         }

    @Test
         public void testAppendOption_RequiredWithShortOptNoArg() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             StringBuffer buff = new StringBuffer();
             Option option = mock(Option.class);
             when(option.getOpt()).thenReturn("f");
             when(option.getLongOpt()).thenReturn(null);
             when(option.hasArg()).thenReturn(false);
             
             // Get the private method via reflection
             Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                 "appendOption", StringBuffer.class, Option.class, boolean.class);
             appendOptionMethod.setAccessible(true);
             
             // Execute
             appendOptionMethod.invoke(formatter, buff, option, true);
             
             // Verify
             assertEquals("-f", buff.toString());
         }

    @Test
         public void testAppendOption_OptionalWithLongOptNoArg() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             StringBuffer buff = new StringBuffer();
             Option option = mock(Option.class);
             when(option.getOpt()).thenReturn(null);
             when(option.getLongOpt()).thenReturn("file");
             when(option.hasArg()).thenReturn(false);
             when(option.hasArgName()).thenReturn(false);
             
             // Get the private method using reflection
             Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                 "appendOption", StringBuffer.class, Option.class, boolean.class);
             appendOptionMethod.setAccessible(true);
             
             // Execute
             appendOptionMethod.invoke(formatter, buff, option, false);
             
             // Verify
             assertEquals("[--file]", buff.toString());
         }

    @Test
         public void testAppendOption_RequiredWithLongOptNoArg() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             StringBuffer buff = new StringBuffer();
             Option option = mock(Option.class);
             when(option.getOpt()).thenReturn(null);
             when(option.getLongOpt()).thenReturn("file");
             when(option.hasArg()).thenReturn(false);
             
             // Get the private method using reflection
             Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                 "appendOption", StringBuffer.class, Option.class, boolean.class);
             appendOptionMethod.setAccessible(true);
             
             // Execute
             appendOptionMethod.invoke(formatter, buff, option, true);
             
             // Verify
             assertEquals("--file", buff.toString());
         }

    @Test
         public void testAppendOption_OptionalWithShortOptAndArg() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             StringBuffer buff = new StringBuffer();
             Option option = mock(Option.class);
             when(option.getOpt()).thenReturn("f");
             when(option.getLongOpt()).thenReturn(null);
             when(option.hasArg()).thenReturn(true);
             when(option.hasArgName()).thenReturn(true);
             when(option.getArgName()).thenReturn("filename");
             
             // Get the private method using reflection
             Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                 "appendOption", StringBuffer.class, Option.class, boolean.class);
             appendOptionMethod.setAccessible(true);
             
             // Execute
             appendOptionMethod.invoke(null, buff, option, false);
             
             // Verify
             assertEquals("[-f <filename>]", buff.toString());
         }

    @Test
         public void testAppendOption_RequiredWithShortOptAndArg() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             StringBuffer buff = new StringBuffer();
             Option option = mock(Option.class);
             when(option.getOpt()).thenReturn("f");
             when(option.getLongOpt()).thenReturn(null);
             when(option.hasArg()).thenReturn(true);
             when(option.hasArgName()).thenReturn(true);
             when(option.getArgName()).thenReturn("filename");
             
             // Get private method via reflection
             Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                 "appendOption", StringBuffer.class, Option.class, boolean.class);
             appendOptionMethod.setAccessible(true);
             
             // Execute
             appendOptionMethod.invoke(formatter, buff, option, true);
             
             // Verify
             assertEquals("-f <filename>", buff.toString());
         }

    @Test
         public void testAppendOption_OptionalWithLongOptAndArg() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             StringBuffer buff = new StringBuffer();
             Option option = mock(Option.class);
             when(option.getOpt()).thenReturn(null);
             when(option.getLongOpt()).thenReturn("file");
             when(option.hasArg()).thenReturn(true);
             when(option.hasArgName()).thenReturn(true);
             when(option.getArgName()).thenReturn("filename");
             
             // Get the private method using reflection
             Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                 "appendOption", StringBuffer.class, Option.class, boolean.class);
             appendOptionMethod.setAccessible(true);
             
             // Execute
             appendOptionMethod.invoke(formatter, buff, option, false);
             
             // Verify
             assertEquals("[--file <filename>]", buff.toString());
         }

    @Test
         public void testAppendOption_RequiredWithLongOptAndArg() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             StringBuffer buff = new StringBuffer();
             Option option = mock(Option.class);
             when(option.getOpt()).thenReturn(null);
             when(option.getLongOpt()).thenReturn("file");
             when(option.hasArg()).thenReturn(true);
             when(option.hasArgName()).thenReturn(true);
             when(option.getArgName()).thenReturn("filename");
             
             // Get private method via reflection
             Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                 "appendOption", StringBuffer.class, Option.class, boolean.class);
             appendOptionMethod.setAccessible(true);
             
             // Execute
             appendOptionMethod.invoke(formatter, buff, option, true);
             
             // Verify
             assertEquals("--file <filename>", buff.toString());
         }

    @Test
         public void testAppendOption_OptionalWithBothOptsAndArg() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             StringBuffer buff = new StringBuffer();
             Option option = mock(Option.class);
             when(option.getOpt()).thenReturn("f");
             when(option.getLongOpt()).thenReturn("file");
             when(option.hasArg()).thenReturn(true);
             when(option.hasArgName()).thenReturn(true);
             when(option.getArgName()).thenReturn("filename");
             
             // Get private method via reflection
             Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                 "appendOption", StringBuffer.class, Option.class, boolean.class);
             appendOptionMethod.setAccessible(true);
             
             // Execute
             appendOptionMethod.invoke(formatter, buff, option, false);
             
             // Verify
             assertEquals("[-f <filename>]", buff.toString());
         }

    @Test
         public void testAppendOption_OptionalWithArgNoArgName() throws Exception {
             // Setup
             HelpFormatter formatter = new HelpFormatter();
             StringBuffer buff = new StringBuffer();
             Option option = mock(Option.class);
             when(option.getOpt()).thenReturn("f");
             when(option.getLongOpt()).thenReturn(null);
             when(option.hasArg()).thenReturn(true);
             when(option.hasArgName()).thenReturn(false);
             
             // Get the private method via reflection
             Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                 "appendOption", StringBuffer.class, Option.class, boolean.class);
             appendOptionMethod.setAccessible(true);
             
             // Execute
             appendOptionMethod.invoke(null, buff, option, false);
             
             // Verify
             assertEquals("[-f]", buff.toString());
         }

    @Test
    public void testAppendOption_ShouldNotShowArgNameWhenOptionDoesNotTakeArgument() throws Exception {
        // Setup test objects
        StringBuffer buff = new StringBuffer();
        boolean required = false;
        
        // Create a mock Option that has arg name but doesn't take arguments
        Option option = mock(Option.class);
        when(option.getOpt()).thenReturn("t"); // short option
        when(option.hasArg()).thenReturn(false); // doesn't take argument
        when(option.hasArgName()).thenReturn(true); // has arg name
        when(option.getArgName()).thenReturn("timeout"); // arg name
        
        // Use reflection to call the private method
        Class<?> helpFormatterClass = Class.forName("org.apache.commons.cli.HelpFormatter");
        Method appendOptionMethod = helpFormatterClass.getDeclaredMethod("appendOption", 
            StringBuffer.class, Option.class, boolean.class);
        appendOptionMethod.setAccessible(true);
        appendOptionMethod.invoke(null, buff, option, required);
        
        // Verify the output
        String result = buff.toString();
        // Original behavior: shouldn't show arg name since hasArg() is false
        // Mutated behavior: would show " <timeout>" because hasArgName() is true
        assertFalse("Should not contain argument name when option doesn't take arguments", 
                   result.contains("<timeout>"));
        // Also verify the basic structure is correct
        assertTrue(result.startsWith("[-t"));
        assertTrue(result.endsWith("]"));
    }


}
