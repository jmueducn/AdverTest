package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
 
public class OptionGroupTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                     public void testAddOption_NullOptionThrowsException() {
                                         OptionGroup optionGroup = new OptionGroup();
                                         ExpectedException thrown = ExpectedException.none();
                                         thrown.expect(NullPointerException.class);
                                         thrown.expectMessage("Option cannot be null");
                                         
                                         optionGroup.addOption(null);
                                     }

    @Test
                                     public void testAddOption_OptionWithNullKeyThrowsException() {
                                         thrown.expect(IllegalArgumentException.class);
                                         thrown.expectMessage("Option key cannot be null");
                                         
                                         OptionGroup optionGroup = new OptionGroup();
                                         Option optionWithNullKey = new Option(null, "description");
                                         optionGroup.addOption(optionWithNullKey);
                                     }

    @Test
                                 public void testAddOption_SingleOption() {
                                     // Create test objects
                                     OptionGroup optionGroup = new OptionGroup();
                                     Option option1 = new Option("key1", "description1");
                                     
                                     // Test the method
                                     OptionGroup result = optionGroup.addOption(option1);
                                     
                                     // Verify fluent interface
                                     assertSame(optionGroup, result);
                                     
                                     // Verify option was added
                                     Collection<Option> options = optionGroup.getOptions();
                                     assertEquals(1, options.size());
                                     assertTrue(options.contains(option1));
                                 }

    @Test
                                 public void testAddOption_MultipleOptions() {
                                     OptionGroup optionGroup = new OptionGroup();
                                     Option option1 = new Option("key1", "description1");
                                     Option option2 = new Option("key2", "description2");
                                     
                                     optionGroup.addOption(option1)
                                               .addOption(option2);
                                     
                                     Collection<Option> options = optionGroup.getOptions();
                                     assertEquals(2, options.size());
                                     assertTrue(options.contains(option1));
                                     assertTrue(options.contains(option2));
                                 }

    @Test
                                 public void testAddOption_DuplicateKeyOverwrites() {
                                     // Create the option group to test
                                     OptionGroup optionGroup = new OptionGroup();
                                     
                                     // Create first option (using mock)
                                     Option option1 = mock(Option.class);
                                     // Since getKey() is not accessible, we'll use reflection to set the key
                                     try {
                                         Field keyField = Option.class.getDeclaredField("key");
                                         keyField.setAccessible(true);
                                         keyField.set(option1, "key1");
                                     } catch (Exception e) {
                                         fail("Failed to set key field via reflection");
                                     }
                                     
                                     // Create second option with same key
                                     Option newOptionWithSameKey = mock(Option.class);
                                     try {
                                         Field keyField = Option.class.getDeclaredField("key");
                                         keyField.setAccessible(true);
                                         keyField.set(newOptionWithSameKey, "key1");
                                     } catch (Exception e) {
                                         fail("Failed to set key field via reflection");
                                     }
                                     
                                     // Add both options (second should overwrite first)
                                     optionGroup.addOption(option1)
                                               .addOption(newOptionWithSameKey);
                                     
                                     // Verify results - getOptions() returns Collection<Option>
                                     Collection<Option> options = optionGroup.getOptions();
                                     assertEquals(1, options.size());
                                     assertTrue(options.contains(newOptionWithSameKey));
                                 }

    @Test
                            public void testAddOptionShouldStoreWithOptionKeyNotNull() {
                                // Setup
                                OptionGroup optionGroup = new OptionGroup();
                                Option option = mock(Option.class);
                                
                                // Use reflection to access private getKey() method
                                try {
                                    Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                    getKeyMethod.setAccessible(true);
                                    when(getKeyMethod.invoke(option)).thenReturn("testKey");
                                } catch (Exception e) {
                                    fail("Failed to setup mock for getKey()");
                                }
                                
                                // Execute
                                OptionGroup result = optionGroup.addOption(option);
                                
                                // Verify
                                // 1. Verify the option was stored
                                assertTrue(optionGroup.getOptions().contains(option));
                                
                                // 2. Verify method returns the instance for chaining
                                assertSame(optionGroup, result);
                                
                                // 3. Verify we can get the option by its key (indirectly)
                                // Since we can't access getKey() directly, we'll verify the option is in the collection
                                // and assume the addOption method properly stores it with its key
                                assertTrue(optionGroup.getOptions().contains(option));
                                
                                // This test would fail if the mutant (putting with null key) was present because:
                                // - The option wouldn't be properly stored in the internal map
                                // - The map might allow null keys but that's not the intended behavior
                            }

    @Test
                        public void testAddOptionShouldAddExactlyOneEntry() {
                            // Setup
                            OptionGroup optionGroup = new OptionGroup();
                            Option option = new Option("testKey", "testValue"); // Assuming Option has such constructor
                            
                            // Execute
                            optionGroup.addOption(option);
                            
                            // Verify
                            Collection<Option> options = optionGroup.getOptions();
                            assertEquals(1, options.size());
                            assertTrue(options.contains(option));
                            // With the mutant, the size would still be 1 (same key overwrites), 
                            // so this might not catch it - hence the first test is better
                        }

    @Test
                   public void testAddOptionShouldCallPutExactlyOnce() {
                       // Setup
                       OptionGroup optionGroup = new OptionGroup();
                       Option option = mock(Option.class);
                       // Mock toString() instead of getKey() since it's public
                       when(option.toString()).thenReturn("testKey");
                       
                       Map<String, Option> mockMap = mock(Map.class);
                       // Use reflection to replace the optionMap with a mock since it's private final
                       try {
                           Field field = OptionGroup.class.getDeclaredField("optionMap");
                           field.setAccessible(true);
                           field.set(optionGroup, mockMap);
                       } catch (Exception e) {
                           fail("Failed to set up test due to reflection error: " + e.getMessage());
                       }
                    
                       // Execute
                       optionGroup.addOption(option);
                    
                       // Verify
                       verify(mockMap, times(1)).put(eq("testKey"), eq(option));
                       // The mutant would call put twice, so this verification would fail
                   }

    @Test
              public void testAddOptionPreservesKeyCase() throws Exception {
                  // Create test data
                  Option mockOption = mock(Option.class);
                  
                  // Use reflection to set up the mock for private getKey() method
                  Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                  getKeyMethod.setAccessible(true);
                  when(getKeyMethod.invoke(mockOption)).thenReturn("TestOption");
                  
                  // Create OptionGroup instance
                  OptionGroup optionGroup = new OptionGroup();
                  
                  // Execute the method
                  OptionGroup result = optionGroup.addOption(mockOption);
                  
                  // Verify the result is the same instance (method chaining)
                  assertSame(optionGroup, result);
                  
                  // Verify the option was added with the exact key case
                  Collection<Option> options = optionGroup.getOptions();
                  assertTrue(options.contains(mockOption));
                  
                  // Verify the key in the map matches exactly (case-sensitive)
                  assertTrue(optionGroup.getNames().contains("TestOption"));
                  
                  // Additional verification that lowercase version is NOT present
                  assertFalse(optionGroup.getNames().contains("testoption"));
              }

    @Test
         public void testAddOptionPreservesOriginalKeyCase() throws Exception {
             // Create test objects
             OptionGroup optionGroup = new OptionGroup();
             Option mockOption = mock(Option.class);
             
             // Setup mock behavior - use mixed case key
             // Since getKey() is not public, we'll use reflection to set a private field
             Field keyField = Option.class.getDeclaredField("key");
             keyField.setAccessible(true);
             keyField.set(mockOption, "TestKey");
             
             // Execute the method
             OptionGroup result = optionGroup.addOption(mockOption);
             
             // Verify the result is the same instance (chaining works)
             assertSame(optionGroup, result);
             
             // Get the option map using reflection
             Field optionMapField = OptionGroup.class.getDeclaredField("optionMap");
             optionMapField.setAccessible(true);
             @SuppressWarnings("unchecked")
             Map<String, Option> optionMap = (Map<String, Option>) optionMapField.get(optionGroup);
             
             // Verify the key is stored with original case
             assertTrue("Option should be stored with original key case", 
                       optionMap.containsKey("TestKey"));
             assertFalse("Option should not be stored with uppercase key", 
                        optionMap.containsKey("TESTKEY"));
             
             // Verify the correct option is stored
             assertSame(mockOption, optionMap.get("TestKey"));
         }

    @Test
    public void testAddOptionShouldCallPutExactlyOnce1() {
        // Setup
        Map<String, Option> mockOptionMap = mock(Map.class);
        Option testOption = new Option("testKey", "description");
        OptionGroup optionGroup = new OptionGroup();
        
        // Use reflection to inject the mock map since optionMap is likely private
        try {
            Field field = OptionGroup.class.getDeclaredField("optionMap");
            field.setAccessible(true);
            field.set(optionGroup, mockOptionMap);
        } catch (Exception e) {
            fail("Failed to inject mock optionMap");
        }
    
        // When
        optionGroup.addOption(testOption);
    
        // Then
        verify(mockOptionMap, times(1)).put(eq("testKey"), eq(testOption));
        // Additional verification that the method returns the OptionGroup instance
        assertEquals(optionGroup, optionGroup.addOption(testOption));
    }


}
