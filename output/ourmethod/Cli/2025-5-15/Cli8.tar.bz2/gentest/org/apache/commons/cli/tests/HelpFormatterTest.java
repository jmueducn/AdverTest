package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                     public void testRenderWrappedText_MultiLineWithDifferentTabStop() throws Exception {
                                         org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                         formatter.setNewLine(System.lineSeparator());
                                         StringBuffer sb = new StringBuffer();
                                         String text = "Very long text that should be wrapped multiple times";
                                         
                                         // Use reflection to access protected method
                                         java.lang.reflect.Method renderWrappedText = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                             "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                         renderWrappedText.setAccessible(true);
                                         StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 15, 4, text);
                                         
                                         String expected = "Very long text" + System.lineSeparator() +
                                                          "    that should" + System.lineSeparator() +
                                                          "    be wrapped" + System.lineSeparator() +
                                                          "    multiple" + System.lineSeparator() +
                                                          "    times";
                                         assertEquals(expected, result.toString());
                                     }

    @Test
                                     public void testRenderWrappedText_ExistingBufferContent() throws Exception {
                                         StringBuffer sb = new StringBuffer();
                                         org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                         sb.append("Prefix ");
                                         String text = "This should be wrapped";
                                         
                                         // Use reflection to access protected method
                                         Method renderWrappedText = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                             "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                         renderWrappedText.setAccessible(true);
                                         StringBuffer result = (StringBuffer) renderWrappedText.invoke(formatter, sb, 10, 2, text);
                                         
                                         String expected = "Prefix This\n  should\n  be\n  wrapped";
                                         assertEquals(expected, result.toString());
                                     }

    @Test
                                     public void testRenderWrappedText_MultipleSpaces() throws Exception {
                                         org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                         StringBuffer sb = new StringBuffer();
                                         String text = "Text    with    multiple    spaces";
                                         
                                         // Use reflection to access protected method
                                         java.lang.reflect.Method renderWrappedText = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                             "renderWrappedText", 
                                             StringBuffer.class, 
                                             int.class, 
                                             int.class, 
                                             String.class
                                         );
                                         renderWrappedText.setAccessible(true);
                                         StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                             formatter, 
                                             sb, 
                                             10, 
                                             2, 
                                             text
                                         );
                                         
                                         // Should preserve at least one space between words
                                         assertEquals("Text with\n  multiple\n  spaces", result.toString());
                                     }

    @Test
                                     public void testRenderWrappedText_NegativeTabStop() throws Exception {
                                         String text = "Test text";
                                         StringBuffer sb = new StringBuffer();
                                         HelpFormatter formatter = new HelpFormatter();
                                         
                                         // Use reflection to access protected method
                                         Method renderWrappedText = HelpFormatter.class.getDeclaredMethod(
                                             "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                                         renderWrappedText.setAccessible(true);
                                         StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                             formatter, sb, 10, -2, text);
                                         
                                         // Should treat negative tab stop as 0
                                         assertEquals("Test text", result.toString());
                                     }

    @Test
                                 public void testRenderWrappedText_WordLongerThanWidth() throws Exception {
                                     String text = "Supercalifragilisticexpialidocious";
                                     StringBuffer sb = new StringBuffer();
                                     org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                     
                                     // Use reflection to access protected method
                                     java.lang.reflect.Method renderWrappedText = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                         "renderWrappedText", 
                                         StringBuffer.class, 
                                         int.class, 
                                         int.class, 
                                         String.class
                                     );
                                     renderWrappedText.setAccessible(true);
                                     StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                         formatter, 
                                         sb, 
                                         10, 
                                         2, 
                                         text
                                     );
                                     
                                     // Should break the word at the width limit
                                     assertEquals("Supercalif\n  ragilist\n  icexpial\n  idocious", result.toString());
                                 }

    @Test
                             public void testRenderWrappedText_NegativeWidth() throws Exception {
                                 org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                 thrown.expect(IllegalArgumentException.class);
                                 StringBuffer sb = new StringBuffer();
                                 org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                 
                                 // Use reflection to access protected method
                                 java.lang.reflect.Method method = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                     "renderWrappedText",
                                     StringBuffer.class,
                                     int.class,
                                     int.class,
                                     String.class
                                 );
                                 method.setAccessible(true);
                                 method.invoke(formatter, sb, -5, 2, "Should fail");
                             }

    @Test
                             public void testRenderWrappedText_SingleLineNoWrapNeeded() throws Exception {
                                 String text = "Short text";
                                 java.lang.StringBuffer sb = new java.lang.StringBuffer();
                                 org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                 
                                 // Get the protected method via reflection
                                 java.lang.reflect.Method renderWrappedText = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                     "renderWrappedText", 
                                     java.lang.StringBuffer.class, 
                                     int.class, 
                                     int.class, 
                                     java.lang.String.class
                                 );
                                 renderWrappedText.setAccessible(true);
                                 
                                 // Invoke the method
                                 java.lang.StringBuffer result = (java.lang.StringBuffer) renderWrappedText.invoke(
                                     formatter, 
                                     sb, 
                                     20, 
                                     2, 
                                     text
                                 );
                                 
                                 assertEquals(text, result.toString());
                             }

    @Test
                             public void testRenderWrappedText_NullText() throws Exception {
                                 // Setup
                                 StringBuffer sb = new StringBuffer();
                                 org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                                 
                                 // Expected exception
                                 ExpectedException thrown = ExpectedException.none();
                                 thrown.expect(NullPointerException.class);
                                 
                                 // Use reflection to access protected method
                                 Method method = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                     "renderWrappedText", 
                                     StringBuffer.class, 
                                     int.class, 
                                     int.class, 
                                     String.class
                                 );
                                 method.setAccessible(true);
                                 method.invoke(formatter, sb, 10, 2, null);
                             }

    @Test
                         public void testRenderWrappedText_SingleLineNeedsWrap() throws Exception {
                             // Create required objects
                             org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                             StringBuffer sb = new StringBuffer();
                             String text = "This is a long line that needs wrapping";
                             
                             // Use reflection to access protected method
                             java.lang.reflect.Method renderWrappedText = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                 "renderWrappedText", 
                                 StringBuffer.class, 
                                 int.class, 
                                 int.class, 
                                 String.class
                             );
                             renderWrappedText.setAccessible(true);
                             StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                 formatter, 
                                 sb, 
                                 10, 
                                 2, 
                                 text
                             );
                             
                             String expected = "This is a\n  long\n  line\n  that\n  needs\n  wrapping";
                             assertEquals(expected, result.toString());
                         }

    @Test
                         public void testRenderWrappedText_SingleLineExactWidth() throws Exception {
                             String text = "1234567890";
                             StringBuffer sb = new StringBuffer();
                             org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                             
                             // Use reflection to access protected method
                             java.lang.reflect.Method method = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                 "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
                             method.setAccessible(true);
                             StringBuffer result = (StringBuffer) method.invoke(formatter, sb, 10, 2, text);
                             
                             assertEquals(text, result.toString());
                         }

    @Test
                         public void testRenderWrappedText_EmptyText() throws Exception {
                             // Import required classes using fully qualified names
                             java.lang.reflect.Method renderWrappedText = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                 "renderWrappedText", 
                                 StringBuffer.class,
                                 int.class, 
                                 int.class, 
                                 String.class
                             );
                             renderWrappedText.setAccessible(true);
                             
                             StringBuffer sb = new StringBuffer();
                             org.apache.commons.cli.HelpFormatter formatter = new org.apache.commons.cli.HelpFormatter();
                             
                             // Invoke the method
                             StringBuffer result = (StringBuffer) renderWrappedText.invoke(
                                 formatter, 
                                 sb, 
                                 10, 
                                 2, 
                                 ""
                             );
                             
                             assertEquals("", result.toString());
                         }

    @Test
    public void testRenderWrappedTextWithNegativeWrapPos() throws Exception {
        // Setup
        HelpFormatter formatter = new HelpFormatter();
        
        // Use reflection to set defaultNewLine since it's likely protected
        Field defaultNewLineField = HelpFormatter.class.getDeclaredField("defaultNewLine");
        defaultNewLineField.setAccessible(true);
        defaultNewLineField.set(formatter, "\n");
        
        // Mock the dependencies
        StringBuffer sb = new StringBuffer();
        String text = "test text";
        int width = 10;
        int nextLineTabStop = 2;
        
        // Create a subclass that overrides findWrapPos to return -2
        HelpFormatter testFormatter = new HelpFormatter() {
            @Override
            protected int findWrapPos(String text, int width, int startPos) {
                return -2;
            }
        };
        
        // Use reflection to call the protected method
        Method renderWrappedTextMethod = HelpFormatter.class.getDeclaredMethod(
            "renderWrappedText", StringBuffer.class, int.class, int.class, String.class);
        renderWrappedTextMethod.setAccessible(true);
        
        // Call the method
        StringBuffer result = (StringBuffer) renderWrappedTextMethod.invoke(
            testFormatter, sb, width, nextLineTabStop, text);
        
        // Verify behavior
        // Original code would continue processing (pos == -1 is false)
        // Mutated code would enter the if block (pos <= -1 is true)
        // So we verify the text was NOT appended (original behavior)
        assertFalse(result.toString().contains(text));
        
        // Also verify the StringBuffer is empty since no text should be added
        assertEquals("", result.toString());
    }


}
