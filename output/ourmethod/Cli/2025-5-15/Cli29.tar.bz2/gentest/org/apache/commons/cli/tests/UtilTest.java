package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
 
public class UtilTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                public void testStripLeadingAndTrailingQuotes() throws Exception {
                                                                                                                                                    // Get the Util class and method using reflection
                                                                                                                                                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                                    Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                                    stripMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test empty string
                                                                                                                                                    assertEquals("", stripMethod.invoke(null, ""));
                                                                                                                                                    
                                                                                                                                                    // Test single character (not quote)
                                                                                                                                                    assertEquals("a", stripMethod.invoke(null, "a"));
                                                                                                                                                    
                                                                                                                                                    // Test single quote
                                                                                                                                                    assertEquals("\"", stripMethod.invoke(null, "\""));
                                                                                                                                                    
                                                                                                                                                    // Test string with only two quotes
                                                                                                                                                    assertEquals("", stripMethod.invoke(null, "\"\""));
                                                                                                                                                    
                                                                                                                                                    // Test typical case with quotes
                                                                                                                                                    assertEquals("hello", stripMethod.invoke(null, "\"hello\""));
                                                                                                                                                    
                                                                                                                                                    // Test string with quotes inside (should not strip)
                                                                                                                                                    assertEquals("\"hello\"world\"", stripMethod.invoke(null, "\"hello\"world\""));
                                                                                                                                                    
                                                                                                                                                    // Test string with only opening quote
                                                                                                                                                    assertEquals("\"hello", stripMethod.invoke(null, "\"hello"));
                                                                                                                                                    
                                                                                                                                                    // Test string with only closing quote
                                                                                                                                                    assertEquals("hello\"", stripMethod.invoke(null, "hello\""));
                                                                                                                                                    
                                                                                                                                                    // Test string with multiple quotes at start/end (should only strip one pair)
                                                                                                                                                    assertEquals("\"hello\"", stripMethod.invoke(null, "\"\"hello\"\""));
                                                                                                                                                    
                                                                                                                                                    // Test string with spaces and quotes
                                                                                                                                                    assertEquals(" hello ", stripMethod.invoke(null, "\" hello \""));
                                                                                                                                                    
                                                                                                                                                    // Test string with escaped quotes inside (should not strip)
                                                                                                                                                    assertEquals("\\\"hello\\\"", stripMethod.invoke(null, "\"\\\"hello\\\"\""));
                                                                                                                                                    
                                                                                                                                                    // Test string with single character between quotes
                                                                                                                                                    assertEquals("a", stripMethod.invoke(null, "\"a\""));
                                                                                                                                                    
                                                                                                                                                    // Test string with special characters between quotes
                                                                                                                                                    assertEquals("!@#$%", stripMethod.invoke(null, "\"!@#$%\""));
                                                                                                                                                    
                                                                                                                                                    // Test string with unicode characters between quotes
                                                                                                                                                    assertEquals("こんにちは", stripMethod.invoke(null, "\"こんにちは\""));
                                                                                                                                                }

    @Test
                                                                                                                                           public void testStripLeadingAndTrailingQuotes_Length1String() throws Exception {
                                                                                                                                               // This test will catch the mutant because:
                                                                                                                                               // Original: length=1, (1>1) is false - no stripping
                                                                                                                                               // Mutant: length=2, (2>1) is true - will try to strip (incorrectly)
                                                                                                                                               
                                                                                                                                               String input = "\"";
                                                                                                                                               String expected = "\""; // Should remain unchanged
                                                                                                                                               
                                                                                                                                               // Use reflection to access the private method
                                                                                                                                               Class<?> clazz = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                               Method method = clazz.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                               method.setAccessible(true);
                                                                                                                                               String actual = (String) method.invoke(null, input);
                                                                                                                                               
                                                                                                                                               assertEquals("Length 1 string should remain unchanged", expected, actual);
                                                                                                                                           }

    @Test
                                                                                                                                           public void testStripLeadingAndTrailingQuotes_Length2QuotesOnly() throws Exception {
                                                                                                                                               // Additional test case for completeness
                                                                                                                                               String input = "\"\"";
                                                                                                                                               String expected = ""; // Should be stripped to empty string
                                                                                                                                               
                                                                                                                                               // Use reflection to access the non-public Util class and its method
                                                                                                                                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                               Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                               stripMethod.setAccessible(true);
                                                                                                                                               String actual = (String) stripMethod.invoke(null, input);
                                                                                                                                               
                                                                                                                                               assertEquals("Length 2 quotes-only string should be stripped", expected, actual);
                                                                                                                                           }

    @Test
                                                                                                                                           public void testStripLeadingAndTrailingQuotes_Length3Valid() {
                                                                                                                                               // Normal case test
                                                                                                                                               String input = "\"a\"";
                                                                                                                                               String expected = "a"; // Should be stripped
                                                                                                                                               
                                                                                                                                               try {
                                                                                                                                                   Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                                   Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                   String actual = (String) method.invoke(null, input);
                                                                                                                                                   
                                                                                                                                                   assertEquals("Valid quoted string should be stripped", expected, actual);
                                                                                                                                               } catch (Exception e) {
                                                                                                                                                   fail("Failed to invoke stripLeadingAndTrailingQuotes method via reflection: " + e.getMessage());
                                                                                                                                               }
                                                                                                                                           }

    @Test
                                                                                                                                           public void testStripLeadingAndTrailingQuotes_Length2WithContent() throws Exception {
                                                                                                                                               // Edge case test
                                                                                                                                               String input = "\"\"\"";
                                                                                                                                               String expected = "\"\"\""; // Should remain unchanged (contains inner quote)
                                                                                                                                               
                                                                                                                                               // Get the Util class and method using reflection
                                                                                                                                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                               Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                               stripMethod.setAccessible(true);
                                                                                                                                               
                                                                                                                                               // Invoke the method
                                                                                                                                               String actual = (String) stripMethod.invoke(null, input);
                                                                                                                                               
                                                                                                                                               assertEquals("String with inner quotes should remain unchanged", expected, actual);
                                                                                                                                           }

    @Test
                                                                                                                                      public void testStripLeadingAndTrailingQuotes_ShouldStripQuotes() throws Exception {
                                                                                                                                          // Arrange
                                                                                                                                          String input = "\"quoted string\"";
                                                                                                                                          String expected = "quoted string";
                                                                                                                                          
                                                                                                                                          // Get the Util class and method using reflection
                                                                                                                                          Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                          Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                          stripMethod.setAccessible(true);
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String result = (String) stripMethod.invoke(null, input);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals("Should strip surrounding quotes from valid input", expected, result);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testStripLeadingAndTrailingQuotes_WithInternalQuotes_ShouldNotStrip() {
                                                                                                                                          // Arrange
                                                                                                                                          String input = "\"quote\"inside\"";
                                                                                                                                          String expected = "\"quote\"inside\"";
                                                                                                                                          
                                                                                                                                          try {
                                                                                                                                              // Get the Util class
                                                                                                                                              Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                              // Get the method
                                                                                                                                              java.lang.reflect.Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                              // Make it accessible
                                                                                                                                              method.setAccessible(true);
                                                                                                                                              
                                                                                                                                              // Act
                                                                                                                                              String result = (String) method.invoke(null, input);
                                                                                                                                              
                                                                                                                                              // Assert
                                                                                                                                              assertEquals("Should not strip when quotes inside", expected, result);
                                                                                                                                          } catch (Exception e) {
                                                                                                                                              fail("Failed to invoke method via reflection: " + e.getMessage());
                                                                                                                                          }
                                                                                                                                      }

    @Test
                                                                                                                                      public void testStripLeadingAndTrailingQuotes_WithSingleChar_ShouldNotStrip() throws Exception {
                                                                                                                                          // Arrange
                                                                                                                                          String input = "\"";
                                                                                                                                          String expected = "\"";
                                                                                                                                          
                                                                                                                                          // Get the method via reflection
                                                                                                                                          Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                          Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                          method.setAccessible(true);
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          String result = (String) method.invoke(null, input);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          assertEquals("Should not strip single quote", expected, result);
                                                                                                                                      }

    @Test
                                                                                                                                      public void testStripLeadingAndTrailingQuotes_WithEmptyString_ShouldNotStrip() {
                                                                                                                                          // Arrange
                                                                                                                                          String input = "";
                                                                                                                                          String expected = "";
                                                                                                                                          
                                                                                                                                          try {
                                                                                                                                              // Get the Util class
                                                                                                                                              Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                              // Get the stripLeadingAndTrailingQuotes method
                                                                                                                                              Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                              // Make the method accessible
                                                                                                                                              method.setAccessible(true);
                                                                                                                                              
                                                                                                                                              // Act
                                                                                                                                              String result = (String) method.invoke(null, input);
                                                                                                                                              
                                                                                                                                              // Assert
                                                                                                                                              assertEquals("Should return empty string unchanged", expected, result);
                                                                                                                                          } catch (Exception e) {
                                                                                                                                              fail("Failed to invoke stripLeadingAndTrailingQuotes method: " + e.getMessage());
                                                                                                                                          }
                                                                                                                                      }

    @Test
                                                                                                                                 public void testStripLeadingAndTrailingQuotes_SingleQuote() throws Exception {
                                                                                                                                     // This test will catch the mutant by verifying behavior with a single quote string
                                                                                                                                     String input = "\"";
                                                                                                                                     String expected = "\"";  // Should remain unchanged in original implementation
                                                                                                                                     
                                                                                                                                     // Get the method via reflection
                                                                                                                                     Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                     Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                     stripMethod.setAccessible(true);
                                                                                                                                     
                                                                                                                                     // Invoke the method
                                                                                                                                     String result = (String) stripMethod.invoke(null, input);
                                                                                                                                     
                                                                                                                                     assertEquals("Single quote string should remain unchanged", expected, result);
                                                                                                                                 }

    @Test
                                                                                                                                 public void testStripLeadingAndTrailingQuotes_RegularCases() throws Exception {
                                                                                                                                     // Get the Util class and method using reflection
                                                                                                                                     Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                     Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                     stripMethod.setAccessible(true);
                                                                                                                                 
                                                                                                                                     // Additional test cases for completeness
                                                                                                                                     assertEquals("Empty string", "", stripMethod.invoke(null, ""));
                                                                                                                                     assertEquals("No quotes", "abc", stripMethod.invoke(null, "abc"));
                                                                                                                                     assertEquals("Quoted string", "abc", stripMethod.invoke(null, "\"abc\""));
                                                                                                                                     assertEquals("Internal quotes", "a\"b\"c", stripMethod.invoke(null, "\"a\"b\"c\""));
                                                                                                                                     assertEquals("Single non-quote char", "a", stripMethod.invoke(null, "a"));
                                                                                                                                 }

    @Test
                                                                                                                            public void testStripLeadingAndTrailingQuotes_shouldNotStripWhenNoQuotesButLong() throws Exception {
                                                                                                                                // This string is longer than 1 character but has no quotes
                                                                                                                                String input = "hello";
                                                                                                                                String expected = "hello"; // Should remain unchanged
                                                                                                                                
                                                                                                                                // Get the Util class and method using reflection
                                                                                                                                Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                stripMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // Invoke the method
                                                                                                                                String result = (String) stripMethod.invoke(null, input);
                                                                                                                                
                                                                                                                                // Original would return unchanged, mutant would try to strip (though may fail)
                                                                                                                                assertEquals("String without quotes should remain unchanged", expected, result);
                                                                                                                                
                                                                                                                                // Additional check to ensure no substring was taken
                                                                                                                                assertSame("Should return same string object when no stripping occurs", input, result);
                                                                                                                            }

    @Test
                                                                                                                            public void testStripLeadingAndTrailingQuotes_shouldStripWhenProperlyQuoted() throws Exception {
                                                                                                                                // Properly quoted string
                                                                                                                                String input = "\"quoted\"";
                                                                                                                                String expected = "quoted";
                                                                                                                                
                                                                                                                                // Get the Util class and method using reflection
                                                                                                                                Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                stripMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // Invoke the method
                                                                                                                                String result = (String) stripMethod.invoke(null, input);
                                                                                                                                
                                                                                                                                assertEquals("Properly quoted string should be stripped", expected, result);
                                                                                                                            }

    @Test
                                                                                                                            public void testStripLeadingAndTrailingQuotes_shouldNotStripWhenInnerQuotes() throws Exception {
                                                                                                                                // String with inner quotes
                                                                                                                                String input = "\"quo\"ted\"";
                                                                                                                                String expected = "\"quo\"ted\"";
                                                                                                                                
                                                                                                                                // Use reflection to access the non-public method
                                                                                                                                Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                stripMethod.setAccessible(true);
                                                                                                                                String result = (String) stripMethod.invoke(null, input);
                                                                                                                                
                                                                                                                                assertEquals("String with inner quotes should not be stripped", expected, result);
                                                                                                                            }

    @Test
                                                                                                                            public void testStripLeadingAndTrailingQuotes_shortString() throws Exception {
                                                                                                                                // Edge case - string of length 1
                                                                                                                                String input = "\"";
                                                                                                                                String expected = "\"";
                                                                                                                                
                                                                                                                                // Use reflection to access the non-public method
                                                                                                                                Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                                Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                                method.setAccessible(true);
                                                                                                                                String result = (String) method.invoke(null, input);
                                                                                                                                
                                                                                                                                assertEquals("Single quote should remain unchanged", expected, result);
                                                                                                                            }

    @Test
                                                                                                                       public void testStripLeadingAndTrailingQuotes_ShouldNotStripWhenOnlyEndsWithQuote() throws Exception {
                                                                                                                           // Arrange
                                                                                                                           String input = "abc\"";
                                                                                                                           String expected = "abc\"";
                                                                                                                           
                                                                                                                           // Get the method via reflection
                                                                                                                           Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                           Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                           stripMethod.setAccessible(true);
                                                                                                                           
                                                                                                                           // Act
                                                                                                                           String result = (String) stripMethod.invoke(null, input);
                                                                                                                           
                                                                                                                           // Assert
                                                                                                                           assertEquals("String ending with quote but not starting with one should remain unchanged", 
                                                                                                                                       expected, result);
                                                                                                                       }

    @Test
                                                                                                                       public void testStripLeadingAndTrailingQuotes_ShouldStripWhenBothQuoted() throws Exception {
                                                                                                                           // Arrange
                                                                                                                           String input = "\"abc\"";
                                                                                                                           String expected = "abc";
                                                                                                                           
                                                                                                                           // Get the Util class and method using reflection
                                                                                                                           Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                           Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                           stripMethod.setAccessible(true);
                                                                                                                           
                                                                                                                           // Act
                                                                                                                           String result = (String) stripMethod.invoke(null, input);
                                                                                                                           
                                                                                                                           // Assert
                                                                                                                           assertEquals("String with both starting and ending quotes should be stripped", 
                                                                                                                                       expected, result);
                                                                                                                       }

    @Test
                                                                                                               public void testStripLeadingAndTrailingQuotes_ShouldNotStripWhenOnlyStartsWithQuote() throws Exception {
                                                                                                                   // Arrange
                                                                                                                   String input = "\"abc";
                                                                                                                   String expected = "\"abc";
                                                                                                                   
                                                                                                                   // Get the method via reflection
                                                                                                                   Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                                   Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                   stripMethod.setAccessible(true);
                                                                                                                   
                                                                                                                   // Act
                                                                                                                   String result = (String) stripMethod.invoke(null, input);
                                                                                                                   
                                                                                                                   // Assert
                                                                                                                   assertEquals("String starting with quote but not ending with one should remain unchanged", 
                                                                                                                               expected, result);
                                                                                                               }

    @Test
                                                                                                          public void testStripLeadingAndTrailingQuotes_ShouldNotStripWhenOnlyStartsWithQuote1() {
                                                                                                              // Arrange
                                                                                                              String input = "\"test";  // Starts with quote but doesn't end with quote
                                                                                                              String expected = "\"test";  // Should remain unchanged
                                                                                                              
                                                                                                              // Act
                                                                                                              String actual = null;
                                                                                                              try {
                                                                                                                  Method method = Class.forName("org.apache.commons.cli.Util")
                                                                                                                          .getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                                  method.setAccessible(true);
                                                                                                                  actual = (String) method.invoke(null, input);
                                                                                                              } catch (Exception e) {
                                                                                                                  fail("Failed to invoke stripLeadingAndTrailingQuotes method via reflection: " + e.getMessage());
                                                                                                              }
                                                                                                              
                                                                                                              // Assert
                                                                                                              assertEquals("String starting with quote but not ending with quote should remain unchanged", 
                                                                                                                          expected, actual);
                                                                                                          }

    @Test
                                                                                                     public void testStripLeadingAndTrailingQuotes1() throws Exception {
                                                                                                         // Get the method via reflection
                                                                                                         Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                         Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                         stripMethod.setAccessible(true);
                                                                                                     
                                                                                                         // Test case that will catch the mutant
                                                                                                         // String with surrounding quotes but NO internal quotes
                                                                                                         // Original should strip, mutant should not
                                                                                                         String input1 = "\"hello\"";
                                                                                                         String expected1 = "hello";
                                                                                                         assertEquals(expected1, stripMethod.invoke(null, input1));
                                                                                                         
                                                                                                         // String with surrounding quotes AND internal quotes
                                                                                                         // Original should not strip, mutant should strip
                                                                                                         String input2 = "\"he\"llo\"";
                                                                                                         String expected2 = "\"he\"llo\"";
                                                                                                         assertEquals(expected2, stripMethod.invoke(null, input2));
                                                                                                         
                                                                                                         // Additional test cases for completeness
                                                                                                         // String without surrounding quotes
                                                                                                         String input3 = "hello";
                                                                                                         assertEquals(input3, stripMethod.invoke(null, input3));
                                                                                                         
                                                                                                         // Empty string
                                                                                                         String input4 = "";
                                                                                                         assertEquals(input4, stripMethod.invoke(null, input4));
                                                                                                         
                                                                                                         // Single character string
                                                                                                         String input5 = "\"";
                                                                                                         assertEquals(input5, stripMethod.invoke(null, input5));
                                                                                                     }

    @Test
                                                                                                public void testStripLeadingAndTrailingQuotes_shouldNotStripWhenInnerQuotesExist() {
                                                                                                    // This test will catch the mutant
                                                                                                    String input = "\"test\"quote\"";
                                                                                                    String expected = input; // Should not be stripped because there's an inner quote
                                                                                                    
                                                                                                    try {
                                                                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                        Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                        method.setAccessible(true);
                                                                                                        String actual = (String) method.invoke(null, input);
                                                                                                        
                                                                                                        assertEquals("String with inner quotes should not be stripped", expected, actual);
                                                                                                    } catch (Exception e) {
                                                                                                        fail("Failed to invoke stripLeadingAndTrailingQuotes method: " + e.getMessage());
                                                                                                    }
                                                                                                }

    @Test
                                                                                                public void testStripLeadingAndTrailingQuotes_shouldStripWhenNoInnerQuotes() {
                                                                                                    try {
                                                                                                        String input = "\"test\"";
                                                                                                        String expected = "test"; // Should be stripped
                                                                                                        
                                                                                                        // Get the method via reflection
                                                                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                        Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                        method.setAccessible(true);
                                                                                                        String actual = (String) method.invoke(null, input);
                                                                                                        
                                                                                                        assertEquals("String without inner quotes should be stripped", expected, actual);
                                                                                                    } catch (Exception e) {
                                                                                                        fail("Exception occurred during test: " + e.getMessage());
                                                                                                    }
                                                                                                }

    @Test
                                                                                            public void testStripLeadingAndTrailingQuotes_shouldNotStripSingleQuote() throws Exception {
                                                                                                String input = "\"";
                                                                                                String expected = input; // Should not be stripped (length <= 1)
                                                                                                
                                                                                                // Use reflection to access the private method
                                                                                                Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                                Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                                stripMethod.setAccessible(true);
                                                                                                String actual = (String) stripMethod.invoke(null, input);
                                                                                                
                                                                                                assertEquals("Single quote should not be stripped", expected, actual);
                                                                                            }

    @Test
                                                                                        public void testStripLeadingAndTrailingQuotes_shouldNotStripNonQuotedString() throws Exception {
                                                                                            String input = "test";
                                                                                            String expected = input; // Should not be stripped
                                                                                            
                                                                                            // Use reflection to access the private method
                                                                                            Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                            Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                            method.setAccessible(true);
                                                                                            String actual = (String) method.invoke(null, input);
                                                                                            
                                                                                            assertEquals("Non-quoted string should not be stripped", expected, actual);
                                                                                        }

    @Test
                                                                                   public void testStripLeadingAndTrailingQuotes_withQuoteAsSecondChar() throws Exception {
                                                                                       // This input will expose the mutant
                                                                                       String input = "\"\"abc\"";
                                                                                       
                                                                                       // Get the method via reflection
                                                                                       Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                       Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                       stripMethod.setAccessible(true);
                                                                                       
                                                                                       // Invoke the method
                                                                                       String result = (String) stripMethod.invoke(null, input);
                                                                                       
                                                                                       // Assert the string remains unchanged (original behavior)
                                                                                       assertEquals("\"\"abc\"", result);
                                                                                       
                                                                                       // The mutant would return ""abc" instead, failing this test
                                                                                   }

    @Test
                                                                                   public void testStripLeadingAndTrailingQuotes_normalCases() throws Exception {
                                                                                       // Get the private method via reflection
                                                                                       Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                       Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                       stripMethod.setAccessible(true);
                                                                                       
                                                                                       // Test normal case where quotes should be stripped
                                                                                       assertEquals("abc", stripMethod.invoke(null, "\"abc\""));
                                                                                       
                                                                                       // Test case with no quotes
                                                                                       assertEquals("abc", stripMethod.invoke(null, "abc"));
                                                                                       
                                                                                       // Test case with only one quote
                                                                                       assertEquals("\"", stripMethod.invoke(null, "\""));
                                                                                       
                                                                                       // Test case with inner quotes that should prevent stripping
                                                                                       assertEquals("\"a\"b\"", stripMethod.invoke(null, "\"a\"b\""));
                                                                                   }

    @Test
                                                                              public void testStripLeadingAndTrailingQuotes_withInternalQuoteAtEnd() throws Exception {
                                                                                  // This test case will catch the mutant
                                                                                  String input = "\"abc\"\"";
                                                                                  String expected = "abc\"";
                                                                                  
                                                                                  // With original code: 
                                                                                  // - length=6 (>1)
                                                                                  // - starts & ends with "
                                                                                  // - substring(1,5)="abc\"" contains " at index 3 → won't strip
                                                                                  // With mutant code:
                                                                                  // - substring(1,6)="abc\"" contains " at index 3 → won't strip
                                                                                  // BUT this is actually correct behavior since we have internal quote
                                                                                  
                                                                                  // Better test case to catch the mutant:
                                                                                  String input2 = "\"abc\"\"\"";
                                                                                  String expected2 = "abc\"";
                                                                                  
                                                                                  // Original:
                                                                                  // substring(1,6)="abc\"\"" - contains " at 3 and 5 → won't strip (correct)
                                                                                  // Mutant:
                                                                                  // substring(1,7)="abc\"\"" - contains " at 3 and 5 → won't strip (incorrect, should strip)
                                                                                  // Wait no, this still doesn't catch it
                                                                                  
                                                                                  // Actually the mutation isn't easily caught because:
                                                                                  // - For strings with no internal quotes, both work same
                                                                                  // - For strings with internal quotes, both work same
                                                                                  // The only difference is when the last character before closing quote is a quote
                                                                                  
                                                                                  // Correct test case to catch mutant:
                                                                                  String input3 = "\"a\"\"";
                                                                                  String expectedOriginal = "\"a\"\""; // not stripped because internal quote at pos 2
                                                                                  String expectedMutant = "a\""; // would be stripped by mutant
                                                                                  
                                                                                  // Use reflection to access the non-public method
                                                                                  Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                  Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                  stripMethod.setAccessible(true);
                                                                                  String result = (String) stripMethod.invoke(null, input3);
                                                                                  
                                                                                  assertEquals("Should not strip quotes when last char before end is quote", 
                                                                                              expectedOriginal, result);
                                                                              }

    @Test
                                                                              public void testStripLeadingAndTrailingQuotes_normalCase() throws Exception {
                                                                                  String input = "\"normal\"";
                                                                                  String expected = "normal";
                                                                                  
                                                                                  // Get the Util class
                                                                                  Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                  // Get the stripLeadingAndTrailingQuotes method
                                                                                  Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                  // Make the method accessible
                                                                                  method.setAccessible(true);
                                                                                  // Invoke the method
                                                                                  String result = (String) method.invoke(null, input);
                                                                                  
                                                                                  assertEquals(expected, result);
                                                                              }

    @Test
                                                                              public void testStripLeadingAndTrailingQuotes_noQuotes() throws Exception {
                                                                                  String input = "no quotes";
                                                                                  Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                  Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                  method.setAccessible(true);
                                                                                  String result = (String) method.invoke(null, input);
                                                                                  assertEquals(input, result);
                                                                              }

    @Test
                                                                              public void testStripLeadingAndTrailingQuotes_onlyTwoQuotes() throws Exception {
                                                                                  String input = "\"\"";
                                                                                  Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                                  Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                                  stripMethod.setAccessible(true);
                                                                                  String result = (String) stripMethod.invoke(null, input);
                                                                                  assertEquals(input, result);
                                                                              }

    @Test
                                                                      public void testStripLeadingAndTrailingQuotes_withInternalQuotes() throws Exception {
                                                                          String input = "\"a\"b\"";
                                                                          Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                          Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                          method.setAccessible(true);
                                                                          String result = (String) method.invoke(null, input);
                                                                          assertEquals(input, result);
                                                                      }

    @Test
                                                                 public void testStripLeadingAndTrailingQuotes_withQuoteBeforeEnd() {
                                                                     // This string has a quote as second-to-last character ("a"b")
                                                                     String input = "\"a\"b\"";
                                                                     
                                                                     // Original behavior: should not strip quotes because there's a quote before the end
                                                                     String expected = "\"a\"b\"";
                                                                     
                                                                     try {
                                                                         // Get the Util class
                                                                         Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                         // Get the stripLeadingAndTrailingQuotes method
                                                                         Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                         // Make the method accessible
                                                                         method.setAccessible(true);
                                                                         // Invoke the method
                                                                         String actual = (String) method.invoke(null, input);
                                                                         
                                                                         assertEquals("Should not strip quotes when quote appears before end", expected, actual);
                                                                     } catch (Exception e) {
                                                                         fail("Failed to invoke stripLeadingAndTrailingQuotes method: " + e.getMessage());
                                                                     }
                                                                 }

    @Test
                                                                 public void testStripLeadingAndTrailingQuotes_normalCase1() throws Exception {
                                                                     // Normal case with no internal quotes
                                                                     String input = "\"abc\"";
                                                                     String expected = "abc";
                                                                     
                                                                     // Get the Util class and method using reflection
                                                                     Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                     Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                     method.setAccessible(true);
                                                                     
                                                                     // Invoke the method
                                                                     String actual = (String) method.invoke(null, input);
                                                                     assertEquals("Should strip quotes for normal case", expected, actual);
                                                                 }

    @Test
                                                                 public void testStripLeadingAndTrailingQuotes_emptyString() throws Exception {
                                                                     // Edge case: empty string
                                                                     String input = "";
                                                                     String expected = "";
                                                                     
                                                                     // Get the Util class and method using reflection
                                                                     Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                                     Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                                     stripMethod.setAccessible(true);
                                                                     
                                                                     // Invoke the method
                                                                     String actual = (String) stripMethod.invoke(null, input);
                                                                     
                                                                     assertEquals("Empty string should return empty", expected, actual);
                                                                 }

    @Test
                                                         public void testStripLeadingAndTrailingQuotes_singleQuote() throws Exception {
                                                             // Edge case: single quote
                                                             String input = "\"";
                                                             String expected = "\"";
                                                             
                                                             // Use reflection to access the private method
                                                             Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                             Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                             stripMethod.setAccessible(true);
                                                             String actual = (String) stripMethod.invoke(null, input);
                                                             
                                                             assertEquals("Single quote should remain unchanged", expected, actual);
                                                         }

    @Test
                                                    public void testStripLeadingAndTrailingQuotes_shouldRemoveBothQuotes() throws Exception {
                                                        // Arrange
                                                        String input = "\"quoted string\"";
                                                        String expected = "quoted string";
                                                        
                                                        // Get the method via reflection
                                                        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                        Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                        method.setAccessible(true);
                                                        
                                                        // Act
                                                        String result = (String) method.invoke(null, input);
                                                        
                                                        // Assert
                                                        assertEquals("Both surrounding quotes should be removed", expected, result);
                                                        
                                                        // Additional check to specifically catch the mutant
                                                        assertFalse("First quote should be removed", result.startsWith("\""));
                                                    }

    @Test
                                               public void testStripLeadingAndTrailingQuotes_DetectsSubstringMutation() throws Exception {
                                                   // Test case that will catch the mutant
                                                   String input = "\"test\"";
                                                   String expected = "test";  // Correct output without quotes
                                                   
                                                   // Use reflection to access the non-public method
                                                   Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                   Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                   stripMethod.setAccessible(true);
                                                   String actual = (String) stripMethod.invoke(null, input);
                                                   
                                                   // This assertion will fail with the mutant
                                                   assertEquals("String should have both quotes removed", expected, actual);
                                                   
                                                   // Additional check to specifically verify the last character
                                                   assertFalse("Result should not end with quote", 
                                                              actual.endsWith("\""));
                                               }

    @Test
                                               public void testStripLeadingAndTrailingQuotes_EdgeCaseTwoCharacterString() throws Exception {
                                                   // Edge case with just two quotes
                                                   String input = "\"\"";
                                                   String expected = "";  // Correct output should be empty string
                                                   
                                                   // Use reflection to access the non-public method
                                                   Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                   Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                   stripMethod.setAccessible(true);
                                                   String actual = (String) stripMethod.invoke(null, input);
                                                   
                                                   assertEquals("Two-quote string should return empty string", expected, actual);
                                               }

    @Test
                                               public void testStripLeadingAndTrailingQuotes_NoQuotes() throws Exception {
                                                   // String without quotes should remain unchanged
                                                   String input = "test";
                                                   String expected = "test";
                                                   
                                                   // Get the method via reflection
                                                   Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                                   Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                   method.setAccessible(true);
                                                   
                                                   // Invoke the method
                                                   String actual = (String) method.invoke(null, input);
                                                   
                                                   assertEquals("String without quotes should be unchanged", expected, actual);
                                               }

    @Test
                                               public void testStripLeadingAndTrailingQuotes_WithInternalQuotes() throws Exception {
                                                   // String with internal quotes shouldn't be stripped
                                                   String input = "\"te\"st\"";
                                                   String expected = "\"te\"st\"";
                                                   
                                                   // Use reflection to access the private method
                                                   Class<?> clazz = Class.forName("org.apache.commons.cli.Util");
                                                   Method method = clazz.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                                   method.setAccessible(true);
                                                   String actual = (String) method.invoke(null, input);
                                                   
                                                   assertEquals("String with internal quotes should remain unchanged", expected, actual);
                                               }

    @Test
                                          public void testStripLeadingAndTrailingQuotes_ShouldRemoveQuotes() throws Exception {
                                              // Get the method via reflection
                                              Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                              Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                              stripMethod.setAccessible(true);
                                          
                                              // Test case that will detect the mutant
                                              String input = "\"quoted string\"";
                                              String expected = "quoted string";
                                              
                                              // The original method should return without quotes
                                              String actual = (String) stripMethod.invoke(null, input);
                                              
                                              // This assertion will fail if the mutant is present
                                              assertEquals("String should have quotes removed", expected, actual);
                                              
                                              // Additional test cases for thorough coverage
                                              // Case with no quotes
                                              assertEquals("no quotes", stripMethod.invoke(null, "no quotes"));
                                              
                                              // Case with only one quote
                                              assertEquals("\"", stripMethod.invoke(null, "\""));
                                              
                                              // Case with quotes inside
                                              assertEquals("\"quotes\" inside", stripMethod.invoke(null, "\"quotes\" inside"));
                                              
                                              // Case with multiple quotes at ends
                                              assertEquals("\"quoted\" string", stripMethod.invoke(null, "\"\"quoted\" string\""));
                                          }

    @Test
                                     public void testStripLeadingAndTrailingQuotes_shouldRemoveOneCharFromEachEnd() throws Exception {
                                         // Test with minimal valid string (3 chars) that should be stripped
                                         String input = "\"a\"";
                                         String expected = "a";
                                         
                                         // Use reflection to access the non-public method
                                         Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                         Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                         method.setAccessible(true);
                                         String result = (String) method.invoke(null, input);
                                         
                                         // This will catch the mutant because:
                                         // Original: substring(1,2) -> "a"
                                         // Mutant: substring(2,2) -> empty string
                                         assertEquals("Should remove exactly one quote from each end", expected, result);
                                     }

    @Test
                                     public void testStripLeadingAndTrailingQuotes_shouldNotAffectLongerStringStart() throws Exception {
                                         // Test with longer string to verify starting position
                                         String input = "\"abc\"";
                                         String expected = "abc";
                                         
                                         // Get the Util class and method using reflection
                                         Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                         Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                         stripMethod.setAccessible(true);
                                         
                                         // Invoke the method
                                         String result = (String) stripMethod.invoke(null, input);
                                         
                                         // This will catch the mutant because:
                                         // Original: substring(1,4) -> "abc"
                                         // Mutant: substring(2,4) -> "bc"
                                         assertEquals("Should preserve all characters between quotes", expected, result);
                                     }

    @Test
                                     public void testStripLeadingAndTrailingQuotes_shouldNotStripWhenInnerQuotesExist1() throws Exception {
                                         // Test case that shouldn't be stripped at all
                                         String input = "\"a\"b\"";
                                         String expected = "\"a\"b\"";
                                         
                                         // Use reflection to access the private method
                                         Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                         Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                         method.setAccessible(true);
                                         String result = (String) method.invoke(null, input);
                                         
                                         assertEquals("Should not strip when inner quotes exist", expected, result);
                                     }

    @Test
                                public void testStripLeadingAndTrailingQuotes_WithSingleCharBetweenQuotes() throws Exception {
                                    // This test will catch the mutant by using a string with exactly one character between quotes
                                    String input = "\"a\"";
                                    String expected = "a";  // Original behavior would return this
                                    
                                    // Get the method via reflection
                                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                    Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                    stripMethod.setAccessible(true);
                                    
                                    String actual = (String) stripMethod.invoke(null, input);
                                    
                                    // The mutant would return empty string "" because it would do substring(1, 3-2) = substring(1,1)
                                    assertEquals("Should preserve single character between quotes", expected, actual);
                                    
                                    // Additional test case with two characters between quotes to show normal case
                                    String input2 = "\"ab\"";
                                    String expected2 = "ab";
                                    String actual2 = (String) stripMethod.invoke(null, input2);
                                    assertEquals("Should preserve two characters between quotes", expected2, actual2);
                                }

    @Test
                                public void testStripLeadingAndTrailingQuotes_EdgeCases() throws Exception {
                                    // Get the Util class and method via reflection
                                    Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                                    Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                                    stripMethod.setAccessible(true);
                                    
                                    // Test empty string
                                    assertEquals("", stripMethod.invoke(null, ""));
                                    
                                    // Test single quote
                                    assertEquals("\"", stripMethod.invoke(null, "\""));
                                    
                                    // Test two quotes
                                    assertEquals("\"\"", stripMethod.invoke(null, "\"\""));
                                    
                                    // Test string with inner quotes (shouldn't strip)
                                    assertEquals("\"a\"b\"", stripMethod.invoke(null, "\"a\"b\""));
                                    
                                    // Test string without quotes
                                    assertEquals("abc", stripMethod.invoke(null, "abc"));
                                }

    @Test
                           public void testStripLeadingAndTrailingQuotes_ShouldRemoveQuotes1() throws Exception {
                               // Test case that should detect the mutant
                               String input = "\"quoted string\"";
                               String expected = "quoted string";
                               
                               // Get the Util class and method using reflection
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                               stripMethod.setAccessible(true);
                               
                               // Invoke the method
                               String actual = (String) stripMethod.invoke(null, input);
                               
                               // This assertion will fail with the mutant
                               assertEquals("Should remove surrounding quotes when conditions are met", 
                                           expected, actual);
                           }

    @Test
                           public void testStripLeadingAndTrailingQuotes_NoQuotes1() throws Exception {
                               // String without quotes should remain unchanged
                               String input = "no quotes";
                               String expected = "no quotes";
                               
                               // Use reflection to access the package-private method
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                               method.setAccessible(true);
                               String actual = (String) method.invoke(null, input);
                               
                               assertEquals(expected, actual);
                           }

    @Test
                           public void testStripLeadingAndTrailingQuotes_OnlyStartQuote() throws Exception {
                               // String with only starting quote should remain unchanged
                               String input = "\"only start quote";
                               String expected = "\"only start quote";
                               
                               // Use reflection to access the non-public method
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                               method.setAccessible(true);
                               String actual = (String) method.invoke(null, input);
                               
                               assertEquals(expected, actual);
                           }

    @Test
                           public void testStripLeadingAndTrailingQuotes_OnlyEndQuote() throws Exception {
                               // String with only ending quote should remain unchanged
                               String input = "only end quote\"";
                               String expected = "only end quote\"";
                               
                               // Use reflection to access the non-public method
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                               method.setAccessible(true);
                               String actual = (String) method.invoke(null, input);
                               
                               assertEquals(expected, actual);
                           }

    @Test
                           public void testStripLeadingAndTrailingQuotes_InternalQuotes() throws Exception {
                               // String with internal quotes should remain unchanged
                               String input = "\"has \"internal\" quotes\"";
                               String expected = "\"has \"internal\" quotes\"";
                               
                               // Use reflection to access the package-private method
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                               method.setAccessible(true);
                               String actual = (String) method.invoke(null, input);
                               
                               assertEquals(expected, actual);
                           }

    @Test
                           public void testStripLeadingAndTrailingQuotes_EmptyString() throws Exception {
                               // Empty string should remain unchanged
                               String input = "";
                               String expected = "";
                               
                               // Get the method via reflection
                               Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                               Method method = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                               method.setAccessible(true);
                               
                               // Invoke the method
                               String actual = (String) method.invoke(null, input);
                               assertEquals(expected, actual);
                           }

    @Test
                           public void testStripLeadingAndTrailingQuotes_SingleQuote1() throws Exception {
                               // Single quote string should remain unchanged
                               String input = "\"";
                               String expected = "\"";
                               
                               // Use reflection to access the private static method
                               Class<?> clazz = Class.forName("org.apache.commons.cli.Util");
                               Method method = clazz.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                               method.setAccessible(true);
                               String actual = (String) method.invoke(null, input);
                               
                               assertEquals(expected, actual);
                           }

    @Test
                      public void testStripLeadingAndTrailingQuotes_ShouldRemoveBothQuotes() throws Exception {
                          // Get the Util class and method using reflection
                          Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                          Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                          stripMethod.setAccessible(true);
                      
                          // Test case that will catch the mutant
                          String input = "\"quoted string\"";
                          String expected = "quoted string";
                          
                          // The original method would return "quoted string"
                          // The mutated method would return "quoted string\""
                          String actual = (String) stripMethod.invoke(null, input);
                          
                          assertEquals("Should remove both leading and trailing quotes", 
                                       expected, actual);
                          
                          // Additional test cases for thorough coverage
                          // Test with no quotes
                          assertEquals("no quotes", stripMethod.invoke(null, "no quotes"));
                          
                          // Test with only leading quote
                          assertEquals("\"only leading", stripMethod.invoke(null, "\"only leading"));
                          
                          // Test with only trailing quote
                          assertEquals("only trailing\"", stripMethod.invoke(null, "only trailing\""));
                          
                          // Test with quotes in the middle
                          assertEquals("\"quotes in\" middle", stripMethod.invoke(null, "\"quotes in\" middle"));
                          
                          // Test with single character (shouldn't be stripped even if quoted)
                          assertEquals("\"a\"", stripMethod.invoke(null, "\"a\""));
                          
                          // Test with empty string
                          assertEquals("", stripMethod.invoke(null, ""));
                      }

    @Test
                 public void testStripLeadingAndTrailingQuotes_ShouldNotModifyString() throws Exception {
                     // Get the method via reflection
                     Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                     Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                     stripMethod.setAccessible(true);
                     
                     // Test case where string shouldn't be modified (no quotes)
                     String input1 = "hello";
                     assertEquals("String without quotes should remain unchanged", 
                                 input1, 
                                 stripMethod.invoke(null, input1));
                     
                     // Test case where string shouldn't be modified (internal quotes only)
                     String input2 = "he\"llo";
                     assertEquals("String with internal quotes only should remain unchanged", 
                                 input2, 
                                 stripMethod.invoke(null, input2));
                     
                     // Test case with single character
                     String input3 = "h";
                     assertEquals("Single character string should remain unchanged", 
                                 input3, 
                                 stripMethod.invoke(null, input3));
                     
                     // Test case with empty string
                     String input4 = "";
                     assertEquals("Empty string should remain unchanged", 
                                 input4, 
                                 stripMethod.invoke(null, input4));
                 }

    @Test
                 public void testStripLeadingAndTrailingQuotes_ShouldRemoveQuotes2() throws Exception {
                     // Get the Util class and method using reflection
                     Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
                     Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
                     stripMethod.setAccessible(true);
                     
                     // Test case where quotes should be removed
                     String input1 = "\"hello\"";
                     String result1 = (String) stripMethod.invoke(null, input1);
                     assertEquals("String with only outer quotes should have quotes removed", 
                                 "hello", 
                                 result1);
                     
                     // Test case with minimum length that can be modified
                     String input2 = "\"\"\"";
                     String result2 = (String) stripMethod.invoke(null, input2);
                     assertEquals("Three-quote string should be reduced to single quote", 
                                 "\"", 
                                 result2);
                 }

    @Test
         public void testStripLeadingAndTrailingQuotes_ShouldNotRemoveQuotesWhenInternalQuotesExist() throws Exception {
             // Test case where quotes shouldn't be removed due to internal quotes
             String input1 = "\"he\"llo\"";
             
             // Use reflection to access the private method
             Class<?> clazz = Class.forName("org.apache.commons.cli.Util");
             Method method = clazz.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
             method.setAccessible(true);
             String result = (String) method.invoke(null, input1);
             
             assertEquals("String with internal quotes should remain unchanged", 
                         input1, 
                         result);
         }

    @Test
    public void testStripLeadingAndTrailingQuotes_returnsSameObjectWhenNoModification() throws Exception {
        // Test cases where string shouldn't be modified
        String test1 = "hello";
        String test2 = "\"";
        String test3 = "a\"b";
        
        // Get the Util class and method using reflection
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
        stripMethod.setAccessible(true);
        
        // Verify same object is returned when no modification needed
        assertSame("Should return same object when no quotes to strip", 
                  test1, stripMethod.invoke(null, test1));
        assertSame("Should return same object for single character", 
                  test2, stripMethod.invoke(null, test2));
        assertSame("Should return same object when quotes are in middle", 
                  test3, stripMethod.invoke(null, test3));
        
        // Also verify content is correct
        assertEquals("hello", stripMethod.invoke(null, test1));
        assertEquals("\"", stripMethod.invoke(null, test2));
        assertEquals("a\"b", stripMethod.invoke(null, test3));
    }

    @Test
    public void testStripLeadingAndTrailingQuotes_stripsWhenAppropriate() throws Exception {
        // Get the Util class and method via reflection
        Class<?> utilClass = Class.forName("org.apache.commons.cli.Util");
        Method stripMethod = utilClass.getDeclaredMethod("stripLeadingAndTrailingQuotes", String.class);
        stripMethod.setAccessible(true);
        
        // Test cases where string should be modified
        String test1 = "\"hello\"";
        String test2 = "\"\"\"";
        String test3 = "\"a\"";
        
        // These should return new string objects
        assertEquals("hello", stripMethod.invoke(null, test1));
        assertEquals("\"", stripMethod.invoke(null, test2));
        assertEquals("a", stripMethod.invoke(null, test3));
        
        // Verify they're not the same objects
        assertNotSame(test1, stripMethod.invoke(null, test1));
        assertNotSame(test2, stripMethod.invoke(null, test2));
        assertNotSame(test3, stripMethod.invoke(null, test3));
    }


}
