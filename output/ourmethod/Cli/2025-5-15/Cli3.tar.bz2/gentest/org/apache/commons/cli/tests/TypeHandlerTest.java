package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
 
public class TypeHandlerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                 public void testCreateNumber_NullInput() {
                                                     assertNull(TypeHandler.createNumber(null));
                                                 }

    @Test
                                                 public void testCreateNumber_EmptyString() {
                                                     assertNull(TypeHandler.createNumber(""));
                                                 }

    @Test
                                                 public void testCreateNumber_ValidInteger() {
                                                     Number result = TypeHandler.createNumber("123");
                                                     assertTrue(result instanceof Long);
                                                     assertEquals(123L, result.longValue());
                                                 }

    @Test
                                                 public void testCreateNumber_ValidNegativeInteger() {
                                                     Number result = TypeHandler.createNumber("-456");
                                                     assertTrue(result instanceof Long);
                                                     assertEquals(-456L, result.longValue());
                                                 }

    @Test
                                                 public void testCreateNumber_ValidDecimal() {
                                                     Number result = TypeHandler.createNumber("123.45");
                                                     assertTrue(result instanceof Double);
                                                     assertEquals(123.45, result.doubleValue(), 0.0001);
                                                 }

    @Test
                                                 public void testCreateNumber_ValidNegativeDecimal() {
                                                     Number result = TypeHandler.createNumber("-456.78");
                                                     assertTrue(result instanceof Double);
                                                     assertEquals(-456.78, result.doubleValue(), 0.0001);
                                                 }

    @Test
                                                 public void testCreateNumber_InvalidNumber() {
                                                     assertNull(TypeHandler.createNumber("abc123"));
                                                 }

    @Test
                                                 public void testCreateNumber_PartialNumber() {
                                                     assertNull(TypeHandler.createNumber("123abc"));
                                                 }

    @Test
                                                 public void testCreateNumber_MultipleDots() {
                                                     assertNull(TypeHandler.createNumber("123.45.67"));
                                                 }

    @Test
                                                 public void testCreateNumber_LargeInteger() {
                                                     Number result = TypeHandler.createNumber("9223372036854775807"); // Long.MAX_VALUE
                                                     assertTrue(result instanceof Long);
                                                     assertEquals(Long.MAX_VALUE, result.longValue());
                                                 }

    @Test
                                                 public void testCreateNumber_LargeDecimal() {
                                                     Number result = TypeHandler.createNumber("1.7976931348623157E308"); // Double.MAX_VALUE
                                                     assertTrue(result instanceof Double);
                                                     assertEquals(Double.MAX_VALUE, result.doubleValue(), 0.0001);
                                                 }

    @Test
                                                 public void testCreateNumber_ScientificNotation() {
                                                     // Even though not explicitly handled, Double.valueOf can parse scientific notation
                                                     Number result = TypeHandler.createNumber("1.23E4");
                                                     assertTrue(result instanceof Double);
                                                     assertEquals(12300.0, result.doubleValue(), 0.0001);
                                                 }

    @Test
                                                 public void testCreateNumber_Whitespace() {
                                                     assertNull(TypeHandler.createNumber(" 123 ")); // Would need trim() to handle
                                                 }

    @Test
                                             public void testCreateNumberWithLeadingDecimal() {
                                                 // Test with decimal at start of string (index 0)
                                                 String input = ".123";
                                                 
                                                 // Should return a Double since it contains a decimal point
                                                 Number result = TypeHandler.createNumber(input);
                                                 
                                                 // Verify the result is not null
                                                 assertNotNull(result);
                                                 
                                                 // Verify the correct type is returned (Double)
                                                 assertTrue(result instanceof Double);
                                                 
                                                 // Verify the value is correct
                                                 assertEquals(0.123, result.doubleValue(), 0.0001);
                                             }

    @Test
                                             public void testCreateNumberWithTrailingDecimal() {
                                                 // Test with decimal at end of string
                                                 String input = "123.";
                                                 
                                                 // Should return a Double since it contains a decimal point
                                                 Number result = TypeHandler.createNumber(input);
                                                 
                                                 // Verify the result is not null
                                                 assertNotNull(result);
                                                 
                                                 // Verify the correct type is returned (Double)
                                                 assertTrue(result instanceof Double);
                                                 
                                                 // Verify the value is correct (should be 123.0)
                                                 assertEquals(123.0, result.doubleValue(), 0.0001);
                                             }

    @Test
                                             public void testCreateNumberWithMiddleDecimal() {
                                                 // Test with decimal in middle of string
                                                 String input = "12.34";
                                                 
                                                 // Should return a Double since it contains a decimal point
                                                 Number result = TypeHandler.createNumber(input);
                                                 
                                                 // Verify the result is not null
                                                 assertNotNull(result);
                                                 
                                                 // Verify the correct type is returned (Double)
                                                 assertTrue(result instanceof Double);
                                                 
                                                 // Verify the value is correct
                                                 assertEquals(12.34, result.doubleValue(), 0.0001);
                                             }

    @Test
                                             public void testCreateNumberWithNoDecimal() {
                                                 // Test with no decimal point
                                                 String input = "12345";
                                                 
                                                 // Should return a Long since there's no decimal point
                                                 Number result = TypeHandler.createNumber(input);
                                                 
                                                 // Verify the result is not null
                                                 assertNotNull(result);
                                                 
                                                 // Verify the correct type is returned (Long)
                                                 assertTrue(result instanceof Long);
                                                 
                                                 // Verify the value is correct
                                                 assertEquals(12345L, result.longValue());
                                             }

    @Test
                                             public void testCreateNumberWithNullInput() {
                                                 // Test with null input
                                                 Number result = TypeHandler.createNumber(null);
                                                 
                                                 // Should return null
                                                 assertNull(result);
                                             }

    @Test
                                             public void testCreateNumberWithInvalidNumber() {
                                                 // Test with invalid number format
                                                 String input = "abc.123";
                                                 
                                                 // Should catch NumberFormatException and return null
                                                 Number result = TypeHandler.createNumber(input);
                                                 
                                                 // Verify null is returned
                                                 assertNull(result);
                                             }

    @Test
                                            public void testCreateNumberWithDecimalPointAtStart() {
                                                // This test specifically catches the mutant
                                                // Original and mutant behave the same for most cases,
                                                // but we want to ensure the condition is properly checked
                                                Number result = TypeHandler.createNumber(".123");
                                                assertTrue("Should return Double when '.' is at start", 
                                                          result instanceof Double);
                                                assertEquals(0.123, result.doubleValue(), 0.0001);
                                            }

    @Test
                                            public void testCreateNumberWithDecimalPoint() {
                                                Number result = TypeHandler.createNumber("123.45");
                                                assertTrue("Should return Double when string contains '.'", 
                                                          result instanceof Double);
                                                assertEquals(123.45, result.doubleValue(), 0.0001);
                                            }

    @Test
                                            public void testCreateNumberWithoutDecimalPoint() {
                                                Number result = TypeHandler.createNumber("12345");
                                                assertTrue("Should return Long when no '.' present", 
                                                          result instanceof Long);
                                                assertEquals(12345L, result.longValue());
                                            }

    @Test
                                            public void testCreateNumberWithNullInput1() {
                                                Number result = TypeHandler.createNumber(null);
                                                assertNull("Should return null for null input", result);
                                            }

    @Test
                                            public void testCreateNumberWithInvalidNumber1() {
                                                Number result = TypeHandler.createNumber("abc");
                                                assertNull("Should return null for invalid number string", result);
                                            }

    @Test
                                            public void testCreateNumberWithEmptyString() {
                                                Number result = TypeHandler.createNumber("");
                                                assertNull("Should return null for empty string", result);
                                            }

    @Test
                                           public void testCreateNumberUsesValueOfForDouble() {
                                               // Test with a string that would be cached by Double.valueOf()
                                               String cachedDoubleStr = "1.0";
                                               
                                               // Call the method twice with same input
                                               Number result1 = TypeHandler.createNumber(cachedDoubleStr);
                                               Number result2 = TypeHandler.createNumber(cachedDoubleStr);
                                               
                                               // Verify it's using valueOf() by checking object identity
                                               // If using new Double(), these would be different objects
                                               assertSame("Expected Double.valueOf() to return same object for cached values", 
                                                         result1, result2);
                                               
                                               // Also verify the value is correct
                                               assertEquals(1.0, result1.doubleValue(), 0.0001);
                                           }

    @Test
                                           public void testCreateNumberWithIntegerString() {
                                               String intStr = "123";
                                               Number result = TypeHandler.createNumber(intStr);
                                               assertTrue(result instanceof Long);
                                               assertEquals(123L, result.longValue());
                                           }

    @Test
                                           public void testCreateNumberWithNull() {
                                               assertNull(TypeHandler.createNumber(null));
                                           }

    @Test
                                           public void testCreateNumberWithInvalidNumber2() {
                                               assertNull(TypeHandler.createNumber("abc"));
                                           }

    @Test
                                      public void testCreateNumberWithCachedLongValue() {
                                          // Test with a value that should be cached (-128 to 127)
                                          String input = "100";
                                          
                                          // Call the method twice - cached version should return same instance
                                          Long result1 = (Long) TypeHandler.createNumber(input);
                                          Long result2 = (Long) TypeHandler.createNumber(input);
                                          
                                          // Original code would use cached instance (same object)
                                          // Mutant would create new instances (different objects)
                                          assertSame("Expected cached Long instances to be the same object", 
                                                    result1, result2);
                                          
                                          // Additional assertions to verify correct value
                                          assertEquals(100L, result1.longValue());
                                          assertEquals(100L, result2.longValue());
                                      }

    @Test
                                    public void testCreateNumberErrorOutput() {
                                        // Save original streams
                                        java.io.PrintStream originalErr = System.err;
                                        java.io.PrintStream originalOut = System.out;
                                        
                                        try {
                                            // Create streams to capture output
                                            java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                                            java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
                                            
                                            // Redirect streams
                                            System.setErr(new java.io.PrintStream(errContent));
                                            System.setOut(new java.io.PrintStream(outContent));
                                            
                                            // Test with invalid number to trigger exception
                                            String invalidNumber = "abc123";
                                            Number result = TypeHandler.createNumber(invalidNumber);
                                            
                                            // Verify null is returned for invalid input
                                            assertNull(result);
                                            
                                            // Verify error was printed to System.err (original behavior)
                                            // This will fail if mutant is present (which uses System.out)
                                            assertTrue("Error should be logged to stderr", 
                                                      errContent.toString().contains("NumberFormatException"));
                                            assertFalse("Error should not be logged to stdout",
                                                      outContent.toString().contains("NumberFormatException"));
                                            
                                        } finally {
                                            // Restore original streams
                                            System.setErr(originalErr);
                                            System.setOut(originalOut);
                                        }
                                    }

    @Test
                           public void testCreateNumberWithInvalidInputLogsFullException() {
                               // Arrange
                               String invalidNumber = "abc123";
                               java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                               java.io.PrintStream originalErr = System.err;
                               System.setErr(new java.io.PrintStream(errContent));
                               
                               try {
                                   // Act
                                   Number result = TypeHandler.createNumber(invalidNumber);
                                   
                                   // Assert
                                   assertNull(result);
                                   String errorOutput = errContent.toString().trim();
                                   assertTrue("Error output should contain full exception string",
                                           errorOutput.contains("NumberFormatException"));
                                   assertTrue("Error output should contain full exception string",
                                           errorOutput.contains(invalidNumber));
                               } finally {
                                   // Clean up
                                   System.setErr(originalErr);
                               }
                           }

    @Test
                  public void testCreateNumber_InvalidNumber_ShouldPrintExceptionMessage() {
                      // Arrange
                      String invalidNumber = "123abc";
                      java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                      java.io.PrintStream originalErr = System.err;
                      System.setErr(new java.io.PrintStream(errContent));
                      
                      try {
                          // Act
                          Number result = TypeHandler.createNumber(invalidNumber);
                          
                          // Assert
                          assertNull(result);
                          assertTrue("Error output should contain exception message", 
                                    errContent.toString().contains("For input string: \"123abc\""));
                      } finally {
                          // Clean up
                          System.setErr(originalErr);
                      }
                  }

    @Test
         public void testCreateNumberErrorOutputFormat() {
             // Save original System.err
             java.io.PrintStream originalErr = System.err;
             
             // Create stream to capture error output
             java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
             System.setErr(new java.io.PrintStream(errContent));
             
             try {
                 // Test with invalid number string to trigger NumberFormatException
                 String invalidNumber = "abc123";
                 
                 // Call the method
                 java.lang.Number result = org.apache.commons.cli.TypeHandler.createNumber(invalidNumber);
                 
                 // Verify null is returned
                 assertNull(result);
                 
                 // Get the error output
                 String errorOutput = errContent.toString();
                 
                 // Verify the output contains only the message (not stack trace)
                 // Original behavior would output just the message
                 // Mutated behavior would output full stack trace
                 assertFalse("Error output should not contain stack trace elements", 
                            errorOutput.contains("at "));
                 assertTrue("Error output should contain the error message", 
                           errorOutput.contains("For input string: \"" + invalidNumber + "\""));
             } finally {
                 // Restore original System.err
                 System.setErr(originalErr);
             }
         }

    @Test
    public void testCreateNumber_InvalidNumber_ShouldPrintErrorMessage() {
        // Import required classes
        java.io.PrintStream originalErr = System.err;
        java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
        
        try {
            // Set up output capture
            System.setErr(new java.io.PrintStream(errContent));
            
            // Test with invalid number string
            String invalidNumber = "abc123";
            Number result = TypeHandler.createNumber(invalidNumber);
            
            // Verify null is returned (main functionality)
            assertNull(result);
            
            // Verify error was printed to System.err
            String errOutput = errContent.toString();
            assertFalse("Error output should not be empty", errOutput.isEmpty());
            assertTrue("Error output should contain number format exception", 
                      errOutput.contains("NumberFormatException"));
        } finally {
            // Restore original System.err
            System.setErr(originalErr);
        }
    }


}
