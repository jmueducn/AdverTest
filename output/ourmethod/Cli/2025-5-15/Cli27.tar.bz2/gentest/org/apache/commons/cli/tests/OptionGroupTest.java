package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
 
public class OptionGroupTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                              public void testSetSelected_DifferentOptionThrowsException() throws Exception {
                                                                                                                                  OptionGroup optionGroup = new OptionGroup();
                                                                                                                                  
                                                                                                                                  // Create mock options and set their keys using reflection
                                                                                                                                  Option option1 = mock(Option.class);
                                                                                                                                  Field keyField1 = Option.class.getDeclaredField("key");
                                                                                                                                  keyField1.setAccessible(true);
                                                                                                                                  keyField1.set(option1, "firstKey");
                                                                                                                                  
                                                                                                                                  Option option2 = mock(Option.class);
                                                                                                                                  Field keyField2 = Option.class.getDeclaredField("key");
                                                                                                                                  keyField2.setAccessible(true);
                                                                                                                                  keyField2.set(option2, "secondKey");
                                                                                                                                  
                                                                                                                                  // Set up exception expectation
                                                                                                                                  ExpectedException exception = ExpectedException.none();
                                                                                                                                  exception.expect(AlreadySelectedException.class);
                                                                                                                                  exception.expectMessage("The option 'secondKey' was specified but an option from this group has already been selected: 'firstKey'");
                                                                                                                                  
                                                                                                                                  optionGroup.setSelected(option1);
                                                                                                                                  optionGroup.setSelected(option2);
                                                                                                                              }

    @Test
                                                                                                                          public void testSetSelected_NullOption() {
                                                                                                                              OptionGroup optionGroup = new OptionGroup();
                                                                                                                              try {
                                                                                                                                  optionGroup.setSelected(new Option("test", false, "test option")); // Set some option first
                                                                                                                                  optionGroup.setSelected(null); // Now set to null
                                                                                                                              } catch (AlreadySelectedException e) {
                                                                                                                                  fail("Unexpected AlreadySelectedException thrown");
                                                                                                                              }
                                                                                                                              
                                                                                                                              assertNull(optionGroup.getSelected());
                                                                                                                          }

    @Test
                                                                                                                          public void testSetSelected_FirstSelection() throws AlreadySelectedException {
                                                                                                                              OptionGroup optionGroup = new OptionGroup();
                                                                                                                              Option option = mock(Option.class);
                                                                                                                              when(option.toString()).thenReturn("testKey");
                                                                                                                              
                                                                                                                              optionGroup.setSelected(option);
                                                                                                                              
                                                                                                                              assertEquals("testKey", optionGroup.getSelected());
                                                                                                                          }

    @Test
                                                                                                                          public void testSetSelected_ReselectSameOption() throws AlreadySelectedException {
                                                                                                                              OptionGroup optionGroup = new OptionGroup();
                                                                                                                              Option option = mock(Option.class);
                                                                                                                              
                                                                                                                              // Since we can't mock getKey(), we'll rely on the OptionGroup's behavior
                                                                                                                              // The test verifies that reselecting the same option doesn't throw an exception
                                                                                                                              // and maintains the same selection
                                                                                                                              optionGroup.setSelected(option);
                                                                                                                              optionGroup.setSelected(option); // Reselect same option
                                                                                                                              
                                                                                                                              // Verify the selection is maintained (though we can't verify the exact key)
                                                                                                                              assertNotNull(optionGroup.getSelected());
                                                                                                                          }

    @Test
                                                                                                                          public void testSetSelected_AfterReset() throws AlreadySelectedException {
                                                                                                                              OptionGroup optionGroup = new OptionGroup();
                                                                                                                              Option option1 = mock(Option.class);
                                                                                                                              Option option2 = mock(Option.class);
                                                                                                                              
                                                                                                                              optionGroup.addOption(option1);
                                                                                                                              optionGroup.addOption(option2);
                                                                                                                              
                                                                                                                              optionGroup.setSelected(option1);
                                                                                                                              optionGroup.setSelected(null); // Reset
                                                                                                                              optionGroup.setSelected(option2); // Now should work
                                                                                                                              
                                                                                                                              assertEquals(option2, optionGroup.getSelected());
                                                                                                                          }

    @Test
                                                                                                                 public void testSetSelectedWithNullOption() throws AlreadySelectedException {
                                                                                                                     OptionGroup optionGroup = new OptionGroup();
                                                                                                                     optionGroup.setSelected(new Option("test", false, "test option")); // set some option first
                                                                                                                     optionGroup.setSelected(null); // should clear selection
                                                                                                                     assertNull(optionGroup.getSelected());
                                                                                                                 }

    @Test(expected = AlreadySelectedException.class)
                                                                                                                 public void testSetSelectedWithDifferentOptionThrowsException() throws AlreadySelectedException {
                                                                                                                     // Setup
                                                                                                                     OptionGroup optionGroup = new OptionGroup();
                                                                                                                     Option option1 = new Option("a", "opt1");
                                                                                                                     Option option2 = new Option("b", "opt2");
                                                                                                                     
                                                                                                                     // First selection - should work
                                                                                                                     optionGroup.setSelected(option1);
                                                                                                                     
                                                                                                                     // Try to select different option - should throw exception
                                                                                                                     optionGroup.setSelected(option2);
                                                                                                                     
                                                                                                                     // If mutant exists, this line would be reached and test would fail
                                                                                                                     // because the mutated version would accept the different option
                                                                                                                 }

    @Test
                                                                                                                 public void testSetSelectedWithSameOption() throws AlreadySelectedException {
                                                                                                                     OptionGroup optionGroup = new OptionGroup();
                                                                                                                     Option option = mock(Option.class);
                                                                                                                     when(option.getOpt()).thenReturn("opt1");
                                                                                                                     
                                                                                                                     // First selection
                                                                                                                     optionGroup.setSelected(option);
                                                                                                                     
                                                                                                                     // Reselect same option - should work
                                                                                                                     optionGroup.setSelected(option);
                                                                                                                     
                                                                                                                     assertEquals("opt1", optionGroup.getSelected());
                                                                                                                 }

    @Test
                                                                                                                 public void testSetSelectedInitialSelection() throws AlreadySelectedException {
                                                                                                                     OptionGroup optionGroup = new OptionGroup();
                                                                                                                     Option option = new Option("opt1", "description");
                                                                                                                     
                                                                                                                     // First selection
                                                                                                                     optionGroup.setSelected(option);
                                                                                                                     
                                                                                                                     assertEquals("opt1", optionGroup.getSelected());
                                                                                                                 }

    @Test
                                                                                                            public void testSetSelectedWithNullKeyOptionAfterSelection() throws Exception {
                                                                                                                // Setup
                                                                                                                OptionGroup optionGroup = new OptionGroup();
                                                                                                                
                                                                                                                // Create valid option mock
                                                                                                                Option validOption = mock(Option.class);
                                                                                                                Field keyField = Option.class.getDeclaredField("key");
                                                                                                                keyField.setAccessible(true);
                                                                                                                keyField.set(validOption, "validKey");
                                                                                                                
                                                                                                                // Create null key option mock
                                                                                                                Option nullKeyOption = mock(Option.class);
                                                                                                                keyField.set(nullKeyOption, null);
                                                                                                                
                                                                                                                // First select a valid option
                                                                                                                optionGroup.setSelected(validOption);
                                                                                                                
                                                                                                                // Now try to select an option with null key
                                                                                                                // Original code will throw NPE when calling selected.equals(null)
                                                                                                                // Mutant will throw AlreadySelectedException when calling null.equals(selected)
                                                                                                                optionGroup.setSelected(nullKeyOption);
                                                                                                            }

    @Test
                                                                                                   public void testSetSelected_DifferentOptionWhenAlreadySelected_ShouldThrowException() {
                                                                                                       // Setup
                                                                                                       OptionGroup optionGroup = new OptionGroup();
                                                                                                       
                                                                                                       // Create mock options and set their key fields via reflection
                                                                                                       Option initialOption = mock(Option.class);
                                                                                                       try {
                                                                                                           Field keyField = Option.class.getDeclaredField("key");
                                                                                                           keyField.setAccessible(true);
                                                                                                           keyField.set(initialOption, "opt1");
                                                                                                       } catch (Exception e) {
                                                                                                           fail("Failed to set key field via reflection");
                                                                                                       }
                                                                                                       
                                                                                                       Option differentOption = mock(Option.class);
                                                                                                       try {
                                                                                                           Field keyField = Option.class.getDeclaredField("key");
                                                                                                           keyField.setAccessible(true);
                                                                                                           keyField.set(differentOption, "opt2");
                                                                                                       } catch (Exception e) {
                                                                                                           fail("Failed to set key field via reflection");
                                                                                                       }
                                                                                                       
                                                                                                       // First select initial option
                                                                                                       try {
                                                                                                           optionGroup.setSelected(initialOption);
                                                                                                       } catch (AlreadySelectedException e) {
                                                                                                           fail("Unexpected AlreadySelectedException when selecting initial option");
                                                                                                       }
                                                                                                       
                                                                                                       // Verify initial selection
                                                                                                       assertEquals("opt1", optionGroup.getSelected());
                                                                                                       
                                                                                                       // Test - should throw exception when selecting different option
                                                                                                       try {
                                                                                                           optionGroup.setSelected(differentOption);
                                                                                                           fail("Expected AlreadySelectedException when selecting different option");
                                                                                                       } catch (AlreadySelectedException e) {
                                                                                                           // Expected behavior
                                                                                                       }
                                                                                                       
                                                                                                       // Verify selection didn't change
                                                                                                       assertEquals("opt1", optionGroup.getSelected());
                                                                                                   }

    @Test
                                                                                          public void testSetSelected_ReselectSameOption_ShouldNotThrowException() throws AlreadySelectedException {
                                                                                              // Setup
                                                                                              OptionGroup optionGroup = new OptionGroup();
                                                                                              Option option = mock(Option.class);
                                                                                              
                                                                                              // Use addOption to properly set up the option in the group
                                                                                              optionGroup.addOption(option);
                                                                                              
                                                                                              // First selection (should work)
                                                                                              optionGroup.setSelected(option);
                                                                                              
                                                                                              try {
                                                                                                  // Try to select same option again
                                                                                                  optionGroup.setSelected(option);
                                                                                                  
                                                                                                  // If we get here, test passes (original behavior)
                                                                                                  // Verify the selected value is still correct
                                                                                                  // Since we can't access option.getKey(), we just verify the option is selected
                                                                                                  assertNotNull(optionGroup.getSelected());
                                                                                              } catch (AlreadySelectedException e) {
                                                                                                  // If exception is thrown, mutant is detected
                                                                                                  fail("Mutant detected: Reselecting same option threw exception when it shouldn't");
                                                                                              }
                                                                                          }

    @Test
                                                                                     public void testSetSelected_ShouldAllowReselectingSameOption() throws AlreadySelectedException {
                                                                                         // Setup
                                                                                         OptionGroup optionGroup = new OptionGroup();
                                                                                         Option option = mock(Option.class);
                                                                                         
                                                                                         // Mock the option's behavior indirectly through OptionGroup's public API
                                                                                         optionGroup.addOption(option);
                                                                                         
                                                                                         // First selection (should work)
                                                                                         optionGroup.setSelected(option);
                                                                                         
                                                                                         // Try to select same option again - should NOT throw exception
                                                                                         optionGroup.setSelected(option);
                                                                                         
                                                                                         // Verify the selection is still the same
                                                                                         // We can verify by checking the selected option is present in the group
                                                                                         assertNotNull(optionGroup.getSelected());
                                                                                     }

    @Test
                                                                                public void testSetSelectedShouldStoreOptionKey() throws Exception {
                                                                                    // Setup
                                                                                    OptionGroup optionGroup = new OptionGroup();
                                                                                    Option option = mock(Option.class);
                                                                                    
                                                                                    // Mock the toString() method which is public and can be used to identify the option
                                                                                    when(option.toString()).thenReturn("testKey");
                                                                                    
                                                                                    // Exercise - first selection (selected == null case)
                                                                                    optionGroup.setSelected(option);
                                                                                    
                                                                                    // Verify
                                                                                    // Since we can't mock getKey(), we'll verify the behavior through getSelected()
                                                                                    // which should return the option's string representation
                                                                                    assertEquals("testKey", optionGroup.getSelected());
                                                                                    
                                                                                    // Additional verification that the selection was properly stored
                                                                                    optionGroup.setSelected(option); // Should not throw exception for reselection
                                                                                }

    @Test
                                                                       public void testSetSelectedNewOptionShouldSetSelectedField() throws AlreadySelectedException {
                                                                           // Setup
                                                                           OptionGroup optionGroup = new OptionGroup();
                                                                           Option option = mock(Option.class);
                                                                           
                                                                           // Use reflection to access the private getKey() method
                                                                           try {
                                                                               Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                               getKeyMethod.setAccessible(true);
                                                                               when(getKeyMethod.invoke(option)).thenReturn("testKey");
                                                                           } catch (Exception e) {
                                                                               fail("Failed to set up mock for getKey()");
                                                                           }
                                                                           
                                                                           // Initially selected should be null
                                                                           assertNull(optionGroup.getSelected());
                                                                           
                                                                           // Action - set a new option
                                                                           optionGroup.setSelected(option);
                                                                           
                                                                           // Verification
                                                                           assertEquals("testKey", optionGroup.getSelected());
                                                                           
                                                                           // Verify the getKey() was called through reflection
                                                                           try {
                                                                               Method getKeyMethod = Option.class.getDeclaredMethod("getKey");
                                                                               getKeyMethod.setAccessible(true);
                                                                               getKeyMethod.invoke(option); // This will throw if not called
                                                                           } catch (Exception e) {
                                                                               fail("getKey() was not called as expected");
                                                                           }
                                                                       }

    @Test
                                                                  public void testSetSelectedUpdatesSelectionWhenNoPreviousSelection() throws AlreadySelectedException {
                                                                      // Setup
                                                                      OptionGroup optionGroup = new OptionGroup();
                                                                      Option option = mock(Option.class);
                                                                      
                                                                      // Use reflection to set up the key value since getKey() is not public
                                                                      try {
                                                                          Field keyField = Option.class.getDeclaredField("key");
                                                                          keyField.setAccessible(true);
                                                                          keyField.set(option, "testKey");
                                                                      } catch (Exception e) {
                                                                          fail("Failed to set key field via reflection");
                                                                      }
                                                                      
                                                                      // Action
                                                                      optionGroup.setSelected(option);
                                                                      
                                                                      // Verification
                                                                      assertEquals("testKey", optionGroup.getSelected());
                                                                      
                                                                      // Additional verification that the selection was actually set
                                                                      // This would fail with the mutant since it comments out the selection line
                                                                      assertNotNull(optionGroup.getSelected());
                                                                  }

    @Test
                                                             public void testSetSelectedWithEqualButDifferentStringObjects() throws AlreadySelectedException, NoSuchFieldException, IllegalAccessException {
                                                                 // Setup
                                                                 OptionGroup optionGroup = new OptionGroup();
                                                                 Option option1 = mock(Option.class);
                                                                 Option option2 = mock(Option.class);
                                                                 
                                                                 // Create two different String objects with same value
                                                                 String key1 = new String("testKey");
                                                                 String key2 = new String("testKey");
                                                                 
                                                                 // Use reflection to set the private key field in Option
                                                                 Field keyField = Option.class.getDeclaredField("key");
                                                                 keyField.setAccessible(true);
                                                                 keyField.set(option1, key1);
                                                                 keyField.set(option2, key2);
                                                                 
                                                                 // First selection should work
                                                                 optionGroup.setSelected(option1);
                                                                 
                                                                 // Second selection with equal but different String object
                                                                 // Original code should allow this (same value)
                                                                 // Mutated code will throw exception (different reference)
                                                                 optionGroup.setSelected(option2);
                                                                 
                                                                 // Verify the selection was updated
                                                                 assertEquals(key2, optionGroup.getSelected());
                                                             }

    @Test(expected = AlreadySelectedException.class)
                                        public void testSetSelectedDifferentOptionShouldThrowAlreadySelectedException() throws AlreadySelectedException {
                                            // Setup
                                            OptionGroup optionGroup = new OptionGroup();
                                            Option option1 = new Option("a", "key1");
                                            Option option2 = new Option("b", "key2");
                                            
                                            // First select option1
                                            optionGroup.setSelected(option1);
                                            
                                            // Try to select option2 - should throw AlreadySelectedException
                                            // If mutant exists, this would throw NullPointerException instead
                                            optionGroup.setSelected(option2);
                                        }

    @Test
                               public void testSetSelectedShouldAllowReselectingSameOption() throws AlreadySelectedException {
                                   // Setup
                                   OptionGroup optionGroup = new OptionGroup();
                                   Option option = mock(Option.class);
                                   
                                   // Use reflection to set the key field since getKey() is not accessible
                                   try {
                                       Field keyField = Option.class.getDeclaredField("key");
                                       keyField.setAccessible(true);
                                       keyField.set(option, "testKey");
                                   } catch (Exception e) {
                                       fail("Failed to set key field via reflection");
                                   }
                                   
                                   // First selection
                                   optionGroup.setSelected(option);
                                   
                                   // Reselect the same option - should work in original, fail in mutant
                                   optionGroup.setSelected(option);
                                   
                                   // Verify
                                   assertEquals("testKey", optionGroup.getSelected());
                                   // If mutant exists, it would throw AlreadySelectedException
                                   // and getSelected() might return null or previous value
                               }

    @Test
                               public void testSetSelectedWithMutantThrowsExceptionOnReselect() {
                                   // Setup
                                   OptionGroup optionGroup = new OptionGroup();
                                   Option option1 = mock(Option.class);
                                   Option option2 = mock(Option.class);
                                   
                                   // Mock equals() to simulate same key behavior
                                   when(option1.equals(any())).thenAnswer(invocation -> {
                                       Object arg = invocation.getArgument(0);
                                       return arg instanceof Option && arg == option1;
                                   });
                                   when(option2.equals(any())).thenAnswer(invocation -> {
                                       Object arg = invocation.getArgument(0);
                                       return arg instanceof Option && arg == option2;
                                   });
                                   
                                   // First selection
                                   try {
                                       optionGroup.setSelected(option1);
                                   } catch (AlreadySelectedException e) {
                                       // Shouldn't happen on first selection
                                       fail("Unexpected AlreadySelectedException on first selection");
                                   }
                                   
                                   try {
                                       // This should work in original (same key) but fail in mutant
                                       optionGroup.setSelected(option2);
                                       // If we reach here, mutant wasn't caught
                                       fail("Mutant not detected - should throw AlreadySelectedException");
                                   } catch (AlreadySelectedException e) {
                                       // Expected behavior
                                   }
                               }

    @Test
                      public void testSetSelectedWithEqualOptionShouldSetSelected() throws Exception {
                          // Create mock objects and test data
                          Option mockOption = mock(Option.class);
                          OptionGroup optionGroup = new OptionGroup();
                          String optionKey = "testKey";
                          
                          // Set up mock behavior using public methods
                          // Assuming Option has a public getOpt() or similar method
                          when(mockOption.getOpt()).thenReturn(optionKey);
                          
                          // First set a selected value
                          optionGroup.setSelected(mockOption);
                          
                          // Now test reselecting the same option
                          // This will exercise the equals() condition in the if statement
                          optionGroup.setSelected(mockOption);
                          
                          // Verify the selected value is still set
                          assertEquals(optionKey, optionGroup.getSelected());
                          
                          // Verify getOpt() was called exactly twice (once for each setSelected)
                          verify(mockOption, times(2)).getOpt();
                      }

    @Test
                 public void testSetSelectedDetectsMutant() throws AlreadySelectedException {
                     // Setup
                     OptionGroup optionGroup = new OptionGroup();
                     Option option1 = new Option("opt1", "option1");
                     Option option2 = new Option("opt2", "option2");
                     
                     // First selection should work
                     optionGroup.setSelected(option1);
                     assertEquals("opt1", optionGroup.getSelected());
                     
                     // Test 1: Try to select different option - should throw exception
                     try {
                         optionGroup.setSelected(option2);
                         fail("Expected AlreadySelectedException when selecting different option");
                     } catch (AlreadySelectedException e) {
                         // Expected behavior
                     }
                     
                     // Test 2: Try to select same option again - should work
                     optionGroup.setSelected(option1); // Should not throw
                     assertEquals("opt1", optionGroup.getSelected());
                     
                     // Test 3: Test with null option
                     optionGroup.setSelected(null);
                     assertNull(optionGroup.getSelected());
                 }

    @Test(expected = AlreadySelectedException.class)
    public void testSetSelectedWithDifferentOptionShouldThrowException() throws AlreadySelectedException {
        // Setup
        OptionGroup optionGroup = new OptionGroup();
        Option option1 = mock(Option.class);
        when(option1.toString()).thenReturn("opt1");
        
        Option option2 = mock(Option.class);
        when(option2.toString()).thenReturn("opt2");
        
        // First selection should work
        optionGroup.setSelected(option1);
        
        // Second selection with different option should throw exception
        optionGroup.setSelected(option2);
        
        // If we reach here, the test fails (mutant survived)
        // Because mutated code would allow the second selection
    }


}
