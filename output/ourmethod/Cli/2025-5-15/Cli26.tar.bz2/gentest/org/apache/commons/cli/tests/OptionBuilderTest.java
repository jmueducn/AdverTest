package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
 
public class OptionBuilderTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                     public void testCreate_WithSimpleCharOption() {
                         Option option = OptionBuilder.create('t');
                         assertNotNull(option);
                         assertEquals("t", option.getOpt());
                         assertNull(option.getLongOpt());
                         assertFalse(option.isRequired());
                         assertEquals(0, option.getArgs());
                         assertNull(option.getDescription());
                     }

    @Test
                     public void testCreate_WithAllPropertiesSet() {
                         OptionBuilder.withLongOpt("test")
                                     .withDescription("Test option")
                                     .isRequired()
                                     .hasArg()
                                     .withArgName("arg")
                                     .withValueSeparator('=')
                                     .withType(Integer.class);
                         
                         Option option = OptionBuilder.create('t');
                         assertNotNull(option);
                         assertEquals("t", option.getOpt());
                         assertEquals("test", option.getLongOpt());
                         assertEquals("Test option", option.getDescription());
                         assertTrue(option.isRequired());
                         assertEquals(1, option.getArgs());
                         assertEquals("arg", option.getArgName());
                         assertEquals('=', option.getValueSeparator());
                         assertEquals(Integer.class, option.getType());
                     }

    @Test
                     public void testCreate_WithOptionalArgs() {
                         OptionBuilder.hasOptionalArg();
                         Option option = OptionBuilder.create('t');
                         assertTrue(option.hasOptionalArg());
                         assertEquals(1, option.getArgs());
                     }

    @Test
                     public void testCreate_WithMultipleArgs() {
                         OptionBuilder.hasArgs(3);
                         Option option = OptionBuilder.create('t');
                         assertEquals(3, option.getArgs());
                     }

    @Test
                     public void testCreate_WithOptionalMultipleArgs() {
                         OptionBuilder.hasOptionalArgs(2);
                         Option option = OptionBuilder.create('t');
                         assertTrue(option.hasOptionalArg());
                         assertEquals(2, option.getArgs());
                     }

    @Test
                     public void testCreate_WithValueSeparatorNoArg() {
                         OptionBuilder.withValueSeparator();
                         Option option = OptionBuilder.create('t');
                         assertEquals('=', option.getValueSeparator());
                         assertEquals(1, option.getArgs());
                     }

    @Test
                     public void testCreate_WithValueSeparatorAndArg() {
                         OptionBuilder.withValueSeparator(':').hasArg();
                         Option option = OptionBuilder.create('t');
                         assertEquals(':', option.getValueSeparator());
                         assertEquals(1, option.getArgs());
                     }

    @Test
                     public void testCreate_WithType() {
                         OptionBuilder.withType(Double.class);
                         Option option = OptionBuilder.create('t');
                         assertEquals(Double.class, option.getType());
                     }

    @Test
                     public void testCreate_WithNonLetterChar() {
                         Option option = OptionBuilder.create('1');
                         assertEquals("1", option.getOpt());
                     }

    @Test
                     public void testCreate_WithSpecialChar() {
                         Option option = OptionBuilder.create('@');
                         assertEquals("@", option.getOpt());
                     }

    @Test
                     public void testCreate_WithAllPropertiesSet1() {
                         // Setup test data
                         char opt = 't';
                         String longopt = "test";
                         String description = "Test option";
                         boolean required = true;
                         boolean optionalArg = true;
                         int numberOfArgs = 2;
                         Object type = String.class;
                         char valuesep = '=';
                         String argName = "value";
                 
                         // Set OptionBuilder properties
                         OptionBuilder.withLongOpt(longopt);
                         OptionBuilder.withDescription(description);
                         OptionBuilder.isRequired(required);
                         OptionBuilder.hasOptionalArg();
                         OptionBuilder.hasArgs(numberOfArgs);
                         OptionBuilder.withType(type);
                         OptionBuilder.withValueSeparator(valuesep);
                         OptionBuilder.withArgName(argName);
                 
                         // Create the option
                         Option option = OptionBuilder.create(opt);
                 
                         // Verify all properties were set correctly
                         assertEquals(opt, option.getOpt());
                         assertEquals(longopt, option.getLongOpt());
                         assertEquals(description, option.getDescription());
                         assertTrue(option.isRequired());
                         assertTrue(option.hasOptionalArg());
                         assertEquals(numberOfArgs, option.getArgs());
                         assertEquals(type, option.getType());
                         assertEquals(valuesep, option.getValueSeparator());
                         assertEquals(argName, option.getArgName());
                     }

    @Test
                     public void testCreate_WithMinimumProperties() {
                         // Setup test data
                         char opt = 'f';
                         String description = "File option";
                 
                         // Set only required properties
                         OptionBuilder.withDescription(description);
                 
                         // Create the option
                         Option option = OptionBuilder.create(opt);
                 
                         // Verify basic properties
                         assertEquals(opt, option.getOpt());
                         assertEquals(description, option.getDescription());
                         
                         // Verify default values
                         assertNull(option.getLongOpt());
                         assertFalse(option.isRequired());
                         assertFalse(option.hasOptionalArg());
                         assertEquals(Option.UNINITIALIZED, option.getArgs());
                         assertNull(option.getType());
                         assertEquals(0, option.getValueSeparator());
                         assertNull(option.getArgName());
                     }

    @Test
                     public void testCreate_WithLongOptOnly() {
                         String longopt = "verbose";
                         OptionBuilder.withLongOpt(longopt);
                 
                         Option option = OptionBuilder.create('v');
                 
                         assertEquals('v', option.getOpt());
                         assertEquals(longopt, option.getLongOpt());
                         assertFalse(option.isRequired());
                     }

    @Test
                     public void testCreate_WithRequiredFlag() {
                         OptionBuilder.isRequired();
                 
                         Option option = OptionBuilder.create('r');
                 
                         assertTrue(option.isRequired());
                     }

    @Test
                     public void testCreate_WithOptionalArgs1() {
                         int numArgs = 3;
                         OptionBuilder.hasOptionalArgs(numArgs);
                 
                         Option option = OptionBuilder.create('o');
                 
                         assertTrue(option.hasOptionalArg());
                         assertEquals(numArgs, option.getArgs());
                     }

    @Test
                     public void testCreate_WithValueSeparator() {
                         char sep = ',';
                         OptionBuilder.withValueSeparator(sep);
                 
                         Option option = OptionBuilder.create('s');
                 
                         assertEquals(sep, option.getValueSeparator());
                     }

    @Test
                     public void testCreate_WithArgName() {
                         String argName = "filename";
                         OptionBuilder.withArgName(argName);
                 
                         Option option = OptionBuilder.create('f');
                 
                         assertEquals(argName, option.getArgName());
                     }

    @Test
                     public void testCreate_WithType1() {
                         Object type = Integer.class;
                         OptionBuilder.withType(type);
                 
                         Option option = OptionBuilder.create('n');
                 
                         assertEquals(type, option.getType());
                     }

    @Test
                     public void testCreate_WithMultipleArgs1() {
                         int numArgs = 5;
                         OptionBuilder.hasArgs(numArgs);
                 
                         Option option = OptionBuilder.create('m');
                 
                         assertEquals(numArgs, option.getArgs());
                         assertFalse(option.hasOptionalArg());
                     }

    @Test
                     public void testCreate_WithSingleArg() {
                         OptionBuilder.hasArg();
                 
                         Option option = OptionBuilder.create('a');
                 
                         assertEquals(1, option.getArgs());
                     }

    @Test
                     public void testCreate_WithUnlimitedArgs() {
                         OptionBuilder.hasArgs();
                 
                         Option option = OptionBuilder.create('u');
                 
                         assertEquals(Option.UNLIMITED_VALUES, option.getArgs());
                     }

    @Test
             public void testCreate_WithEmptyChar() {
                 org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                 exception.expect(IllegalArgumentException.class);
                 OptionBuilder.create('\0');
             }

    @Test
             public void testCreate_AfterReset() throws Exception {
                 OptionBuilder.withLongOpt("test").isRequired();
                 // Use reflection to call private reset method
                 Method resetMethod = OptionBuilder.class.getDeclaredMethod("reset");
                 resetMethod.setAccessible(true);
                 resetMethod.invoke(null);
                 
                 Option option = OptionBuilder.create('t');
                 assertNull(option.getLongOpt());
                 assertFalse(option.isRequired());
             }

    @Test
             public void testCreate_WhenLongOptIsNotNull_ShouldCallCreateWithNull() throws Exception {
                 // Arrange
                 Option mockOption = mock(Option.class);
                 OptionBuilder optionBuilderSpy = spy(OptionBuilder.class);
                 
                 // Use reflection to set the private longopt field
                 Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
                 longoptField.setAccessible(true);
                 longoptField.set(null, "testLongOpt");
                 
                 // Mock the internal create method call
                 doReturn(mockOption).when(optionBuilderSpy).create((String)null);
                 
                 // Act
                 Option result = optionBuilderSpy.create();
                 
                 // Assert
                 assertNotNull(result);
                 assertEquals(mockOption, result);
                 
                 // Reset the field for other tests
                 longoptField.set(null, null);
                 longoptField.setAccessible(false);
             }

    @Test
             public void testCreate_WhenLongOptIsEmptyString_ShouldCallCreateWithNull() {
                 // Arrange
                 OptionBuilder.withLongOpt("");
                 Option mockOption = mock(Option.class);
                 OptionBuilder optionBuilderSpy = spy(OptionBuilder.class);
                 
                 // Mock the internal create method call
                 doReturn(mockOption).when(optionBuilderSpy).create((String)null);
                 
                 // Act
                 Option result = optionBuilderSpy.create();
                 
                 // Assert
                 assertNotNull(result);
                 assertEquals(mockOption, result);
             }

    @Test
             public void testCreate_ShouldResetOptionBuilderAfterCreation() {
                 // Arrange
                 OptionBuilder.withLongOpt("testLongOpt")
                             .withDescription("testDescription")
                             .isRequired(true);
                 
                 Option mockOption = mock(Option.class);
                 OptionBuilder optionBuilderSpy = spy(OptionBuilder.class);
                 
                 // Mock the internal create method call
                 doReturn(mockOption).when(optionBuilderSpy).create((String)null);
                 
                 // Act
                 OptionBuilder.create();
                 
                 // Assert that builder was reset by verifying subsequent create() throws
                 try {
                     OptionBuilder.create();
                     fail("Expected IllegalArgumentException");
                 } catch (IllegalArgumentException e) {
                     assertEquals("must specify longopt", e.getMessage());
                 }
             }

    @Test
             public void testCreate_WithNullOpt() {
                 ExpectedException exception = ExpectedException.none();
                 exception.expect(IllegalArgumentException.class);
                 exception.expectMessage("opt is null");
                 
                 OptionBuilder.create((String) null);
             }

    @Test
             public void testCreate_WithEmptyOpt() {
                 org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                 exception.expect(IllegalArgumentException.class);
                 exception.expectMessage("opt is empty");
                 
                 OptionBuilder.create("");
             }

    @Test
             public void testCreate_VerifyResetAfterCreation() throws Exception {
                 // Set some properties
                 OptionBuilder.withLongOpt("test");
                 OptionBuilder.isRequired(true);
                 OptionBuilder.withDescription("Test option");
             
                 // Create an option
                 OptionBuilder.create('t');
             
                 // Use reflection to verify properties were reset
                 Class<?> optionBuilderClass = OptionBuilder.class;
                 
                 Field longoptField = optionBuilderClass.getDeclaredField("longopt");
                 longoptField.setAccessible(true);
                 assertNull(longoptField.get(null));
                 
                 Field descriptionField = optionBuilderClass.getDeclaredField("description");
                 descriptionField.setAccessible(true);
                 assertNull(descriptionField.get(null));
                 
                 Field requiredField = optionBuilderClass.getDeclaredField("required");
                 requiredField.setAccessible(true);
                 assertFalse(requiredField.getBoolean(null));
                 
                 Field numberOfArgsField = optionBuilderClass.getDeclaredField("numberOfArgs");
                 numberOfArgsField.setAccessible(true);
                 assertEquals(Option.UNINITIALIZED, numberOfArgsField.getInt(null));
                 
                 Field typeField = optionBuilderClass.getDeclaredField("type");
                 typeField.setAccessible(true);
                 assertNull(typeField.get(null));
                 
                 Field optionalArgField = optionBuilderClass.getDeclaredField("optionalArg");
                 optionalArgField.setAccessible(true);
                 assertFalse(optionalArgField.getBoolean(null));
                 
                 Field valuesepField = optionBuilderClass.getDeclaredField("valuesep");
                 valuesepField.setAccessible(true);
                 assertEquals(0, valuesepField.getChar(null));
                 
                 Field argNameField = optionBuilderClass.getDeclaredField("argName");
                 argNameField.setAccessible(true);
                 assertNull(argNameField.get(null));
             }

    @Test
         public void testCreate_WhenLongOptIsNull_ShouldThrowIllegalArgumentException() throws Exception {
             // Arrange
             Field longoptField = OptionBuilder.class.getDeclaredField("longopt");
             longoptField.setAccessible(true);
             longoptField.set(null, null);
             
             // Setup expected exception
             ExpectedException expectedException = ExpectedException.none();
             expectedException.expect(IllegalArgumentException.class);
             expectedException.expectMessage("must specify longopt");
             
             // Act
             OptionBuilder.create();
         }

    @Test(expected = NullPointerException.class)
         public void testCreateWithNullInputShouldThrowException() {
             // This test will fail if the mutant is present (which returns null instead of throwing)
             OptionBuilder.create((String) null);
         }

    @Test
         public void testCreateWithValidInput() {
             // Test normal functionality remains unchanged
             Option result = OptionBuilder.create("validOption");
             assertNotNull(result);
             // Additional assertions about the created Option could be added here
         }

    @Test
         public void testCreateWithEmptyString() {
             // Test boundary case
             Option result = OptionBuilder.create("");
             assertNotNull(result);
             // Additional assertions about the created Option could be added here
         }

    @Test
         public void testCreateReturnsOptionEvenWhenNull() throws Exception {
             // Setup - mock the static create(String) method
             OptionBuilder builder = spy(OptionBuilder.class);
             
             // Mock the internal create(null) call to return null
             doReturn(null).when(builder).create((String)null);
             
             // Set a non-null longopt to avoid the exception path
             OptionBuilder.withLongOpt("test");
             
             // Call the method and verify behavior
             Option result = builder.create();
             
             // The original code would return null (from create(null))
             // The mutant would return null only after null check
             // This test would pass for both, so we need to verify the actual behavior
             
             // More precise verification - check if the method returns exactly what create(null) returns
             // Since we mocked create(null) to return null, we expect null
             assertNull(result);
             
             // Verify the create(null) was called exactly once
             verify(builder, times(1)).create((String)null);
         }

    @Test
     public void testCreateReturnsOptionDirectlyWithoutNullCheck() {
         // Setup - create a real option to return
         Option testOption = new Option("test", "description");
         
         // Mock the OptionBuilder to return our test option
         OptionBuilder builder = spy(OptionBuilder.class);
         doReturn(testOption).when(builder).create((String)null);
         
         // Set a non-null longopt
         OptionBuilder.withLongOpt("test");
         
         // Call the method
         Option result = builder.create();
         
         // Original code would return testOption directly
         // Mutant would return testOption (since it's not null)
         // So this still wouldn't catch the mutant
         
         // The key is that the mutant adds behavior that could differ if create(null) returns null
         // Since we can't make create(null) return null in one case and non-null in another,
         // we need to verify the behavior through other means
         
         // Alternative approach - verify the mutant would behave differently if option was null
         // Since we can't test that directly, we need to test the behavior through state changes
         
         // The most reliable way is to verify that the method returns exactly what create(null) returns
         assertSame(testOption, result);
         
         // The mutant's behavior would be identical in this case, so we need a different approach
         
         // Final solution - we need to test that the method doesn't perform any null check
         // This is tricky to test directly, but we can verify that it returns null when create(null) returns null
         // (which the original would do as well)
         
         // Therefore, this mutant might not actually change observable behavior
         // and thus can't be detected through testing
     }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateThrowsExceptionWhenLongOptNull() {
        OptionBuilder.create(); // should throw exception when longopt is null
    }

    @Test
    public void testCreateOptionReturnBehavior() {
        // Test successful creation (non-null return)
        OptionBuilder.withLongOpt("longopt");
        OptionBuilder.withDescription("description");
        OptionBuilder.withArgName("arg");
        Option option = OptionBuilder.create("opt");
        assertNotNull("Option should not be null when creation succeeds", option);
        
        // Test failed creation path (null return)
        // Simulate failure by not setting required fields before creation
        // No need to call reset() as create() does it automatically
        try {
            // Create without setting required fields to force null return
            option = OptionBuilder.create(null);
            assertNull("Option should be null when creation fails", option);
        } catch (Exception e) {
            fail("Creation with null opt should not throw exception");
        }
        
        // Additional test with empty string
        try {
            option = OptionBuilder.create("");
            assertNull("Option should be null when created with empty string", option);
        } catch (Exception e) {
            fail("Creation with empty string should not throw exception");
        }
    }


}
