package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                            public void testAppendOption_RequiredShortOptWithArg() throws Exception {
                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                StringBuffer buff = new StringBuffer();
                                                                                Option option = mock(Option.class);
                                                                                
                                                                                when(option.getOpt()).thenReturn("f");
                                                                                when(option.getLongOpt()).thenReturn(null);
                                                                                when(option.hasArg()).thenReturn(true);
                                                                                when(option.getArgName()).thenReturn("file");
                                                                                when(option.isRequired()).thenReturn(true);
                                                                                
                                                                                // Use reflection to access private method
                                                                                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                                                                                appendOptionMethod.setAccessible(true);
                                                                                appendOptionMethod.invoke(formatter, buff, option, true);
                                                                                
                                                                                assertEquals("-f <file>", buff.toString());
                                                                            }

 @Test
                                                                            public void testAppendOption_OptionalShortOptWithArg() throws Exception {
                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                StringBuffer buff = new StringBuffer();
                                                                                Option option = mock(Option.class);
                                                                                
                                                                                when(option.getOpt()).thenReturn("v");
                                                                                when(option.getLongOpt()).thenReturn(null);
                                                                                when(option.hasArg()).thenReturn(true);
                                                                                when(option.getArgName()).thenReturn("value");
                                                                                when(option.isRequired()).thenReturn(false);
                                                                                
                                                                                // Use reflection to access private method
                                                                                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                                                                                appendOptionMethod.setAccessible(true);
                                                                                appendOptionMethod.invoke(formatter, buff, option, false);
                                                                                
                                                                                assertEquals("[-v <value>]", buff.toString());
                                                                            }

 @Test
                                                                            public void testAppendOption_RequiredLongOptWithArg() throws Exception {
                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                StringBuffer buff = new StringBuffer();
                                                                                Option option = mock(Option.class);
                                                                                
                                                                                when(option.getOpt()).thenReturn(null);
                                                                                when(option.getLongOpt()).thenReturn("file");
                                                                                when(option.hasArg()).thenReturn(true);
                                                                                when(option.getArgName()).thenReturn("path");
                                                                                when(option.isRequired()).thenReturn(true);
                                                                                
                                                                                // Use reflection to access private method
                                                                                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                                                                                appendOptionMethod.setAccessible(true);
                                                                                appendOptionMethod.invoke(formatter, buff, option, true);
                                                                                
                                                                                assertEquals("--file=<path>", buff.toString());
                                                                            }

 @Test
                                                                            public void testAppendOption_OptionalLongOptWithArg() throws Exception {
                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                StringBuffer buff = new StringBuffer();
                                                                                Option option = mock(Option.class);
                                                                                
                                                                                when(option.getOpt()).thenReturn(null);
                                                                                when(option.getLongOpt()).thenReturn("verbose");
                                                                                when(option.hasArg()).thenReturn(true);
                                                                                when(option.getArgName()).thenReturn("level");
                                                                                when(option.isRequired()).thenReturn(false);
                                                                                
                                                                                // Use reflection to access private method
                                                                                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                                                                                appendOptionMethod.setAccessible(true);
                                                                                appendOptionMethod.invoke(formatter, buff, option, false);
                                                                                
                                                                                assertEquals("[--verbose=<level>]", buff.toString());
                                                                            }

 @Test
                                                                            public void testAppendOption_ShortOptWithoutArg() throws Exception {
                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                StringBuffer buff = new StringBuffer();
                                                                                Option option = mock(Option.class);
                                                                                
                                                                                when(option.getOpt()).thenReturn("h");
                                                                                when(option.getLongOpt()).thenReturn(null);
                                                                                when(option.hasArg()).thenReturn(false);
                                                                                when(option.isRequired()).thenReturn(true);
                                                                                
                                                                                // Use reflection to access private method
                                                                                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                                                                                appendOptionMethod.setAccessible(true);
                                                                                appendOptionMethod.invoke(formatter, buff, option, true);
                                                                                
                                                                                assertEquals("-h", buff.toString());
                                                                            }

 @Test
                                                                            public void testAppendOption_LongOptWithoutArg() throws Exception {
                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                StringBuffer buff = new StringBuffer();
                                                                                Option option = mock(Option.class);
                                                                                
                                                                                when(option.getOpt()).thenReturn(null);
                                                                                when(option.getLongOpt()).thenReturn("help");
                                                                                when(option.hasArg()).thenReturn(false);
                                                                                when(option.isRequired()).thenReturn(true);
                                                                                
                                                                                // Use reflection to access private method
                                                                                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                                                                                appendOptionMethod.setAccessible(true);
                                                                                appendOptionMethod.invoke(formatter, buff, option, true);
                                                                                
                                                                                assertEquals("--help", buff.toString());
                                                                            }

 @Test
                                                                            public void testAppendOption_ShortOptWithEmptyArgName() throws Exception {
                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                StringBuffer buff = new StringBuffer();
                                                                                Option option = mock(Option.class);
                                                                                
                                                                                when(option.getOpt()).thenReturn("d");
                                                                                when(option.getLongOpt()).thenReturn(null);
                                                                                when(option.hasArg()).thenReturn(true);
                                                                                when(option.getArgName()).thenReturn("");
                                                                                when(option.isRequired()).thenReturn(true);
                                                                                
                                                                                // Use reflection to access private method
                                                                                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                                                                                appendOptionMethod.setAccessible(true);
                                                                                appendOptionMethod.invoke(formatter, buff, option, true);
                                                                                
                                                                                assertEquals("-d", buff.toString());
                                                                            }

 @Test
                                                                            public void testAppendOption_ShortOptWithNullArgName() throws Exception {
                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                formatter.setArgName("defaultArg");
                                                                                StringBuffer buff = new StringBuffer();
                                                                                Option option = mock(Option.class);
                                                                                
                                                                                when(option.getOpt()).thenReturn("c");
                                                                                when(option.getLongOpt()).thenReturn(null);
                                                                                when(option.hasArg()).thenReturn(true);
                                                                                when(option.getArgName()).thenReturn(null);
                                                                                when(option.isRequired()).thenReturn(true);
                                                                                
                                                                                // Use reflection to access private appendOption method
                                                                                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                                                                                appendOptionMethod.setAccessible(true);
                                                                                appendOptionMethod.invoke(formatter, buff, option, true);
                                                                                
                                                                                assertEquals("-c <defaultArg>", buff.toString());
                                                                            }

 @Test
                                                                            public void testAppendOption_CustomLongOptSeparator() throws Exception {
                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                formatter.setLongOptSeparator(" ");
                                                                                StringBuffer buff = new StringBuffer();
                                                                                Option option = mock(Option.class);
                                                                                
                                                                                when(option.getOpt()).thenReturn(null);
                                                                                when(option.getLongOpt()).thenReturn("output");
                                                                                when(option.hasArg()).thenReturn(true);
                                                                                when(option.getArgName()).thenReturn("file");
                                                                                when(option.isRequired()).thenReturn(true);
                                                                                
                                                                                // Use reflection to access private method
                                                                                Method appendOptionMethod = HelpFormatter.class.getDeclaredMethod(
                                                                                    "appendOption", StringBuffer.class, Option.class, boolean.class);
                                                                                appendOptionMethod.setAccessible(true);
                                                                                appendOptionMethod.invoke(formatter, buff, option, true);
                                                                                
                                                                                assertEquals("--output <file>", buff.toString());
                                                                            }

 @Test(expected = NullPointerException.class)
                                                                            public void testAppendOption_NullBufferThrowsException() throws Exception {
                                                                                HelpFormatter formatter = new HelpFormatter();
                                                                                Option option = mock(Option.class);
                                                                                when(option.getOpt()).thenReturn("t");
                                                                                when(option.getLongOpt()).thenReturn("test");
                                                                                when(option.hasArg()).thenReturn(false);
                                                                                
                                                                                Method method = HelpFormatter.class.getDeclaredMethod("appendOption", StringBuffer.class, Option.class, boolean.class);
                                                                                method.setAccessible(true);
                                                                                method.invoke(formatter, null, option, true);
                                                                            }

}
