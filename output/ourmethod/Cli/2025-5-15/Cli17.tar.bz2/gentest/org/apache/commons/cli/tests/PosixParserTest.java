package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
 
public class PosixParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                 public void testBurstToken_WithValidOption() {
                                                                                                                                                                                                                     // Setup mock behavior
                                                                                                                                                                                                                     Options options = mock(Options.class);
                                                                                                                                                                                                                     Option mockOption = mock(Option.class);
                                                                                                                                                                                                                     when(mockOption.hasArg()).thenReturn(false);
                                                                                                                                                                                                                     when(options.hasOption("a")).thenReturn(true);
                                                                                                                                                                                                                     when(options.getOption("a")).thenReturn(mockOption);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Initialize parser and tokens
                                                                                                                                                                                                                     PosixParser parser = new PosixParser();
                                                                                                                                                                                                                     List<String> tokens = new ArrayList<>();
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to set private fields for testing
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                                                                                         tokensField.setAccessible(true);
                                                                                                                                                                                                                         tokensField.set(parser, tokens);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                                                                                         optionsField.setAccessible(true);
                                                                                                                                                                                                                         optionsField.set(parser, options);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Use reflection to access protected method
                                                                                                                                                                                                                         Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                                         burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                                         burstTokenMethod.invoke(parser, "-abc", false);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to set up test context: " + e.getMessage());
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                     assertEquals(1, tokens.size());
                                                                                                                                                                                                                     assertEquals("-a", tokens.get(0));
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testBurstToken_WithOptionAndArgument() {
                                                                                                                                                                                                                     // Setup mocks
                                                                                                                                                                                                                     Options options = mock(Options.class);
                                                                                                                                                                                                                     Option mockOption = mock(Option.class);
                                                                                                                                                                                                                     when(mockOption.hasArg()).thenReturn(true);
                                                                                                                                                                                                                     when(options.hasOption("a")).thenReturn(true);
                                                                                                                                                                                                                     when(options.getOption("a")).thenReturn(mockOption);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Initialize parser and tokens
                                                                                                                                                                                                                     PosixParser parser = new PosixParser();
                                                                                                                                                                                                                     List<String> tokens = new ArrayList<>();
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to set private fields
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                                                                                         optionsField.setAccessible(true);
                                                                                                                                                                                                                         optionsField.set(parser, options);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                                                                                         tokensField.setAccessible(true);
                                                                                                                                                                                                                         tokensField.set(parser, tokens);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Use reflection to access protected burstToken method
                                                                                                                                                                                                                         Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                                         burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                                         burstTokenMethod.invoke(parser, "-abcde", false);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                     assertEquals(2, tokens.size());
                                                                                                                                                                                                                     assertEquals("-a", tokens.get(0));
                                                                                                                                                                                                                     assertEquals("bcde", tokens.get(1));
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testBurstToken_WithStopAtNonOption() {
                                                                                                                                                                                                                     // Setup required objects
                                                                                                                                                                                                                     Options options = mock(Options.class);
                                                                                                                                                                                                                     Option mockOption = mock(Option.class);
                                                                                                                                                                                                                     List<String> tokens = new ArrayList<>();
                                                                                                                                                                                                                     PosixParser parser = new PosixParser();
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to set private fields since we can't modify the class
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Field optionsField = parser.getClass().getDeclaredField("options");
                                                                                                                                                                                                                         optionsField.setAccessible(true);
                                                                                                                                                                                                                         optionsField.set(parser, options);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                                                                                                                                                                         tokensField.setAccessible(true);
                                                                                                                                                                                                                         tokensField.set(parser, tokens);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Get and invoke the protected burstToken method
                                                                                                                                                                                                                         Method burstTokenMethod = parser.getClass().getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                                         burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Setup mock behavior - first char is valid option, second isn't
                                                                                                                                                                                                                         when(mockOption.hasArg()).thenReturn(false);
                                                                                                                                                                                                                         when(options.hasOption("a")).thenReturn(true);
                                                                                                                                                                                                                         when(options.hasOption("b")).thenReturn(false);
                                                                                                                                                                                                                         when(options.getOption("a")).thenReturn(mockOption);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Test with stopAtNonOption=true
                                                                                                                                                                                                                         burstTokenMethod.invoke(parser, "-ab", true);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Verify it processed the remaining part
                                                                                                                                                                                                                         assertEquals(1, tokens.size());
                                                                                                                                                                                                                         assertEquals("-a", tokens.get(0));
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to set up or execute test: " + e.getMessage());
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testBurstToken_WithoutStopAtNonOption() throws Exception {
                                                                                                                                                                                                                     // Setup test objects
                                                                                                                                                                                                                     Options options = mock(Options.class);
                                                                                                                                                                                                                     PosixParser parser = new PosixParser();
                                                                                                                                                                                                                     List<String> tokens = new ArrayList<>();
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to set private fields
                                                                                                                                                                                                                     Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                                                                                     optionsField.setAccessible(true);
                                                                                                                                                                                                                     optionsField.set(parser, options);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                                                                                     tokensField.setAccessible(true);
                                                                                                                                                                                                                     tokensField.set(parser, tokens);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Setup mock behavior - first char is valid option, second isn't
                                                                                                                                                                                                                     Option mockOption = mock(Option.class);
                                                                                                                                                                                                                     when(mockOption.hasArg()).thenReturn(false);
                                                                                                                                                                                                                     when(options.hasOption("a")).thenReturn(true);
                                                                                                                                                                                                                     when(options.hasOption("b")).thenReturn(false);
                                                                                                                                                                                                                     when(options.getOption("a")).thenReturn(mockOption);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to invoke protected burstToken method
                                                                                                                                                                                                                     Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                                     burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                                     burstTokenMethod.invoke(parser, "-ab", false);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify it added the whole token
                                                                                                                                                                                                                     assertEquals(1, tokens.size());
                                                                                                                                                                                                                     assertEquals("-ab", tokens.get(0));
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testBurstToken_WithMultipleValidOptions() {
                                                                                                                                                                                                                     // Setup mock behavior
                                                                                                                                                                                                                     Options options = mock(Options.class);
                                                                                                                                                                                                                     Option mockOptionA = mock(Option.class);
                                                                                                                                                                                                                     Option mockOptionB = mock(Option.class);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     when(mockOptionA.hasArg()).thenReturn(false);
                                                                                                                                                                                                                     when(mockOptionB.hasArg()).thenReturn(false);
                                                                                                                                                                                                                     when(options.hasOption("a")).thenReturn(true);
                                                                                                                                                                                                                     when(options.hasOption("b")).thenReturn(true);
                                                                                                                                                                                                                     when(options.getOption("a")).thenReturn(mockOptionA);
                                                                                                                                                                                                                     when(options.getOption("b")).thenReturn(mockOptionB);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Initialize parser and tokens
                                                                                                                                                                                                                     PosixParser parser = new PosixParser();
                                                                                                                                                                                                                     List<String> tokens = new ArrayList<>();
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to set private fields for testing
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                                                                                         optionsField.setAccessible(true);
                                                                                                                                                                                                                         optionsField.set(parser, options);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                                                                                         tokensField.setAccessible(true);
                                                                                                                                                                                                                         tokensField.set(parser, tokens);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Use reflection to access protected burstToken method
                                                                                                                                                                                                                         Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                                         burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                                         burstTokenMethod.invoke(parser, "-abc", false);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to set up test context using reflection");
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify both options were added
                                                                                                                                                                                                                     assertEquals(2, tokens.size());
                                                                                                                                                                                                                     assertEquals("-a", tokens.get(0));
                                                                                                                                                                                                                     assertEquals("-b", tokens.get(1));
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testBurstToken_WithOptionArgumentAtEnd() throws Exception {
                                                                                                                                                                                                                     // Setup mocks
                                                                                                                                                                                                                     Options options = mock(Options.class);
                                                                                                                                                                                                                     Option mockOption = mock(Option.class);
                                                                                                                                                                                                                     when(mockOption.hasArg()).thenReturn(true);
                                                                                                                                                                                                                     when(options.hasOption("a")).thenReturn(true);
                                                                                                                                                                                                                     when(options.getOption("a")).thenReturn(mockOption);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Initialize parser and set options
                                                                                                                                                                                                                     PosixParser parser = new PosixParser();
                                                                                                                                                                                                                     Field optionsField = parser.getClass().getDeclaredField("options");
                                                                                                                                                                                                                     optionsField.setAccessible(true);
                                                                                                                                                                                                                     optionsField.set(parser, options);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Initialize tokens list and set in parser
                                                                                                                                                                                                                     List<String> tokens = new ArrayList<>();
                                                                                                                                                                                                                     Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                                                                                                                                                                     tokensField.setAccessible(true);
                                                                                                                                                                                                                     tokensField.set(parser, tokens);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Get burstToken method and make it accessible
                                                                                                                                                                                                                     Method burstTokenMethod = parser.getClass().getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                                     burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Test with argument at end
                                                                                                                                                                                                                     burstTokenMethod.invoke(parser, "-a", false);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify only option was added (no argument)
                                                                                                                                                                                                                     assertEquals(1, tokens.size());
                                                                                                                                                                                                                     assertEquals("-a", tokens.get(0));
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testBurstToken_WithEmptyToken() throws Exception {
                                                                                                                                                                                                                     PosixParser parser = new PosixParser();
                                                                                                                                                                                                                     Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                                     burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                     exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                     burstTokenMethod.invoke(parser, "", false);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testBurstToken_WithNullToken() throws Exception {
                                                                                                                                                                                                                     PosixParser parser = new PosixParser();
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         // Use reflection to access protected method
                                                                                                                                                                                                                         Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                                         burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                                         burstTokenMethod.invoke(parser, null, false);
                                                                                                                                                                                                                         fail("Expected NullPointerException to be thrown");
                                                                                                                                                                                                                     } catch (InvocationTargetException e) {
                                                                                                                                                                                                                         // The actual exception will be wrapped in InvocationTargetException
                                                                                                                                                                                                                         if (e.getCause() instanceof NullPointerException) {
                                                                                                                                                                                                                             // Expected exception
                                                                                                                                                                                                                             return;
                                                                                                                                                                                                                         }
                                                                                                                                                                                                                         throw e;
                                                                                                                                                                                                                     } catch (NullPointerException e) {
                                                                                                                                                                                                                         // Expected exception (in case it's thrown before reflection)
                                                                                                                                                                                                                         return;
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testBurstToken_WithSingleCharacterToken() throws Exception {
                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                     Options options = mock(Options.class);
                                                                                                                                                                                                                     when(options.hasOption("a")).thenReturn(false);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create parser instance and set options using reflection
                                                                                                                                                                                                                     PosixParser parser = new PosixParser();
                                                                                                                                                                                                                     Field optionsField = parser.getClass().getDeclaredField("options");
                                                                                                                                                                                                                     optionsField.setAccessible(true);
                                                                                                                                                                                                                     optionsField.set(parser, options);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Get tokens field for verification
                                                                                                                                                                                                                     Field tokensField = parser.getClass().getDeclaredField("tokens");
                                                                                                                                                                                                                     tokensField.setAccessible(true);
                                                                                                                                                                                                                     @SuppressWarnings("unchecked")
                                                                                                                                                                                                                     List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Get burstToken method and invoke it using reflection
                                                                                                                                                                                                                     Method burstTokenMethod = parser.getClass().getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                                     burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                                     burstTokenMethod.invoke(parser, "a", false);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                     assertEquals(1, tokens.size());
                                                                                                                                                                                                                     assertEquals("a", tokens.get(0));
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                            public void testBurstTokenWithInvalidOptionAndStopAtNonOption() throws Exception {
                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                PosixParser parser = new PosixParser();
                                                                                                                                                                                                                Options options = mock(Options.class);
                                                                                                                                                                                                                when(options.hasOption(anyString())).thenReturn(false); // Make all options invalid
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Set private fields using reflection
                                                                                                                                                                                                                Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                                                                                optionsField.setAccessible(true);
                                                                                                                                                                                                                optionsField.set(parser, options);
                                                                                                                                                                                                                
                                                                                                                                                                                                                Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                                                                                tokensField.setAccessible(true);
                                                                                                                                                                                                                List<String> tokens = new ArrayList<>();
                                                                                                                                                                                                                tokensField.set(parser, tokens);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Get protected burstToken method via reflection
                                                                                                                                                                                                                Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                                burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Test case 1: stopAtNonOption = true (should process remaining characters)
                                                                                                                                                                                                                burstTokenMethod.invoke(parser, "xabc", true);
                                                                                                                                                                                                                // Original: should process "abc" (call process("abc"))
                                                                                                                                                                                                                // Mutant: should add full token "xabc" to tokens
                                                                                                                                                                                                                assertTrue("Should process remaining characters when stopAtNonOption is true", 
                                                                                                                                                                                                                           tokens.isEmpty()); // process() would clear/add differently
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Reset for next test
                                                                                                                                                                                                                tokens.clear();
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Test case 2: stopAtNonOption = false (should add full token)
                                                                                                                                                                                                                burstTokenMethod.invoke(parser, "xabc", false);
                                                                                                                                                                                                                // Original: should add full token "xabc"
                                                                                                                                                                                                                // Mutant: should process "abc" (call process("abc"))
                                                                                                                                                                                                                assertEquals("Should add full token when stopAtNonOption is false", 
                                                                                                                                                                                                                            java.util.Collections.singletonList("xabc"), tokens);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                       public void testBurstTokenWithNonOptionAndStopAtNonOptionFalse() throws Exception {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           PosixParser parser = new PosixParser();
                                                                                                                                                                                                           Options mockOptions = mock(Options.class);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Use reflection to set private fields
                                                                                                                                                                                                           Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                                                                           optionsField.setAccessible(true);
                                                                                                                                                                                                           optionsField.set(parser, mockOptions);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                                                                           tokensField.setAccessible(true);
                                                                                                                                                                                                           tokensField.set(parser, new ArrayList<>());
                                                                                                                                                                                                       
                                                                                                                                                                                                           // Mock behavior - first character is not an option
                                                                                                                                                                                                           when(mockOptions.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // We need to mock process() to verify it's not called
                                                                                                                                                                                                           // Since process() is private, we'll verify by checking tokens list instead
                                                                                                                                                                                                           String token = "abc";
                                                                                                                                                                                                           boolean stopAtNonOption = false;
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Use reflection to call protected method
                                                                                                                                                                                                           Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                           burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                           burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify - original behavior would add the entire token
                                                                                                                                                                                                           // Mutated behavior would call process() and not add to tokens
                                                                                                                                                                                                           @SuppressWarnings("unchecked")
                                                                                                                                                                                                           List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                                                                                                                           assertEquals(1, tokens.size());
                                                                                                                                                                                                           assertEquals(token, tokens.get(0));
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Additional verification that process() wasn't called
                                                                                                                                                                                                           // Since we can't directly verify private method calls, we rely on tokens list state
                                                                                                                                                                                                           // If process() was called (mutated behavior), tokens would be empty
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                  public void testBurstToken_DetectsStopAtNonOptionMutation() throws Exception {
                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                      PosixParser parser = new PosixParser();
                                                                                                                                                                                                      Options options = mock(Options.class);
                                                                                                                                                                                                      Option mockOption = mock(Option.class);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Mock behavior - first character is valid option, second is invalid
                                                                                                                                                                                                      when(options.hasOption("a")).thenReturn(true);
                                                                                                                                                                                                      when(options.hasOption("b")).thenReturn(false);
                                                                                                                                                                                                      when(options.getOption("a")).thenReturn(mockOption);
                                                                                                                                                                                                      when(mockOption.hasArg()).thenReturn(false);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Set parser state using reflection
                                                                                                                                                                                                      Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                                                                      optionsField.setAccessible(true);
                                                                                                                                                                                                      optionsField.set(parser, options);
                                                                                                                                                                                                      
                                                                                                                                                                                                      Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                                                                      tokensField.setAccessible(true);
                                                                                                                                                                                                      tokensField.set(parser, new ArrayList<>());
                                                                                                                                                                                                      
                                                                                                                                                                                                      Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                                                                                                                                                      eatTheRestField.setAccessible(true);
                                                                                                                                                                                                      eatTheRestField.set(parser, false);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Call protected method using reflection
                                                                                                                                                                                                      Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                                      burstTokenMethod.setAccessible(true);
                                                                                                                                                                                                      burstTokenMethod.invoke(parser, "ab", true);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Get tokens for verification
                                                                                                                                                                                                      @SuppressWarnings("unchecked")
                                                                                                                                                                                                      List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Verify behavior - should NOT add whole token ("ab") but should process remaining
                                                                                                                                                                                                      assertFalse("Test should detect mutation by checking token wasn't added whole", 
                                                                                                                                                                                                                 tokens.contains("ab"));
                                                                                                                                                                                                      // Also verify valid option was processed
                                                                                                                                                                                                      assertTrue(tokens.contains("-a"));
                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                         public void testBurstToken_ProcessesCorrectSubstringWhenStopAtNonOption() throws Exception {
                                                                                                                                                                                             // Setup
                                                                                                                                                                                             PosixParser parser = new PosixParser();
                                                                                                                                                                                             Options mockOptions = mock(Options.class);
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to set private fields
                                                                                                                                                                                             Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                                                             optionsField.setAccessible(true);
                                                                                                                                                                                             optionsField.set(parser, mockOptions);
                                                                                                                                                                                             
                                                                                                                                                                                             Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                                                             tokensField.setAccessible(true);
                                                                                                                                                                                             tokensField.set(parser, new ArrayList<>());
                                                                                                                                                                                             
                                                                                                                                                                                             // Mock options to return false for any option check
                                                                                                                                                                                             when(mockOptions.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                             
                                                                                                                                                                                             // Set stopAtNonOption to true to trigger the process() call
                                                                                                                                                                                             boolean stopAtNonOption = true;
                                                                                                                                                                                             String token = "abc"; // 'a' is at index 0, 'b' at 1, 'c' at 2
                                                                                                                                                                                             
                                                                                                                                                                                             // Get the burstToken method via reflection since it's protected
                                                                                                                                                                                             Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                             burstTokenMethod.setAccessible(true);
                                                                                                                                                                                             
                                                                                                                                                                                             // Execute
                                                                                                                                                                                             burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify the tokens list contains the expected values
                                                                                                                                                                                             @SuppressWarnings("unchecked")
                                                                                                                                                                                             List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                                                                                                             assertEquals(1, tokens.size());
                                                                                                                                                                                             assertEquals("bc", tokens.get(0));
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                public void testBurstToken_StopAtNonOption_ProcessesCorrectSubstring() throws Exception {
                                                                                                                                                                                    // Setup
                                                                                                                                                                                    PosixParser parser = new PosixParser();
                                                                                                                                                                                    Options mockOptions = mock(Options.class);
                                                                                                                                                                                    
                                                                                                                                                                                    // Set private fields using reflection
                                                                                                                                                                                    Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                                                    optionsField.setAccessible(true);
                                                                                                                                                                                    optionsField.set(parser, mockOptions);
                                                                                                                                                                                    
                                                                                                                                                                                    Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                                                    tokensField.setAccessible(true);
                                                                                                                                                                                    tokensField.set(parser, new ArrayList<>());
                                                                                                                                                                                    
                                                                                                                                                                                    Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                                                                                                                                    eatTheRestField.setAccessible(true);
                                                                                                                                                                                    eatTheRestField.set(parser, false);
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock options to return false for any option check
                                                                                                                                                                                    when(mockOptions.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use a spy to verify process() calls
                                                                                                                                                                                    PosixParser spyParser = spy(parser);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test input where mutation would make a difference
                                                                                                                                                                                    String token = "abc";
                                                                                                                                                                                    boolean stopAtNonOption = true;
                                                                                                                                                                                    
                                                                                                                                                                                    // Get burstToken method via reflection since it's protected
                                                                                                                                                                                    Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                                    burstTokenMethod.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Execute
                                                                                                                                                                                    burstTokenMethod.invoke(spyParser, token, stopAtNonOption);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify tokens list remains empty
                                                                                                                                                                                    List<?> tokens = (List<?>) tokensField.get(spyParser);
                                                                                                                                                                                    assertTrue(tokens.isEmpty());
                                                                                                                                                                                    
                                                                                                                                                                                    // Alternative verification - check if the first character was processed as a non-option
                                                                                                                                                                                    // and the rest were processed as potential options
                                                                                                                                                                                    // This assumes the implementation would leave tokens empty when stopAtNonOption is true
                                                                                                                                                                                    // and the first character is not an option
                                                                                                                                                                                }

    @Test
                                                                                                                                                                           public void testBurstToken_DetectsSubstringProcessMutation() throws Exception {
                                                                                                                                                                               // Setup
                                                                                                                                                                               PosixParser parser = new PosixParser();
                                                                                                                                                                               Options options = mock(Options.class);
                                                                                                                                                                               Option mockOption = mock(Option.class);
                                                                                                                                                                               
                                                                                                                                                                               // Mock behavior - first character is valid option, second is invalid
                                                                                                                                                                               when(options.hasOption("a")).thenReturn(true);
                                                                                                                                                                               when(options.hasOption("b")).thenReturn(false);
                                                                                                                                                                               when(options.getOption("a")).thenReturn(mockOption);
                                                                                                                                                                               when(mockOption.hasArg()).thenReturn(false);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to set private fields since no constructor
                                                                                                                                                                               Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                                               optionsField.setAccessible(true);
                                                                                                                                                                               optionsField.set(parser, options);
                                                                                                                                                                               
                                                                                                                                                                               Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                                               tokensField.setAccessible(true);
                                                                                                                                                                               tokensField.set(parser, new ArrayList<>());
                                                                                                                                                                               
                                                                                                                                                                               // Test input - "a" is valid option, "b" is not
                                                                                                                                                                               String token = "ab";
                                                                                                                                                                               boolean stopAtNonOption = true;
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to call protected burstToken method
                                                                                                                                                                               Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                               burstTokenMethod.setAccessible(true);
                                                                                                                                                                               burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                                                                                                               
                                                                                                                                                                               // Verify tokens list contains the valid option and processed invalid option
                                                                                                                                                                               @SuppressWarnings("unchecked")
                                                                                                                                                                               List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                                                                                               assertEquals(2, tokens.size());
                                                                                                                                                                               assertEquals("-a", tokens.get(0));
                                                                                                                                                                               assertEquals("b", tokens.get(1));
                                                                                                                                                                           }

    @Test
                                                                                                                                                                  public void testBurstToken_ProcessesRemainingTokenWhenStopAtNonOptionTrue() throws Exception {
                                                                                                                                                                      // Setup
                                                                                                                                                                      PosixParser parser = new PosixParser();
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                      Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                                      tokensField.setAccessible(true);
                                                                                                                                                                      tokensField.set(parser, new ArrayList<>());
                                                                                                                                                                      
                                                                                                                                                                      Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                                      optionsField.setAccessible(true);
                                                                                                                                                                      Options options = mock(Options.class);
                                                                                                                                                                      optionsField.set(parser, options);
                                                                                                                                                                      
                                                                                                                                                                      Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                                                                                                                      currentOptionField.setAccessible(true);
                                                                                                                                                                      Option currentOption = mock(Option.class);
                                                                                                                                                                      currentOptionField.set(parser, currentOption);
                                                                                                                                                                      
                                                                                                                                                                      // Mock behavior
                                                                                                                                                                      when(options.hasOption("a")).thenReturn(true);
                                                                                                                                                                      when(options.hasOption("b")).thenReturn(false); // Invalid option
                                                                                                                                                                      when(currentOption.hasArg()).thenReturn(false);
                                                                                                                                                                      
                                                                                                                                                                      // Create spy to verify process() call
                                                                                                                                                                      PosixParser spyParser = spy(parser);
                                                                                                                                                                      
                                                                                                                                                                      // Test input - "a" is valid, "b" is invalid
                                                                                                                                                                      String token = "-ab123";
                                                                                                                                                                      boolean stopAtNonOption = true;
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to call protected method
                                                                                                                                                                      Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                                      burstTokenMethod.setAccessible(true);
                                                                                                                                                                      burstTokenMethod.invoke(spyParser, token, stopAtNonOption);
                                                                                                                                                                      
                                                                                                                                                                      // Verify tokens list through reflection
                                                                                                                                                                      List<?> tokens = (List<?>) tokensField.get(spyParser);
                                                                                                                                                                      assertEquals(2, tokens.size());
                                                                                                                                                                      assertEquals("-a", tokens.get(0));
                                                                                                                                                                      assertEquals("b123", tokens.get(1));
                                                                                                                                                                  }

    @Test
                                                                                                                                                         public void testBurstTokenWithMultipleOptionsAfterArgument_DetectsBreakToContinueMutant() throws Exception {
                                                                                                                                                             // Setup test data
                                                                                                                                                             String token = "abcde"; // 'b' is valid option with arg, 'c' is another valid option
                                                                                                                                                             boolean stopAtNonOption = false;
                                                                                                                                                             
                                                                                                                                                             // Mock options and their behavior
                                                                                                                                                             Options options = mock(Options.class);
                                                                                                                                                             Option optionB = mock(Option.class);
                                                                                                                                                             Option optionC = mock(Option.class);
                                                                                                                                                             
                                                                                                                                                             when(options.hasOption("b")).thenReturn(true);
                                                                                                                                                             when(options.hasOption("c")).thenReturn(true);
                                                                                                                                                             when(options.getOption("b")).thenReturn(optionB);
                                                                                                                                                             when(options.getOption("c")).thenReturn(optionC);
                                                                                                                                                             when(optionB.hasArg()).thenReturn(true);
                                                                                                                                                             when(optionC.hasArg()).thenReturn(false); // Doesn't matter for this test
                                                                                                                                                             
                                                                                                                                                             // Create instance and set up using reflection
                                                                                                                                                             PosixParser parser = new PosixParser();
                                                                                                                                                             
                                                                                                                                                             // Set private 'options' field
                                                                                                                                                             Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                             optionsField.setAccessible(true);
                                                                                                                                                             optionsField.set(parser, options);
                                                                                                                                                             
                                                                                                                                                             // Set private 'tokens' field
                                                                                                                                                             Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                             tokensField.setAccessible(true);
                                                                                                                                                             tokensField.set(parser, new ArrayList<>());
                                                                                                                                                             
                                                                                                                                                             // Get protected 'burstToken' method
                                                                                                                                                             Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                             burstTokenMethod.setAccessible(true);
                                                                                                                                                             
                                                                                                                                                             // Execute method
                                                                                                                                                             burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                                                                                             
                                                                                                                                                             // Verify results - original should have 2 tokens (-b and "cde"), mutant would have more
                                                                                                                                                             @SuppressWarnings("unchecked")
                                                                                                                                                             List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                                                                             assertEquals(2, tokens.size());
                                                                                                                                                             assertEquals("-b", tokens.get(0));
                                                                                                                                                             assertEquals("cde", tokens.get(1));
                                                                                                                                                             
                                                                                                                                                             // Additional check to ensure no other options were processed
                                                                                                                                                             verify(options, never()).getOption("c");
                                                                                                                                                         }

    @Test
                                                                                                                                                    public void testBurstTokenWithMultipleOptionsDetectsBreakToReturnMutant() throws Exception {
                                                                                                                                                        // Setup test data
                                                                                                                                                        String token = "abcde"; // 'b' is option with arg, 'c' is another option
                                                                                                                                                        boolean stopAtNonOption = false;
                                                                                                                                                        
                                                                                                                                                        // Mock options and their behavior
                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                        Option optionWithArg = mock(Option.class);
                                                                                                                                                        Option regularOption = mock(Option.class);
                                                                                                                                                        
                                                                                                                                                        // Configure mocks
                                                                                                                                                        when(options.hasOption("b")).thenReturn(true);
                                                                                                                                                        when(options.hasOption("c")).thenReturn(true);
                                                                                                                                                        when(options.getOption("b")).thenReturn(optionWithArg);
                                                                                                                                                        when(options.getOption("c")).thenReturn(regularOption);
                                                                                                                                                        when(optionWithArg.hasArg()).thenReturn(true);
                                                                                                                                                        when(regularOption.hasArg()).thenReturn(false);
                                                                                                                                                        
                                                                                                                                                        // Create instance and set fields using reflection
                                                                                                                                                        PosixParser parser = new PosixParser();
                                                                                                                                                        
                                                                                                                                                        // Set private fields using reflection
                                                                                                                                                        Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                        optionsField.setAccessible(true);
                                                                                                                                                        optionsField.set(parser, options);
                                                                                                                                                        
                                                                                                                                                        Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                        tokensField.setAccessible(true);
                                                                                                                                                        tokensField.set(parser, new ArrayList<>());
                                                                                                                                                        
                                                                                                                                                        // Invoke protected method using reflection
                                                                                                                                                        Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                        burstTokenMethod.setAccessible(true);
                                                                                                                                                        burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                                                                                        
                                                                                                                                                        // Verify behavior - original would process both options, mutant would stop after first
                                                                                                                                                        // Check if both options were added to tokens
                                                                                                                                                        @SuppressWarnings("unchecked")
                                                                                                                                                        List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                                                                        assertEquals(3, tokens.size()); // "-b", "cde", "-c" in original
                                                                                                                                                        assertEquals("-b", tokens.get(0));
                                                                                                                                                        assertEquals("cde", tokens.get(1));
                                                                                                                                                        assertEquals("-c", tokens.get(2));
                                                                                                                                                        
                                                                                                                                                        // Verify currentOption is set to the last processed option
                                                                                                                                                        Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                                                                                                        currentOptionField.setAccessible(true);
                                                                                                                                                        assertSame(regularOption, currentOptionField.get(parser));
                                                                                                                                                    }

    @Test
                                                                                                                                               public void testBurstTokenWithOptionHavingArgument_ShouldStopProcessingAfterArgument() throws Exception {
                                                                                                                                                   // Setup
                                                                                                                                                   PosixParser parser = new PosixParser();
                                                                                                                                                   
                                                                                                                                                   // Get and set private tokens field
                                                                                                                                                   Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                                   tokensField.setAccessible(true);
                                                                                                                                                   tokensField.set(parser, new ArrayList<>());
                                                                                                                                                   
                                                                                                                                                   // Mock options and option
                                                                                                                                                   Options options = mock(Options.class);
                                                                                                                                                   Option mockOption = mock(Option.class);
                                                                                                                                                   when(options.hasOption(anyString())).thenReturn(true);
                                                                                                                                                   when(options.getOption(anyString())).thenReturn(mockOption);
                                                                                                                                                   when(mockOption.hasArg()).thenReturn(true);
                                                                                                                                                   
                                                                                                                                                   // Get and set private options field
                                                                                                                                                   Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                                   optionsField.setAccessible(true);
                                                                                                                                                   optionsField.set(parser, options);
                                                                                                                                                   
                                                                                                                                                   // Test input: "-abc" where 'a' is an option requiring argument ("bc")
                                                                                                                                                   String token = "abc";
                                                                                                                                                   boolean stopAtNonOption = false;
                                                                                                                                                   
                                                                                                                                                   // Get and call protected burstToken method
                                                                                                                                                   Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                                   burstTokenMethod.setAccessible(true);
                                                                                                                                                   burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                                                                                   
                                                                                                                                                   // Verify results through reflection
                                                                                                                                                   @SuppressWarnings("unchecked")
                                                                                                                                                   List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                                                                   assertEquals(2, tokens.size());
                                                                                                                                                   assertEquals("-a", tokens.get(0));
                                                                                                                                                   assertEquals("bc", tokens.get(1));
                                                                                                                                                   
                                                                                                                                                   // Additional verification that we didn't process 'b' and 'c' as options
                                                                                                                                                   verify(options, times(1)).hasOption(anyString());
                                                                                                                                                   verify(options, times(1)).getOption(anyString());
                                                                                                                                               }

    @Test
                                                                                                                                          public void testBurstToken_DetectsElseToElseIfTrueMutant() throws Exception {
                                                                                                                                              // Setup
                                                                                                                                              PosixParser parser = new PosixParser();
                                                                                                                                              Options options = mock(Options.class);
                                                                                                                                              
                                                                                                                                              // Use reflection to set private fields
                                                                                                                                              Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                              optionsField.setAccessible(true);
                                                                                                                                              optionsField.set(parser, options);
                                                                                                                                              
                                                                                                                                              Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                              tokensField.setAccessible(true);
                                                                                                                                              tokensField.set(parser, new ArrayList<>());
                                                                                                                                              
                                                                                                                                              // Mock behavior - no options are valid
                                                                                                                                              when(options.hasOption(anyString())).thenReturn(false);
                                                                                                                                              
                                                                                                                                              String testToken = "abc";
                                                                                                                                              boolean stopAtNonOption = false;
                                                                                                                                              
                                                                                                                                              // Execute using reflection to call protected method
                                                                                                                                              Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                              burstTokenMethod.setAccessible(true);
                                                                                                                                              burstTokenMethod.invoke(parser, testToken, stopAtNonOption);
                                                                                                                                              
                                                                                                                                              // Verify
                                                                                                                                              @SuppressWarnings("unchecked")
                                                                                                                                              List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                                                              assertEquals(1, tokens.size());
                                                                                                                                              assertEquals(testToken, tokens.get(0));
                                                                                                                                              
                                                                                                                                              // Additional verification that we went through the else branch
                                                                                                                                              Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                                                                                              currentOptionField.setAccessible(true);
                                                                                                                                              assertNull(currentOptionField.get(parser)); // Shouldn't be set in else branch
                                                                                                                                          }

    @Test
                                                                                                                                     public void testBurstToken_DetectsMutatedElseCase() {
                                                                                                                                         // Setup
                                                                                                                                         PosixParser parser = new PosixParser();
                                                                                                                                         Options options = mock(Options.class);
                                                                                                                                         Option option = mock(Option.class);
                                                                                                                                         
                                                                                                                                         // Mock behavior - no options available (all characters invalid)
                                                                                                                                         when(options.hasOption(anyString())).thenReturn(false);
                                                                                                                                         when(options.getOption(anyString())).thenReturn(option);
                                                                                                                                         
                                                                                                                                         // Use reflection to set private fields since no constructor
                                                                                                                                         try {
                                                                                                                                             Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                             tokensField.setAccessible(true);
                                                                                                                                             tokensField.set(parser, new ArrayList<String>());
                                                                                                                                             
                                                                                                                                             Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                             optionsField.setAccessible(true);
                                                                                                                                             optionsField.set(parser, options);
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Failed to set up test via reflection");
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Test case with invalid option and stopAtNonOption false
                                                                                                                                         String token = "abc"; // Invalid option characters
                                                                                                                                         boolean stopAtNonOption = false;
                                                                                                                                         
                                                                                                                                         // Execute using reflection to call protected method
                                                                                                                                         try {
                                                                                                                                             Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                             burstTokenMethod.setAccessible(true);
                                                                                                                                             burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Failed to invoke burstToken method via reflection");
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Verify - original would add token, mutant wouldn't
                                                                                                                                         List<String> resultTokens;
                                                                                                                                         try {
                                                                                                                                             resultTokens = (List<String>) PosixParser.class.getDeclaredField("tokens").get(parser);
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Failed to verify results");
                                                                                                                                             return;
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Original behavior would add token, mutant would skip
                                                                                                                                         assertEquals("Original should add token when invalid option found and stopAtNonOption=false", 
                                                                                                                                                     1, resultTokens.size());
                                                                                                                                         assertEquals("Original should add full token", 
                                                                                                                                                     "abc", resultTokens.get(0));
                                                                                                                                     }

    @Test
                                                                                                                                public void testBurstTokenWithStopAtNonOptionAndNonOptionChar() throws NoSuchFieldException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
                                                                                                                                    // Setup
                                                                                                                                    PosixParser parser = new PosixParser();
                                                                                                                                    
                                                                                                                                    // Mock the Options object and its behavior
                                                                                                                                    Options options = mock(Options.class);
                                                                                                                                    Option mockOption = mock(Option.class);
                                                                                                                                    when(options.hasOption("a")).thenReturn(true);
                                                                                                                                    when(options.hasOption("b")).thenReturn(false); // 'b' is not an option
                                                                                                                                    when(options.getOption("a")).thenReturn(mockOption);
                                                                                                                                    when(mockOption.hasArg()).thenReturn(false);
                                                                                                                                    
                                                                                                                                    // Use reflection to set private fields since no constructor
                                                                                                                                    Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                                    optionsField.setAccessible(true);
                                                                                                                                    optionsField.set(parser, options);
                                                                                                                                    
                                                                                                                                    Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                                    tokensField.setAccessible(true);
                                                                                                                                    tokensField.set(parser, new ArrayList<String>());
                                                                                                                                    
                                                                                                                                    // Test case with stopAtNonOption=true and token "aab" where 'b' is non-option
                                                                                                                                    String token = "aab";
                                                                                                                                    boolean stopAtNonOption = true;
                                                                                                                                    
                                                                                                                                    // Call the method (using reflection since it's protected)
                                                                                                                                    Method burstToken = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                                    burstToken.setAccessible(true);
                                                                                                                                    burstToken.invoke(parser, token, stopAtNonOption);
                                                                                                                                    
                                                                                                                                    // Verify results
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                                                    
                                                                                                                                    // Original behavior should process "-a" and then the remaining "b"
                                                                                                                                    // Mutated behavior would incorrectly add the whole token "aab"
                                                                                                                                    assertEquals(2, tokens.size());
                                                                                                                                    assertEquals("-a", tokens.get(0));
                                                                                                                                    assertEquals("b", tokens.get(1));
                                                                                                                                    
                                                                                                                                    // Also verify currentOption was set correctly
                                                                                                                                    Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                                                                                    currentOptionField.setAccessible(true);
                                                                                                                                    assertEquals(mockOption, currentOptionField.get(parser));
                                                                                                                                }

    @Test
                                                                                                                       public void testBurstToken_ProcessesCorrectSubstringWhenStopAtNonOption1() throws Exception {
                                                                                                                           // Setup
                                                                                                                           PosixParser parser = new PosixParser();
                                                                                                                           
                                                                                                                           // Use reflection to access private fields
                                                                                                                           Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                           tokensField.setAccessible(true);
                                                                                                                           tokensField.set(parser, new ArrayList<>());
                                                                                                                           
                                                                                                                           // Mock options to recognize only 'a' as valid option
                                                                                                                           Options options = mock(Options.class);
                                                                                                                           Option optionA = mock(Option.class);
                                                                                                                           when(options.hasOption("a")).thenReturn(true);
                                                                                                                           when(options.getOption("a")).thenReturn(optionA);
                                                                                                                           when(optionA.hasArg()).thenReturn(false);
                                                                                                                           
                                                                                                                           Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                           optionsField.setAccessible(true);
                                                                                                                           optionsField.set(parser, options);
                                                                                                                           
                                                                                                                           // Test input: "-abc" where 'a' is valid, 'b' is invalid
                                                                                                                           String token = "abc";
                                                                                                                           boolean stopAtNonOption = true;
                                                                                                                           
                                                                                                                           // Execute burstToken using reflection
                                                                                                                           Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                           burstTokenMethod.setAccessible(true);
                                                                                                                           burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                                                           
                                                                                                                           // Verify tokens contains the valid option through reflection
                                                                                                                           List<?> tokens = (List<?>) tokensField.get(parser);
                                                                                                                           assertEquals(1, tokens.size());
                                                                                                                           assertEquals("-a", tokens.get(0));
                                                                                                                           
                                                                                                                           // Verify the remaining characters were not processed (since stopAtNonOption is true)
                                                                                                                           // We can check that the tokens list only contains "-a" and not "-b" or "-c"
                                                                                                                       }

    @Test
                                                                                                              public void testBurstTokenWithInvalidOptionAndStopAtNonOption1() throws Exception {
                                                                                                                  // Setup
                                                                                                                  PosixParser parser = new PosixParser();
                                                                                                                  
                                                                                                                  // Mock options using reflection
                                                                                                                  Options mockOptions = mock(Options.class);
                                                                                                                  Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                                  optionsField.setAccessible(true);
                                                                                                                  optionsField.set(parser, mockOptions);
                                                                                                                  
                                                                                                                  // Initialize tokens list using reflection
                                                                                                                  Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                                  tokensField.setAccessible(true);
                                                                                                                  tokensField.set(parser, new ArrayList<String>());
                                                                                                                  
                                                                                                                  // Set eatTheRest to false using reflection
                                                                                                                  Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                                                                                                                  eatTheRestField.setAccessible(true);
                                                                                                                  eatTheRestField.set(parser, false);
                                                                                                                  
                                                                                                                  // Mock behavior - first character is valid option, second is invalid
                                                                                                                  when(mockOptions.hasOption("a")).thenReturn(true);
                                                                                                                  when(mockOptions.hasOption("b")).thenReturn(false);
                                                                                                                  
                                                                                                                  // Mock process consumer
                                                                                                                  java.util.function.Consumer<String> mockProcess = mock(java.util.function.Consumer.class);
                                                                                                                  Field processField = PosixParser.class.getDeclaredField("process");
                                                                                                                  processField.setAccessible(true);
                                                                                                                  processField.set(parser, mockProcess);
                                                                                                                  
                                                                                                                  // Test input - "ab" where 'a' is valid, 'b' is invalid
                                                                                                                  String token = "ab";
                                                                                                                  boolean stopAtNonOption = true;
                                                                                                                  
                                                                                                                  // Get burstToken method using reflection since it's protected
                                                                                                                  Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                                  burstTokenMethod.setAccessible(true);
                                                                                                                  
                                                                                                                  // Execute
                                                                                                                  burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                                                  
                                                                                                                  // Verify process was called with correct substring
                                                                                                                  verify(mockProcess).accept("b");
                                                                                                                  
                                                                                                                  // Verify tokens list through reflection
                                                                                                                  @SuppressWarnings("unchecked")
                                                                                                                  List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                                  assertEquals(1, tokens.size());
                                                                                                                  assertEquals("-a", tokens.get(0));
                                                                                                              }

    @Test
                                                                                                         public void testBurstToken_DetectsProcessSubstringMutation() throws Exception {
                                                                                                             // Setup
                                                                                                             PosixParser parser = new PosixParser();
                                                                                                             
                                                                                                             // Set tokens list via reflection
                                                                                                             Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                             tokensField.setAccessible(true);
                                                                                                             tokensField.set(parser, new ArrayList<>());
                                                                                                             
                                                                                                             // Mock options to have one valid option 'a' and make others invalid
                                                                                                             Options options = mock(Options.class);
                                                                                                             when(options.hasOption("a")).thenReturn(true);
                                                                                                             when(options.hasOption(anyString())).thenReturn(false);
                                                                                                             
                                                                                                             // Set options via reflection
                                                                                                             Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                             optionsField.setAccessible(true);
                                                                                                             optionsField.set(parser, options);
                                                                                                             
                                                                                                             // Create spy parser
                                                                                                             PosixParser spyParser = spy(parser);
                                                                                                             
                                                                                                             // Test case where we have valid option followed by invalid
                                                                                                             String token = "abc"; // 'a' is valid, 'b' and 'c' are invalid
                                                                                                             boolean stopAtNonOption = true;
                                                                                                             
                                                                                                             // Execute burstToken via reflection
                                                                                                             Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                             burstTokenMethod.setAccessible(true);
                                                                                                             burstTokenMethod.invoke(spyParser, token, stopAtNonOption);
                                                                                                             
                                                                                                             // Verify tokens list contains the valid option
                                                                                                             List<?> tokens = (List<?>) tokensField.get(spyParser);
                                                                                                             assertEquals(1, tokens.size());
                                                                                                             assertEquals("-a", tokens.get(0));
                                                                                                             
                                                                                                             // Verify process was called with "bc" by checking tokens weren't modified further
                                                                                                             // (since process would normally add to tokens list)
                                                                                                             assertEquals(1, tokens.size());
                                                                                                         }

    @Test
                                                                                                public void testBurstToken_ProcessesCorrectSubstringWhenStopAtNonOption2() throws Exception {
                                                                                                    // Setup
                                                                                                    PosixParser parser = spy(new PosixParser());
                                                                                                    Options options = mock(Options.class);
                                                                                                    Option option = mock(Option.class);
                                                                                                    
                                                                                                    // Configure mocks
                                                                                                    when(options.hasOption("a")).thenReturn(true);
                                                                                                    when(options.hasOption("b")).thenReturn(false); // 'b' is invalid option
                                                                                                    when(options.getOption("a")).thenReturn(option);
                                                                                                    when(option.hasArg()).thenReturn(false);
                                                                                                    
                                                                                                    // Set private fields using reflection
                                                                                                    Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                                    optionsField.setAccessible(true);
                                                                                                    optionsField.set(parser, options);
                                                                                                    
                                                                                                    Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                                    tokensField.setAccessible(true);
                                                                                                    tokensField.set(parser, new ArrayList<>());
                                                                                                    
                                                                                                    Field stopAtNonOptionField = PosixParser.class.getDeclaredField("stopAtNonOption");
                                                                                                    stopAtNonOptionField.setAccessible(true);
                                                                                                    stopAtNonOptionField.set(parser, true); // Important for this test case
                                                                                                    
                                                                                                    String token = "-ab"; // 'a' valid, 'b' invalid
                                                                                                    
                                                                                                    // Test
                                                                                                    Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                                    burstTokenMethod.setAccessible(true);
                                                                                                    burstTokenMethod.invoke(parser, token, true);
                                                                                                    
                                                                                                    // Verify tokens were processed correctly
                                                                                                    @SuppressWarnings("unchecked")
                                                                                                    List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                                    assertEquals(1, tokens.size());
                                                                                                    assertEquals("-a", tokens.get(0));
                                                                                                }

    @Test
                                                                                           public void testBurstTokenWithMultipleOptionsAfterArgument_DetectsBreakToReturnMutant() throws Exception {
                                                                                               // Setup test data
                                                                                               String token = "abcde"; // 'b' is option with arg, 'c' is another option
                                                                                               boolean stopAtNonOption = false;
                                                                                               
                                                                                               // Mock options and their behavior
                                                                                               Options options = mock(Options.class);
                                                                                               Option optionWithArg = mock(Option.class);
                                                                                               Option anotherOption = mock(Option.class);
                                                                                               
                                                                                               // Configure mocks
                                                                                               when(options.hasOption("b")).thenReturn(true);
                                                                                               when(options.getOption("b")).thenReturn(optionWithArg);
                                                                                               when(optionWithArg.hasArg()).thenReturn(true);
                                                                                               
                                                                                               when(options.hasOption("c")).thenReturn(true);
                                                                                               when(options.getOption("c")).thenReturn(anotherOption);
                                                                                               when(anotherOption.hasArg()).thenReturn(false);
                                                                                               
                                                                                               // Create instance and set options using reflection
                                                                                               PosixParser parser = new PosixParser();
                                                                                               Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                               optionsField.setAccessible(true);
                                                                                               optionsField.set(parser, options);
                                                                                               
                                                                                               Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                               tokensField.setAccessible(true);
                                                                                               tokensField.set(parser, new ArrayList<>());
                                                                                               
                                                                                               // Execute method using reflection
                                                                                               Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                               burstTokenMethod.setAccessible(true);
                                                                                               burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                               
                                                                                               // Verify behavior - should process both options if break works correctly
                                                                                               // Mutant with return would stop after first option
                                                                                               List<String> expectedTokens = new ArrayList<>();
                                                                                               expectedTokens.add("-b");
                                                                                               expectedTokens.add("cde"); // argument for b
                                                                                               expectedTokens.add("-c"); // this would be missing if return was used instead of break
                                                                                               
                                                                                               @SuppressWarnings("unchecked")
                                                                                               List<String> actualTokens = (List<String>) tokensField.get(parser);
                                                                                               assertEquals(expectedTokens, actualTokens);
                                                                                           }

    @Test
                                                                                      public void testBurstToken_ElseBranch_AddsWholeTokenWhenInvalidOptionAndNotStopAtNonOption() {
                                                                                          // Setup
                                                                                          PosixParser parser = new PosixParser();
                                                                                          Options options = mock(Options.class);
                                                                                          when(options.hasOption(anyString())).thenReturn(false);
                                                                                          
                                                                                          try {
                                                                                              // Use reflection to set private fields since no constructor
                                                                                              Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                              optionsField.setAccessible(true);
                                                                                              optionsField.set(parser, options);
                                                                                              
                                                                                              Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                              tokensField.setAccessible(true);
                                                                                              List<String> tokens = new ArrayList<>();
                                                                                              tokensField.set(parser, tokens);
                                                                                              
                                                                                              // Test input - invalid option character with stopAtNonOption false
                                                                                              String token = "xinvalid";
                                                                                              boolean stopAtNonOption = false;
                                                                                              
                                                                                              // Execute
                                                                                              Method burstToken = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                              burstToken.setAccessible(true);
                                                                                              burstToken.invoke(parser, token, stopAtNonOption);
                                                                                              
                                                                                              // Verify
                                                                                              assertEquals(1, tokens.size());
                                                                                              assertEquals(token, tokens.get(0));
                                                                                          } catch (NoSuchFieldException | IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                                                                                              fail("Reflection operation failed: " + e.getMessage());
                                                                                          }
                                                                                      }

    @Test
                                                                                 public void testBurstToken_NonOptionCharacterWithStopAtNonOptionFalse_ShouldAddToken() throws Exception {
                                                                                     // Setup
                                                                                     PosixParser parser = new PosixParser();
                                                                                     Options options = mock(Options.class);
                                                                                     
                                                                                     // Use reflection to set private fields
                                                                                     Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                     optionsField.setAccessible(true);
                                                                                     optionsField.set(parser, options);
                                                                                     
                                                                                     Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                     tokensField.setAccessible(true);
                                                                                     tokensField.set(parser, new ArrayList<>());
                                                                                     
                                                                                     // Mock behavior - no options available
                                                                                     when(options.hasOption(anyString())).thenReturn(false);
                                                                                     
                                                                                     String token = "abc"; // No hyphen prefix, not an option
                                                                                     boolean stopAtNonOption = false;
                                                                                     
                                                                                     // Use reflection to call protected method
                                                                                     Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                     burstTokenMethod.setAccessible(true);
                                                                                     burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                     
                                                                                     // Verify
                                                                                     @SuppressWarnings("unchecked")
                                                                                     List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                     assertEquals(1, tokens.size());
                                                                                     assertEquals(token, tokens.get(0));
                                                                                     
                                                                                     // Also verify no option was processed
                                                                                     Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                                                                     currentOptionField.setAccessible(true);
                                                                                     assertNull(currentOptionField.get(parser));
                                                                                 }

    @Test
                                                                            public void testBurstToken_InvalidOptionWithStopAtNonOptionFalse_ShouldAddToken() throws Exception {
                                                                                // Setup
                                                                                PosixParser parser = new PosixParser();
                                                                                Options options = mock(Options.class);
                                                                                
                                                                                // Set private field 'options' using reflection
                                                                                Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                                optionsField.setAccessible(true);
                                                                                optionsField.set(parser, options);
                                                                                
                                                                                // Set private field 'tokens' using reflection
                                                                                Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                                tokensField.setAccessible(true);
                                                                                tokensField.set(parser, new ArrayList<>());
                                                                                
                                                                                // Mock behavior - first character is invalid option
                                                                                when(options.hasOption(anyString())).thenReturn(false);
                                                                                
                                                                                // Test input - first character is invalid option
                                                                                String token = "xabc";
                                                                                boolean stopAtNonOption = false;
                                                                                
                                                                                // Get protected method 'burstToken' using reflection
                                                                                Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                                burstTokenMethod.setAccessible(true);
                                                                                
                                                                                // Execute
                                                                                burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                                
                                                                                // Verify - should add original token when invalid option found and stopAtNonOption=false
                                                                                @SuppressWarnings("unchecked")
                                                                                List<String> tokens = (List<String>) tokensField.get(parser);
                                                                                assertEquals(1, tokens.size());
                                                                                assertEquals(token, tokens.get(0));
                                                                            }

    @Test
                                                                       public void testBurstToken_InvalidOptionWithStopAtNonOption_ShouldAddWholeToken() throws Exception {
                                                                           // Setup
                                                                           PosixParser parser = new PosixParser();
                                                                           Options options = mock(Options.class);
                                                                           
                                                                           // Use reflection to set private options field
                                                                           Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                           optionsField.setAccessible(true);
                                                                           optionsField.set(parser, options);
                                                                           
                                                                           // Mock options to return false for any option check
                                                                           when(options.hasOption(anyString())).thenReturn(false);
                                                                           
                                                                           // Set stopAtNonOption to true
                                                                           boolean stopAtNonOption = true;
                                                                           
                                                                           // Create a test token with invalid option
                                                                           String token = "xabc";
                                                                           
                                                                           // Use reflection to call protected burstToken method
                                                                           Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                           burstTokenMethod.setAccessible(true);
                                                                           burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                           
                                                                           // Use reflection to get private tokens field for verification
                                                                           Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                           tokensField.setAccessible(true);
                                                                           @SuppressWarnings("unchecked")
                                                                           List<String> tokens = (List<String>) tokensField.get(parser);
                                                                           
                                                                           // Verify behavior
                                                                           // Original: Should have added the whole token "xabc"
                                                                           // Mutant: Would add nothing
                                                                           assertEquals(1, tokens.size());
                                                                           assertEquals(token, tokens.get(0));
                                                                       }

    @Test
                                                              public void testBurstToken_ProcessesCorrectSubstringWhenStopAtNonOption3() throws Exception {
                                                                  // Setup test data
                                                                  String token = "abc"; // 'a' is valid, 'b' is invalid
                                                                  boolean stopAtNonOption = true;
                                                                  
                                                                  // Mock dependencies
                                                                  Options options = mock(Options.class);
                                                                  Option validOption = mock(Option.class);
                                                                  when(validOption.hasArg()).thenReturn(false);
                                                                  when(options.hasOption("a")).thenReturn(true);
                                                                  when(options.hasOption("b")).thenReturn(false);
                                                                  when(options.hasOption("c")).thenReturn(false);
                                                                  when(options.getOption("a")).thenReturn(validOption);
                                                                  
                                                                  // Create parser and set private fields via reflection
                                                                  PosixParser parser = new PosixParser();
                                                                  Field optionsField = PosixParser.class.getDeclaredField("options");
                                                                  optionsField.setAccessible(true);
                                                                  optionsField.set(parser, options);
                                                                  
                                                                  Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                                  tokensField.setAccessible(true);
                                                                  tokensField.set(parser, new ArrayList<>());
                                                                  
                                                                  // Execute method via reflection
                                                                  Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                                  burstTokenMethod.setAccessible(true);
                                                                  burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                                                  
                                                                  // Verify results through tokens list
                                                                  @SuppressWarnings("unchecked")
                                                                  List<String> tokens = (List<String>) tokensField.get(parser);
                                                                  assertEquals(1, tokens.size());
                                                                  assertEquals("-a", tokens.get(0));
                                                              }

    @Test
                                                     public void testBurstToken_StopAtNonOption_ProcessesCorrectSubstring1() throws Exception {
                                                         // Setup
                                                         PosixParser parser = new PosixParser();
                                                         Options mockOptions = mock(Options.class);
                                                         
                                                         // Use reflection to set private fields
                                                         Field optionsField = PosixParser.class.getDeclaredField("options");
                                                         optionsField.setAccessible(true);
                                                         optionsField.set(parser, mockOptions);
                                                         
                                                         Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                                         tokensField.setAccessible(true);
                                                         @SuppressWarnings("unchecked")
                                                         List<String> tokens = (List<String>) tokensField.get(parser);
                                                         
                                                         // Mock options to return false for any option check
                                                         when(mockOptions.hasOption(anyString())).thenReturn(false);
                                                         
                                                         // Enable stopAtNonOption
                                                         boolean stopAtNonOption = true;
                                                         
                                                         // Create a spy to verify process() calls
                                                         PosixParser spyParser = spy(parser);
                                                         
                                                         // Test input - invalid option at position 1
                                                         String token = "xabc";
                                                         
                                                         // Use reflection to call protected method
                                                         Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                                         burstTokenMethod.setAccessible(true);
                                                         burstTokenMethod.invoke(spyParser, token, stopAtNonOption);
                                                         
                                                         // Verify tokens list wasn't modified (indirect verification of behavior)
                                                         assertTrue(tokens.isEmpty());
                                                     }

    @Test
                                        public void testBurstToken_DetectsProcessSubstringMutation1() throws Exception {
                                            // Setup
                                            PosixParser parser = new PosixParser();
                                            
                                            // Use reflection to access private fields
                                            Field tokensField = PosixParser.class.getDeclaredField("tokens");
                                            tokensField.setAccessible(true);
                                            tokensField.set(parser, new ArrayList<>());
                                            
                                            Field optionsField = PosixParser.class.getDeclaredField("options");
                                            optionsField.setAccessible(true);
                                            Options mockOptions = mock(Options.class);
                                            optionsField.set(parser, mockOptions);
                                            
                                            Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                                            currentOptionField.setAccessible(true);
                                            currentOptionField.set(parser, null);
                                            
                                            // Mock options.hasOption() to return false for 'b' (invalid option)
                                            when(mockOptions.hasOption("a")).thenReturn(true);
                                            when(mockOptions.hasOption("b")).thenReturn(false);
                                            
                                            // Test input: "-ab" where 'a' is valid, 'b' is invalid
                                            String token = "ab";
                                            boolean stopAtNonOption = true;
                                            
                                            // Execute burstToken through reflection
                                            Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                                            burstTokenMethod.setAccessible(true);
                                            burstTokenMethod.invoke(parser, token, stopAtNonOption);
                                            
                                            // Verify the results through state changes
                                            List<String> tokens = (List<String>) tokensField.get(parser);
                                            assertEquals(1, tokens.size());
                                            assertEquals("-a", tokens.get(0));
                                            
                                            // The mutant would call process("ab") instead of process("b")
                                            // So this test would fail for the mutant
                                        }

    @Test
                   public void testBurstToken_ProcessesRemainingTokenWhenStopAtNonOptionTrue1() {
                       // Setup
                       PosixParser parser = new PosixParser();
                       Options options = mock(Options.class);
                       Option validOption = mock(Option.class);
                       
                       // Mock behavior
                       when(options.hasOption("a")).thenReturn(true);
                       when(options.hasOption("b")).thenReturn(false); // 'b' is invalid option
                       when(options.getOption("a")).thenReturn(validOption);
                       when(validOption.hasArg()).thenReturn(false);
                       
                       // Use reflection to set private fields since no constructor
                       try {
                           Field tokensField = PosixParser.class.getDeclaredField("tokens");
                           tokensField.setAccessible(true);
                           tokensField.set(parser, new ArrayList<String>());
                           
                           Field optionsField = PosixParser.class.getDeclaredField("options");
                           optionsField.setAccessible(true);
                           optionsField.set(parser, options);
                           
                           Field eatTheRestField = PosixParser.class.getDeclaredField("eatTheRest");
                           eatTheRestField.setAccessible(true);
                           eatTheRestField.set(parser, false);
                       } catch (Exception e) {
                           fail("Failed to set up test via reflection: " + e.getMessage());
                       }
                       
                       // Create spy to verify process() call
                       PosixParser spyParser = spy(parser);
                       
                       // Test input - 'a' is valid, 'b' is invalid, 'c' should be processed
                       String token = "-abc";
                       boolean stopAtNonOption = true;
                       
                       // Execute burstToken using reflection
                       try {
                           Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                           burstTokenMethod.setAccessible(true);
                           burstTokenMethod.invoke(spyParser, token, stopAtNonOption);
                       } catch (Exception e) {
                           fail("Failed to invoke burstToken: " + e.getMessage());
                       }
                       
                       // Verify tokens contains the valid option using reflection
                       try {
                           Field tokensField = PosixParser.class.getDeclaredField("tokens");
                           tokensField.setAccessible(true);
                           @SuppressWarnings("unchecked")
                           List<String> tokens = (List<String>) tokensField.get(spyParser);
                           
                           assertTrue(tokens.contains("-a"));
                           assertEquals(1, tokens.size());
                       } catch (Exception e) {
                           fail("Failed to verify tokens: " + e.getMessage());
                       }
                   }

    @Test
              public void testBurstTokenWithOptionArgShouldNotReturnEarly() {
                  try {
                      // Setup
                      PosixParser parser = new PosixParser();
                      Options options = mock(Options.class);
                      Option mockOption = mock(Option.class);
                      when(mockOption.hasArg()).thenReturn(true);
                      when(options.getOption("a")).thenReturn(mockOption);
                      when(options.hasOption("a")).thenReturn(true);
                      
                      // Use reflection to set private fields since no constructor
                      Field optionsField = PosixParser.class.getDeclaredField("options");
                      optionsField.setAccessible(true);
                      optionsField.set(parser, options);
                      
                      Field tokensField = PosixParser.class.getDeclaredField("tokens");
                      tokensField.setAccessible(true);
                      @SuppressWarnings("unchecked")
                      List<String> tokens = (List<String>) tokensField.get(parser);
                      if (tokens == null) {
                          tokens = new ArrayList<>();
                          tokensField.set(parser, tokens);
                      }
                      
                      // Test input - "ba123" where 'a' is an option requiring argument
                      String token = "ba123";
                      boolean stopAtNonOption = false;
                      
                      // Execute
                      Method burstToken = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                      burstToken.setAccessible(true);
                      burstToken.invoke(parser, token, stopAtNonOption);
                      
                      // Verify - should process full token
                      assertEquals(2, tokens.size());
                      assertEquals("-a", tokens.get(0));
                      assertEquals("123", tokens.get(1));
                      
                      // Verify currentOption was set
                      Field currentOptionField = PosixParser.class.getDeclaredField("currentOption");
                      currentOptionField.setAccessible(true);
                      assertEquals(mockOption, currentOptionField.get(parser));
                  } catch (NoSuchFieldException | IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                      fail("Reflection failed: " + e.getMessage());
                  }
              }

    @Test
         public void testBurstToken_ElseBranch() {
             // Setup
             PosixParser parser = new PosixParser();
             Options options = mock(Options.class);
             Option option = mock(Option.class);
             
             // Mock behavior - no options match
             when(options.hasOption(anyString())).thenReturn(false);
             when(options.getOption(anyString())).thenReturn(option);
             
             // Use reflection to set private fields since no constructor
             Field tokensField = null;
             try {
                 Field optionsField = PosixParser.class.getDeclaredField("options");
                 optionsField.setAccessible(true);
                 optionsField.set(parser, options);
                 
                 tokensField = PosixParser.class.getDeclaredField("tokens");
                 tokensField.setAccessible(true);
                 List<String> tokens = new ArrayList<>();
                 tokensField.set(parser, tokens);
             } catch (Exception e) {
                 fail("Failed to set up test via reflection: " + e.getMessage());
             }
             
             // Test input - non-option token with stopAtNonOption false
             String testToken = "abc";
             boolean stopAtNonOption = false;
             
             // Execute burstToken via reflection since it's protected
             try {
                 Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
                 burstTokenMethod.setAccessible(true);
                 burstTokenMethod.invoke(parser, testToken, stopAtNonOption);
             } catch (Exception e) {
                 fail("Failed to invoke burstToken via reflection: " + e.getMessage());
             }
             
             // Verify
             List<String> resultTokens;
             try {
                 resultTokens = (List<String>) tokensField.get(parser);
             } catch (Exception e) {
                 fail("Failed to verify test via reflection: " + e.getMessage());
                 return;
             }
             
             // Original behavior would add the full token when neither condition is met
             assertEquals(1, resultTokens.size());
             assertEquals(testToken, resultTokens.get(0));
             
             // Verify no option processing occurred
             verify(options, times(testToken.length() - 1)).hasOption(anyString());
             verify(options, never()).getOption(anyString());
         }

    @Test
    public void testBurstToken_InvalidOptionWithStopAtNonOptionFalse_AddsEntireToken() {
        // Setup
        PosixParser parser = new PosixParser();
        Options options = mock(Options.class);
        Option option = mock(Option.class);
        
        // Mock behavior - first character is valid option, second is invalid
        when(options.hasOption("a")).thenReturn(true);
        when(options.hasOption("b")).thenReturn(false);
        when(options.getOption("a")).thenReturn(option);
        when(option.hasArg()).thenReturn(false);
        
        // Use reflection to set private fields since no constructor
        try {
            Field optionsField = PosixParser.class.getDeclaredField("options");
            optionsField.setAccessible(true);
            optionsField.set(parser, options);
            
            Field tokensField = PosixParser.class.getDeclaredField("tokens");
            tokensField.setAccessible(true);
            tokensField.set(parser, new ArrayList<String>());
            
            // Use reflection to access protected burstToken method
            Method burstTokenMethod = PosixParser.class.getDeclaredMethod("burstToken", String.class, boolean.class);
            burstTokenMethod.setAccessible(true);
            
            // Test - token is "-ab" where 'a' is valid, 'b' is invalid
            // stopAtNonOption is false
            burstTokenMethod.invoke(parser, "ab", false);
            
            // Verify
            tokensField = PosixParser.class.getDeclaredField("tokens");
            tokensField.setAccessible(true);
            List<String> tokens = (List<String>) tokensField.get(parser);
            
            // Original behavior would add "-a" and then "ab" when hitting invalid 'b'
            // Mutated behavior would only add "-a"
            assertTrue("Should contain full token when invalid option encountered", 
                      tokens.contains("ab"));
        } catch (Exception e) {
            fail("Failed to set up or verify test: " + e.getMessage());
        }
    }


}
