package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
 
public class DefaultParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                    public void testIsShortOption_NotStartingWithDash() throws Exception {
                                                                                        Options options = new Options();
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        
                                                                                        // Get the private isShortOption method using reflection
                                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                        isShortOptionMethod.setAccessible(true);
                                                                                        
                                                                                        // Test various strings that should not be considered short options
                                                                                        assertFalse((Boolean) isShortOptionMethod.invoke(parser, "abc"));
                                                                                        assertFalse((Boolean) isShortOptionMethod.invoke(parser, "1"));
                                                                                        assertFalse((Boolean) isShortOptionMethod.invoke(parser, ""));
                                                                                    }

    @Test
                                                                                    public void testIsShortOption_SingleDash() throws Exception {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                        isShortOptionMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, "-");
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsShortOption_ValidShortOptionWithoutValue() {
                                                                                        // Create mock Options
                                                                                        Options options = mock(Options.class);
                                                                                        
                                                                                        // Create parser instance (assuming DefaultParser)
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        
                                                                                        // Use reflection to set private options field in parser
                                                                                        try {
                                                                                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                            optionsField.setAccessible(true);
                                                                                            optionsField.set(parser, options);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set options field via reflection");
                                                                                        }
                                                                                        
                                                                                        // Get the private isShortOption method via reflection
                                                                                        Method isShortOptionMethod;
                                                                                        try {
                                                                                            isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                            isShortOptionMethod.setAccessible(true);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to get isShortOption method via reflection");
                                                                                            return;
                                                                                        }
                                                                                        
                                                                                        // Test cases
                                                                                        try {
                                                                                            when(options.hasShortOption("f")).thenReturn(true);
                                                                                            assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-f"));
                                                                                            
                                                                                            when(options.hasShortOption("x")).thenReturn(true);
                                                                                            assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-x"));
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to invoke isShortOption method");
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testIsShortOption_ValidShortOptionWithValue() {
                                                                                        Options options = mock(Options.class);
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        
                                                                                        // Use reflection to set the private options field in parser
                                                                                        try {
                                                                                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                            optionsField.setAccessible(true);
                                                                                            optionsField.set(parser, options);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set options field via reflection");
                                                                                        }
                                                                                        
                                                                                        when(options.hasShortOption("f")).thenReturn(true);
                                                                                        
                                                                                        // Use reflection to access the private isShortOption method
                                                                                        try {
                                                                                            Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                            isShortOptionMethod.setAccessible(true);
                                                                                            
                                                                                            assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-f=value"));
                                                                                            assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-f=123"));
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to access isShortOption method via reflection");
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testIsShortOption_InvalidShortOptionWithoutValue() throws Exception {
                                                                                        Options options = mock(Options.class);
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        when(options.hasShortOption("z")).thenReturn(false);
                                                                                        
                                                                                        // Use reflection to access private method
                                                                                        Method method = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                        method.setAccessible(true);
                                                                                        boolean result = (boolean) method.invoke(parser, "-z");
                                                                                        
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsShortOption_InvalidShortOptionWithValue() throws Exception {
                                                                                        Options options = mock(Options.class);
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        when(options.hasShortOption("y")).thenReturn(false);
                                                                                        
                                                                                        // Use reflection to access private method
                                                                                        Method method = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                        method.setAccessible(true);
                                                                                        boolean result = (boolean) method.invoke(parser, "-y=test");
                                                                                        
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testIsShortOption_MultipleCharacterOption() {
                                                                                        // Create mock Options
                                                                                        Options options = mock(Options.class);
                                                                                        when(options.hasShortOption("abc")).thenReturn(true);
                                                                                        
                                                                                        // Create parser instance
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        
                                                                                        // Use reflection to set private options field in parser
                                                                                        try {
                                                                                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                            optionsField.setAccessible(true);
                                                                                            optionsField.set(parser, options);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set options field via reflection");
                                                                                        }
                                                                                        
                                                                                        // Use reflection to invoke private isShortOption method
                                                                                        try {
                                                                                            Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                            isShortOptionMethod.setAccessible(true);
                                                                                            
                                                                                            assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-abc"));
                                                                                            assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-abc=def"));
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to invoke isShortOption method via reflection");
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testIsShortOption_EmptyStringAfterDash() {
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        Options options = new Options();
                                                                                        // Add some dummy short options to test against
                                                                                        options.addOption("a", "aaa", false, "");
                                                                                        options.addOption("b", "bbb", false, "");
                                                                                        
                                                                                        // Use reflection to set the options field in parser since it's private
                                                                                        try {
                                                                                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                            optionsField.setAccessible(true);
                                                                                            optionsField.set(parser, options);
                                                                                            
                                                                                            // Get the private isShortOption method
                                                                                            Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                            isShortOptionMethod.setAccessible(true);
                                                                                            
                                                                                            // Invoke the method using reflection
                                                                                            assertFalse((Boolean) isShortOptionMethod.invoke(parser, "-="));
                                                                                            assertFalse((Boolean) isShortOptionMethod.invoke(parser, "-=value"));
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to access or invoke private method via reflection: " + e.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testIsShortOption_OnlyEqualsSign() throws Exception {
                                                                                        Options options = mock(Options.class);
                                                                                        DefaultParser parser = new DefaultParser();
                                                                                        when(options.hasShortOption("")).thenReturn(false);
                                                                                        
                                                                                        // Use reflection to access private method
                                                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                                                        isShortOptionMethod.setAccessible(true);
                                                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, "-=");
                                                                                        
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                           public void testIsShortOption_ShouldRejectNonDashPrefix() throws Exception {
                                               // Setup
                                               DefaultParser parser = new DefaultParser();
                                               Options mockOptions = mock(Options.class);
                                               
                                               // Use reflection to set protected field
                                               Field optionsField = DefaultParser.class.getDeclaredField("options");
                                               optionsField.setAccessible(true);
                                               optionsField.set(parser, mockOptions);
                                               
                                               // Test a token that starts with "/" (should be rejected)
                                               String invalidToken = "/option=value";
                                               
                                               // Use reflection to access private method
                                               Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                               isShortOptionMethod.setAccessible(true);
                                               
                                               // Execute and Verify
                                               boolean result = (boolean) isShortOptionMethod.invoke(parser, invalidToken);
                                               assertFalse("Method should reject tokens not starting with '-'", result);
                                               
                                               // Verify no interaction with options object occurred
                                               verify(mockOptions, never()).hasShortOption(anyString());
                                           }

    @Test
                                           public void testIsShortOption_ShouldAcceptDashPrefix() throws Exception {
                                               // Setup
                                               DefaultParser parser = new DefaultParser();
                                               Options mockOptions = mock(Options.class);
                                               when(mockOptions.hasShortOption("valid")).thenReturn(true);
                                               
                                               // Use reflection to set protected options field
                                               Field optionsField = DefaultParser.class.getDeclaredField("options");
                                               optionsField.setAccessible(true);
                                               optionsField.set(parser, mockOptions);
                                               
                                               // Test a valid short option token
                                               String validToken = "-valid=value";
                                               
                                               // Use reflection to access private isShortOption method
                                               Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                               isShortOptionMethod.setAccessible(true);
                                               
                                               // Execute and Verify
                                               boolean result = (boolean) isShortOptionMethod.invoke(parser, validToken);
                                               assertTrue("Method should accept tokens starting with '-'", result);
                                               
                                               // Verify correct interaction with options object
                                               verify(mockOptions).hasShortOption("valid");
                                           }

    @Test
                                      public void testIsShortOption_ShouldReturnTrueForValidShortOption() throws Exception {
                                          // Setup
                                          DefaultParser parser = new DefaultParser();
                                          Options mockOptions = mock(Options.class);
                                          
                                          // Use reflection to set protected options field
                                          Field optionsField = DefaultParser.class.getDeclaredField("options");
                                          optionsField.setAccessible(true);
                                          optionsField.set(parser, mockOptions);
                                          
                                          // Mock behavior - assume "-a" is a valid short option
                                          when(mockOptions.hasShortOption("a")).thenReturn(true);
                                          
                                          // Use reflection to access private isShortOption method
                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                          isShortOptionMethod.setAccessible(true);
                                          
                                          // Test with valid short option (-a)
                                          String token = "-a";
                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                          
                                          // Verify
                                          assertTrue("Should return true for valid short option", result);
                                          verify(mockOptions).hasShortOption("a");
                                      }

    @Test
                                      public void testIsShortOption_ShouldReturnFalseForSingleDash() throws Exception {
                                          // Setup
                                          DefaultParser parser = new DefaultParser();
                                          
                                          // Use reflection to set protected options field
                                          Field optionsField = DefaultParser.class.getDeclaredField("options");
                                          optionsField.setAccessible(true);
                                          Options mockOptions = mock(Options.class);
                                          optionsField.set(parser, mockOptions);
                                          
                                          // Test with single dash (-)
                                          String token = "-";
                                          
                                          // Use reflection to call private isShortOption method
                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                          isShortOptionMethod.setAccessible(true);
                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                          
                                          // Verify
                                          assertFalse("Should return false for single dash", result);
                                          verify(mockOptions, never()).hasShortOption(anyString());
                                      }

    @Test
                                      public void testIsShortOption_ShouldReturnFalseForInvalidOption() throws Exception {
                                          // Setup
                                          DefaultParser parser = new DefaultParser();
                                          Options mockOptions = mock(Options.class);
                                          
                                          // Use reflection to set protected options field
                                          Field optionsField = DefaultParser.class.getDeclaredField("options");
                                          optionsField.setAccessible(true);
                                          optionsField.set(parser, mockOptions);
                                          
                                          // Mock behavior - assume "b" is not a valid short option
                                          when(mockOptions.hasShortOption("b")).thenReturn(false);
                                          
                                          // Use reflection to access private isShortOption method
                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                          isShortOptionMethod.setAccessible(true);
                                          
                                          // Test with invalid short option (-b)
                                          String token = "-b";
                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                          
                                          // Verify
                                          assertFalse("Should return false for invalid short option", result);
                                          verify(mockOptions).hasShortOption("b");
                                      }

    @Test
                                      public void testIsShortOption_ShouldHandleOptionWithValue() throws Exception {
                                          // Setup
                                          DefaultParser parser = new DefaultParser();
                                          Options mockOptions = mock(Options.class);
                                          
                                          // Set protected options field using reflection
                                          Field optionsField = DefaultParser.class.getDeclaredField("options");
                                          optionsField.setAccessible(true);
                                          optionsField.set(parser, mockOptions);
                                          
                                          // Mock behavior - assume "c" is a valid short option
                                          when(mockOptions.hasShortOption("c")).thenReturn(true);
                                          
                                          // Test with option with value (-c=value)
                                          String token = "-c=value";
                                          
                                          // Invoke private method using reflection
                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                          isShortOptionMethod.setAccessible(true);
                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                          
                                          // Verify
                                          assertTrue("Should return true for valid short option with value", result);
                                          verify(mockOptions).hasShortOption("c");
                                      }

    @Test
                                 public void testIsShortOption_ShouldReturnFalseForInvalidTokens() throws Exception {
                                     // Setup
                                     DefaultParser parser = new DefaultParser();
                                     Options mockOptions = mock(Options.class);
                                     
                                     // Use reflection to set protected field
                                     Field optionsField = DefaultParser.class.getDeclaredField("options");
                                     optionsField.setAccessible(true);
                                     optionsField.set(parser, mockOptions);
                                     
                                     // Get private method via reflection
                                     Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                     isShortOptionMethod.setAccessible(true);
                                     
                                     // Test tokens that should be rejected
                                     // Case 1: Token doesn't start with "-"
                                     assertFalse((Boolean) isShortOptionMethod.invoke(parser, "a"));
                                     
                                     // Case 2: Token is just "-" (length 1)
                                     assertFalse((Boolean) isShortOptionMethod.invoke(parser, "-"));
                                     
                                     // Case 3: Token is empty
                                     assertFalse((Boolean) isShortOptionMethod.invoke(parser, ""));
                                     
                                     // Case 4: Token starts with "-" but has no option name
                                     assertFalse((Boolean) isShortOptionMethod.invoke(parser, "-="));
                                     
                                     // Verify that hasShortOption was never called for invalid tokens
                                     verify(mockOptions, never()).hasShortOption(anyString());
                                 }

    @Test
                                 public void testIsShortOption_ShouldProcessValidTokens() throws Exception {
                                     // Setup
                                     DefaultParser parser = new DefaultParser();
                                     Options mockOptions = mock(Options.class);
                                     when(mockOptions.hasShortOption("f")).thenReturn(true);
                                     when(mockOptions.hasShortOption("file")).thenReturn(false);
                                     
                                     // Use reflection to set protected options field
                                     Field optionsField = DefaultParser.class.getDeclaredField("options");
                                     optionsField.setAccessible(true);
                                     optionsField.set(parser, mockOptions);
                                     
                                     // Get private isShortOption method
                                     Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                     isShortOptionMethod.setAccessible(true);
                                     
                                     // Test valid tokens
                                     // Case 1: Simple short option
                                     assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-f"));
                                     
                                     // Case 2: Short option with value
                                     assertFalse((Boolean) isShortOptionMethod.invoke(parser, "-file=test.txt"));
                                     
                                     // Verify interactions
                                     verify(mockOptions).hasShortOption("f");
                                     verify(mockOptions).hasShortOption("file");
                                 }

    @Test
                            public void testIsShortOptionWithMultipleEqualsSigns() throws Exception {
                                // Setup
                                DefaultParser parser = new DefaultParser();
                                Options options = mock(Options.class);
                                
                                // Use reflection to set protected options field
                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                optionsField.setAccessible(true);
                                optionsField.set(parser, options);
                                
                                // Token with multiple equals signs
                                String token = "-a=b=c";
                                
                                // Original behavior would check for option "a=b"
                                // Mutated behavior would check for option "a"
                                when(options.hasShortOption("a")).thenReturn(true);
                                when(options.hasShortOption("a=b")).thenReturn(false);
                                
                                // Use reflection to call private isShortOption method
                                Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                isShortOptionMethod.setAccessible(true);
                                boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                
                                // Verify
                                assertTrue("Should recognize as short option when using first '='", result);
                                verify(options).hasShortOption("a");
                            }

    @Test
                       public void testIsShortOption_ShouldReturnTrueForExistingShortOption() throws Exception {
                           // Setup
                           DefaultParser parser = new DefaultParser();
                           Options options = mock(Options.class);
                           
                           // Use reflection to set protected options field
                           Field optionsField = DefaultParser.class.getDeclaredField("options");
                           optionsField.setAccessible(true);
                           optionsField.set(parser, options);
                           
                           // Mock the options to contain a short option "f"
                           when(options.hasShortOption("f")).thenReturn(true);
                           
                           // Test with valid short option "-f" that exists
                           String token = "-f";
                           
                           // Use reflection to access private isShortOption method
                           Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                           isShortOptionMethod.setAccessible(true);
                           boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                           
                           // Verify
                           assertTrue("Method should return true for existing short option", result);
                           verify(options).hasShortOption("f");
                       }

    @Test
                       public void testIsShortOption_ShouldReturnFalseForNonExistingShortOption() throws Exception {
                           // Setup
                           DefaultParser parser = new DefaultParser();
                           Options options = mock(Options.class);
                           
                           // Use reflection to set the protected options field
                           Field optionsField = DefaultParser.class.getDeclaredField("options");
                           optionsField.setAccessible(true);
                           optionsField.set(parser, options);
                           
                           // Mock the options to not contain a short option "x"
                           when(options.hasShortOption("x")).thenReturn(false);
                           
                           // Test with valid short option format "-x" that doesn't exist
                           String token = "-x";
                           
                           // Use reflection to call the private method
                           Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                           isShortOptionMethod.setAccessible(true);
                           boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                           
                           // Verify
                           assertFalse("Method should return false for non-existing short option", result);
                           verify(options).hasShortOption("x");
                       }

    @Test
              public void testIsShortOptionWithEmptyString() {
                  // This test will catch the mutant
                  // Original: "" -> !startsWith("-") is true, so returns false (correct)
                  // Mutant: "" -> length <=1 is true, so returns false (correct but for wrong reason)
                  // However, we need to verify the behavior difference
                  
                  DefaultParser parser = new DefaultParser();
                  
                  try {
                      // Get the private method using reflection
                      Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                      isShortOptionMethod.setAccessible(true);
                      
                      // Test empty string
                      boolean result = (boolean) isShortOptionMethod.invoke(parser, "");
                      assertFalse(result);
                  } catch (Exception e) {
                      fail("Failed to invoke private isShortOption method: " + e.getMessage());
                  }
              }

    @Test
              public void testIsShortOptionWithSingleDash() throws Exception {
                  DefaultParser parser = new DefaultParser();
                  Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                  isShortOptionMethod.setAccessible(true);
                  // Both versions should return false
                  assertFalse((Boolean) isShortOptionMethod.invoke(parser, "-"));
              }

    @Test
              public void testIsShortOptionWithValidOption() {
                  // Create mock Options
                  Options options = mock(Options.class);
                  // Setup mock to return true for option "a"
                  when(options.hasShortOption("a")).thenReturn(true);
                  
                  // Create parser instance
                  DefaultParser parser = new DefaultParser();
                  
                  // Use reflection to set the options field since it's private
                  try {
                      Field optionsField = DefaultParser.class.getDeclaredField("options");
                      optionsField.setAccessible(true);
                      optionsField.set(parser, options);
                  } catch (Exception e) {
                      fail("Failed to set options field via reflection");
                  }
                  
                  // Test valid short option using reflection
                  try {
                      Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                      isShortOptionMethod.setAccessible(true);
                      boolean result = (boolean) isShortOptionMethod.invoke(parser, "-a");
                      assertTrue(result);
                  } catch (Exception e) {
                      fail("Failed to invoke isShortOption method via reflection");
                  }
              }

    @Test
              public void testIsShortOptionWithValidOptionAndValue() {
                  // Create mock Options
                  Options options = mock(Options.class);
                  // Setup mock to return true for option "a"
                  when(options.hasShortOption("a")).thenReturn(true);
                  
                  // Create parser instance
                  DefaultParser parser = new DefaultParser();
                  
                  // Use reflection to set the options field since it's private
                  try {
                      Field optionsField = DefaultParser.class.getDeclaredField("options");
                      optionsField.setAccessible(true);
                      optionsField.set(parser, options);
                  } catch (Exception e) {
                      fail("Failed to set options field via reflection");
                  }
                  
                  // Use reflection to access and invoke the private isShortOption method
                  try {
                      Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                      isShortOptionMethod.setAccessible(true);
                      boolean result = (boolean) isShortOptionMethod.invoke(parser, "-a=value");
                      assertTrue(result);
                  } catch (Exception e) {
                      fail("Failed to invoke isShortOption method via reflection");
                  }
              }

    @Test
         public void testIsShortOption_ShouldDetectLengthMutation() throws Exception {
             // Setup
             DefaultParser parser = new DefaultParser();
             Options options = mock(Options.class);
             
             // Use reflection to set protected options field
             Field optionsField = DefaultParser.class.getDeclaredField("options");
             optionsField.setAccessible(true);
             optionsField.set(parser, options);
             
             // Get private isShortOption method
             Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
             isShortOptionMethod.setAccessible(true);
             
             // Mock the options to return true for any short option check
             when(options.hasShortOption(anyString())).thenReturn(true);
             
             // Test case that would pass original but fail mutated
             String validShortOption = "-ab"; // length > 1
             
             // Execute and verify
             assertTrue("Should accept valid short option with length > 1", 
                       (Boolean)isShortOptionMethod.invoke(parser, validShortOption));
             
             // Additional test case to ensure original behavior for length 1
             String invalidShortOption = "-a"; // length == 1
             assertFalse("Should reject option with length 1", 
                        (Boolean)isShortOptionMethod.invoke(parser, invalidShortOption));
         }

    @Test
    public void testIsShortOption_EqualsSignAtPositionZero() throws Exception {
        // Setup
        DefaultParser parser = new DefaultParser();
        Options mockOptions = mock(Options.class);
        
        // Use reflection to set the protected options field
        Field optionsField = DefaultParser.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        optionsField.set(parser, mockOptions);
        
        // Mock options.hasShortOption to return specific values
        when(mockOptions.hasShortOption("")).thenReturn(true);
        when(mockOptions.hasShortOption("=invalid")).thenReturn(false);
        
        String testToken = "-=invalid";
        
        // Use reflection to access the private isShortOption method
        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
        isShortOptionMethod.setAccessible(true);
        boolean result = (boolean) isShortOptionMethod.invoke(parser, testToken);
        
        // Assert original behavior (true)
        assertTrue(result);
        
        // Reset accessibility
        optionsField.setAccessible(false);
        isShortOptionMethod.setAccessible(false);
    }


}
