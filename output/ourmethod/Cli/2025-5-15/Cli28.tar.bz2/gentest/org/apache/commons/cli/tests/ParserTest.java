package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;
 
public class ParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                  public void testProcessProperties_NullProperties() throws Exception {
                                                                                                                                                                                                                                                                                                      Parser parser = new Parser() {
                                                                                                                                                                                                                                                                                                          // Implement abstract methods
                                                                                                                                                                                                                                                                                                          protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                                                                              return new String[0];
                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                      // Use reflection to access protected method
                                                                                                                                                                                                                                                                                                      Method method = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                      // Should not throw any exception
                                                                                                                                                                                                                                                                                                      method.invoke(parser, (Properties)null);
                                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                                  public void testProcessProperties_OptionAlreadyInCommandLine() throws Exception {
                                                                                                                                                                                                                                                                                                      Parser parser = new Parser() {
                                                                                                                                                                                                                                                                                                          protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                                                                              return new String[0];
                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                      CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                                                      when(cmd.hasOption("existingOption")).thenReturn(true);
                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                      // Set the protected cmd field using reflection
                                                                                                                                                                                                                                                                                                      Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                                                      cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                                                      cmdField.set(parser, cmd);
                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                      Properties properties = new Properties();
                                                                                                                                                                                                                                                                                                      properties.setProperty("existingOption", "value");
                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                      // Call the protected processProperties method using reflection
                                                                                                                                                                                                                                                                                                      Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                                                                      processProperties.setAccessible(true);
                                                                                                                                                                                                                                                                                                      processProperties.invoke(parser, properties);
                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                      // Verify the option wasn't added by checking hasOption remains true
                                                                                                                                                                                                                                                                                                      verify(cmd, never()).hasOption(anyString());
                                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                              public void testProcessProperties_EmptyProperties() throws Exception {
                                                                                                                                                                                                                                                                                                  Parser parser = new Parser() {
                                                                                                                                                                                                                                                                                                      protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                                                                          return new String[0];
                                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Set required options (if any) using reflection
                                                                                                                                                                                                                                                                                                  Options options = new Options();
                                                                                                                                                                                                                                                                                                  Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                                                  optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  optionsField.set(parser, options);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Get command line object by parsing empty arguments
                                                                                                                                                                                                                                                                                                  CommandLine cmd = parser.parse(options, new String[0]);
                                                                                                                                                                                                                                                                                                  Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                                                  cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  cmdField.set(parser, cmd);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  Properties properties = new Properties();
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Use reflection to call protected method
                                                                                                                                                                                                                                                                                                  Method method = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                                                                  method.setAccessible(true);
                                                                                                                                                                                                                                                                                                  method.invoke(parser, properties);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // No assertions needed as method has void return and we're testing it doesn't throw
                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                              public void testProcessProperties_OptionWithArgAndNoValues() throws Exception {
                                                                                                                                                                                                                                                                                                  Parser parser = new Parser() {
                                                                                                                                                                                                                                                                                                      protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                                                                          return new String[0];
                                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                                                  when(cmd.hasOption("newOption")).thenReturn(false);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Set cmd field using reflection
                                                                                                                                                                                                                                                                                                  Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                                                  cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  cmdField.set(parser, cmd);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  Options options = mock(Options.class);
                                                                                                                                                                                                                                                                                                  Option opt = mock(Option.class);
                                                                                                                                                                                                                                                                                                  when(options.getOption("newOption")).thenReturn(opt);
                                                                                                                                                                                                                                                                                                  when(opt.hasArg()).thenReturn(true);
                                                                                                                                                                                                                                                                                                  when(opt.getValues()).thenReturn(null);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Set options field using reflection
                                                                                                                                                                                                                                                                                                  Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                                                  optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  optionsField.set(parser, options);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  Properties properties = new Properties();
                                                                                                                                                                                                                                                                                                  properties.setProperty("newOption", "argValue");
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Call processProperties using reflection
                                                                                                                                                                                                                                                                                                  Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                                                                  processProperties.setAccessible(true);
                                                                                                                                                                                                                                                                                                  processProperties.invoke(parser, properties);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Verify the option was processed by checking if hasOption now returns true
                                                                                                                                                                                                                                                                                                  verify(cmd).hasOption("newOption");
                                                                                                                                                                                                                                                                                                  // Alternatively, we could verify that the property was processed by checking other side effects
                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                              public void testProcessProperties_OptionWithArgAndExistingValues() throws Exception {
                                                                                                                                                                                                                                                                                                  Parser parser = new Parser() {
                                                                                                                                                                                                                                                                                                      protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                                                                          return new String[0];
                                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                                                  // Set cmd field using reflection
                                                                                                                                                                                                                                                                                                  Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                                                  cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  cmdField.set(parser, cmd);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  when(cmd.hasOption("newOption")).thenReturn(false);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  Options options = mock(Options.class);
                                                                                                                                                                                                                                                                                                  Option opt = mock(Option.class);
                                                                                                                                                                                                                                                                                                  when(options.getOption("newOption")).thenReturn(opt);
                                                                                                                                                                                                                                                                                                  when(opt.hasArg()).thenReturn(true);
                                                                                                                                                                                                                                                                                                  when(opt.getValues()).thenReturn(new String[]{"existingValue"});
                                                                                                                                                                                                                                                                                                  // Set options field using reflection
                                                                                                                                                                                                                                                                                                  Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                                                  optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  optionsField.set(parser, options);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  Properties properties = new Properties();
                                                                                                                                                                                                                                                                                                  properties.setProperty("newOption", "argValue");
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Call processProperties through reflection
                                                                                                                                                                                                                                                                                                  Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                                                                  processProperties.setAccessible(true);
                                                                                                                                                                                                                                                                                                  processProperties.invoke(parser, properties);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Verify through public interfaces
                                                                                                                                                                                                                                                                                                  verify(cmd).hasOption("newOption");
                                                                                                                                                                                                                                                                                                  // We can't verify the internal addOption call, but we can verify the end result
                                                                                                                                                                                                                                                                                                  // through the public parse method if needed
                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                              public void testProcessProperties_OptionWithoutArgWithValidValue() throws Exception {
                                                                                                                                                                                                                                                                                                  Parser parser = new Parser() {
                                                                                                                                                                                                                                                                                                      protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                                                                          return new String[0];
                                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  Options options = new Options();
                                                                                                                                                                                                                                                                                                  Option opt = new Option("flagOption", "flag option");
                                                                                                                                                                                                                                                                                                  opt.setRequired(false);
                                                                                                                                                                                                                                                                                                  options.addOption(opt);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Set protected options field using reflection
                                                                                                                                                                                                                                                                                                  Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                                                  optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  optionsField.set(parser, options);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  Properties properties = new Properties();
                                                                                                                                                                                                                                                                                                  properties.setProperty("flagOption", "yes"); // Also test with "true" and "1"
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Call protected processProperties method using reflection
                                                                                                                                                                                                                                                                                                  Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                                                                  processProperties.setAccessible(true);
                                                                                                                                                                                                                                                                                                  processProperties.invoke(parser, properties);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Verify through public parse method
                                                                                                                                                                                                                                                                                                  CommandLine cmd = parser.parse(options, new String[0]);
                                                                                                                                                                                                                                                                                                  assertTrue("Option should be set", cmd.hasOption("flagOption"));
                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                              public void testProcessProperties_OptionWithoutArgWithInvalidValue() throws Exception {
                                                                                                                                                                                                                                                                                                  Parser parser = new Parser() {
                                                                                                                                                                                                                                                                                                      protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                                                                          return new String[0];
                                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                                                  // Set protected cmd field using reflection
                                                                                                                                                                                                                                                                                                  Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                                                  cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  cmdField.set(parser, cmd);
                                                                                                                                                                                                                                                                                                  when(cmd.hasOption("flagOption")).thenReturn(false);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  Options options = mock(Options.class);
                                                                                                                                                                                                                                                                                                  Option opt = mock(Option.class);
                                                                                                                                                                                                                                                                                                  when(options.getOption("flagOption")).thenReturn(opt);
                                                                                                                                                                                                                                                                                                  when(opt.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                                                                                  // Use reflection to call protected setOptions method
                                                                                                                                                                                                                                                                                                  Method setOptions = Parser.class.getDeclaredMethod("setOptions", Options.class);
                                                                                                                                                                                                                                                                                                  setOptions.setAccessible(true);
                                                                                                                                                                                                                                                                                                  setOptions.invoke(parser, options);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  Properties properties = new Properties();
                                                                                                                                                                                                                                                                                                  properties.setProperty("flagOption", "no"); // Invalid value
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Call protected method using reflection
                                                                                                                                                                                                                                                                                                  Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                                                                  processProperties.setAccessible(true);
                                                                                                                                                                                                                                                                                                  processProperties.invoke(parser, properties);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Verify through mock - check that hasOption remains false
                                                                                                                                                                                                                                                                                                  verify(cmd, never()).hasOption("flagOption");
                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                              public void testProcessProperties_MultipleProperties() throws Exception {
                                                                                                                                                                                                                                                                                                  Parser parser = new Parser() {
                                                                                                                                                                                                                                                                                                      protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                                                                          return new String[0];
                                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                                                  // Set protected cmd field using reflection
                                                                                                                                                                                                                                                                                                  Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                                                  cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                                                  cmdField.set(parser, cmd);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  Options options = mock(Options.class);
                                                                                                                                                                                                                                                                                                  Option opt1 = mock(Option.class);
                                                                                                                                                                                                                                                                                                  Option opt2 = mock(Option.class);
                                                                                                                                                                                                                                                                                                  when(options.getOption("option1")).thenReturn(opt1);
                                                                                                                                                                                                                                                                                                  when(options.getOption("option2")).thenReturn(opt2);
                                                                                                                                                                                                                                                                                                  when(opt1.hasArg()).thenReturn(true);
                                                                                                                                                                                                                                                                                                  when(opt2.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                                                                                  when(opt1.getValues()).thenReturn(null);
                                                                                                                                                                                                                                                                                                  when(opt2.getValues()).thenReturn(null);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Use reflection to call protected setOptions method
                                                                                                                                                                                                                                                                                                  Method setOptions = Parser.class.getDeclaredMethod("setOptions", Options.class);
                                                                                                                                                                                                                                                                                                  setOptions.setAccessible(true);
                                                                                                                                                                                                                                                                                                  setOptions.invoke(parser, options);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  Properties properties = new Properties();
                                                                                                                                                                                                                                                                                                  properties.setProperty("option1", "value1");
                                                                                                                                                                                                                                                                                                  properties.setProperty("option2", "true");
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Call processProperties using reflection
                                                                                                                                                                                                                                                                                                  Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                                                                  processProperties.setAccessible(true);
                                                                                                                                                                                                                                                                                                  processProperties.invoke(parser, properties);
                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                  // Verify using public methods or alternative verification approach
                                                                                                                                                                                                                                                                                                  verify(cmd, atLeastOnce()).hasOption(anyString());
                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                  public void testProcessProperties_OptionWithArgThrowsException() throws Exception {
                                                                                                                                                                                                                                                                                      Parser parser = new Parser() {
                                                                                                                                                                                                                                                                                          protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                                                              return new String[0];
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                                      // Set protected cmd field using reflection
                                                                                                                                                                                                                                                                                      Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                                      cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                                      cmdField.set(parser, cmd);
                                                                                                                                                                                                                                                                                      when(cmd.hasOption("problemOption")).thenReturn(false);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Options options = mock(Options.class);
                                                                                                                                                                                                                                                                                      Option opt = mock(Option.class);
                                                                                                                                                                                                                                                                                      when(options.getOption("problemOption")).thenReturn(opt);
                                                                                                                                                                                                                                                                                      when(opt.hasArg()).thenReturn(true);
                                                                                                                                                                                                                                                                                      when(opt.getValues()).thenReturn(null);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Instead of trying to mock the non-public method, we'll make getValues() throw the exception
                                                                                                                                                                                                                                                                                      when(opt.getValues()).thenThrow(new RuntimeException("Test exception"));
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Set private options field using reflection
                                                                                                                                                                                                                                                                                      Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                                                                                      optionsField.setAccessible(true);
                                                                                                                                                                                                                                                                                      optionsField.set(parser, options);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      Properties properties = new Properties();
                                                                                                                                                                                                                                                                                      properties.setProperty("problemOption", "badValue");
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Call protected method using reflection
                                                                                                                                                                                                                                                                                      Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                                                      processPropertiesMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                                                                                          processPropertiesMethod.invoke(parser, properties);
                                                                                                                                                                                                                                                                                          fail("Expected exception to be thrown");
                                                                                                                                                                                                                                                                                      } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                                                          assertTrue(e.getCause() instanceof RuntimeException);
                                                                                                                                                                                                                                                                                          assertEquals("Test exception", e.getCause().getMessage());
                                                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Verify the option was processed by checking if the command line was updated
                                                                                                                                                                                                                                                                                      verify(cmd, times(1)).hasOption("problemOption");
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                     public void testProcessPropertiesContinueVsBreakMutant() {
                                                                                                                                                                                                                                                                         // Setup test data - multiple properties including one with non-true value
                                                                                                                                                                                                                                                                         Properties props = new Properties();
                                                                                                                                                                                                                                                                         props.setProperty("opt1", "true");  // should be added
                                                                                                                                                                                                                                                                         props.setProperty("opt2", "no");    // should be skipped (but not break in original)
                                                                                                                                                                                                                                                                         props.setProperty("opt3", "yes");   // should be added in original, skipped in mutant
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Mock dependencies
                                                                                                                                                                                                                                                                         CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                         Options options = mock(Options.class);
                                                                                                                                                                                                                                                                         Option opt1 = mock(Option.class);
                                                                                                                                                                                                                                                                         Option opt2 = mock(Option.class);
                                                                                                                                                                                                                                                                         Option opt3 = mock(Option.class);
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Setup mock behaviors
                                                                                                                                                                                                                                                                         when(opt1.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                                                         when(opt2.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                                                         when(opt3.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                                                         when(options.getOption("opt1")).thenReturn(opt1);
                                                                                                                                                                                                                                                                         when(options.getOption("opt2")).thenReturn(opt2);
                                                                                                                                                                                                                                                                         when(options.getOption("opt3")).thenReturn(opt3);
                                                                                                                                                                                                                                                                         when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Create test instance
                                                                                                                                                                                                                                                                         Parser parser = new Parser() {
                                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                                             protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                                                 return new String[0];
                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                         // Use reflection to set protected fields and call protected methods
                                                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                                                             // Set options
                                                                                                                                                                                                                                                                             Method setOptionsMethod = Parser.class.getDeclaredMethod("setOptions", Options.class);
                                                                                                                                                                                                                                                                             setOptionsMethod.setAccessible(true);
                                                                                                                                                                                                                                                                             setOptionsMethod.invoke(parser, options);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Set cmd field
                                                                                                                                                                                                                                                                             Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                             cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                             cmdField.set(parser, cmd);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Call processProperties
                                                                                                                                                                                                                                                                             Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                                             processPropertiesMethod.setAccessible(true);
                                                                                                                                                                                                                                                                             processPropertiesMethod.invoke(parser, props);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Verify behavior by checking which options were set through hasOption
                                                                                                                                                                                                                                                                             verify(cmd, times(1)).hasOption("opt1");  // opt1 should always be added
                                                                                                                                                                                                                                                                             verify(cmd, times(1)).hasOption("opt3");  // opt3 should be added in original
                                                                                                                                                                                                                                                                             verify(cmd, never()).hasOption("opt2");   // opt2 should never be added
                                                                                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                                                                                             fail("Failed to use reflection: " + e.getMessage());
                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                            public void testProcessPropertiesWithMultipleBooleanOptions() {
                                                                                                                                                                                                                                                                // Setup test data
                                                                                                                                                                                                                                                                Properties properties = new Properties();
                                                                                                                                                                                                                                                                properties.setProperty("valid1", "true");  // valid boolean
                                                                                                                                                                                                                                                                properties.setProperty("invalid1", "no");  // invalid boolean
                                                                                                                                                                                                                                                                properties.setProperty("valid2", "yes");   // valid boolean
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Mock dependencies
                                                                                                                                                                                                                                                                CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                                                                Options options = mock(Options.class);
                                                                                                                                                                                                                                                                Option validOpt1 = mock(Option.class);
                                                                                                                                                                                                                                                                Option validOpt2 = mock(Option.class);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Setup mock behavior
                                                                                                                                                                                                                                                                when(validOpt1.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                                                when(validOpt2.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                                                when(options.getOption("valid1")).thenReturn(validOpt1);
                                                                                                                                                                                                                                                                when(options.getOption("valid2")).thenReturn(validOpt2);
                                                                                                                                                                                                                                                                when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create test instance and set up state
                                                                                                                                                                                                                                                                Parser parser = new Parser() {
                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    protected Options getOptions() {
                                                                                                                                                                                                                                                                        return options;
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                                        return new String[0];
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Inject cmd using reflection
                                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                                    Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                                    cmdField.setAccessible(true);
                                                                                                                                                                                                                                                                    cmdField.set(parser, cmd);
                                                                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                                                                    fail("Failed to set cmd field");
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Call processProperties using reflection
                                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                                    Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                                    processProperties.setAccessible(true);
                                                                                                                                                                                                                                                                    processProperties.invoke(parser, properties);
                                                                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                                                                    fail("Failed to invoke processProperties");
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify behavior - should process both valid options despite invalid one in middle
                                                                                                                                                                                                                                                                // Verify that hasOption was called for each property key
                                                                                                                                                                                                                                                                verify(cmd).hasOption("valid1");
                                                                                                                                                                                                                                                                verify(cmd).hasOption("invalid1");
                                                                                                                                                                                                                                                                verify(cmd).hasOption("valid2");
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                           public void testProcessProperties_ShouldNotAddOptionWhenValueNotYesTrueOr() {
                                                                                                                                                                                                                                               // Setup test data
                                                                                                                                                                                                                                               Properties props = new Properties();
                                                                                                                                                                                                                                               props.setProperty("testOption", "no"); // Value that should skip adding
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Mock dependencies
                                                                                                                                                                                                                                               Options options = mock(Options.class);
                                                                                                                                                                                                                                               Option opt = mock(Option.class);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Create test instance
                                                                                                                                                                                                                                               Parser parser = new Parser() {
                                                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                                                   protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                       return new String[0];
                                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                                               };
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Create empty CommandLine through parser
                                                                                                                                                                                                                                               CommandLine cmd;
                                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                                   cmd = parser.parse(options, new String[0]);
                                                                                                                                                                                                                                               } catch (ParseException e) {
                                                                                                                                                                                                                                                   fail("Unexpected ParseException");
                                                                                                                                                                                                                                                   return;
                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                               CommandLine spyCmd = spy(cmd);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Setup mock behavior
                                                                                                                                                                                                                                               when(opt.hasArg()).thenReturn(false); // Option doesn't take argument
                                                                                                                                                                                                                                               when(options.getOption("testOption")).thenReturn(opt);
                                                                                                                                                                                                                                               when(spyCmd.hasOption("testOption")).thenReturn(false); // Option not already in cmd
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Use reflection to set protected fields and call protected methods
                                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                                   // Set options
                                                                                                                                                                                                                                                   Method setOptionsMethod = Parser.class.getDeclaredMethod("setOptions", Options.class);
                                                                                                                                                                                                                                                   setOptionsMethod.setAccessible(true);
                                                                                                                                                                                                                                                   setOptionsMethod.invoke(parser, options);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Set cmd field
                                                                                                                                                                                                                                                   Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                                   cmdField.setAccessible(true);
                                                                                                                                                                                                                                                   cmdField.set(parser, spyCmd);
                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                   // Call processProperties
                                                                                                                                                                                                                                                   Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                                   processPropertiesMethod.setAccessible(true);
                                                                                                                                                                                                                                                   processPropertiesMethod.invoke(parser, props);
                                                                                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                                                                                   fail("Failed to access protected methods/fields via reflection");
                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Verify behavior - option should NOT be added
                                                                                                                                                                                                                                               // Verify through checking the options in the command line
                                                                                                                                                                                                                                               assertFalse(spyCmd.hasOption("testOption"));
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                      public void testProcessProperties_ShouldNotAddBooleanOptionWithInvalidValue() throws Exception {
                                                                                                                                                                                                                                          // Setup test data
                                                                                                                                                                                                                                          Properties properties = new Properties();
                                                                                                                                                                                                                                          properties.setProperty("testOpt", "no"); // Invalid value for boolean option
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Create a boolean option (hasArg = false)
                                                                                                                                                                                                                                          Option opt = new Option("testOpt", false, "test option");
                                                                                                                                                                                                                                          Options options = new Options();
                                                                                                                                                                                                                                          options.addOption(opt);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Mock CommandLine
                                                                                                                                                                                                                                          CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                                                          when(cmd.hasOption("testOpt")).thenReturn(false);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Create parser instance
                                                                                                                                                                                                                                          Parser parser = new Parser() {
                                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                                              protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                                  return new String[0];
                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                          };
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Use reflection to set options
                                                                                                                                                                                                                                          Method setOptionsMethod = Parser.class.getDeclaredMethod("setOptions", Options.class);
                                                                                                                                                                                                                                          setOptionsMethod.setAccessible(true);
                                                                                                                                                                                                                                          setOptionsMethod.invoke(parser, options);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Use reflection to set protected cmd field
                                                                                                                                                                                                                                          Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                          cmdField.setAccessible(true);
                                                                                                                                                                                                                                          cmdField.set(parser, cmd);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Use reflection to call processProperties
                                                                                                                                                                                                                                          Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                          processPropertiesMethod.setAccessible(true);
                                                                                                                                                                                                                                          processPropertiesMethod.invoke(parser, properties);
                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                          // Verify the option was NOT added by checking that hasOption still returns false
                                                                                                                                                                                                                                          verify(cmd, never()).hasOption("testOpt");
                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                 public void testProcessProperties_ShouldAddOptionToCommandLine() {
                                                                                                                                                                                                                                     // Setup test data
                                                                                                                                                                                                                                     Properties properties = new Properties();
                                                                                                                                                                                                                                     properties.setProperty("testOption", "true"); // This should trigger option addition
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                                                                     CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                                                                                                                                     Options mockOptions = mock(Options.class);
                                                                                                                                                                                                                                     Option mockOption = mock(Option.class);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Create parser instance and set mocks
                                                                                                                                                                                                                                     Parser parser = new Parser() {
                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                         protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                             return new String[0];
                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Use reflection to set protected fields since we don't have direct access
                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                         Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                         cmdField.setAccessible(true);
                                                                                                                                                                                                                                         cmdField.set(parser, mockCmd);
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                                         optionsField.setAccessible(true);
                                                                                                                                                                                                                                         optionsField.set(parser, mockOptions);
                                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                                         fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Configure mock behavior
                                                                                                                                                                                                                                     when(mockOptions.getOption("testOption")).thenReturn(mockOption);
                                                                                                                                                                                                                                     when(mockCmd.hasOption("testOption")).thenReturn(false);
                                                                                                                                                                                                                                     when(mockOption.hasArg()).thenReturn(false);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Use reflection to call the protected method
                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                         Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                         processProperties.setAccessible(true);
                                                                                                                                                                                                                                         processProperties.invoke(parser, properties);
                                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                                         fail("Failed to invoke processProperties method: " + e.getMessage());
                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Verify the option was processed by checking if hasOption returns true
                                                                                                                                                                                                                                     verify(mockCmd).hasOption("testOption");
                                                                                                                                                                                                                                     // Verify the option was added by checking if getOptionValue was called
                                                                                                                                                                                                                                     verify(mockCmd).getOptionValue("testOption");
                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                        public void testProcessPropertiesAddsCorrectOption() {
                                                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                                                            Properties properties = new Properties();
                                                                                                                                                                                                                            properties.setProperty("testOption", "testValue");
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Create mock objects
                                                                                                                                                                                                                            CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                                                                                                                            Options mockOptions = mock(Options.class);
                                                                                                                                                                                                                            Option mockOption = mock(Option.class);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Create parser instance and set mocks
                                                                                                                                                                                                                            Parser parser = new Parser() {
                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                                    return new String[0];
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                            };
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to set protected fields since we can't access them directly
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                                cmdField.setAccessible(true);
                                                                                                                                                                                                                                cmdField.set(parser, mockCmd);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                                                optionsField.setAccessible(true);
                                                                                                                                                                                                                                optionsField.set(parser, mockOptions);
                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Configure mock behavior
                                                                                                                                                                                                                            when(mockOptions.getOption("testOption")).thenReturn(mockOption);
                                                                                                                                                                                                                            when(mockOption.hasArg()).thenReturn(true);
                                                                                                                                                                                                                            when(mockOption.getValues()).thenReturn(null);
                                                                                                                                                                                                                            when(mockCmd.hasOption("testOption")).thenReturn(false);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Execute test using reflection to call protected method
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                                processProperties.setAccessible(true);
                                                                                                                                                                                                                                processProperties.invoke(parser, properties);
                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                fail("Failed to invoke processProperties: " + e.getMessage());
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Verify the option was processed by checking if the command line was updated
                                                                                                                                                                                                                            // We can verify that getOption was called on the mockOptions
                                                                                                                                                                                                                            verify(mockOptions).getOption("testOption");
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Verify the option was added to command line indirectly
                                                                                                                                                                                                                            verify(mockCmd).hasOption("testOption");
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                           public void testProcessProperties_AddsOptionToCommandLine() {
                                                                                                                                                                                                               // Setup test data
                                                                                                                                                                                                               Properties properties = new Properties();
                                                                                                                                                                                                               properties.setProperty("testOpt", "value");
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Mock dependencies
                                                                                                                                                                                                               CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                               Options options = mock(Options.class);
                                                                                                                                                                                                               Option opt = mock(Option.class);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Setup behavior
                                                                                                                                                                                                               when(cmd.hasOption("testOpt")).thenReturn(false);
                                                                                                                                                                                                               when(options.getOption("testOpt")).thenReturn(opt);
                                                                                                                                                                                                               when(opt.hasArg()).thenReturn(true);
                                                                                                                                                                                                               when(opt.getValues()).thenReturn(null);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create test instance and set up
                                                                                                                                                                                                               Parser parser = new Parser() {
                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                   protected Options getOptions() {
                                                                                                                                                                                                                       return options;
                                                                                                                                                                                                                   }
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                   protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                                       return new String[0];
                                                                                                                                                                                                                   }
                                                                                                                                                                                                               };
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Inject mock cmd using reflection
                                                                                                                                                                                                               try {
                                                                                                                                                                                                                   Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                                   cmdField.setAccessible(true);
                                                                                                                                                                                                                   cmdField.set(parser, cmd);
                                                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                                                   fail("Failed to set cmd field");
                                                                                                                                                                                                               }
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Execute using reflection to call protected method
                                                                                                                                                                                                               try {
                                                                                                                                                                                                                   Method method = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                                                   method.invoke(parser, properties);
                                                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                                                   fail("Failed to invoke processProperties method");
                                                                                                                                                                                                               }
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Verify indirectly by checking if option was processed
                                                                                                                                                                                                               verify(cmd, times(1)).hasOption("testOpt");
                                                                                                                                                                                                               // We can't verify addOption directly, but we can verify the expected behavior
                                                                                                                                                                                                               // by checking if the option value was processed in some way
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                  public void testProcessPropertiesWithNonBooleanValueShouldContinueNotThrow() throws Exception {
                                                                                                                                                                                                      // Setup test data
                                                                                                                                                                                                      Properties properties = new Properties();
                                                                                                                                                                                                      properties.setProperty("flag1", "false");  // Will trigger the else-if branch
                                                                                                                                                                                                      properties.setProperty("flag2", "true");   // Should still be processed
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Mock dependencies
                                                                                                                                                                                                      CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                                      Options options = mock(Options.class);
                                                                                                                                                                                                      Option opt1 = mock(Option.class);
                                                                                                                                                                                                      Option opt2 = mock(Option.class);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Configure mocks
                                                                                                                                                                                                      when(opt1.hasArg()).thenReturn(false);
                                                                                                                                                                                                      when(opt2.hasArg()).thenReturn(false);
                                                                                                                                                                                                      when(options.getOption("flag1")).thenReturn(opt1);
                                                                                                                                                                                                      when(options.getOption("flag2")).thenReturn(opt2);
                                                                                                                                                                                                      when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Create test instance and set up using reflection
                                                                                                                                                                                                      Parser parser = new Parser() {
                                                                                                                                                                                                          @Override
                                                                                                                                                                                                          protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                              return new String[0];
                                                                                                                                                                                                          }
                                                                                                                                                                                                      };
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Set protected fields using reflection
                                                                                                                                                                                                      Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                                      optionsField.setAccessible(true);
                                                                                                                                                                                                      optionsField.set(parser, options);
                                                                                                                                                                                                      
                                                                                                                                                                                                      Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                      cmdField.setAccessible(true);
                                                                                                                                                                                                      cmdField.set(parser, cmd);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Execute test - should not throw exception
                                                                                                                                                                                                      Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                      processProperties.setAccessible(true);
                                                                                                                                                                                                      processProperties.invoke(parser, properties);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Verify behavior through mock interactions
                                                                                                                                                                                                      // Verify that flag2 was processed (true value) by checking hasOption was called
                                                                                                                                                                                                      verify(cmd).hasOption("flag2");
                                                                                                                                                                                                      // Verify that flag1 was skipped (false value) by checking hasOption was not called
                                                                                                                                                                                                      verify(cmd, never()).hasOption("flag1");
                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                         public void testProcessPropertiesWithNullOption() {
                                                                                                                                                                                             // Setup test data
                                                                                                                                                                                             Properties properties = new Properties();
                                                                                                                                                                                             properties.setProperty("testOption", "value");
                                                                                                                                                                                             
                                                                                                                                                                                             // Mock dependencies
                                                                                                                                                                                             Options mockedOptions = mock(Options.class);
                                                                                                                                                                                             CommandLine mockedCmd = mock(CommandLine.class);
                                                                                                                                                                                             Parser parser = new Parser() {
                                                                                                                                                                                                 @Override
                                                                                                                                                                                                 protected Options getOptions() {
                                                                                                                                                                                                     return mockedOptions;
                                                                                                                                                                                                 }
                                                                                                                                                                                                 
                                                                                                                                                                                                 @Override
                                                                                                                                                                                                 protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                     return new String[0];
                                                                                                                                                                                                 }
                                                                                                                                                                                             };
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to set protected cmd field
                                                                                                                                                                                             try {
                                                                                                                                                                                                 Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                                 cmdField.setAccessible(true);
                                                                                                                                                                                                 cmdField.set(parser, mockedCmd);
                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                 fail("Failed to set cmd field");
                                                                                                                                                                                             }
                                                                                                                                                                                             
                                                                                                                                                                                             // Stub behavior
                                                                                                                                                                                             when(mockedOptions.getOption("testOption")).thenReturn(null);
                                                                                                                                                                                             when(mockedCmd.hasOption("testOption")).thenReturn(false);
                                                                                                                                                                                             
                                                                                                                                                                                             // Execute using reflection to call protected method
                                                                                                                                                                                             try {
                                                                                                                                                                                                 Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                                 processProperties.setAccessible(true);
                                                                                                                                                                                                 processProperties.invoke(parser, properties);
                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                 fail("Failed to invoke processProperties method");
                                                                                                                                                                                             }
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify indirectly by checking that hasOption still returns false (since no option was added)
                                                                                                                                                                                             verify(mockedCmd).hasOption("testOption");
                                                                                                                                                                                             assertFalse(mockedCmd.hasOption("testOption"));
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                    public void testProcessPropertiesContinueMutation() throws Exception {
                                                                                                                                                                                        // Setup test data
                                                                                                                                                                                        Properties properties = new Properties();
                                                                                                                                                                                        properties.setProperty("testOption", "false"); // Value that should trigger continue
                                                                                                                                                                                        
                                                                                                                                                                                        // Mock dependencies
                                                                                                                                                                                        CommandLine cmd = mock(CommandLine.class);
                                                                                                                                                                                        Options options = mock(Options.class);
                                                                                                                                                                                        Option opt = mock(Option.class);
                                                                                                                                                                                        
                                                                                                                                                                                        // Setup mock behavior
                                                                                                                                                                                        when(cmd.hasOption("testOption")).thenReturn(false);
                                                                                                                                                                                        when(options.getOption("testOption")).thenReturn(opt);
                                                                                                                                                                                        when(opt.hasArg()).thenReturn(false);
                                                                                                                                                                                        
                                                                                                                                                                                        // Create parser instance and set required fields using reflection
                                                                                                                                                                                        Parser parser = new Parser() {
                                                                                                                                                                                            @Override
                                                                                                                                                                                            protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                                                                return new String[0];
                                                                                                                                                                                            }
                                                                                                                                                                                        };
                                                                                                                                                                                        
                                                                                                                                                                                        // Set protected fields using reflection
                                                                                                                                                                                        Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                                                                        optionsField.setAccessible(true);
                                                                                                                                                                                        optionsField.set(parser, options);
                                                                                                                                                                                        
                                                                                                                                                                                        Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                                                                        cmdField.setAccessible(true);
                                                                                                                                                                                        cmdField.set(parser, cmd);
                                                                                                                                                                                        
                                                                                                                                                                                        // Get protected method using reflection
                                                                                                                                                                                        Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                                                        processProperties.setAccessible(true);
                                                                                                                                                                                        
                                                                                                                                                                                        // Run multiple times to catch random behavior
                                                                                                                                                                                        for (int i = 0; i < 100; i++) {
                                                                                                                                                                                            processProperties.invoke(parser, properties);
                                                                                                                                                                                        }
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify through public methods or other means
                                                                                                                                                                                        // Since we can't verify addOption directly, we can verify that hasOption still returns false
                                                                                                                                                                                        verify(cmd, times(100)).hasOption("testOption");
                                                                                                                                                                                        verify(cmd, never()).hasOption(anyString()); // Only testOption should be checked
                                                                                                                                                                                    }

    @Test
                                                                                                                                                   public void testProcessProperties_ShouldAddOptionOnlyOnce() throws Exception {
                                                                                                                                                       // Setup test data
                                                                                                                                                       Properties properties = new Properties();
                                                                                                                                                       properties.setProperty("testOption", "testValue");
                                                                                                                                                       
                                                                                                                                                       // Mock dependencies
                                                                                                                                                       org.apache.commons.cli.CommandLine mockCmd = mock(org.apache.commons.cli.CommandLine.class);
                                                                                                                                                       org.apache.commons.cli.Options mockOptions = mock(org.apache.commons.cli.Options.class);
                                                                                                                                                       org.apache.commons.cli.Option mockOption = mock(org.apache.commons.cli.Option.class);
                                                                                                                                                       
                                                                                                                                                       // Setup mock behavior
                                                                                                                                                       when(mockOptions.getOption("testOption")).thenReturn(mockOption);
                                                                                                                                                       when(mockOption.hasArg()).thenReturn(true);
                                                                                                                                                       when(mockOption.getValues()).thenReturn(null);
                                                                                                                                                       when(mockCmd.hasOption("testOption")).thenReturn(false);
                                                                                                                                                       
                                                                                                                                                       // Create test instance using anonymous subclass to access protected members
                                                                                                                                                       org.apache.commons.cli.Parser parser = new org.apache.commons.cli.Parser() {
                                                                                                                                                           @Override
                                                                                                                                                           protected String[] flatten(org.apache.commons.cli.Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                               return new String[0];
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       // Use reflection to set protected field
                                                                                                                                                       java.lang.reflect.Field cmdField = org.apache.commons.cli.Parser.class.getDeclaredField("cmd");
                                                                                                                                                       cmdField.setAccessible(true);
                                                                                                                                                       cmdField.set(parser, mockCmd);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to set options
                                                                                                                                                       java.lang.reflect.Method setOptionsMethod = org.apache.commons.cli.Parser.class.getDeclaredMethod("setOptions", org.apache.commons.cli.Options.class);
                                                                                                                                                       setOptionsMethod.setAccessible(true);
                                                                                                                                                       setOptionsMethod.invoke(parser, mockOptions);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to call processProperties
                                                                                                                                                       java.lang.reflect.Method processPropertiesMethod = org.apache.commons.cli.Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                                       processPropertiesMethod.setAccessible(true);
                                                                                                                                                       processPropertiesMethod.invoke(parser, properties);
                                                                                                                                                       
                                                                                                                                                       // Verify behavior indirectly by checking if the option is now available
                                                                                                                                                       verify(mockCmd, times(1)).hasOption("testOption");
                                                                                                                                                       
                                                                                                                                                       // This test will fail on the mutant since it calls addOption twice
                                                                                                                                                       // The mutant would require different verification to pass
                                                                                                                                                   }

    @Test
                                                                                                                                      public void testProcessProperties_AddsFlagOptionWhenValueIsYes() throws Exception {
                                                                                                                                          // Setup test data
                                                                                                                                          Properties properties = new Properties();
                                                                                                                                          properties.setProperty("flagOption", "yes");
                                                                                                                                          
                                                                                                                                          // Create real Options and Option objects instead of mocks
                                                                                                                                          Options options = new Options();
                                                                                                                                          Option opt = new Option("flagOption", "flag option description");
                                                                                                                                          options.addOption(opt);
                                                                                                                                          
                                                                                                                                          // Create parser instance
                                                                                                                                          Parser parser = new Parser() {
                                                                                                                                              @Override
                                                                                                                                              protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                                  return new String[0];
                                                                                                                                              }
                                                                                                                                          };
                                                                                                                                          
                                                                                                                                          // Use reflection to set private fields since there are no setters
                                                                                                                                          Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                                                          optionsField.setAccessible(true);
                                                                                                                                          optionsField.set(parser, options);
                                                                                                                                          
                                                                                                                                          // Execute method under test
                                                                                                                                          Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                          processProperties.setAccessible(true);
                                                                                                                                          processProperties.invoke(parser, properties);
                                                                                                                                          
                                                                                                                                          // Verify behavior by parsing empty arguments and checking if option is present
                                                                                                                                          CommandLine cmd = parser.parse(options, new String[0]);
                                                                                                                                          assertTrue("Flag option should be present", cmd.hasOption("flagOption"));
                                                                                                                                      }

    @Test
                                                                                                                                 public void testProcessPropertiesContinueVsBreakMutant1() throws Exception {
                                                                                                                                     // Setup test data - multiple properties with one that should be skipped
                                                                                                                                     Properties props = new Properties();
                                                                                                                                     props.setProperty("valid1", "true");  // should be added
                                                                                                                                     props.setProperty("invalid1", "no");  // should be skipped
                                                                                                                                     props.setProperty("valid2", "1");     // should be added (but won't with mutant)
                                                                                                                                     
                                                                                                                                     // Mock dependencies
                                                                                                                                     CommandLine cmd = mock(CommandLine.class);
                                                                                                                                     Options options = mock(Options.class);
                                                                                                                                     Option validOpt1 = mock(Option.class);
                                                                                                                                     Option validOpt2 = mock(Option.class);
                                                                                                                                     Option invalidOpt = mock(Option.class);
                                                                                                                                     
                                                                                                                                     // Stub behavior
                                                                                                                                     when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                                                                     when(options.getOption("valid1")).thenReturn(validOpt1);
                                                                                                                                     when(options.getOption("invalid1")).thenReturn(invalidOpt);
                                                                                                                                     when(options.getOption("valid2")).thenReturn(validOpt2);
                                                                                                                                     
                                                                                                                                     when(validOpt1.hasArg()).thenReturn(false);
                                                                                                                                     when(invalidOpt.hasArg()).thenReturn(false);
                                                                                                                                     when(validOpt2.hasArg()).thenReturn(false);
                                                                                                                                     
                                                                                                                                     // Create parser instance and set dependencies using reflection
                                                                                                                                     Parser parser = new Parser() {
                                                                                                                                         @Override
                                                                                                                                         protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                             return new String[0];
                                                                                                                                         }
                                                                                                                                     };
                                                                                                                                     
                                                                                                                                     // Set options using reflection
                                                                                                                                     Method setOptionsMethod = Parser.class.getDeclaredMethod("setOptions", Options.class);
                                                                                                                                     setOptionsMethod.setAccessible(true);
                                                                                                                                     setOptionsMethod.invoke(parser, options);
                                                                                                                                     
                                                                                                                                     // Set cmd field using reflection
                                                                                                                                     Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                                     cmdField.setAccessible(true);
                                                                                                                                     cmdField.set(parser, cmd);
                                                                                                                                     
                                                                                                                                     // Execute processProperties using reflection
                                                                                                                                     Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                                     processPropertiesMethod.setAccessible(true);
                                                                                                                                     processPropertiesMethod.invoke(parser, props);
                                                                                                                                     
                                                                                                                                     // Verify through command line parsing results rather than direct addOption calls
                                                                                                                                     verify(cmd, times(2)).hasOption(anyString());
                                                                                                                                     // Additional verification can be done by checking the command line state if needed
                                                                                                                                 }

    @Test
                                                                                                                    public void testProcessPropertiesWithInvalidBooleanValueShouldContinueProcessing() throws Exception {
                                                                                                                        // Setup test data
                                                                                                                        Properties properties = new Properties();
                                                                                                                        properties.setProperty("validBool", "true");  // valid boolean option
                                                                                                                        properties.setProperty("invalidBool", "no");  // invalid boolean option (should skip)
                                                                                                                        properties.setProperty("validArg", "value");  // option with argument
                                                                                                                        
                                                                                                                        // Mock dependencies
                                                                                                                        CommandLine cmd = mock(CommandLine.class);
                                                                                                                        Options options = mock(Options.class);
                                                                                                                        Option boolOption = mock(Option.class);
                                                                                                                        Option argOption = mock(Option.class);
                                                                                                                        
                                                                                                                        // Setup mock behavior
                                                                                                                        when(cmd.hasOption(anyString())).thenReturn(false);
                                                                                                                        when(options.getOption("validBool")).thenReturn(boolOption);
                                                                                                                        when(options.getOption("invalidBool")).thenReturn(boolOption);
                                                                                                                        when(options.getOption("validArg")).thenReturn(argOption);
                                                                                                                        
                                                                                                                        when(boolOption.hasArg()).thenReturn(false);
                                                                                                                        when(argOption.hasArg()).thenReturn(true);
                                                                                                                        when(argOption.getValues()).thenReturn(null);
                                                                                                                        
                                                                                                                        // Create test instance and set up state using reflection
                                                                                                                        Parser parser = new Parser() {
                                                                                                                            @Override
                                                                                                                            protected Options getOptions() {
                                                                                                                                return options;
                                                                                                                            }
                                                                                                                            
                                                                                                                            @Override
                                                                                                                            protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                                return new String[0];
                                                                                                                            }
                                                                                                                        };
                                                                                                                        
                                                                                                                        // Set protected cmd field using reflection
                                                                                                                        Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                                        cmdField.setAccessible(true);
                                                                                                                        cmdField.set(parser, cmd);
                                                                                                                        
                                                                                                                        // Call protected method using reflection
                                                                                                                        Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                                        processPropertiesMethod.setAccessible(true);
                                                                                                                        processPropertiesMethod.invoke(parser, properties);
                                                                                                                        
                                                                                                                        // Verify behavior by checking that options were processed
                                                                                                                        // We can't verify addOption directly, but we can verify that hasOption was called
                                                                                                                        verify(cmd, atLeastOnce()).hasOption(anyString());
                                                                                                                        // Verify that the valid options were processed
                                                                                                                        verify(cmd).hasOption("validBool");
                                                                                                                        verify(cmd).hasOption("validArg");
                                                                                                                    }

    @Test
                                                                                                           public void testProcessProperties_NonBooleanOptionValue_ShouldNotAddOption() throws Exception {
                                                                                                               // Setup test data
                                                                                                               Properties properties = new Properties();
                                                                                                               properties.setProperty("testOption", "no"); // Value that should skip adding
                                                                                                               
                                                                                                               // Mock dependencies
                                                                                                               CommandLine cmd = mock(CommandLine.class);
                                                                                                               Options options = mock(Options.class);
                                                                                                               Option opt = mock(Option.class);
                                                                                                               
                                                                                                               // Setup mock behavior
                                                                                                               when(cmd.hasOption("testOption")).thenReturn(false);
                                                                                                               when(options.getOption("testOption")).thenReturn(opt);
                                                                                                               when(opt.hasArg()).thenReturn(false); // Option doesn't require argument
                                                                                                               
                                                                                                               // Create parser instance
                                                                                                               Parser parser = new Parser() {
                                                                                                                   @Override
                                                                                                                   protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                                       return new String[0];
                                                                                                                   }
                                                                                                               };
                                                                                                               
                                                                                                               // Use reflection to set protected fields
                                                                                                               Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                               optionsField.setAccessible(true);
                                                                                                               optionsField.set(parser, options);
                                                                                                               
                                                                                                               Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                               cmdField.setAccessible(true);
                                                                                                               cmdField.set(parser, cmd);
                                                                                                               
                                                                                                               // Use reflection to call protected method
                                                                                                               Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                               processProperties.setAccessible(true);
                                                                                                               processProperties.invoke(parser, properties);
                                                                                                               
                                                                                                               // Verify behavior - option should NOT be added
                                                                                                               // Verify that hasOption remains false after processing
                                                                                                               verify(cmd, never()).hasOption("testOption");
                                                                                                           }

    @Test
                                                                                                  public void testProcessProperties_ShouldSkipBooleanOptionWithInvalidValue() {
                                                                                                      // Setup test data
                                                                                                      Properties props = new Properties();
                                                                                                      props.setProperty("verbose", "no"); // Should be skipped in original code
                                                                                                      
                                                                                                      // Mock dependencies
                                                                                                      CommandLine cmd = mock(CommandLine.class);
                                                                                                      Options options = mock(Options.class);
                                                                                                      Option opt = mock(Option.class);
                                                                                                      
                                                                                                      // Configure mocks
                                                                                                      when(cmd.hasOption("verbose")).thenReturn(false);
                                                                                                      when(options.getOption("verbose")).thenReturn(opt);
                                                                                                      when(opt.hasArg()).thenReturn(false); // Boolean option
                                                                                                      
                                                                                                      // Create parser and set dependencies using reflection
                                                                                                      Parser parser = new Parser() {
                                                                                                          @Override
                                                                                                          protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                              return new String[0];
                                                                                                          }
                                                                                                      };
                                                                                                      
                                                                                                      try {
                                                                                                          // Set options using reflection
                                                                                                          Method setOptions = Parser.class.getDeclaredMethod("setOptions", Options.class);
                                                                                                          setOptions.setAccessible(true);
                                                                                                          setOptions.invoke(parser, options);
                                                                                                          
                                                                                                          // Set cmd field using reflection
                                                                                                          Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                          cmdField.setAccessible(true);
                                                                                                          cmdField.set(parser, cmd);
                                                                                                          
                                                                                                          // Call processProperties using reflection
                                                                                                          Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                          processProperties.setAccessible(true);
                                                                                                          processProperties.invoke(parser, props);
                                                                                                          
                                                                                                          // Verify behavior - should not add the option
                                                                                                          // Verify that hasOption("verbose") remains false
                                                                                                          verify(cmd, never()).hasOption("verbose");
                                                                                                      } catch (Exception e) {
                                                                                                          fail("Failed to set up or execute test: " + e.getMessage());
                                                                                                      }
                                                                                                      
                                                                                                      // This test will fail if the mutant is present because:
                                                                                                      // Original: continues loop (never adds option)
                                                                                                      // Mutant: doesn't continue (adds option)
                                                                                                  }

    @Test
                                                                                             public void testProcessProperties_ShouldAddOption_WhenConditionsMet() {
                                                                                                 // Setup test data
                                                                                                 Properties properties = new Properties();
                                                                                                 properties.setProperty("testOption", "true");
                                                                                                 
                                                                                                 // Create required mocks and objects
                                                                                                 CommandLine cmd = mock(CommandLine.class);
                                                                                                 Options options = mock(Options.class);
                                                                                                 Option opt = mock(Option.class);
                                                                                                 
                                                                                                 // Create parser instance and set required fields
                                                                                                 Parser parser = new Parser() {
                                                                                                     @Override
                                                                                                     protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                         return new String[0];
                                                                                                     }
                                                                                                 };
                                                                                                 
                                                                                                 // Set up mock behaviors
                                                                                                 when(cmd.hasOption("testOption")).thenReturn(false);
                                                                                                 when(options.getOption("testOption")).thenReturn(opt);
                                                                                                 when(opt.hasArg()).thenReturn(false);
                                                                                                 
                                                                                                 // Use reflection to set private fields since we don't have setters
                                                                                                 try {
                                                                                                     Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                     cmdField.setAccessible(true);
                                                                                                     cmdField.set(parser, cmd);
                                                                                                     
                                                                                                     Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                     optionsField.setAccessible(true);
                                                                                                     optionsField.set(parser, options);
                                                                                                     
                                                                                                     // Use reflection to call the protected method
                                                                                                     Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                     processProperties.setAccessible(true);
                                                                                                     processProperties.invoke(parser, properties);
                                                                                                     
                                                                                                     // Verify the behavior by checking if the option is now present
                                                                                                     verify(cmd, times(1)).hasOption("testOption");
                                                                                                     verify(options, times(1)).getOption("testOption");
                                                                                                     verify(opt, times(1)).hasArg();
                                                                                                 } catch (Exception e) {
                                                                                                     fail("Failed to set up or execute test due to reflection error: " + e.getMessage());
                                                                                                 }
                                                                                             }

    @Test
                                                                                        public void testProcessPropertiesAddsCorrectOptionToCommandLine() {
                                                                                            // Setup test data
                                                                                            Properties properties = new Properties();
                                                                                            properties.setProperty("testOption", "testValue");
                                                                                            
                                                                                            // Create mock objects
                                                                                            CommandLine mockCmd = mock(CommandLine.class);
                                                                                            Options mockOptions = mock(Options.class);
                                                                                            Option mockOption = mock(Option.class);
                                                                                            
                                                                                            // Create parser instance and set mocks
                                                                                            Parser parser = new Parser() {
                                                                                                @Override
                                                                                                protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                                    return new String[0];
                                                                                                }
                                                                                            };
                                                                                            
                                                                                            // Use reflection to set protected fields since we can't access them directly
                                                                                            try {
                                                                                                Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                                cmdField.setAccessible(true);
                                                                                                cmdField.set(parser, mockCmd);
                                                                                                
                                                                                                Field optionsField = Parser.class.getDeclaredField("options");
                                                                                                optionsField.setAccessible(true);
                                                                                                optionsField.set(parser, mockOptions);
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                            }
                                                                                            
                                                                                            // Configure mock behavior
                                                                                            when(mockCmd.hasOption("testOption")).thenReturn(false);
                                                                                            when(mockOptions.getOption("testOption")).thenReturn(mockOption);
                                                                                            when(mockOption.hasArg()).thenReturn(true);
                                                                                            when(mockOption.getValues()).thenReturn(null);
                                                                                            
                                                                                            // Execute the method using reflection
                                                                                            try {
                                                                                                Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                                processProperties.setAccessible(true);
                                                                                                processProperties.invoke(parser, properties);
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to invoke processProperties: " + e.getMessage());
                                                                                            }
                                                                                            
                                                                                            // Verify the behavior through command line state
                                                                                            verify(mockCmd).hasOption("testOption");
                                                                                            verify(mockOptions).getOption("testOption");
                                                                                            
                                                                                            // Verify option processing
                                                                                            verify(mockOption).hasArg();
                                                                                            verify(mockOption).getValues();
                                                                                            
                                                                                            // Verify the value was processed by checking mock interactions
                                                                                            // Since we can't verify addOption directly, we verify the expected behavior
                                                                                            // through the command line's public methods
                                                                                            verify(mockCmd).getOptionValues("testOption");
                                                                                        }

    @Test
                                                                                   public void testProcessProperties_AddOptionCalledWhenExpected() {
                                                                                       // Setup test data
                                                                                       Properties properties = new Properties();
                                                                                       properties.setProperty("testOption", "true"); // This should trigger option addition
                                                                                       
                                                                                       // Create mock objects
                                                                                       CommandLine mockCmd = mock(CommandLine.class);
                                                                                       Options mockOptions = mock(Options.class);
                                                                                       Option mockOption = mock(Option.class);
                                                                                       
                                                                                       // Setup mock behavior
                                                                                       when(mockCmd.hasOption("testOption")).thenReturn(false);
                                                                                       when(mockOptions.getOption("testOption")).thenReturn(mockOption);
                                                                                       when(mockOption.hasArg()).thenReturn(false);
                                                                                       
                                                                                       // Create parser instance and set mocks
                                                                                       Parser parser = new Parser() {
                                                                                           @Override
                                                                                           protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                               return new String[0];
                                                                                           }
                                                                                       };
                                                                                       
                                                                                       // Use reflection to set private fields since there are no setters
                                                                                       try {
                                                                                           Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                           cmdField.setAccessible(true);
                                                                                           cmdField.set(parser, mockCmd);
                                                                                           
                                                                                           Field optionsField = Parser.class.getDeclaredField("options");
                                                                                           optionsField.setAccessible(true);
                                                                                           optionsField.set(parser, mockOptions);
                                                                                           
                                                                                           // Use reflection to call the protected method
                                                                                           Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                           processProperties.setAccessible(true);
                                                                                           processProperties.invoke(parser, properties);
                                                                                       } catch (Exception e) {
                                                                                           fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                       }
                                                                                       
                                                                                       // Verify interaction indirectly by checking if the option would have been added
                                                                                       // Since we can't verify addOption directly, we verify that hasOption would return true
                                                                                       // after processing (assuming the mock behavior is properly set up)
                                                                                       verify(mockCmd).hasOption("testOption");
                                                                                       // Also verify that getOption was called, which is part of the expected flow
                                                                                       verify(mockOptions).getOption("testOption");
                                                                                   }

    @Test
                                                                              public void testProcessPropertiesWithNullOption1() {
                                                                                  // Setup test data
                                                                                  Properties properties = new Properties();
                                                                                  properties.setProperty("testOption", "value");
                                                                                  
                                                                                  // Mock dependencies
                                                                                  CommandLine cmd = mock(CommandLine.class);
                                                                                  Options options = mock(Options.class);
                                                                                  Option opt = null; // This will be our null option
                                                                                  
                                                                                  // Create parser instance and set mocked dependencies
                                                                                  Parser parser = new Parser() {
                                                                                      @Override
                                                                                      protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                          return new String[0];
                                                                                      }
                                                                                  };
                                                                                  
                                                                                  // Use reflection to set protected fields and call protected methods
                                                                                  try {
                                                                                      // Set options field
                                                                                      Field optionsField = Parser.class.getDeclaredField("options");
                                                                                      optionsField.setAccessible(true);
                                                                                      optionsField.set(parser, options);
                                                                                      
                                                                                      // Set cmd field
                                                                                      Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                                      cmdField.setAccessible(true);
                                                                                      cmdField.set(parser, cmd);
                                                                                      
                                                                                      // Stub behavior
                                                                                      when(options.getOption("testOption")).thenReturn(opt);
                                                                                      when(cmd.hasOption("testOption")).thenReturn(false);
                                                                                      
                                                                                      // Call processProperties via reflection
                                                                                      Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                                      processProperties.setAccessible(true);
                                                                                      processProperties.invoke(parser, properties);
                                                                                      
                                                                                      // Verify behavior - should try to add null option in original code
                                                                                      // We verify that the command line was interacted with, since we can't directly verify addOption
                                                                                      verify(cmd, atLeastOnce()).hasOption(anyString());
                                                                                      
                                                                                  } catch (Exception e) {
                                                                                      fail("Failed to set fields or call methods via reflection: " + e.getMessage());
                                                                                  }
                                                                                  
                                                                                  // In mutated version, this verification would fail because of the null check
                                                                                  // This test will catch the mutant by expecting the original behavior
                                                                              }

    @Test
                                                                     public void testProcessProperties_ShouldNeverAddOptionWithInvalidValue() {
                                                                         // Setup test data
                                                                         Properties props = new Properties();
                                                                         props.setProperty("testOption", "no"); // Invalid value
                                                                         
                                                                         // Mock dependencies
                                                                         CommandLine cmd = mock(CommandLine.class);
                                                                         Options options = mock(Options.class);
                                                                         Option opt = mock(Option.class);
                                                                         
                                                                         // Configure mocks
                                                                         when(cmd.hasOption("testOption")).thenReturn(false);
                                                                         when(options.getOption("testOption")).thenReturn(opt);
                                                                         when(opt.hasArg()).thenReturn(false);
                                                                         
                                                                         // Create parser instance and set dependencies
                                                                         Parser parser = new Parser() {
                                                                             @Override
                                                                             protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                                 return new String[0];
                                                                             }
                                                                         };
                                                                         
                                                                         // Use reflection to set protected fields and call protected methods
                                                                         try {
                                                                             // Set options field
                                                                             Field optionsField = Parser.class.getDeclaredField("options");
                                                                             optionsField.setAccessible(true);
                                                                             optionsField.set(parser, options);
                                                                             
                                                                             // Set cmd field
                                                                             Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                             cmdField.setAccessible(true);
                                                                             cmdField.set(parser, cmd);
                                                                             
                                                                             // Get processProperties method
                                                                             Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                             processProperties.setAccessible(true);
                                                                             
                                                                             // Run multiple times to catch random behavior
                                                                             for (int i = 0; i < 20; i++) {
                                                                                 processProperties.invoke(parser, props);
                                                                                 
                                                                                 // Verify option was never added by checking hasOption remains false
                                                                                 verify(cmd, never()).hasOption("testOption");
                                                                             }
                                                                         } catch (Exception e) {
                                                                             fail("Failed to set up or execute test: " + e.getMessage());
                                                                         }
                                                                     }

    @Test
                                                            public void testProcessProperties_ShouldAddEachOptionOnlyOnce() throws Exception {
                                                                // Setup test data
                                                                Properties properties = new Properties();
                                                                properties.setProperty("testOption", "testValue");
                                                                
                                                                // Mock dependencies
                                                                CommandLine mockCmd = mock(CommandLine.class);
                                                                Options mockOptions = mock(Options.class);
                                                                Option mockOption = mock(Option.class);
                                                                
                                                                // Setup mock behavior
                                                                when(mockOptions.getOption("testOption")).thenReturn(mockOption);
                                                                when(mockOption.hasArg()).thenReturn(true);
                                                                when(mockOption.getValues()).thenReturn(null);
                                                                when(mockCmd.hasOption("testOption")).thenReturn(false);
                                                                
                                                                // Create test instance
                                                                Parser parser = new Parser() {
                                                                    @Override
                                                                    protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                                        return new String[0];
                                                                    }
                                                                };
                                                                
                                                                // Use reflection to set protected fields
                                                                Field optionsField = Parser.class.getDeclaredField("options");
                                                                optionsField.setAccessible(true);
                                                                optionsField.set(parser, mockOptions);
                                                                
                                                                Field cmdField = Parser.class.getDeclaredField("cmd");
                                                                cmdField.setAccessible(true);
                                                                cmdField.set(parser, mockCmd);
                                                                
                                                                // Use reflection to call protected method
                                                                Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                                processProperties.setAccessible(true);
                                                                processProperties.invoke(parser, properties);
                                                                
                                                                // Verify behavior by checking if the option was processed
                                                                // Instead of verifying the non-public addOption call, we verify the hasOption call
                                                                // which is the public API that would be affected by adding the option
                                                                verify(mockCmd).hasOption("testOption");
                                                                
                                                                // Additional verification to ensure no other interactions
                                                                verifyNoMoreInteractions(mockCmd);
                                                            }

    @Test
                                           public void testProcessProperties_ShouldAddFlagOptions_DetectsMutant() {
                                               // Setup test data
                                               Properties properties = new Properties();
                                               properties.setProperty("flagOption", "true");  // flag option (no arg)
                                               properties.setProperty("argOption", "value");  // option with arg
                                               
                                               // Mock dependencies
                                               Options options = mock(Options.class);
                                               Option flagOption = mock(Option.class);
                                               Option argOption = mock(Option.class);
                                               CommandLine cmd = mock(CommandLine.class);
                                               
                                               // Stub behavior
                                               when(flagOption.hasArg()).thenReturn(false);
                                               when(argOption.hasArg()).thenReturn(true);
                                               when(argOption.getValues()).thenReturn(new String[]{"value"});
                                               when(options.getOption("flagOption")).thenReturn(flagOption);
                                               when(options.getOption("argOption")).thenReturn(argOption);
                                               when(cmd.hasOption(anyString())).thenReturn(false);
                                               
                                               // Create test instance and set up state
                                               Parser parser = new Parser() {
                                                   @Override
                                                   protected Options getOptions() {
                                                       return options;
                                                   }
                                                   
                                                   @Override
                                                   protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                       return new String[0];
                                                   }
                                               };
                                               
                                               // Use reflection to set protected cmd field
                                               try {
                                                   Field cmdField = Parser.class.getDeclaredField("cmd");
                                                   cmdField.setAccessible(true);
                                                   cmdField.set(parser, cmd);
                                               } catch (Exception e) {
                                                   fail("Failed to set cmd field");
                                               }
                                               
                                               // Use reflection to invoke protected processProperties method
                                               try {
                                                   Method method = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                                   method.setAccessible(true);
                                                   method.invoke(parser, properties);
                                               } catch (Exception e) {
                                                   fail("Failed to invoke processProperties");
                                               }
                                               
                                               // Verify both options were processed by checking hasOption calls
                                               verify(cmd).hasOption("flagOption");
                                               verify(cmd).hasOption("argOption");
                                               
                                               // Verify options were processed by checking their presence in the command line
                                               verify(cmd).getOptionValue("flagOption");
                                               verify(cmd).getOptionValue("argOption");
                                           }

    @Test
                                      public void testProcessPropertiesBooleanOptionFalseValue() {
                                          // Setup test data
                                          Properties props = new Properties();
                                          props.setProperty("boolOpt", "no"); // False value for boolean option
                                          
                                          // Mock dependencies
                                          CommandLine cmd = mock(CommandLine.class);
                                          Options options = mock(Options.class);
                                          Option opt = mock(Option.class);
                                          
                                          // Create parser instance (might need reflection if constructor is private)
                                          Parser parser = new Parser() {
                                              protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                                  return new String[0];
                                              }
                                          };
                                          
                                          // Set up mock behavior
                                          when(cmd.hasOption("boolOpt")).thenReturn(false);
                                          when(options.getOption("boolOpt")).thenReturn(opt);
                                          when(opt.hasArg()).thenReturn(false);
                                          
                                          // Use reflection to set private fields if needed
                                          try {
                                              Field cmdField = Parser.class.getDeclaredField("cmd");
                                              cmdField.setAccessible(true);
                                              cmdField.set(parser, cmd);
                                              
                                              Field optionsField = Parser.class.getDeclaredField("options");
                                              optionsField.setAccessible(true);
                                              optionsField.set(parser, options);
                                              
                                              // Use reflection to invoke protected method
                                              Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                              processProperties.setAccessible(true);
                                              processProperties.invoke(parser, props);
                                          } catch (Exception e) {
                                              fail("Failed to set up test due to reflection issues");
                                          }
                                          
                                          // Verify the option was NOT added by checking hasOption remains false
                                          verify(cmd, never()).hasOption("boolOpt");
                                          
                                          // Additional verification that we went through the boolean path
                                          verify(opt, times(1)).hasArg();
                                      }

    @Test
                                 public void testProcessProperties_ShouldNotAddOptionWhenValueIsInvalid() {
                                     // Setup test data
                                     Properties props = new Properties();
                                     props.setProperty("testOption", "no"); // Invalid value
                                     
                                     // Mock dependencies
                                     CommandLine cmd = mock(CommandLine.class);
                                     Options options = mock(Options.class);
                                     Option opt = mock(Option.class);
                                     
                                     // Set up mock behavior
                                     when(cmd.hasOption("testOption")).thenReturn(false);
                                     when(options.getOption("testOption")).thenReturn(opt);
                                     when(opt.hasArg()).thenReturn(false);
                                     
                                     // Create parser instance
                                     Parser parser = new Parser() {
                                         @Override
                                         protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                             return new String[0];
                                         }
                                     };
                                     
                                     // Use reflection to set protected fields and call protected methods
                                     try {
                                         // Set options
                                         Method setOptionsMethod = Parser.class.getDeclaredMethod("setOptions", Options.class);
                                         setOptionsMethod.setAccessible(true);
                                         setOptionsMethod.invoke(parser, options);
                                         
                                         // Set cmd field
                                         Field cmdField = Parser.class.getDeclaredField("cmd");
                                         cmdField.setAccessible(true);
                                         cmdField.set(parser, cmd);
                                         
                                         // Call processProperties
                                         Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                         processPropertiesMethod.setAccessible(true);
                                         processPropertiesMethod.invoke(parser, props);
                                     } catch (Exception e) {
                                         fail("Failed to access protected fields/methods via reflection");
                                     }
                                     
                                     // Verify behavior - should not add option for invalid value
                                     // Since we can't verify addOption directly, we verify that hasOption remains false
                                     verify(cmd, never()).hasOption("testOption");
                                 }

    @Test
                            public void testProcessPropertiesAddsCorrectOptionsToCommandLine() {
                                // Setup test data
                                Properties properties = new Properties();
                                properties.setProperty("testOption", "testValue");
                                
                                // Create mock objects
                                CommandLine mockCmd = mock(CommandLine.class);
                                Options mockOptions = mock(Options.class);
                                Option mockOption = mock(Option.class);
                                
                                // Create parser instance and set up test scenario
                                Parser parser = new Parser() {
                                    @Override
                                    protected Options getOptions() {
                                        return mockOptions;
                                    }
                                    
                                    @Override
                                    protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                        return new String[0];
                                    }
                                };
                                
                                // Use reflection to set protected cmd field
                                try {
                                    Field cmdField = Parser.class.getDeclaredField("cmd");
                                    cmdField.setAccessible(true);
                                    cmdField.set(parser, mockCmd);
                                } catch (Exception e) {
                                    fail("Failed to set cmd field via reflection");
                                }
                                
                                // Set up mock behavior
                                when(mockCmd.hasOption("testOption")).thenReturn(false);
                                when(mockOptions.getOption("testOption")).thenReturn(mockOption);
                                when(mockOption.hasArg()).thenReturn(true);
                                when(mockOption.getValues()).thenReturn(null);
                                
                                // Execute the method using reflection
                                try {
                                    Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                                    processProperties.setAccessible(true);
                                    processProperties.invoke(parser, properties);
                                } catch (Exception e) {
                                    fail("Failed to invoke processProperties via reflection");
                                }
                                
                                // Verify the command line now has the option
                                verify(mockCmd).hasOption("testOption");
                                // Verify the option was retrieved from options
                                verify(mockOptions).getOption("testOption");
                                // Verify option processing was checked
                                verify(mockOption).hasArg();
                                verify(mockOption).getValues();
                            }

    @Test
                       public void testProcessPropertiesOptionAddition() throws Exception {
                           // Setup test data
                           Properties props = new Properties();
                           props.setProperty("flagOption", "true");  // Should be added
                           props.setProperty("argOption", "value"); // Should be added if hasArg
                           
                           // Mock dependencies
                           CommandLine cmd = mock(CommandLine.class);
                           Options options = mock(Options.class);
                           Option flagOpt = mock(Option.class);
                           Option argOpt = mock(Option.class);
                           
                           // Stub behavior
                           when(cmd.hasOption("flagOption")).thenReturn(false);
                           when(cmd.hasOption("argOption")).thenReturn(false);
                           when(options.getOption("flagOption")).thenReturn(flagOpt);
                           when(options.getOption("argOption")).thenReturn(argOpt);
                           when(flagOpt.hasArg()).thenReturn(false);
                           when(argOpt.hasArg()).thenReturn(true);
                           when(argOpt.getValues()).thenReturn(null);
                           
                           // Create test instance using anonymous subclass to access protected members
                           Parser parser = new Parser() {
                               @Override
                               protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                                   return new String[0];
                               }
                               
                               // Override processProperties to make it accessible
                               @Override
                               protected void processProperties(Properties properties) {
                                   super.processProperties(properties);
                               }
                           };
                           
                           // Use reflection to set protected fields
                           Field optionsField = Parser.class.getDeclaredField("options");
                           optionsField.setAccessible(true);
                           optionsField.set(parser, options);
                           
                           Field cmdField = Parser.class.getDeclaredField("cmd");
                           cmdField.setAccessible(true);
                           cmdField.set(parser, cmd);
                           
                           // Execute
                           Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                           processProperties.setAccessible(true);
                           processProperties.invoke(parser, props);
                           
                           // Verify option additions through public methods or state changes
                           // Since we can't verify addOption directly, we can verify the final state
                           verify(cmd, times(1)).hasOption("flagOption");
                           verify(cmd, times(1)).hasOption("argOption");
                           verify(options, times(1)).getOption("flagOption");
                           verify(options, times(1)).getOption("argOption");
                       }

    @Test
                  public void testProcessPropertiesWithNullOption2() {
                      // Setup test data
                      Properties properties = new Properties();
                      properties.setProperty("testOption", "testValue");
                      
                      // Mock dependencies
                      CommandLine cmd = mock(CommandLine.class);
                      Options options = mock(Options.class);
                      
                      // Create parser instance and set mocks
                      Parser parser = new Parser() {
                          @Override
                          protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                              return new String[0];
                          }
                      };
                      
                      // Use reflection to set protected fields since we can't access them directly
                      try {
                          Field cmdField = Parser.class.getDeclaredField("cmd");
                          cmdField.setAccessible(true);
                          cmdField.set(parser, cmd);
                          
                          Field optionsField = Parser.class.getDeclaredField("options");
                          optionsField.setAccessible(true);
                          optionsField.set(parser, options);
                      } catch (Exception e) {
                          fail("Failed to set up test due to reflection error: " + e.getMessage());
                      }
                      
                      // Configure mocks
                      when(options.getOption("testOption")).thenReturn(null);
                      when(cmd.hasOption("testOption")).thenReturn(false);
                      
                      // Invoke protected method using reflection
                      try {
                          Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                          processProperties.setAccessible(true);
                          processProperties.invoke(parser, properties);
                      } catch (Exception e) {
                          fail("Failed to invoke processProperties: " + e.getMessage());
                      }
                      
                      // Verify the mutation would skip adding null option by checking hasOption wasn't called with testOption
                      verify(cmd, never()).hasOption("testOption");
                  }

    @Test
             public void testProcessPropertiesWithInvalidBooleanValuesShouldNeverAddOptions() {
                 // Setup test data
                 Properties props = new Properties();
                 props.setProperty("opt1", "no");  // invalid value
                 props.setProperty("opt2", "false"); // invalid value
                 props.setProperty("opt3", "0");    // invalid value
                 
                 // Mock dependencies
                 CommandLine cmd = mock(CommandLine.class);
                 Options options = mock(Options.class);
                 Option opt1 = mock(Option.class);
                 Option opt2 = mock(Option.class);
                 Option opt3 = mock(Option.class);
                 
                 // Stub behavior
                 when(opt1.hasArg()).thenReturn(false);
                 when(opt2.hasArg()).thenReturn(false);
                 when(opt3.hasArg()).thenReturn(false);
                 when(options.getOption("opt1")).thenReturn(opt1);
                 when(options.getOption("opt2")).thenReturn(opt2);
                 when(options.getOption("opt3")).thenReturn(opt3);
                 when(cmd.hasOption(anyString())).thenReturn(false);
                 
                 // Create test instance
                 Parser parser = new Parser() {
                     @Override
                     protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                         return new String[0];
                     }
                 };
                 
                 // Use reflection to set protected fields and call protected methods
                 try {
                     // Set options
                     Method setOptionsMethod = Parser.class.getDeclaredMethod("setOptions", Options.class);
                     setOptionsMethod.setAccessible(true);
                     setOptionsMethod.invoke(parser, options);
                     
                     // Set cmd field
                     Field cmdField = Parser.class.getDeclaredField("cmd");
                     cmdField.setAccessible(true);
                     cmdField.set(parser, cmd);
                     
                     // Call processProperties
                     Method processPropertiesMethod = Parser.class.getDeclaredMethod("processProperties", Properties.class);
                     processPropertiesMethod.setAccessible(true);
                     processPropertiesMethod.invoke(parser, props);
                 } catch (Exception e) {
                     fail("Failed to set fields or call methods via reflection");
                 }
                 
                 // Verify - none of the options should be present in cmd
                 verify(cmd, never()).hasOption("opt1");
                 verify(cmd, never()).hasOption("opt2");
                 verify(cmd, never()).hasOption("opt3");
             }

    @Test
    public void testProcessProperties_ShouldNotAddDuplicateOptions() {
        // Setup test data
        Properties properties = new Properties();
        properties.setProperty("testOption", "true");
        
        // Mock dependencies
        CommandLine cmd = mock(CommandLine.class);
        Options options = mock(Options.class);
        Option opt = mock(Option.class);
        
        // Set up test class
        Parser parser = new Parser() {
            @Override
            protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
                return new String[0];
            }
        };
        
        // Use reflection to set protected fields
        try {
            Field cmdField = Parser.class.getDeclaredField("cmd");
            cmdField.setAccessible(true);
            cmdField.set(parser, cmd);
            
            Field optionsField = Parser.class.getDeclaredField("options");
            optionsField.setAccessible(true);
            optionsField.set(parser, options);
        } catch (Exception e) {
            fail("Failed to set up test due to reflection issues");
        }
        
        // Configure mocks
        when(options.getOption("testOption")).thenReturn(opt);
        when(opt.hasArg()).thenReturn(false);
        when(cmd.hasOption("testOption")).thenReturn(false);
        
        // Execute test using reflection to call protected method
        try {
            Method processProperties = Parser.class.getDeclaredMethod("processProperties", Properties.class);
            processProperties.setAccessible(true);
            processProperties.invoke(parser, properties);
        } catch (Exception e) {
            fail("Failed to invoke processProperties method");
        }
        
        // Verify behavior by checking if option was checked
        verify(cmd, times(1)).hasOption("testOption");
        // Remove the verification of non-public method
        // Verify no other unexpected interactions
        verifyNoMoreInteractions(cmd);
    }


}
