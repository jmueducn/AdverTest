package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
 
public class DefaultParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                            public void testHandleProperties_NullProperties() throws Exception {
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                Method method = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                method.setAccessible(true);
                                                                                                                method.invoke(parser, (Properties) null);
                                                                                                                // No exception should be thrown, method should return silently
                                                                                                            }

    @Test
                                                                                                            public void testHandleProperties_EmptyProperties() throws Exception {
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                Properties properties = new Properties();
                                                                                                                
                                                                                                                // Use reflection to access the private handleProperties method
                                                                                                                Method method = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                method.setAccessible(true);
                                                                                                                method.invoke(parser, properties);
                                                                                                                
                                                                                                                // No exception should be thrown, method should process empty properties
                                                                                                            }

    @Test
                                                                                                            public void testHandleProperties_UnrecognizedOption() throws Exception {
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Create mock Options
                                                                                                                Options mockOptions = mock(Options.class);
                                                                                                                
                                                                                                                // Use reflection to set the protected options field
                                                                                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                optionsField.setAccessible(true);
                                                                                                                optionsField.set(parser, mockOptions);
                                                                                                                
                                                                                                                Properties properties = new Properties();
                                                                                                                properties.setProperty("unknownOption", "value");
                                                                                                                
                                                                                                                when(mockOptions.getOption("unknownOption")).thenReturn(null);
                                                                                                                
                                                                                                                thrown.expect(UnrecognizedOptionException.class);
                                                                                                                thrown.expectMessage("Default option wasn't defined");
                                                                                                                
                                                                                                                // Use reflection to call the private handleProperties method
                                                                                                                Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                handlePropertiesMethod.setAccessible(true);
                                                                                                                handlePropertiesMethod.invoke(parser, properties);
                                                                                                            }

    @Test
                                                                                                            public void testHandleProperties_OptionWithoutArgWithInvalidValue() throws Exception {
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Set protected fields using reflection
                                                                                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                optionsField.setAccessible(true);
                                                                                                                Options mockOptions = mock(Options.class);
                                                                                                                optionsField.set(parser, mockOptions);
                                                                                                                
                                                                                                                Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                                cmdField.setAccessible(true);
                                                                                                                CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                cmdField.set(parser, mockCmd);
                                                                                                                
                                                                                                                Properties properties = new Properties();
                                                                                                                properties.setProperty("flagOption", "no");
                                                                                                                
                                                                                                                Option mockOption = mock(Option.class);
                                                                                                                when(mockOption.hasArg()).thenReturn(false);
                                                                                                                
                                                                                                                when(mockOptions.getOption("flagOption")).thenReturn(mockOption);
                                                                                                                when(mockCmd.hasOption("flagOption")).thenReturn(false);
                                                                                                                when(mockOptions.getOptionGroup(mockOption)).thenReturn(null);
                                                                                                                
                                                                                                                // Get handleProperties method via reflection
                                                                                                                Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                handlePropertiesMethod.setAccessible(true);
                                                                                                                handlePropertiesMethod.invoke(parser, properties);
                                                                                                                
                                                                                                                // Verify handleOption was never called
                                                                                                                Method handleOptionMethod = DefaultParser.class.getDeclaredMethod("handleOption", Option.class);
                                                                                                                handleOptionMethod.setAccessible(true);
                                                                                                                verify(mockOptions, never()).getOption("flagOption");
                                                                                                            }

    @Test
                                                                                                            public void testHandleProperties_OptionAlreadyInCommandLine() throws Exception {
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Create mock objects
                                                                                                                Options mockOptions = mock(Options.class);
                                                                                                                CommandLine mockCmd = mock(CommandLine.class);
                                                                                                                Option mockOption = mock(Option.class);
                                                                                                                
                                                                                                                // Use reflection to set protected fields
                                                                                                                Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                                optionsField.setAccessible(true);
                                                                                                                optionsField.set(parser, mockOptions);
                                                                                                                
                                                                                                                Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                                cmdField.setAccessible(true);
                                                                                                                cmdField.set(parser, mockCmd);
                                                                                                                
                                                                                                                // Setup test data
                                                                                                                Properties properties = new Properties();
                                                                                                                properties.setProperty("existingOption", "value");
                                                                                                                
                                                                                                                // Setup mock behavior
                                                                                                                when(mockOptions.getOption("existingOption")).thenReturn(mockOption);
                                                                                                                when(mockCmd.hasOption("existingOption")).thenReturn(true);
                                                                                                                
                                                                                                                // Get and invoke private method
                                                                                                                Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                                handlePropertiesMethod.setAccessible(true);
                                                                                                                handlePropertiesMethod.invoke(parser, properties);
                                                                                                                
                                                                                                                // Verify handleOption was never called
                                                                                                                Method handleOptionMethod = DefaultParser.class.getDeclaredMethod("handleOption", Option.class);
                                                                                                                handleOptionMethod.setAccessible(true);
                                                                                                                verify(mockOptions, never()).getOption(anyString()); // Indirect verification since we can't verify private method call directly
                                                                                                            }

    @Test
                                                                                                            public void testIsArgument_WhenTokenIsNotOptionAndNotNegativeNumber() throws Exception {
                                                                                                                // Setup
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Mock isOption to return false and isNegativeNumber to return false
                                                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                isOptionMethod.setAccessible(true);
                                                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Test & Verify
                                                                                                                assertTrue((boolean) isArgumentMethod.invoke(parser, "regularToken"));
                                                                                                            }

    @Test
                                                                                                            public void testIsArgument_WhenTokenIsOptionButNegativeNumber() throws Exception {
                                                                                                                // Create parser instance
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Use reflection to test private method
                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Test & Verify
                                                                                                                // According to the implementation: !isOption(token) || isNegativeNumber(token)
                                                                                                                // When token is both option and negative number, it should return true
                                                                                                                boolean result = (boolean) isArgumentMethod.invoke(parser, "-123");
                                                                                                                assertTrue(result);
                                                                                                            }

    @Test
                                                                                                            public void testIsArgument_WhenTokenIsOptionAndNotNegativeNumber() throws Exception {
                                                                                                                // Create parser instance
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Get private methods via reflection
                                                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                isOptionMethod.setAccessible(true);
                                                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Setup test conditions
                                                                                                                String token = "-option";
                                                                                                                
                                                                                                                // Verify behavior
                                                                                                                boolean isOption = (boolean) isOptionMethod.invoke(parser, token);
                                                                                                                boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, token);
                                                                                                                boolean isArgument = (boolean) isArgumentMethod.invoke(parser, token);
                                                                                                                
                                                                                                                // Assert expected behavior
                                                                                                                assertTrue(isOption);
                                                                                                                assertFalse(isNegativeNumber);
                                                                                                                assertFalse(isArgument);
                                                                                                            }

    @Test
                                                                                                            public void testIsArgument_WhenTokenIsNotOptionButNegativeNumber() throws Exception {
                                                                                                                // Setup
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Get private methods via reflection
                                                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                isOptionMethod.setAccessible(true);
                                                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Create spy and mock behavior
                                                                                                                DefaultParser spyParser = spy(parser);
                                                                                                                when(isOptionMethod.invoke(spyParser, "-456")).thenReturn(false);
                                                                                                                when(isNegativeNumberMethod.invoke(spyParser, "-456")).thenReturn(true);
                                                                                                                
                                                                                                                // Test & Verify
                                                                                                                assertTrue((Boolean) isArgumentMethod.invoke(spyParser, "-456"));
                                                                                                            }

    @Test
                                                                                                            public void testIsArgument_WithEmptyString() throws Exception {
                                                                                                                // Create parser instance
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Get private methods via reflection
                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                
                                                                                                                // Make methods accessible
                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                isOptionMethod.setAccessible(true);
                                                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Create spy parser
                                                                                                                DefaultParser spyParser = spy(parser);
                                                                                                                
                                                                                                                // Mock private methods
                                                                                                                when(isOptionMethod.invoke(spyParser, "")).thenReturn(false);
                                                                                                                when(isNegativeNumberMethod.invoke(spyParser, "")).thenReturn(false);
                                                                                                                
                                                                                                                // Test & Verify
                                                                                                                assertTrue((Boolean) isArgumentMethod.invoke(spyParser, ""));
                                                                                                            }

    @Test
                                                                                                            public void testIsArgument_WithPositiveNumber() throws Exception {
                                                                                                                // Create parser instance
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Get private methods via reflection
                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                
                                                                                                                // Set accessible
                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                isOptionMethod.setAccessible(true);
                                                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Verify that with a positive number (not option and not negative number)
                                                                                                                // it should be considered an argument
                                                                                                                boolean result = (boolean) isArgumentMethod.invoke(parser, "123");
                                                                                                                assertTrue(result);
                                                                                                            }

    @Test
                                                                                                            public void testIsArgument_WithNegativeZero() throws Exception {
                                                                                                                // Create parser instance
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                
                                                                                                                // Use reflection to test private methods
                                                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                                isOptionMethod.setAccessible(true);
                                                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                                isArgumentMethod.setAccessible(true);
                                                                                                                
                                                                                                                // Verify the behavior
                                                                                                                assertFalse((boolean) isOptionMethod.invoke(parser, "-0"));
                                                                                                                assertTrue((boolean) isNegativeNumberMethod.invoke(parser, "-0"));
                                                                                                                assertTrue((boolean) isArgumentMethod.invoke(parser, "-0"));
                                                                                                            }

    @Test
                                                                                                            public void testIsNegativeNumber_WithValidNegativeNumbers() throws Exception {
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                Method isNegativeNumber = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                isNegativeNumber.setAccessible(true);
                                                                                                                
                                                                                                                assertTrue((Boolean) isNegativeNumber.invoke(parser, "-1"));
                                                                                                                assertTrue((Boolean) isNegativeNumber.invoke(parser, "-0.5"));
                                                                                                                assertTrue((Boolean) isNegativeNumber.invoke(parser, "-1234567890.987654321"));
                                                                                                                assertTrue((Boolean) isNegativeNumber.invoke(parser, "-1.0E10"));
                                                                                                                assertTrue((Boolean) isNegativeNumber.invoke(parser, "-1e-10"));
                                                                                                            }

    @Test
                                                                                                            public void testIsNegativeNumber_WithZero() throws Exception {
                                                                                                                DefaultParser parser = new DefaultParser();
                                                                                                                Method isNegativeNumber = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                                isNegativeNumber.setAccessible(true);
                                                                                                                
                                                                                                                assertFalse((boolean)isNegativeNumber.invoke(parser, "0"));
                                                                                                                assertFalse((boolean)isNegativeNumber.invoke(parser, "0.0"));
                                                                                                                assertFalse((boolean)isNegativeNumber.invoke(parser, "-0"));
                                                                                                                assertFalse((boolean)isNegativeNumber.invoke(parser, "-0.0"));
                                                                                                            }

    @Test
                                                                                                        public void testHandleProperties_OptionWithoutArgWithValidValue() throws Exception {
                                                                                                            DefaultParser parser = new DefaultParser();
                                                                                                            
                                                                                                            // Set up mocks using reflection
                                                                                                            Options mockOptions = mock(Options.class);
                                                                                                            CommandLine mockCmd = mock(CommandLine.class);
                                                                                                            
                                                                                                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                            optionsField.setAccessible(true);
                                                                                                            optionsField.set(parser, mockOptions);
                                                                                                            
                                                                                                            Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                            cmdField.setAccessible(true);
                                                                                                            cmdField.set(parser, mockCmd);
                                                                                                            
                                                                                                            Properties properties = new Properties();
                                                                                                            properties.setProperty("flagOption", "true");
                                                                                                            
                                                                                                            Option mockOption = mock(Option.class);
                                                                                                            when(mockOption.hasArg()).thenReturn(false);
                                                                                                            
                                                                                                            when(mockOptions.getOption("flagOption")).thenReturn(mockOption);
                                                                                                            when(mockCmd.hasOption("flagOption")).thenReturn(false);
                                                                                                            when(mockOptions.getOptionGroup(mockOption)).thenReturn(null);
                                                                                                            
                                                                                                            // Get and invoke private handleProperties method
                                                                                                            Method handleProperties = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                            handleProperties.setAccessible(true);
                                                                                                            handleProperties.invoke(parser, properties);
                                                                                                            
                                                                                                            // Verify the option was added by checking the internal state
                                                                                                            Field optionsFieldInCmd = mockCmd.getClass().getDeclaredField("options");
                                                                                                            optionsFieldInCmd.setAccessible(true);
                                                                                                            @SuppressWarnings("unchecked")
                                                                                                            List<Option> options = (List<Option>) optionsFieldInCmd.get(mockCmd);
                                                                                                            assertTrue(options.contains(mockOption));
                                                                                                        }

    @Test
                                                                                                        public void testHandleProperties_MultipleProperties() throws Exception {
                                                                                                            DefaultParser parser = new DefaultParser();
                                                                                                            
                                                                                                            // Set up mocks using reflection
                                                                                                            Options mockOptions = mock(Options.class);
                                                                                                            CommandLine mockCmd = mock(CommandLine.class);
                                                                                                            
                                                                                                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                            optionsField.setAccessible(true);
                                                                                                            optionsField.set(parser, mockOptions);
                                                                                                            
                                                                                                            Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                            cmdField.setAccessible(true);
                                                                                                            cmdField.set(parser, mockCmd);
                                                                                                            
                                                                                                            Properties properties = new Properties();
                                                                                                            properties.setProperty("option1", "value1");
                                                                                                            properties.setProperty("option2", "true");
                                                                                                            properties.setProperty("option3", "no");
                                                                                                            
                                                                                                            Option mockOption1 = mock(Option.class);
                                                                                                            when(mockOption1.hasArg()).thenReturn(true);
                                                                                                            when(mockOption1.getValues()).thenReturn(null);
                                                                                                            
                                                                                                            Option mockOption2 = mock(Option.class);
                                                                                                            when(mockOption2.hasArg()).thenReturn(false);
                                                                                                            
                                                                                                            when(mockOptions.getOption("option1")).thenReturn(mockOption1);
                                                                                                            when(mockOptions.getOption("option2")).thenReturn(mockOption2);
                                                                                                            when(mockOptions.getOption("option3")).thenReturn(mockOption2);
                                                                                                            
                                                                                                            when(mockCmd.hasOption(anyString())).thenReturn(false);
                                                                                                            when(mockOptions.getOptionGroup(any())).thenReturn(null);
                                                                                                            
                                                                                                            // Get and invoke private method
                                                                                                            Method handleProperties = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                            handleProperties.setAccessible(true);
                                                                                                            handleProperties.invoke(parser, properties);
                                                                                                            
                                                                                                            // Verify that the options were processed by checking the command line was updated
                                                                                                            // We can't verify private method calls, so we verify the expected interactions
                                                                                                            verify(mockOptions, times(3)).getOption(anyString());
                                                                                                            verify(mockCmd, atLeastOnce()).hasOption(anyString());
                                                                                                        }

    @Test
                                                                                                        public void testIsArgument_WithNullToken() throws Exception {
                                                                                                            // Setup
                                                                                                            DefaultParser parser = new DefaultParser();
                                                                                                            ExpectedException exceptionRule = ExpectedException.none();
                                                                                                            exceptionRule.expect(NullPointerException.class);
                                                                                                            
                                                                                                            // Get the private method using reflection
                                                                                                            Method method = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                            method.setAccessible(true);
                                                                                                            
                                                                                                            // Test
                                                                                                            method.invoke(parser, (Object) null);
                                                                                                        }

    @Test
                                                                                                        public void testIsNegativeNumber_WithValidPositiveNumbers() throws Exception {
                                                                                                            DefaultParser parser = new DefaultParser();
                                                                                                            Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                            isNegativeNumberMethod.setAccessible(true);
                                                                                                            
                                                                                                            assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1"));
                                                                                                            assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "0.5"));
                                                                                                            assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1234567890.987654321"));
                                                                                                            assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1.0E10"));
                                                                                                            assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1e-10"));
                                                                                                        }

    @Test
                                                                                                    public void testIsNegativeNumber_WithNonNumberStrings() throws Exception {
                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                                        
                                                                                                        assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "abc"));
                                                                                                        assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "123abc"));
                                                                                                        assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1.2.3"));
                                                                                                        assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "--1"));
                                                                                                        assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "++1"));
                                                                                                        assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "1-"));
                                                                                                    }

    @Test
                                                                                                    public void testIsNegativeNumber_WithEmptyOrNull() throws Exception {
                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                        
                                                                                                        // Get the private method using reflection
                                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                                        
                                                                                                        // Test empty string
                                                                                                        assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, ""));
                                                                                                        
                                                                                                        // Test whitespace string
                                                                                                        assertFalse((Boolean) isNegativeNumberMethod.invoke(parser, "   "));
                                                                                                        
                                                                                                        // Test null - should throw NullPointerException
                                                                                                        try {
                                                                                                            isNegativeNumberMethod.invoke(parser, (String) null);
                                                                                                            fail("Expected NullPointerException");
                                                                                                        } catch (InvocationTargetException e) {
                                                                                                            assertTrue(e.getCause() instanceof NullPointerException);
                                                                                                        }
                                                                                                    }

    @Test
                                                                                                    public void testIsNegativeNumber_WithSpecialNumberFormats() throws Exception {
                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                        isNegativeNumberMethod.setAccessible(true);
                                                                                                        
                                                                                                        assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, ".5"));
                                                                                                        assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-.5"));
                                                                                                        assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "1."));
                                                                                                        assertTrue((Boolean) isNegativeNumberMethod.invoke(parser, "-1."));
                                                                                                    }

    @Test
                                                                                                    public void testIsNegativeNumber_WithNumberFormatEdgeCases() throws Exception {
                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                        Method isNegativeNumber = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                        isNegativeNumber.setAccessible(true);
                                                                                                        
                                                                                                        assertFalse((Boolean) isNegativeNumber.invoke(parser, "1e+10"));  // positive scientific notation
                                                                                                        assertTrue((Boolean) isNegativeNumber.invoke(parser, "-1e+10"));  // negative scientific notation
                                                                                                        assertFalse((Boolean) isNegativeNumber.invoke(parser, "1E10"));   // positive scientific notation (uppercase E)
                                                                                                        assertTrue((Boolean) isNegativeNumber.invoke(parser, "-1E10"));   // negative scientific notation (uppercase E)
                                                                                                    }

    @Test
                                                                                                    public void testHandleProperties_OptionWithArgAndExistingValues() throws Exception {
                                                                                                        DefaultParser parser = new DefaultParser();
                                                                                                        
                                                                                                        // Set up mocks using reflection
                                                                                                        Options mockOptions = mock(Options.class);
                                                                                                        CommandLine mockCmd = mock(CommandLine.class);
                                                                                                        
                                                                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                        optionsField.setAccessible(true);
                                                                                                        optionsField.set(parser, mockOptions);
                                                                                                        
                                                                                                        Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                        cmdField.setAccessible(true);
                                                                                                        cmdField.set(parser, mockCmd);
                                                                                                        
                                                                                                        Properties properties = new Properties();
                                                                                                        properties.setProperty("multiArgOption", "newValue");
                                                                                                        
                                                                                                        Option mockOption = mock(Option.class);
                                                                                                        when(mockOption.hasArg()).thenReturn(true);
                                                                                                        when(mockOption.getValues()).thenReturn(new String[]{"existingValue"});
                                                                                                        
                                                                                                        when(mockOptions.getOption("multiArgOption")).thenReturn(mockOption);
                                                                                                        when(mockCmd.hasOption("multiArgOption")).thenReturn(false);
                                                                                                        when(mockOptions.getOptionGroup(mockOption)).thenReturn(null);
                                                                                                        
                                                                                                        // Invoke private method using reflection
                                                                                                        Method handlePropertiesMethod = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                        handlePropertiesMethod.setAccessible(true);
                                                                                                        handlePropertiesMethod.invoke(parser, properties);
                                                                                                        
                                                                                                        // Verify the command line still doesn't have the option
                                                                                                        verify(mockCmd, never()).hasOption("multiArgOption");
                                                                                                    }

    @Test
                                                                                                public void testHandleProperties_OptionWithArg() throws Exception {
                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                    
                                                                                                    // Set up reflection to access private/protected members
                                                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                    optionsField.setAccessible(true);
                                                                                                    Options mockOptions = mock(Options.class);
                                                                                                    optionsField.set(parser, mockOptions);
                                                                                                    
                                                                                                    Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                    cmdField.setAccessible(true);
                                                                                                    CommandLine mockCmd = mock(CommandLine.class);
                                                                                                    cmdField.set(parser, mockCmd);
                                                                                                    
                                                                                                    Properties properties = new Properties();
                                                                                                    properties.setProperty("knownOption", "argValue");
                                                                                                    
                                                                                                    Option mockOption = mock(Option.class);
                                                                                                    when(mockOption.hasArg()).thenReturn(true);
                                                                                                    when(mockOption.getValues()).thenReturn(null);
                                                                                                    
                                                                                                    when(mockOptions.getOption("knownOption")).thenReturn(mockOption);
                                                                                                    when(mockCmd.hasOption("knownOption")).thenReturn(false);
                                                                                                    when(mockOptions.getOptionGroup(mockOption)).thenReturn(null);
                                                                                                    
                                                                                                    // Access private handleProperties method via reflection
                                                                                                    Method handleProperties = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                    handleProperties.setAccessible(true);
                                                                                                    handleProperties.invoke(parser, properties);
                                                                                                    
                                                                                                    // Verify the option was processed by checking if getOption was called
                                                                                                    verify(mockOptions).getOption("knownOption");
                                                                                                    verify(mockCmd).hasOption("knownOption");
                                                                                                }

    @Test
                                                                                                public void testHandleProperties_OptionInGroupWithSelectedOption() throws Exception {
                                                                                                    DefaultParser parser = new DefaultParser();
                                                                                                    
                                                                                                    // Set protected fields using reflection
                                                                                                    Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                                                                    optionsField.setAccessible(true);
                                                                                                    Options mockOptions = mock(Options.class);
                                                                                                    optionsField.set(parser, mockOptions);
                                                                                                    
                                                                                                    Field cmdField = DefaultParser.class.getDeclaredField("cmd");
                                                                                                    cmdField.setAccessible(true);
                                                                                                    CommandLine mockCmd = mock(CommandLine.class);
                                                                                                    cmdField.set(parser, mockCmd);
                                                                                                    
                                                                                                    Properties properties = new Properties();
                                                                                                    properties.setProperty("groupOption", "value");
                                                                                                    
                                                                                                    Option mockOption = mock(Option.class);
                                                                                                    OptionGroup mockGroup = mock(OptionGroup.class);
                                                                                                    Option selectedOption = mock(Option.class);
                                                                                                    
                                                                                                    when(mockOptions.getOption("groupOption")).thenReturn(mockOption);
                                                                                                    when(mockCmd.hasOption("groupOption")).thenReturn(false);
                                                                                                    when(mockOptions.getOptionGroup(mockOption)).thenReturn(mockGroup);
                                                                                                    when(mockGroup.getSelected()).thenReturn(selectedOption.getOpt());
                                                                                                    
                                                                                                    // Call private handleProperties method using reflection
                                                                                                    Method handleProperties = DefaultParser.class.getDeclaredMethod("handleProperties", Properties.class);
                                                                                                    handleProperties.setAccessible(true);
                                                                                                    handleProperties.invoke(parser, properties);
                                                                                                    
                                                                                                    // Verify private handleOption was not called using reflection
                                                                                                    verify(mockOptions, never()).getOption(anyString());
                                                                                                }

    @Test
                                                                                           public void testIsArgumentWithNegativeNumberOption() {
                                                                                               // Setup
                                                                                               DefaultParser parser = new DefaultParser();
                                                                                               String negativeOption = "-1"; // Assuming this is both an option and negative number
                                                                                               
                                                                                               // Mock the behavior of isOption and isNegativeNumber
                                                                                               // We need to mock these since they're private methods, but since we can't mock private methods,
                                                                                               // we'll assume they work as expected based on the input
                                                                                               
                                                                                               // For our test case, we need a token that:
                                                                                               // - isOption(token) returns true
                                                                                               // - isNegativeNumber(token) returns true
                                                                                               
                                                                                               // Since we can't mock private methods, we'll use reflection to test this
                                                                                               try {
                                                                                                   Method isOption = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                                   isOption.setAccessible(true);
                                                                                                   Method isNegativeNumber = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                                   isNegativeNumber.setAccessible(true);
                                                                                                   Method isArgument = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                                   isArgument.setAccessible(true);
                                                                                                   
                                                                                                   // Set up the test scenario where token is both an option and negative number
                                                                                                   when(isOption.invoke(parser, negativeOption)).thenReturn(true);
                                                                                                   when(isNegativeNumber.invoke(parser, negativeOption)).thenReturn(true);
                                                                                                   
                                                                                                   // Test
                                                                                                   boolean result = (boolean) isArgument.invoke(parser, negativeOption);
                                                                                                   
                                                                                                   // Verify - original should return true, mutant will return false
                                                                                                   assertTrue("Should return true for negative number options", result);
                                                                                               } catch (Exception e) {
                                                                                                   fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                               }
                                                                                           }

    @Test
                                                                                           public void testIsArgumentWithNegativeNumberOption1() throws Exception {
                                                                                               // Setup
                                                                                               DefaultParser parser = new DefaultParser();
                                                                                               
                                                                                               // We need to test with a token that would make:
                                                                                               // isOption(token) return true
                                                                                               // isNegativeNumber(token) return true
                                                                                               
                                                                                               // Assuming the implementation treats "-1" as both:
                                                                                               String negativeOption = "-1";
                                                                                               
                                                                                               // Since we can't mock private methods, we'll have to make assumptions
                                                                                               // about how isOption and isNegativeNumber work
                                                                                               
                                                                                               // Expected behavior:
                                                                                               // Original: !true || true => false || true => true
                                                                                               // Mutant: !true => false
                                                                                               
                                                                                               // So we need to verify the method returns true for this case
                                                                                               // This test will pass with original code but fail with mutant
                                                                                               
                                                                                               // Note: This assumes the actual implementations of isOption and isNegativeNumber
                                                                                               // treat "-1" as both an option and negative number
                                                                                               
                                                                                               // Use reflection to access private method
                                                                                               Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                               isArgumentMethod.setAccessible(true);
                                                                                               boolean result = (boolean) isArgumentMethod.invoke(parser, "-1");
                                                                                               
                                                                                               assertTrue("Should return true for negative number options", result);
                                                                                           }

    @Test
                                                                                       public void testIsArgument_NonOptionNonNegativeNumber_ShouldReturnTrue() {
                                                                                           // Setup test data
                                                                                           DefaultParser parser = new DefaultParser();
                                                                                           String testToken = "regularArgument";
                                                                                           
                                                                                           // Mock the behavior of isOption and isNegativeNumber
                                                                                           // Using reflection since methods are private
                                                                                           try {
                                                                                               Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                               isOptionMethod.setAccessible(true);
                                                                                               when(isOptionMethod.invoke(parser, testToken)).thenReturn(false);
                                                                                               
                                                                                               Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                               isNegativeNumberMethod.setAccessible(true);
                                                                                               when(isNegativeNumberMethod.invoke(parser, testToken)).thenReturn(false);
                                                                                               
                                                                                               // Call the method under test
                                                                                               Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                               isArgumentMethod.setAccessible(true);
                                                                                               boolean result = (boolean) isArgumentMethod.invoke(parser, testToken);
                                                                                               
                                                                                               // Verify the result
                                                                                               assertTrue("Should return true for non-option, non-negative number", result);
                                                                                           } catch (Exception e) {
                                                                                               fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                           }
                                                                                       }

    @Test
                                                                                      public void testIsArgument_NonOptionNonNegativeNumber_ShouldReturnTrue1() throws Exception {
                                                                                          // Create instance of parser
                                                                                          DefaultParser parser = new DefaultParser();
                                                                                          
                                                                                          // Get private methods using reflection
                                                                                          Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                          isArgumentMethod.setAccessible(true);
                                                                                          
                                                                                          Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                          isOptionMethod.setAccessible(true);
                                                                                          
                                                                                          Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                          isNegativeNumberMethod.setAccessible(true);
                                                                                          
                                                                                          // Create a spy to verify method calls
                                                                                          DefaultParser spyParser = spy(parser);
                                                                                          
                                                                                          // Test with a regular argument (not option, not negative number)
                                                                                          String testToken = "regularArgument";
                                                                                          
                                                                                          // Verify the private method returns true for non-option, non-negative number
                                                                                          boolean result = (boolean) isArgumentMethod.invoke(spyParser, testToken);
                                                                                          
                                                                                          // Verify
                                                                                          assertTrue("Should return true for non-option, non-negative number", result);
                                                                                      }

    @Test
                                                                                 public void testIsArgumentWithNegativeNumberOption2() throws Exception {
                                                                                     // Setup
                                                                                     DefaultParser parser = new DefaultParser();
                                                                                     String negativeOption = "-1";
                                                                                     
                                                                                     // Get private methods via reflection
                                                                                     Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                     isOptionMethod.setAccessible(true);
                                                                                     Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                     isNegativeNumberMethod.setAccessible(true);
                                                                                     Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                     isArgumentMethod.setAccessible(true);
                                                                                     
                                                                                     // Test the conditions
                                                                                     boolean isOption = (boolean) isOptionMethod.invoke(parser, negativeOption);
                                                                                     boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, negativeOption);
                                                                                     
                                                                                     // Verify the negativeOption is both an option and negative number
                                                                                     // (This might need adjustment based on actual implementation)
                                                                                     if (!isOption || !isNegativeNumber) {
                                                                                         fail("Test setup failed - negativeOption should be both option and negative number");
                                                                                     }
                                                                                     
                                                                                     // Test the actual method
                                                                                     boolean result = (boolean) isArgumentMethod.invoke(parser, negativeOption);
                                                                                     
                                                                                     // Original would return true (is negative number)
                                                                                     // Mutant would return false (!isNegativeNumber is false)
                                                                                     assertTrue("Should return true for negative number option", result);
                                                                                 }

    @Test
                                                                                 public void testIsArgumentWithNegativeNumberNonOption() {
                                                                                     // Setup
                                                                                     DefaultParser parser = new DefaultParser();
                                                                                     String negativeNonOption = "-123";
                                                                                     
                                                                                     // Since we can't mock private methods, we'll test the actual behavior
                                                                                     // The test verifies that negative numbers are treated as arguments
                                                                                     try {
                                                                                         Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                         isArgumentMethod.setAccessible(true);
                                                                                         boolean result = (boolean) isArgumentMethod.invoke(parser, negativeNonOption);
                                                                                         assertTrue(result);
                                                                                     } catch (Exception e) {
                                                                                         fail("Failed to test private method via reflection: " + e.getMessage());
                                                                                     }
                                                                                 }

    @Test
                                                                                 public void testIsArgumentWithPositiveNumberOption() {
                                                                                     // Setup
                                                                                     DefaultParser parser = new DefaultParser();
                                                                                     Options options = new Options();
                                                                                     options.addOption("1", false, "test option");
                                                                                     String[] args = {"1"};
                                                                                     
                                                                                     // Test through public parse method which internally uses isArgument
                                                                                     try {
                                                                                         CommandLine cmd = parser.parse(options, args);
                                                                                         // If parse succeeds, then "1" was treated as an option (not argument)
                                                                                         // So isArgument("1") should return false
                                                                                         assertFalse(cmd.getArgList().contains("1"));
                                                                                     } catch (ParseException e) {
                                                                                         fail("Parsing failed unexpectedly");
                                                                                     }
                                                                                 }

    @Test
                                                                                 public void testIsArgumentWithPositiveNumberNonOption() {
                                                                                     // Setup
                                                                                     DefaultParser parser = new DefaultParser();
                                                                                     Options options = new Options();
                                                                                     String positiveNonOption = "123";
                                                                                     
                                                                                     // Test through public parse method
                                                                                     try {
                                                                                         CommandLine cmd = parser.parse(options, new String[]{positiveNonOption});
                                                                                         // Verify the argument was treated as a non-option argument
                                                                                         assertEquals(1, cmd.getArgList().size());
                                                                                         assertEquals(positiveNonOption, cmd.getArgList().get(0));
                                                                                     } catch (ParseException e) {
                                                                                         fail("Parsing failed: " + e.getMessage());
                                                                                     }
                                                                                 }

    @Test
                                                                                 public void testIsArgumentWithNegativeNumberOption3() throws Exception {
                                                                                     // Setup
                                                                                     DefaultParser parser = new DefaultParser();
                                                                                     String negativeOption = "-1";
                                                                                     
                                                                                     // Get private methods via reflection
                                                                                     Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                     isOptionMethod.setAccessible(true);
                                                                                     Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                     isNegativeNumberMethod.setAccessible(true);
                                                                                     Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                     isArgumentMethod.setAccessible(true);
                                                                                     
                                                                                     // Test the behavior
                                                                                     boolean isOption = (boolean) isOptionMethod.invoke(parser, negativeOption);
                                                                                     boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, negativeOption);
                                                                                     boolean result = (boolean) isArgumentMethod.invoke(parser, negativeOption);
                                                                                     
                                                                                     // Verify the expected behavior
                                                                                     assertTrue("Should return true for negative number option", 
                                                                                                result == (!isOption || isNegativeNumber));
                                                                                 }

    @Test
                                                                            public void testIsArgument_OptionButNotNegativeNumber_ShouldReturnFalse() throws Exception {
                                                                                // Create a real parser instance using reflection since there are no public constructors
                                                                                Constructor<DefaultParser> constructor = DefaultParser.class.getDeclaredConstructor();
                                                                                constructor.setAccessible(true);
                                                                                DefaultParser parser = constructor.newInstance();
                                                                                
                                                                                // Get the private methods we need to test
                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                isOptionMethod.setAccessible(true);
                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                isArgumentMethod.setAccessible(true);
                                                                                
                                                                                // Test with an option token that's not a negative number (e.g., "-option")
                                                                                String optionToken = "-option";
                                                                                
                                                                                // Verify the private method behaviors
                                                                                boolean isOption = (boolean) isOptionMethod.invoke(parser, optionToken);
                                                                                boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, optionToken);
                                                                                boolean result = (boolean) isArgumentMethod.invoke(parser, optionToken);
                                                                                
                                                                                // Verify the method returns false (original behavior)
                                                                                assertFalse(result);
                                                                                
                                                                                // Verify the expected intermediate results
                                                                                // Note: These assertions verify our understanding of the test case,
                                                                                // not necessarily the implementation details
                                                                                assertTrue(isOption);
                                                                                assertFalse(isNegativeNumber);
                                                                            }

    @Test
                                                                            public void testIsArgument_NegativeNumber_ShouldReturnTrue() throws Exception {
                                                                                DefaultParser parser = new DefaultParser();
                                                                                
                                                                                // Get the private method using reflection
                                                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                                isArgumentMethod.setAccessible(true);
                                                                                
                                                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                                isOptionMethod.setAccessible(true);
                                                                                
                                                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                                isNegativeNumberMethod.setAccessible(true);
                                                                                
                                                                                String negativeNumber = "-123";
                                                                                
                                                                                // Verify the negative number is not an option but is a negative number
                                                                                boolean isOption = (boolean) isOptionMethod.invoke(parser, negativeNumber);
                                                                                boolean isNegative = (boolean) isNegativeNumberMethod.invoke(parser, negativeNumber);
                                                                                
                                                                                // Test the actual method
                                                                                boolean result = (boolean) isArgumentMethod.invoke(parser, negativeNumber);
                                                                                
                                                                                assertTrue(result);
                                                                                assertFalse(isOption);
                                                                                assertTrue(isNegative);
                                                                            }

    @Test
                                                                public void testIsArgument_NotOptionNotNegativeNumber_ShouldReturnTrue() throws Exception {
                                                                    DefaultParser parser = new DefaultParser();
                                                                    
                                                                    // Use reflection to access private methods
                                                                    Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                                    isOptionMethod.setAccessible(true);
                                                                    Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                                    isNegativeNumberMethod.setAccessible(true);
                                                                    Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                                    isArgumentMethod.setAccessible(true);
                                                                    
                                                                    // Create a spy to verify method calls
                                                                    DefaultParser spyParser = spy(parser);
                                                                    
                                                                    // Instead of mocking private methods, we'll let them execute normally
                                                                    // and verify their behavior through reflection
                                                                    String regularToken = "regular";
                                                                    boolean result = (boolean) isArgumentMethod.invoke(spyParser, regularToken);
                                                                    
                                                                    assertTrue(result);
                                                                    
                                                                    // Verify the private method calls using reflection
                                                                    boolean isOptionResult = (boolean) isOptionMethod.invoke(spyParser, regularToken);
                                                                    boolean isNegativeNumberResult = (boolean) isNegativeNumberMethod.invoke(spyParser, regularToken);
                                                                    
                                                                    // Assert that these methods returned false for our regular token
                                                                    assertFalse(isOptionResult);
                                                                    assertFalse(isNegativeNumberResult);
                                                                }

    @Test
                                                           public void testIsArgument_ShouldReturnTrueForNegativeNumberOption() throws Exception {
                                                               // Setup
                                                               DefaultParser parser = new DefaultParser();
                                                               String negativeOption = "-1"; // This is both an option (starts with -) and negative number
                                                               
                                                               // Get the private method using reflection
                                                               Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                               isArgumentMethod.setAccessible(true);
                                                               
                                                               // Invoke the method
                                                               boolean result = (boolean) isArgumentMethod.invoke(parser, negativeOption);
                                                               
                                                               // Assert
                                                               assertTrue("Should return true for negative number that looks like option", result);
                                                               
                                                               // This test would pass with original code but fail with mutated code
                                                           }

    @Test
                                                      public void testIsArgumentWithNegativeNumberOption4() {
                                                          DefaultParser parser = new DefaultParser();
                                                          
                                                          // Test case where token is both an option and negative number
                                                          String negativeOption = "-1";
                                                          
                                                          try {
                                                              // Get private methods via reflection
                                                              Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                              Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                              Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                              
                                                              // Make methods accessible
                                                              isOptionMethod.setAccessible(true);
                                                              isNegativeNumberMethod.setAccessible(true);
                                                              isArgumentMethod.setAccessible(true);
                                                              
                                                              // Test case 1: token is both option and negative number
                                                              boolean isOption = (boolean) isOptionMethod.invoke(parser, negativeOption);
                                                              boolean isNegative = (boolean) isNegativeNumberMethod.invoke(parser, negativeOption);
                                                              boolean result = (boolean) isArgumentMethod.invoke(parser, negativeOption);
                                                              
                                                              // Assert true because negative number should make it return true
                                                              assertTrue(result);
                                                              
                                                              // Test case 2: token is not an option but is negative number
                                                              String negativeNonOption = "-123";
                                                              isOption = (boolean) isOptionMethod.invoke(parser, negativeNonOption);
                                                              isNegative = (boolean) isNegativeNumberMethod.invoke(parser, negativeNonOption);
                                                              result = (boolean) isArgumentMethod.invoke(parser, negativeNonOption);
                                                              assertTrue(result);
                                                              
                                                              // Test case 3: token is not an option and not negative number
                                                              String regularArgument = "arg";
                                                              isOption = (boolean) isOptionMethod.invoke(parser, regularArgument);
                                                              isNegative = (boolean) isNegativeNumberMethod.invoke(parser, regularArgument);
                                                              result = (boolean) isArgumentMethod.invoke(parser, regularArgument);
                                                              assertTrue(result);
                                                              
                                                              // Test case 4: token is an option but not negative number
                                                              String regularOption = "-o";
                                                              isOption = (boolean) isOptionMethod.invoke(parser, regularOption);
                                                              isNegative = (boolean) isNegativeNumberMethod.invoke(parser, regularOption);
                                                              result = (boolean) isArgumentMethod.invoke(parser, regularOption);
                                                              assertFalse(result);
                                                              
                                                          } catch (Exception e) {
                                                              fail("Test failed due to reflection exception: " + e.getMessage());
                                                          }
                                                      }

    @Test
                                                      public void testIsArgumentWithNegativeNumberOption5() throws Exception {
                                                          DefaultParser parser = new DefaultParser();
                                                          
                                                          // Test case that would expose the mutant
                                                          // We need a token that is both an option and a negative number
                                                          // In real implementation, this might be something like "-1" where:
                                                          // - isOption("-1") returns true (it's a valid option)
                                                          // - isNegativeNumber("-1") returns true (it's a negative number)
                                                          
                                                          // The original code would return true (because it's negative number)
                                                          // The mutated code would return true (but for wrong reason - because it's option)
                                                          // So this test case alone wouldn't catch the mutant
                                                          
                                                          // To catch the mutant, we need to verify that isNegativeNumber is actually called
                                                          // when the token is an option
                                                          
                                                          // Since we can't verify method calls without mocking, we need another approach
                                                          
                                                          // Alternative test case: token is an option but NOT negative number
                                                          // Original code: return false (since !isOption=false and isNegativeNumber=false)
                                                          // Mutated code: return true (since !isOption=false but isOption=true)
                                                          
                                                          // This would expose the mutant
                                                          String optionButNotNegative = "-o";
                                                          // Assuming in real implementation:
                                                          // isOption("-o") returns true
                                                          // isNegativeNumber("-o") returns false
                                                          
                                                          // Use reflection to access private method
                                                          Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                          isArgumentMethod.setAccessible(true);
                                                          boolean result = (boolean) isArgumentMethod.invoke(parser, optionButNotNegative);
                                                          
                                                          // Original code should return false
                                                          // Mutated code would return true
                                                          assertFalse("Should return false for option that's not negative number", result);
                                                      }

    @Test
                                                 public void testIsArgument_ShouldReturnTrueForNegativeNumberOption1() throws Exception {
                                                     // Setup
                                                     DefaultParser parser = new DefaultParser();
                                                     String negativeOption = "-1"; // Example negative number option
                                                     
                                                     // Use reflection to test private methods
                                                     Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                     isOptionMethod.setAccessible(true);
                                                     Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                     isNegativeNumberMethod.setAccessible(true);
                                                     Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                     isArgumentMethod.setAccessible(true);
                                                     
                                                     // Verify the behavior of isArgument based on isOption and isNegativeNumber
                                                     boolean isOption = (boolean) isOptionMethod.invoke(parser, negativeOption);
                                                     boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, negativeOption);
                                                     boolean result = (boolean) isArgumentMethod.invoke(parser, negativeOption);
                                                     
                                                     // The expected result should be !isOption || isNegativeNumber
                                                     boolean expected = !isOption || isNegativeNumber;
                                                     
                                                     // Verify
                                                     assertEquals("Should return true for negative number option", expected, result);
                                                 }

    @Test
                                            public void testIsArgumentWithNegativeNumberOption6() {
                                                // Setup
                                                DefaultParser parser = new DefaultParser();
                                                String negativeOption = "-1"; // Negative number that looks like an option
                                                
                                                // Since we can't test private methods directly, we need to test this through
                                                // the public parse method with appropriate options
                                                Options options = new Options();
                                                options.addOption("a", "alpha", false, "test option");
                                                
                                                // Test that the negative number is treated as an argument
                                                try {
                                                    CommandLine cmd = parser.parse(options, new String[] {negativeOption});
                                                    assertTrue(cmd.getArgList().contains(negativeOption));
                                                } catch (ParseException e) {
                                                    fail("Unexpected ParseException: " + e.getMessage());
                                                }
                                            }

    @Test
                                            public void testIsArgumentWithNegativeNumberNonOption1() throws Exception {
                                                // Setup
                                                DefaultParser parser = new DefaultParser();
                                                String negativeNonOption = "-123abc"; // Negative number that doesn't look like an option
                                                
                                                // Get private methods via reflection
                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                isOptionMethod.setAccessible(true);
                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                isNegativeNumberMethod.setAccessible(true);
                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                isArgumentMethod.setAccessible(true);
                                                
                                                // Create spy parser
                                                DefaultParser spyParser = spy(parser);
                                                
                                                // Mock the behavior of helper methods
                                                when(isOptionMethod.invoke(spyParser, negativeNonOption)).thenReturn(false);
                                                when(isNegativeNumberMethod.invoke(spyParser, negativeNonOption)).thenReturn(true);
                                                
                                                // Test - should return true for negative numbers
                                                assertTrue((Boolean) isArgumentMethod.invoke(spyParser, negativeNonOption));
                                            }

    @Test
                                            public void testIsArgumentWithPositiveOption() throws Exception {
                                                // Setup
                                                DefaultParser parser = new DefaultParser();
                                                String positiveOption = "-a"; // Positive option (not a number)
                                                
                                                // Get private methods using reflection
                                                Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                                Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                                Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                                
                                                // Make methods accessible
                                                isArgumentMethod.setAccessible(true);
                                                isOptionMethod.setAccessible(true);
                                                isNegativeNumberMethod.setAccessible(true);
                                                
                                                // Verify the behavior of isOption and isNegativeNumber for our test case
                                                boolean isOption = (boolean) isOptionMethod.invoke(parser, positiveOption);
                                                boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, positiveOption);
                                                
                                                // Test - should return false for positive options
                                                boolean result = (boolean) isArgumentMethod.invoke(parser, positiveOption);
                                                assertFalse("Positive option should not be considered an argument", result);
                                            }

    @Test
                                       public void testIsArgument_OptionButNotNegativeNumber_ShouldReturnFalse1() {
                                           // Setup
                                           DefaultParser parser = new DefaultParser();
                                           String token = "-option";
                                           
                                           try {
                                               // Get private methods via reflection
                                               Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                               Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                               Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                               
                                               // Make methods accessible
                                               isOptionMethod.setAccessible(true);
                                               isNegativeNumberMethod.setAccessible(true);
                                               isArgumentMethod.setAccessible(true);
                                               
                                               // Verify the behavior
                                               boolean isOption = (boolean) isOptionMethod.invoke(parser, token);
                                               boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, token);
                                               boolean isArgument = (boolean) isArgumentMethod.invoke(parser, token);
                                               
                                               // Test the logic
                                               assertEquals(!isOption || isNegativeNumber, isArgument);
                                               assertFalse("Should return false for option that's not negative number", isArgument);
                                           } catch (Exception e) {
                                               fail("Reflection failed: " + e.getMessage());
                                           }
                                       }

    @Test
                                  public void testIsArgument_WithNegativeNumberOption_ShouldReturnTrue() throws Exception {
                                      // Setup
                                      DefaultParser parser = new DefaultParser();
                                      String negativeNumberOption = "-123"; // Example of negative number that could be an option
                                      
                                      // Use reflection to access private methods
                                      Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                      isArgumentMethod.setAccessible(true);
                                      Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                                      isOptionMethod.setAccessible(true);
                                      Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                                      isNegativeNumberMethod.setAccessible(true);
                                      
                                      // Verify the negative number is both an option and a negative number
                                      boolean isOption = (boolean) isOptionMethod.invoke(parser, negativeNumberOption);
                                      boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, negativeNumberOption);
                                      
                                      // Test and verify
                                      boolean result = (boolean) isArgumentMethod.invoke(parser, negativeNumberOption);
                                      assertTrue("Should return true for negative number even if it's an option", 
                                                result);
                                  }

    @Test
                             public void testIsArgument_OptionButNotNegativeNumber_ShouldReturnFalse2() {
                                 // Since we can't mock private methods and DefaultParser has no constructors,
                                 // we'll test the behavior indirectly through the parse method
                                 
                                 // Create real objects needed for parsing
                                 Options options = new Options();
                                 options.addOption("option", false, "test option");
                                 
                                 // Create parser instance (assuming it's accessible through some factory method)
                                 DefaultParser parser = new DefaultParser();
                                 
                                 // Test with a token that is an option but not a negative number
                                 String testToken = "-option";
                                 
                                 // The actual test is that when we parse arguments containing this token,
                                 // it should be treated as an option, not an argument
                                 try {
                                     CommandLine cmd = parser.parse(options, new String[]{testToken});
                                     // Verify the option was recognized
                                     assertTrue("Option should be recognized", cmd.hasOption("option"));
                                 } catch (ParseException e) {
                                     fail("Parsing should not throw exception for valid option");
                                 }
                             }

    @Test
                             public void testIsArgument_OptionAndNegativeNumber_ShouldReturnTrue() throws Exception {
                                 DefaultParser parser = new DefaultParser();
                                 
                                 // Since we can't mock private methods, we'll test the actual behavior
                                 // The token "-123" should be treated as both an option and negative number
                                 // According to the method logic: !isOption(token) || isNegativeNumber(token)
                                 // Since it's a negative number, the result should be true
                                 
                                 // Use reflection to test private method
                                 Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                                 isArgumentMethod.setAccessible(true);
                                 
                                 String testToken = "-123";
                                 boolean result = (boolean) isArgumentMethod.invoke(parser, testToken);
                                 
                                 assertTrue("For an option that's a negative number, should return true", result);
                             }

    @Test
                             public void testIsArgument_NotOption_ShouldReturnTrue() {
                                 DefaultParser parser = new DefaultParser();
                                 Options options = new Options();
                                 
                                 // Create a test argument that should be treated as non-option
                                 String[] args = {"argument"};
                                 
                                 try {
                                     // This will internally call isArgument()
                                     CommandLine cmd = parser.parse(options, args);
                                     
                                     // Verify the argument was accepted (not treated as option)
                                     assertEquals(1, cmd.getArgList().size());
                                     assertEquals("argument", cmd.getArgList().get(0));
                                 } catch (ParseException e) {
                                     fail("Should not throw exception for non-option argument");
                                 }
                             }

    @Test
                        public void testIsArgument_WhenOptionIsNegativeNumber_ShouldReturnTrue() throws Exception {
                            // Setup
                            DefaultParser parser = new DefaultParser();
                            String negativeOption = "-1"; // Assuming this is both an option and negative number
                            
                            // Use reflection to access private method
                            Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                            isArgumentMethod.setAccessible(true);
                            
                            // Test - should return true because even though it's an option, it's a negative number
                            boolean result = (boolean) isArgumentMethod.invoke(parser, negativeOption);
                            
                            // Verify - this will fail for the mutant but pass for original
                            assertTrue("Should return true for negative number even if it's an option", result);
                        }

    @Test
                   public void testIsArgument_ShouldReturnTrueWhenNegativeNumberOption() throws Exception {
                       // Setup
                       DefaultParser parser = new DefaultParser();
                       
                       // Get private methods using reflection
                       Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
                       isOptionMethod.setAccessible(true);
                       Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
                       isNegativeNumberMethod.setAccessible(true);
                       Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                       isArgumentMethod.setAccessible(true);
                       
                       // Test case 1: Negative number that looks like an option
                       String negativeOption = "-1";
                       boolean isOption = (boolean) isOptionMethod.invoke(parser, negativeOption);
                       boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, negativeOption);
                       boolean result = (boolean) isArgumentMethod.invoke(parser, negativeOption);
                       
                       // Verify - should return true because it's a negative number
                       assertTrue("Should return true for negative number even if it looks like an option", 
                                  result == (!isOption || isNegativeNumber));
                       
                       // Additional test cases for completeness
                       // Case 1: Not an option, not negative number
                       String plainArg = "plainArg";
                       isOption = (boolean) isOptionMethod.invoke(parser, plainArg);
                       isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, plainArg);
                       result = (boolean) isArgumentMethod.invoke(parser, plainArg);
                       assertTrue(result == (!isOption || isNegativeNumber));
                       
                       // Case 2: Not an option, is negative number
                       String negativeNumber = "-123";
                       isOption = (boolean) isOptionMethod.invoke(parser, negativeNumber);
                       isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, negativeNumber);
                       result = (boolean) isArgumentMethod.invoke(parser, negativeNumber);
                       assertTrue(result == (!isOption || isNegativeNumber));
                       
                       // Case 3: Is option, not negative number
                       String option = "-v";
                       isOption = (boolean) isOptionMethod.invoke(parser, option);
                       isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, option);
                       result = (boolean) isArgumentMethod.invoke(parser, option);
                       assertFalse(result == (!isOption || isNegativeNumber));
                   }

    @Test
              public void testIsArgument_ShouldReturnFalseForPositiveOption() {
                  // Setup
                  DefaultParser parser = new DefaultParser();
                  Options options = new Options();
                  options.addOption("a", false, "test option");
                  String[] args = {"-a"}; // This is an option but not a negative number
                  
                  // Test - parse should handle -a as an option, not an argument
                  try {
                      CommandLine cmd = parser.parse(options, args);
                      // Verify that -a was treated as an option (not an argument)
                      assertTrue("Option -a should be recognized", cmd.hasOption("a"));
                  } catch (ParseException e) {
                      fail("Unexpected ParseException: " + e.getMessage());
                  }
              }

    @Test
              public void testIsArgument_ShouldReturnTrueForNegativeNumber() throws Exception {
                  // Setup
                  DefaultParser parser = new DefaultParser();
                  String negativeNumber = "-123"; // This is a negative number
                  
                  // Get the private method using reflection
                  Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                  isArgumentMethod.setAccessible(true);
                  
                  // Test - should return true since it's a negative number
                  boolean result = (boolean) isArgumentMethod.invoke(parser, negativeNumber);
                  
                  // Assert
                  assertTrue("Should return true for negative number", result);
              }

    @Test
              public void testIsArgument_ShouldReturnTrueForNonOption() throws Exception {
                  // Setup
                  DefaultParser parser = new DefaultParser();
                  String nonOption = "filename"; // This is not an option
                  
                  // Get the private method using reflection
                  Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
                  isArgumentMethod.setAccessible(true);
                  
                  // Test - should return true since it's not an option
                  boolean result = (boolean) isArgumentMethod.invoke(parser, nonOption);
                  
                  // Assert
                  assertTrue("Should return true for non-option token", result);
              }

    @Test
         public void testIsArgumentWithNegativeNumberOption7() throws Exception {
             DefaultParser parser = new DefaultParser();
             
             // Get the private isArgument method using reflection
             Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
             isArgumentMethod.setAccessible(true);
             
             // Test case 1: Token is a negative number option (should return true)
             // Assuming "-1" is both an option and a negative number
             assertTrue("Should return true for negative number options", 
                        (Boolean) isArgumentMethod.invoke(parser, "-1"));
             
             // Test case 2: Token is a regular option (should return false)
             // Assuming "-a" is an option but not a negative number
             assertFalse("Should return false for regular options", 
                        (Boolean) isArgumentMethod.invoke(parser, "-a"));
             
             // Test case 3: Token is not an option (should return true regardless of negative number status)
             // Assuming "arg" is not an option
             assertTrue("Should return true for non-option tokens", 
                        (Boolean) isArgumentMethod.invoke(parser, "arg"));
         }

    @Test
    public void testIsArgument_WhenTokenIsOptionAndNegativeNumber_ShouldReturnTrue() throws Exception {
        // Setup
        DefaultParser parser = new DefaultParser();
        String negativeOption = "-1"; // Assuming this is both an option and negative number
        
        // Get the private isArgument method using reflection
        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
        isArgumentMethod.setAccessible(true);
        
        // Test
        boolean result = (boolean) isArgumentMethod.invoke(parser, negativeOption);
        
        // Verify
        assertTrue("Should return true for negative number even if it's an option", result);
        
        // Additional verification that the method follows the expected logic
        // Get the private isOption and isNegativeNumber methods
        Method isOptionMethod = DefaultParser.class.getDeclaredMethod("isOption", String.class);
        Method isNegativeNumberMethod = DefaultParser.class.getDeclaredMethod("isNegativeNumber", String.class);
        isOptionMethod.setAccessible(true);
        isNegativeNumberMethod.setAccessible(true);
        
        boolean isOption = (boolean) isOptionMethod.invoke(parser, negativeOption);
        boolean isNegativeNumber = (boolean) isNegativeNumberMethod.invoke(parser, negativeOption);
        
        // Verify the method follows the expected logic: !isOption || isNegativeNumber
        assertEquals("Method should follow !isOption || isNegativeNumber logic", 
                    !isOption || isNegativeNumber, result);
    }

    @Test
    public void testIsArgument_WhenTokenIsNotOptionButIsNegativeNumber_ShouldReturnTrue() throws Exception {
        // Setup
        DefaultParser parser = new DefaultParser();
        String negativeNonOption = "-123"; // Negative number but not an option
        
        // Use reflection to access private isArgument method
        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
        isArgumentMethod.setAccessible(true);
        
        // Test
        boolean result = (boolean) isArgumentMethod.invoke(parser, negativeNonOption);
        
        // Verify
        assertTrue("Should return true for negative number when it's not an option", result);
    }

    @Test
    public void testIsArgument_WhenTokenIsOptionAndNotNegativeNumber_ShouldReturnFalse() throws Exception {
        // Setup
        DefaultParser parser = new DefaultParser();
        String option = "-f"; // An option that's not a negative number
        
        // Get the private method using reflection
        Method isArgumentMethod = DefaultParser.class.getDeclaredMethod("isArgument", String.class);
        isArgumentMethod.setAccessible(true);
        
        // Test
        boolean result = (boolean) isArgumentMethod.invoke(parser, option);
        
        // Verify
        assertFalse("Should return false for option that's not negative number", result);
        
        // This will catch the mutation because:
        // Original: !true || false → false || false → false
        // Mutated: !true || true → false || true → true
        // So original returns false, mutated returns true
    }


}
