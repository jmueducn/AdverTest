package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
 
public class HelpFormatterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                 public void testFindWrapPos_NewLineBeforeWidth() {
                                     String text = "This is a test\nstring";
                                     int width = 20;
                                     int startPos = 0;
                                     HelpFormatter helpFormatter = new HelpFormatter();
                                     try {
                                         Method method = HelpFormatter.class.getDeclaredMethod("findWrapPos", String.class, int.class, int.class);
                                         method.setAccessible(true);
                                         int result = (int) method.invoke(helpFormatter, text, width, startPos);
                                         assertEquals(13, result); // Should return position right after '\n'
                                     } catch (Exception e) {
                                         fail("Failed to invoke findWrapPos method");
                                     }
                                 }

    @Test
                                 public void testFindWrapPos_TextEndsAtWidth() {
                                     HelpFormatter helpFormatter = new HelpFormatter();
                                     String text = "Exactly ten";
                                     int width = 10;
                                     int startPos = 0;
                                     try {
                                         Method method = HelpFormatter.class.getDeclaredMethod("findWrapPos", String.class, int.class, int.class);
                                         method.setAccessible(true);
                                         int result = (int) method.invoke(helpFormatter, text, width, startPos);
                                         assertEquals(-1, result); // Should return -1 when text ends at width
                                     } catch (Exception e) {
                                         fail("Failed to invoke findWrapPos method");
                                     }
                                 }

    @Test
                                 public void testFindWrapPos_EmptyString() throws Exception {
                                     String text = "";
                                     int width = 10;
                                     int startPos = 0;
                                     
                                     // Create HelpFormatter instance
                                     HelpFormatter helpFormatter = new HelpFormatter();
                                     
                                     // Use reflection to access protected method
                                     Method method = HelpFormatter.class.getDeclaredMethod(
                                         "findWrapPos", String.class, int.class, int.class);
                                     method.setAccessible(true);
                                     int result = (int) method.invoke(helpFormatter, text, width, startPos);
                                     
                                     assertEquals(-1, result); // Should return -1 for empty string
                                 }

    @Test
                                 public void testFindWrapPos_NegativeStartPos() throws Exception {
                                     HelpFormatter helpFormatter = new HelpFormatter();
                                     String text = "Test text";
                                     int width = 10;
                                     int startPos = -5;
                                     
                                     // Use reflection to access protected method
                                     Method method = HelpFormatter.class.getDeclaredMethod("findWrapPos", String.class, int.class, int.class);
                                     method.setAccessible(true);
                                     int result = (int) method.invoke(helpFormatter, text, width, startPos);
                                     
                                     assertEquals(4, result); // Should handle negative startPos by effectively starting at 0
                                 }

    @Test
                             public void testFindWrapPos_TabBeforeWidth() throws Exception {
                                 HelpFormatter helpFormatter = new HelpFormatter();
                                 String text = "This is a test\tstring";
                                 int width = 20;
                                 int startPos = 0;
                                 
                                 // Use reflection to access protected method
                                 Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                     "findWrapPos", String.class, int.class, int.class);
                                 findWrapPosMethod.setAccessible(true);
                                 int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                 
                                 assertEquals(13, result); // Should return position right after '\t'
                             }

    @Test
                             public void testFindWrapPos_NoWrapNeeded() throws Exception {
                                 HelpFormatter helpFormatter = new HelpFormatter();
                                 String text = "Short text";
                                 int width = 20;
                                 int startPos = 0;
                                 
                                 // Use reflection to access protected method
                                 Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                     "findWrapPos", String.class, int.class, int.class);
                                 findWrapPosMethod.setAccessible(true);
                                 int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                 
                                 assertEquals(-1, result); // Should return -1 when no wrapping needed
                             }

    @Test
                             public void testFindWrapPos_WrapAtLastSpace() throws Exception {
                                 HelpFormatter helpFormatter = new HelpFormatter();
                                 String text = "This is a longer text that needs wrapping";
                                 int width = 15;
                                 int startPos = 0;
                                 
                                 // Use reflection to access protected method
                                 Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                     "findWrapPos", String.class, int.class, int.class);
                                 findWrapPosMethod.setAccessible(true);
                                 int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                 
                                 assertEquals(7, result); // Should wrap at last space before width
                             }

    @Test
                             public void testFindWrapPos_NoSpaceFound() throws Exception {
                                 HelpFormatter helpFormatter = new HelpFormatter();
                                 String text = "ThisIsALongWordWithoutAnySpaces";
                                 int width = 10;
                                 int startPos = 0;
                                 
                                 // Use reflection to access protected method
                                 Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                     "findWrapPos", String.class, int.class, int.class);
                                 findWrapPosMethod.setAccessible(true);
                                 int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                 
                                 assertEquals(10, result); // Should hard-wrap at width when no space found
                             }

    @Test
                             public void testFindWrapPos_StartPosNotZero() throws Exception {
                                 HelpFormatter helpFormatter = new HelpFormatter();
                                 String text = "First part Second part Third part";
                                 int width = 10;
                                 int startPos = 11;
                                 
                                 // Use reflection to access protected method
                                 Method findWrapPos = HelpFormatter.class.getDeclaredMethod(
                                     "findWrapPos", String.class, int.class, int.class);
                                 findWrapPos.setAccessible(true);
                                 int result = (Integer) findWrapPos.invoke(helpFormatter, text, width, startPos);
                                 
                                 assertEquals(17, result); // Should find space in "Second part"
                             }

    @Test
                             public void testFindWrapPos_NullText() throws Exception {
                                 org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                 exceptionRule.expect(NullPointerException.class);
                                 org.apache.commons.cli.HelpFormatter helpFormatter = new org.apache.commons.cli.HelpFormatter();
                                 
                                 // Use reflection to access protected method
                                 java.lang.reflect.Method method = org.apache.commons.cli.HelpFormatter.class.getDeclaredMethod(
                                     "findWrapPos", String.class, int.class, int.class);
                                 method.setAccessible(true);
                                 method.invoke(helpFormatter, null, 10, 0);
                             }

    @Test
                             public void testFindWrapPos_NegativeWidth() throws Exception {
                                 HelpFormatter helpFormatter = new HelpFormatter();
                                 String text = "Test text";
                                 int width = -1;
                                 int startPos = 0;
                                 
                                 // Use reflection to access protected method
                                 Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                     "findWrapPos", String.class, int.class, int.class);
                                 findWrapPosMethod.setAccessible(true);
                                 int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                 
                                 assertEquals(-1, result); // Should handle negative width gracefully
                             }

    @Test
                             public void testFindWrapPos_StartPosBeyondTextLength() throws Exception {
                                 HelpFormatter helpFormatter = new HelpFormatter();
                                 String text = "Short";
                                 int width = 10;
                                 int startPos = 10;
                                 
                                 // Use reflection to access protected method
                                 Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                     "findWrapPos", String.class, int.class, int.class);
                                 findWrapPosMethod.setAccessible(true);
                                 int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                 
                                 assertEquals(-1, result); // Should return -1 when startPos is beyond text length
                             }

    @Test
                             public void testFindWrapPos_CarriageReturn() throws Exception {
                                 HelpFormatter helpFormatter = new HelpFormatter();
                                 String text = "Line1\rLine2";
                                 int width = 20;
                                 int startPos = 0;
                                 
                                 // Use reflection to access protected method
                                 Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                     "findWrapPos", String.class, int.class, int.class);
                                 findWrapPosMethod.setAccessible(true);
                                 int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                 
                                 assertEquals(6, result); // Should recognize '\r' as line break
                             }

    @Test
                             public void testFindWrapPos_MultipleSpaces() throws Exception {
                                 HelpFormatter helpFormatter = new HelpFormatter();
                                 String text = "Word1   Word2    Word3";
                                 int width = 10;
                                 int startPos = 0;
                                 
                                 // Use reflection to access protected method
                                 Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                     "findWrapPos", String.class, int.class, int.class);
                                 findWrapPosMethod.setAccessible(true);
                                 int result = (int) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                 
                                 assertEquals(6, result); // Should find last space before width
                             }

    @Test
                             public void testFindWrapPos_UnicodeCharacters() throws Exception {
                                 HelpFormatter helpFormatter = new HelpFormatter();
                                 String text = "日本語のテキスト テスト";
                                 int width = 8;
                                 int startPos = 0;
                                 
                                 // Use reflection to access protected method
                                 Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                     "findWrapPos", String.class, int.class, int.class);
                                 findWrapPosMethod.setAccessible(true);
                                 int result = (Integer) findWrapPosMethod.invoke(helpFormatter, text, width, startPos);
                                 
                                 assertEquals(7, result); // Should handle multi-byte characters correctly
                             }

    @Test
                        public void testFindWrapPos_DetectsMutantIgnoringStartPos() throws Exception {
                            HelpFormatter formatter = new HelpFormatter();
                            String text = "ThisIsALongTextWithNoWhitespace";
                            int width = 10;
                            int startPos = 5;
                            
                            // Use reflection to access protected method
                            Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                                "findWrapPos", String.class, int.class, int.class);
                            findWrapPosMethod.setAccessible(true);
                            int result = (Integer) findWrapPosMethod.invoke(formatter, text, width, startPos);
                            
                            // Verify the correct position is returned considering startPos
                            assertEquals("Wrap position should be startPos + width when no breaks found", 
                                         startPos + width, result);
                            
                            // Additional verification that we're not at end of string
                            assertNotEquals("Should not return -1 when not at end of string", -1, result);
                            
                            // Verify the position is within bounds
                            assertTrue("Result should be within text bounds", result <= text.length());
                        }

    @Test
                   public void testFindWrapPos_WhenPosExceedsTextLength() throws Exception {
                       HelpFormatter formatter = new HelpFormatter();
                       String text = "short";
                       int width = 10;  // width is larger than text length
                       int startPos = 0;
                       
                       // Use reflection to access protected method
                       Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                           "findWrapPos", String.class, int.class, int.class);
                       findWrapPosMethod.setAccessible(true);
                       int result = (Integer) findWrapPosMethod.invoke(formatter, text, width, startPos);
                       
                       // Assert original behavior - should return text length (5) not -1
                       assertEquals(text.length(), result);
                   }

    @Test
              public void testFindWrapPos_WhenPosEqualsTextLength_ShouldReturnNegativeOne() throws Exception {
                  // Arrange
                  HelpFormatter formatter = new HelpFormatter();
                  String text = "ThisIsATestStringWithNoSpaces"; // No whitespace characters
                  int width = 10;
                  int startPos = text.length() - width; // startPos + width = text.length()
                  
                  // Use reflection to access protected method
                  Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                      "findWrapPos", String.class, int.class, int.class);
                  findWrapPosMethod.setAccessible(true);
                  
                  // Act
                  int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
                  
                  // Assert
                  assertEquals("When pos equals text length, should return -1", -1, result);
              }

    @Test
         public void testFindWrapPos_EndOfText_ShouldReturnNegativeOne() throws Exception {
             HelpFormatter formatter = new HelpFormatter();
             String text = "abcdef"; // No whitespace, newlines or tabs
             int width = 6; // Equal to text length when startPos is 0
             int startPos = 0;
             
             // Use reflection to access protected method
             Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
                 "findWrapPos", String.class, int.class, int.class);
             findWrapPosMethod.setAccessible(true);
             int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
             
             assertEquals("When reaching end of text, should return -1", -1, result);
         }

    @Test
    public void testFindWrapPos_ExactTextLength() throws Exception {
        // Setup
        HelpFormatter formatter = new HelpFormatter();
        String text = "exacttext"; // length = 9
        int width = 9; // equals text length
        int startPos = 0;
        
        // Get the protected method via reflection
        Method findWrapPosMethod = HelpFormatter.class.getDeclaredMethod(
            "findWrapPos", String.class, int.class, int.class);
        findWrapPosMethod.setAccessible(true);
        
        // Test - should return -1 when remaining text exactly fits width
        int result = (int) findWrapPosMethod.invoke(formatter, text, width, startPos);
        
        // Verify
        assertEquals("Should return -1 when text exactly fits width", -1, result);
    }


}
