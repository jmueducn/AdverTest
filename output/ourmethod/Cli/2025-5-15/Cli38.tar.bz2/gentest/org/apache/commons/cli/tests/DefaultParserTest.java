package gentest.org.apache.commons.cli.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
 
public class DefaultParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testIsShortOption_InvalidFormat_NoDash() throws Exception {
                                                    DefaultParser parser = new DefaultParser();
                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                    isShortOptionMethod.setAccessible(true);
                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "option");
                                                    assertFalse(result);
                                                }

    @Test
                                                public void testIsShortOption_InvalidFormat_SingleDash() throws Exception {
                                                    DefaultParser parser = new DefaultParser();
                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                    isShortOptionMethod.setAccessible(true);
                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "-");
                                                    assertFalse(result);
                                                }

    @Test
                                                public void testIsShortOption_ValidSingleOption_NoValue() throws Exception {
                                                    Options options = mock(Options.class);
                                                    DefaultParser parser = new DefaultParser();
                                                    when(options.hasShortOption("a")).thenReturn(true);
                                                    
                                                    // Use reflection to access private method
                                                    Method method = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                    method.setAccessible(true);
                                                    boolean result = (boolean) method.invoke(parser, "-a");
                                                    
                                                    assertTrue(result);
                                                }

    @Test
                                                public void testIsShortOption_ValidSingleOption_WithValue() throws Exception {
                                                    // Setup mock (though not directly used in private method)
                                                    Options options = mock(Options.class);
                                                    when(options.hasShortOption("a")).thenReturn(true);
                                                    
                                                    // Create parser instance
                                                    DefaultParser parser = new DefaultParser();
                                                    
                                                    // Use reflection to access private method
                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                    isShortOptionMethod.setAccessible(true);
                                                    
                                                    // Invoke the method and assert
                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "-a=value");
                                                    assertTrue(result);
                                                }

    @Test
                                                public void testIsShortOption_ValidConcatenatedOptions() {
                                                    // Create mock Options
                                                    Options options = mock(Options.class);
                                                    when(options.hasShortOption("a")).thenReturn(true);
                                                    when(options.hasShortOption("b")).thenReturn(false);
                                                    when(options.hasShortOption("c")).thenReturn(true);
                                                    
                                                    // Create parser instance and inject options
                                                    DefaultParser parser = new DefaultParser();
                                                    try {
                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                        optionsField.setAccessible(true);
                                                        optionsField.set(parser, options);
                                                        
                                                        // Get the private isShortOption method
                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                        isShortOptionMethod.setAccessible(true);
                                                        
                                                        // First character is valid option
                                                        assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-abc"));
                                                        
                                                        // First character is invalid option
                                                        assertFalse((Boolean) isShortOptionMethod.invoke(parser, "-bac"));
                                                    } catch (Exception e) {
                                                        fail("Failed to set options field or invoke isShortOption method via reflection");
                                                    }
                                                }

    @Test
                                                public void testIsShortOption_NonExistentOption() throws Exception {
                                                    Options options = mock(Options.class);
                                                    DefaultParser parser = new DefaultParser();
                                                    
                                                    when(options.hasShortOption(anyString())).thenReturn(false);
                                                    
                                                    // Use reflection to access private method
                                                    Method method = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                    method.setAccessible(true);
                                                    boolean result = (boolean) method.invoke(parser, "-x");
                                                    
                                                    assertFalse(result);
                                                }

    @Test
                                                public void testIsShortOption_EmptyString() throws Exception {
                                                    DefaultParser parser = new DefaultParser();
                                                    Method method = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                    method.setAccessible(true);
                                                    boolean result = (boolean) method.invoke(parser, "");
                                                    assertFalse(result);
                                                }

    @Test
                                                public void testIsShortOption_NullInput() throws Exception {
                                                    org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                    exception.expect(NullPointerException.class);
                                                    org.apache.commons.cli.DefaultParser parser = new org.apache.commons.cli.DefaultParser();
                                                    
                                                    // Use reflection to access private method
                                                    java.lang.reflect.Method method = org.apache.commons.cli.DefaultParser.class
                                                            .getDeclaredMethod("isShortOption", String.class);
                                                    method.setAccessible(true);
                                                    method.invoke(parser, (Object) null);
                                                }

    @Test
                                                public void testIsShortOption_OptionWithEmptyName() throws Exception {
                                                    Options options = mock(Options.class);
                                                    DefaultParser parser = new DefaultParser();
                                                    when(options.hasShortOption("")).thenReturn(false);
                                                    
                                                    // Use reflection to access private method
                                                    Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                    isShortOptionMethod.setAccessible(true);
                                                    boolean result = (boolean) isShortOptionMethod.invoke(parser, "-=");
                                                    
                                                    assertFalse(result);
                                                }

    @Test
                                                public void testIsShortOption_MultipleEqualsSigns() {
                                                    Options options = mock(Options.class);
                                                    DefaultParser parser = new DefaultParser();
                                                    
                                                    // Use reflection to set the private 'options' field in parser
                                                    try {
                                                        Field optionsField = DefaultParser.class.getDeclaredField("options");
                                                        optionsField.setAccessible(true);
                                                        optionsField.set(parser, options);
                                                    } catch (Exception e) {
                                                        fail("Failed to set options field via reflection");
                                                    }
                                                    
                                                    when(options.hasShortOption("a")).thenReturn(true);
                                                    
                                                    // Use reflection to access and invoke the private isShortOption method
                                                    try {
                                                        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                                        isShortOptionMethod.setAccessible(true);
                                                        boolean result = (boolean) isShortOptionMethod.invoke(parser, "-a=b=c");
                                                        assertTrue(result);
                                                    } catch (Exception e) {
                                                        fail("Failed to invoke isShortOption method via reflection");
                                                    }
                                                }

    @Test
                                           public void testIsShortOptionWithMultipleEqualsSigns() throws Exception {
                                               // Setup mock options
                                               Options options = mock(Options.class);
                                               when(options.hasShortOption("a")).thenReturn(true);
                                               when(options.hasShortOption("b")).thenReturn(true);
                                               
                                               DefaultParser parser = new DefaultParser();
                                               
                                               // Use reflection to set the protected options field
                                               Field optionsField = DefaultParser.class.getDeclaredField("options");
                                               optionsField.setAccessible(true);
                                               optionsField.set(parser, options);
                                               
                                               // Use reflection to access the private isShortOption method
                                               Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                               isShortOptionMethod.setAccessible(true);
                                               
                                               // Test case where first "=" is correct (original behavior)
                                               // "-a=b=c" should be treated as option "a" with value "b=c"
                                               assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-a=b=c"));
                                               
                                               // Test case where last "=" would give different result
                                               // If mutation is present, "-b=a=c" would be treated as option "a" (last "=")
                                               // But original treats it as option "b" (first "=")
                                               assertTrue((Boolean) isShortOptionMethod.invoke(parser, "-b=a=c"));
                                               
                                               // Verify mock interactions to ensure correct option was checked
                                               verify(options).hasShortOption("a");
                                               verify(options).hasShortOption("b");
                                               verify(options, times(2)).hasShortOption(anyString());
                                           }

    @Test
                                  public void testIsShortOption_WithEqualsSign_ShouldDetectOption() {
                                      // Create mock objects
                                      Options options = mock(Options.class);
                                      DefaultParser parser = new DefaultParser();
                                      
                                      // Setup mock to return true for option "f"
                                      when(options.hasShortOption("f")).thenReturn(true);
                                      when(options.hasShortOption(anyString())).thenReturn(false);
                                      
                                      // Use reflection to set the private options field in parser
                                      try {
                                          Field optionsField = DefaultParser.class.getDeclaredField("options");
                                          optionsField.setAccessible(true);
                                          optionsField.set(parser, options);
                                      } catch (Exception e) {
                                          fail("Failed to set options field via reflection");
                                      }
                                      
                                      // Test case with "=" sign (should pass original, fail mutant)
                                      String token = "-f=value";
                                      
                                      // Use reflection to invoke private isShortOption method
                                      try {
                                          Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                          isShortOptionMethod.setAccessible(true);
                                          boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                          
                                          // Verify original behavior would return true
                                          assertTrue(result);
                                      } catch (Exception e) {
                                          fail("Failed to invoke isShortOption method via reflection");
                                      }
                                      
                                      // Verify mutant would fail because it looks for space instead of "="
                                      // and would try to check whole "f=value" as option name
                                      verify(options, times(1)).hasShortOption("f");
                                  }

    @Test
                                  public void testIsShortOption_WithSpace_ShouldNotBeTreatedAsValueSeparator() throws Exception {
                                      // Create mock objects
                                      Options options = mock(Options.class);
                                      DefaultParser parser = new DefaultParser();
                                      
                                      // Setup mock to return true for option "f"
                                      when(options.hasShortOption("f")).thenReturn(true);
                                      when(options.hasShortOption("f value")).thenReturn(false);
                                      
                                      // Test case with space (both original and mutant should fail)
                                      String token = "-f value";
                                      
                                      // Use reflection to access private isShortOption method
                                      Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                      isShortOptionMethod.setAccessible(true);
                                      boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                                      
                                      // Original would look for "=", not find it, and check whole "f value"
                                      // Mutant would find space and check just "f"
                                      assertFalse(result);
                                      
                                      // Verify mutant would incorrectly check for "f" only
                                      verify(options, never()).hasShortOption("f");
                                      verify(options, times(1)).hasShortOption("f value");
                                  }

    @Test
                             public void testIsShortOption_WithEqualsSign_ShouldNotIncludeEqualsInOptionName() throws Exception {
                                 // Setup
                                 DefaultParser parser = new DefaultParser();
                                 Options options = mock(Options.class);
                                 
                                 // Use reflection to access private method
                                 Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                                 isShortOptionMethod.setAccessible(true);
                                 
                                 // Mock behavior - return true only for valid short option "f"
                                 when(options.hasShortOption("f")).thenReturn(true);
                                 when(options.hasShortOption("f=")).thenReturn(false);
                                 when(options.hasShortOption(anyString())).thenReturn(false);
                                 
                                 // Set options through reflection since we can't access protected field
                                 Field optionsField = DefaultParser.class.getDeclaredField("options");
                                 optionsField.setAccessible(true);
                                 optionsField.set(parser, options);
                                 
                                 // Test case that will catch the mutant
                                 String tokenWithValue = "-f=value";
                                 
                                 // Original should return true (f is valid short option)
                                 // Mutated version would check for "f=" which would return false
                                 assertTrue((Boolean) isShortOptionMethod.invoke(parser, tokenWithValue));
                                 
                                 // Verify mock interactions
                                 verify(options).hasShortOption("f");
                                 verify(options, never()).hasShortOption("f=");
                             }

    @Test
                        public void testIsShortOption_DetectsMutatedOptionCheck() throws Exception {
                            // Setup
                            DefaultParser parser = new DefaultParser();
                            Options options = mock(Options.class);
                            
                            // Use reflection to set protected field
                            Field optionsField = DefaultParser.class.getDeclaredField("options");
                            optionsField.setAccessible(true);
                            optionsField.set(parser, options);
                            
                            // Create a valid short option case
                            String validShortOption = "-f";
                            String optionName = "f";
                            
                            // Mock behavior - the option exists
                            when(options.hasShortOption(optionName)).thenReturn(true);
                            
                            // Use reflection to call private method
                            Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                            isShortOptionMethod.setAccessible(true);
                            boolean result = (boolean) isShortOptionMethod.invoke(parser, validShortOption);
                            
                            // Verify - this will fail with the mutant
                            assertTrue("Method should return true for existing short option", result);
                            
                            // Verify the mock was called with correct parameter
                            verify(options).hasShortOption(optionName);
                        }

    @Test
                   public void testIsShortOptionWithEmptyOptionName() throws Exception {
                       // Setup
                       DefaultParser parser = new DefaultParser();
                       Options options = mock(Options.class);
                       
                       // Use reflection to set the protected options field
                       Field optionsField = DefaultParser.class.getDeclaredField("options");
                       optionsField.setAccessible(true);
                       optionsField.set(parser, options);
                       
                       // Mock behavior - return false for any option check
                       when(options.hasShortOption(anyString())).thenReturn(false);
                       
                       // Test case with empty option name ("-=")
                       String token = "-=";
                       
                       // Use reflection to call the private isShortOption method
                       Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                       isShortOptionMethod.setAccessible(true);
                       boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                       
                       // Verify
                       assertFalse(result);
                       
                       // Also verify the interaction with options
                       verify(options, never()).hasShortOption(anyString());
                   }

    @Test
              public void testIsShortOption_shouldReturnFalseForInvalidOption_whenMutated() throws Exception {
                  // Setup
                  DefaultParser parser = new DefaultParser();
                  Options mockOptions = mock(Options.class);
                  
                  // Use reflection to set protected options field
                  Field optionsField = DefaultParser.class.getDeclaredField("options");
                  optionsField.setAccessible(true);
                  optionsField.set(parser, mockOptions);
                  
                  // Mock options.hasShortOption() to return false for our test option
                  when(mockOptions.hasShortOption("x")).thenReturn(false);
                  
                  // Test with an invalid short option "-x" (length > 0 but not in options)
                  String token = "-x";
                  
                  // Use reflection to access private isShortOption method
                  Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                  isShortOptionMethod.setAccessible(true);
                  boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                  
                  // Original behavior would return false (since hasShortOption returns false)
                  // Mutated behavior would return true (since optName.length() > 0)
                  assertFalse("Method should return false for invalid short option", result);
                  
                  // Verify the interaction
                  verify(mockOptions).hasShortOption("x");
              }

    @Test
              public void testIsShortOption_shouldReturnTrueForValidOption() throws Exception {
                  // Setup
                  DefaultParser parser = new DefaultParser();
                  Options mockOptions = mock(Options.class);
                  
                  // Use reflection to set protected options field
                  Field optionsField = DefaultParser.class.getDeclaredField("options");
                  optionsField.setAccessible(true);
                  optionsField.set(parser, mockOptions);
                  
                  // Mock options.hasShortOption() to return true for our test option
                  when(mockOptions.hasShortOption("v")).thenReturn(true);
                  
                  // Test with a valid short option "-v"
                  String token = "-v";
                  
                  // Use reflection to invoke private isShortOption method
                  Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
                  isShortOptionMethod.setAccessible(true);
                  boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
                  
                  // Assert the result
                  assertTrue("Method should return true for valid short option", result);
                  
                  // Verify the interaction
                  verify(mockOptions).hasShortOption("v");
              }

    @Test
         public void testIsShortOption_ShouldDetectSingleCharacterOption_WhenOptionExists() throws Exception {
             // Setup
             DefaultParser parser = new DefaultParser();
             Options options = mock(Options.class);
             
             // Use reflection to set protected options field
             Field optionsField = DefaultParser.class.getDeclaredField("options");
             optionsField.setAccessible(true);
             optionsField.set(parser, options);
             
             // Mock the options to return true for our test option 'a'
             when(options.hasShortOption("a")).thenReturn(true);
             
             // Test with single character short option "-a"
             String token = "-a";
             
             // Use reflection to call private isShortOption method
             Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
             isShortOptionMethod.setAccessible(true);
             boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
             
             // Verify
             assertTrue("Should return true for valid single character option", result);
             
             // Additional verification that the concatenated options check was reached
             verify(options).hasShortOption("a");
         }

    @Test
    public void testIsShortOptionWithEmptyOptionName1() throws Exception {
        // Setup
        DefaultParser parser = new DefaultParser();
        Options options = mock(Options.class);
        
        // Mock behavior - not important for this test case
        when(options.hasShortOption(anyString())).thenReturn(false);
        
        // Use reflection to set the private options field in parser
        Field optionsField = DefaultParser.class.getDeclaredField("options");
        optionsField.setAccessible(true);
        optionsField.set(parser, options);
        
        // Get the private method using reflection
        Method isShortOptionMethod = DefaultParser.class.getDeclaredMethod("isShortOption", String.class);
        isShortOptionMethod.setAccessible(true);
        
        // Test case that would expose the mutant
        String token = "-="; // This creates empty optName after processing
        
        // Execute and verify
        boolean result = (boolean) isShortOptionMethod.invoke(parser, token);
        assertFalse("Method should return false for empty option name", result);
        
        // Verify no interactions with options mock since optName is empty
        verify(options, never()).hasShortOption(anyString());
    }


}
