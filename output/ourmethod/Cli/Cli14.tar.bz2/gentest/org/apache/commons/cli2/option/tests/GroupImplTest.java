package gentest.org.apache.commons.cli2.option.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.cli2.option.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.DisplaySetting;
import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.HelpLine;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;
import org.apache.commons.cli2.resource.ResourceConstants;
 
public class GroupImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                                public void testValidate_OptionsWithinRange() throws OptionException {
                                                                                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                                                                                                                                    Option option1 = mock(Option.class);
                                                                                                                                                                                                                                                                                                                                    Option option2 = mock(Option.class);
                                                                                                                                                                                                                                                                                                                                    options.add(option1);
                                                                                                                                                                                                                                                                                                                                    options.add(option2);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                                                                                                    when(commandLine.hasOption(option1)).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                    when(commandLine.hasOption(option2)).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "description", 1, 2);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Execute - should not throw exceptions
                                                                                                                                                                                                                                                                                                                                    group.validate(commandLine);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify option validations were called
                                                                                                                                                                                                                                                                                                                                    verify(option1).validate(commandLine);
                                                                                                                                                                                                                                                                                                                                    verify(option2).validate(commandLine);
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testValidate_RequiredOptionNotPresentButValidated() throws OptionException {
                                                                                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                                                                                                                                    Option requiredOption = mock(Option.class);
                                                                                                                                                                                                                                                                                                                                    when(requiredOption.isRequired()).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                    options.add(requiredOption);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                                                                                                    when(commandLine.hasOption(requiredOption)).thenReturn(false);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "description", 0, 1);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                                                                                                                    group.validate(commandLine);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify required option was validated even though not present
                                                                                                                                                                                                                                                                                                                                    verify(requiredOption).validate(commandLine);
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testValidate_GroupOptionValidated() throws OptionException {
                                                                                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                                                                                                                                    Option groupOption = mock(Option.class);
                                                                                                                                                                                                                                                                                                                                    options.add(groupOption);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                                                                                                    when(commandLine.hasOption(groupOption)).thenReturn(false);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "description", 0, 1);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                                                                                                                    group.validate(commandLine);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify group option was validated
                                                                                                                                                                                                                                                                                                                                    verify(groupOption).validate(commandLine);
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testValidate_AnonymousOptionsValidated() throws OptionException {
                                                                                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                                                                                                                                    Option regularOption = mock(Option.class);
                                                                                                                                                                                                                                                                                                                                    options.add(regularOption);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Anonymous option will be moved to anonymous list during construction
                                                                                                                                                                                                                                                                                                                                    Option anonymousOption = mock(Option.class);
                                                                                                                                                                                                                                                                                                                                    options.add(anonymousOption);
                                                                                                                                                                                                                                                                                                                                    when(anonymousOption instanceof Argument).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "description", 0, 1);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                                                                                                                    group.validate(commandLine);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify anonymous option was validated
                                                                                                                                                                                                                                                                                                                                    verify(anonymousOption).validate(commandLine);
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testValidate_ExactlyMinimumOptions() throws OptionException {
                                                                                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                                                                                                                                    Option option1 = mock(Option.class);
                                                                                                                                                                                                                                                                                                                                    Option option2 = mock(Option.class);
                                                                                                                                                                                                                                                                                                                                    options.add(option1);
                                                                                                                                                                                                                                                                                                                                    options.add(option2);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                                                                                                    when(commandLine.hasOption(option1)).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                    when(commandLine.hasOption(option2)).thenReturn(false);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "description", 1, 2);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Execute - should not throw exception
                                                                                                                                                                                                                                                                                                                                    group.validate(commandLine);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify validations
                                                                                                                                                                                                                                                                                                                                    verify(option1).validate(commandLine);
                                                                                                                                                                                                                                                                                                                                    verify(option2, never()).validate(commandLine);
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testValidate_ExactlyMaximumOptions() throws OptionException {
                                                                                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                                                                                                                                    Option option1 = mock(Option.class);
                                                                                                                                                                                                                                                                                                                                    Option option2 = mock(Option.class);
                                                                                                                                                                                                                                                                                                                                    options.add(option1);
                                                                                                                                                                                                                                                                                                                                    options.add(option2);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                                                                                                    when(commandLine.hasOption(option1)).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                    when(commandLine.hasOption(option2)).thenReturn(true);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "description", 1, 2);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Execute - should not throw exception
                                                                                                                                                                                                                                                                                                                                    group.validate(commandLine);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Verify validations
                                                                                                                                                                                                                                                                                                                                    verify(option1).validate(commandLine);
                                                                                                                                                                                                                                                                                                                                    verify(option2).validate(commandLine);
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                                                                public void testValidate_TooFewOptions() throws OptionException {
                                                                                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                                                                                    List<Option> options = new ArrayList<Option>();
                                                                                                                                                                                                                                                                                                                                    Option option1 = mock(Option.class);
                                                                                                                                                                                                                                                                                                                                    options.add(option1);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                                                                                                    when(commandLine.hasOption(any(Option.class))).thenReturn(false);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "description", 1, 1);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Setup exception rule
                                                                                                                                                                                                                                                                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                                                                                                                    exception.expect(OptionException.class);
                                                                                                                                                                                                                                                                                                                                    exception.expectMessage(ResourceConstants.MISSING_OPTION);
                                                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                                                                                                                    group.validate(commandLine);
                                                                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                                            public void testValidateShouldNotValidateNonRequiredNonGroupOptionsWhenNotPresent() throws OptionException {
                                                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                                                List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                                                                                                Option mockOption = mock(Option.class);
                                                                                                                                                                                                                                                                                                when(mockOption.isRequired()).thenReturn(false);
                                                                                                                                                                                                                                                                                                // Not a Group instance by default mock behavior
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                options.add(mockOption);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                                                                when(mockCommandLine.hasOption(mockOption)).thenReturn(false);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                GroupImpl group = new GroupImpl(options, "test", "desc", 0, 1);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                                                group.validate(mockCommandLine);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Verify - option.validate should NOT be called since it's not required, not a Group, and not present
                                                                                                                                                                                                                                                                                                verify(mockOption, never()).validate(mockCommandLine);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // This test will fail with the mutant since it will call validate on all options
                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                            public void testValidateShouldCallValidationForGroupOptionsEvenWhenNotRequired() throws OptionException {
                                                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                                                Option requiredOption = mock(Option.class);
                                                                                                                                                                                                                                                                                when(requiredOption.isRequired()).thenReturn(true);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                Option groupOption = mock(Option.class);
                                                                                                                                                                                                                                                                                when(groupOption.isRequired()).thenReturn(false);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                Option regularOption = mock(Option.class);
                                                                                                                                                                                                                                                                                when(regularOption.isRequired()).thenReturn(false);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                java.util.List<Option> options = java.util.Arrays.asList(requiredOption, groupOption, regularOption);
                                                                                                                                                                                                                                                                                GroupImpl groupImpl = new GroupImpl(options, "testGroup", "description", 1, 3);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                                                groupImpl.validate(commandLine);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                                                // Verify that validate was called for required option
                                                                                                                                                                                                                                                                                verify(requiredOption).validate(commandLine);
                                                                                                                                                                                                                                                                                // Verify that validate was called for group option (this would fail with the mutant)
                                                                                                                                                                                                                                                                                verify(groupOption).validate(commandLine);
                                                                                                                                                                                                                                                                                // Verify that validate was NOT called for regular non-required option
                                                                                                                                                                                                                                                                                verify(regularOption, never()).validate(commandLine);
                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                public void testValidate_NonRequiredGroupOption_ShouldBeValidated() throws OptionException {
                                                                                                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                                                                    List<Option> anonymous = new ArrayList<>();
                                                                                                                                                                                                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Create a Group option that is not required
                                                                                                                                                                                                                                                                    Option groupOption = mock(Option.class);
                                                                                                                                                                                                                                                                    when(groupOption.isRequired()).thenReturn(false);
                                                                                                                                                                                                                                                                    when(((Group)groupOption).getTriggers()).thenReturn(Collections.emptySet()); // Needed for instanceof Group mock
                                                                                                                                                                                                                                                                    when(groupOption.getPrefixes()).thenReturn(Collections.emptySet()); // Needed for constructor processing
                                                                                                                                                                                                                                                                    options.add(groupOption);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Configure commandLine to not have the option (so validation depends on isRequired/Group check)
                                                                                                                                                                                                                                                                    when(commandLine.hasOption(groupOption)).thenReturn(false);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Create GroupImpl with min=0, max=1 (so no quantity violations) and pass anonymous list
                                                                                                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "desc", 0, 1);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Test - should validate the Group option even though it's not required and not present
                                                                                                                                                                                                                                                                    group.validate(commandLine);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Verify the Group option was validated
                                                                                                                                                                                                                                                                    verify(groupOption).validate(commandLine);
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                            public void testValidate_RequiredOptionNotPresent_ShouldNotCountTowardsMaximum() throws OptionException {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                                                                Option requiredOption = mock(Option.class);
                                                                                                                                                                                                                                                                when(requiredOption.isRequired()).thenReturn(true);
                                                                                                                                                                                                                                                                when(requiredOption.getPreferredName()).thenReturn("reqOption");
                                                                                                                                                                                                                                                                options.add(requiredOption);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                                when(commandLine.hasOption(requiredOption)).thenReturn(false);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Group with max 0 to easily trigger "too many options" case
                                                                                                                                                                                                                                                                GroupImpl group = new GroupImpl(options, "testGroup", "description", 0, 0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Test - should not throw OptionException for required but not present option
                                                                                                                                                                                                                                                                group.validate(commandLine);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify the required option was validated (due to being required)
                                                                                                                                                                                                                                                                verify(requiredOption).validate(commandLine);
                                                                                                                                                                                                                                                                // But since it wasn't present in command line, it shouldn't count towards maximum
                                                                                                                                                                                                                                                                // (if mutant is present, it would throw OptionException)
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                    public void testValidate_DetectsPreIncrementToPostIncrementMutant() throws Exception {
                                                                                                                                                                                                                                                        // Setup test where present == maximum (boundary case)
                                                                                                                                                                                                                                                        int minimum = 1;
                                                                                                                                                                                                                                                        int maximum = 2;
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Create mock options where 2 options are present (equal to maximum)
                                                                                                                                                                                                                                                        List<Option> options = new ArrayList<Option>();
                                                                                                                                                                                                                                                        Option option1 = mock(Option.class);
                                                                                                                                                                                                                                                        Option option2 = mock(Option.class);
                                                                                                                                                                                                                                                        options.add(option1);
                                                                                                                                                                                                                                                        options.add(option2);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Create command line that has both options
                                                                                                                                                                                                                                                        WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                                        when(commandLine.hasOption(any(Option.class))).thenReturn(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Create group with these parameters
                                                                                                                                                                                                                                                        GroupImpl group = new GroupImpl(options, "test", "description", minimum, maximum);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // This should throw exception in original (since ++present > maximum when present=2)
                                                                                                                                                                                                                                                        // But mutant (present++ > maximum) won't throw since it checks before increment
                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                            group.validate(commandLine);
                                                                                                                                                                                                                                                            fail("Expected OptionException not thrown - mutant may have survived");
                                                                                                                                                                                                                                                        } catch (OptionException e) {
                                                                                                                                                                                                                                                            // Expected behavior for original code
                                                                                                                                                                                                                                                            assertNotNull("Expected OptionException to be thrown", e);
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify options were validated
                                                                                                                                                                                                                                                        verify(option1).validate(commandLine);
                                                                                                                                                                                                                                                        verify(option2).validate(commandLine);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                        public void testValidate_TooManyOptions_ShouldThrowExceptionWithOptionName() throws OptionException {
                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                            List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                                            Option option1 = mock(Option.class);
                                                                                                                                                                                                                                            Option option2 = mock(Option.class);
                                                                                                                                                                                                                                            when(option1.getPreferredName()).thenReturn("opt1");
                                                                                                                                                                                                                                            when(option2.getPreferredName()).thenReturn("opt2");
                                                                                                                                                                                                                                            when(option1.isRequired()).thenReturn(false);
                                                                                                                                                                                                                                            when(option2.isRequired()).thenReturn(false);
                                                                                                                                                                                                                                            options.add(option1);
                                                                                                                                                                                                                                            options.add(option2);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            GroupImpl group = new GroupImpl(options, "test", "desc", 0, 1); // max 1 option allowed
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                            when(commandLine.hasOption(option1)).thenReturn(true);
                                                                                                                                                                                                                                            when(commandLine.hasOption(option2)).thenReturn(true);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // This will verify the exception contains the correct option name
                                                                                                                                                                                                                                            ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                                            exception.expect(OptionException.class);
                                                                                                                                                                                                                                            exception.expectMessage("opt1"); // should be first unexpected option
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Execute
                                                                                                                                                                                                                                            group.validate(commandLine);
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                public void testValidate_TooManyOptions_ReportsCorrectOptionName() {
                                                                                                                                                                                                                                    // Setup test data - group allows max 1 option but we'll provide 2
                                                                                                                                                                                                                                    List<Option> options = new ArrayList<Option>();
                                                                                                                                                                                                                                    Option option1 = mock(Option.class);
                                                                                                                                                                                                                                    Option option2 = mock(Option.class);
                                                                                                                                                                                                                                    options.add(option1);
                                                                                                                                                                                                                                    options.add(option2);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Configure mocks
                                                                                                                                                                                                                                    when(option1.getPreferredName()).thenReturn("opt1");
                                                                                                                                                                                                                                    when(option2.getPreferredName()).thenReturn("opt2");
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                                    when(commandLine.hasOption(any(Option.class))).thenReturn(true);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Create group with max 1 option
                                                                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "testGroup", "description", 0, 1);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        group.validate(commandLine);
                                                                                                                                                                                                                                        fail("Expected OptionException not thrown");
                                                                                                                                                                                                                                    } catch (OptionException e) {
                                                                                                                                                                                                                                        // Verify exception contains the option name, not group name
                                                                                                                                                                                                                                        assertEquals("opt2", e.getMessage());
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                    public void testValidate_ExceedsMaximumOptions_ShouldNotValidateRemainingOptions() {
                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                        List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                        Option option1 = mock(Option.class);
                                                                                                                                                                                                                        Option option2 = mock(Option.class);
                                                                                                                                                                                                                        Option option3 = mock(Option.class);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        when(option1.isRequired()).thenReturn(false);
                                                                                                                                                                                                                        when(option2.isRequired()).thenReturn(false);
                                                                                                                                                                                                                        when(option3.isRequired()).thenReturn(false);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        options.add(option1);
                                                                                                                                                                                                                        options.add(option2);
                                                                                                                                                                                                                        options.add(option3);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                        when(commandLine.hasOption(any(Option.class))).thenReturn(true);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        GroupImpl group = new GroupImpl(options, "test", "description", 1, 2);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Execute and verify
                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                            group.validate(commandLine);
                                                                                                                                                                                                                            fail("Expected OptionException");
                                                                                                                                                                                                                        } catch (OptionException e) {
                                                                                                                                                                                                                            // Verify only first two options were validated (original behavior)
                                                                                                                                                                                                                            // Mutant would validate all three options
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                verify(option1, times(1)).validate(commandLine);
                                                                                                                                                                                                                                verify(option2, times(1)).validate(commandLine);
                                                                                                                                                                                                                                verify(option3, never()).validate(commandLine);
                                                                                                                                                                                                                            } catch (OptionException ex) {
                                                                                                                                                                                                                                fail("Unexpected OptionException during verification");
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Verify the exception was for too many options
                                                                                                                                                                                                                            assertTrue(e.getMessage().contains("Unexpected option"));
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                public void testValidate_ExceedsMaximum_ShouldBreakLoopNotReturn() throws OptionException {
                                                                                                                                                                                                                    // Setup - create group with max 1 option
                                                                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                    Option option1 = mock(Option.class);
                                                                                                                                                                                                                    Option option2 = mock(Option.class);
                                                                                                                                                                                                                    when(option1.isRequired()).thenReturn(true);
                                                                                                                                                                                                                    when(option2.isRequired()).thenReturn(true);
                                                                                                                                                                                                                    options.add(option1);
                                                                                                                                                                                                                    options.add(option2);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "desc", 0, 1);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Mock command line to have both options
                                                                                                                                                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                    when(commandLine.hasOption(any(Option.class))).thenReturn(true);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Setup validation tracking
                                                                                                                                                                                                                    doNothing().when(option1).validate(commandLine);
                                                                                                                                                                                                                    doNothing().when(option2).validate(commandLine);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                        group.validate(commandLine);
                                                                                                                                                                                                                        fail("Should have thrown OptionException for too many options");
                                                                                                                                                                                                                    } catch (OptionException e) {
                                                                                                                                                                                                                        // Expected - verify exception was thrown
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Verify option2.validate() was NOT called (break worked)
                                                                                                                                                                                                                    verify(option2, never()).validate(commandLine);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Additional verification that we didn't return early
                                                                                                                                                                                                                    verify(option1).validate(commandLine);
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                            public void testValidate_PresentAndRequiredOption_ShouldAlwaysValidate() throws Exception {
                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                List<Option> options = new ArrayList<>();
                                                                                                                                                                                                                Option mockOption = mock(Option.class);
                                                                                                                                                                                                                when(mockOption.isRequired()).thenReturn(true);
                                                                                                                                                                                                                when(mockOption.getPreferredName()).thenReturn("testOption");
                                                                                                                                                                                                                options.add(mockOption);
                                                                                                                                                                                                                
                                                                                                                                                                                                                WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                                when(mockCommandLine.hasOption(mockOption)).thenReturn(true);
                                                                                                                                                                                                                
                                                                                                                                                                                                                GroupImpl group = new GroupImpl(options, "testGroup", "description", 1, 1);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // This should always call validate regardless of mutation
                                                                                                                                                                                                                // In original: validate = true (after being true from isRequired)
                                                                                                                                                                                                                // In mutant: validate = !true = false
                                                                                                                                                                                                                group.validate(mockCommandLine);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify the option was validated (would fail for mutant)
                                                                                                                                                                                                                verify(mockOption).validate(mockCommandLine);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Also verify no exceptions were thrown
                                                                                                                                                                                                                // (implicit in test not throwing exceptions)
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                    public void testValidateShouldNotValidateNonRequiredAbsentOption() throws Exception {
                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                        List<Option> options = new ArrayList<Option>();
                                                                                                                                                                                                        Option mockOption = mock(Option.class);
                                                                                                                                                                                                        when(mockOption.isRequired()).thenReturn(false);
                                                                                                                                                                                                        when(mockOption.getTriggers()).thenReturn(new HashSet<String>());
                                                                                                                                                                                                        when(mockOption.getPrefixes()).thenReturn(new HashSet<String>());
                                                                                                                                                                                                        
                                                                                                                                                                                                        options.add(mockOption);
                                                                                                                                                                                                        
                                                                                                                                                                                                        WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                        when(commandLine.hasOption(mockOption)).thenReturn(false);
                                                                                                                                                                                                        
                                                                                                                                                                                                        GroupImpl groupImpl = new GroupImpl(options, "test", "description", 0, 1);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Execute
                                                                                                                                                                                                        groupImpl.validate(commandLine);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Verify - option.validate() should NOT be called since it's not required and not present
                                                                                                                                                                                                        verify(mockOption, never()).validate(commandLine);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // If mutant exists (if(true)), the verify would fail since validate would be called
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testValidateShouldValidateRequiredOptionEvenWhenAbsent() throws Exception {
                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                        List<Option> options = new ArrayList<>();
                                                                                                                                                                                                        Option mockOption = mock(Option.class);
                                                                                                                                                                                                        when(mockOption.isRequired()).thenReturn(true);
                                                                                                                                                                                                        when(mockOption.getTriggers()).thenReturn(new HashSet<>()); // Added to satisfy Option interface
                                                                                                                                                                                                        when(mockOption.getPrefixes()).thenReturn(new HashSet<>()); // Added to satisfy Option interface
                                                                                                                                                                                                        
                                                                                                                                                                                                        options.add(mockOption);
                                                                                                                                                                                                        
                                                                                                                                                                                                        WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                        when(commandLine.hasOption(mockOption)).thenReturn(false);
                                                                                                                                                                                                        
                                                                                                                                                                                                        GroupImpl groupImpl = new GroupImpl(options, "test", "description", 0, 1);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Execute
                                                                                                                                                                                                        groupImpl.validate(commandLine);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Verify - option.validate() SHOULD be called since it's required
                                                                                                                                                                                                        verify(mockOption, times(1)).validate(commandLine);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                    public void testValidateShouldValidatePresentOption() throws Exception {
                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                        List<Option> options = new ArrayList<Option>();
                                                                                                                                                                                                        Option mockOption = mock(Option.class);
                                                                                                                                                                                                        when(mockOption.isRequired()).thenReturn(false);
                                                                                                                                                                                                        when(mockOption.getTriggers()).thenReturn(new HashSet<String>());
                                                                                                                                                                                                        options.add(mockOption);
                                                                                                                                                                                                        
                                                                                                                                                                                                        WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                                        when(commandLine.hasOption(mockOption)).thenReturn(true);
                                                                                                                                                                                                        
                                                                                                                                                                                                        GroupImpl groupImpl = new GroupImpl(options, "test", "description", 0, 1);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Execute
                                                                                                                                                                                                        groupImpl.validate(commandLine);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Verify - option.validate() SHOULD be called since it's present
                                                                                                                                                                                                        verify(mockOption, times(1)).validate(commandLine);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                        public void testValidatePassesCorrectCommandLineToOptionValidation() {
                                                                                                                                                                                            // Setup
                                                                                                                                                                                            WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                            Option mockOption = mock(Option.class);
                                                                                                                                                                                            
                                                                                                                                                                                            // Configure mock option to be required and throw exception when validated with null
                                                                                                                                                                                            when(mockOption.isRequired()).thenReturn(true);
                                                                                                                                                                                            try {
                                                                                                                                                                                                doThrow(new RuntimeException("Should not validate with null"))
                                                                                                                                                                                                    .when(mockOption).validate(null);
                                                                                                                                                                                            } catch (OptionException e) {
                                                                                                                                                                                                fail("Unexpected OptionException");
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            // Create group with our mock option
                                                                                                                                                                                            List<Option> options = Collections.singletonList(mockOption);
                                                                                                                                                                                            GroupImpl groupImpl = new GroupImpl(options, "test", "desc", 1, 1);
                                                                                                                                                                                            
                                                                                                                                                                                            // Configure command line to have our option
                                                                                                                                                                                            when(commandLine.hasOption(mockOption)).thenReturn(true);
                                                                                                                                                                                            
                                                                                                                                                                                            // This should call option.validate(commandLine) in original code
                                                                                                                                                                                            // Will throw exception if mutant is present (validate(null) called instead)
                                                                                                                                                                                            try {
                                                                                                                                                                                                groupImpl.validate(commandLine);
                                                                                                                                                                                            } catch (OptionException e) {
                                                                                                                                                                                                fail("Unexpected OptionException");
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify the option was validated with the correct command line
                                                                                                                                                                                            try {
                                                                                                                                                                                                verify(mockOption).validate(commandLine);
                                                                                                                                                                                            } catch (OptionException e) {
                                                                                                                                                                                                fail("Unexpected OptionException");
                                                                                                                                                                                            }
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                public void testValidate_ShouldCallValidateOnRequiredOption() throws OptionException {
                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                                    Option mockRequiredOption = mock(Option.class);
                                                                                                                                                                                    when(mockRequiredOption.isRequired()).thenReturn(true);
                                                                                                                                                                                    options.add(mockRequiredOption);
                                                                                                                                                                                    
                                                                                                                                                                                    WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                    when(mockCommandLine.hasOption(mockRequiredOption)).thenReturn(false);
                                                                                                                                                                                    
                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "testGroup", "description", 0, 1);
                                                                                                                                                                                    
                                                                                                                                                                                    // Execute
                                                                                                                                                                                    group.validate(mockCommandLine);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify - this will fail if the mutant is present
                                                                                                                                                                                    verify(mockRequiredOption).validate(mockCommandLine);
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testValidate_ShouldCallValidateOnGroupOption() throws OptionException {
                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                                    Option mockGroupOption = mock(Option.class);
                                                                                                                                                                                    options.add(mockGroupOption);
                                                                                                                                                                                    
                                                                                                                                                                                    WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                    when(mockCommandLine.hasOption(mockGroupOption)).thenReturn(false);
                                                                                                                                                                                    
                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "testGroup", "description", 0, 1);
                                                                                                                                                                                    
                                                                                                                                                                                    // Execute
                                                                                                                                                                                    group.validate(mockCommandLine);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify - this will fail if the mutant is present
                                                                                                                                                                                    verify(mockGroupOption).validate(mockCommandLine);
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testValidate_ShouldCallValidateOnPresentOption() throws OptionException {
                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                                    Option mockOption = mock(Option.class);
                                                                                                                                                                                    options.add(mockOption);
                                                                                                                                                                                    
                                                                                                                                                                                    WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                                    when(mockCommandLine.hasOption(mockOption)).thenReturn(true);
                                                                                                                                                                                    
                                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "testGroup", "description", 0, 1);
                                                                                                                                                                                    
                                                                                                                                                                                    // Execute
                                                                                                                                                                                    group.validate(mockCommandLine);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify - this will fail if the mutant is present
                                                                                                                                                                                    verify(mockOption).validate(mockCommandLine);
                                                                                                                                                                                }

    @Test
                                                                                                                                                                        public void testValidateCallsOptionValidateNotThisValidate() {
                                                                                                                                                                            // Setup test data
                                                                                                                                                                            List<Option> options = new ArrayList<>();
                                                                                                                                                                            Option mockOption = mock(Option.class);
                                                                                                                                                                            when(mockOption.isRequired()).thenReturn(true); // Make it require validation
                                                                                                                                                                            options.add(mockOption);
                                                                                                                                                                            
                                                                                                                                                                            WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                            when(mockCommandLine.hasOption(mockOption)).thenReturn(true); // Option is present
                                                                                                                                                                            
                                                                                                                                                                            // Create group with min=1, max=1 to pass validation
                                                                                                                                                                            GroupImpl group = new GroupImpl(options, "test", "description", 1, 1);
                                                                                                                                                                            
                                                                                                                                                                            try {
                                                                                                                                                                                // Execute validation
                                                                                                                                                                                group.validate(mockCommandLine);
                                                                                                                                                                                
                                                                                                                                                                                try {
                                                                                                                                                                                    // Verify the option's validate was called, not the group's
                                                                                                                                                                                    verify(mockOption).validate(mockCommandLine);
                                                                                                                                                                                } catch (OptionException e) {
                                                                                                                                                                                    fail("Option validation should not throw exception in this test case");
                                                                                                                                                                                }
                                                                                                                                                                                
                                                                                                                                                                                // The mutant would call this.validate() instead, which would fail this verification
                                                                                                                                                                                // Also verify no unexpected interactions with the command line
                                                                                                                                                                                verifyNoMoreInteractions(mockOption, mockCommandLine);
                                                                                                                                                                            } catch (OptionException e) {
                                                                                                                                                                                fail("Group validation should not throw exception in this test case");
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testValidateCallsOptionValidate() throws Exception {
                                                                                                                                                                            // Setup test data
                                                                                                                                                                            List<Option> options = new ArrayList<>();
                                                                                                                                                                            Option mockOption = mock(Option.class);
                                                                                                                                                                            when(mockOption.isRequired()).thenReturn(true);
                                                                                                                                                                            options.add(mockOption);
                                                                                                                                                                            
                                                                                                                                                                            WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                            when(mockCommandLine.hasOption(mockOption)).thenReturn(true);
                                                                                                                                                                            
                                                                                                                                                                            // Create GroupImpl with min=1, max=1
                                                                                                                                                                            GroupImpl group = new GroupImpl(options, "test", "desc", 1, 1);
                                                                                                                                                                            
                                                                                                                                                                            // Execute validation
                                                                                                                                                                            group.validate(mockCommandLine);
                                                                                                                                                                            
                                                                                                                                                                            // Verify option.validate() was called
                                                                                                                                                                            verify(mockOption).validate(mockCommandLine);
                                                                                                                                                                            
                                                                                                                                                                            // The mutant would fail this verification because it would call 
                                                                                                                                                                            // GroupImpl's validate() instead of the option's validate()
                                                                                                                                                                        }

    @Test
                                                                                                                                                                public void testValidateShouldCheckGroupOptionsEvenWhenNotRequired() throws Exception {
                                                                                                                                                                    // Setup test data
                                                                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                                                                    List<Option> anonymous = new ArrayList<>();
                                                                                                                                                                    
                                                                                                                                                                    // Create a mock Group option that is not required
                                                                                                                                                                    Option groupOption = mock(Option.class);
                                                                                                                                                                    when(groupOption.isRequired()).thenReturn(false);
                                                                                                                                                                    when(groupOption instanceof Group).thenReturn(true); // Mock instanceof
                                                                                                                                                                    
                                                                                                                                                                    options.add(groupOption);
                                                                                                                                                                    
                                                                                                                                                                    // Create command line mock that doesn't have our option
                                                                                                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                                    when(commandLine.hasOption(groupOption)).thenReturn(false);
                                                                                                                                                                    
                                                                                                                                                                    // Create GroupImpl with our test options (min=0, max=1)
                                                                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "desc", 0, 1);
                                                                                                                                                                    group.validate(commandLine);
                                                                                                                                                                    
                                                                                                                                                                    // Verify that validate was called on the group option
                                                                                                                                                                    // This assertion would fail with the mutant but pass with original code
                                                                                                                                                                    verify(groupOption).validate(commandLine);
                                                                                                                                                                }

    @Test
                                                                                                                                                        public void testValidate_TooManyOptions_ShouldThrowWithUnexpectedOption() throws OptionException {
                                                                                                                                                            // Setup
                                                                                                                                                            List<Option> options = new ArrayList<>();
                                                                                                                                                            Option option1 = mock(Option.class);
                                                                                                                                                            Option option2 = mock(Option.class);
                                                                                                                                                            Option option3 = mock(Option.class);
                                                                                                                                                            when(option1.getPreferredName()).thenReturn("opt1");
                                                                                                                                                            when(option2.getPreferredName()).thenReturn("opt2");
                                                                                                                                                            when(option3.getPreferredName()).thenReturn("opt3");
                                                                                                                                                            options.add(option1);
                                                                                                                                                            options.add(option2);
                                                                                                                                                            options.add(option3);
                                                                                                                                                            
                                                                                                                                                            WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                            when(commandLine.hasOption(any(Option.class))).thenReturn(true);
                                                                                                                                                            
                                                                                                                                                            // Group with maximum 2 options but we'll provide 3
                                                                                                                                                            GroupImpl group = new GroupImpl(options, "test", "description", 1, 2);
                                                                                                                                                            
                                                                                                                                                            try {
                                                                                                                                                                group.validate(commandLine);
                                                                                                                                                                fail("Expected OptionException to be thrown");
                                                                                                                                                            } catch (OptionException e) {
                                                                                                                                                                // Verify the exception contains the correct unexpected option name
                                                                                                                                                                assertEquals("opt3", e.getMessage());
                                                                                                                                                            }
                                                                                                                                                        }

    @Test(expected = OptionException.class)
                                                                                                                                                    public void testValidate_TooManyOptions_ReportsOptionName() throws OptionException {
                                                                                                                                                        // Setup
                                                                                                                                                        List<Option> options = new ArrayList<>();
                                                                                                                                                        Option option1 = mock(Option.class);
                                                                                                                                                        Option option2 = mock(Option.class);
                                                                                                                                                        when(option1.isRequired()).thenReturn(false);
                                                                                                                                                        when(option2.isRequired()).thenReturn(false);
                                                                                                                                                        options.add(option1);
                                                                                                                                                        options.add(option2);
                                                                                                                                                        
                                                                                                                                                        WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                                        when(commandLine.hasOption(any(Option.class))).thenReturn(true);
                                                                                                                                                        
                                                                                                                                                        // Group with max 1 option but we'll provide 2
                                                                                                                                                        GroupImpl group = new GroupImpl(options, "testGroup", "description", 0, 1);
                                                                                                                                                        
                                                                                                                                                        // Set up option names for exception message verification
                                                                                                                                                        when(option1.getPreferredName()).thenReturn("option1");
                                                                                                                                                        when(option2.getPreferredName()).thenReturn("option2");
                                                                                                                                                        
                                                                                                                                                        try {
                                                                                                                                                            // Execute
                                                                                                                                                            group.validate(commandLine);
                                                                                                                                                            fail("Expected OptionException not thrown");
                                                                                                                                                        } catch (OptionException e) {
                                                                                                                                                            // Verify exception contains the option name, not group name
                                                                                                                                                            assertTrue("Exception should contain option name", 
                                                                                                                                                                      e.getMessage().contains("option1") || e.getMessage().contains("option2"));
                                                                                                                                                            assertFalse("Exception should not contain group name", 
                                                                                                                                                                       e.getMessage().contains("testGroup"));
                                                                                                                                                            throw e;
                                                                                                                                                        }
                                                                                                                                                    }

    @Test
                                                                                                                                    public void testValidateWithExcessOptionsShouldBreakNotReturn() {
                                                                                                                                        // Setup test data with:
                                                                                                                                        // - 3 options where maximum is 2 (to trigger excess)
                                                                                                                                        // - At least 1 anonymous argument to validate
                                                                                                                                        // - Minimum set to 0 to ensure minimum check would pass
                                                                                                                                        
                                                                                                                                        // Create mock options
                                                                                                                                        Option option1 = mock(Option.class);
                                                                                                                                        Option option2 = mock(Option.class);
                                                                                                                                        Option option3 = mock(Option.class); // This will exceed maximum
                                                                                                                                        Option anonymousOption = mock(Option.class);
                                                                                                                                        
                                                                                                                                        when(option1.isRequired()).thenReturn(false);
                                                                                                                                        when(option2.isRequired()).thenReturn(false);
                                                                                                                                        when(option3.isRequired()).thenReturn(false);
                                                                                                                                        
                                                                                                                                        List<Option> options = new ArrayList<Option>();
                                                                                                                                        options.add(option1);
                                                                                                                                        options.add(option2);
                                                                                                                                        options.add(option3);
                                                                                                                                        
                                                                                                                                        List<Option> anonymous = new ArrayList<Option>();
                                                                                                                                        anonymous.add(anonymousOption);
                                                                                                                                        
                                                                                                                                        // Create GroupImpl with max=2, min=0
                                                                                                                                        GroupImpl group = new GroupImpl(options, "test", "desc", 0, 2);
                                                                                                                                        
                                                                                                                                        // Mock command line that has all options present
                                                                                                                                        WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                                        when(commandLine.hasOption(any(Option.class))).thenReturn(true);
                                                                                                                                        
                                                                                                                                        // Test - should throw OptionException for too many options
                                                                                                                                        try {
                                                                                                                                            group.validate(commandLine);
                                                                                                                                            fail("Expected OptionException not thrown");
                                                                                                                                        } catch (OptionException e) {
                                                                                                                                            // Verify exception was thrown for too many options
                                                                                                                                            assertNotNull(e.getMessage());
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        // Verify anonymous option was validated (would fail with return; mutant)
                                                                                                                                        try {
                                                                                                                                            verify(anonymousOption).validate(commandLine);
                                                                                                                                        } catch (OptionException e) {
                                                                                                                                            fail("Unexpected OptionException during verification");
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        // Verify all options up to maximum were processed
                                                                                                                                        try {
                                                                                                                                            verify(option1).validate(commandLine);
                                                                                                                                            verify(option2).validate(commandLine);
                                                                                                                                        } catch (OptionException e) {
                                                                                                                                            fail("Unexpected OptionException during verification");
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        // option3 should not be validated as it's the unexpected one
                                                                                                                                        try {
                                                                                                                                            verify(option3, never()).validate(commandLine);
                                                                                                                                        } catch (OptionException e) {
                                                                                                                                            fail("Unexpected OptionException during verification");
                                                                                                                                        }
                                                                                                                                    }

    @Test
                                                                                                                        public void testValidateCallsOptionValidateWithCorrectCommandLine() throws OptionException {
                                                                                                                            // Arrange
                                                                                                                            List<Option> options = new ArrayList<>();
                                                                                                                            Option mockOption = mock(Option.class);
                                                                                                                            options.add(mockOption);
                                                                                                                            
                                                                                                                            GroupImpl group = new GroupImpl(options, "testGroup", "description", 0, 1);
                                                                                                                            WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                            
                                                                                                                            // Act
                                                                                                                            group.validate(commandLine);
                                                                                                                            
                                                                                                                            // Verify that option.validate() was called with the correct commandLine object
                                                                                                                            verify(mockOption).validate(commandLine);
                                                                                                                            
                                                                                                                            // The mutant would call validate(null) instead, so this verification would fail
                                                                                                                        }

    @Test
                                                                                                                    public void testValidateThrowsWhenTooManyOptions() throws Exception {
                                                                                                                        // Setup test objects
                                                                                                                        List<Option> options = new ArrayList<Option>();
                                                                                                                        Option firstOption = mock(Option.class);
                                                                                                                        options.add(firstOption);
                                                                                                                        
                                                                                                                        // Create group with maximum 1 option allowed
                                                                                                                        GroupImpl group = new GroupImpl(options, "testGroup", "description", 0, 1);
                                                                                                                        
                                                                                                                        // Add a second option to exceed maximum
                                                                                                                        Option secondOption = mock(Option.class);
                                                                                                                        options.add(secondOption);
                                                                                                                        
                                                                                                                        WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                        when(commandLine.hasOption(firstOption)).thenReturn(true);
                                                                                                                        when(commandLine.hasOption(secondOption)).thenReturn(true);
                                                                                                                        
                                                                                                                        // This should throw OptionException
                                                                                                                        try {
                                                                                                                            group.validate(commandLine);
                                                                                                                            fail("Expected OptionException to be thrown");
                                                                                                                        } catch (OptionException e) {
                                                                                                                            // Expected exception
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                                    public void testValidateThrowsWhenTooFewOptions() {
                                                                                                                        // Define required variables
                                                                                                                        List<Option> options = new ArrayList<Option>();
                                                                                                                        Option mockOption = mock(Option.class);
                                                                                                                        options.add(mockOption);
                                                                                                                        
                                                                                                                        // Create commandLine mock
                                                                                                                        WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                                                        
                                                                                                                        // Create group with min=1
                                                                                                                        GroupImpl group = new GroupImpl(options, "testGroup", "description", 1, 1);
                                                                                                                        when(commandLine.hasOption(mockOption)).thenReturn(false);
                                                                                                                        
                                                                                                                        // This should throw OptionException
                                                                                                                        try {
                                                                                                                            group.validate(commandLine);
                                                                                                                            fail("Expected OptionException to be thrown");
                                                                                                                        } catch (OptionException e) {
                                                                                                                            // Expected exception
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                                public void testValidate_CallsValidationForRequiredOption() throws Exception {
                                                                                                                    // Setup test data
                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                    Option mockRequiredOption = mock(Option.class);
                                                                                                                    when(mockRequiredOption.isRequired()).thenReturn(true);
                                                                                                                    options.add(mockRequiredOption);
                                                                                                                    
                                                                                                                    WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                                    when(mockCommandLine.hasOption(any(Option.class))).thenReturn(false);
                                                                                                                    
                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "desc", 0, 1);
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    group.validate(mockCommandLine);
                                                                                                                    
                                                                                                                    // Verify - this would fail if the mutant is present
                                                                                                                    verify(mockRequiredOption).validate(mockCommandLine);
                                                                                                                }

    @Test
                                                                                                                public void testValidate_CallsValidationForPresentOption() throws Exception {
                                                                                                                    // Setup test data
                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                    Option mockOption = mock(Option.class);
                                                                                                                    when(mockOption.isRequired()).thenReturn(false);
                                                                                                                    options.add(mockOption);
                                                                                                                    
                                                                                                                    WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                                    when(mockCommandLine.hasOption(mockOption)).thenReturn(true);
                                                                                                                    
                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "desc", 0, 1);
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    group.validate(mockCommandLine);
                                                                                                                    
                                                                                                                    // Verify - this would fail if the mutant is present
                                                                                                                    verify(mockOption).validate(mockCommandLine);
                                                                                                                }

    @Test
                                                                                                                public void testValidate_CallsValidationForGroupOption() throws Exception {
                                                                                                                    // Setup test data
                                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                                    Option mockGroupOption = mock(Option.class);
                                                                                                                    when(mockGroupOption.isRequired()).thenReturn(false);
                                                                                                                    when(mockGroupOption instanceof Group).thenReturn(true); // Simulate group option
                                                                                                                    options.add(mockGroupOption);
                                                                                                                    
                                                                                                                    WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                                    when(mockCommandLine.hasOption(any(Option.class))).thenReturn(false);
                                                                                                                    
                                                                                                                    GroupImpl group = new GroupImpl(options, "test", "desc", 0, 1);
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    group.validate(mockCommandLine);
                                                                                                                    
                                                                                                                    // Verify - this would fail if the mutant is present
                                                                                                                    verify(mockGroupOption).validate(mockCommandLine);
                                                                                                                }

    @Test
                                                                                                        public void testValidateCallsOptionValidateNotThisValidate1() {
                                                                                                            // Setup test data
                                                                                                            List<Option> options = new ArrayList<>();
                                                                                                            Option mockOption = mock(Option.class);
                                                                                                            when(mockOption.isRequired()).thenReturn(true); // Ensure it needs validation
                                                                                                            options.add(mockOption);
                                                                                                            
                                                                                                            WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                            when(mockCommandLine.hasOption(mockOption)).thenReturn(false); // Not present
                                                                                                            
                                                                                                            // Create GroupImpl with min=0, max=1 (so no count violations)
                                                                                                            GroupImpl group = new GroupImpl(options, "test", "desc", 0, 1);
                                                                                                            
                                                                                                            try {
                                                                                                                // Execute validation
                                                                                                                group.validate(mockCommandLine);
                                                                                                                
                                                                                                                // Verify option's validate was called, not GroupImpl's
                                                                                                                verify(mockOption).validate(mockCommandLine);
                                                                                                            } catch (OptionException e) {
                                                                                                                fail("Unexpected OptionException: " + e.getMessage());
                                                                                                            }
                                                                                                            
                                                                                                            // Also verify GroupImpl's validate wasn't called (would happen with mutant)
                                                                                                            try {
                                                                                                                verify(group, never()).validate(mockCommandLine);
                                                                                                            } catch (OptionException e) {
                                                                                                                fail("Unexpected OptionException during verification: " + e.getMessage());
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                public void testValidateCallsOptionValidateMethod() throws OptionException {
                                                                                                    // Setup test data
                                                                                                    List<Option> options = new ArrayList<>();
                                                                                                    Option mockOption = mock(Option.class);
                                                                                                    when(mockOption.isRequired()).thenReturn(true);
                                                                                                    options.add(mockOption);
                                                                                                    
                                                                                                    WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                                    when(mockCommandLine.hasOption(mockOption)).thenReturn(true);
                                                                                                    
                                                                                                    // Create GroupImpl with min=0, max=1 (so our single option is acceptable)
                                                                                                    GroupImpl group = new GroupImpl(options, "test", "description", 0, 1);
                                                                                                    
                                                                                                    // Execute validation
                                                                                                    group.validate(mockCommandLine);
                                                                                                    
                                                                                                    // Verify the option's validate method was called
                                                                                                    verify(mockOption).validate(mockCommandLine);
                                                                                                    
                                                                                                    // Additional verification that group validation didn't throw exceptions
                                                                                                    // (implicitly verified by test not failing)
                                                                                                }

    @Test
                                                                                        public void testValidateShouldNotValidateNonRequiredNonGroupOptionWhenNotPresent() throws OptionException {
                                                                                            // Setup test data
                                                                                            List<Option> options = new ArrayList<>();
                                                                                            Option mockOption = mock(Option.class);
                                                                                            when(mockOption.isRequired()).thenReturn(false);
                                                                                            options.add(mockOption);
                                                                                            
                                                                                            List<Option> anonymous = new ArrayList<>();
                                                                                            WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                                                            when(mockCommandLine.hasOption(mockOption)).thenReturn(false);
                                                                                            
                                                                                            // Create GroupImpl with min=0, max=1 (so no validation errors)
                                                                                            GroupImpl group = new GroupImpl(options, "test", "desc", 0, 1);
                                                                                            
                                                                                            // Execute validation
                                                                                            group.validate(mockCommandLine);
                                                                                            
                                                                                            // Verify - option.validate() should NOT be called since:
                                                                                            // 1. It's not required (isRequired=false)
                                                                                            // 2. It's not a Group
                                                                                            // 3. It's not present on command line (hasOption=false)
                                                                                            verify(mockOption, never()).validate(mockCommandLine);
                                                                                            
                                                                                            // The mutant would call validate() anyway since it sets validate=true unconditionally
                                                                                            // This test would fail for the mutant version
                                                                                        }

    @Test
                                                                                public void testValidateShouldValidateGroupOptionsEvenWhenNotRequired() throws OptionException {
                                                                                    // Setup
                                                                                    List<Option> options = new ArrayList<>();
                                                                                    Option groupOption = mock(Option.class);
                                                                                    when(groupOption.isRequired()).thenReturn(false);
                                                                                    when(groupOption instanceof Group).thenReturn(true); // Mock the instanceof check
                                                                                    options.add(groupOption);
                                                                                    
                                                                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                                    when(commandLine.hasOption(groupOption)).thenReturn(false);
                                                                                    
                                                                                    GroupImpl group = new GroupImpl(options, "testGroup", "description", 0, 1);
                                                                                    
                                                                                    // Execute
                                                                                    group.validate(commandLine);
                                                                                    
                                                                                    // Verify - the key assertion that catches the mutant
                                                                                    verify(groupOption).validate(commandLine);
                                                                                    
                                                                                    // Additional assertions for completeness
                                                                                    verify(commandLine).hasOption(groupOption);
                                                                                    verifyNoMoreInteractions(groupOption, commandLine);
                                                                                }

    @Test
                                                                        public void testValidate_GroupOptionValidation() {
                                                                            // Setup test data
                                                                            List<Option> options = new ArrayList<>();
                                                                            List<Option> anonymous = new ArrayList<>();
                                                                            
                                                                            // Create a mock Group option that is not required
                                                                            Option groupOption = mock(Option.class);
                                                                            when(groupOption.isRequired()).thenReturn(false);
                                                                            when(groupOption instanceof Group).thenReturn(true); // Mock instanceof
                                                                            
                                                                            // Create a mock regular option that is not required
                                                                            Option regularOption = mock(Option.class);
                                                                            when(regularOption.isRequired()).thenReturn(false);
                                                                            
                                                                            options.add(groupOption);
                                                                            options.add(regularOption);
                                                                            
                                                                            // Create command line that doesn't have any options (to test default validation)
                                                                            WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                            when(commandLine.hasOption(any(Option.class))).thenReturn(false);
                                                                            
                                                                            // Create GroupImpl with min=0, max=2 (so no quantity violations)
                                                                            GroupImpl group = new GroupImpl(options, "test", "desc", 0, 2);
                                                                            
                                                                            // Set anonymous list via reflection since it's final
                                                                            try {
                                                                                Field anonymousField = GroupImpl.class.getDeclaredField("anonymous");
                                                                                anonymousField.setAccessible(true);
                                                                                anonymousField.set(group, anonymous);
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set anonymous field via reflection");
                                                                            }
                                                                            
                                                                            try {
                                                                                // Test - should validate the group option in original, but mutant won't
                                                                                group.validate(commandLine);
                                                                                
                                                                                // Verify group option was validated (original behavior)
                                                                                verify(groupOption).validate(commandLine);
                                                                                
                                                                                // Verify regular option was not validated (both original and mutant)
                                                                                verify(regularOption, never()).validate(commandLine);
                                                                            } catch (OptionException e) {
                                                                                fail("Unexpected OptionException: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                            public void testValidate_TooManyOptions_ThrowsExceptionWithCorrectOptionName() throws OptionException {
                                                                // Setup
                                                                List<Option> options = new ArrayList<>();
                                                                Option option1 = mock(Option.class);
                                                                Option option2 = mock(Option.class);
                                                                when(option1.isRequired()).thenReturn(false);
                                                                when(option2.isRequired()).thenReturn(false);
                                                                when(option1.getPreferredName()).thenReturn("opt1");
                                                                when(option2.getPreferredName()).thenReturn("opt2");
                                                                options.add(option1);
                                                                options.add(option2);
                                                                
                                                                WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                                when(commandLine.hasOption(any(Option.class))).thenReturn(true);
                                                                
                                                                // Group with max 1 option but we'll provide 2
                                                                GroupImpl group = new GroupImpl(options, "testGroup", "description", 0, 1);
                                                                
                                                                try {
                                                                    // Exercise
                                                                    group.validate(commandLine);
                                                                    fail("Expected OptionException to be thrown");
                                                                } catch (OptionException e) {
                                                                    // Verify
                                                                    assertEquals("opt2", e.getMessage()); // Should be the second option's name
                                                                    throw e;
                                                                }
                                                            }

    @Test
                                                    public void testValidate_DetectsExcessOptionsAndBreaks() throws OptionException {
                                                        // Setup test data - group allows 1 option max
                                                        List<Option> options = new ArrayList<>();
                                                        Option option1 = mock(Option.class);
                                                        Option option2 = mock(Option.class);
                                                        options.add(option1);
                                                        options.add(option2);
                                                        
                                                        // Configure mocks
                                                        when(option1.isRequired()).thenReturn(true);
                                                        when(option2.isRequired()).thenReturn(true);
                                                        WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                                        when(commandLine.hasOption(any(Option.class))).thenReturn(true);
                                                        
                                                        // Create group with min=1, max=1
                                                        GroupImpl group = new GroupImpl(options, "test", "desc", 1, 1);
                                                        
                                                        // Track validation calls
                                                        List<Option> validatedOptions = new ArrayList<>();
                                                        doAnswer(invocation -> {
                                                            validatedOptions.add(invocation.getArgument(0));
                                                            return null;
                                                        }).when(option1).validate(any(WriteableCommandLine.class));
                                                        doAnswer(invocation -> {
                                                            validatedOptions.add(invocation.getArgument(0));
                                                            return null;
                                                        }).when(option2).validate(any(WriteableCommandLine.class));
                                                        
                                                        try {
                                                            group.validate(commandLine);
                                                            fail("Expected OptionException");
                                                        } catch (OptionException e) {
                                                            // Verify only one option was validated before exception
                                                            assertEquals(1, validatedOptions.size());
                                                            // Verify exception was thrown for unexpected option
                                                            assertNotNull(e.getMessage());
                                                        }
                                                    }

    @Test
                                            public void testValidateShouldNotValidateNonRequiredNonGroupAbsentOption() throws OptionException {
                                                // Setup
                                                List<Option> options = new ArrayList<>();
                                                Option mockOption = mock(Option.class);
                                                when(mockOption.isRequired()).thenReturn(false);
                                                // mockOption is not a Group instance
                                                options.add(mockOption);
                                                
                                                WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                                                when(mockCommandLine.hasOption(mockOption)).thenReturn(false);
                                                
                                                GroupImpl group = new GroupImpl(options, "test", "desc", 0, 1);
                                                
                                                // Execute
                                                group.validate(mockCommandLine);
                                                
                                                // Verify - option should not be validated since it's not required, not a group, and not present
                                                verify(mockOption, never()).validate(mockCommandLine);
                                                
                                                // Additional assertions for other behaviors
                                                // No exception should be thrown for this case
                                            }

    @Test
                                public void testValidateShouldCallOptionValidateWithCommandLine() throws OptionException {
                                    // Setup
                                    List<Option> options = new ArrayList<>();
                                    Option mockOption = mock(Option.class);
                                    options.add(mockOption);
                                    GroupImpl groupImpl = new GroupImpl(options, "testGroup", "description", 0, 1);
                                    WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                                    
                                    // When
                                    groupImpl.validate(commandLine);
                                    
                                    // Then verify option.validate() was called with real commandLine
                                    verify(mockOption).validate(commandLine);
                                    
                                    // This assertion would fail if mutant is present (validate(null))
                                    // because mockito would record null parameter instead
                                }

    @Test
                        public void testValidateThrowsWhenOptionValidationFails() throws OptionException {
                            // Create mock objects
                            Option mockOption = mock(Option.class);
                            WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                            
                            // Create GroupImpl with mock option
                            List<Option> options = Collections.singletonList(mockOption);
                            GroupImpl groupImpl = new GroupImpl(options, "testGroup", "description", 0, 1);
                            
                            // Configure mock option to throw when validated with command line
                            doThrow(new OptionException(null, null))
                                .when(mockOption).validate(commandLine);
                            
                            try {
                                // This should throw OptionException because we're validating with commandLine
                                groupImpl.validate(commandLine);
                                fail("Expected OptionException to be thrown");
                            } catch (OptionException e) {
                                // Expected exception
                            }
                        }

    @Test
                    public void testValidate_CallsValidationForRequiredOptionNotInCommandLine() throws Exception {
                        // Setup
                        List<Option> options = new ArrayList<>();
                        Option requiredOption = mock(Option.class);
                        when(requiredOption.isRequired()).thenReturn(true);
                        options.add(requiredOption);
                        
                        WriteableCommandLine commandLine = mock(WriteableCommandLine.class);
                        when(commandLine.hasOption(requiredOption)).thenReturn(false);
                        
                        GroupImpl group = new GroupImpl(options, "test", "description", 0, 1);
                        
                        // Exercise
                        group.validate(commandLine);
                        
                        // Verify
                        verify(requiredOption).validate(commandLine);
                    }

    @Test
            public void testValidateCallsOptionValidateMethod1() throws OptionException {
                // Setup test data
                List<Option> options = new ArrayList<>();
                Option mockOption = mock(Option.class);
                when(mockOption.isRequired()).thenReturn(true); // Make it require validation
                options.add(mockOption);
                
                WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
                when(mockCommandLine.hasOption(mockOption)).thenReturn(false); // Not present in command line
                
                // Create group with min=0, max=1 to avoid triggering count exceptions
                GroupImpl group = new GroupImpl(options, "testGroup", "description", 0, 1);
                
                // Execute validation
                group.validate(mockCommandLine);
                
                // Verify the option's validate method was called (would fail with mutant)
                verify(mockOption).validate(mockCommandLine);
                
                // Additional verification that group's validate wasn't called (though not strictly necessary)
                // This line was incorrect in original test as it contradicts the previous verification
                // Removed as it doesn't make logical sense
            }

    @Test
    public void testValidateCallsOptionValidateNotGroupValidate() throws OptionException {
        // Setup test data
        List<Option> options = new ArrayList<>();
        Option mockOption = mock(Option.class);
        when(mockOption.isRequired()).thenReturn(true); // Make it required so it gets validated
        options.add(mockOption);
        
        WriteableCommandLine mockCommandLine = mock(WriteableCommandLine.class);
        when(mockCommandLine.hasOption(mockOption)).thenReturn(true); // Option is present
        
        // Create GroupImpl with min=1, max=1 (exactly one option required)
        GroupImpl group = new GroupImpl(options, "test", "desc", 1, 1);
        
        // Execute validation
        group.validate(mockCommandLine);
        
        // Verify the correct validate method was called
        verify(mockOption).validate(mockCommandLine); // This would fail if mutant survives
        
        // Additional verification that group's validate wasn't called recursively
        // (though this might be harder to verify directly)
        
        // Also verify no exceptions were thrown for this case
        // (implicit in test not throwing exceptions)
    }


}
