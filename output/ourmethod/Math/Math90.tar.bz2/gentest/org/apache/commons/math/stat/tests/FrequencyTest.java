package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                            public void testAddValue_Comparable_FirstTimeAddition() {
                                                Frequency frequency = new Frequency();
                                                Comparable<String> value = "test";
                                                
                                                frequency.addValue(value);
                                                
                                                assertEquals(1, frequency.getCount(value));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Comparable_MultipleAdditions() {
                                                Frequency frequency = new Frequency();
                                                Comparable<Integer> value = 42;
                                                
                                                frequency.addValue(value);
                                                frequency.addValue(value);
                                                frequency.addValue(value);
                                                
                                                assertEquals(3, frequency.getCount(value));
                                                assertEquals(3, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Comparable_NullValue() {
                                                Frequency frequency = new Frequency();
                                                
                                                thrown.expect(IllegalArgumentException.class);
                                                frequency.addValue((Comparable<?>) null);
                                            }

    @Test
                                            public void testAddValue_Comparable_DifferentTypes() {
                                                Frequency frequency = new Frequency();
                                                Comparable<String> stringValue = "abc";
                                                Comparable<Integer> intValue = 123;
                                                
                                                frequency.addValue(stringValue);
                                                frequency.addValue(intValue);
                                                frequency.addValue(stringValue);
                                                
                                                assertEquals(2, frequency.getCount(stringValue));
                                                assertEquals(1, frequency.getCount(intValue));
                                                assertEquals(3, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Comparable_WithCustomComparator() {
                                                Comparator<String> caseInsensitiveComparator = String.CASE_INSENSITIVE_ORDER;
                                                Frequency frequency = new Frequency(caseInsensitiveComparator);
                                                
                                                Comparable<String> value1 = "Test";
                                                Comparable<String> value2 = "TEST";
                                                
                                                frequency.addValue(value1);
                                                frequency.addValue(value2);
                                                
                                                assertEquals(2, frequency.getCount(value1));
                                                assertEquals(2, frequency.getCount(value2));
                                                assertEquals(2, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Comparable_AfterClear() {
                                                Frequency frequency = new Frequency();
                                                Comparable<Character> value = 'A';
                                                
                                                frequency.addValue(value);
                                                frequency.clear();
                                                frequency.addValue(value);
                                                
                                                assertEquals(1, frequency.getCount(value));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Comparable_MixedWithOtherAddMethods() {
                                                Frequency frequency = new Frequency();
                                                Comparable<Integer> comparableValue = 10;
                                                int primitiveValue = 10;
                                                Integer wrapperValue = 10;
                                                
                                                frequency.addValue(comparableValue);
                                                frequency.addValue(primitiveValue);
                                                frequency.addValue(wrapperValue);
                                                
                                                assertEquals(3, frequency.getCount(10));
                                                assertEquals(3, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_AddsValueToEmptyFrequencyTable() {
                                                Frequency frequency = new Frequency();
                                                long value = 5L;
                                                
                                                frequency.addValue(value);
                                                
                                                assertEquals(1, frequency.getCount(value));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_AddsValueToNonEmptyFrequencyTable() {
                                                Frequency frequency = new Frequency();
                                                long value1 = 5L;
                                                long value2 = 10L;
                                                
                                                frequency.addValue(value1);
                                                frequency.addValue(value1);
                                                frequency.addValue(value2);
                                                
                                                assertEquals(2, frequency.getCount(value1));
                                                assertEquals(1, frequency.getCount(value2));
                                                assertEquals(3, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_AddsSameValueMultipleTimes() {
                                                Frequency frequency = new Frequency();
                                                long value = 7L;
                                                
                                                frequency.addValue(value);
                                                frequency.addValue(value);
                                                frequency.addValue(value);
                                                
                                                assertEquals(3, frequency.getCount(value));
                                                assertEquals(3, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_HandlesNegativeValues() {
                                                Frequency frequency = new Frequency();
                                                long value = -3L;
                                                
                                                frequency.addValue(value);
                                                
                                                assertEquals(1, frequency.getCount(value));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_HandlesZeroValue() {
                                                Frequency frequency = new Frequency();
                                                long value = 0L;
                                                
                                                frequency.addValue(value);
                                                
                                                assertEquals(1, frequency.getCount(value));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_HandlesMaxLongValue() {
                                                Frequency frequency = new Frequency();
                                                long value = Long.MAX_VALUE;
                                                
                                                frequency.addValue(value);
                                                
                                                assertEquals(1, frequency.getCount(value));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_HandlesMinLongValue() {
                                                Frequency frequency = new Frequency();
                                                long value = Long.MIN_VALUE;
                                                
                                                frequency.addValue(value);
                                                
                                                assertEquals(1, frequency.getCount(value));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_WorksWithCustomComparator() {
                                                Comparator<Long> comparator = mock(Comparator.class);
                                                Frequency frequency = new Frequency(comparator);
                                                long value = 5L;
                                                
                                                frequency.addValue(value);
                                                
                                                assertEquals(1, frequency.getCount(value));
                                                assertEquals(1, frequency.getSumFreq());
                                                verify(comparator, times(1)).compare(eq(value), eq(value));
                                            }

    @Test
                                            public void testAddValue_Long_AfterClearOperation() {
                                                Frequency frequency = new Frequency();
                                                long value1 = 5L;
                                                long value2 = 10L;
                                                
                                                frequency.addValue(value1);
                                                frequency.clear();
                                                frequency.addValue(value2);
                                                
                                                assertEquals(0, frequency.getCount(value1));
                                                assertEquals(1, frequency.getCount(value2));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_MixedWithOtherAddValueMethods() {
                                                Frequency frequency = new Frequency();
                                                long longValue = 5L;
                                                int intValue = 5;
                                                char charValue = '5';
                                                Integer integerValue = Integer.valueOf(5);
                                                
                                                frequency.addValue(longValue);
                                                frequency.addValue(intValue);
                                                frequency.addValue(charValue);
                                                frequency.addValue(integerValue);
                                                
                                                assertEquals(4, frequency.getCount(5L));
                                                assertEquals(4, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_WithLongObject_ShouldIncrementCount() {
                                                Frequency frequency = new Frequency();
                                                Long value = Long.valueOf(5L);
                                                
                                                // First addition
                                                frequency.addValue(value);
                                                assertEquals(1L, frequency.getCount(value));
                                                
                                                // Second addition
                                                frequency.addValue(value);
                                                assertEquals(2L, frequency.getCount(value));
                                            }

    @Test
                                            public void testAddValue_WithDifferentLongObjects_ShouldTrackSeparately() {
                                                Frequency frequency = new Frequency();
                                                Long value1 = Long.valueOf(5L);
                                                Long value2 = Long.valueOf(10L);
                                                
                                                frequency.addValue(value1);
                                                frequency.addValue(value2);
                                                frequency.addValue(value1);
                                                
                                                assertEquals(2L, frequency.getCount(value1));
                                                assertEquals(1L, frequency.getCount(value2));
                                            }

    @Test
                                            public void testAddValue_WithNull_ShouldThrowException() {
                                                Frequency frequency = new Frequency();
                                                
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("Value cannot be null");
                                                
                                                frequency.addValue((Long)null);
                                            }

    @Test
                                            public void testAddValue_WithCustomComparator_ShouldUseComparator() {
                                                // Create a custom comparator that treats all values as equal
                                                Comparator<Long> comparator = mock(Comparator.class);
                                                when(comparator.compare(anyLong(), anyLong())).thenReturn(0);
                                                
                                                Frequency frequency = new Frequency(comparator);
                                                Long value1 = Long.valueOf(5L);
                                                Long value2 = Long.valueOf(10L);
                                                
                                                frequency.addValue(value1);
                                                frequency.addValue(value2);
                                                
                                                // Both values should be considered the same by our comparator
                                                assertEquals(2L, frequency.getCount(value1));
                                                assertEquals(2L, frequency.getCount(value2));
                                                
                                                verify(comparator, atLeastOnce()).compare(anyLong(), anyLong());
                                            }

    @Test
                                            public void testAddValue_WithMaxAndMinLongValues_ShouldHandleCorrectly() {
                                                Frequency frequency = new Frequency();
                                                Long minValue = Long.MIN_VALUE;
                                                Long maxValue = Long.MAX_VALUE;
                                                
                                                frequency.addValue(minValue);
                                                frequency.addValue(maxValue);
                                                frequency.addValue(minValue);
                                                
                                                assertEquals(2L, frequency.getCount(minValue));
                                                assertEquals(1L, frequency.getCount(maxValue));
                                            }

    @Test
                                            public void testAddValue_ShouldIncreaseTotalFrequencyCount() {
                                                Frequency frequency = new Frequency();
                                                Long value1 = Long.valueOf(1L);
                                                Long value2 = Long.valueOf(2L);
                                                
                                                assertEquals(0L, frequency.getSumFreq());
                                                
                                                frequency.addValue(value1);
                                                assertEquals(1L, frequency.getSumFreq());
                                                
                                                frequency.addValue(value2);
                                                assertEquals(2L, frequency.getSumFreq());
                                                
                                                frequency.addValue(value1);
                                                assertEquals(3L, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_AddSingleValue() {
                                                Frequency frequency = new Frequency();
                                                frequency.addValue(5L);
                                                
                                                assertEquals(1, frequency.getCount(5L));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_AddMultipleValues() {
                                                Frequency frequency = new Frequency();
                                                frequency.addValue(10L);
                                                frequency.addValue(10L);
                                                frequency.addValue(20L);
                                                
                                                assertEquals(2, frequency.getCount(10L));
                                                assertEquals(1, frequency.getCount(20L));
                                                assertEquals(3, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_AddZeroValue() {
                                                Frequency frequency = new Frequency();
                                                frequency.addValue(0L);
                                                frequency.addValue(0L);
                                                frequency.addValue(0L);
                                                
                                                assertEquals(3, frequency.getCount(0L));
                                                assertEquals(3, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_AddNegativeValue() {
                                                Frequency frequency = new Frequency();
                                                frequency.addValue(-5L);
                                                frequency.addValue(-5L);
                                                frequency.addValue(-10L);
                                                
                                                assertEquals(2, frequency.getCount(-5L));
                                                assertEquals(1, frequency.getCount(-10L));
                                                assertEquals(3, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_AddMaxLongValue() {
                                                Frequency frequency = new Frequency();
                                                frequency.addValue(Long.MAX_VALUE);
                                                frequency.addValue(Long.MAX_VALUE);
                                                
                                                assertEquals(2, frequency.getCount(Long.MAX_VALUE));
                                                assertEquals(2, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_AddMinLongValue() {
                                                Frequency frequency = new Frequency();
                                                frequency.addValue(Long.MIN_VALUE);
                                                
                                                assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_WithCustomComparator() {
                                                Comparator<Long> reverseComparator = Comparator.reverseOrder();
                                                Frequency frequency = new Frequency(reverseComparator);
                                                
                                                frequency.addValue(100L);
                                                frequency.addValue(200L);
                                                frequency.addValue(100L);
                                                
                                                assertEquals(2, frequency.getCount(100L));
                                                assertEquals(1, frequency.getCount(200L));
                                                assertEquals(3, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Long_AfterClear() {
                                                Frequency frequency = new Frequency();
                                                frequency.addValue(5L);
                                                frequency.addValue(5L);
                                                frequency.clear();
                                                frequency.addValue(10L);
                                                
                                                assertEquals(0, frequency.getCount(5L));
                                                assertEquals(1, frequency.getCount(10L));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Char_AddSingleCharacter() {
                                                Frequency frequency = new Frequency();
                                                char testChar = 'a';
                                                
                                                frequency.addValue(testChar);
                                                
                                                assertEquals(1, frequency.getCount(testChar));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Char_AddMultipleSameCharacters() {
                                                Frequency frequency = new Frequency();
                                                char testChar = 'z';
                                                int count = 5;
                                                
                                                for (int i = 0; i < count; i++) {
                                                    frequency.addValue(testChar);
                                                }
                                                
                                                assertEquals(count, frequency.getCount(testChar));
                                                assertEquals(count, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Char_AddDifferentCharacters() {
                                                Frequency frequency = new Frequency();
                                                char[] testChars = {'a', 'b', 'c', 'a', 'b', 'a'};
                                                
                                                for (char c : testChars) {
                                                    frequency.addValue(c);
                                                }
                                                
                                                assertEquals(3, frequency.getCount('a'));
                                                assertEquals(2, frequency.getCount('b'));
                                                assertEquals(1, frequency.getCount('c'));
                                                assertEquals(6, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Char_WithSpecialCharacters() {
                                                Frequency frequency = new Frequency();
                                                char[] specialChars = {'\n', '\t', ' ', '!', '@'};
                                                
                                                for (char c : specialChars) {
                                                    frequency.addValue(c);
                                                }
                                                
                                                for (char c : specialChars) {
                                                    assertEquals(1, frequency.getCount(c));
                                                }
                                                assertEquals(specialChars.length, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Char_WithComparatorConstructor() {
                                                Comparator<Character> caseInsensitiveComparator = (c1, c2) -> 
                                                    Character.toLowerCase(c1) - Character.toLowerCase(c2);
                                                Frequency frequency = new Frequency(caseInsensitiveComparator);
                                                
                                                frequency.addValue('A');
                                                frequency.addValue('a');
                                                frequency.addValue('B');
                                                frequency.addValue('b');
                                                
                                                assertEquals(2, frequency.getCount('A'));
                                                assertEquals(2, frequency.getCount('a'));
                                                assertEquals(2, frequency.getCount('B'));
                                                assertEquals(2, frequency.getCount('b'));
                                                assertEquals(4, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Char_AfterClear() {
                                                Frequency frequency = new Frequency();
                                                frequency.addValue('x');
                                                frequency.addValue('y');
                                                frequency.clear();
                                                
                                                frequency.addValue('z');
                                                
                                                assertEquals(0, frequency.getCount('x'));
                                                assertEquals(0, frequency.getCount('y'));
                                                assertEquals(1, frequency.getCount('z'));
                                                assertEquals(1, frequency.getSumFreq());
                                            }

    @Test
                                            public void testAddValue_Char_UnicodeCharacters() {
                                                Frequency frequency = new Frequency();
                                                char[] unicodeChars = {'\u03A9', '\u221E', '\u00A9'};
                                                
                                                for (char c : unicodeChars) {
                                                    frequency.addValue(c);
                                                }
                                                
                                                for (char c : unicodeChars) {
                                                    assertEquals(1, frequency.getCount(c));
                                                }
                                                assertEquals(unicodeChars.length, frequency.getSumFreq());
                                            }

    @Test
                                    public void testAddValue_Long_VerifyTreeMapInteraction() throws Exception {
                                        @SuppressWarnings("unchecked")
                                        TreeMap<Long, Long> mockTreeMap = mock(TreeMap.class);
                                        Frequency frequency = new Frequency();
                                        
                                        // Use reflection to set the private freqTable field
                                        Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                        freqTableField.setAccessible(true);
                                        freqTableField.set(frequency, mockTreeMap);
                                        
                                        frequency.addValue(42L);
                                        
                                        verify(mockTreeMap).put(42L, 1L);
                                        
                                        frequency.addValue(42L);
                                        verify(mockTreeMap).put(42L, 2L);
                                    }

    @Test
                                    public void testAddValue_Char_VerifyTreeMapInteraction() throws Exception {
                                        @SuppressWarnings("unchecked")
                                        TreeMap<Character, Long> mockTreeMap = mock(TreeMap.class);
                                        Frequency frequency = new Frequency();
                                        
                                        // Use reflection to set the private freqTable field
                                        Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                        freqTableField.setAccessible(true);
                                        freqTableField.set(frequency, mockTreeMap);
                                        
                                        char testChar = 'm';
                                        
                                        frequency.addValue(testChar);
                                        
                                        verify(mockTreeMap).put(eq(testChar), anyLong());
                                    }

    @Test
                                    public void testAddValueObjectDoesNotThrowException() throws Exception {
                                        // Test that original behavior still works (no exception)
                                        Frequency frequency = new Frequency();
                                        Object testValue = "test";
                                        
                                        // Should not throw exception
                                        frequency.addValue(testValue);
                                        
                                        // Verify value was added
                                        assertEquals(1, frequency.getCount(testValue));
                                    }

    @Test
                                    public void testAddValueObjectSignatureChange() {
                                        // Verify the method can now throw Exception
                                        try {
                                            Frequency.class.getMethod("addValue", Object.class);
                                            fail("Method should now declare throws Exception");
                                        } catch (NoSuchMethodException e) {
                                            // Expected if method doesn't exist
                                        } catch (Exception e) {
                                            // Should get here for the mutated version
                                            assertTrue(true);
                                        }
                                    }

    @Test
                            public void testAddValueObjectCanNowThrowException() throws Exception {
                                // Create a mock that will throw exception
                                Frequency frequencyMock = mock(Frequency.class);
                                Object testValue = "test";
                                
                                // Set up mock to throw exception
                                doThrow(new Exception()).when(frequencyMock).addValue(any(Object.class));
                                
                                // This should throw exception now
                                frequencyMock.addValue(testValue);
                            }

    @Test(expected = ClassCastException.class)
                            public void testAddNonComparableObject() {
                                // Create a Frequency object with natural ordering
                                Frequency frequency = new Frequency();
                                
                                // Create a non-Comparable object
                                Object nonComparable = new Object() {
                                    @Override
                                    public String toString() {
                                        return "NonComparable";
                                    }
                                };
                                
                                // Try to add the non-Comparable object
                                frequency.addValue(nonComparable);
                                
                                // This line should throw ClassCastException when TreeMap tries to compare
                                // If the mutation survives, it will throw the exception here
                                frequency.toString();
                            }

    @Test
                            public void testAddNonComparableWithCustomComparator() {
                                // Create a custom comparator that can handle any object
                                Comparator<Object> comparator = (o1, o2) -> 0; // Always equal
                                
                                // Create Frequency with custom comparator
                                Frequency frequency = new Frequency(comparator);
                                
                                // Create a non-Comparable object
                                Object nonComparable = new Object() {
                                    @Override
                                    public String toString() {
                                        return "NonComparable";
                                    }
                                };
                                
                                // Add the non-Comparable object - should work with custom comparator
                                frequency.addValue(nonComparable);
                                
                                // This should not throw exception
                                String result = frequency.toString();
                                assertTrue(result.contains("NonComparable"));
                            }

    @Test
                public void testToStringWithGenericComparables() {
                    // Define CustomComparable class inside the test method
                    class CustomComparable implements Comparable<CustomComparable> {
                        private int value;
                        
                        public CustomComparable(int value) {
                            this.value = value;
                        }
                        
                        @Override
                        public int compareTo(CustomComparable o) {
                            return Integer.compare(this.value, o.value);
                        }
                        
                        @Override
                        public String toString() {
                            return "CustomComparable[value=" + value + "]";
                        }
                    }
                
                    // Create a frequency object with natural ordering
                    Frequency freq = new Frequency();
                    
                    // Add different types of comparable objects that would test the generic type safety
                    freq.addValue("stringValue");
                    freq.addValue(123);
                    freq.addValue(456L);
                    freq.addValue('c');
                    
                    // Also add a custom comparable object
                    freq.addValue(new CustomComparable(1));
                    
                    // Get the string representation
                    String result = freq.toString();
                    
                    // Verify all values are properly formatted in the output
                    assertTrue(result.contains("stringValue"));
                    assertTrue(result.contains("123"));
                    assertTrue(result.contains("456"));
                    assertTrue(result.contains("c"));
                    assertTrue(result.contains("CustomComparable[value=1]"));
                    
                    // Verify the format contains all expected columns
                    assertTrue(result.contains("Value\tFreq.\tPct.\tCum Pct."));
                    assertTrue(result.contains("\t"));
                    assertTrue(result.contains("\n"));
                }

    @Test
        public void testAddValueWithDifferentComparableTypes() {
            // Define a simple raw Comparable implementation
            class MyRawComparable implements Comparable {
                @Override
                public int compareTo(Object o) {
                    return 0; // simple implementation for testing
                }
            }
        
            // Create a frequency object
            Frequency frequency = new Frequency();
            
            // Create different types of Comparable objects
            Comparable<?> genericComparable1 = Integer.valueOf(1);
            Comparable<?> genericComparable2 = "string";
            Comparable rawComparable = new MyRawComparable();
            
            // Add values - this should work with original but might fail with mutant
            frequency.addValue(genericComparable1);
            frequency.addValue(genericComparable2);
            frequency.addValue(rawComparable);
            
            // Verify all values were added correctly
            assertEquals(1, frequency.getCount(genericComparable1));
            assertEquals(1, frequency.getCount(genericComparable2));
            assertEquals(1, frequency.getCount(rawComparable));
        }

    @Test
    public void testToStringWithLargeIntegerValues() {
        // Setup
        Frequency frequency = new Frequency();
        Integer largeValue = Integer.MAX_VALUE;
        Integer negativeValue = Integer.MIN_VALUE;
        
        // Add values multiple times to create frequencies
        frequency.addValue(largeValue);
        frequency.addValue(largeValue); // count = 2
        frequency.addValue(negativeValue); // count = 1
        
        // Expected strings - these would differ between original and mutant
        String expectedLargeValueLine = largeValue + "\t2\t"; // Count should be 2
        String expectedNegativeValueLine = negativeValue + "\t1\t"; // Count should be 1
        
        // Execute
        String result = frequency.toString();
        
        // Verify
        assertTrue("Output should contain large value line", 
                  result.contains(expectedLargeValueLine));
        assertTrue("Output should contain negative value line", 
                  result.contains(expectedNegativeValueLine));
        
        // Verify percentages (mutant might show wrong percentages due to int conversion)
        String[] lines = result.split("\n");
        for (String line : lines) {
            if (line.contains(String.valueOf(largeValue))) {
                assertTrue("Large value percentage should be correct",
                          line.contains("66.66%") || line.contains("67%")); // 2/3
            }
            if (line.contains(String.valueOf(negativeValue))) {
                assertTrue("Negative value percentage should be correct",
                          line.contains("33.33%") || line.contains("33%")); // 1/3
            }
        }
    }

}
