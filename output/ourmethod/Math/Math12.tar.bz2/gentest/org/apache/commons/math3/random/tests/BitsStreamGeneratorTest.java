package gentest.org.apache.commons.math3.random.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.random.*;
import java.io.Serializable;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.util.FastMath;
 
public class BitsStreamGeneratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                public void testNextInt_ThrowsForNegativeInput() {
                                                                                                    BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                    when(generator.nextInt(anyInt())).thenCallRealMethod();
                                                                                                    
                                                                                                    thrown.expect(NotStrictlyPositiveException.class);
                                                                                                    generator.nextInt(-5);
                                                                                                }

    @Test
                                                                                                public void testNextInt_ThrowsForZeroInput() {
                                                                                                    BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                                    when(generator.nextInt(anyInt())).thenCallRealMethod();
                                                                                                    
                                                                                                    thrown.expect(NotStrictlyPositiveException.class);
                                                                                                    generator.nextInt(0);
                                                                                                }

    @Test
                                                                                        public void testSetSeedWithIntArrayNull() {
                                                                                            org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.MersenneTwister();
                                                                                            org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                            exception.expect(NullPointerException.class);
                                                                                            generator.setSeed((int[])null);
                                                                                        }

    @Test
                                                                                        public void testConstructorInitializesNextGaussian() throws Exception {
                                                                                            // Create an instance of the generator (using a concrete subclass since BitsStreamGenerator is abstract)
                                                                                            BitsStreamGenerator generator = new MersenneTwister();
                                                                                            
                                                                                            // Use reflection to access the private nextGaussian field
                                                                                            Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                            nextGaussianField.setAccessible(true);
                                                                                            double nextGaussianValue = nextGaussianField.getDouble(generator);
                                                                                            
                                                                                            // Verify the constructor sets nextGaussian to NaN
                                                                                            assertTrue(Double.isNaN(nextGaussianValue));
                                                                                        }

    @Test
                                                                                        public void testSetSeed_Int_ValidValue() {
                                                                                            // Create a concrete subclass of BitsStreamGenerator for testing
                                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                public void setSeed(int seed) {
                                                                                                    // Empty implementation for testing
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {
                                                                                                    // Empty implementation for testing
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                public void setSeed(long seed) {
                                                                                                    // Empty implementation for testing
                                                                                                }
                                                                                                
                                                                                                @Override
                                                                                                protected int next(int bits) {
                                                                                                    return 0; // Empty implementation for testing
                                                                                                }
                                                                                            };
                                                                                        
                                                                                            // Test with typical positive value
                                                                                            generator.setSeed(12345);
                                                                                            // Verify no exception is thrown
                                                                                            
                                                                                            // Test with zero
                                                                                            generator.setSeed(0);
                                                                                            
                                                                                            // Test with negative value
                                                                                            generator.setSeed(-12345);
                                                                                        }

    @Test
                                                                                        public void testSetSeed_IntArray_ValidValues() {
                                                                                            // Create a concrete instance of BitsStreamGenerator for testing
                                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                                
                                                                                                @Override
                                                                                                protected int next(int bits) {
                                                                                                    return 0;
                                                                                                }
                                                                                            };
                                                                                            
                                                                                            // Test with typical array
                                                                                            generator.setSeed(new int[]{1, 2, 3, 4});
                                                                                            
                                                                                            // Test with single element
                                                                                            generator.setSeed(new int[]{42});
                                                                                            
                                                                                            // Test with empty array
                                                                                            generator.setSeed(new int[]{});
                                                                                        }

    @Test(expected = NullPointerException.class)
                                                                                        public void testSetSeed_IntArray_NullInput() {
                                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                                
                                                                                                @Override
                                                                                                protected int next(int bits) {
                                                                                                    return 0;
                                                                                                }
                                                                                            };
                                                                                            generator.setSeed((int[])null);
                                                                                        }

    @Test
                                                                                        public void testConstructor_InitializesNextGaussian() throws Exception {
                                                                                            BitsStreamGenerator newGenerator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                                @Override
                                                                                                protected int next(int bits) { return 0; }
                                                                                            };
                                                                                            
                                                                                            // Use reflection to access private nextGaussian field
                                                                                            Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                            nextGaussianField.setAccessible(true);
                                                                                            double nextGaussianValue = (Double) nextGaussianField.get(newGenerator);
                                                                                            
                                                                                            assertTrue(Double.isNaN(nextGaussianValue));
                                                                                        }

    @Test
                                                                                        public void testClear_ResetsNextGaussian() throws Exception {
                                                                                            // Create an instance of the generator (using a concrete subclass since BitsStreamGenerator is abstract)
                                                                                            BitsStreamGenerator generator = new MersenneTwister();
                                                                                            
                                                                                            // Use reflection to access the private nextGaussian field
                                                                                            Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                            nextGaussianField.setAccessible(true);
                                                                                            
                                                                                            // First set nextGaussian to a non-NaN value
                                                                                            nextGaussianField.setDouble(generator, 1.0);
                                                                                            assertFalse(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                            
                                                                                            // Call clear
                                                                                            generator.clear();
                                                                                            
                                                                                            // Verify nextGaussian was reset to NaN
                                                                                            assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                        }

    @Test
                                                                                        public void testSetSeedIntArray() {
                                                                                            // Create a mock generator
                                                                                            BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                            // Setup exception handling
                                                                                            ExpectedException thrown = ExpectedException.none();
                                                                                            
                                                                                            int[] seedArray = {1, 2, 3, 4};
                                                                                            
                                                                                            // Test that setSeed(int[]) is called
                                                                                            generator.setSeed(seedArray);
                                                                                            verify(generator).setSeed(seedArray);
                                                                                            
                                                                                            // Test with empty array
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            generator.setSeed(new int[0]);
                                                                                        }

    @Test
                                                                                        public void testSetSeedLong() {
                                                                                            // Create a mock generator
                                                                                            BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                            
                                                                                            // Test that setSeed(long) is called
                                                                                            generator.setSeed(987654321L);
                                                                                            verify(generator).setSeed(987654321L);
                                                                                            
                                                                                            // Test that setting seed affects nextGaussian
                                                                                            when(generator.nextGaussian()).thenReturn(Double.NaN);
                                                                                            double result = generator.nextGaussian();
                                                                                            assertTrue(Double.isNaN(result));
                                                                                        }

    @Test
                                                                                        public void testNextGaussianAfterSetSeed() throws Exception {
                                                                                            // Create a new generator instance
                                                                                            BitsStreamGenerator generator = new Well19937c();
                                                                                            
                                                                                            // Use reflection to access and modify the private nextGaussian field
                                                                                            Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                            nextGaussianField.setAccessible(true);
                                                                                            
                                                                                            // Set some value to nextGaussian
                                                                                            nextGaussianField.setDouble(generator, 1.23);
                                                                                            
                                                                                            // Set seed which should reset nextGaussian
                                                                                            generator.setSeed(12345);
                                                                                            
                                                                                            // Verify nextGaussian was reset to NaN
                                                                                            assertTrue(Double.isNaN(nextGaussianField.getDouble(generator)));
                                                                                        }

    @Test
                                                                                        public void testClearResetsNextGaussian() throws Exception {
                                                                                            // Create a new generator instance
                                                                                            BitsStreamGenerator generator = new Well19937c();
                                                                                            
                                                                                            // Use reflection to access the private nextGaussian field
                                                                                            Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                            nextGaussianField.setAccessible(true);
                                                                                            
                                                                                            // Set some value to nextGaussian
                                                                                            nextGaussianField.setDouble(generator, 1.23);
                                                                                            
                                                                                            // Call clear()
                                                                                            generator.clear();
                                                                                            
                                                                                            // Verify nextGaussian was reset to NaN
                                                                                            assertTrue(Double.isNaN(nextGaussianField.getDouble(generator)));
                                                                                        }

    @Test
                                                                                        public void testConstructorInitializesNextGaussian1() throws Exception {
                                                                                            BitsStreamGenerator newGenerator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                                @Override
                                                                                                protected int next(int bits) { return 0; }
                                                                                            };
                                                                                            
                                                                                            // Use reflection to access private nextGaussian field
                                                                                            Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                            nextGaussianField.setAccessible(true);
                                                                                            double nextGaussianValue = (Double) nextGaussianField.get(newGenerator);
                                                                                            
                                                                                            assertTrue(Double.isNaN(nextGaussianValue));
                                                                                        }

    @Test
                                                                                        public void testNextGaussian_ReturnsNaNWhenFirstCall() {
                                                                                            // Create an anonymous subclass of BitsStreamGenerator since it's abstract
                                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                                @Override
                                                                                                protected int next(int bits) { return 0; }
                                                                                            };
                                                                                            
                                                                                            // The first call should return NaN since nextGaussian is initialized as NaN
                                                                                            assertEquals(Double.NaN, generator.nextGaussian(), 0.0);
                                                                                        }

    @Test
                                                                                        public void testNextIntWithBound_ThrowsForNonPositiveBound() {
                                                                                            // Initialize the rule for exception testing
                                                                                            org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                            
                                                                                            // Create an instance of the generator (using anonymous class since BitsStreamGenerator is abstract)
                                                                                            org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                                                                @Override
                                                                                                protected int next(int bits) {
                                                                                                    return 0;
                                                                                                }
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                            };
                                                                                            
                                                                                            // Set up exception expectations
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("bound must be positive");
                                                                                            
                                                                                            // Test the method
                                                                                            generator.nextInt(0);
                                                                                        }

    @Test
                                                                                        public void testClear_ResetsNextGaussian1() {
                                                                                            // Create a concrete instance of BitsStreamGenerator (using anonymous class since it's abstract)
                                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                                @Override
                                                                                                protected int next(int bits) { return 0; }
                                                                                                @Override
                                                                                                public void setSeed(int seed) {}
                                                                                                @Override
                                                                                                public void setSeed(int[] seed) {}
                                                                                                @Override
                                                                                                public void setSeed(long seed) {}
                                                                                            };
                                                                                            
                                                                                            // Use reflection to access the nextGaussian field since it's likely private
                                                                                            try {
                                                                                                Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                                nextGaussianField.setAccessible(true);
                                                                                                nextGaussianField.setDouble(generator, 1.0); // Set to non-NaN value
                                                                                                generator.clear();
                                                                                                assertEquals(Double.NaN, nextGaussianField.getDouble(generator), 0.0);
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to access nextGaussian field: " + e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                    public void testNextBytes_LengthDivisibleByFour() throws Exception {
                                                                                        // Setup
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            private int callCount = 0;
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                if (callCount++ == 0) {
                                                                                                    return 0x01020304;
                                                                                                } else {
                                                                                                    return 0xAABBCCDD;
                                                                                                }
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        byte[] bytes = new byte[8];
                                                                                        
                                                                                        // Execute
                                                                                        generator.nextBytes(bytes);
                                                                                        
                                                                                        // Verify
                                                                                        assertArrayEquals(new byte[] {
                                                                                            0x04, 0x03, 0x02, 0x01,  // First 32-bit chunk (little-endian)
                                                                                            (byte)0xDD, (byte)0xCC, (byte)0xBB, (byte)0xAA  // Second 32-bit chunk
                                                                                        }, bytes);
                                                                                    }

    @Test
                                                                                    public void testNextBytes_LengthNotDivisibleByFour() throws Exception {
                                                                                        // Setup
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            private int callCount = 0;
                                                                                            protected int next(int bits) {
                                                                                                if (callCount++ == 0) {
                                                                                                    return 0x11223344;
                                                                                                } else {
                                                                                                    return 0x55667788;
                                                                                                }
                                                                                            }
                                                                                            public void setSeed(int seed) {}
                                                                                            public void setSeed(int[] seed) {}
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        byte[] bytes = new byte[5];  // 1 byte remaining after first 4
                                                                                        
                                                                                        // Execute
                                                                                        generator.nextBytes(bytes);
                                                                                        
                                                                                        // Verify
                                                                                        assertArrayEquals(new byte[] {
                                                                                            0x44, 0x33, 0x22, 0x11,  // First 32-bit chunk
                                                                                            (byte)0x88  // Remaining byte from second chunk
                                                                                        }, bytes);
                                                                                    }

    @Test
                                                                                    public void testNextBytes_EmptyArray() {
                                                                                        // Setup
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0; // dummy implementation
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        byte[] bytes = new byte[0];
                                                                                        
                                                                                        // Execute
                                                                                        generator.nextBytes(bytes);
                                                                                        
                                                                                        // Verify
                                                                                        assertEquals(0, bytes.length);
                                                                                    }

    @Test
                                                                                    public void testNextBytes_NullArray() {
                                                                                        // Setup
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            protected int next(int bits) { return 0; }
                                                                                            public void setSeed(int seed) {}
                                                                                            public void setSeed(int[] seed) {}
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        thrown.expect(NullPointerException.class);
                                                                                        
                                                                                        // Execute
                                                                                        generator.nextBytes(null);
                                                                                    }

    @Test
                                                                                    public void testNextBytes_VerifyAllBytesFilled() throws Exception {
                                                                                        // Setup
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0xFFFFFFFF; // Always return all 1s
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        byte[] bytes = new byte[7];  // Test with odd size
                                                                                        
                                                                                        // Execute
                                                                                        generator.nextBytes(bytes);
                                                                                        
                                                                                        // Verify all bytes are filled with 0xFF
                                                                                        for (byte b : bytes) {
                                                                                            assertEquals((byte)0xFF, b);
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testNextBytes_DifferentResultsOnDifferentCalls() {
                                                                                        // Setup
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            private int callCount = 0;
                                                                                            private final int[] values = {0x12345678, 0x87654321, 0xABCDEF01, 0x10FEDCBA};
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return values[callCount++ % values.length];
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        byte[] bytes1 = new byte[4];
                                                                                        byte[] bytes2 = new byte[4];
                                                                                        
                                                                                        // Execute
                                                                                        generator.nextBytes(bytes1);
                                                                                        generator.nextBytes(bytes2);
                                                                                        
                                                                                        // Verify
                                                                                        assertFalse("Different calls should produce different results",
                                                                                                   java.util.Arrays.equals(bytes1, bytes2));
                                                                                    }

    @Test
                                                                                    public void testNextDouble_MinimumValue() {
                                                                                        // Create a concrete instance of BitsStreamGenerator
                                                                                        BitsStreamGenerator generator = new MersenneTwister();
                                                                                        
                                                                                        // Set both high and low bits to 0
                                                                                        generator.setSeed(0L);
                                                                                        
                                                                                        double result = generator.nextDouble();
                                                                                        
                                                                                        assertEquals(0.0, result, 0.0);
                                                                                    }

    @Test
                                                                                    public void testNextDouble_RangeCheck() {
                                                                                        // Create an instance of a concrete BitsStreamGenerator implementation
                                                                                        // Since BitsStreamGenerator is abstract, we'll use its subclass RandomGeneratorAdapter
                                                                                        // or create an anonymous class for testing purposes
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 0; // Simple implementation for testing
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Test multiple random values to ensure they're in range
                                                                                        for (int i = 0; i < 1000; i++) {
                                                                                            double result = generator.nextDouble();
                                                                                            assertTrue("Value should be >= 0.0: " + result, result >= 0.0);
                                                                                            assertTrue("Value should be < 1.0: " + result, result < 1.0);
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testNextDouble_StatisticalProperties() {
                                                                                        // Simple statistical test - mean should be around 0.5
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return (int)(Math.random() * (1 << bits));
                                                                                            }
                                                                                            // Implement other abstract methods as needed
                                                                                            public void setSeed(int seed) {}
                                                                                            public void setSeed(int[] seed) {}
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        double sum = 0;
                                                                                        int count = 10000;
                                                                                        
                                                                                        for (int i = 0; i < count; i++) {
                                                                                            sum += generator.nextDouble();
                                                                                        }
                                                                                        
                                                                                        double mean = sum / count;
                                                                                        assertTrue("Mean should be close to 0.5", Math.abs(mean - 0.5) < 0.05);
                                                                                    }

    @Test
                                                                                    public void testNextFloat_MiddleRangeValue() {
                                                                                        // Arrange
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            private int nextValue;
                                                                                            
                                                                                            public void setNextValue(int value) {
                                                                                                this.nextValue = value;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return nextValue;
                                                                                            }
                                                                                            
                                                                                            // Implement other abstract methods with empty implementations
                                                                                            @Override public void setSeed(int seed) {}
                                                                                            @Override public void setSeed(int[] seed) {}
                                                                                            @Override public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        // Use reflection to access setNextValue since it's not in the base class
                                                                                        try {
                                                                                            Method setNextValue = generator.getClass().getMethod("setNextValue", int.class);
                                                                                            setNextValue.invoke(generator, 0x400000); // Middle value
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set next value: " + e.getMessage());
                                                                                        }
                                                                                        
                                                                                        // Act
                                                                                        float result = generator.nextFloat();
                                                                                        
                                                                                        // Assert
                                                                                        assertEquals(0.5f, result, 0.0000001f);
                                                                                    }

    @Test
                                                                                    public void testNextFloat_WithNegativeNextValue() {
                                                                                        // Arrange
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            private int nextValue;
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return nextValue;
                                                                                            }
                                                                                            
                                                                                            public void setNextValue(int value) {
                                                                                                this.nextValue = value;
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Use reflection to access and set the next value
                                                                                        try {
                                                                                            Method setNextMethod = generator.getClass().getMethod("setNextValue", int.class);
                                                                                            setNextMethod.invoke(generator, -1);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set next value via reflection");
                                                                                        }
                                                                                        
                                                                                        // Act
                                                                                        float result = generator.nextFloat();
                                                                                        
                                                                                        // Assert
                                                                                        // Due to integer overflow when multiplying, this might produce unexpected results
                                                                                        // but we should still test the behavior
                                                                                        assertNotNull(Float.valueOf(result));
                                                                                    }

    @Test
                                                                                    public void testNextGaussian_FirstCallGeneratesNewPair() {
                                                                                        // Create mock generator
                                                                                        BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                        
                                                                                        // Mock nextDouble calls to return fixed values for deterministic testing
                                                                                        when(generator.nextDouble()).thenReturn(0.5, 0.5);
                                                                                        
                                                                                        // Mock nextGaussian behavior
                                                                                        when(generator.nextGaussian()).thenCallRealMethod();
                                                                                        
                                                                                        // Use reflection to access and modify the private nextGaussian field
                                                                                        try {
                                                                                            Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                            nextGaussianField.setAccessible(true);
                                                                                            nextGaussianField.set(generator, Double.NaN); // Reset to initial state
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set nextGaussian field via reflection");
                                                                                        }
                                                                                        
                                                                                        double result = generator.nextGaussian();
                                                                                        
                                                                                        // Verify the first call generates new pair
                                                                                        verify(generator, times(2)).nextDouble();
                                                                                        // With these inputs, r would be sqrt(-2*ln(0.5)) ≈ 1.17741
                                                                                        // alpha would be 2*PI*0.5 = PI
                                                                                        // cos(PI) = -1, so random should be -1.17741
                                                                                        assertEquals(-1.17741, result, 0.00001);
                                                                                        
                                                                                        // Verify the stored nextGaussian value
                                                                                        try {
                                                                                            Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                            nextGaussianField.setAccessible(true);
                                                                                            double storedValue = (Double) nextGaussianField.get(generator);
                                                                                            assertEquals(0.0, storedValue, 0.00001);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to get nextGaussian field via reflection");
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testNextGaussian_SecondCallUsesStoredValue() throws Exception {
                                                                                        // Create a mock of BitsStreamGenerator
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                            @Override
                                                                                            protected int next(int bits) { return 0; }
                                                                                            @Override
                                                                                            public double nextDouble() { return 0; }
                                                                                        };
                                                                                        
                                                                                        // Use reflection to set the private nextGaussian field
                                                                                        Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                        nextGaussianField.setAccessible(true);
                                                                                        nextGaussianField.set(generator, 1.5);
                                                                                        
                                                                                        double result = generator.nextGaussian();
                                                                                        
                                                                                        // Should return the stored value without calling nextDouble
                                                                                        // Note: Since we're not using Mockito, we can't verify method calls
                                                                                        assertEquals(1.5, result, 0.00001);
                                                                                        // Should reset nextGaussian to NaN
                                                                                        assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                    }

    @Test
                                                                                    public void testNextGaussian_SequenceOfCalls() {
                                                                                        // Create mock generator
                                                                                        BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                        
                                                                                        // Mock first pair generation
                                                                                        when(generator.nextDouble()).thenReturn(0.25, 0.75);
                                                                                        
                                                                                        // First call - generates new pair
                                                                                        double first = generator.nextGaussian();
                                                                                        // With x=0.25, y=0.75:
                                                                                        // alpha = 2*PI*0.25 = PI/2
                                                                                        // r = sqrt(-2*ln(0.75)) ≈ 0.758044
                                                                                        // first = r*cos(alpha) ≈ 0 (cos(PI/2) = 0)
                                                                                        // stored = r*sin(alpha) ≈ 0.758044
                                                                                        
                                                                                        assertEquals(0.0, first, 0.00001);
                                                                                        assertEquals(0.758044, generator.nextGaussian(), 0.00001);
                                                                                        
                                                                                        // Second call - uses stored value
                                                                                        double second = generator.nextGaussian();
                                                                                        assertEquals(0.758044, second, 0.00001);
                                                                                        assertTrue(Double.isNaN(generator.nextGaussian()));
                                                                                        
                                                                                        // Third call - generates new pair again
                                                                                        when(generator.nextDouble()).thenReturn(0.1, 0.9);
                                                                                        double third = generator.nextGaussian();
                                                                                        // x=0.1, y=0.9:
                                                                                        // alpha = 2*PI*0.1 = 0.628319
                                                                                        // r = sqrt(-2*ln(0.9)) ≈ 0.459588
                                                                                        // third = r*cos(alpha) ≈ 0.459588*0.809017 ≈ 0.37181
                                                                                        // stored = r*sin(alpha) ≈ 0.459588*0.587785 ≈ 0.27018
                                                                                        
                                                                                        assertEquals(0.37181, third, 0.00001);
                                                                                        assertEquals(0.27018, generator.nextGaussian(), 0.00001);
                                                                                    }

    @Test
                                                                                    public void testNextGaussian_EdgeCaseZeroY() {
                                                                                        // Create mock generator
                                                                                        BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                        
                                                                                        // When y is 0, log(y) would be -infinity
                                                                                        // But nextDouble() shouldn't return exactly 0
                                                                                        when(generator.nextDouble()).thenReturn(0.5, 0.0);
                                                                                        
                                                                                        // Set up expected exception
                                                                                        ExpectedException exception = ExpectedException.none();
                                                                                        exception.expect(IllegalArgumentException.class);
                                                                                        
                                                                                        // Test the method
                                                                                        generator.nextGaussian();
                                                                                    }

    @Test
                                                                                    public void testNextGaussian_EdgeCaseOneY() {
                                                                                        // Create a mock of BitsStreamGenerator
                                                                                        BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                        
                                                                                        // When y is 1, log(y) would be 0
                                                                                        when(generator.nextDouble()).thenReturn(0.5, 1.0);
                                                                                        
                                                                                        double result = generator.nextGaussian();
                                                                                        // r would be sqrt(-2*0) = 0
                                                                                        assertEquals(0.0, result, 0.00001);
                                                                                    }

    @Test
                                                                                    public void testNextInt_ReturnsMaximumIntegerValue() {
                                                                                        // Arrange
                                                                                        int maxValue = Integer.MAX_VALUE;
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            private int nextValue;
                                                                                            
                                                                                            public void setNextValue(int value) {
                                                                                                this.nextValue = value;
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                            
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return nextValue;
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Use reflection to access and set the next value
                                                                                        try {
                                                                                            Method setNextValueMethod = generator.getClass().getMethod("setNextValue", int.class);
                                                                                            setNextValueMethod.invoke(generator, maxValue);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set next value via reflection");
                                                                                        }
                                                                                        
                                                                                        // Act
                                                                                        int result = generator.nextInt();
                                                                                        
                                                                                        // Assert
                                                                                        assertEquals(maxValue, result);
                                                                                    }

    @Test
                                                                                    public void testNextInt_PowerOfTwoCase() {
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 123456789;
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        // Test with n=16 (power of 2)
                                                                                        int result = generator.nextInt(16);
                                                                                        // Verify the calculation: (16 * 123456789L) >> 31
                                                                                        long expected = (16 * 123456789L) >> 31;
                                                                                        assertEquals((int)expected, result);
                                                                                        
                                                                                        // Verify the range
                                                                                        assertTrue(result >= 0 && result < 16);
                                                                                    }

    @Test
                                                                                    public void testNextInt_WithOne() {
                                                                                        // Create a concrete subclass to test the protected method
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return 12345; // Our test value
                                                                                            }
                                                                                            
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        int result = generator.nextInt(1);
                                                                                        assertEquals(0, result); // Only possible result when n=1
                                                                                    }

    @Test
                                                                                    public void testNextInt_WithMaxValue() throws Exception {
                                                                                        BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                            @Override
                                                                                            protected int next(int bits) {
                                                                                                return Integer.MAX_VALUE - 1;
                                                                                            }
                                                                                    
                                                                                            @Override
                                                                                            public void setSeed(int seed) {}
                                                                                            @Override
                                                                                            public void setSeed(int[] seed) {}
                                                                                            @Override
                                                                                            public void setSeed(long seed) {}
                                                                                        };
                                                                                        
                                                                                        int result = generator.nextInt(Integer.MAX_VALUE);
                                                                                        assertTrue(result >= 0 && result < Integer.MAX_VALUE);
                                                                                    }

    @Test
                                                                                public void testNextLong_RandomValues() {
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        private int nextValue;
                                                                                        private int callCount = 0;
                                                                                        private final int[] values = {0x5A5A5A5A, 0xA5A5A5A5};
                                                                                
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return values[callCount++];
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    assertEquals(0x5A5A5A5AA5A5A5A5L, generator.nextLong());
                                                                                }

    @Test
                                                                                public void testNextLong_VerifyBitOperations() {
                                                                                    // Test that the bit operations work as expected
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        private int nextValue;
                                                                                        private int callCount = 0;
                                                                                        private final int[] values = new int[]{0x11111111, 0x22222222};
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return values[callCount++];
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    long expected = (0x11111111L << 32) | (0x22222222L & 0xffffffffL);
                                                                                    assertEquals(expected, generator.nextLong());
                                                                                }

    @Test
                                                                                public void testClear_InitialState() {
                                                                                    // Create instance and verify initial state set by constructor
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                        @Override
                                                                                        protected int next(int bits) { return 0; }
                                                                                    };
                                                                                    assertTrue(Double.isNaN(generator.nextGaussian()));
                                                                                }

    @Test
                                                                                public void testClear_SetsNextGaussianToNaN() {
                                                                                    // Create a concrete instance of BitsStreamGenerator (or use a mock)
                                                                                    // Since BitsStreamGenerator is abstract, we'll need to use a concrete subclass
                                                                                    // For testing purposes, we'll use MersenneTwister as it's a common implementation
                                                                                    org.apache.commons.math3.random.MersenneTwister generator = new org.apache.commons.math3.random.MersenneTwister();
                                                                                    
                                                                                    try {
                                                                                        // Use reflection to access the private nextGaussian field
                                                                                        java.lang.reflect.Field nextGaussianField = org.apache.commons.math3.random.BitsStreamGenerator.class
                                                                                            .getDeclaredField("nextGaussian");
                                                                                        nextGaussianField.setAccessible(true);
                                                                                        
                                                                                        // Change the state first
                                                                                        nextGaussianField.set(generator, 1.23);
                                                                                        
                                                                                        // Call clear and verify
                                                                                        generator.clear();
                                                                                        assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                    } catch (Exception e) {
                                                                                        fail("Exception during test: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testClear_MultipleCalls() throws Exception {
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                        @Override
                                                                                        protected int next(int bits) { return 0; }
                                                                                    };
                                                                                    
                                                                                    Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                    nextGaussianField.setAccessible(true);
                                                                                    
                                                                                    // First call
                                                                                    generator.clear();
                                                                                    assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                    
                                                                                    // Change value
                                                                                    nextGaussianField.set(generator, 4.56);
                                                                                    
                                                                                    // Second call
                                                                                    generator.clear();
                                                                                    assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                                                }

    @Test
                                                                                public void testClear_AfterNextGaussianCall() {
                                                                                    // Create a concrete subclass instance since BitsStreamGenerator is abstract
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                        @Override
                                                                                        protected int next(int bits) { return 0; }
                                                                                    };
                                                                                    
                                                                                    // This tests interaction with other methods
                                                                                    // We'll mock the nextGaussian() behavior since it's abstract
                                                                                    BitsStreamGenerator spyGenerator = spy(generator);
                                                                                    when(spyGenerator.nextGaussian()).thenReturn(3.14);
                                                                                    
                                                                                    // Call nextGaussian which might modify the field
                                                                                    spyGenerator.nextGaussian();
                                                                                    
                                                                                    // Now call clear
                                                                                    spyGenerator.clear();
                                                                                    
                                                                                    // Use reflection to check the private nextGaussian field
                                                                                    try {
                                                                                        Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                                        nextGaussianField.setAccessible(true);
                                                                                        double nextGaussianValue = nextGaussianField.getDouble(spyGenerator);
                                                                                        assertTrue(Double.isNaN(nextGaussianValue));
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to access nextGaussian field: " + e.getMessage());
                                                                                    }
                                                                                    
                                                                                    // Verify interaction
                                                                                    verify(spyGenerator).nextGaussian();
                                                                                }

    @Test
                                                                                public void testSetSeedInteractionWithNext() {
                                                                                    // Create an anonymous implementation of BitsStreamGenerator for testing
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        private int seed;
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int seed) {
                                                                                            this.seed = seed;
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {
                                                                                            // Not used in this test
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {
                                                                                            // Not used in this test
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return this.seed; // Simple implementation that returns the seed
                                                                                        }
                                                                                    };
                                                                                    
                                                                                    int testSeed = 42;
                                                                                    generator.setSeed(testSeed);
                                                                                    
                                                                                    try {
                                                                                        // Use reflection to access the protected next() method
                                                                                        Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                                                        nextMethod.setAccessible(true);
                                                                                        int result = (Integer) nextMethod.invoke(generator, 32);
                                                                                        assertEquals(testSeed, result);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to invoke protected next() method: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testSetSeedMultipleTimes() {
                                                                                    // Create a concrete instance of the generator
                                                                                    BitsStreamGenerator generator = new MersenneTwister();
                                                                                    
                                                                                    // First seed - verify by checking consistent output
                                                                                    generator.setSeed(1);
                                                                                    int firstInt = generator.nextInt();
                                                                                    generator.setSeed(1);
                                                                                    assertEquals(firstInt, generator.nextInt());
                                                                                    
                                                                                    // Second seed - verify different output
                                                                                    generator.setSeed(2);
                                                                                    assertNotEquals(firstInt, generator.nextInt());
                                                                                    
                                                                                    // Different type - long seed
                                                                                    generator.setSeed(3L);
                                                                                    long firstLong = generator.nextLong();
                                                                                    generator.setSeed(3L);
                                                                                    assertEquals(firstLong, generator.nextLong());
                                                                                }

    @Test
                                                                                public void testSetSeed_Long_ValidValue() {
                                                                                    // Create a concrete instance of the abstract class for testing
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) { return 0; }
                                                                                    };
                                                                                    
                                                                                    // Test with typical positive value
                                                                                    generator.setSeed(123456789L);
                                                                                    
                                                                                    // Test with zero
                                                                                    generator.setSeed(0L);
                                                                                    
                                                                                    // Test with negative value
                                                                                    generator.setSeed(-123456789L);
                                                                                    
                                                                                    // Test with max long value
                                                                                    generator.setSeed(Long.MAX_VALUE);
                                                                                    
                                                                                    // Test with min long value
                                                                                    generator.setSeed(Long.MIN_VALUE);
                                                                                }

    @Test
                                                                                public void testSetSeedInt() {
                                                                                    // Create a mock of the abstract BitsStreamGenerator class
                                                                                    BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                                                    
                                                                                    // Test that setSeed(int) is called
                                                                                    generator.setSeed(12345);
                                                                                    verify(generator).setSeed(12345);
                                                                                    
                                                                                    // Test that setting seed affects subsequent random values
                                                                                    // We can only verify the public nextBoolean() call
                                                                                    generator.nextBoolean();
                                                                                    verify(generator).nextBoolean();
                                                                                }

    @Test
                                                                                public void testNextBoolean_ReturnsTrueWhenNextBitIsSet() throws Exception {
                                                                                    // Create a concrete subclass to access protected method
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return 1; // Always return 1 to simulate next bit being set
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    assertTrue(generator.nextBoolean());
                                                                                    
                                                                                    // Verify the protected method was called through reflection
                                                                                    Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                                                    nextMethod.setAccessible(true);
                                                                                    int result = (int) nextMethod.invoke(generator, 1);
                                                                                    assertEquals(1, result);
                                                                                }

    @Test
                                                                                public void testNextBoolean_ReturnsFalseWhenNextBitIsNotSet() throws Exception {
                                                                                    // Create a concrete subclass to access the protected method
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        private int nextValue;
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return nextValue;
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                
                                                                                    // Use reflection to set the next value to return 0
                                                                                    Field nextField = generator.getClass().getDeclaredField("nextValue");
                                                                                    nextField.setAccessible(true);
                                                                                    nextField.setInt(generator, 0);
                                                                                
                                                                                    assertFalse(generator.nextBoolean());
                                                                                }

    @Test
                                                                                public void testNextFloat_ReturnsValueBetweenZeroAndOne() {
                                                                                    // Create a concrete subclass to test the protected method
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return 0xFFFFFF; // Max value should give just under 1.0f
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    float result = generator.nextFloat();
                                                                                    assertTrue(result >= 0.0f && result < 1.0f);
                                                                                }

    @Test
                                                                                public void testNextDouble_ReturnsValueBetweenZeroAndOne() throws Exception {
                                                                                    // Create a concrete subclass to test the protected method
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        private int callCount = 0;
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            // Return fixed values for the first two calls (0x3FFFFFF is 2^26-1)
                                                                                            if (callCount++ < 2) {
                                                                                                return 0x3FFFFFF;
                                                                                            }
                                                                                            return 0;
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                
                                                                                    // Call the method under test
                                                                                    double result = generator.nextDouble();
                                                                                    
                                                                                    // Verify the result is in expected range
                                                                                    assertTrue(result >= 0.0 && result < 1.0);
                                                                                    
                                                                                    // Verify the implementation detail that next(26) is called twice
                                                                                    // This is done through the anonymous class implementation above
                                                                                }

    @Test
                                                                                public void testNextBytes_FillsEntireArray() {
                                                                                    // Create a concrete subclass to test the protected method
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        private int count = 0;
                                                                                        private final int[] values = {0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A};
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return values[count++];
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    byte[] bytes = new byte[10];
                                                                                    generator.nextBytes(bytes);
                                                                                    byte[] expected = {0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A};
                                                                                    assertArrayEquals(expected, bytes);
                                                                                }

    @Test
                                                                                public void testNextIntWithBound_ReturnsValueWithinRange() throws Exception {
                                                                                    // Create a subclass of BitsStreamGenerator to access protected method
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return 100; // Return fixed value for testing
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                
                                                                                    // Call the method under test
                                                                                    int result = generator.nextInt(200);
                                                                                    
                                                                                    // Verify the result is within bounds
                                                                                    assertTrue(result >= 0 && result < 200);
                                                                                    
                                                                                    // Verify the internal behavior by checking the result value
                                                                                    // Since we can't verify the protected method call directly,
                                                                                    // we verify the expected behavior through the result
                                                                                    assertEquals(100 % 200, result);
                                                                                }

    @Test
                                                                                public void testNextBoolean_WhenNextReturnsNonZero_ShouldReturnTrue() {
                                                                                    // Arrange
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return 1; // non-zero value
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    // Act
                                                                                    boolean result = generator.nextBoolean();
                                                                                    
                                                                                    // Assert
                                                                                    assertTrue(result);
                                                                                }

    @Test
                                                                                public void testNextBoolean_WhenNextReturnsZero_ShouldReturnFalse() {
                                                                                    // Arrange
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return 0;
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    // Act
                                                                                    boolean result = generator.nextBoolean();
                                                                                    
                                                                                    // Assert
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testNextBoolean_WhenNextReturnsNegative_ShouldReturnTrue() {
                                                                                    // Arrange
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return -1; // non-zero value
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    // Act
                                                                                    boolean result = generator.nextBoolean();
                                                                                    
                                                                                    // Assert
                                                                                    assertTrue(result);
                                                                                }

    @Test
                                                                                public void testNextBoolean_VerifyExactlyOneCallToNext() throws Exception {
                                                                                    // Arrange
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        private int callCount = 0;
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            callCount++;
                                                                                            return 1;
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    // Use reflection to get the next method
                                                                                    Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                                                    nextMethod.setAccessible(true);
                                                                                    
                                                                                    // Act
                                                                                    generator.nextBoolean();
                                                                                    
                                                                                    // Assert
                                                                                    // Verify next(1) was called exactly once by checking our counter
                                                                                    // We can't use Mockito verify for protected methods
                                                                                    Field callCountField = generator.getClass().getDeclaredField("callCount");
                                                                                    callCountField.setAccessible(true);
                                                                                    assertEquals(1, callCountField.getInt(generator));
                                                                                }

    @Test
                                                                                public void testNextFloat_MaximumValue() {
                                                                                    // Arrange
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return 0x7FFFFF; // 23 bits set
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    // Act
                                                                                    float result = generator.nextFloat();
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(0.99999994f, result, 0.00000001f);
                                                                                }

    @Test
                                                                                public void testNextFloat_RandomValue() {
                                                                                    // Arrange
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        private int nextValue = 1234567;
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            int value = nextValue;
                                                                                            nextValue = 0; // Reset after use
                                                                                            return value;
                                                                                        }
                                                                                
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    // Act
                                                                                    float result = generator.nextFloat();
                                                                                    float expected = 1234567 * 0x1.0p-23f;
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(expected, result, 0.0f);
                                                                                }

    @Test
                                                                                public void testNextInt_ReturnsValueFromNext() {
                                                                                    // Arrange
                                                                                    int expectedValue = 123456789;
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        private int nextValue;
                                                                                        
                                                                                        public void setNextValue(int value) {
                                                                                            this.nextValue = value;
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return nextValue;
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    // Use reflection to access setNextValue since it's not in the original class
                                                                                    try {
                                                                                        Method setNextValue = generator.getClass().getMethod("setNextValue", int.class);
                                                                                        setNextValue.invoke(generator, expectedValue);
                                                                                    } catch (Exception e) {
                                                                                        throw new RuntimeException(e);
                                                                                    }
                                                                                    
                                                                                    // Act
                                                                                    int result = generator.nextInt();
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(expectedValue, result);
                                                                                }

    @Test
                                                                                public void testNextInt_ReturnsMinimumIntegerValue() {
                                                                                    // Arrange
                                                                                    int minValue = Integer.MIN_VALUE;
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return minValue;
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    };
                                                                                    
                                                                                    // Act
                                                                                    int result = generator.nextInt();
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(minValue, result);
                                                                                }

    @Test
                                                                                public void testNextInt_ReturnsZero() {
                                                                                    // Arrange
                                                                                    int zeroValue = 0;
                                                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                        private int nextValue;
                                                                                        
                                                                                        public void setNextValue(int value) {
                                                                                            this.nextValue = value;
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            return nextValue;
                                                                                        }
                                                                                    };
                                                                                    
                                                                                    // Use reflection to access the setNextValue method since it's not part of BitsStreamGenerator
                                                                                    try {
                                                                                        Method setNextValue = generator.getClass().getMethod("setNextValue", int.class);
                                                                                        setNextValue.invoke(generator, zeroValue);
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed to set next value: " + e.getMessage());
                                                                                    }
                                                                                    
                                                                                    // Act
                                                                                    int result = generator.nextInt();
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(zeroValue, result);
                                                                                }

    @Test
                                                                                public void testNextLong_MixedValues() {
                                                                                    // Create a custom implementation with accessible method
                                                                                    class TestGenerator extends BitsStreamGenerator {
                                                                                        private final List<Integer> nextValues = new ArrayList<>();
                                                                                        
                                                                                        public void addNextValue(int value) {
                                                                                            nextValues.add(value);
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        protected int next(int bits) {
                                                                                            if (!nextValues.isEmpty()) {
                                                                                                return nextValues.remove(0);
                                                                                            }
                                                                                            return 0;
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        public void setSeed(int seed) {}
                                                                                        @Override
                                                                                        public void setSeed(int[] seed) {}
                                                                                        @Override
                                                                                        public void setSeed(long seed) {}
                                                                                    }
                                                                                    
                                                                                    TestGenerator generator = new TestGenerator();
                                                                                    
                                                                                    generator.addNextValue(0x00000000); // min high
                                                                                    generator.addNextValue(0xFFFFFFFF); // max low
                                                                                    assertEquals(0x00000000FFFFFFFFL, generator.nextLong());
                                                                                    
                                                                                    generator.addNextValue(0xFFFFFFFF); // max high
                                                                                    generator.addNextValue(0x00000000); // min low
                                                                                    assertEquals(0xFFFFFFFF00000000L, generator.nextLong());
                                                                                }

    @Test
                                                                            public void testNextInt_ReturnsValueFromNext32Bits() {
                                                                                // Create a concrete implementation where we can control the next() method
                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                    @Override
                                                                                    protected int next(int bits) {
                                                                                        return bits == 32 ? 0xDEADBEEF : 0;
                                                                                    }
                                                                                
                                                                                    @Override
                                                                                    public void setSeed(int seed) {}
                                                                                    @Override
                                                                                    public void setSeed(int[] seed) {}
                                                                                    @Override
                                                                                    public void setSeed(long seed) {}
                                                                                };
                                                                                
                                                                                int expectedValue = 0xDEADBEEF;
                                                                                assertEquals(expectedValue, generator.nextInt());
                                                                            }

    @Test
                                                                            public void testNextLong_CombinesTwo32BitValues() {
                                                                                // Create a concrete subclass to test the protected method
                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                    private int callCount = 0;
                                                                                    
                                                                                    @Override
                                                                                    protected int next(int bits) {
                                                                                        return callCount++ == 0 ? 0xDEADBEEF : 0xCAFEBABE;
                                                                                    }
                                                                            
                                                                                    @Override
                                                                                    public void setSeed(int seed) {}
                                                                                    
                                                                                    @Override
                                                                                    public void setSeed(int[] seed) {}
                                                                                    
                                                                                    @Override
                                                                                    public void setSeed(long seed) {}
                                                                                };
                                                                                
                                                                                long expected = ((long) 0xDEADBEEF << 32) + 0xCAFEBABE;
                                                                                assertEquals(expected, generator.nextLong());
                                                                            }

    @Test
                                                                            public void testNextFloat_MinimumValue() {
                                                                                // Arrange
                                                                                BitsStreamGenerator generator = new MersenneTwister();
                                                                                
                                                                                // Act
                                                                                float result = generator.nextFloat();
                                                                                
                                                                                // Assert
                                                                                assertEquals(0.0f, result, 0.0f);
                                                                            }

    @Test
                                                                            public void testNextFloat_AlwaysReturnsWithinRange() {
                                                                                // Create real generator (using anonymous class since BitsStreamGenerator is abstract)
                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                    private int nextValue;
                                                                                    
                                                                                    public void setNextValue(int value) {
                                                                                        this.nextValue = value;
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    protected int next(int bits) {
                                                                                        return nextValue;
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public void setSeed(int seed) {}
                                                                                    
                                                                                    @Override
                                                                                    public void setSeed(int[] seed) {}
                                                                                    
                                                                                    @Override
                                                                                    public void setSeed(long seed) {}
                                                                                };
                                                                                
                                                                                // Test multiple values to ensure they're always in [0,1) range
                                                                                for (int i = 0; i < 1000; i++) {
                                                                                    // Arrange
                                                                                    // Need to cast to the anonymous class type to access setNextValue
                                                                                    // Act
                                                                                    float result = generator.nextFloat();
                                                                                    
                                                                                    // Assert
                                                                                    assertTrue("Value should be >= 0", result >= 0.0f);
                                                                                    assertTrue("Value should be < 1", result < 1.0f);
                                                                                }
                                                                            }

    @Test
                                                                            public void testNextInt_NonPowerOfTwoCase() throws Exception {
                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                    // Implement abstract methods
                                                                                    @Override
                                                                                    public void setSeed(int seed) {}
                                                                                    @Override
                                                                                    public void setSeed(int[] seed) {}
                                                                                    @Override
                                                                                    public void setSeed(long seed) {}
                                                                                    @Override
                                                                                    protected int next(int bits) {
                                                                                        // This will return our sequence of values
                                                                                        if (bits == 31) {
                                                                                            return sequence[index++ % sequence.length];
                                                                                        }
                                                                                        return 0;
                                                                                    }
                                                                                    
                                                                                    private int[] sequence = {100, 200, 300};
                                                                                    private int index = 0;
                                                                                };
                                                                                
                                                                                int n = 7; // Not a power of 2
                                                                                int result = generator.nextInt(n);
                                                                                
                                                                                // Verify the range
                                                                                assertTrue(result >= 0 && result < n);
                                                                            }

    @Test
                                                                            public void testNextLong_CombinesHighAndLowBitsCorrectly() {
                                                                                // Create a concrete subclass of BitsStreamGenerator for testing
                                                                                BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                    private int nextHigh = 0x12345678;
                                                                                    private int nextLow = 0x9ABCDEF0;
                                                                                    private boolean highReturned = false;
                                                                                    
                                                                                    @Override
                                                                                    public void setSeed(int seed) {}
                                                                                    
                                                                                    @Override
                                                                                    public void setSeed(int[] seed) {}
                                                                                    
                                                                                    @Override
                                                                                    public void setSeed(long seed) {}
                                                                                    
                                                                                    @Override
                                                                                    protected int next(int bits) {
                                                                                        if (!highReturned) {
                                                                                            highReturned = true;
                                                                                            return nextHigh;
                                                                                        } else {
                                                                                            return nextLow;
                                                                                        }
                                                                                    }
                                                                                    
                                                                                    @Override
                                                                                    public long nextLong() {
                                                                                        return (((long) next(32)) << 32) + next(32);
                                                                                    }
                                                                                };
                                                                                
                                                                                // Call nextLong which should combine high and low bits
                                                                                long result = generator.nextLong();
                                                                                
                                                                                // Verify the combination is correct
                                                                                assertEquals(0x123456789ABCDEF0L, result);
                                                                            }

    @Test
                                                                        public void testNextInt_Verifies32BitsRequested() throws Exception {
                                                                            // Arrange
                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                private int bitsReceived = 0;
                                                                                
                                                                                @Override
                                                                                protected int next(int bits) {
                                                                                    bitsReceived = bits;
                                                                                    return 0;
                                                                                }
                                                                                
                                                                                @Override
                                                                                public void setSeed(int seed) {}
                                                                                
                                                                                @Override
                                                                                public void setSeed(int[] seed) {}
                                                                                
                                                                                @Override
                                                                                public void setSeed(long seed) {}
                                                                                
                                                                                public int getBitsReceived() {
                                                                                    return bitsReceived;
                                                                                }
                                                                            };
                                                                            
                                                                            // Act
                                                                            generator.nextInt();
                                                                            
                                                                            // Assert - Using reflection to access the bits value
                                                                            Class<?> clazz = generator.getClass();
                                                                            Method getBitsMethod = clazz.getMethod("getBitsReceived");
                                                                            int bits = (int) getBitsMethod.invoke(generator);
                                                                            assertEquals(32, bits);
                                                                        }

    @Test
                                                                        public void testNextInt_RejectionCase() throws Exception {
                                                                            // Create a subclass that implements the protected method with our test behavior
                                                                            BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                                private int callCount = 0;
                                                                                
                                                                                @Override
                                                                                protected int next(int bits) {
                                                                                    callCount++;
                                                                                    // First call returns value that should be rejected
                                                                                    if (callCount == 1) {
                                                                                        return Integer.MAX_VALUE;
                                                                                    }
                                                                                    // Second call returns acceptable value
                                                                                    return 1000;
                                                                                }
                                                                        
                                                                                @Override
                                                                                public void setSeed(int seed) {}
                                                                        
                                                                                @Override
                                                                                public void setSeed(int[] seed) {}
                                                                        
                                                                                @Override
                                                                                public void setSeed(long seed) {}
                                                                            };
                                                                            
                                                                            int n = 10;
                                                                            int result = generator.nextInt(n);
                                                                            
                                                                            assertTrue(result >= 0 && result < n);
                                                                            // We can't verify the number of calls to next() directly, 
                                                                            // but we know it must have been called twice based on the behavior
                                                                        }

    @Test
                                                public void testSetSeedWithInt() {
                                                    // Create an anonymous subclass of BitsStreamGenerator
                                                    org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                        private int seed;
                                                        
                                                        @Override
                                                        public void setSeed(int seed) {
                                                            this.seed = seed;
                                                        }
                                                        
                                                        @Override
                                                        public void setSeed(int[] seed) {
                                                            throw new UnsupportedOperationException("Not used in this test");
                                                        }
                                                        
                                                        @Override
                                                        public void setSeed(long seed) {
                                                            throw new UnsupportedOperationException("Not used in this test");
                                                        }
                                                        
                                                        @Override
                                                        protected int next(int bits) {
                                                            return 0; // Not used in this test
                                                        }
                                                        
                                                        public int getSeed() {
                                                            return seed;
                                                        }
                                                    };
                                                    
                                                    int testSeed = 12345;
                                                    generator.setSeed(testSeed);
                                                }

    @Test
                                                public void testSetSeedWithIntArray() {
                                                    org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                        private int[] arraySeed;
                                                        private double nextGaussian = Double.NaN;
                                                        
                                                        @Override
                                                        public void setSeed(int seed) {}
                                                        
                                                        @Override
                                                        public void setSeed(int[] seed) {
                                                            this.arraySeed = seed.clone();
                                                        }
                                                        
                                                        @Override
                                                        public void setSeed(long seed) {}
                                                        
                                                        @Override
                                                        protected int next(int bits) { 
                                                            return 0; 
                                                        }
                                                        
                                                        public int[] getArraySeed() {
                                                            return arraySeed;
                                                        }
                                                    };
                                                    
                                                    int[] testSeed = {1, 2, 3, 4, 5};
                                                    generator.setSeed(testSeed);
                                                }

    @Test
                                                public void testSetSeedWithIntArrayEmpty() {
                                                    org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                        @Override
                                                        public void setSeed(int seed) {}
                                                        
                                                        @Override
                                                        public void setSeed(int[] seed) {}
                                                        
                                                        @Override
                                                        public void setSeed(long seed) {}
                                                        
                                                        @Override
                                                        protected int next(int bits) {
                                                            return 0;
                                                        }
                                                        
                                                        public int[] getArraySeed() {
                                                            return new int[0];
                                                        }
                                                        
                                                        @Override
                                                        public boolean nextBoolean() {
                                                            return false;
                                                        }
                                                        
                                                        @Override
                                                        public void nextBytes(byte[] bytes) {}
                                                        
                                                        @Override
                                                        public double nextDouble() {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public float nextFloat() {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public double nextGaussian() {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public int nextInt() {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public int nextInt(int n) {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public long nextLong() {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public void clear() {}
                                                    };
                                                    
                                                    int[] testSeed = new int[0];
                                                    generator.setSeed(testSeed);
                                                }

    @Test
                                                public void testSetSeedWithLong() {
                                                    // Create an anonymous subclass of BitsStreamGenerator for testing
                                                    org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                        private long seed;
                                                        
                                                        @Override
                                                        public void setSeed(int seed) {}
                                                        
                                                        @Override
                                                        public void setSeed(int[] seed) {}
                                                        
                                                        @Override
                                                        public void setSeed(long seed) {
                                                            this.seed = seed;
                                                        }
                                                        
                                                        @Override
                                                        protected int next(int bits) {
                                                            return 0;
                                                        }
                                                        
                                                        public long getLongSeed() {
                                                            return seed;
                                                        }
                                                    };
                                                    
                                                    long testSeed = 123456789L;
                                                    generator.setSeed(testSeed);
                                                }

    @Test
                                                public void testNextDouble_MaximumValue() {
                                                    // Create a concrete instance (using a stub implementation since BitsStreamGenerator is abstract)
                                                    org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                        private int nextValue;
                                                        private double nextGaussian = Double.NaN;
                                                        
                                                        @Override
                                                        public void setSeed(int seed) {}
                                                        
                                                        @Override
                                                        public void setSeed(int[] seed) {}
                                                        
                                                        @Override
                                                        public void setSeed(long seed) {}
                                                        
                                                        @Override
                                                        protected int next(int bits) {
                                                            return nextValue;
                                                        }
                                                        
                                                        public void setNextReturnValue(int value) {
                                                            this.nextValue = value;
                                                        }
                                                    
                                                        @Override
                                                        public boolean nextBoolean() {
                                                            return false;
                                                        }
                                                    
                                                        @Override
                                                        public void nextBytes(byte[] bytes) {
                                                        }
                                                    
                                                        @Override
                                                        public float nextFloat() {
                                                            return 0;
                                                        }
                                                    
                                                        @Override
                                                        public double nextGaussian() {
                                                            return 0;
                                                        }
                                                    
                                                        @Override
                                                        public int nextInt() {
                                                            return 0;
                                                        }
                                                    
                                                        @Override
                                                        public int nextInt(int n) {
                                                            return 0;
                                                        }
                                                    
                                                        @Override
                                                        public long nextLong() {
                                                            return 0;
                                                        }
                                                    
                                                        @Override
                                                        public double nextDouble() {
                                                            // Implementation from BitsStreamGenerator
                                                            long high = ((long) next(26)) << 26;
                                                            long low = next(26);
                                                            return (high | low) * 0x1.0p-52d;
                                                        }
                                                    
                                                        @Override
                                                        public void clear() {
                                                        }
                                                    };
                                                    
                                                    // Set both high and low bits to maximum 26-bit values (2^26 - 1)
                                                    
                                                    double result = generator.nextDouble();
                                                    
                                                    // Maximum value should be just under 1.0
                                                    org.junit.Assert.assertEquals(0.9999999999999998, result, 0.0);
                                                }

    @Test
                                                public void testNextDouble_TypicalValue() {
                                                    // Create a concrete subclass of BitsStreamGenerator for testing
                                                    org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                        private int nextValue;
                                                        
                                                        @Override
                                                        public void setSeed(int seed) {}
                                                        
                                                        @Override
                                                        public void setSeed(int[] seed) {}
                                                        
                                                        @Override
                                                        public void setSeed(long seed) {}
                                                        
                                                        @Override
                                                        protected int next(int bits) {
                                                            return nextValue;
                                                        }
                                                        
                                                        public void setNextReturnValue(int value) {
                                                            this.nextValue = value;
                                                        }
                                                    };
                                                    
                                                    // Set high bits to 1 and low bits to 0
                                                    double result1 = generator.nextDouble();
                                                    
                                                    // Set low bits to 1 and high bits to 0
                                                    generator.nextDouble(); // Consume first call
                                                    double result2 = generator.nextDouble();
                                                    
                                                    // Verify results are in expected range
                                                    org.junit.Assert.assertTrue(result1 >= 0.0 && result1 < 1.0);
                                                    org.junit.Assert.assertTrue(result2 >= 0.0 && result2 < 1.0);
                                                    org.junit.Assert.assertNotEquals(result1, result2);
                                                }

    @Test
                                                public void testNextLong_MaxValues() {
                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                        private int nextReturnValue;
                                                        
                                                        public void setNextReturnValue(int value) {
                                                            this.nextReturnValue = value;
                                                        }
                                                        
                                                        @Override
                                                        protected int next(int bits) {
                                                            return nextReturnValue;
                                                        }
                                                        
                                                        @Override
                                                        public void setSeed(int seed) {}
                                                        
                                                        @Override
                                                        public void setSeed(int[] seed) {}
                                                        
                                                        @Override
                                                        public void setSeed(long seed) {}
                                                    };
                                                    
                                                    // Need to cast to the anonymous class type to access setNextReturnValue
                                                    // Create a local variable of the anonymous class type
                                                    BitsStreamGenerator anonymousGenerator = generator;
                                                    try {
                                                        java.lang.reflect.Method setNextReturnValueMethod = anonymousGenerator.getClass().getMethod("setNextReturnValue", int.class);
                                                        setNextReturnValueMethod.invoke(anonymousGenerator, 0xFFFFFFFF); // max high
                                                        setNextReturnValueMethod.invoke(anonymousGenerator, 0xFFFFFFFF); // max low
                                                    } catch (Exception e) {
                                                        throw new RuntimeException(e);
                                                    }
                                                    
                                                    assertEquals(0xFFFFFFFFFFFFFFFFL, generator.nextLong());
                                                }

    @Test
                                                public void testNextLong_MinValues() {
                                                    BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                        private int nextHigh;
                                                        private int nextLow;
                                                        private boolean returnHigh = true;
                                                        
                                                        public void setNextHighLow(int high, int low) {
                                                            this.nextHigh = high;
                                                            this.nextLow = low;
                                                            this.returnHigh = true;
                                                        }
                                                        
                                                        @Override
                                                        protected int next(int bits) {
                                                            // First call returns high bits, second call returns low bits
                                                            if (returnHigh) {
                                                                returnHigh = false;
                                                                return nextHigh;
                                                            } else {
                                                                return nextLow;
                                                            }
                                                        }
                                                        
                                                        // Implement other abstract methods with dummy implementations
                                                        @Override
                                                        public void setSeed(int seed) {}
                                                        @Override
                                                        public void setSeed(int[] seed) {}
                                                        @Override
                                                        public void setSeed(long seed) {}
                                                    };
                                                    
                                                    // Use reflection to access the setNextHighLow method since we can't modify the original class
                                                    try {
                                                        Method setNextHighLow = generator.getClass().getMethod("setNextHighLow", int.class, int.class);
                                                        setNextHighLow.invoke(generator, 0x00000000, 0x00000000);
                                                    } catch (Exception e) {
                                                        fail("Failed to set next values via reflection");
                                                    }
                                                    
                                                    assertEquals(0x0000000000000000L, generator.nextLong());
                                                }

    @Test
    public void testClassImplementsSerializableAndCloneable() {
        // Create an anonymous subclass since BitsStreamGenerator is abstract
        BitsStreamGenerator generator = new BitsStreamGenerator() {
            @Override
            protected int next(int bits) {
                return 0; // dummy implementation
            }
            
            @Override
            public void setSeed(int seed) {
                // dummy implementation
            }
            
            @Override
            public void setSeed(int[] seed) {
                // dummy implementation
            }
            
            @Override
            public void setSeed(long seed) {
                // dummy implementation
            }
        };
        
        // Verify the class implements both interfaces
        assertTrue("Class should implement Serializable", 
            generator instanceof java.io.Serializable);
        assertTrue("Class should implement Cloneable", 
            generator instanceof Cloneable);
    }

    @Test
    public void testNextBoolean() {
        // Create an anonymous subclass with controlled next() behavior
        BitsStreamGenerator generator = new BitsStreamGenerator() {
            @Override
            protected int next(int bits) {
                return 1; // will make nextBoolean return true
            }
            
            @Override
            public void setSeed(long seed) {
                // empty implementation for test
            }
            
            @Override
            public void setSeed(int[] seed) {
                // empty implementation for test
            }
            
            @Override
            public void setSeed(int seed) {
                // empty implementation for test
            }
        };
        
        assertTrue(generator.nextBoolean());
        
        // Another case where next returns 0
        BitsStreamGenerator generatorFalse = new BitsStreamGenerator() {
            @Override
            protected int next(int bits) {
                return 0; // will make nextBoolean return false
            }
            
            @Override
            public void setSeed(long seed) {
                // empty implementation for test
            }
            
            @Override
            public void setSeed(int[] seed) {
                // empty implementation for test
            }
            
            @Override
            public void setSeed(int seed) {
                // empty implementation for test
            }
        };
        
        assertFalse(generatorFalse.nextBoolean());
    }


}
