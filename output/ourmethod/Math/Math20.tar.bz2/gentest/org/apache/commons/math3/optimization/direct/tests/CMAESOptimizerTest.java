package gentest.org.apache.commons.math3.optimization.direct.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.direct.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathUnsupportedOperationException;
import org.apache.commons.math3.exception.MathIllegalStateException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.MultivariateOptimizer;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.optimization.SimpleValueChecker;
import org.apache.commons.math3.random.MersenneTwister;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.util.MathArrays;
 
public class CMAESOptimizerTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                                                                                                                                                                                                                                                                                                        public void testRepairAndDecode_WithEmptyArray() {
                                                                                                                                                                                                                                                                                                                                                                                                                            // Create optimizer instance with default constructor
                                                                                                                                                                                                                                                                                                                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(0, new double[0]);
                                                                                                                                                                                                                                                                                                                                                                                                                            double[] emptyArray = new double[0];
                                                                                                                                                                                                                                                                                                                                                                                                                            double[] decodedEmpty = new double[0];
                                                                                                                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                                                                                                                                                                                                // Get the decode method using reflection
                                                                                                                                                                                                                                                                                                                                                                                                                                Method decodeMethod = CMAESOptimizer.class.getDeclaredMethod("decode", double[].class);
                                                                                                                                                                                                                                                                                                                                                                                                                                decodeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                // Create a spy of the optimizer to mock the decode method
                                                                                                                                                                                                                                                                                                                                                                                                                                CMAESOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                // Call the method under test
                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                // Verify the result
                                                                                                                                                                                                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                                    public void testRepairAndDecode_WhenRepairModeFalse() {
                                                                                                                                                                                                                                                                                                                                                                                                        // Create test data
                                                                                                                                                                                                                                                                                                                                                                                                        double[] testArray = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                                                                                                                                                                                                                                                        double[] decodedArray = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                                                                                                        // Create mock optimizer
                                                                                                                                                                                                                                                                                                                                                                                                        CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                                                                                                                                                                            // Use reflection to access the decode method
                                                                                                                                                                                                                                                                                                                                                                                                            Method decodeMethod = CMAESOptimizer.class.getDeclaredMethod("decode", double[].class);
                                                                                                                                                                                                                                                                                                                                                                                                            decodeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                                                                                                            // Stub the decode method to return the input array
                                                                                                                                                                                                                                                                                                                                                                                                            when(decodeMethod.invoke(optimizer, any(double[].class))).thenAnswer(invocation -> {
                                                                                                                                                                                                                                                                                                                                                                                                                double[] input = (double[]) invocation.getArguments()[0];
                                                                                                                                                                                                                                                                                                                                                                                                                return input.clone();
                                                                                                                                                                                                                                                                                                                                                                                                            });
                                                                                                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                                                                                                            // Use reflection to access the repairAndDecode method
                                                                                                                                                                                                                                                                                                                                                                                                            Method repairAndDecodeMethod = CMAESOptimizer.class.getDeclaredMethod("repairAndDecode", double[].class);
                                                                                                                                                                                                                                                                                                                                                                                                            repairAndDecodeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                                                                                                            // Stub the repairAndDecode method to just decode
                                                                                                                                                                                                                                                                                                                                                                                                            when(repairAndDecodeMethod.invoke(optimizer, any(double[].class))).thenAnswer(invocation -> {
                                                                                                                                                                                                                                                                                                                                                                                                                double[] input = (double[]) invocation.getArguments()[0];
                                                                                                                                                                                                                                                                                                                                                                                                                return decodeMethod.invoke(optimizer, input);
                                                                                                                                                                                                                                                                                                                                                                                                            });
                                                                                                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                                                                                                            // Call the method under test
                                                                                                                                                                                                                                                                                                                                                                                                            double[] result = (double[]) repairAndDecodeMethod.invoke(optimizer, testArray);
                                                                                                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                                                                                                            // Verify repair was NOT called by checking that decode was called directly
                                                                                                                                                                                                                                                                                                                                                                                                            verify(decodeMethod, times(1)).invoke(optimizer, testArray);
                                                                                                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                                                                                                                            // Verify result is decoded original array
                                                                                                                                                                                                                                                                                                                                                                                                            assertArrayEquals(decodedArray, result, 0.0001);
                                                                                                                                                                                                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                                                                                                                                                                                                            fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                                                                                                                                            public void testRepairAndDecode_VerifyRepairAndDecodeSequence() {
                                                                                                                                                                                                                                                                                                                                                                                                // Create optimizer instance with required parameters
                                                                                                                                                                                                                                                                                                                                                                                                org.apache.commons.math3.random.JDKRandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                                                                                                                                                                                                                                                                                                                                double[] inputSigma = new double[]{0.5}; // Example input sigma
                                                                                                                                                                                                                                                                                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                                                                                                                                                                                                                                                                                                                                        10,          // lambda
                                                                                                                                                                                                                                                                                                                                                                                                        inputSigma,  // inputSigma
                                                                                                                                                                                                                                                                                                                                                                                                        100,         // maxIterations
                                                                                                                                                                                                                                                                                                                                                                                                        1e-13,       // stopFitness
                                                                                                                                                                                                                                                                                                                                                                                                        true,        // isActiveCMA
                                                                                                                                                                                                                                                                                                                                                                                                        0,           // diagonalOnly
                                                                                                                                                                                                                                                                                                                                                                                                        0,           // checkFeasableCount
                                                                                                                                                                                                                                                                                                                                                                                                        random,      // random
                                                                                                                                                                                                                                                                                                                                                                                                        false,       // generateStatistics
                                                                                                                                                                                                                                                                                                                                                                                                        null         // checker
                                                                                                                                                                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                // Use reflection to set valueRange since setValueRange is package-private
                                                                                                                                                                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                                                                                                                                                                    Field valueRangeField = CMAESOptimizer.class.getDeclaredField("valueRange");
                                                                                                                                                                                                                                                                                                                                                                                                    valueRangeField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                                    valueRangeField.set(optimizer, 1.0); // Set as primitive double
                                                                                                                                                                                                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                                                                                                                                                                                                    fail("Failed to set valueRange via reflection");
                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                // Create test data
                                                                                                                                                                                                                                                                                                                                                                                                double[] testArray = {4.0, 5.0, 6.0};
                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                // Call the method under test
                                                                                                                                                                                                                                                                                                                                                                                                double[] result = null;
                                                                                                                                                                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                                                                                                                                                                    Method repairAndDecodeMethod = CMAESOptimizer.class.getDeclaredMethod("repairAndDecode", double[].class);
                                                                                                                                                                                                                                                                                                                                                                                                    repairAndDecodeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                                                                                    result = (double[]) repairAndDecodeMethod.invoke(optimizer, testArray);
                                                                                                                                                                                                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                                                                                                                                                                                                    fail("Failed to invoke repairAndDecode method via reflection");
                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                // Verify the result is not null
                                                                                                                                                                                                                                                                                                                                                                                                assertNotNull(result);
                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                // Verify the result length matches input length
                                                                                                                                                                                                                                                                                                                                                                                                assertEquals(testArray.length, result.length);
                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                                                                                                                // Additional verification could be added here based on expected behavior
                                                                                                                                                                                                                                                                                                                                                                                                // Since we can't mock private methods, we can only verify the output meets certain expectations
                                                                                                                                                                                                                                                                                                                                                                                                // For example, verify values are within expected range
                                                                                                                                                                                                                                                                                                                                                                                                for (double value : result) {
                                                                                                                                                                                                                                                                                                                                                                                                    assertTrue(value >= -1.0 && value <= 1.0); // Assuming decode maps to [-1,1] range
                                                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                            public void testRepairAndDecode_WhenBoundariesNotNullAndRepairModeTrue() {
                                                                                                                                                                                                                                                                                                // Initialize test data
                                                                                                                                                                                                                                                                                                double[] testArray = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                                                                                                                                                double[] repairedArray = new double[]{1.0, 1.0, 1.0}; // Assuming repair clamps values to 1.0
                                                                                                                                                                                                                                                                                                double[] decodedArray = new double[]{1.0, 1.0, 1.0}; // Assuming decode returns same as input in this case
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Mock the optimizer behavior
                                                                                                                                                                                                                                                                                                CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Mock the required methods
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Use reflection to set the private fields
                                                                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                                                                    Field valueRangeField = CMAESOptimizer.class.getDeclaredField("valueRange");
                                                                                                                                                                                                                                                                                                    valueRangeField.setAccessible(true);
                                                                                                                                                                                                                                                                                                    valueRangeField.set(optimizer, new double[]{0.0, 1.0}); // Setting proper bounds
                                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                    Field repairModeField = CMAESOptimizer.class.getDeclaredField("repairMode");
                                                                                                                                                                                                                                                                                                    repairModeField.setAccessible(true);
                                                                                                                                                                                                                                                                                                    repairModeField.setBoolean(optimizer, true);
                                                                                                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                                                                                                    fail("Failed to set field via reflection: " + e.getMessage());
                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Call the method under test
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Verify repair was called
                                                                                                                                                                                                                                                                                                // Verify decode was called with repaired array
                                                                                                                                                                                                                                                                                                // Verify result is decoded repaired array
                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                            public void testRepairAndDecode_WithNullInput() {
                                                                                                                                                                                                                                                                                                // Create required parameters
                                                                                                                                                                                                                                                                                                int lambda = 10;
                                                                                                                                                                                                                                                                                                double[] inputSigma = new double[]{1.0};
                                                                                                                                                                                                                                                                                                int maxIterations = 1000;
                                                                                                                                                                                                                                                                                                double stopFitness = 0.0;
                                                                                                                                                                                                                                                                                                boolean isActiveCMA = true;
                                                                                                                                                                                                                                                                                                int diagonalOnly = 0;
                                                                                                                                                                                                                                                                                                int checkFeasableCount = 1;
                                                                                                                                                                                                                                                                                                org.apache.commons.math3.random.RandomGenerator random = 
                                                                                                                                                                                                                                                                                                    new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                                                                                                                                                                                                                                boolean generateStatistics = false;
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Create a new CMAESOptimizer using the correct constructor
                                                                                                                                                                                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                                                                                                                                                                                                                                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                                                                                                                                                                                                                                                                        lambda,
                                                                                                                                                                                                                                                                                                        inputSigma,
                                                                                                                                                                                                                                                                                                        maxIterations,
                                                                                                                                                                                                                                                                                                        stopFitness,
                                                                                                                                                                                                                                                                                                        isActiveCMA,
                                                                                                                                                                                                                                                                                                        diagonalOnly,
                                                                                                                                                                                                                                                                                                        checkFeasableCount,
                                                                                                                                                                                                                                                                                                        random,
                                                                                                                                                                                                                                                                                                        generateStatistics);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Call the method with null input
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Verify the result is not null (basic assertion)
                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                            public void testRepairAndDecode_WhenBoundariesNull() {
                                                                                                                                                                                                                                                                                                // Create test data
                                                                                                                                                                                                                                                                                                double[] testArray = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                                                                                                                                                double[] decodedArray = new double[]{1.0, 2.0, 3.0}; // Assuming decode returns same array
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Create mock of the optimizer
                                                                                                                                                                                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                                                                                                                                                                                                                                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer(0, new double[]{1.0}, 0, 0, false, 0, 0, null, false);
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Use reflection to set valueRange field since it's private
                                                                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                                                                    java.lang.reflect.Field valueRangeField = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("valueRange");
                                                                                                                                                                                                                                                                                                    valueRangeField.setAccessible(true);
                                                                                                                                                                                                                                                                                                    valueRangeField.set(optimizer, null);
                                                                                                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                                                                                                    org.junit.Assert.fail("Failed to set valueRange field through reflection");
                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Call the method under test
                                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                                // Verify repair was NOT called (since valueRange is null, it should just return the input)
                                                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                                                public void testGetStatisticsSigmaHistoryWithDifferentBoundaryConditions() throws Exception {
                                                                                                                                                                                                                                                                                    // Create test data
                                                                                                                                                                                                                                                                                    List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Case 1: boundaries not null, repair mode true
                                                                                                                                                                                                                                                                                    CMAESOptimizer optimizer1 = new CMAESOptimizer(10);
                                                                                                                                                                                                                                                                                    Field boundariesField1 = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                                    boundariesField1.setAccessible(true);
                                                                                                                                                                                                                                                                                    boundariesField1.set(optimizer1, new double[][]{{0, 1}}); // boundaries not null
                                                                                                                                                                                                                                                                                    Field repairModeField1 = CMAESOptimizer.class.getDeclaredField("isRepairMode");
                                                                                                                                                                                                                                                                                    repairModeField1.setAccessible(true);
                                                                                                                                                                                                                                                                                    repairModeField1.set(optimizer1, true);
                                                                                                                                                                                                                                                                                    Field sigmaHistoryField1 = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                                                    sigmaHistoryField1.setAccessible(true);
                                                                                                                                                                                                                                                                                    sigmaHistoryField1.set(optimizer1, expectedHistory);
                                                                                                                                                                                                                                                                                    assertEquals(expectedHistory, optimizer1.getStatisticsSigmaHistory());
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Case 2: boundaries null, repair mode true
                                                                                                                                                                                                                                                                                    CMAESOptimizer optimizer2 = new CMAESOptimizer(10);
                                                                                                                                                                                                                                                                                    Field boundariesField2 = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                                    boundariesField2.setAccessible(true);
                                                                                                                                                                                                                                                                                    boundariesField2.set(optimizer2, null); // boundaries null
                                                                                                                                                                                                                                                                                    Field repairModeField2 = CMAESOptimizer.class.getDeclaredField("isRepairMode");
                                                                                                                                                                                                                                                                                    repairModeField2.setAccessible(true);
                                                                                                                                                                                                                                                                                    repairModeField2.set(optimizer2, true);
                                                                                                                                                                                                                                                                                    Field sigmaHistoryField2 = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                                                    sigmaHistoryField2.setAccessible(true);
                                                                                                                                                                                                                                                                                    sigmaHistoryField2.set(optimizer2, expectedHistory);
                                                                                                                                                                                                                                                                                    assertEquals(expectedHistory, optimizer2.getStatisticsSigmaHistory());
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Case 3: boundaries not null, repair mode false
                                                                                                                                                                                                                                                                                    CMAESOptimizer optimizer3 = new CMAESOptimizer(10);
                                                                                                                                                                                                                                                                                    Field boundariesField3 = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                                    boundariesField3.setAccessible(true);
                                                                                                                                                                                                                                                                                    boundariesField3.set(optimizer3, new double[][]{{0, 1}}); // boundaries not null
                                                                                                                                                                                                                                                                                    Field repairModeField3 = CMAESOptimizer.class.getDeclaredField("isRepairMode");
                                                                                                                                                                                                                                                                                    repairModeField3.setAccessible(true);
                                                                                                                                                                                                                                                                                    repairModeField3.set(optimizer3, false);
                                                                                                                                                                                                                                                                                    Field sigmaHistoryField3 = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                                                    sigmaHistoryField3.setAccessible(true);
                                                                                                                                                                                                                                                                                    sigmaHistoryField3.set(optimizer3, expectedHistory);
                                                                                                                                                                                                                                                                                    assertEquals(expectedHistory, optimizer3.getStatisticsSigmaHistory());
                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                    // Case 4: boundaries null, repair mode false
                                                                                                                                                                                                                                                                                    CMAESOptimizer optimizer4 = new CMAESOptimizer(10);
                                                                                                                                                                                                                                                                                    Field boundariesField4 = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                                    boundariesField4.setAccessible(true);
                                                                                                                                                                                                                                                                                    boundariesField4.set(optimizer4, null); // boundaries null
                                                                                                                                                                                                                                                                                    Field repairModeField4 = CMAESOptimizer.class.getDeclaredField("isRepairMode");
                                                                                                                                                                                                                                                                                    repairModeField4.setAccessible(true);
                                                                                                                                                                                                                                                                                    repairModeField4.set(optimizer4, false);
                                                                                                                                                                                                                                                                                    Field sigmaHistoryField4 = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                                                    sigmaHistoryField4.setAccessible(true);
                                                                                                                                                                                                                                                                                    sigmaHistoryField4.set(optimizer4, expectedHistory);
                                                                                                                                                                                                                                                                                    assertEquals(expectedHistory, optimizer4.getStatisticsSigmaHistory());
                                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                        public void testGetStatisticsSigmaHistory() {
                                                                                                                                                                                                                                                                            // Create test data
                                                                                                                                                                                                                                                                            List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Test case 1: boundaries null, repairMode false
                                                                                                                                                                                                                                                                            CMAESOptimizer optimizer1 = new CMAESOptimizer();
                                                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                                                java.lang.reflect.Field sigmaHistoryField = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                                                sigmaHistoryField.setAccessible(true);
                                                                                                                                                                                                                                                                                sigmaHistoryField.set(optimizer1, expectedHistory);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                java.lang.reflect.Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                                boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                                                boundariesField.set(optimizer1, null);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                java.lang.reflect.Field repairModeField = CMAESOptimizer.class.getDeclaredField("isRepairMode");
                                                                                                                                                                                                                                                                                repairModeField.setAccessible(true);
                                                                                                                                                                                                                                                                                repairModeField.set(optimizer1, false);
                                                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                                                fail("Failed to set fields via reflection");
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                            assertNull(optimizer1.getStatisticsSigmaHistory());
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Test case 2: boundaries non-null, repairMode false
                                                                                                                                                                                                                                                                            CMAESOptimizer optimizer2 = new CMAESOptimizer();
                                                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                                                java.lang.reflect.Field sigmaHistoryField = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                                                sigmaHistoryField.setAccessible(true);
                                                                                                                                                                                                                                                                                sigmaHistoryField.set(optimizer2, expectedHistory);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                java.lang.reflect.Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                                boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                                                boundariesField.set(optimizer2, new double[][]{{1.0}});
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                java.lang.reflect.Field repairModeField = CMAESOptimizer.class.getDeclaredField("isRepairMode");
                                                                                                                                                                                                                                                                                repairModeField.setAccessible(true);
                                                                                                                                                                                                                                                                                repairModeField.set(optimizer2, false);
                                                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                                                fail("Failed to set fields via reflection");
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                            assertEquals(expectedHistory, optimizer2.getStatisticsSigmaHistory());
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Test case 3: boundaries null, repairMode true
                                                                                                                                                                                                                                                                            CMAESOptimizer optimizer3 = new CMAESOptimizer();
                                                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                                                java.lang.reflect.Field sigmaHistoryField = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                                                sigmaHistoryField.setAccessible(true);
                                                                                                                                                                                                                                                                                sigmaHistoryField.set(optimizer3, expectedHistory);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                java.lang.reflect.Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                                boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                                                boundariesField.set(optimizer3, null);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                java.lang.reflect.Field repairModeField = CMAESOptimizer.class.getDeclaredField("isRepairMode");
                                                                                                                                                                                                                                                                                repairModeField.setAccessible(true);
                                                                                                                                                                                                                                                                                repairModeField.set(optimizer3, true);
                                                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                                                fail("Failed to set fields via reflection");
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                            assertNull(optimizer3.getStatisticsSigmaHistory());
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Test case 4: boundaries non-null, repairMode true
                                                                                                                                                                                                                                                                            CMAESOptimizer optimizer4 = new CMAESOptimizer();
                                                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                                                java.lang.reflect.Field sigmaHistoryField = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                                                sigmaHistoryField.setAccessible(true);
                                                                                                                                                                                                                                                                                sigmaHistoryField.set(optimizer4, expectedHistory);
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                java.lang.reflect.Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                                                                                                                                                boundariesField.setAccessible(true);
                                                                                                                                                                                                                                                                                boundariesField.set(optimizer4, new double[][]{{1.0}});
                                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                                java.lang.reflect.Field repairModeField = CMAESOptimizer.class.getDeclaredField("isRepairMode");
                                                                                                                                                                                                                                                                                repairModeField.setAccessible(true);
                                                                                                                                                                                                                                                                                repairModeField.set(optimizer4, true);
                                                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                                                fail("Failed to set fields via reflection");
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                            assertEquals(expectedHistory, optimizer4.getStatisticsSigmaHistory());
                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                        public void testGetStatisticsSigmaHistory1() {
                                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Create test data
                                                                                                                                                                                                                                                                            List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Use reflection to set the private field since there's no setter
                                                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                                                java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                                                                                                                                field.set(optimizer, expectedHistory);
                                                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                                                fail("Failed to set statisticsSigmaHistory field via reflection");
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                                                                            List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                                            assertSame("Should return the exact same list instance", expectedHistory, actualHistory);
                                                                                                                                                                                                                                                                            assertEquals("Should return correct history data", Arrays.asList(1.0, 2.0, 3.0), actualHistory);
                                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                                    public void testGetStatisticsSigmaHistory2() {
                                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Create test data
                                                                                                                                                                                                                                                                        List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Use reflection to set the private field since there's no setter
                                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                                            java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                                                                                                                            field.set(optimizer, expectedHistory);
                                                                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                                                                            fail("Failed to set statisticsSigmaHistory field via reflection");
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Test
                                                                                                                                                                                                                                                                        Object result = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify return type is List<Double>
                                                                                                                                                                                                                                                                        assertTrue("Return type should be List", result instanceof List);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Verify the content matches what we set
                                                                                                                                                                                                                                                                        assertEquals("Returned history should match expected", expectedHistory, result);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Explicitly verify it's not returning true (the mutant behavior)
                                                                                                                                                                                                                                                                        assertNotEquals("Method should not return true (mutant check)", true, result);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                                public void testGetStatisticsSigmaHistory3() {
                                                                                                                                                                                                                                                                    // Create test data
                                                                                                                                                                                                                                                                    List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Create optimizer instance using constructor that enables statistics
                                                                                                                                                                                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                                                                                                                                                                                                        10,                      // lambda
                                                                                                                                                                                                                                                                        new double[]{0.1, 0.2},  // inputSigma
                                                                                                                                                                                                                                                                        1000,                   // maxIterations
                                                                                                                                                                                                                                                                        1e-12,                  // stopFitness
                                                                                                                                                                                                                                                                        true,                   // isActiveCMA
                                                                                                                                                                                                                                                                        0,                       // diagonalOnly
                                                                                                                                                                                                                                                                        1,                       // checkFeasableCount
                                                                                                                                                                                                                                                                        null,                    // random
                                                                                                                                                                                                                                                                        true                     // generateStatistics
                                                                                                                                                                                                                                                                    );
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Use reflection to set the private statisticsSigmaHistory field for testing
                                                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                                                        java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                                        field.setAccessible(true);
                                                                                                                                                                                                                                                                        field.set(optimizer, expectedHistory);
                                                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                                                        fail("Failed to set statisticsSigmaHistory field for testing");
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Test the method
                                                                                                                                                                                                                                                                    List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Verify the result
                                                                                                                                                                                                                                                                    assertNotNull("Returned history should not be null", actualHistory);
                                                                                                                                                                                                                                                                    assertEquals("History size should match", expectedHistory.size(), actualHistory.size());
                                                                                                                                                                                                                                                                    assertEquals("History content should match", expectedHistory, actualHistory);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // This test would fail on the mutant since it would return false instead of the List
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testGetStatisticsSigmaHistoryWithProperEncoding() {
                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                    double[] inputSigma = new double[]{0.5, 0.5};
                                                                                                                                                                                                                                                    int lambda = 10;
                                                                                                                                                                                                                                                    boolean generateStatistics = true;
                                                                                                                                                                                                                                                    org.apache.commons.math3.random.JDKRandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                                                                                                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer(lambda, inputSigma, 
                                                                                                                                                                                                                                                        1000, 1e-6, true, 0, 1, random, generateStatistics);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Initialize with a dummy optimization problem using reflection since initializeCMA is private
                                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                                        java.lang.reflect.Method initializeCMA = CMAESOptimizer.class.getDeclaredMethod("initializeCMA", double[].class);
                                                                                                                                                                                                                                                        initializeCMA.setAccessible(true);
                                                                                                                                                                                                                                                        initializeCMA.invoke(optimizer, new Object[]{new double[]{1.0, 1.0}});
                                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                                        fail("Failed to initialize CMA due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Get statistics sigma history
                                                                                                                                                                                                                                                    List<Double> originalHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Add test values that would differ between repaired+decoded vs just decoded
                                                                                                                                                                                                                                                    double testValue = 1.5; // A value that might need repair
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Assertions
                                                                                                                                                                                                                                                    assertNotNull("Statistics sigma history should not be null", originalHistory);
                                                                                                                                                                                                                                                    assertTrue("Statistics collection should be active when generateStatistics is true", 
                                                                                                                                                                                                                                                        optimizer.getStatisticsSigmaHistory().size() >= 0);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                        public void testGetStatisticsSigmaHistoryAfterOptimization() {
                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                            double[] inputSigma = new double[]{0.5};
                                                                                                                                                                                                                                            RandomGenerator random = mock(RandomGenerator.class);
                                                                                                                                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(10, inputSigma, 100, 1e-6, 
                                                                                                                                                                                                                                                    true, 0, 1, random, true);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Use reflection to set the private field since we can't access it directly
                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                                                                                                List<Double> expectedHistory = Arrays.asList(0.5, 0.4, 0.3);
                                                                                                                                                                                                                                                field.set(optimizer, expectedHistory);
                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                fail("Failed to set statisticsSigmaHistory through reflection: " + e.getMessage());
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                                            List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                            assertEquals("Statistics sigma history should match expected values", 
                                                                                                                                                                                                                                                    Arrays.asList(0.5, 0.4, 0.3), actualHistory);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Verify the mutation by checking the order of operations would affect results
                                                                                                                                                                                                                                            // This is implicit in the test since the mutation would change the contents
                                                                                                                                                                                                                                            // of statisticsSigmaHistory during actual optimization
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                        public void testGetStatisticsSigmaHistoryWithEmptyHistory() throws Exception {
                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Use reflection to set private fields
                                                                                                                                                                                                                                            Field generateStatisticsField = CMAESOptimizer.class.getDeclaredField("generateStatistics");
                                                                                                                                                                                                                                            generateStatisticsField.setAccessible(true);
                                                                                                                                                                                                                                            generateStatisticsField.set(optimizer, true);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            Field statisticsSigmaHistoryField = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                            statisticsSigmaHistoryField.setAccessible(true);
                                                                                                                                                                                                                                            statisticsSigmaHistoryField.set(optimizer, null);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Test and verify
                                                                                                                                                                                                                                            assertNull("Should return null when no history exists",
                                                                                                                                                                                                                                                    optimizer.getStatisticsSigmaHistory());
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                        public void testGetStatisticsSigmaHistoryReturnsSameInstance() {
                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                                            List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Use reflection to set the private field since there's no setter
                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                                                                                                field.set(optimizer, expectedHistory);
                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                fail("Failed to set statisticsSigmaHistory field via reflection");
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                                            List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Assert - should be same instance (original behavior)
                                                                                                                                                                                                                                            assertSame("Returned list should be the same instance as the internal field", 
                                                                                                                                                                                                                                                      expectedHistory, actualHistory);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Additional check for mutation where clone is returned
                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                actualHistory.add(4.0);
                                                                                                                                                                                                                                                assertEquals("Modifying returned list should modify internal state",
                                                                                                                                                                                                                                                            4, expectedHistory.size());
                                                                                                                                                                                                                                            } catch (UnsupportedOperationException e) {
                                                                                                                                                                                                                                                // Some List implementations are immutable
                                                                                                                                                                                                                                                // In this case, we can check if both lists are still equal
                                                                                                                                                                                                                                                assertEquals("Lists should remain equal after modification attempt",
                                                                                                                                                                                                                                                            expectedHistory, actualHistory);
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                            public void testGetStatisticsSigmaHistoryReturnsProcessedValues() {
                                                                                                                                                                                                                                // Setup test with generateStatistics enabled
                                                                                                                                                                                                                                org.apache.commons.math3.random.JDKRandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                                                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                                                                                                                                                                    10,                     // lambda
                                                                                                                                                                                                                                    new double[]{1.0},      // inputSigma
                                                                                                                                                                                                                                    1000,                   // maxIterations
                                                                                                                                                                                                                                    1e-12,                  // stopFitness
                                                                                                                                                                                                                                    true,                   // isActiveCMA
                                                                                                                                                                                                                                    0,                      // diagonalOnly
                                                                                                                                                                                                                                    1,                      // checkFeasableCount
                                                                                                                                                                                                                                    random,                 // random
                                                                                                                                                                                                                                    true                    // generateStatistics
                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Force some sigma history to be recorded
                                                                                                                                                                                                                                // This would normally happen during optimization, but we'll simulate it
                                                                                                                                                                                                                                // by directly accessing the field via reflection for testing purposes
                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                    java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                                                                                                    List<Double> testHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                                                                    field.set(optimizer, testHistory);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Test that the returned values match exactly what we set
                                                                                                                                                                                                                                    // If the mutant is present, it might try to process the values
                                                                                                                                                                                                                                    List<Double> result = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                                                    assertEquals("Returned sigma history should match exactly what was set", 
                                                                                                                                                                                                                                                testHistory, result);
                                                                                                                                                                                                                                    assertEquals("Size should match", 3, result.size());
                                                                                                                                                                                                                                    assertEquals("First value should match", 1.0, result.get(0), 0.0001);
                                                                                                                                                                                                                                    assertEquals("Second value should match", 2.0, result.get(1), 0.0001);
                                                                                                                                                                                                                                    assertEquals("Third value should match", 3.0, result.get(2), 0.0001);
                                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                    public void testGetStatisticsSigmaHistoryDetectsMutation() {
                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                        int lambda = 10;
                                                                                                                                                                                                                        double[] inputSigma = new double[]{0.5};
                                                                                                                                                                                                                        int maxIterations = 100;
                                                                                                                                                                                                                        double stopFitness = 1e-12;
                                                                                                                                                                                                                        boolean isActiveCMA = true;
                                                                                                                                                                                                                        int diagonalOnly = 0;
                                                                                                                                                                                                                        int checkFeasableCount = 1;
                                                                                                                                                                                                                        RandomGenerator random = new MersenneTwister();
                                                                                                                                                                                                                        boolean generateStatistics = true;
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Create optimizer with statistics generation enabled
                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                                                                                                                                                            lambda, inputSigma, maxIterations, stopFitness, 
                                                                                                                                                                                                                            isActiveCMA, diagonalOnly, checkFeasableCount, 
                                                                                                                                                                                                                            random, generateStatistics);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Run optimization using reflection to access protected method
                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                            Method doOptimize = CMAESOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                            doOptimize.setAccessible(true);
                                                                                                                                                                                                                            doOptimize.invoke(optimizer);
                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                            fail("Failed to invoke doOptimize: " + e.getMessage());
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Get sigma history
                                                                                                                                                                                                                        List<Double> sigmaHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Verify statistics were collected
                                                                                                                                                                                                                        assertNotNull("Sigma history should not be null", sigmaHistory);
                                                                                                                                                                                                                        assertFalse("Sigma history should not be empty", sigmaHistory.isEmpty());
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Verify sigma values follow expected pattern
                                                                                                                                                                                                                        double firstSigma = sigmaHistory.get(0);
                                                                                                                                                                                                                        double lastSigma = sigmaHistory.get(sigmaHistory.size() - 1);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Typically sigma should decrease during optimization
                                                                                                                                                                                                                        assertTrue("Sigma should generally decrease", lastSigma < firstSigma);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Check for reasonable values
                                                                                                                                                                                                                        for (double sigma : sigmaHistory) {
                                                                                                                                                                                                                            assertTrue("Sigma should be positive", sigma > 0);
                                                                                                                                                                                                                            assertTrue("Sigma should be reasonable value", sigma < 10);
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                    public void testGetStatisticsSigmaHistory4() {
                                                                                                                                                                                                                        // Create test data
                                                                                                                                                                                                                        List<Double> testData = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Create instance and set the field via reflection since it's private
                                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                            java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test case 1: returns null when field is null
                                                                                                                                                                                                                            field.set(optimizer, null);
                                                                                                                                                                                                                            assertNull(optimizer.getStatisticsSigmaHistory());
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test case 2: returns the exact same list object
                                                                                                                                                                                                                            field.set(optimizer, testData);
                                                                                                                                                                                                                            assertSame(testData, optimizer.getStatisticsSigmaHistory());
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test case 3: returned list contains expected values
                                                                                                                                                                                                                            assertEquals(3, optimizer.getStatisticsSigmaHistory().size());
                                                                                                                                                                                                                            assertEquals(1.0, optimizer.getStatisticsSigmaHistory().get(0), 0.0001);
                                                                                                                                                                                                                            assertEquals(2.0, optimizer.getStatisticsSigmaHistory().get(1), 0.0001);
                                                                                                                                                                                                                            assertEquals(3.0, optimizer.getStatisticsSigmaHistory().get(2), 0.0001);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test case 4: modifications to returned list don't affect internal state
                                                                                                                                                                                                                            List<Double> returnedList = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                                            returnedList.set(0, 5.0);
                                                                                                                                                                                                                            assertEquals(5.0, returnedList.get(0), 0.0001);
                                                                                                                                                                                                                            assertEquals(1.0, optimizer.getStatisticsSigmaHistory().get(0), 0.0001);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                            fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                public void testGetStatisticsSigmaHistory5() {
                                                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                                                    List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Create instance and set field via reflection since it's private
                                                                                                                                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer(10); // using simplest constructor
                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                        // Use reflection to set the private field for testing
                                                                                                                                                                                                                        java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                                        field.setAccessible(true);
                                                                                                                                                                                                                        field.set(optimizer, expectedHistory);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Also set generateStatistics to true
                                                                                                                                                                                                                        field = CMAESOptimizer.class.getDeclaredField("generateStatistics");
                                                                                                                                                                                                                        field.setAccessible(true);
                                                                                                                                                                                                                        field.set(optimizer, true);
                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                        fail("Failed to set up test via reflection");
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Test - verify the returned list is exactly what we set (mutant behavior)
                                                                                                                                                                                                                    List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                                    assertNotNull("Returned history should not be null", actualHistory);
                                                                                                                                                                                                                    assertEquals("History size should match", expectedHistory.size(), actualHistory.size());
                                                                                                                                                                                                                    assertEquals("History contents should match exactly", expectedHistory, actualHistory);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Additional test for when generateStatistics is false
                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                        java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("generateStatistics");
                                                                                                                                                                                                                        field.setAccessible(true);
                                                                                                                                                                                                                        field.set(optimizer, false);
                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                        fail("Failed to modify generateStatistics via reflection");
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    assertNull("Should return null when generateStatistics is false", 
                                                                                                                                                                                                                              optimizer.getStatisticsSigmaHistory());
                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                    public void testGetStatisticsSigmaHistoryReturnsActualList() {
                                                                                                                                                                                                        // Setup - create optimizer with statistics generation enabled
                                                                                                                                                                                                        int lambda = 10;
                                                                                                                                                                                                        double[] inputSigma = new double[]{1.0};
                                                                                                                                                                                                        boolean generateStatistics = true;
                                                                                                                                                                                                        org.apache.commons.math3.random.JDKRandomGenerator randomGenerator = new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                                                                                                                                            lambda, 
                                                                                                                                                                                                            inputSigma, 
                                                                                                                                                                                                            CMAESOptimizer.DEFAULT_MAXITERATIONS, 
                                                                                                                                                                                                            CMAESOptimizer.DEFAULT_STOPFITNESS, 
                                                                                                                                                                                                            CMAESOptimizer.DEFAULT_ISACTIVECMA, 
                                                                                                                                                                                                            CMAESOptimizer.DEFAULT_DIAGONALONLY, 
                                                                                                                                                                                                            CMAESOptimizer.DEFAULT_CHECKFEASABLECOUNT, 
                                                                                                                                                                                                            randomGenerator, 
                                                                                                                                                                                                            generateStatistics
                                                                                                                                                                                                        );
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Exercise optimization to populate statistics
                                                                                                                                                                                                        // (Note: In a real test, we would need to actually run some optimization steps,
                                                                                                                                                                                                        // but for this test we'll verify the basic behavior)
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Verify the statistics sigma history is not null
                                                                                                                                                                                                        List<Double> result = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                        assertNotNull("Statistics sigma history should not be null", result);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Additional verification that it returns the actual field
                                                                                                                                                                                                        // (This would normally be populated during optimization)
                                                                                                                                                                                                        assertSame("Should return the actual statisticsSigmaHistory field", 
                                                                                                                                                                                                                  optimizer.getStatisticsSigmaHistory(), 
                                                                                                                                                                                                                  optimizer.getStatisticsSigmaHistory());
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                            public void testGetStatisticsSigmaHistory6() {
                                                                                                                                                                                                // Setup test with statistics generation enabled
                                                                                                                                                                                                org.apache.commons.math3.random.JDKRandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                                                                                                                                    10,                     // lambda
                                                                                                                                                                                                    new double[]{1.0, 2.0}, // inputSigma
                                                                                                                                                                                                    1000,                   // maxIterations
                                                                                                                                                                                                    1e-12,                  // stopFitness
                                                                                                                                                                                                    true,                   // isActiveCMA
                                                                                                                                                                                                    0,                      // diagonalOnly
                                                                                                                                                                                                    1,                      // checkFeasableCount
                                                                                                                                                                                                    random,                 // random
                                                                                                                                                                                                    true                    // generateStatistics
                                                                                                                                                                                                );
                                                                                                                                                                                                
                                                                                                                                                                                                // Test 1: Verify returned list is not null when generateStatistics is true
                                                                                                                                                                                                List<Double> result = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                assertNotNull("Returned list should not be null when generateStatistics is true", result);
                                                                                                                                                                                                
                                                                                                                                                                                                // Test 2: Verify modifying returned list doesn't affect internal state
                                                                                                                                                                                                List<Double> original = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                int originalSize = original.size();
                                                                                                                                                                                                try {
                                                                                                                                                                                                    original.add(1.0);
                                                                                                                                                                                                    fail("Should have thrown UnsupportedOperationException for immutable list");
                                                                                                                                                                                                } catch (UnsupportedOperationException e) {
                                                                                                                                                                                                    // Expected behavior
                                                                                                                                                                                                }
                                                                                                                                                                                                assertEquals("Internal state should not be modified", 
                                                                                                                                                                                                    originalSize, optimizer.getStatisticsSigmaHistory().size());
                                                                                                                                                                                                    
                                                                                                                                                                                                // Test 3: Verify with generateStatistics disabled
                                                                                                                                                                                                CMAESOptimizer noStatsOptimizer = new CMAESOptimizer(
                                                                                                                                                                                                    10,                     // lambda
                                                                                                                                                                                                    new double[]{1.0, 2.0}, // inputSigma
                                                                                                                                                                                                    1000,                   // maxIterations
                                                                                                                                                                                                    1e-12,                  // stopFitness
                                                                                                                                                                                                    true,                   // isActiveCMA
                                                                                                                                                                                                    0,                      // diagonalOnly
                                                                                                                                                                                                    1,                      // checkFeasableCount
                                                                                                                                                                                                    random,                 // random
                                                                                                                                                                                                    false                   // generateStatistics
                                                                                                                                                                                                );
                                                                                                                                                                                                assertNotNull("Returned list should not be null even when generateStatistics is false", 
                                                                                                                                                                                                    noStatsOptimizer.getStatisticsSigmaHistory());
                                                                                                                                                                                                assertEquals("Returned list should be empty when generateStatistics is false",
                                                                                                                                                                                                    0, noStatsOptimizer.getStatisticsSigmaHistory().size());
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testGetStatisticsSigmaHistory7() {
                                                                                                                                                                                                // Setup
                                                                                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                                List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Use reflection to set the private field since there's no setter
                                                                                                                                                                                                try {
                                                                                                                                                                                                    java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                                                                    field.set(optimizer, expectedHistory);
                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                    fail("Failed to set statisticsSigmaHistory via reflection");
                                                                                                                                                                                                }
                                                                                                                                                                                                
                                                                                                                                                                                                // Test
                                                                                                                                                                                                List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify
                                                                                                                                                                                                assertSame("Should return the exact statisticsSigmaHistory field", 
                                                                                                                                                                                                          expectedHistory, actualHistory);
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                        public void testGetStatisticsSigmaHistory8() {
                                                                                                                                                                                            // Create test data
                                                                                                                                                                                            List<Double> expectedHistory = new ArrayList<>();
                                                                                                                                                                                            expectedHistory.add(1.0);
                                                                                                                                                                                            expectedHistory.add(2.0);
                                                                                                                                                                                            expectedHistory.add(3.0);
                                                                                                                                                                                            
                                                                                                                                                                                            // Create optimizer instance with statistics enabled
                                                                                                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                                                                                                                                10,                      // lambda
                                                                                                                                                                                                new double[]{0.1, 0.2},  // inputSigma
                                                                                                                                                                                                1000,                    // maxIterations
                                                                                                                                                                                                1e-12,                   // stopFitness
                                                                                                                                                                                                true,                    // isActiveCMA
                                                                                                                                                                                                0,                       // diagonalOnly
                                                                                                                                                                                                1,                       // checkFeasableCount
                                                                                                                                                                                                mock(RandomGenerator.class), // random
                                                                                                                                                                                                true                     // generateStatistics
                                                                                                                                                                                            );
                                                                                                                                                                                            
                                                                                                                                                                                            // Use reflection to set the private field for testing
                                                                                                                                                                                            try {
                                                                                                                                                                                                java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                                                field.set(optimizer, expectedHistory);
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Failed to set statisticsSigmaHistory field");
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            // Test case 1: Verify getter returns correct history
                                                                                                                                                                                            List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                            assertEquals(expectedHistory, actualHistory);
                                                                                                                                                                                            
                                                                                                                                                                                            // Test case 2: Verify returns null when statistics not generated
                                                                                                                                                                                            CMAESOptimizer noStatsOptimizer = new CMAESOptimizer(
                                                                                                                                                                                                10,
                                                                                                                                                                                                new double[]{0.1, 0.2},
                                                                                                                                                                                                1000,
                                                                                                                                                                                                1e-12,
                                                                                                                                                                                                true,
                                                                                                                                                                                                0,
                                                                                                                                                                                                1,
                                                                                                                                                                                                mock(RandomGenerator.class),
                                                                                                                                                                                                false  // generateStatistics disabled
                                                                                                                                                                                            );
                                                                                                                                                                                            assertNull(noStatsOptimizer.getStatisticsSigmaHistory());
                                                                                                                                                                                            
                                                                                                                                                                                            // Test case 3: Verify returns empty list when initialized but empty
                                                                                                                                                                                            CMAESOptimizer emptyStatsOptimizer = new CMAESOptimizer(
                                                                                                                                                                                                10,
                                                                                                                                                                                                new double[]{0.1, 0.2},
                                                                                                                                                                                                1000,
                                                                                                                                                                                                1e-12,
                                                                                                                                                                                                true,
                                                                                                                                                                                                0,
                                                                                                                                                                                                1,
                                                                                                                                                                                                mock(RandomGenerator.class),
                                                                                                                                                                                                true
                                                                                                                                                                                            );
                                                                                                                                                                                            assertNotNull(emptyStatsOptimizer.getStatisticsSigmaHistory());
                                                                                                                                                                                            assertTrue(emptyStatsOptimizer.getStatisticsSigmaHistory().isEmpty());
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                    public void testGetStatisticsSigmaHistory9() {
                                                                                                                                                                                        // Create test instance
                                                                                                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                        
                                                                                                                                                                                        // Test case 1: When statisticsSigmaHistory is null
                                                                                                                                                                                        assertNull(optimizer.getStatisticsSigmaHistory());
                                                                                                                                                                                        
                                                                                                                                                                                        // Test case 2: When statisticsSigmaHistory contains values
                                                                                                                                                                                        List<Double> testData = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to set the private field for testing
                                                                                                                                                                                        try {
                                                                                                                                                                                            java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                                            field.set(optimizer, testData);
                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                            fail("Failed to set statisticsSigmaHistory field for testing");
                                                                                                                                                                                        }
                                                                                                                                                                                        
                                                                                                                                                                                        List<Double> result = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                        assertNotNull(result);
                                                                                                                                                                                        assertEquals(testData.size(), result.size());
                                                                                                                                                                                        assertEquals(testData, result);
                                                                                                                                                                                        
                                                                                                                                                                                        // Test case 3: Verify returned list is a copy (if it should be immutable)
                                                                                                                                                                                        // This depends on implementation - if the method returns direct reference
                                                                                                                                                                                        // or a defensive copy. Current implementation appears to return direct reference.
                                                                                                                                                                                        result.add(4.0);
                                                                                                                                                                                        assertEquals(4, optimizer.getStatisticsSigmaHistory().size());
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                public void testGetStatisticsSigmaHistory10() {
                                                                                                                                                                                    // Create test data
                                                                                                                                                                                    List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create instance and set test data
                                                                                                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to set the private field for testing
                                                                                                                                                                                    try {
                                                                                                                                                                                        java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                        field.setAccessible(true);
                                                                                                                                                                                        
                                                                                                                                                                                        // Test case 1: When statisticsSigmaHistory is not null
                                                                                                                                                                                        field.set(optimizer, expectedHistory);
                                                                                                                                                                                        List<Double> result = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                        assertNotNull("Returned history should not be null", result);
                                                                                                                                                                                        assertEquals("Returned history should match expected", expectedHistory, result);
                                                                                                                                                                                        
                                                                                                                                                                                        // Test case 2: When statisticsSigmaHistory is null
                                                                                                                                                                                        field.set(optimizer, null);
                                                                                                                                                                                        assertNull("Should return null when statisticsSigmaHistory is null", 
                                                                                                                                                                                                  optimizer.getStatisticsSigmaHistory());
                                                                                                                                                                                        
                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                        fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                            public void testGetStatisticsSigmaHistory11() {
                                                                                                                                                                                // Setup test data
                                                                                                                                                                                List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                                                
                                                                                                                                                                                // Create optimizer instance using constructor that enables statistics
                                                                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                                                                                                                    0,                          // lambda
                                                                                                                                                                                    null,                       // inputSigma
                                                                                                                                                                                    1000,                       // maxIterations
                                                                                                                                                                                    0.0,                        // stopFitness
                                                                                                                                                                                    false,                       // isActiveCMA
                                                                                                                                                                                    0,                          // diagonalOnly
                                                                                                                                                                                    0,                          // checkFeasableCount
                                                                                                                                                                                    null,                       // random
                                                                                                                                                                                    true                        // generateStatistics
                                                                                                                                                                                );
                                                                                                                                                                                
                                                                                                                                                                                // Use reflection to set the private statisticsSigmaHistory field for testing
                                                                                                                                                                                try {
                                                                                                                                                                                    java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                                                    field.set(optimizer, expectedHistory);
                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                    fail("Failed to set statisticsSigmaHistory field via reflection");
                                                                                                                                                                                }
                                                                                                                                                                                
                                                                                                                                                                                // Test the method
                                                                                                                                                                                List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                                                
                                                                                                                                                                                // Verify the result
                                                                                                                                                                                assertNotNull("Returned history should not be null", actualHistory);
                                                                                                                                                                                assertSame("Should return the same list instance that was set", expectedHistory, actualHistory);
                                                                                                                                                                                assertEquals("History contents should match", expectedHistory, actualHistory);
                                                                                                                                                                                
                                                                                                                                                                                // Additional check to catch the mutant that returns false
                                                                                                                                                                                assertNotEquals("Method should not return false", false, actualHistory);
                                                                                                                                                                            }

    @Test
                                                                                                                                                public void testGetStatisticsSigmaHistoryDetectsMutant() {
                                                                                                                                                    // Setup test parameters
                                                                                                                                                    int lambda = 10;
                                                                                                                                                    double[] inputSigma = new double[]{0.5};
                                                                                                                                                    int maxIterations = 1000;
                                                                                                                                                    double stopFitness = 1e-12;
                                                                                                                                                    boolean isActiveCMA = true;
                                                                                                                                                    int diagonalOnly = 0;
                                                                                                                                                    int checkFeasableCount = 1;
                                                                                                                                                    org.apache.commons.math3.random.RandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                                                                                    boolean generateStatistics = true;
                                                                                                                                                    
                                                                                                                                                    // Create optimizer instance with statistics generation enabled
                                                                                                                                                    org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                                                                                                                        lambda, inputSigma, maxIterations, stopFitness, 
                                                                                                                                                        isActiveCMA, diagonalOnly, checkFeasableCount, 
                                                                                                                                                        random, generateStatistics);
                                                                                                                                                    
                                                                                                                                                    // Define test function with values that would need repair
                                                                                                                                                    org.apache.commons.math3.analysis.MultivariateFunction function = new org.apache.commons.math3.analysis.MultivariateFunction() {
                                                                                                                                                        public double value(double[] point) {
                                                                                                                                                            // Function that would benefit from repair step
                                                                                                                                                            return point[0] * point[0] - 2 * point[0] + 1;
                                                                                                                                                        }
                                                                                                                                                    };
                                                                                                                                                    
                                                                                                                                                    // Define starting point that might need repair
                                                                                                                                                    double[] startPoint = new double[]{10.0};
                                                                                                                                                    
                                                                                                                                                    // Define optimization goal
                                                                                                                                                    org.apache.commons.math3.optimization.GoalType goal = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
                                                                                                                                                    
                                                                                                                                                    // Run optimization with correct parameter types
                                                                                                                                                    optimizer.optimize(
                                                                                                                                                        maxIterations,
                                                                                                                                                        function,
                                                                                                                                                        goal,
                                                                                                                                                        startPoint);
                                                                                                                                                    
                                                                                                                                                    // Get statistics history
                                                                                                                                                    java.util.List<Double> sigmaHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                    
                                                                                                                                                    // Verify the history contains reasonable values
                                                                                                                                                    assertNotNull("Sigma history should not be null", sigmaHistory);
                                                                                                                                                    assertFalse("Sigma history should not be empty", sigmaHistory.isEmpty());
                                                                                                                                                    
                                                                                                                                                    // Check that values follow expected pattern (would differ between repaired and non-repaired)
                                                                                                                                                    double previousSigma = Double.MAX_VALUE;
                                                                                                                                                    for (double sigma : sigmaHistory) {
                                                                                                                                                        assertTrue("Sigma should be positive", sigma > 0);
                                                                                                                                                        // In proper operation, sigma should generally decrease
                                                                                                                                                        // The mutant might show different patterns due to missing repair step
                                                                                                                                                        assertTrue("Sigma should generally decrease", sigma <= previousSigma);
                                                                                                                                                        previousSigma = sigma;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    // Additional check: first sigma should match input sigma (adjusted)
                                                                                                                                                    assertEquals("First sigma should match input sigma (adjusted)", 
                                                                                                                                                        0.5, sigmaHistory.get(0), 0.1);
                                                                                                                                                }

    @Test
                                                                                                                                            public void testGetStatisticsSigmaHistoryReturnsDefensiveCopy() {
                                                                                                                                                // Setup
                                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                
                                                                                                                                                // Create a sample statistics list and set it using reflection since it's private
                                                                                                                                                List<Double> originalList = new ArrayList<>();
                                                                                                                                                originalList.add(1.0);
                                                                                                                                                originalList.add(2.0);
                                                                                                                                                
                                                                                                                                                try {
                                                                                                                                                    Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                    field.set(optimizer, originalList);
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    fail("Failed to set statisticsSigmaHistory field via reflection");
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Test
                                                                                                                                                List<Double> returnedList = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                
                                                                                                                                                // Modify the returned list
                                                                                                                                                returnedList.add(3.0);
                                                                                                                                                
                                                                                                                                                // Get the internal list again
                                                                                                                                                List<Double> internalList;
                                                                                                                                                try {
                                                                                                                                                    Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                    internalList = (List<Double>) field.get(optimizer);
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    fail("Failed to get statisticsSigmaHistory field via reflection");
                                                                                                                                                    return;
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Assertions
                                                                                                                                                // Original behavior would show the modification (size 3)
                                                                                                                                                // Mutated behavior with clone would not (size 2)
                                                                                                                                                assertEquals("Internal list should not be modified when returned list is changed", 
                                                                                                                                                             2, internalList.size());
                                                                                                                                                assertEquals("Returned list should contain the modification",
                                                                                                                                                             3, returnedList.size());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testGetStatisticsSigmaHistory12() {
                                                                                                                                                // Setup
                                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                                                                
                                                                                                                                                // Use reflection to set the private field since there's no setter
                                                                                                                                                try {
                                                                                                                                                    java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                    field.set(optimizer, expectedHistory);
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    fail("Failed to set statisticsSigmaHistory field via reflection");
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Test
                                                                                                                                                List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                assertNotNull("Returned history should not be null", actualHistory);
                                                                                                                                                assertEquals("History size should match", expectedHistory.size(), actualHistory.size());
                                                                                                                                                assertEquals("History contents should match", expectedHistory, actualHistory);
                                                                                                                                                
                                                                                                                                                // Additional check that would catch the mutant
                                                                                                                                                try {
                                                                                                                                                    optimizer.getStatisticsSigmaHistory().get(0); // Would throw NPE or ClassCastException if mutant is present
                                                                                                                                                } catch (NullPointerException | ClassCastException e) {
                                                                                                                                                    fail("Mutant detected - method returned wrong type or null");
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                        public void testGetStatisticsSigmaHistoryWithValueProcessing() {
                                                                                                            // Setup
                                                                                                            double[] inputSigma = new double[]{0.5};
                                                                                                            org.apache.commons.math3.random.JDKRandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                                            org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                                                                                10,                  // lambda
                                                                                                                inputSigma,          // inputSigma
                                                                                                                1000,                // maxIterations
                                                                                                                1e-6,                // stopFitness
                                                                                                                true,                // isActiveCMA
                                                                                                                0,                   // diagonalOnly
                                                                                                                1,                   // checkFeasableCount
                                                                                                                random,              // random
                                                                                                                true                 // generateStatistics
                                                                                                            );
                                                                                                            
                                                                                                            // Create a simple optimization problem
                                                                                                            org.apache.commons.math3.analysis.MultivariateFunction fitnessFunction = new org.apache.commons.math3.analysis.MultivariateFunction() {
                                                                                                                public double value(double[] point) {
                                                                                                                    return point[0] * point[0]; // Simple quadratic function
                                                                                                                }
                                                                                                            };
                                                                                                            
                                                                                                            // Initial guess
                                                                                                            double[] startPoint = new double[]{1.0};
                                                                                                            
                                                                                                            // Action - perform optimization (without bounds)
                                                                                                            org.apache.commons.math3.optimization.PointValuePair result = optimizer.optimize(
                                                                                                                1000,  // maxEval
                                                                                                                fitnessFunction,
                                                                                                                org.apache.commons.math3.optimization.GoalType.MINIMIZE,
                                                                                                                startPoint
                                                                                                            );
                                                                                                            
                                                                                                            // Get the statistics
                                                                                                            java.util.List<Double> sigmaHistory = optimizer.getStatisticsSigmaHistory();
                                                                                                            
                                                                                                            // Verification
                                                                                                            org.junit.Assert.assertNotNull("Sigma history should not be null", sigmaHistory);
                                                                                                            org.junit.Assert.assertFalse("Sigma history should not be empty", sigmaHistory.isEmpty());
                                                                                                            
                                                                                                            // Check that values follow the expected coded/decoded pattern
                                                                                                            // rather than repaired values
                                                                                                            for (int i = 1; i < sigmaHistory.size(); i++) {
                                                                                                                double current = sigmaHistory.get(i);
                                                                                                                double previous = sigmaHistory.get(i-1);
                                                                                                                // Expect sigma to decrease (for this simple problem)
                                                                                                                org.junit.Assert.assertTrue("Sigma should generally decrease during optimization", 
                                                                                                                               current <= previous);
                                                                                                                
                                                                                                                // Additional checks could be added here to verify the exact
                                                                                                                // transformation that was applied (codedecode vs repair)
                                                                                                            }
                                                                                                            
                                                                                                            // Verify the last sigma value is close to optimal
                                                                                                            double lastSigma = sigmaHistory.get(sigmaHistory.size() - 1);
                                                                                                            org.junit.Assert.assertTrue("Final sigma should be small", lastSigma < 0.1);
                                                                                                        }

    @Test
                                                                                                        public void testGetStatisticsSigmaHistoryReturnsRawValues() {
                                                                                                            // Setup
                                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                            
                                                                                                            // Create test data that would be different if repaired
                                                                                                            List<Double> testHistory = Arrays.asList(1.0, 2.0, 3.0, 4.0);
                                                                                                            
                                                                                                            // Use reflection to set the private field since it's not accessible otherwise
                                                                                                            try {
                                                                                                                java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                                field.setAccessible(true);
                                                                                                                field.set(optimizer, testHistory);
                                                                                                            } catch (Exception e) {
                                                                                                                fail("Failed to set statisticsSigmaHistory field");
                                                                                                            }
                                                                                                            
                                                                                                            // Test
                                                                                                            List<Double> result = optimizer.getStatisticsSigmaHistory();
                                                                                                            
                                                                                                            // Verify
                                                                                                            assertNotNull("Returned history should not be null", result);
                                                                                                            assertEquals("History size should match", testHistory.size(), result.size());
                                                                                                            for (int i = 0; i < testHistory.size(); i++) {
                                                                                                                assertEquals("Element " + i + " should match original value", 
                                                                                                                             testHistory.get(i), result.get(i), 0.0001);
                                                                                                            }
                                                                                                            
                                                                                                            // This test would fail if values were repaired before being stored in history
                                                                                                            // because repaired values might be different from original values
                                                                                                        }

    @Test
                                                                                                    public void testGetStatisticsSigmaHistory13() {
                                                                                                        // Create test data
                                                                                                        List<Double> testData = Arrays.asList(1.0, 2.0, 3.0);
                                                                                                        
                                                                                                        // Create optimizer instance using reflection to set private field
                                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10); // Using simplest constructor
                                                                                                        
                                                                                                        try {
                                                                                                            // Use reflection to set the private statisticsSigmaHistory field
                                                                                                            java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                            field.setAccessible(true);
                                                                                                            field.set(optimizer, testData);
                                                                                                            
                                                                                                            // Test 1: Verify returned value matches what we set
                                                                                                            List<Double> result = optimizer.getStatisticsSigmaHistory();
                                                                                                            assertSame("Returned list should be the same instance as internal field", testData, result);
                                                                                                            
                                                                                                            // Test 2: Verify modifying returned list affects internal state (shouldn't if defensive copy was made)
                                                                                                            result.add(4.0);
                                                                                                            List<Double> newResult = optimizer.getStatisticsSigmaHistory();
                                                                                                            assertEquals("List size should increase when modified", 4, newResult.size());
                                                                                                            assertEquals("Last element should be 4.0", 4.0, newResult.get(3), 0.0001);
                                                                                                            
                                                                                                            // Test 3: Test with null
                                                                                                            field.set(optimizer, null);
                                                                                                            assertNull("Should return null when field is null", optimizer.getStatisticsSigmaHistory());
                                                                                                            
                                                                                                        } catch (Exception e) {
                                                                                                            fail("Reflection failed: " + e.getMessage());
                                                                                                        }
                                                                                                    }

    @Test
                                                                                        public void testGetStatisticsSigmaHistoryReturnsActualList1() {
                                                                                            // Setup
                                                                                            double[] inputSigma = new double[]{0.5};
                                                                                            org.apache.commons.math3.random.JDKRandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                                10,                      // lambda
                                                                                                inputSigma,              // inputSigma
                                                                                                1000,                    // maxIterations
                                                                                                1e-12,                   // stopFitness
                                                                                                true,                    // isActiveCMA
                                                                                                0,                       // diagonalOnly
                                                                                                1,                       // checkFeasableCount
                                                                                                random,                  // random
                                                                                                true                     // generateStatistics
                                                                                            );
                                                                                            
                                                                                            // Exercise some operations that would populate statistics
                                                                                            // (Note: In real usage, doOptimize() would be called)
                                                                                            // For test purposes, we'll directly inject some test data
                                                                                            List<Double> expectedHistory = Arrays.asList(1.0, 0.9, 0.8);
                                                                                            try {
                                                                                                java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                field.setAccessible(true);
                                                                                                field.set(optimizer, expectedHistory);
                                                                                            } catch (Exception e) {
                                                                                                fail("Failed to set test data via reflection");
                                                                                            }
                                                                                            
                                                                                            // Verify
                                                                                            List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                                            assertNotNull("Returned statistics sigma history should not be null", actualHistory);
                                                                                            assertEquals("Returned history should match expected history", 
                                                                                                        expectedHistory, 
                                                                                                        actualHistory);
                                                                                        }

    @Test
                                                                                        public void testGetStatisticsSigmaHistory14() {
                                                                                            // Create test data
                                                                                            List<Double> testData = Arrays.asList(1.0, 2.0, 3.0);
                                                                                            
                                                                                            // Create instance and set the field via reflection since it's private
                                                                                            CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                            try {
                                                                                                java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                                field.setAccessible(true);
                                                                                                
                                                                                                // Test case 1: Verify returns exact same object reference
                                                                                                field.set(optimizer, testData);
                                                                                                List<Double> result = optimizer.getStatisticsSigmaHistory();
                                                                                                assertSame("Should return the same list object", testData, result);
                                                                                                
                                                                                                // Test case 2: Verify modifications to returned list don't affect internal state
                                                                                                result.add(4.0);
                                                                                                List<Double> internalData = (List<Double>) field.get(optimizer);
                                                                                                assertEquals("Internal list should be modified", 4, internalData.size());
                                                                                                
                                                                                                // Test case 3: Verify null case
                                                                                                field.set(optimizer, null);
                                                                                                assertNull("Should return null when field is null", optimizer.getStatisticsSigmaHistory());
                                                                                                
                                                                                                // Test case 4: Verify empty list case
                                                                                                field.set(optimizer, Arrays.asList());
                                                                                                assertNotNull("Should not return null for empty list", optimizer.getStatisticsSigmaHistory());
                                                                                                assertEquals("Empty list should be returned", 0, optimizer.getStatisticsSigmaHistory().size());
                                                                                                
                                                                                            } catch (Exception e) {
                                                                                                fail("Reflection failed: " + e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                    public void testGetStatisticsSigmaHistory15() {
                                                                                        // Create test data
                                                                                        List<Double> expectedHistory = new ArrayList<>();
                                                                                        expectedHistory.add(1.0);
                                                                                        expectedHistory.add(2.0);
                                                                                        expectedHistory.add(3.0);
                                                                                        
                                                                                        // Create CMAESOptimizer instance using constructor
                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10); // Using simplest constructor
                                                                                        
                                                                                        // Use reflection to set the private field for testing
                                                                                        try {
                                                                                            java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                            field.setAccessible(true);
                                                                                            field.set(optimizer, expectedHistory);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set statisticsSigmaHistory field for testing");
                                                                                        }
                                                                                        
                                                                                        // Test that getter returns the correct list
                                                                                        List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                                        assertEquals("Returned history should match set history", expectedHistory, actualHistory);
                                                                                        
                                                                                        // Test that modifying returned list doesn't affect internal state
                                                                                        actualHistory.add(4.0);
                                                                                        List<Double> newHistory = optimizer.getStatisticsSigmaHistory();
                                                                                        assertNotSame("Modifying returned list should not affect internal state", 
                                                                                                     expectedHistory.size(), newHistory.size());
                                                                                        assertEquals("Internal history should remain unchanged", 
                                                                                                    3, newHistory.size());
                                                                                    }

    @Test
                                                                        public void testGetStatisticsSigmaHistory16() {
                                                                            // Create test cases for all combinations of boundary and repair mode states
                                                                            
                                                                            try {
                                                                                // Get both fields via reflection
                                                                                java.lang.reflect.Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                boundariesField.setAccessible(true);
                                                                                java.lang.reflect.Field repairModeField = CMAESOptimizer.class.getDeclaredField("isRepairMode");
                                                                                repairModeField.setAccessible(true);
                                                                                
                                                                                // Test case 1: boundaries null, repair mode false
                                                                                CMAESOptimizer optimizer1 = new CMAESOptimizer(10);
                                                                                boundariesField.set(optimizer1, null);
                                                                                repairModeField.set(optimizer1, false);
                                                                                List<Double> result1 = optimizer1.getStatisticsSigmaHistory();
                                                                                assertNotNull(result1); // Should return the field regardless of conditions
                                                                                
                                                                                // Test case 2: boundaries not null, repair mode false
                                                                                CMAESOptimizer optimizer2 = new CMAESOptimizer(10);
                                                                                boundariesField.set(optimizer2, new double[1][1]);
                                                                                repairModeField.set(optimizer2, false);
                                                                                List<Double> result2 = optimizer2.getStatisticsSigmaHistory();
                                                                                assertNotNull(result2);
                                                                                
                                                                                // Test case 3: boundaries null, repair mode true
                                                                                CMAESOptimizer optimizer3 = new CMAESOptimizer(10);
                                                                                boundariesField.set(optimizer3, null);
                                                                                repairModeField.set(optimizer3, true);
                                                                                List<Double> result3 = optimizer3.getStatisticsSigmaHistory();
                                                                                assertNotNull(result3);
                                                                                
                                                                                // Test case 4: boundaries not null, repair mode true
                                                                                CMAESOptimizer optimizer4 = new CMAESOptimizer(10);
                                                                                boundariesField.set(optimizer4, new double[1][1]);
                                                                                repairModeField.set(optimizer4, true);
                                                                                List<Double> result4 = optimizer4.getStatisticsSigmaHistory();
                                                                                assertNotNull(result4);
                                                                                
                                                                            } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                fail("Failed to access private fields for testing: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testGetStatisticsSigmaHistoryWithDifferentRepairModes() {
                                                                            // Setup test data
                                                                            List<Double> expectedHistory = new ArrayList<>();
                                                                            expectedHistory.add(1.0);
                                                                            expectedHistory.add(2.0);
                                                                            
                                                                            // Create optimizer with statistics enabled
                                                                            CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                10, // lambda
                                                                                new double[]{1.0}, // inputSigma
                                                                                1000, // maxIterations
                                                                                1e-12, // stopFitness
                                                                                true, // isActiveCMA
                                                                                0, // diagonalOnly
                                                                                1, // checkFeasableCount
                                                                                mock(RandomGenerator.class), // random
                                                                                true // generateStatistics
                                                                            );
                                                                            
                                                                            // Use reflection to set private fields since they're not accessible directly
                                                                            try {
                                                                                // Set statisticsSigmaHistory
                                                                                java.lang.reflect.Field historyField = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                                historyField.setAccessible(true);
                                                                                historyField.set(optimizer, expectedHistory);
                                                                                
                                                                                // Set boundaries
                                                                                java.lang.reflect.Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                boundariesField.setAccessible(true);
                                                                                boundariesField.set(optimizer, new double[][]{{0.0, 1.0}});
                                                                                
                                                                                // Test case 1: boundaries exist and in repair mode (original would return history, mutant would not)
                                                                                java.lang.reflect.Field repairModeField = CMAESOptimizer.class.getDeclaredField("isRepairMode");
                                                                                repairModeField.setAccessible(true);
                                                                                repairModeField.set(optimizer, true);
                                                                                
                                                                                List<Double> result1 = optimizer.getStatisticsSigmaHistory();
                                                                                assertNotNull("History should be returned when boundaries exist and in repair mode", result1);
                                                                                assertEquals(expectedHistory, result1);
                                                                                
                                                                                // Test case 2: boundaries exist and not in repair mode (original would not return history, mutant would)
                                                                                repairModeField.set(optimizer, false);
                                                                                List<Double> result2 = optimizer.getStatisticsSigmaHistory();
                                                                                assertNotNull("History should be returned when boundaries exist and not in repair mode", result2);
                                                                                assertEquals(expectedHistory, result2);
                                                                                
                                                                                // Test case 3: no boundaries (should return history regardless of repair mode)
                                                                                boundariesField.set(optimizer, null);
                                                                                repairModeField.set(optimizer, true);
                                                                                List<Double> result3 = optimizer.getStatisticsSigmaHistory();
                                                                                assertNotNull("History should be returned when no boundaries exist", result3);
                                                                                assertEquals(expectedHistory, result3);
                                                                                
                                                                                repairModeField.set(optimizer, false);
                                                                                List<Double> result4 = optimizer.getStatisticsSigmaHistory();
                                                                                assertNotNull("History should be returned when no boundaries exist", result4);
                                                                                assertEquals(expectedHistory, result4);
                                                                                
                                                                            } catch (Exception e) {
                                                                                fail("Reflection failed: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                    public void testGetStatisticsSigmaHistory17() {
                                                                        // Create test data
                                                                        List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                        
                                                                        // Create instance and set test data using reflection since field is private
                                                                        CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                        try {
                                                                            java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                            field.setAccessible(true);
                                                                            field.set(optimizer, expectedHistory);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to set test data via reflection");
                                                                        }
                                                                        
                                                                        // Test the method
                                                                        List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                        
                                                                        // Verify the results
                                                                        assertNotNull("Returned history should not be null", actualHistory);
                                                                        assertEquals("Returned history size should match", expectedHistory.size(), actualHistory.size());
                                                                        assertEquals("Returned history content should match", expectedHistory, actualHistory);
                                                                        
                                                                        // Additional test for null case
                                                                        try {
                                                                            java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                            field.setAccessible(true);
                                                                            field.set(optimizer, null);
                                                                        } catch (Exception e) {
                                                                            fail("Failed to set null test data via reflection");
                                                                        }
                                                                        
                                                                        assertNull("Should return null when statisticsSigmaHistory is null", 
                                                                                  optimizer.getStatisticsSigmaHistory());
                                                                    }

    @Test
                                                                public void testGetStatisticsSigmaHistory18() {
                                                                    // Create test data
                                                                    List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                                                                    
                                                                    // Create optimizer instance using constructor that enables statistics
                                                                    CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                        0,                          // lambda
                                                                        new double[]{0.1, 0.2},     // inputSigma
                                                                        1000,                       // maxIterations
                                                                        1e-12,                      // stopFitness
                                                                        true,                       // isActiveCMA
                                                                        0,                          // diagonalOnly
                                                                        1,                          // checkFeasableCount
                                                                        null,                       // random
                                                                        true                        // generateStatistics
                                                                    );
                                                                    
                                                                    // Use reflection to set the private field for testing
                                                                    try {
                                                                        java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                        field.setAccessible(true);
                                                                        field.set(optimizer, expectedHistory);
                                                                    } catch (Exception e) {
                                                                        fail("Failed to set statisticsSigmaHistory field");
                                                                    }
                                                                    
                                                                    // Test the method
                                                                    List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                    
                                                                    // Verify the result
                                                                    assertNotNull("Returned history should not be null", actualHistory);
                                                                    assertEquals("History size should match", expectedHistory.size(), actualHistory.size());
                                                                    assertEquals("History content should match", expectedHistory, actualHistory);
                                                                }

    @Test
                                                            public void testGetStatisticsSigmaHistoryReturnsExactList() {
                                                                // Setup
                                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0, 4.0);
                                                                
                                                                // Use reflection to set the private field since it's not exposed otherwise
                                                                try {
                                                                    java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                                    field.setAccessible(true);
                                                                    field.set(optimizer, expectedHistory);
                                                                } catch (Exception e) {
                                                                    fail("Failed to set statisticsSigmaHistory field via reflection");
                                                                }
                                                                
                                                                // Test
                                                                List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                                
                                                                // Verify
                                                                assertSame("The returned list should be the exact same object as the internal field", 
                                                                          expectedHistory, actualHistory);
                                                                assertEquals("The returned list should match exactly what was set", 
                                                                            expectedHistory, actualHistory);
                                                            }

    @Test
                                                public void testGetStatisticsSigmaHistory19() throws Exception {
                                                    // Setup
                                                    double[] inputSigma = new double[]{0.5, 0.5};
                                                    RandomGenerator random = new MersenneTwister(); // Using MersenneTwister instead of JDKRandomGenerator
                                                    CMAESOptimizer optimizer = new CMAESOptimizer(
                                                        10, inputSigma, 1000, 1e-12, true, 0, 
                                                        0, random, true);
                                                    
                                                    // Initialize with a guess that would require repair using reflection
                                                    double[] guess = new double[]{1.5, -0.5};
                                                    Method initializeCMA = CMAESOptimizer.class.getDeclaredMethod("initializeCMA", double[].class);
                                                    initializeCMA.setAccessible(true);
                                                    initializeCMA.invoke(optimizer, guess);
                                                    
                                                    // Perform an optimization step that would update statistics using reflection
                                                    Method doOptimize = CMAESOptimizer.class.getDeclaredMethod("doOptimize");
                                                    doOptimize.setAccessible(true);
                                                    doOptimize.invoke(optimizer);
                                                    
                                                    // Get the statistics history
                                                    List<Double> sigmaHistory = optimizer.getStatisticsSigmaHistory();
                                                    
                                                    // Verify the history is not null and contains expected values
                                                    assertNotNull("Statistics sigma history should not be null", sigmaHistory);
                                                    assertFalse("Statistics sigma history should not be empty", sigmaHistory.isEmpty());
                                                    
                                                    // Verify the values are within expected bounds (repair should constrain them)
                                                    for (Double sigma : sigmaHistory) {
                                                        assertTrue("Sigma value should be positive", sigma > 0);
                                                        assertTrue("Sigma value should be reasonable", sigma < 10);
                                                    }
                                                    
                                                    // Verify the sequence of values makes sense (should generally decrease)
                                                    for (int i = 1; i < sigmaHistory.size(); i++) {
                                                        assertTrue("Sigma should generally decrease", 
                                                            sigmaHistory.get(i) <= sigmaHistory.get(i-1) * 1.1); // Allow small fluctuations
                                                    }
                                                }

    @Test
                                            public void testGetStatisticsSigmaHistoryReturnsDefensiveCopy1() {
                                                // Setup test data
                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                
                                                // Use reflection to set private statisticsSigmaHistory field since there's no public setter
                                                try {
                                                    Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                    field.setAccessible(true);
                                                    
                                                    // Create original list with test data
                                                    List<Double> originalList = new ArrayList<>();
                                                    originalList.add(1.0);
                                                    originalList.add(2.0);
                                                    field.set(optimizer, originalList);
                                                    
                                                    // Get the list via the method
                                                    List<Double> returnedList = optimizer.getStatisticsSigmaHistory();
                                                    
                                                    // Modify the returned list
                                                    returnedList.add(3.0);
                                                    
                                                    // Check if original was modified
                                                    List<Double> currentInternalList = (List<Double>) field.get(optimizer);
                                                    assertEquals("Original list should not be modified", 2, currentInternalList.size());
                                                    assertFalse("Original list should not contain added value", currentInternalList.contains(3.0));
                                                    
                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                    fail("Failed to access statisticsSigmaHistory field via reflection");
                                                }
                                            }

    @Test
                                            public void testGetStatisticsSigmaHistory20() {
                                                // Setup
                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                
                                                // Create a test list with specific values
                                                List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0, 4.0);
                                                
                                                // Use reflection to set the private field since it's not accessible otherwise
                                                try {
                                                    java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                                                    field.setAccessible(true);
                                                    field.set(optimizer, expectedHistory);
                                                } catch (Exception e) {
                                                    fail("Failed to set statisticsSigmaHistory field via reflection");
                                                }
                                                
                                                // Test
                                                List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
                                                
                                                // Verify
                                                assertNotNull("Returned history should not be null", actualHistory);
                                                assertEquals("History size should match", expectedHistory.size(), actualHistory.size());
                                                assertSame("Should return the exact same list object", expectedHistory, actualHistory);
                                                
                                                // Verify contents
                                                for (int i = 0; i < expectedHistory.size(); i++) {
                                                    assertEquals("Element at index " + i + " should match", 
                                                                expectedHistory.get(i), actualHistory.get(i), 0.0001);
                                                }
                                                
                                                // Verify modifying the returned list doesn't affect internal state
                                                actualHistory.set(0, 99.0);
                                                List<Double> modifiedHistory = optimizer.getStatisticsSigmaHistory();
                                                assertEquals("Modifying returned list should modify internal state", 
                                                            Double.valueOf(99.0), modifiedHistory.get(0));
                                            }

    @Test
                        public void testGetStatisticsSigmaHistoryWithDecoding() {
                            // Setup test with known values that would differ between decode and repair
                            double[] inputSigma = {1.0, 2.0, 3.0};
                            org.apache.commons.math3.random.JDKRandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                            CMAESOptimizer optimizer = new CMAESOptimizer(
                                10, 
                                inputSigma, 
                                1000, 
                                1e-12, 
                                true, 
                                0, 
                                1, 
                                random,
                                true  // enable statistics generation
                            );
                            
                            // Force some optimization steps to populate statistics
                            // Using reflection to access protected doOptimize() method
                            try {
                                java.lang.reflect.Method doOptimize = CMAESOptimizer.class.getDeclaredMethod("doOptimize");
                                doOptimize.setAccessible(true);
                                doOptimize.invoke(optimizer);
                            } catch (Exception e) {
                                fail("Failed to invoke doOptimize: " + e.getMessage());
                            }
                            
                            // Get the history and verify it contains expected decoded values
                            List<Double> sigmaHistory = optimizer.getStatisticsSigmaHistory();
                            assertNotNull("Sigma history should not be null", sigmaHistory);
                            assertFalse("Sigma history should not be empty", sigmaHistory.isEmpty());
                            
                            // Verify first entry matches expected decoded value (would differ if repair was used)
                            // Assuming decode would just pass through in this case, while repair might modify
                            double firstSigma = sigmaHistory.get(0);
                            assertEquals("First sigma value should match decoded input", 
                                        inputSigma[0], firstSigma, 1e-10);
                            
                            // Verify trend of sigma values (should decrease during optimization)
                            for (int i = 1; i < sigmaHistory.size(); i++) {
                                assertTrue("Sigma should generally decrease over time", 
                                          sigmaHistory.get(i) <= sigmaHistory.get(i-1));
                            }
                        }

    @Test
            public void testGetStatisticsSigmaHistoryDetectsMutant1() {
                // Setup
                double[] inputSigma = new double[]{0.5};
                org.apache.commons.math3.random.JDKRandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                        10, inputSigma, 100, 1e-12, true, 0, 1, random, true);
                
                // Mock a point to be decoded
                double[] testPoint = new double[]{1.0, 2.0, 3.0};
                
                // Expected behavior: direct decoding
                double[] expectedDecoded = testPoint.clone(); // Direct decoding in CMAESOptimizer just returns the input
                
                // Mutated behavior: repair then decode
                double[] repaired = testPoint.clone(); // Simple repair that doesn't change values
                double[] mutatedDecoded = repaired.clone(); // Decoding just returns the repaired array
                
                // Verify the mutation would produce different results
                assertNotEquals("Mutation should produce different decoded values",
                        expectedDecoded[0], mutatedDecoded[0], 1e-10);
                
                // Now test the actual sigma history collection
                // The sigma history should reflect the direct decoding (original behavior)
                optimizer.optimize(
                        100, // maxEval
                        new org.apache.commons.math3.analysis.MultivariateFunction() {
                            public double value(double[] point) {
                                return 0.0;
                            }
                        },
                        org.apache.commons.math3.optimization.GoalType.MINIMIZE,
                        testPoint); // start point
                
                java.util.List<Double> sigmaHistory = optimizer.getStatisticsSigmaHistory();
                assertNotNull("Sigma history should not be null", sigmaHistory);
                assertFalse("Sigma history should not be empty", sigmaHistory.isEmpty());
                
                // The mutation would cause different sigma values to be stored
                // Here we verify the first entry matches expected behavior
                double firstSigma = sigmaHistory.get(0);
                assertEquals("Sigma history should match original decoding behavior",
                        expectedDecoded[0], firstSigma, 1e-10);
            }

    @Test
            public void testGetStatisticsSigmaHistory21() {
                // Setup test data
                List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
                
                // Create instance and set the field directly via reflection
                CMAESOptimizer optimizer = new CMAESOptimizer();
                try {
                    // Use reflection to set the private field since there's no setter
                    java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                    field.setAccessible(true);
                    field.set(optimizer, expectedHistory);
                    
                    // Also set generateStatistics to true to ensure the history is active
                    field = CMAESOptimizer.class.getDeclaredField("generateStatistics");
                    field.setAccessible(true);
                    field.set(optimizer, true);
                } catch (Exception e) {
                    fail("Failed to set up test via reflection");
                }
                
                // Test the method
                List<Double> result = optimizer.getStatisticsSigmaHistory();
                
                // Verify the result
                assertNotNull("Returned history should not be null", result);
                assertEquals("History size should match", expectedHistory.size(), result.size());
                
                // This assertion would catch the mutant - if there was any processing (like decoding),
                // the values wouldn't be exactly equal
                assertEquals("History contents should match exactly", expectedHistory, result);
                
                // Additional check for individual values
                for (int i = 0; i < expectedHistory.size(); i++) {
                    assertEquals("Element " + i + " should match", 
                                expectedHistory.get(i), 
                                result.get(i), 
                                0.000001);
                }
            }

    @Test
        public void testGetStatisticsSigmaHistoryReturnsActualList2() {
            // Create test data
            List<Double> expectedHistory = Arrays.asList(1.0, 2.0, 3.0);
            
            // Create optimizer instance using constructor that enables statistics
            CMAESOptimizer optimizer = new CMAESOptimizer(
                10,                         // lambda
                new double[]{0.1, 0.2},     // inputSigma
                1000,                      // maxIterations
                1e-12,                     // stopFitness
                true,                       // isActiveCMA
                0,                          // diagonalOnly
                1,                          // checkFeasableCount
                null,                       // random
                true                        // generateStatistics
            );
            
            // Use reflection to set the private statisticsSigmaHistory field for testing
            try {
                java.lang.reflect.Field field = CMAESOptimizer.class.getDeclaredField("statisticsSigmaHistory");
                field.setAccessible(true);
                field.set(optimizer, expectedHistory);
            } catch (Exception e) {
                fail("Failed to set statisticsSigmaHistory field for testing");
            }
            
            // Test the method
            List<Double> actualHistory = optimizer.getStatisticsSigmaHistory();
            
            // Assertions
            assertNotNull("Returned history should not be null", actualHistory);
            assertEquals("Returned history should match expected", expectedHistory, actualHistory);
        }

}
