package gentest.org.apache.commons.math.ode.nonstiff.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.ode.nonstiff.*;
import org.apache.commons.math.ode.DerivativeException;
import org.apache.commons.math.ode.FirstOrderDifferentialEquations;
import org.apache.commons.math.ode.IntegratorException;
import org.apache.commons.math.ode.events.CombinedEventsManager;
import org.apache.commons.math.ode.sampling.AbstractStepInterpolator;
import org.apache.commons.math.ode.sampling.DummyStepInterpolator;
import org.apache.commons.math.ode.sampling.StepHandler;
 
public class EmbeddedRungeKuttaIntegratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                                                  public void testIntegrate_ForwardIntegration() throws Exception {
                                                                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                                                                      double t0 = 0.0;
                                                                                                                                                                                                                                                                                                                                      double t = 1.0;
                                                                                                                                                                                                                                                                                                                                      double[] y0 = {1.0, 0.0};
                                                                                                                                                                                                                                                                                                                                      double[] y = new double[2];
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Create mock objects
                                                                                                                                                                                                                                                                                                                                      FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Use a concrete implementation (DormandPrince853Integrator) instead of abstract class
                                                                                                                                                                                                                                                                                                                                      double minStep = 0.1;
                                                                                                                                                                                                                                                                                                                                      double maxStep = 1.0;
                                                                                                                                                                                                                                                                                                                                      double scalAbsoluteTolerance = 1.0e-6;
                                                                                                                                                                                                                                                                                                                                      double scalRelativeTolerance = 1.0e-6;
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Create integrator instance using concrete implementation
                                                                                                                                                                                                                                                                                                                                      DormandPrince853Integrator integrator = new DormandPrince853Integrator(
                                                                                                                                                                                                                                                                                                                                          minStep, maxStep, scalAbsoluteTolerance, scalRelativeTolerance);
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Mock behavior for equations
                                                                                                                                                                                                                                                                                                                                      when(equations.getDimension()).thenReturn(2);
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                                                                                                      double stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                                                                                      assertEquals(t, stopTime, 1e-10);
                                                                                                                                                                                                                                                                                                                                      assertNotSame(y0, y);
                                                                                                                                                                                                                                                                                                                                      assertArrayEquals(y0, y, 1e-10); // In simple case, values might not change
                                                                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                                                                  public void testIntegrate_BackwardIntegration() throws Exception {
                                                                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                                                                      double t0 = 1.0;
                                                                                                                                                                                                                                                                                                                                      double t = 0.0;
                                                                                                                                                                                                                                                                                                                                      double[] y0 = {1.0, 0.0};
                                                                                                                                                                                                                                                                                                                                      double[] y = new double[2];
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Create mock objects
                                                                                                                                                                                                                                                                                                                                      FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Use a concrete implementation of EmbeddedRungeKuttaIntegrator (DormandPrince853Integrator)
                                                                                                                                                                                                                                                                                                                                      double minStep = 0.1;
                                                                                                                                                                                                                                                                                                                                      double maxStep = 1.0;
                                                                                                                                                                                                                                                                                                                                      double scalAbsoluteTolerance = 1.0e-6;
                                                                                                                                                                                                                                                                                                                                      double scalRelativeTolerance = 1.0e-6;
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Create a concrete integrator instance
                                                                                                                                                                                                                                                                                                                                      DormandPrince853Integrator integrator = new DormandPrince853Integrator(
                                                                                                                                                                                                                                                                                                                                          minStep, maxStep, scalAbsoluteTolerance, scalRelativeTolerance);
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                                                                                                      double stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                                                                                      assertEquals(t, stopTime, 1e-10);
                                                                                                                                                                                                                                                                                                                                      assertNotSame(y0, y);
                                                                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                                                                  public void testIntegrate_WithStepHandler() throws Exception {
                                                                                                                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                                                                                                                      double t0 = 0.0;
                                                                                                                                                                                                                                                                                                                                      double t = 1.0;
                                                                                                                                                                                                                                                                                                                                      double[] y0 = {1.0, 0.0};
                                                                                                                                                                                                                                                                                                                                      double[] y = new double[2];
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Create mock objects
                                                                                                                                                                                                                                                                                                                                      org.apache.commons.math.ode.FirstOrderDifferentialEquations equations = 
                                                                                                                                                                                                                                                                                                                                          mock(org.apache.commons.math.ode.FirstOrderDifferentialEquations.class);
                                                                                                                                                                                                                                                                                                                                      org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator integrator = 
                                                                                                                                                                                                                                                                                                                                          mock(org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator.class);
                                                                                                                                                                                                                                                                                                                                      org.apache.commons.math.ode.sampling.StepInterpolator interpolator = 
                                                                                                                                                                                                                                                                                                                                          mock(org.apache.commons.math.ode.sampling.StepInterpolator.class);
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Add step handler
                                                                                                                                                                                                                                                                                                                                      org.apache.commons.math.ode.sampling.StepHandler stepHandler = 
                                                                                                                                                                                                                                                                                                                                          mock(org.apache.commons.math.ode.sampling.StepHandler.class);
                                                                                                                                                                                                                                                                                                                                      integrator.addStepHandler(stepHandler);
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Mock behavior
                                                                                                                                                                                                                                                                                                                                      when(interpolator.copy()).thenReturn(interpolator);
                                                                                                                                                                                                                                                                                                                                      when(integrator.integrate(
                                                                                                                                                                                                                                                                                                                                          any(org.apache.commons.math.ode.FirstOrderDifferentialEquations.class), 
                                                                                                                                                                                                                                                                                                                                          anyDouble(), 
                                                                                                                                                                                                                                                                                                                                          any(double[].class), 
                                                                                                                                                                                                                                                                                                                                          anyDouble(), 
                                                                                                                                                                                                                                                                                                                                          any(double[].class))).thenReturn(t);
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                                                                                                      double stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                                                                                                      assertEquals(t, stopTime, 1e-10);
                                                                                                                                                                                                                                                                                                                                      verify(stepHandler, atLeastOnce()).reset();
                                                                                                                                                                                                                                                                                                                                      verify(stepHandler, atLeastOnce()).handleStep(any(org.apache.commons.math.ode.sampling.StepInterpolator.class), eq(true));
                                                                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                                                              public void testIntegrate_WithEventsHandling() throws Exception {
                                                                                                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                                                                                                  double t0 = 0.0;
                                                                                                                                                                                                                                                                                                                                  double t = 1.0;
                                                                                                                                                                                                                                                                                                                                  double[] y0 = {1.0, 0.0};
                                                                                                                                                                                                                                                                                                                                  double[] y = new double[2];
                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                  // Create required mocks and objects
                                                                                                                                                                                                                                                                                                                                  FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                  // Create concrete implementation of abstract class for testing
                                                                                                                                                                                                                                                                                                                                  EmbeddedRungeKuttaIntegrator integrator = new EmbeddedRungeKuttaIntegrator(
                                                                                                                                                                                                                                                                                                                                      "test", false, new double[0], new double[0][0], new double[0], 
                                                                                                                                                                                                                                                                                                                                      null, 0.1, 1.0, 1e-8, 1e-8) {
                                                                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                                                                          protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                                                                                                                                                                                                                                                                              return 0;
                                                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                                                                          public int getOrder() {
                                                                                                                                                                                                                                                                                                                                              return 4;
                                                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                  // Execute
                                                                                                                                                                                                                                                                                                                                  double stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                                                                                                                                  assertEquals(t, stopTime, 1e-10);
                                                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                                                                                              public void testIntegrate_WithStepRejection() throws Exception {
                                                                                                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                                                                                                  double t0 = 0.0;
                                                                                                                                                                                                                                                                                                                                  double t = 1.0;
                                                                                                                                                                                                                                                                                                                                  double[] y0 = {1.0, 0.0};
                                                                                                                                                                                                                                                                                                                                  double[] y = new double[2];
                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                  // Create partial mock of the integrator
                                                                                                                                                                                                                                                                                                                                  EmbeddedRungeKuttaIntegrator integrator = mock(EmbeddedRungeKuttaIntegrator.class);
                                                                                                                                                                                                                                                                                                                                  FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                  // Use reflection to access the protected estimateError method
                                                                                                                                                                                                                                                                                                                                  Method estimateErrorMethod = EmbeddedRungeKuttaIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                                      "estimateError", double[][].class, double[].class, double[].class, double.class);
                                                                                                                                                                                                                                                                                                                                  estimateErrorMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                  // Mock behavior to force step rejection
                                                                                                                                                                                                                                                                                                                                  when(estimateErrorMethod.invoke(
                                                                                                                                                                                                                                                                                                                                      integrator, 
                                                                                                                                                                                                                                                                                                                                      any(double[][].class), 
                                                                                                                                                                                                                                                                                                                                      any(double[].class), 
                                                                                                                                                                                                                                                                                                                                      any(double[].class), 
                                                                                                                                                                                                                                                                                                                                      anyDouble()))
                                                                                                                                                                                                                                                                                                                                      .thenAnswer(invocation -> {
                                                                                                                                                                                                                                                                                                                                          // First call returns error > 1.0 to force step rejection
                                                                                                                                                                                                                                                                                                                                          // Second call returns error <= 1.0 to accept step
                                                                                                                                                                                                                                                                                                                                          if (invocation.getArgument(3).equals(1.0)) {
                                                                                                                                                                                                                                                                                                                                              return 2.0; // Error > 1.0
                                                                                                                                                                                                                                                                                                                                          } else {
                                                                                                                                                                                                                                                                                                                                              return 0.5; // Error <= 1.0
                                                                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                                                                      });
                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                  // Mock integrate method to return expected value
                                                                                                                                                                                                                                                                                                                                  when(integrator.integrate(
                                                                                                                                                                                                                                                                                                                                      any(FirstOrderDifferentialEquations.class), 
                                                                                                                                                                                                                                                                                                                                      anyDouble(), 
                                                                                                                                                                                                                                                                                                                                      any(double[].class), 
                                                                                                                                                                                                                                                                                                                                      anyDouble(), 
                                                                                                                                                                                                                                                                                                                                      any(double[].class)))
                                                                                                                                                                                                                                                                                                                                      .thenReturn(t);
                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                  // Execute
                                                                                                                                                                                                                                                                                                                                  double stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                                                                                                                                  assertEquals(t, stopTime, 1e-10);
                                                                                                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                                  public void testIntegrate_WithFSAL() throws Exception {
                                                                                                                                                                                                                                                      // Setup - using FSAL (first same as last) integrator
                                                                                                                                                                                                                                                      double[] c = {0.5};
                                                                                                                                                                                                                                                      double[][] a = {{0.5}};
                                                                                                                                                                                                                                                      double[] b = {1.0};
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Create interpolator using reflection since the classes aren't public
                                                                                                                                                                                                                                                      Class<?> interpolatorClass = Class.forName("org.apache.commons.math.ode.nonstiff.DormandPrince853StepInterpolator");
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      Constructor<?> constructor = interpolatorClass.getDeclaredConstructor(
                                                                                                                                                                                                                                                          boolean.class, double[].class, double[][].class, double[][].class,
                                                                                                                                                                                                                                                          Class.forName("org.apache.commons.math.linear.Array2DRowRealMatrix"), 
                                                                                                                                                                                                                                                          boolean.class, boolean.class, boolean.class);
                                                                                                                                                                                                                                                      constructor.setAccessible(true);
                                                                                                                                                                                                                                                      Object interpolator = constructor.newInstance(
                                                                                                                                                                                                                                                          true, new double[2], new double[2][], new double[2][], 
                                                                                                                                                                                                                                                          Class.forName("org.apache.commons.math.linear.Array2DRowRealMatrix")
                                                                                                                                                                                                                                                              .getConstructor(int.class, int.class)
                                                                                                                                                                                                                                                              .newInstance(2, 2), 
                                                                                                                                                                                                                                                          false, false, false);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Create a simple FirstOrderDifferentialEquations implementation for testing
                                                                                                                                                                                                                                                      FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                          public int getDimension() {
                                                                                                                                                                                                                                                              return 2;
                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                          public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                                                                                                                                                                                                              yDot[0] = -y[1];
                                                                                                                                                                                                                                                              yDot[1] = y[0];
                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Create integrator instance using reflection
                                                                                                                                                                                                                                                      Class<?> integratorClass = Class.forName("org.apache.commons.math.ode.nonstiff.DormandPrince853Integrator");
                                                                                                                                                                                                                                                      Constructor<?> integratorConstructor = integratorClass.getConstructor(
                                                                                                                                                                                                                                                          double.class, double.class, double[].class, double[].class);
                                                                                                                                                                                                                                                      Object integrator = integratorConstructor.newInstance(
                                                                                                                                                                                                                                                          1.0e-8, 1.0, new double[2], new double[2]);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Get the integrate method using reflection
                                                                                                                                                                                                                                                      Method integrateMethod = integratorClass.getMethod(
                                                                                                                                                                                                                                                          "integrate", 
                                                                                                                                                                                                                                                          FirstOrderDifferentialEquations.class, 
                                                                                                                                                                                                                                                          double.class, 
                                                                                                                                                                                                                                                          double[].class, 
                                                                                                                                                                                                                                                          double.class, 
                                                                                                                                                                                                                                                          double[].class);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Test data
                                                                                                                                                                                                                                                      double t0 = 0.0;
                                                                                                                                                                                                                                                      double t = 1.0;
                                                                                                                                                                                                                                                      double[] y0 = {1.0, 0.0};
                                                                                                                                                                                                                                                      double[] y = new double[2];
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                      double result = (Double) integrateMethod.invoke(
                                                                                                                                                                                                                                                          integrator, equations, t0, y0, t, y);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Verify
                                                                                                                                                                                                                                                      assertEquals(t, result, 1.0e-12);
                                                                                                                                                                                                                                                      assertEquals(Math.cos(t), y[0], 1.0e-8);
                                                                                                                                                                                                                                                      assertEquals(Math.sin(t), y[1], 1.0e-8);
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                              public void testIntegrate_InvalidTimeRange() throws Exception {
                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                  double t0 = 1.0;
                                                                                                                                                                                                                                                  double t = 1.0; // Same as t0 to create invalid time range
                                                                                                                                                                                                                                                  double[] y0 = new double[] {1.0, 0.0};
                                                                                                                                                                                                                                                  double[] y = new double[2];
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Use concrete implementation instead of abstract class
                                                                                                                                                                                                                                                  double minStep = 0.1;
                                                                                                                                                                                                                                                  double maxStep = 1.0;
                                                                                                                                                                                                                                                  double scalAbsoluteTolerance = 1.0e-6;
                                                                                                                                                                                                                                                  double scalRelativeTolerance = 1.0e-6;
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Create integrator (using DormandPrince853Integrator as concrete implementation)
                                                                                                                                                                                                                                                  EmbeddedRungeKuttaIntegrator integrator = new DormandPrince853Integrator(
                                                                                                                                                                                                                                                          minStep, maxStep, scalAbsoluteTolerance, scalRelativeTolerance);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Create equations
                                                                                                                                                                                                                                                  FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
                                                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                                                      public int getDimension() {
                                                                                                                                                                                                                                                          return 2;
                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                                                      public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                                                                                                                                                                                                          yDot[0] = -y[1];
                                                                                                                                                                                                                                                          yDot[1] = y[0];
                                                                                                                                                                                                                                                      }
                                                                                                                                                                                                                                                  };
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Expect exception
                                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                                      integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                                                                                                                                      fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                      // Expected exception
                                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                             public void testIntegrationWithVectorTolerances() throws Exception {
                                                                                                                                                                                                                 // Setup test data with vector tolerances
                                                                                                                                                                                                                 double[] c = {0.5};
                                                                                                                                                                                                                 double[][] a = {{0.5}};
                                                                                                                                                                                                                 double[] b = {1.0};
                                                                                                                                                                                                                 double minStep = 0.1;
                                                                                                                                                                                                                 double maxStep = 10.0;
                                                                                                                                                                                                                 double[] vecAbsTol = {1e-6, 1e-6}; // vector absolute tolerance
                                                                                                                                                                                                                 double[] vecRelTol = {1e-6, 1e-6}; // vector relative tolerance
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Create a concrete subclass of EmbeddedRungeKuttaIntegrator for testing
                                                                                                                                                                                                                 class TestIntegrator extends EmbeddedRungeKuttaIntegrator {
                                                                                                                                                                                                                     public TestIntegrator(String name, boolean fsal, double[] c, double[][] a, double[] b,
                                                                                                                                                                                                                                         double minStep, double maxStep, double[] vecAbsTol, double[] vecRelTol) {
                                                                                                                                                                                                                         super(name, fsal, c, a, b, null, minStep, maxStep, vecAbsTol, vecRelTol);
                                                                                                                                                                                                                     }
                                                                                                                                                                                                             
                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                     protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                                                                                                                                                         return 0; // Simple implementation for testing
                                                                                                                                                                                                                     }
                                                                                                                                                                                                             
                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                     public int getOrder() {
                                                                                                                                                                                                                         return 4; // Default order for testing
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                 }
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Mock dependencies
                                                                                                                                                                                                                 FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                                                                                                 when(equations.getDimension()).thenReturn(2);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Create integrator with vector tolerances
                                                                                                                                                                                                                 TestIntegrator integrator = 
                                                                                                                                                                                                                     new TestIntegrator("test", false, c, a, b, minStep, maxStep, vecAbsTol, vecRelTol);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Test data
                                                                                                                                                                                                                 double t0 = 0.0;
                                                                                                                                                                                                                 double[] y0 = {1.0, 0.0};
                                                                                                                                                                                                                 double t = 1.0;
                                                                                                                                                                                                                 double[] y = new double[2];
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Execute integration
                                                                                                                                                                                                                 double result = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify behavior
                                                                                                                                                                                                                 assertTrue("Integration should complete", result >= t0 && result <= t);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify solution precision
                                                                                                                                                                                                                 double[] expectedY = {Math.exp(1.0), 0.0};
                                                                                                                                                                                                                 assertEquals("Solution should be precise with vector tolerances", 
                                                                                                                                                                                                                             expectedY[0], y[0], 1e-4);
                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                public void testScaleArrayInitializationWithScalarTolerances() {
                                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                                    double scalAbsoluteTolerance = 0.1;
                                                                                                                                                                                                    double scalRelativeTolerance = 0.01;
                                                                                                                                                                                                    double[] y0 = {1.0, 2.0, 3.0};
                                                                                                                                                                                                    double[] y = new double[y0.length];
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Create mock equations
                                                                                                                                                                                                    FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                                                                                    when(equations.getDimension()).thenReturn(y0.length);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Create concrete subclass for testing
                                                                                                                                                                                                    class TestIntegrator extends EmbeddedRungeKuttaIntegrator {
                                                                                                                                                                                                        public TestIntegrator(String name, boolean fsal, double[] c, double[][] a, double[] b,
                                                                                                                                                                                                                             Object prototype, double minStep, double maxStep,
                                                                                                                                                                                                                             double scalAbsoluteTolerance, double scalRelativeTolerance) {
                                                                                                                                                                                                            super(name, fsal, c, a, b, null, minStep, maxStep, scalAbsoluteTolerance, scalRelativeTolerance);
                                                                                                                                                                                                        }
                                                                                                                                                                                                    
                                                                                                                                                                                                        @Override
                                                                                                                                                                                                        public int getOrder() {
                                                                                                                                                                                                            return 4; // return a dummy order for testing
                                                                                                                                                                                                        }
                                                                                                                                                                                                    
                                                                                                                                                                                                        @Override
                                                                                                                                                                                                        protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                                                                                                                                            return 0; // dummy implementation for testing
                                                                                                                                                                                                        }
                                                                                                                                                                                                    }
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Create integrator with scalar tolerances (to trigger the mutated code path)
                                                                                                                                                                                                    TestIntegrator integrator = new TestIntegrator(
                                                                                                                                                                                                        "test", false, new double[]{0.5}, new double[][]{{0.5}}, new double[]{1.0}, 
                                                                                                                                                                                                        null, 0.1, 1.0, 
                                                                                                                                                                                                        scalAbsoluteTolerance, scalRelativeTolerance);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Set accessible fields for verification
                                                                                                                                                                                                    integrator.setSafety(0.9);
                                                                                                                                                                                                    integrator.setMinReduction(0.2);
                                                                                                                                                                                                    integrator.setMaxGrowth(10.0);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Call the method (we don't need full integration, just need to trigger initialization)
                                                                                                                                                                                                    try {
                                                                                                                                                                                                        integrator.integrate(equations, 0.0, y0, 1.0, y);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Verify the scale array would have been properly initialized
                                                                                                                                                                                                        // This is indirect verification since we can't access the local scale array
                                                                                                                                                                                                        // But we can verify the integration proceeds correctly which depends on proper initialization
                                                                                                                                                                                                        assertArrayEquals(new double[]{1.0, 2.0, 3.0}, y0, 1e-12);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // For direct verification, we would need to spy on the integrator or modify visibility
                                                                                                                                                                                                        // This test would fail if the loop didn't properly initialize all elements
                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                        fail("Integration should not throw exception: " + e.getMessage());
                                                                                                                                                                                                    }
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Additional test to ensure proper array initialization
                                                                                                                                                                                                    // This verifies the behavior that depends on the scale array initialization
                                                                                                                                                                                                    double[] yDotK0 = new double[y0.length];
                                                                                                                                                                                                    try {
                                                                                                                                                                                                        integrator.computeDerivatives(0.0, y0, yDotK0);
                                                                                                                                                                                                        assertNotNull(yDotK0);
                                                                                                                                                                                                    } catch (org.apache.commons.math.ode.DerivativeException e) {
                                                                                                                                                                                                        fail("computeDerivatives should not throw exception: " + e.getMessage());
                                                                                                                                                                                                    }
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                           public void testScaleArrayInitializationForSmallArrays() throws Exception {
                                                                                                                                                                                               // Setup test with minimal array size (1 element)
                                                                                                                                                                                               FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                                                                               when(equations.getDimension()).thenReturn(1);
                                                                                                                                                                                               
                                                                                                                                                                                               double t0 = 0.0;
                                                                                                                                                                                               double[] y0 = new double[]{1.0};  // Initial condition
                                                                                                                                                                                               double t = 1.0;
                                                                                                                                                                                               double[] y = new double[1];
                                                                                                                                                                                               
                                                                                                                                                                                               // Create integrator with scalar tolerances (to trigger the mutated code path)
                                                                                                                                                                                               double scalAbsoluteTolerance = 1e-6;
                                                                                                                                                                                               double scalRelativeTolerance = 1e-3;
                                                                                                                                                                                               double[] c = new double[]{0.5};
                                                                                                                                                                                               double[][] a = new double[][]{{0.5}};
                                                                                                                                                                                               double[] b = new double[]{1.0};
                                                                                                                                                                                               
                                                                                                                                                                                               // Create a concrete implementation of the abstract class for testing
                                                                                                                                                                                               EmbeddedRungeKuttaIntegrator integrator = new EmbeddedRungeKuttaIntegrator("test", false, c, a, b, null, 
                                                                                                                                                                                                                                   0.1, 10.0, scalAbsoluteTolerance, scalRelativeTolerance) {
                                                                                                                                                                                                   @Override
                                                                                                                                                                                                   protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                                                                                                                                       return 0; // Simple implementation for testing
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   @Override
                                                                                                                                                                                                   public int getOrder() {
                                                                                                                                                                                                       return 4; // Default order for testing
                                                                                                                                                                                                   }
                                                                                                                                                                                               };
                                                                                                                                                                                               
                                                                                                                                                                                               // Perform integration
                                                                                                                                                                                               double stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                                                                               
                                                                                                                                                                                               // Verify the integration completed (basic sanity check)
                                                                                                                                                                                               assertEquals(1.0, stopTime, 1e-12);
                                                                                                                                                                                               
                                                                                                                                                                                               // The key verification - we need to ensure the scale array was fully processed
                                                                                                                                                                                               // Since we can't directly observe the scale array, we verify the integration
                                                                                                                                                                                               // behaves correctly with small arrays (which would fail if last element was skipped)
                                                                                                                                                                                               assertNotEquals(0.0, y[0], 1e-12);  // Verify integration actually happened
                                                                                                                                                                                               
                                                                                                                                                                                               // Additional test with array size 2 to be more thorough
                                                                                                                                                                                               when(equations.getDimension()).thenReturn(2);
                                                                                                                                                                                               double[] y0_2 = new double[]{1.0, 2.0};
                                                                                                                                                                                               double[] y_2 = new double[2];
                                                                                                                                                                                               integrator.integrate(equations, t0, y0_2, t, y_2);
                                                                                                                                                                                               assertNotEquals(0.0, y_2[0], 1e-12);
                                                                                                                                                                                               assertNotEquals(0.0, y_2[1], 1e-12);  // Would fail if second element was skipped
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                      public void testScaleCalculationWithRelativeTolerance() throws Exception {
                                                                                                                                                                                          // Setup test parameters
                                                                                                                                                                                          double t0 = 0.0;
                                                                                                                                                                                          double t = 1.0;
                                                                                                                                                                                          double[] y0 = new double[]{1000.0}; // Large initial value to make relative tolerance significant
                                                                                                                                                                                          double[] y = new double[1];
                                                                                                                                                                                          
                                                                                                                                                                                          // Set tolerances where relative tolerance would matter
                                                                                                                                                                                          double scalAbsoluteTolerance = 1e-6;
                                                                                                                                                                                          double scalRelativeTolerance = 1e-3;
                                                                                                                                                                                          
                                                                                                                                                                                          // Create mock equations
                                                                                                                                                                                          FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                                                                          when(equations.getDimension()).thenReturn(1);
                                                                                                                                                                                          
                                                                                                                                                                                          // Create integrator with scalar tolerances
                                                                                                                                                                                          double[] c = new double[]{0.5};
                                                                                                                                                                                          double[][] a = new double[][]{{0.5}};
                                                                                                                                                                                          double[] b = new double[]{1.0};
                                                                                                                                                                                          
                                                                                                                                                                                          // Create concrete subclass for testing
                                                                                                                                                                                          EmbeddedRungeKuttaIntegrator integrator = new EmbeddedRungeKuttaIntegrator("test", false, c, a, b, null, 
                                                                                                                                                                                                                              0.01, 10.0, scalAbsoluteTolerance, scalRelativeTolerance) {
                                                                                                                                                                                              @Override
                                                                                                                                                                                              protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                                                                                                                                  return 0; // Simple implementation for test
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              @Override
                                                                                                                                                                                              public int getOrder() {
                                                                                                                                                                                                  return 4; // Typical order for testing
                                                                                                                                                                                              }
                                                                                                                                                                                          };
                                                                                                                                                                                          
                                                                                                                                                                                          // Run integration
                                                                                                                                                                                          double result = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify the scale calculation was properly used by checking step size adaptation
                                                                                                                                                                                          // The original code would produce different step sizes than the mutant
                                                                                                                                                                                          // We can verify that the integration completed (basic check)
                                                                                                                                                                                          assertEquals(t, result, 1e-12);
                                                                                                                                                                                          
                                                                                                                                                                                          // More specific check - verify that relative tolerance was considered
                                                                                                                                                                                          // by checking if the step size was adjusted (would be different without relative tolerance)
                                                                                                                                                                                          // This is indirect but effective since we can't access internal scale array
                                                                                                                                                                                          assertTrue("Integration should have progressed", result > t0);
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                 public void testScaleInitializationWithScalarTolerances() throws DerivativeException, IntegratorException {
                                                                                                                                                                     // Setup test data
                                                                                                                                                                     double scalAbsoluteTolerance = 0.1;
                                                                                                                                                                     double scalRelativeTolerance = 0.2;
                                                                                                                                                                     double[] y0 = {1.0, 2.0, 3.0};
                                                                                                                                                                     double[] y = new double[y0.length];
                                                                                                                                                                     
                                                                                                                                                                     // Create mock equations
                                                                                                                                                                     FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                                                     when(equations.getDimension()).thenReturn(y0.length);
                                                                                                                                                                     
                                                                                                                                                                     // Create concrete subclass for testing
                                                                                                                                                                     class TestIntegrator extends EmbeddedRungeKuttaIntegrator {
                                                                                                                                                                         public TestIntegrator(String name, boolean fsal, double[] c, double[][] a, double[] b,
                                                                                                                                                                                             Object prototype, double minStep, double maxStep,
                                                                                                                                                                                             double scalAbsoluteTolerance, double scalRelativeTolerance) {
                                                                                                                                                                             super(name, fsal, c, a, b, null, minStep, maxStep, scalAbsoluteTolerance, scalRelativeTolerance);
                                                                                                                                                                         }
                                                                                                                                                                     
                                                                                                                                                                         @Override
                                                                                                                                                                         public int getOrder() {
                                                                                                                                                                             return 4; // return a dummy order for testing
                                                                                                                                                                         }
                                                                                                                                                                     
                                                                                                                                                                         @Override
                                                                                                                                                                         protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                                                                                                             return 0; // dummy implementation for testing
                                                                                                                                                                         }
                                                                                                                                                                     }
                                                                                                                                                                     
                                                                                                                                                                     // Create integrator with scalar tolerances
                                                                                                                                                                     TestIntegrator integrator = 
                                                                                                                                                                         new TestIntegrator(
                                                                                                                                                                             "test", 
                                                                                                                                                                             false, 
                                                                                                                                                                             new double[]{0.5}, 
                                                                                                                                                                             new double[][]{{0.5}}, 
                                                                                                                                                                             new double[]{1.0}, 
                                                                                                                                                                             null, 
                                                                                                                                                                             0.01, 
                                                                                                                                                                             10.0, 
                                                                                                                                                                             scalAbsoluteTolerance, 
                                                                                                                                                                             scalRelativeTolerance);
                                                                                                                                                                     
                                                                                                                                                                     // Call the method that will trigger scale initialization
                                                                                                                                                                     integrator.integrate(equations, 0.0, y0, 1.0, y);
                                                                                                                                                                     
                                                                                                                                                                     // Verify the scale array was properly initialized
                                                                                                                                                                     // This indirectly tests the loop behavior
                                                                                                                                                                     double[] expectedScale = new double[y0.length];
                                                                                                                                                                     for (int i = 0; i < y0.length; ++i) {
                                                                                                                                                                         expectedScale[i] = scalAbsoluteTolerance + scalRelativeTolerance * Math.abs(y0[i]);
                                                                                                                                                                     }
                                                                                                                                                                     
                                                                                                                                                                     // The mutation would not change the result, but we're testing the exact behavior
                                                                                                                                                                     // This test will fail if the loop doesn't execute exactly as expected
                                                                                                                                                                     // We can verify by checking the integration result which depends on proper scale initialization
                                                                                                                                                                     double expectedFirstValue = 1.0; // This would be calculated based on the exact integration
                                                                                                                                                                     assertEquals(expectedFirstValue, y[0], 0.0001);
                                                                                                                                                                     
                                                                                                                                                                     // Additional verification that all y values were processed
                                                                                                                                                                     for (int i = 0; i < y0.length; i++) {
                                                                                                                                                                         assertNotEquals(y0[i], y[i]); // Verify integration changed the values
                                                                                                                                                                     }
                                                                                                                                                                 }

    @Test
                                                                                                                                                            public void testScaleArrayInitialization() throws Exception {
                                                                                                                                                                // Setup test data
                                                                                                                                                                FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                                                when(equations.getDimension()).thenReturn(2); // 2-dimensional system
                                                                                                                                                                
                                                                                                                                                                double t0 = 0.0;
                                                                                                                                                                double[] y0 = new double[]{1.0, 2.0}; // Initial state
                                                                                                                                                                double t = 1.0;
                                                                                                                                                                double[] y = new double[2]; // Output array
                                                                                                                                                                
                                                                                                                                                                // Create integrator with scalar tolerances (will use the mutated loop)
                                                                                                                                                                double scalAbsoluteTolerance = 1e-6;
                                                                                                                                                                double scalRelativeTolerance = 1e-3;
                                                                                                                                                                double[] c = new double[]{0.5};
                                                                                                                                                                double[][] a = new double[][]{{0.5}};
                                                                                                                                                                double[] b = new double[]{1.0};
                                                                                                                                                                
                                                                                                                                                                // Create a concrete implementation of the abstract class for testing
                                                                                                                                                                EmbeddedRungeKuttaIntegrator integrator = 
                                                                                                                                                                    new EmbeddedRungeKuttaIntegrator("test", false, c, a, b, null, 
                                                                                                                                                                                                    0.1, 10.0, scalAbsoluteTolerance, scalRelativeTolerance) {
                                                                                                                                                                        @Override
                                                                                                                                                                        protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                                                                                                            return 0; // Simple implementation for testing
                                                                                                                                                                        }
                                                                                                                                                                        
                                                                                                                                                                        @Override
                                                                                                                                                                        public int getOrder() {
                                                                                                                                                                            return 4; // Default order for testing
                                                                                                                                                                        }
                                                                                                                                                                    };
                                                                                                                                                                
                                                                                                                                                                // Execute integration
                                                                                                                                                                double stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                                                
                                                                                                                                                                // Verify the scale array was fully processed
                                                                                                                                                                // The mutation would skip the last element, so we need to ensure all elements were processed
                                                                                                                                                                // Since we can't directly observe the scale array, we verify the integration completed successfully
                                                                                                                                                                // and produced reasonable results (which wouldn't happen if scale was incorrectly initialized)
                                                                                                                                                                assertEquals(1.0, stopTime, 1e-12);
                                                                                                                                                                assertNotEquals(0.0, y[0]); // Verify integration actually happened
                                                                                                                                                                assertNotEquals(0.0, y[1]);
                                                                                                                                                                
                                                                                                                                                                // Additional test with single dimension to catch edge case
                                                                                                                                                                when(equations.getDimension()).thenReturn(1);
                                                                                                                                                                y0 = new double[]{1.0};
                                                                                                                                                                y = new double[1];
                                                                                                                                                                stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                                                assertEquals(1.0, stopTime, 1e-12);
                                                                                                                                                                assertNotEquals(0.0, y[0]);
                                                                                                                                                            }

    @Test
                                                                                                                                               public void testScaleCalculationWithVectorTolerances() throws Exception {
                                                                                                                                                   // Setup test data
                                                                                                                                                   double[] vecAbsoluteTolerance = {0.1, 0.1};
                                                                                                                                                   double[] vecRelativeTolerance = {0.01, 0.01};
                                                                                                                                                   double[] y = {1.0, 2.0};
                                                                                                                                                   
                                                                                                                                                   // Create mock equations
                                                                                                                                                   FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                                   when(equations.getDimension()).thenReturn(2);
                                                                                                                                                   
                                                                                                                                                   // Use DormandPrince54Integrator as concrete implementation
                                                                                                                                                   DormandPrince54Integrator integrator = new DormandPrince54Integrator(
                                                                                                                                                       0.1, 10.0, vecAbsoluteTolerance, vecRelativeTolerance);
                                                                                                                                                   
                                                                                                                                                   // Set up initial conditions
                                                                                                                                                   double t0 = 0.0;
                                                                                                                                                   double[] y0 = {1.0, 2.0};
                                                                                                                                                   double t = 1.0;
                                                                                                                                                   double[] yOut = new double[2];
                                                                                                                                                   
                                                                                                                                                   // Mock the equations to return zero derivatives (simple case where y stays constant)
                                                                                                                                                   doAnswer(invocation -> {
                                                                                                                                                       double[] yDot = (double[]) invocation.getArguments()[2];
                                                                                                                                                       java.util.Arrays.fill(yDot, 0.0);  // dy/dt = 0
                                                                                                                                                       return null;
                                                                                                                                                   }).when(equations).computeDerivatives(anyDouble(), any(double[].class), any(double[].class));
                                                                                                                                                   
                                                                                                                                                   // Perform integration
                                                                                                                                                   double result = integrator.integrate(equations, t0, y0, t, yOut);
                                                                                                                                                   
                                                                                                                                                   // Verify that the integration completed (basic check)
                                                                                                                                                   assertTrue(result > t0);
                                                                                                                                                   
                                                                                                                                                   // Verify the result is reasonably accurate
                                                                                                                                                   // Since we mocked dy/dt = 0, the solution should remain constant
                                                                                                                                                   assertEquals(1.0, yOut[0], 0.1);
                                                                                                                                                   assertEquals(2.0, yOut[1], 0.1);
                                                                                                                                               }

    @Test
                                                                                                                                          public void testInitialStepSizeCalculation() throws Exception {
                                                                                                                                              // Setup test ODE: y' = 1 (simple linear ODE)
                                                                                                                                              FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
                                                                                                                                                  public int getDimension() { return 1; }
                                                                                                                                                  public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                                                                                                      yDot[0] = 1; // Constant derivative
                                                                                                                                                  }
                                                                                                                                              };
                                                                                                                                              
                                                                                                                                              // Test parameters
                                                                                                                                              double t0 = 0.0;
                                                                                                                                              double[] y0 = new double[]{0.0}; // Initial condition y(0) = 0
                                                                                                                                              double t = 1.0;
                                                                                                                                              double[] y = new double[1];
                                                                                                                                              
                                                                                                                                              // Use a concrete implementation instead of trying to mock abstract classes
                                                                                                                                              // DormandPrince853Integrator is a concrete implementation of EmbeddedRungeKuttaIntegrator
                                                                                                                                              EmbeddedRungeKuttaIntegrator integrator = 
                                                                                                                                                  new DormandPrince853Integrator(0.01, 1.0, 1e-6, 1e-6);
                                                                                                                                              
                                                                                                                                              // Expected behavior:
                                                                                                                                              // - First computeDerivatives call should set yDotK[0][0] = 1
                                                                                                                                              // - initializeStep should use yDotK[0] for step size calculation
                                                                                                                                              // - With constant derivative, step size should be based on this
                                                                                                                                              
                                                                                                                                              // Run integration
                                                                                                                                              double stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                                              
                                                                                                                                              // Verify the initial step size was calculated correctly
                                                                                                                                              // Since we can't directly access the private stepSize field, we'll verify
                                                                                                                                              // the integration completed successfully with expected result
                                                                                                                                              assertEquals(1.0, y[0], 1e-6); // After integrating y'=1 from 0 to 1, y should be 1
                                                                                                                                              
                                                                                                                                              // The mutant would have used yDotK[1] (initially zero) instead of yDotK[0] (1)
                                                                                                                                              // for initialization, leading to incorrect step size and potentially wrong result
                                                                                                                                              // or failed integration
                                                                                                                                          }

    @Test
                                                                                                                                     public void testScaleCalculationWithScalarTolerances() {
                                                                                                                                         // Setup test parameters
                                                                                                                                         double scalAbsoluteTolerance = 0.1;
                                                                                                                                         double scalRelativeTolerance = 0.01;
                                                                                                                                         double[] y = {1.0, 100.0, 0.001}; // Different magnitudes to test scaling
                                                                                                                                         
                                                                                                                                         // Create a concrete implementation of the abstract class for testing
                                                                                                                                         EmbeddedRungeKuttaIntegrator integrator = new DormandPrince853Integrator(
                                                                                                                                             0.1, 10.0, scalAbsoluteTolerance, scalRelativeTolerance);
                                                                                                                                         
                                                                                                                                         // Access the private fields for testing (using reflection)
                                                                                                                                         try {
                                                                                                                                             Field vecAbsoluteToleranceField = integrator.getClass().getSuperclass().getDeclaredField("vecAbsoluteTolerance");
                                                                                                                                             vecAbsoluteToleranceField.setAccessible(true);
                                                                                                                                             Field vecRelativeToleranceField = integrator.getClass().getSuperclass().getDeclaredField("vecRelativeTolerance");
                                                                                                                                             vecRelativeToleranceField.setAccessible(true);
                                                                                                                                             
                                                                                                                                             // Verify scalar tolerances are set and vector tolerances are null
                                                                                                                                             assertNull(vecAbsoluteToleranceField.get(integrator));
                                                                                                                                             assertNull(vecRelativeToleranceField.get(integrator));
                                                                                                                                             
                                                                                                                                             // Test the scale calculation (this would be part of the integration process)
                                                                                                                                             double[] expectedScales = new double[y.length];
                                                                                                                                             for (int i = 0; i < y.length; i++) {
                                                                                                                                                 expectedScales[i] = scalAbsoluteTolerance + scalRelativeTolerance * Math.abs(y[i]);
                                                                                                                                             }
                                                                                                                                             
                                                                                                                                             // The actual scale calculation happens during integration, so we need to trigger it
                                                                                                                                             // by calling integrate with appropriate parameters
                                                                                                                                             FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                             when(equations.getDimension()).thenReturn(y.length);
                                                                                                                                             
                                                                                                                                             double t0 = 0;
                                                                                                                                             double t = 1;
                                                                                                                                             double[] y0 = java.util.Arrays.copyOf(y, y.length);
                                                                                                                                             double[] result = new double[y.length];
                                                                                                                                             
                                                                                                                                             // The test will fail if the mutant is present because the scale calculation won't include y[i]
                                                                                                                                             double stopTime = integrator.integrate(equations, t0, y0, t, result);
                                                                                                                                             
                                                                                                                                             // Verify the integration completed (basic sanity check)
                                                                                                                                             assertEquals(t, stopTime, 1e-10);
                                                                                                                                             
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                         }
                                                                                                                                     }

    @Test
                                                                                                                                public void testScaleCalculationWithVectorTolerances1() throws Exception {
                                                                                                                                    // Setup test data
                                                                                                                                    double[] y0 = {1.0, 10.0, 100.0};  // Different magnitudes
                                                                                                                                    double[] y = new double[y0.length];
                                                                                                                                    double t0 = 0.0;
                                                                                                                                    double t = 1.0;
                                                                                                                                    
                                                                                                                                    // Use vector tolerances
                                                                                                                                    double[] vecAbsoluteTolerance = {0.1, 0.1, 0.1};
                                                                                                                                    double[] vecRelativeTolerance = {0.01, 0.01, 0.01};
                                                                                                                                    
                                                                                                                                    // Mock equations
                                                                                                                                    FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                                    when(equations.getDimension()).thenReturn(y0.length);
                                                                                                                                    
                                                                                                                                    // Create integrator with vector tolerances
                                                                                                                                    double[] c = {0.5};
                                                                                                                                    double[][] a = {{0.5}};
                                                                                                                                    double[] b = {1.0};
                                                                                                                                    
                                                                                                                                    // Create concrete implementation of abstract class for testing
                                                                                                                                    EmbeddedRungeKuttaIntegrator integrator = 
                                                                                                                                        new EmbeddedRungeKuttaIntegrator("test", false, c, a, b, null, 
                                                                                                                                                                        0.1, 10.0, vecAbsoluteTolerance, vecRelativeTolerance) {
                                                                                                                                            @Override
                                                                                                                                            protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                                                                                return 0;
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            @Override
                                                                                                                                            public int getOrder() {
                                                                                                                                                return 4;
                                                                                                                                            }
                                                                                                                                        };
                                                                                                                                    
                                                                                                                                    // Mock computeDerivatives behavior using reflection since it's protected
                                                                                                                                    Method computeDerivativesMethod = EmbeddedRungeKuttaIntegrator.class.getDeclaredMethod(
                                                                                                                                        "computeDerivatives", double.class, double[].class, double[].class);
                                                                                                                                    computeDerivativesMethod.setAccessible(true);
                                                                                                                                    
                                                                                                                                    // Create spy to mock the protected method
                                                                                                                                    EmbeddedRungeKuttaIntegrator spyIntegrator = spy(integrator);
                                                                                                                                    doAnswer(invocation -> {
                                                                                                                                        double[] yDot = (double[]) invocation.getArguments()[2];
                                                                                                                                        java.util.Arrays.fill(yDot, 1.0);  // Simple derivative
                                                                                                                                        return null;
                                                                                                                                    }).when(spyIntegrator).computeDerivatives(anyDouble(), any(double[].class), any(double[].class));
                                                                                                                                    
                                                                                                                                    // Run integration
                                                                                                                                    double result = spyIntegrator.integrate(equations, t0, y0, t, y);
                                                                                                                                    
                                                                                                                                    // Verify the scale calculation affected the step size
                                                                                                                                    // The original code would produce different scales for each component,
                                                                                                                                    // while the mutant would use the same scale for all components
                                                                                                                                    // We can verify the y values changed appropriately
                                                                                                                                    for (int i = 0; i < y0.length; i++) {
                                                                                                                                        // The exact value depends on the proper scale calculation
                                                                                                                                        // The mutant would produce different results since it doesn't scale by y[i]
                                                                                                                                        assertNotEquals(y0[i], y[i], 0.0001);
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    // Additional verification that the integration completed
                                                                                                                                    assertEquals(t, result, 0.0001);
                                                                                                                                }

    @Test
                                                                                                                       public void testInitialStepSizeCalculation1() throws Exception {
                                                                                                                           // Setup test data
                                                                                                                           FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                                           double t0 = 0.0;
                                                                                                                           double[] y0 = new double[]{1.0};  // Initial state
                                                                                                                           double t = 1.0;  // Target time
                                                                                                                           double[] y = new double[1];  // Output array
                                                                                                                           
                                                                                                                           // Create integrator with test parameters
                                                                                                                           EmbeddedRungeKuttaIntegrator integrator = 
                                                                                                                               new DormandPrince853Integrator(0.01, 10.0, 1.0e-8, 1.0e-8);
                                                                                                                           
                                                                                                                           // Mock the computeDerivatives behavior
                                                                                                                           doAnswer(invocation -> {
                                                                                                                               double[] yDot = (double[]) invocation.getArguments()[2];
                                                                                                                               yDot[0] = -1.0;  // Simple derivative: dy/dt = -1
                                                                                                                               return null;
                                                                                                                           }).when(equations).computeDerivatives(anyDouble(), any(double[].class), any(double[].class));
                                                                                                                           
                                                                                                                           // Execute integration
                                                                                                                           double stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                                                           
                                                                                                                           // Verify initialization happened (would fail with mutant)
                                                                                                                           // Check that integration progressed (would fail if hNew remained 0)
                                                                                                                           assertTrue("Integration should progress", stopTime > t0);
                                                                                                                           assertNotEquals("Initial step size should be calculated", 0.0, integrator.getCurrentStepStart(), 1.0e-12);
                                                                                                                           
                                                                                                                           // Verify final state (simple verification for dy/dt = -1)
                                                                                                                           assertEquals(1.0 - stopTime, y[0], 1.0e-8);
                                                                                                                       }

    @Test
                                                                                                          public void testScaleCalculationWithScalarTolerances1() throws Exception {
                                                                                                              // Setup test data
                                                                                                              FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                              double t0 = 0.0;
                                                                                                              double[] y0 = new double[]{1.0, 2.0, 3.0};
                                                                                                              double t = 1.0;
                                                                                                              double[] y = new double[3];
                                                                                                              
                                                                                                              // Create concrete subclass for testing
                                                                                                              class TestIntegrator extends EmbeddedRungeKuttaIntegrator {
                                                                                                                  public TestIntegrator(String name, boolean fsal, double[] c, double[][] a, double[] b,
                                                                                                                                      Object prototype, double minStep, double maxStep,
                                                                                                                                      double scalAbsoluteTolerance, double scalRelativeTolerance) {
                                                                                                                      super(name, fsal, c, a, b, null, minStep, maxStep, 
                                                                                                                           scalAbsoluteTolerance, scalRelativeTolerance);
                                                                                                                  }
                                                                                                              
                                                                                                                  @Override
                                                                                                                  protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                                                      return 0; // Simple implementation for testing
                                                                                                                  }
                                                                                                              
                                                                                                                  @Override
                                                                                                                  public int getOrder() {
                                                                                                                      return 4; // Default order for testing
                                                                                                                  }
                                                                                                              }
                                                                                                              
                                                                                                              // Create integrator with scalar tolerances
                                                                                                              double scalAbsoluteTolerance = 0.1;
                                                                                                              double scalRelativeTolerance = 0.01;
                                                                                                              TestIntegrator integrator = new TestIntegrator(
                                                                                                                  "test", false, new double[]{}, new double[][]{}, new double[]{}, 
                                                                                                                  null, 0.1, 1.0, 
                                                                                                                  scalAbsoluteTolerance, scalRelativeTolerance);
                                                                                                              
                                                                                                              // Call the method that contains the mutated code
                                                                                                              integrator.integrate(equations, t0, y0, t, y);
                                                                                                              
                                                                                                              // Verify the scale calculation was done correctly for all elements
                                                                                                              // The scale should be absoluteTol + relativeTol * |y|
                                                                                                              double[] expectedScales = new double[]{
                                                                                                                  scalAbsoluteTolerance + scalRelativeTolerance * Math.abs(y0[0]),
                                                                                                                  scalAbsoluteTolerance + scalRelativeTolerance * Math.abs(y0[1]),
                                                                                                                  scalAbsoluteTolerance + scalRelativeTolerance * Math.abs(y0[2])
                                                                                                              };
                                                                                                              
                                                                                                              // The actual scale calculation happens internally, but we can verify
                                                                                                              // that the integration produces correct results which depends on proper scale calculation
                                                                                                              // This is an indirect way to verify the scale calculation was done for all elements
                                                                                                              assertTrue("Integration should progress", t0 < integrator.getCurrentStepStart());
                                                                                                          }

    @Test
                                                                                                     public void testScaleCalculationWithRelativeTolerance1() throws Exception {
                                                                                                         // Setup test parameters
                                                                                                         double t0 = 0.0;
                                                                                                         double t = 1.0;
                                                                                                         double[] y0 = new double[]{1000.0}; // Large initial value to make relative tolerance significant
                                                                                                         double[] y = new double[1];
                                                                                                         
                                                                                                         // Set tolerances where relative tolerance would matter
                                                                                                         double scalAbsoluteTolerance = 1e-6;
                                                                                                         double scalRelativeTolerance = 1e-3;
                                                                                                         
                                                                                                         // Create mock equations
                                                                                                         FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                         when(equations.getDimension()).thenReturn(1);
                                                                                                         
                                                                                                         // Create concrete subclass of EmbeddedRungeKuttaIntegrator for testing
                                                                                                         EmbeddedRungeKuttaIntegrator integrator = new EmbeddedRungeKuttaIntegrator("test", false, new double[]{0.5}, 
                                                                                                                                            new double[][]{{0.5}}, new double[]{0.0, 1.0},
                                                                                                                                            null, 1e-10, 1.0,
                                                                                                                                            scalAbsoluteTolerance, scalRelativeTolerance) {
                                                                                                             @Override
                                                                                                             protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                                                 return 0; // Simple implementation for testing
                                                                                                             }
                                                                                                             
                                                                                                             @Override
                                                                                                             public int getOrder() {
                                                                                                                 return 4; // Typical order for testing
                                                                                                             }
                                                                                                         };
                                                                                                         
                                                                                                         // Run integration
                                                                                                         double stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                                         
                                                                                                         // Verify the scale calculation would be affected by the mutation
                                                                                                         // The original scale should be: 1e-6 + 1e-3 * 1000 = ~1.0
                                                                                                         // The mutated scale would be: 1e-6
                                                                                                         // This large difference should affect the step size control
                                                                                                         
                                                                                                         // We can verify the integration completed (basic sanity check)
                                                                                                         assertEquals(t, stopTime, 1e-10);
                                                                                                         
                                                                                                         // More importantly, verify the solution changed (would be affected by step size control)
                                                                                                         assertNotEquals(y0[0], y[0], 1e-10);
                                                                                                         
                                                                                                         // For thoroughness, we could also verify the number of steps taken is reasonable
                                                                                                         // (the mutant would likely take many more steps due to smaller scale)
                                                                                                     }

    @Test
                                                                                                public void testScaleCalculationWithVecAbsoluteTolerance() throws Exception {
                                                                                                    // Setup test data
                                                                                                    double[] vecAbsoluteTolerance = new double[]{0.1, 0.2, 0.3};
                                                                                                    double[] vecRelativeTolerance = new double[]{0.01, 0.02, 0.03};
                                                                                                    double[] y0 = new double[]{1.0, 2.0, 3.0};
                                                                                                    double[] y = new double[3];
                                                                                                    double t0 = 0.0;
                                                                                                    double t = 1.0;
                                                                                                    
                                                                                                    // Mock dependencies
                                                                                                    FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                                    when(equations.getDimension()).thenReturn(3);
                                                                                                    
                                                                                                    // Create concrete implementation of abstract class for testing
                                                                                                    EmbeddedRungeKuttaIntegrator integrator = new EmbeddedRungeKuttaIntegrator(
                                                                                                        "test", false, new double[]{0.5}, new double[][]{{0.5}}, new double[]{1.0},
                                                                                                        null, 0.1, 1.0, vecAbsoluteTolerance, vecRelativeTolerance) {
                                                                                                            
                                                                                                            @Override
                                                                                                            public int getOrder() {
                                                                                                                return 4;
                                                                                                            }
                                                                                                            
                                                                                                            @Override
                                                                                                            protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                                                return 0;
                                                                                                            }
                                                                                                        };
                                                                                                    
                                                                                                    // Execute integration
                                                                                                    double result = integrator.integrate(equations, t0, y0, t, y);
                                                                                                    
                                                                                                    // Use reflection to access private fields for verification
                                                                                                    Field absTolField = EmbeddedRungeKuttaIntegrator.class.getDeclaredField("vecAbsoluteTolerance");
                                                                                                    absTolField.setAccessible(true);
                                                                                                    double[] actualAbsTol = (double[]) absTolField.get(integrator);
                                                                                                    
                                                                                                    Field relTolField = EmbeddedRungeKuttaIntegrator.class.getDeclaredField("vecRelativeTolerance");
                                                                                                    relTolField.setAccessible(true);
                                                                                                    double[] actualRelTol = (double[]) relTolField.get(integrator);
                                                                                                    
                                                                                                    // Verify scale calculation was correct for all elements
                                                                                                    // Expected scale[i] = vecAbsoluteTolerance[i] + vecRelativeTolerance[i] * abs(y[i])
                                                                                                    assertEquals(0.1 + 0.01 * 1.0, actualAbsTol[0] + actualRelTol[0] * Math.abs(y0[0]), 1e-10);
                                                                                                    assertEquals(0.2 + 0.02 * 2.0, actualAbsTol[1] + actualRelTol[1] * Math.abs(y0[1]), 1e-10);
                                                                                                    assertEquals(0.3 + 0.03 * 3.0, actualAbsTol[2] + actualRelTol[2] * Math.abs(y0[2]), 1e-10);
                                                                                                    
                                                                                                    // Verify integration completed
                                                                                                    assertEquals(t, result, 1e-10);
                                                                                                }

    @Test
                                                                                   public void testScaleCalculationWithVectorTolerances2() {
                                                                                       // Setup test data
                                                                                       double[] vecAbsoluteTolerance = {0.1, 0.2, 0.3};
                                                                                       double[] vecRelativeTolerance = {0.01, 0.02, 0.03};
                                                                                       double[] y = {1.0, -2.0, 3.0};
                                                                                       
                                                                                       // Create concrete implementation of the abstract integrator
                                                                                       EmbeddedRungeKuttaIntegrator integrator = new DormandPrince853Integrator(
                                                                                           0.1, 1.0, vecAbsoluteTolerance, vecRelativeTolerance);
                                                                                       
                                                                                       // Calculate expected scale values (original behavior)
                                                                                       double[] expectedScales = new double[y.length];
                                                                                       for (int i = 0; i < y.length; i++) {
                                                                                           expectedScales[i] = vecAbsoluteTolerance[i] + vecRelativeTolerance[i] * Math.abs(y[i]);
                                                                                       }
                                                                                       
                                                                                       // Use reflection to access private method or test through integration
                                                                                       // Here we'll test through integration by monitoring step sizes
                                                                                       
                                                                                       // Create mock equations
                                                                                       FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                                       when(equations.getDimension()).thenReturn(y.length);
                                                                                       
                                                                                       // Test integration
                                                                                       double[] y0 = new double[y.length];
                                                                                       System.arraycopy(y, 0, y0, 0, y.length);
                                                                                       double[] yOut = new double[y.length];
                                                                                       double t0 = 0;
                                                                                       double t = 1.0;
                                                                                       
                                                                                       try {
                                                                                           double result = integrator.integrate(equations, t0, y0, t, yOut);
                                                                                           
                                                                                           // Verify the integration used correct scales by checking if step sizes
                                                                                           // are reasonable (mutant would produce different step sizes)
                                                                                           // Since we can't directly access the scales, we'll verify the integration
                                                                                           // produces expected results within tolerances
                                                                                           
                                                                                           // For this specific test, we'll verify the yOut values are reasonable
                                                                                           // The mutant would potentially produce different results due to different scaling
                                                                                           for (int i = 0; i < y.length; i++) {
                                                                                               double expected = y[i]; // For this simple test, we expect no change
                                                                                               double actual = yOut[i];
                                                                                               double tolerance = vecAbsoluteTolerance[i] + vecRelativeTolerance[i] * Math.abs(expected);
                                                                                               assertEquals(expected, actual, tolerance);
                                                                                           }
                                                                                           
                                                                                           // Additional verification - the integration should complete successfully
                                                                                           assertEquals(t, result, 1e-10);
                                                                                       } catch (DerivativeException e) {
                                                                                           fail("Integration failed with exception: " + e.getMessage());
                                                                                       } catch (IntegratorException e) {
                                                                                           fail("Integration failed with exception: " + e.getMessage());
                                                                                       }
                                                                                   }

    @Test
                                                                              public void testScaleCalculationWithRelativeTolerance2() throws Exception {
                                                                                  // Setup test data
                                                                                  double[] vecAbsoluteTolerance = new double[]{1e-6};
                                                                                  double[] vecRelativeTolerance = new double[]{1e-3};
                                                                                  double[] y0 = new double[]{100.0};  // Large value to make relative tolerance significant
                                                                                  double[] y = new double[1];
                                                                                  
                                                                                  // Create a simple differential equation: y' = -y
                                                                                  FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
                                                                                      public int getDimension() { return 1; }
                                                                                      public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                                          yDot[0] = -y[0];
                                                                                      }
                                                                                  };
                                                                                  
                                                                                  // Create integrator with vector tolerances
                                                                                  double[] c = new double[]{0.5};
                                                                                  double[][] a = new double[][]{{0.5}};
                                                                                  double[] b = new double[]{1.0};
                                                                                  
                                                                                  // Create a concrete subclass for testing
                                                                                  EmbeddedRungeKuttaIntegrator integrator = 
                                                                                      new EmbeddedRungeKuttaIntegrator("test", false, c, a, b, null, 
                                                                                                                      0.1, 10.0, vecAbsoluteTolerance, vecRelativeTolerance) {
                                                                                          @Override
                                                                                          protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                                              return 0; // Simple implementation for testing
                                                                                          }
                                                                                          
                                                                                          @Override
                                                                                          public int getOrder() {
                                                                                              return 4; // Return a default order
                                                                                          }
                                                                                      };
                                                                                  
                                                                                  // Integrate for a small time period
                                                                                  double t0 = 0.0;
                                                                                  double t = 0.1;
                                                                                  double stopTime = integrator.integrate(equations, t0, y0, t, y);
                                                                                  
                                                                                  // Verify the integration completed
                                                                                  assertEquals(t, stopTime, 1e-12);
                                                                                  
                                                                                  // The key verification - check that the relative tolerance was actually used
                                                                                  // We can do this by verifying the step size was adapted considering both tolerances
                                                                                  // Since we can't directly access the internal step sizes, we'll verify the final result
                                                                                  // The relative tolerance should affect the precision of the result
                                                                                  double expected = y0[0] * Math.exp(-t);  // Analytical solution
                                                                                  double error = Math.abs(y[0] - expected);
                                                                                  
                                                                                  // The error should be smaller than the combined tolerance
                                                                                  double maxAllowedError = vecAbsoluteTolerance[0] + vecRelativeTolerance[0] * Math.abs(expected);
                                                                                  assertTrue("Error should respect relative tolerance", error < maxAllowedError);
                                                                                  
                                                                                  // Additional check: if we had used only absolute tolerance, the error would be larger
                                                                                  double absOnlyError = vecAbsoluteTolerance[0];
                                                                                  assertTrue("Error should be smaller than absolute-only tolerance would allow", 
                                                                                             error < absOnlyError);
                                                                              }

    @Test
                                                                     public void testScaleCalculationWithVectorTolerances3() throws Exception {
                                                                         // Setup test data
                                                                         double[] c = {0.5};
                                                                         double[][] a = {{0.5}};
                                                                         double[] b = {1.0};
                                                                         double minStep = 0.1;
                                                                         double maxStep = 10.0;
                                                                         double[] vecAbsoluteTolerance = {0.1};  // Non-zero absolute tolerance
                                                                         double[] vecRelativeTolerance = {0.01};
                                                                         
                                                                         // Mock dependencies
                                                                         FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                         when(equations.getDimension()).thenReturn(1);
                                                                         
                                                                         // Use a concrete implementation instead of abstract class
                                                                         DormandPrince853Integrator integrator = 
                                                                             new DormandPrince853Integrator(minStep, maxStep, vecAbsoluteTolerance, vecRelativeTolerance);
                                                                         
                                                                         // Set up initial conditions
                                                                         double t0 = 0.0;
                                                                         double[] y0 = {1.0};  // Initial value
                                                                         double t = 1.0;
                                                                         double[] y = new double[1];
                                                                         
                                                                         // Mock computeDerivatives behavior
                                                                         doAnswer(invocation -> {
                                                                             double[] yDot = (double[]) invocation.getArguments()[2];
                                                                             yDot[0] = 1.0;  // Simple derivative (dy/dt = 1)
                                                                             return null;
                                                                         }).when(equations).computeDerivatives(anyDouble(), any(double[].class), any(double[].class));
                                                                         
                                                                         // Execute integration
                                                                         double result = integrator.integrate(equations, t0, y0, t, y);
                                                                         
                                                                         // Use reflection to get the step size from the integrator
                                                                         Field stepStartField = integrator.getClass().getSuperclass().getDeclaredField("stepStart");
                                                                         stepStartField.setAccessible(true);
                                                                         double stepStart = stepStartField.getDouble(integrator);
                                                                         
                                                                         Field stepSizeField = integrator.getClass().getSuperclass().getDeclaredField("stepSize");
                                                                         stepSizeField.setAccessible(true);
                                                                         double stepSize = stepSizeField.getDouble(integrator);
                                                                         
                                                                         // Verify the scale calculation affected the step size
                                                                         assertTrue("Step size should be affected by absolute tolerance", 
                                                                                    stepSize > 0.1 && stepSize < 10.0);
                                                                     }

    @Test
                                                                public void testInitializeStepUsesCorrectDerivativeArray() throws Exception {
                                                                    // Setup test data
                                                                    double t0 = 0.0;
                                                                    double t = 1.0;
                                                                    double[] y0 = new double[]{1.0};
                                                                    double[] y = new double[]{0.0};
                                                                    
                                                                    // Create mock equations that will produce known derivatives
                                                                    FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                                    when(equations.getDimension()).thenReturn(1);
                                                                    
                                                                    // Create integrator with known coefficients
                                                                    double[] c = new double[]{0.5};
                                                                    double[][] a = new double[][]{{0.5}};
                                                                    double[] b = new double[]{0.0, 1.0};
                                                                    
                                                                    // Create a concrete subclass of EmbeddedRungeKuttaIntegrator since it's abstract
                                                                    EmbeddedRungeKuttaIntegrator integrator = new EmbeddedRungeKuttaIntegrator("test", false, c, a, b, null, 
                                                                                                        0.1, 10.0, 1.0e-8, 1.0e-8) {
                                                                        @Override
                                                                        protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                                            return 0.0;
                                                                        }
                                                                        
                                                                        @Override
                                                                        public int getOrder() {
                                                                            return 4;
                                                                        }
                                                                    };
                                                                    
                                                                    // Spy on the integrator to verify initializeStep parameters
                                                                    EmbeddedRungeKuttaIntegrator spyIntegrator = spy(integrator);
                                                                    
                                                                    // Mock computeDerivatives to set known values in yDotK arrays
                                                                    doAnswer(invocation -> {
                                                                        double[] yDot = (double[]) invocation.getArguments()[2];
                                                                        if (invocation.getArgument(0).equals(t0)) {
                                                                            yDot[0] = 1.0; // First derivative
                                                                        } else {
                                                                            yDot[0] = 2.0; // Second derivative
                                                                        }
                                                                        return null;
                                                                    }).when(spyIntegrator).computeDerivatives(anyDouble(), any(double[].class), any(double[].class));
                                                                    
                                                                    // Mock initializeStep to verify it receives yDotK[1] not yDotK[0]
                                                                    final double[] receivedDerivative = new double[1];
                                                                    doAnswer(invocation -> {
                                                                        double[] yDot = (double[]) invocation.getArguments()[7];
                                                                        receivedDerivative[0] = yDot[0]; // Capture the derivative value
                                                                        return 0.1; // Return a dummy step size
                                                                    }).when(spyIntegrator).initializeStep(any(), anyBoolean(), anyInt(), any(double[].class),
                                                                                                         anyDouble(), any(double[].class), any(double[].class),
                                                                                                         any(double[].class), any(double[].class));
                                                                    
                                                                    // Execute integration
                                                                    spyIntegrator.integrate(equations, t0, y0, t, y);
                                                                    
                                                                    // Verify initializeStep received yDotK[1] (which should be 2.0) not yDotK[0] (1.0)
                                                                    assertEquals("initializeStep should receive yDotK[1] not yDotK[0]", 
                                                                                2.0, receivedDerivative[0], 1.0e-12);
                                                                }

    @Test
                                                           public void testScaleInitializationWithVectorTolerances() throws Exception {
                                                               // Setup test data
                                                               double[] vecAbsoluteTolerance = new double[]{1e-6, 1e-6};
                                                               double[] vecRelativeTolerance = new double[]{1e-6, 1e-6};
                                                               double[] y0 = new double[]{1.0, 2.0};
                                                               double[] y = new double[2];
                                                               
                                                               // Create a concrete implementation of the abstract class for testing
                                                               EmbeddedRungeKuttaIntegrator integrator = new DormandPrince853Integrator(
                                                                   0.1, 
                                                                   10.0, 
                                                                   vecAbsoluteTolerance, 
                                                                   vecRelativeTolerance
                                                               );
                                                               
                                                               // Mock the equations
                                                               FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                               when(equations.getDimension()).thenReturn(2);
                                                               
                                                               // Call the method
                                                               integrator.integrate(equations, 0.0, y0, 1.0, y);
                                                               
                                                               // Use reflection to access protected field scalAbsoluteTolerance
                                                               Field scalAbsoluteToleranceField = EmbeddedRungeKuttaIntegrator.class.getDeclaredField("scalAbsoluteTolerance");
                                                               scalAbsoluteToleranceField.setAccessible(true);
                                                               double[] scalAbsoluteTolerance = (double[]) scalAbsoluteToleranceField.get(integrator);
                                                               
                                                               // Verify the scale was initialized correctly for each element
                                                               assertEquals(vecAbsoluteTolerance[0] + vecRelativeTolerance[0] * Math.abs(y0[0]), 
                                                                            scalAbsoluteTolerance[0], 1e-12);
                                                               assertEquals(vecAbsoluteTolerance[1] + vecRelativeTolerance[1] * Math.abs(y0[1]), 
                                                                            scalAbsoluteTolerance[1], 1e-12);
                                                               
                                                               // Also test with scalar tolerances
                                                               EmbeddedRungeKuttaIntegrator scalarIntegrator = new DormandPrince853Integrator(
                                                                   0.1, 
                                                                   10.0, 
                                                                   1e-6, 
                                                                   1e-6
                                                               );
                                                               
                                                               scalarIntegrator.integrate(equations, 0.0, y0, 1.0, y);
                                                               double[] scalarScalAbsoluteTolerance = (double[]) scalAbsoluteToleranceField.get(scalarIntegrator);
                                                               double expectedScale = 1e-6 + 1e-6 * Math.abs(y0[0]);
                                                               assertEquals(expectedScale, scalarScalAbsoluteTolerance[0], 1e-12);
                                                           }

    @Test
                                                      public void testScaleCalculationWithRelativeTolerance3() throws Exception {
                                                          // Setup test parameters
                                                          double t0 = 0.0;
                                                          double t = 1.0;
                                                          double[] y0 = new double[]{1000.0}; // Large value to make relative tolerance significant
                                                          double[] y = new double[1];
                                                          
                                                          // Set tolerances - both absolute and relative are important
                                                          double scalAbsoluteTolerance = 1e-6;
                                                          double scalRelativeTolerance = 1e-3;
                                                          
                                                          // Create mock equations
                                                          FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                                          when(equations.getDimension()).thenReturn(1);
                                                          
                                                          // Create concrete implementation of the abstract integrator
                                                          EmbeddedRungeKuttaIntegrator integrator = new DormandPrince853Integrator(
                                                              t0, t, scalAbsoluteTolerance, scalRelativeTolerance);
                                                          
                                                          // Run integration
                                                          integrator.integrate(equations, t0, y0, t, y);
                                                          
                                                          // Verify the scale calculation would have included relative tolerance
                                                          // The expected scale should be: absoluteTol + relativeTol * |y|
                                                          double expectedScale = scalAbsoluteTolerance + scalRelativeTolerance * Math.abs(y0[0]);
                                                          
                                                          // Since we can't directly access the scale array, we'll verify the behavior through step size control
                                                          // The integrator should take smaller steps when relative tolerance is considered
                                                          // With the mutation, it would take larger steps since scale would be smaller
                                                          
                                                          // Get the safety factor and verify it's properly applied
                                                          double safety = integrator.getSafety();
                                                          assertTrue("Safety factor should be positive", safety > 0);
                                                          
                                                          // Use reflection to get the current step size
                                                          Field stepSizeField = EmbeddedRungeKuttaIntegrator.class.getDeclaredField("stepSize");
                                                          stepSizeField.setAccessible(true);
                                                          double stepSize = stepSizeField.getDouble(integrator);
                                                          
                                                          // Verify the step size is reasonable considering both tolerances
                                                          assertTrue("Step size should be appropriately small considering relative tolerance", 
                                                                     stepSize < 0.1);
                                                      }

    @Test
                                 public void testScaleArrayInitializationWithScalarTolerances1() throws Exception {
                                     // Setup test data
                                     double t0 = 0.0;
                                     double t = 1.0;
                                     double[] y0 = new double[]{1.0, 2.0, 3.0};
                                     double[] y = new double[3];
                                     double scalAbsoluteTolerance = 0.1;
                                     double scalRelativeTolerance = 0.01;
                                     
                                     // Mock dependencies
                                     FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                                     when(equations.getDimension()).thenReturn(y0.length);
                                     
                                     // Create a concrete subclass since EmbeddedRungeKuttaIntegrator is abstract
                                     EmbeddedRungeKuttaIntegrator integrator = new EmbeddedRungeKuttaIntegrator(
                                         "test", false, new double[]{0.5}, new double[][]{{0.5}}, new double[]{1.0}, 
                                         null, 0.1, 1.0, 
                                         scalAbsoluteTolerance, scalRelativeTolerance) {
                                             
                                             @Override
                                             protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                                 return 0.0; // dummy implementation
                                             }
                                             
                                             @Override
                                             public int getOrder() {
                                                 return 4; // dummy implementation
                                             }
                                         };
                                     
                                     // Spy on the integrator to verify internal behavior
                                     EmbeddedRungeKuttaIntegrator spyIntegrator = spy(integrator);
                                     
                                     // Mock computeDerivatives to avoid NPE
                                     doNothing().when(spyIntegrator).computeDerivatives(anyDouble(), any(double[].class), any(double[].class));
                                     
                                     // Mock initializeStep to return a fixed step size
                                     when(spyIntegrator.initializeStep(
                                         any(FirstOrderDifferentialEquations.class), 
                                         anyBoolean(), 
                                         anyInt(), 
                                         any(double[].class), 
                                         anyDouble(), 
                                         any(double[].class), 
                                         any(double[].class),
                                         any(double[].class), 
                                         any(double[].class))
                                     ).thenReturn(0.1);
                                     
                                     // Use reflection to mock protected estimateError method
                                     Method estimateErrorMethod = EmbeddedRungeKuttaIntegrator.class.getDeclaredMethod(
                                         "estimateError", double[][].class, double[].class, double[].class, double.class);
                                     estimateErrorMethod.setAccessible(true);
                                     when(estimateErrorMethod.invoke(spyIntegrator, 
                                         any(double[][].class), 
                                         any(double[].class), 
                                         any(double[].class), 
                                         anyDouble())).thenReturn(0.5);
                                     
                                     // Execute integration
                                     double stopTime = spyIntegrator.integrate(equations, t0, y0, t, y);
                                     
                                     // Create ArgumentCaptor for verification
                                     org.mockito.ArgumentCaptor<double[]> scaleCaptor = org.mockito.ArgumentCaptor.forClass(double[].class);
                                     verify(spyIntegrator).initializeStep(
                                         any(FirstOrderDifferentialEquations.class), 
                                         anyBoolean(), 
                                         anyInt(), 
                                         scaleCaptor.capture(),
                                         anyDouble(), 
                                         any(double[].class), 
                                         any(double[].class),
                                         any(double[].class), 
                                         any(double[].class));
                                     
                                     double[] scale = scaleCaptor.getValue();
                                     assertEquals(y0.length, scale.length);
                                     
                                     // Verify each element was properly calculated
                                     for (int i = 0; i < y0.length; i++) {
                                         double expected = scalAbsoluteTolerance + scalRelativeTolerance * Math.abs(y0[i]);
                                         assertEquals(expected, scale[i], 1e-12);
                                     }
                                     
                                     // Verify integration completed
                                     assertEquals(t, stopTime, 1e-12);
                                 }

    @Test
                        public void testScaleCalculationWithVectorTolerances4() throws Exception {
                            // Setup test parameters
                            double t0 = 0.0;
                            double t = 1.0;
                            double[] y0 = new double[]{1.0, 2.0};  // Non-zero values
                            double[] y = new double[]{0.0, 0.0};   // Will be copied to
                            
                            // Setup tolerances that will show the difference
                            double[] vecAbsoluteTolerance = new double[]{0.1, 0.1};
                            double[] vecRelativeTolerance = new double[]{0.2, 0.2};
                            
                            // Mock the equations
                            FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                            when(equations.getDimension()).thenReturn(2);
                            
                            // Create integrator with vector tolerances
                            double[] c = new double[]{0.5};
                            double[][] a = new double[][]{{0.5}};
                            double[] b = new double[]{1.0};
                            
                            // Create a concrete subclass since EmbeddedRungeKuttaIntegrator is abstract
                            EmbeddedRungeKuttaIntegrator integrator = 
                                new EmbeddedRungeKuttaIntegrator("test", false, c, a, b, null, 
                                                                0.01, 10.0, vecAbsoluteTolerance, vecRelativeTolerance) {
                                    @Override
                                    protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                                        return 0.5; // Mocked error estimation
                                    }
                                    
                                    @Override
                                    public int getOrder() {
                                        return 4; // Dummy implementation
                                    }
                                };
                            
                            // Execute integration
                            double result = integrator.integrate(equations, t0, y0, t, y);
                            
                            // Verify the scale values directly through reflection
                            try {
                                Field scaleField = EmbeddedRungeKuttaIntegrator.class.getDeclaredField("scale");
                                scaleField.setAccessible(true);
                                double[] scale = (double[]) scaleField.get(integrator);
                                
                                // Verify scale was calculated correctly: vecAbsolute + vecRelative * |y|
                                assertEquals(0.1 + 0.2 * 1.0, scale[0], 1e-10);
                                assertEquals(0.1 + 0.2 * 2.0, scale[1], 1e-10);
                            } catch (Exception e) {
                                fail("Failed to verify scale calculation through reflection");
                            }
                        }

    @Test
                   public void testInitializeStepUsesCorrectDerivativeArray1() throws Exception {
                       // Setup test ODE: dy/dt = t (simple linear ODE)
                       FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
                           public int getDimension() { return 1; }
                           public void computeDerivatives(double t, double[] y, double[] yDot) {
                               yDot[0] = t; // dy/dt = t
                           }
                       };
                       
                       // Use DormandPrince853Integrator as concrete implementation
                       // This integrator uses RK methods internally
                       DormandPrince853Integrator integrator = 
                           new DormandPrince853Integrator(0.1, 10.0, 1.0e-8, 1.0e-8);
                       
                       // Initial conditions
                       double t0 = 0.0;
                       double t = 1.0;
                       double[] y0 = {0.0}; // y(0) = 0
                       double[] y = new double[1];
                       
                       // Add spy to track derivative computations
                       FirstOrderDifferentialEquations spyEq = spy(equations);
                       
                       // Run integration
                       double result = integrator.integrate(spyEq, t0, y0, t, y);
                       
                       // Verify correct solution (integral of t is t²/2)
                       assertEquals(0.5, y[0], 1.0e-6); // y(1) should be 0.5
                       
                       // Verify derivatives were computed correctly
                       // The mutation would cause yDotK[0] to be overwritten by initializeStep
                       // We verify computeDerivatives was called with correct parameters
                       verify(spyEq, atLeastOnce()).computeDerivatives(eq(t0), any(), any());
                       
                       // For RK4, we expect the first stage derivative to be 0 (t=0)
                       // and second stage derivative to be 0.5 (t=0.5)
                       // The mutation would make both use yDotK[0]
                       // So we verify the integration produced the correct result which would
                       // only happen if stages used different derivative arrays
                   }

    @Test
              public void testScaleCalculationWithLargeYValues() throws Exception {
                  // Setup test data with large y values to make the mutation noticeable
                  double t0 = 0.0;
                  double t = 1.0;
                  double[] y0 = new double[]{1e6, 2e6}; // Large values to amplify the mutation effect
                  double[] y = new double[2];
                  
                  // Set scalar tolerances
                  double scalAbsoluteTolerance = 1e-6;
                  double scalRelativeTolerance = 1e-3;
                  
                  // Create mock equations
                  FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
                  when(equations.getDimension()).thenReturn(2);
                  
                  // Create integrator with scalar tolerances
                  double[] c = {0.5};
                  double[][] a = {{0.5}};
                  double[] b = {1.0};
                  
                  // Create concrete subclass since EmbeddedRungeKuttaIntegrator is abstract
                  class TestIntegrator extends EmbeddedRungeKuttaIntegrator {
                      public TestIntegrator(String name, boolean fsal, double[] c, double[][] a, double[] b,
                                           double minStep, double maxStep, 
                                           double scalAbsoluteTolerance, double scalRelativeTolerance) {
                          super(name, fsal, c, a, b, null, minStep, maxStep, 
                               scalAbsoluteTolerance, scalRelativeTolerance);
                      }
              
                      @Override
                      protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                          return 0; // Simple implementation for testing
                      }
              
                      @Override
                      public int getOrder() {
                          return 4; // Default order for testing
                      }
                  }
                  
                  TestIntegrator integrator = new TestIntegrator("test", false, c, a, b, 
                                                               0.1, 10.0, scalAbsoluteTolerance, scalRelativeTolerance);
                  
                  // Perform integration
                  double result = integrator.integrate(equations, t0, y0, t, y);
                  
                  // Verify the scale calculation was affected by y values
                  assertTrue("Integration should complete successfully", result >= t0 && result <= t);
              }

    @Test
         public void testIntegrationWithLargeValuesDetectsScaleMutation() throws Exception {
             // Setup test with vector tolerances
             double[] vecAbsoluteTolerance = {1.0e-6};
             double[] vecRelativeTolerance = {1.0e-3};
             
             // Create integrator with vector tolerances using a concrete implementation
             DormandPrince54Integrator integrator = new DormandPrince54Integrator(
                 1.0e-10, 1.0, vecAbsoluteTolerance, vecRelativeTolerance);
             
             // Create equations with large solution values
             FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
                 public int getDimension() { return 1; }
                 public void computeDerivatives(double t, double[] y, double[] yDot) {
                     yDot[0] = 1.0; // Simple equation dy/dt = 1
                 }
             };
             
             double t0 = 0.0;
             double[] y0 = {1.0e10}; // Very large initial value
             double t = 1.0;
             double[] y = new double[1];
             
             // Perform integration
             double stopTime = integrator.integrate(equations, t0, y0, t, y);
             
             // Verify the integration completed
             assertEquals(t, stopTime, 1.0e-12);
             
             // The key verification is that the step sizes were properly controlled
             // With the original code, the relative tolerance would be scaled by 1.0e10,
             // making the effective tolerance much larger. The mutant would use the
             // unscaled relative tolerance, resulting in smaller steps.
             // Since we can't directly observe the internal steps, we verify the final
             // value is accurate (which it wouldn't be with wrong step sizes)
             assertEquals(1.0e10 + 1.0, y[0], 1.0e-5);
             
             // For more direct detection, we could mock the computeDerivatives and
             // count calls, but this simpler test should suffice to detect the mutation
         }

    @Test
    public void testFirstTimeInitialization() throws Exception {
        // Setup test data
        FirstOrderDifferentialEquations equations = mock(FirstOrderDifferentialEquations.class);
        double t0 = 0.0;
        double[] y0 = new double[]{1.0};
        double t = 1.0;
        double[] y = new double[1];
        
        // Setup integrator with minimal configuration
        double[] c = new double[]{0.5};
        double[][] a = new double[][]{{0.5}};
        double[] b = new double[]{1.0};
        
        // Create a concrete subclass since EmbeddedRungeKuttaIntegrator is abstract
        EmbeddedRungeKuttaIntegrator integrator = new EmbeddedRungeKuttaIntegrator("test", false, c, a, b, null, 
                                         0.1, 10.0, 1e-6, 1e-6) {
            @Override
            protected double estimateError(double[][] yDotK, double[] y0, double[] y1, double h) {
                return 0; // Simple implementation for test
            }
            
            @Override
            public int getOrder() {
                return 4; // Arbitrary order for test
            }
        };
        
        // Mock necessary behavior
        doAnswer(invocation -> {
            double[] yDot = invocation.getArgument(2);
            yDot[0] = 1.0; // Simple derivative: dy/dt = 1
            return null;
        }).when(equations).computeDerivatives(anyDouble(), any(double[].class), any(double[].class));
        
        // Execute integration
        double result = integrator.integrate(equations, t0, y0, t, y);
        
        // Verify initialization happened
        // If mutation is present (if(false)), these would fail:
        assertNotEquals(0.0, integrator.getSafety()); // Safety should be set
        assertNotEquals(0.0, integrator.getMinReduction()); // Min reduction should be set
        assertNotEquals(0.0, integrator.getMaxGrowth()); // Max growth should be set
        
        // Verify integration completed (would fail if initialization was skipped)
        assertEquals(1.0, result, 1e-6);
        assertEquals(1.0, y[0], 1e-6); // Simple integration of dy/dt=1 from 0 to 1
    }


}
