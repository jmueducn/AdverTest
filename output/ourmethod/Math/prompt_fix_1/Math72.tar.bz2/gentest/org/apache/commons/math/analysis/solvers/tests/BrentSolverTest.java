package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class BrentSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                            public void testSolve_BracketingInterval() throws Exception {
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                double result = solver.solve(1.0, 2.0);
                                                                                                                                                                
                                                                                                                                                                // The root should be between 1 and 2
                                                                                                                                                                assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_WithInitialGuess() throws Exception {
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(0.0)).thenReturn(-1.0);
                                                                                                                                                                when(f.value(1.5)).thenReturn(0.5);
                                                                                                                                                                when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver();
                                                                                                                                                                double result = solver.solve(0.0, 3.0, 1.5);
                                                                                                                                                                
                                                                                                                                                                // The root should be between 0 and 3
                                                                                                                                                                assertTrue(result >= 0.0 && result <= 3.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_WithFunctionParameter() throws Exception {
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(-1.0)).thenReturn(-2.0);
                                                                                                                                                                when(f.value(1.0)).thenReturn(2.0);
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver();
                                                                                                                                                                double result = solver.solve(f, -1.0, 1.0);
                                                                                                                                                                
                                                                                                                                                                // The root should be between -1 and 1
                                                                                                                                                                assertTrue(result >= -1.0 && result <= 1.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_SmallInterval() throws Exception {
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.999)).thenReturn(-0.001);
                                                                                                                                                                when(f.value(2.001)).thenReturn(0.001);
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                double result = solver.solve(1.999, 2.001);
                                                                                                                                                                
                                                                                                                                                                // The root should be very close to 2.0
                                                                                                                                                                assertEquals(2.0, result, 0.001);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_RootAtBoundary() throws Exception {
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(0.0)).thenReturn(0.0);
                                                                                                                                                                when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                double result = solver.solve(0.0, 1.0);
                                                                                                                                                                
                                                                                                                                                                // Should return the boundary where f(x) = 0
                                                                                                                                                                assertEquals(0.0, result, 0.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_WithDefaultConstructor() throws Exception {
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(-2.0)).thenReturn(-1.0);
                                                                                                                                                                when(f.value(0.0)).thenReturn(1.0);
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver();
                                                                                                                                                                double result = solver.solve(f, -2.0, 0.0);
                                                                                                                                                                
                                                                                                                                                                // The root should be between -2 and 0
                                                                                                                                                                assertTrue(result >= -2.0 && result <= 0.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_MinValueCloseToZero() throws Exception {
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(1e-7);  // Below default accuracy of 1E-6
                                                                                                                                                                when(f.value(3.0)).thenReturn(2.0);
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                double result = solver.solve(1.0, 3.0);
                                                                                                                                                                assertEquals(1.0, result, 0.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_MaxValueCloseToZero() throws Exception {
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(2.0);
                                                                                                                                                                when(f.value(3.0)).thenReturn(-1e-7);  // Below default accuracy of 1E-6
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                double result = solver.solve(1.0, 3.0);
                                                                                                                                                                assertEquals(3.0, result, 0.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_MinIsExactRoot() throws Exception {
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                                                when(f.value(3.0)).thenReturn(0.0);
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                double result = solver.solve(1.0, 3.0);
                                                                                                                                                                assertEquals(1.0, result, 0.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_MaxIsExactRoot() throws Exception {
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                                when(f.value(3.0)).thenReturn(0.0);
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                double result = solver.solve(1.0, 3.0);
                                                                                                                                                                assertEquals(3.0, result, 0.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_BothValuesZero() throws Exception {
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                                                when(f.value(3.0)).thenReturn(0.0);
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                double result = solver.solve(1.0, 3.0);
                                                                                                                                                                assertEquals(1.0, result, 0.0);  // Should return min in this case
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_ConvergesWithinFunctionValueAccuracy() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(0.0);  // Exact solution
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                
                                                                                                                                                                // Test - should converge immediately since y1 is within functionValueAccuracy
                                                                                                                                                                double result = solver.solve(f, 0.0, 1.0, 2.0);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals(1.0, result, 0.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_ConvergesWithinTolerance() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(0.1);
                                                                                                                                                                when(f.value(1.1)).thenReturn(-0.1);
                                                                                                                                                                when(f.value(1.05)).thenReturn(0.0);  // Solution
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                
                                                                                                                                                                // Test - should converge when dx <= tolerance
                                                                                                                                                                double result = solver.solve(f, 1.0, 1.1, 1.05);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals(1.05, result, 1E-6);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_UsesBisectionWhenProgressIsSlow() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(0.5);
                                                                                                                                                                when(f.value(2.0)).thenReturn(-0.5);
                                                                                                                                                                when(f.value(1.5)).thenReturn(0.25);
                                                                                                                                                                when(f.value(1.75)).thenReturn(-0.125);
                                                                                                                                                                when(f.value(1.625)).thenReturn(0.0625);
                                                                                                                                                                when(f.value(1.6875)).thenReturn(-0.03125);
                                                                                                                                                                when(f.value(1.65625)).thenReturn(0.0);  // Solution
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                
                                                                                                                                                                // Test - should fall back to bisection when progress is slow
                                                                                                                                                                double result = solver.solve(f, 1.0, 2.0, 1.5);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals(1.65625, result, 1E-6);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_LinearInterpolationCase() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(0.5);
                                                                                                                                                                when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                when(f.value(1.25)).thenReturn(0.0);  // Solution
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                
                                                                                                                                                                // Test - should use linear interpolation when x0 == x2
                                                                                                                                                                double result = solver.solve(f, 1.0, 1.5, 1.0);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals(1.25, result, 1E-6);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_InverseQuadraticInterpolation() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(0.5);
                                                                                                                                                                when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                when(f.value(2.0)).thenReturn(0.25);
                                                                                                                                                                when(f.value(1.25)).thenReturn(0.0);  // Solution
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                
                                                                                                                                                                // Test - should use inverse quadratic interpolation
                                                                                                                                                                double result = solver.solve(f, 1.0, 1.5, 2.0);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals(1.25, result, 1E-6);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_SwapsPointsWhenY2IsBetter() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(0.1);
                                                                                                                                                                when(f.value(1.1)).thenReturn(0.05);  // Better than y1
                                                                                                                                                                when(f.value(1.2)).thenReturn(0.0);   // Solution
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                
                                                                                                                                                                // Test - should swap points when y2 is better than y1
                                                                                                                                                                double result = solver.solve(f, 1.0, 1.1, 1.2);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals(1.2, result, 1E-6);
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testSolve_HandlesVerySmallTolerance() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(1.0)).thenReturn(1E-10);
                                                                                                                                                                when(f.value(1.000001)).thenReturn(-1E-10);
                                                                                                                                                                when(f.value(1.0000005)).thenReturn(0.0);  // Solution
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                
                                                                                                                                                                // Test - should handle very small tolerance values
                                                                                                                                                                double result = solver.solve(f, 1.0, 1.000001, 1.0000005);
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertEquals(1.0000005, result, 1E-12);
                                                                                                                                                            }

    @Test
                                                                                                                                                    public void testSolve_NonBracketingInterval() throws Exception {
                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                        when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                        when(f.value(2.0)).thenReturn(2.0);
                                                                                                                                                        
                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                        thrown.expectMessage("Function values at endpoints do not have different signs." +
                                                                                                                                                                            " Endpoints: [1.0, 2.0]" +
                                                                                                                                                                            " Values: [1.0, 2.0]");
                                                                                                                                                        
                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                        solver.solve(1.0, 2.0);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testSolve_NonBracketingInterval1() throws Exception {
                                                                                                                                                        org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                        when(f.value(1.0)).thenReturn(2.0);
                                                                                                                                                        when(f.value(3.0)).thenReturn(4.0);
                                                                                                                                                        
                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                        expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                        solver.solve(1.0, 3.0);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testSolve_BracketingInterval1() throws Exception {
                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                        when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                        when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                        
                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                        double result = solver.solve(1.0, 3.0);
                                                                                                                                                        
                                                                                                                                                        // The actual root should be between 1.0 and 3.0 since f(1)=-1 and f(3)=1
                                                                                                                                                        // We can't predict the exact value, but it should be in the interval
                                                                                                                                                        assertTrue(result >= 1.0 && result <= 3.0);
                                                                                                                                                        assertEquals(0.0, f.value(result), 1e-6);  // Verify it's actually a root
                                                                                                                                                    }

    @Test(expected = MaxIterationsExceededException.class)
                                                                                                                                                    public void testSolve_ThrowsMaxIterationsExceeded() throws Exception {
                                                                                                                                                        // Setup
                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                        when(f.value(anyDouble())).thenReturn(1.0);  // Never converges
                                                                                                                                                        
                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                        
                                                                                                                                                        // Test - should throw MaxIterationsExceededException
                                                                                                                                                        solver.solve(f, 0.0, 1.0, 0.5);
                                                                                                                                                    }

    @Test
                                                                                                            public void testSolve_MinMax() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                when(f.value(2.0)).thenReturn(1.0);
                                                                                                                
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                double result = solver.solve(1.0, 2.0);
                                                                                                                
                                                                                                                // Should find root between 1 and 2 where function crosses zero
                                                                                                                assertEquals(1.5, result, 0.0001);
                                                                                                            }

    @Test
                                                                                                            public void testSolve_MinMaxInitial() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                when(f.value(0.0)).thenReturn(-2.0);
                                                                                                                when(f.value(1.0)).thenReturn(0.5);
                                                                                                                when(f.value(2.0)).thenReturn(3.0);
                                                                                                                
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                double result = solver.solve(0.0, 2.0, 1.0);
                                                                                                                
                                                                                                                // Should find root between 0 and 1
                                                                                                                assertEquals(0.8, result, 0.0001);
                                                                                                            }

    @Test
                                                                                                            public void testSolve_FunctionMinMax() {
                                                                                                                try {
                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                    when(f.value(-1.0)).thenReturn(-0.5);
                                                                                                                    when(f.value(1.0)).thenReturn(0.5);
                                                                                                                    
                                                                                                                    BrentSolver solver = new BrentSolver();
                                                                                                                    double result = solver.solve(f, -1.0, 1.0);
                                                                                                                    
                                                                                                                    // Should find root at 0
                                                                                                                    assertEquals(0.0, result, 0.0001);
                                                                                                                } catch (FunctionEvaluationException e) {
                                                                                                                    fail("Function evaluation failed: " + e.getMessage());
                                                                                                                } catch (MaxIterationsExceededException e) {
                                                                                                                    fail("Max iterations exceeded: " + e.getMessage());
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testSolve_FunctionMinMaxInitial() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                when(f.value(2.0)).thenReturn(1.0);
                                                                                                                
                                                                                                                BrentSolver solver = new BrentSolver();
                                                                                                                double result = solver.solve(f, 1.0, 2.0, 1.5);
                                                                                                                
                                                                                                                // Should find root between 1.5 and 2.0
                                                                                                                assertEquals(1.75, result, 0.0001);
                                                                                                            }

    @Test
                                                                                                            public void testSolve_RootBetweenMinAndInitial() throws Exception {
                                                                                                                UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                                                    public double value(double x) throws FunctionEvaluationException {
                                                                                                                        if (x == 1.0) return -1.0;
                                                                                                                        if (x == 1.5) return 0.5;
                                                                                                                        if (x == 2.0) return 1.0;
                                                                                                                        throw new FunctionEvaluationException(x, "Function not defined for this value");
                                                                                                                    }
                                                                                                                };
                                                                                                                
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                
                                                                                                                // We can't predict exact root due to mock, but verify it's between min and initial
                                                                                                                assertTrue(result >= 1.0 && result <= 1.5);
                                                                                                            }

    @Test
                                                                                                            public void testSolve_RootBetweenInitialAndMax() throws Exception {
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                when(f.value(2.0)).thenReturn(1.0);
                                                                                                                
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                
                                                                                                                // We can't predict exact root due to mock, but verify it's between initial and max
                                                                                                                assertTrue(result >= 1.5 && result <= 2.0);
                                                                                                            }

    @Test
                                                                                                            public void testSolve_NonBracketing() throws Exception {
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                when(f.value(1.0)).thenReturn(1.0);
                                                                                                                when(f.value(2.0)).thenReturn(2.0);
                                                                                                                
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                
                                                                                                                // Get the private NON_BRACKETING_MESSAGE field via reflection
                                                                                                                String nonBracketingMessage;
                                                                                                                try {
                                                                                                                    Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                                                    field.setAccessible(true);
                                                                                                                    nonBracketingMessage = (String) field.get(null);
                                                                                                                } catch (Exception e) {
                                                                                                                    throw new RuntimeException("Failed to access NON_BRACKETING_MESSAGE", e);
                                                                                                                }
                                                                                                                
                                                                                                                // Define exception rule
                                                                                                                ExpectedException exception = ExpectedException.none();
                                                                                                                exception.expect(IllegalArgumentException.class);
                                                                                                                exception.expectMessage(nonBracketingMessage);
                                                                                                                
                                                                                                                try {
                                                                                                                    solver.solve(1.0, 2.0);
                                                                                                                } catch (FunctionEvaluationException e) {
                                                                                                                    // This shouldn't happen with mocked function
                                                                                                                    throw new RuntimeException("Unexpected FunctionEvaluationException", e);
                                                                                                                } catch (MaxIterationsExceededException e) {
                                                                                                                    // This shouldn't happen in this test case
                                                                                                                    throw new RuntimeException("Unexpected MaxIterationsExceededException", e);
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testSolve_InitialGuessIsRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                final double FUNCTION_VALUE_ACCURACY = 1E-6;
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                when(f.value(1.5)).thenReturn(0.0);
                                                                                                                
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                
                                                                                                                assertEquals(1.5, result, FUNCTION_VALUE_ACCURACY);
                                                                                                            }

    @Test
                                                                                                            public void testSolve_MinIsRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                final double FUNCTION_VALUE_ACCURACY = 1E-6;
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                when(f.value(1.0)).thenReturn(0.0);
                                                                                                                when(f.value(1.5)).thenReturn(0.5);
                                                                                                                
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                
                                                                                                                assertEquals(1.0, result, FUNCTION_VALUE_ACCURACY);
                                                                                                            }

    @Test
                                                                                                            public void testSolve_MaxIsRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                final double FUNCTION_VALUE_ACCURACY = 1E-6;
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                when(f.value(2.0)).thenReturn(0.0);
                                                                                                                when(f.value(1.5)).thenReturn(0.5);
                                                                                                                
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                
                                                                                                                assertEquals(2.0, result, FUNCTION_VALUE_ACCURACY);
                                                                                                            }

    @Test
                                                                                                            public void testSolve_NonBracketingIntervalThrowsException() throws Exception {
                                                                                                                // Create mock function
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                when(f.value(1.0)).thenReturn(1.0);
                                                                                                                when(f.value(1.5)).thenReturn(1.5);
                                                                                                                when(f.value(2.0)).thenReturn(2.0);
                                                                                                                
                                                                                                                // Create expected exception rule
                                                                                                                ExpectedException exception = ExpectedException.none();
                                                                                                                exception.expect(IllegalArgumentException.class);
                                                                                                                
                                                                                                                // Get private message field using reflection
                                                                                                                String nonBracketingMessage;
                                                                                                                try {
                                                                                                                    Field field = BrentSolver.class.getDeclaredField("NON_BRACKETING_MESSAGE");
                                                                                                                    field.setAccessible(true);
                                                                                                                    nonBracketingMessage = (String) field.get(null);
                                                                                                                    exception.expectMessage(nonBracketingMessage);
                                                                                                                } catch (Exception e) {
                                                                                                                    throw new RuntimeException("Failed to access NON_BRACKETING_MESSAGE field", e);
                                                                                                                }
                                                                                                                
                                                                                                                // Test the solver
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                try {
                                                                                                                    solver.solve(1.0, 2.0, 1.5);
                                                                                                                } catch (FunctionEvaluationException e) {
                                                                                                                    throw new RuntimeException("Unexpected FunctionEvaluationException", e);
                                                                                                                } catch (MaxIterationsExceededException e) {
                                                                                                                    throw new RuntimeException("Unexpected MaxIterationsExceededException", e);
                                                                                                                }
                                                                                                            }

    @Test(expected = IllegalArgumentException.class)
                                                                                                        public void testSolve_InvalidInterval() throws Exception {
                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                                            solver.solve(3.0, 1.0);
                                                                                                        }

    @Test
                                                                                                    public void testSolve_InvalidRange() {
                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                        
                                                                                                        try {
                                                                                                            solver.solve(1.0, 1.0);
                                                                                                            fail("Expected IllegalArgumentException");
                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                            // Expected exception
                                                                                                        } catch (MaxIterationsExceededException e) {
                                                                                                            fail("Unexpected MaxIterationsExceededException");
                                                                                                        } catch (FunctionEvaluationException e) {
                                                                                                            fail("Unexpected FunctionEvaluationException");
                                                                                                        }
                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                    public void testSolve_NullFunction() throws MaxIterationsExceededException, FunctionEvaluationException {
                                                                                                        BrentSolver solver = new BrentSolver();
                                                                                                        solver.solve(null, 1.0, 2.0);
                                                                                                    }

    @Test
                                                                                                    public void testSolve_InitialOutsideRange() {
                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                        
                                                                                                        try {
                                                                                                            solver.solve(1.0, 2.0, 3.0);
                                                                                                            fail("Expected IllegalArgumentException");
                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                            // Expected exception
                                                                                                        } catch (MaxIterationsExceededException e) {
                                                                                                            fail("Unexpected MaxIterationsExceededException");
                                                                                                        } catch (FunctionEvaluationException e) {
                                                                                                            fail("Unexpected FunctionEvaluationException");
                                                                                                        }
                                                                                                    }

    @Test
                                                                                                    public void testSolve_WithActualFunction() throws MaxIterationsExceededException, FunctionEvaluationException {
                                                                                                        UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                                            public double value(double x) {
                                                                                                                return x * x - 2; // root at sqrt(2) ≈ 1.4142
                                                                                                            }
                                                                                                        };
                                                                                                        
                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                        double result = solver.solve(1.0, 2.0);
                                                                                                        
                                                                                                        double FUNCTION_VALUE_ACCURACY = 1E-6; // Define accuracy constant
                                                                                                        assertEquals(Math.sqrt(2), result, FUNCTION_VALUE_ACCURACY);
                                                                                                    }

    @Test
                                                                                                    public void testSolve_WithActualFunctionAndRootAtBoundary() throws MaxIterationsExceededException, FunctionEvaluationException {
                                                                                                        final double FUNCTION_VALUE_ACCURACY = 1E-6;
                                                                                                        UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                                            public double value(double x) {
                                                                                                                return (x - 1.0) * (x - 2.0); // roots at 1.0 and 2.0
                                                                                                            }
                                                                                                        };
                                                                                                        
                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                        double result = solver.solve(0.5, 1.5, 1.25);
                                                                                                        
                                                                                                        assertEquals(1.0, result, FUNCTION_VALUE_ACCURACY);
                                                                                                    }

    @Test
                                                                                                    public void testSolveWithExactFunctionValueAccuracy() throws Exception {
                                                                                                        // Setup
                                                                                                        double functionValueAccuracy = 1E-6;
                                                                                                        double min = 0.0;
                                                                                                        double max = 2.0;
                                                                                                        double exactValue = functionValueAccuracy; // Value that exactly matches accuracy
                                                                                                        
                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                        when(f.value(min)).thenReturn(-exactValue);
                                                                                                        when(f.value(max)).thenReturn(exactValue);
                                                                                                        
                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                        
                                                                                                        // Test - should return max when f(max) exactly equals functionValueAccuracy
                                                                                                        double result = solver.solve(min, max);
                                                                                                        
                                                                                                        // Verify - original would return max, mutant would continue searching
                                                                                                        assertEquals("Should accept exact functionValueAccuracy as solution", 
                                                                                                                    max, result, 0.0);
                                                                                                        
                                                                                                        // Verify function was called with expected arguments
                                                                                                        verify(f).value(min);
                                                                                                        verify(f).value(max);
                                                                                                    }

    @Test
                                                                                                    public void testSolveWithExactFunctionValueAccuracy1() throws Exception {
                                                                                                        // Setup
                                                                                                        double functionValueAccuracy = 1E-6;
                                                                                                        double xValue = 1.5;
                                                                                                        double yValue = functionValueAccuracy; // Exact boundary case
                                                                                                        
                                                                                                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                        when(mockFunction.value(xValue)).thenReturn(yValue);
                                                                                                        
                                                                                                        BrentSolver solver = new BrentSolver();
                                                                                                        
                                                                                                        // Use reflection to access private solve method since it's private
                                                                                                        // This is a workaround for testing private methods
                                                                                                        try {
                                                                                                            java.lang.reflect.Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                "solve", 
                                                                                                                UnivariateRealFunction.class, 
                                                                                                                double.class, 
                                                                                                                double.class, 
                                                                                                                double.class, 
                                                                                                                double.class, 
                                                                                                                double.class, 
                                                                                                                double.class
                                                                                                            );
                                                                                                            solveMethod.setAccessible(true);
                                                                                                            
                                                                                                            // Call the method with values that will make yMax exactly equal functionValueAccuracy
                                                                                                            double result = (Double)solveMethod.invoke(
                                                                                                                solver,
                                                                                                                mockFunction,
                                                                                                                1.0,  // x0
                                                                                                                0.0,  // y0
                                                                                                                2.0,  // x1
                                                                                                                0.0,  // y1
                                                                                                                xValue,  // x2
                                                                                                                yValue   // y2
                                                                                                            );
                                                                                                            
                                                                                                            // Verify the result is xValue when yMax equals functionValueAccuracy
                                                                                                            assertEquals(xValue, result, 0.0);
                                                                                                        } catch (Exception e) {
                                                                                                            fail("Failed to test private solve method: " + e.getMessage());
                                                                                                        }
                                                                                                    }

    @Test
                                                                                               public void testFunctionValueExactlyAtAccuracy() throws Exception {
                                                                                                   // Setup
                                                                                                   double functionValueAccuracy = 1e-6;
                                                                                                   double x0 = 0.0, x1 = 1.0, x2 = 2.0;
                                                                                                   double y0 = -1.0, y1 = functionValueAccuracy, y2 = 1.0; // y1 exactly equals accuracy
                                                                                                   
                                                                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                   when(f.value(x0)).thenReturn(y0);
                                                                                                   when(f.value(x1)).thenReturn(y1);
                                                                                                   when(f.value(x2)).thenReturn(y2);
                                                                                                   
                                                                                                   BrentSolver solver = new BrentSolver(f);
                                                                                                   
                                                                                                   // Execute - using public solve method with min and max bounds
                                                                                                   double result = solver.solve(x0, x2);
                                                                                                   
                                                                                                   // Verify - should return x1 since y1 equals the accuracy threshold
                                                                                                   assertEquals(x1, result, 0.0);
                                                                                                   // Verify function was called for the initial bounds and solution
                                                                                                   verify(f, atLeastOnce()).value(x0);
                                                                                                   verify(f, atLeastOnce()).value(x2);
                                                                                                   verify(f, atLeastOnce()).value(result);
                                                                                               }

    @Test
                                                                                           public void testSolve_WhenFunctionValueAtMaxEqualsAccuracy_ShouldReturnMax() throws Exception {
                                                                                               // Setup
                                                                                               final double functionValueAccuracy = 1E-6;
                                                                                               final double min = 0.0;
                                                                                               final double max = 2.0;
                                                                                               final double initial = 1.0;
                                                                                               
                                                                                               // Create a mock function where f(max) returns exactly functionValueAccuracy
                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                               when(f.value(min)).thenReturn(1.0); // Not zero
                                                                                               when(f.value(initial)).thenReturn(0.5); // Not zero
                                                                                               when(f.value(max)).thenReturn(functionValueAccuracy); // Exactly equals accuracy
                                                                                               
                                                                                               // Create solver with known functionValueAccuracy
                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                               
                                                                                               // Test
                                                                                               double result = 0;
                                                                                               try {
                                                                                                   result = solver.solve(min, max, initial);
                                                                                               } catch (MaxIterationsExceededException e) {
                                                                                                   fail("Max iterations exceeded unexpectedly");
                                                                                               } catch (FunctionEvaluationException e) {
                                                                                                   fail("Function evaluation failed unexpectedly");
                                                                                               }
                                                                                               
                                                                                               // Verify
                                                                                               assertEquals("When f(max) equals functionValueAccuracy, should return max", 
                                                                                                           max, result, 0.0);
                                                                                               
                                                                                               // Verify interactions
                                                                                               verify(f).value(min);
                                                                                               verify(f).value(initial);
                                                                                               verify(f).value(max);
                                                                                           }

    @Test
                                                                                           public void testSolve_WhenYMaxEqualsFunctionAccuracy_ShouldReturnMax() {
                                                                                               // Setup
                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                               try {
                                                                                                   when(f.value(anyDouble())).thenReturn(1.0, 1E-6); // yMin=1.0, yMax=1E-6
                                                                                               } catch (FunctionEvaluationException e) {
                                                                                                   fail("Mock setup failed");
                                                                                               }
                                                                                               
                                                                                               // Create solver with known functionValueAccuracy of 1E-6 (from constructor)
                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                               
                                                                                               // Use reflection to set functionValueAccuracy to 1E-6 to match our test case
                                                                                               try {
                                                                                                   Field field = solver.getClass().getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                                   field.setAccessible(true);
                                                                                                   field.set(solver, 1E-6);
                                                                                               } catch (Exception e) {
                                                                                                   fail("Failed to set functionValueAccuracy via reflection");
                                                                                               }
                                                                                               
                                                                                               // Test
                                                                                               double result = 0;
                                                                                               try {
                                                                                                   result = solver.solve(0.0, 1.0);
                                                                                               } catch (MaxIterationsExceededException e) {
                                                                                                   fail("Max iterations exceeded");
                                                                                               } catch (FunctionEvaluationException e) {
                                                                                                   fail("Function evaluation failed");
                                                                                               }
                                                                                               
                                                                                               // Verify
                                                                                               assertEquals(1.0, result, 0.0); // Should return max (1.0) since yMax equals accuracy
                                                                                               
                                                                                               // Verify f.value() was called correctly
                                                                                               try {
                                                                                                   verify(f).value(0.0); // min
                                                                                                   verify(f).value(1.0); // max
                                                                                               } catch (FunctionEvaluationException e) {
                                                                                                   fail("Function evaluation verification failed");
                                                                                               }
                                                                                           }

    @Test
                                                                                           public void testSolveDetectsRootWhenYMaxLessThanAccuracy() throws Exception {
                                                                                               // Setup
                                                                                               double functionValueAccuracy = 1E-6;
                                                                                               double yMaxValue = functionValueAccuracy * 0.9; // Less than accuracy
                                                                                               
                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                               when(f.value(anyDouble())).thenReturn(1.0, yMaxValue); // First call returns 1.0, second returns yMaxValue
                                                                                               
                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                               
                                                                                               // Test bounds where solution exists
                                                                                               double min = 0.0;
                                                                                               double max = 1.0;
                                                                                               
                                                                                               // Call method - should return max when yMax is within accuracy
                                                                                               double result = solver.solve(min, max);
                                                                                               
                                                                                               // Verify - original would return max, mutant would continue searching
                                                                                               assertEquals(max, result, 0.0);
                                                                                               
                                                                                               // Verify function was called appropriately
                                                                                               verify(f, atLeast(2)).value(anyDouble());
                                                                                           }

    @Test
                                                                                       public void testSolveWithY1JustBelowFunctionValueAccuracy() throws Exception {
                                                                                           // Setup
                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                           when(f.value(anyDouble())).thenReturn(0.0); // Mock function
                                                                                           
                                                                                           // Create solver with known functionValueAccuracy (1E-6 from constructor)
                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                           
                                                                                           // Use reflection to access private solve method
                                                                                           Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                               "solve", 
                                                                                               UnivariateRealFunction.class, 
                                                                                               double.class, double.class, 
                                                                                               double.class, double.class, 
                                                                                               double.class, double.class
                                                                                           );
                                                                                           solveMethod.setAccessible(true);
                                                                                           
                                                                                           // Test case where y1 is just below functionValueAccuracy (0.999999 * 1E-6)
                                                                                           double x0 = 0.0, y0 = 1.0;
                                                                                           double x1 = 1.0, y1 = 0.999999e-6; // Just below threshold
                                                                                           double x2 = 2.0, y2 = -1.0;
                                                                                           
                                                                                           // Should return x1 (1.0) because y1 is within accuracy
                                                                                           double result = (double) solveMethod.invoke(
                                                                                               solver, f, x0, y0, x1, y1, x2, y2
                                                                                           );
                                                                                           
                                                                                           // Verify the result is x1 (1.0) - original would return here
                                                                                           // Mutant would continue iterating because y1 isn't exactly equal to accuracy
                                                                                           assertEquals(1.0, result, 0.0);
                                                                                           
                                                                                           // Verify the function was called exactly once (for y1)
                                                                                           verify(f, times(1)).value(anyDouble());
                                                                                       }

    @Test
                                                                                      public void testSolveDetectsMutantWhenYMaxIsLessThanButNotEqualToAccuracy() throws Exception {
                                                                                          // Setup
                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                          when(f.value(1.0)).thenReturn(1.0); // yMin
                                                                                          when(f.value(2.0)).thenReturn(0.000005); // yMax (less than but not equal to accuracy)
                                                                                          
                                                                                          // Create solver with custom accuracy (1E-6 = 0.000001)
                                                                                          BrentSolver solver = new BrentSolver(f) {
                                                                                              @Override
                                                                                              public double getFunctionValueAccuracy() {
                                                                                                  return 1E-5; // 0.00001 (yMax is 0.000005 which is < but not == accuracy)
                                                                                              }
                                                                                          };
                                                                                          
                                                                                          // Test
                                                                                          double result = solver.solve(1.0, 2.0);
                                                                                          
                                                                                          // Verify - original would return max (2.0) because yMax is within accuracy
                                                                                          // Mutant would throw exception because condition fails
                                                                                          assertEquals(2.0, result, 0.0);
                                                                                      }

    @Test
                                                                                      public void testSolveOriginalBehaviorWhenYMaxEqualsAccuracy() throws Exception {
                                                                                          // Setup
                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                          when(f.value(1.0)).thenReturn(1.0); // yMin
                                                                                          when(f.value(2.0)).thenReturn(0.00001); // yMax exactly equals accuracy
                                                                                          
                                                                                          // Create solver with default accuracy
                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                          
                                                                                          // Use reflection to set custom accuracy (1E-5 = 0.00001)
                                                                                          try {
                                                                                              Field field = BrentSolver.class.getDeclaredField("functionValueAccuracy");
                                                                                              field.setAccessible(true);
                                                                                              field.set(solver, 1E-5);
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to set functionValueAccuracy via reflection");
                                                                                          }
                                                                                          
                                                                                          // Test
                                                                                          double result = solver.solve(1.0, 2.0);
                                                                                          
                                                                                          // Verify - both original and mutant would return max (2.0)
                                                                                          assertEquals(2.0, result, 0.0);
                                                                                      }

    @Test
                                                                                  public void testSolveWithValueExactlyAtAccuracyThreshold() throws Exception {
                                                                                      // Setup
                                                                                      double functionValueAccuracy = 1E-6;
                                                                                      double exactAccuracyValue = functionValueAccuracy;
                                                                                      
                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                      when(mockFunction.value(anyDouble())).thenReturn(exactAccuracyValue);
                                                                                      
                                                                                      BrentSolver solver = new BrentSolver();
                                                                                      solver.setFunctionValueAccuracy(functionValueAccuracy);
                                                                                      
                                                                                      // Test
                                                                                      double result = solver.solve(mockFunction, 0, 1); // min and max values
                                                                                      
                                                                                      // Both original and mutant should accept this
                                                                                      org.junit.Assert.assertTrue("Should return a valid result", 
                                                                                          result >= 0 && result <= 1);
                                                                                  }

    @Test
                                                                              public void testSolveWithValueJustBelowAccuracyThreshold() throws Exception {
                                                                                  // Setup
                                                                                  double functionValueAccuracy = 1E-6;
                                                                                  double valueJustBelowAccuracy = functionValueAccuracy * 0.99; // Just below threshold
                                                                                  
                                                                                  // Create mock function
                                                                                  org.apache.commons.math.analysis.UnivariateRealFunction mockFunction = 
                                                                                      new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                                          @Override
                                                                                          public double value(double x) {
                                                                                              return valueJustBelowAccuracy;
                                                                                          }
                                                                                      };
                                                                                  
                                                                                  org.apache.commons.math.analysis.solvers.BrentSolver solver = 
                                                                                      new org.apache.commons.math.analysis.solvers.BrentSolver(mockFunction);
                                                                                  
                                                                                  // Test
                                                                                  double result = solver.solve(0, 1); // min and max values
                                                                                  
                                                                                  // Verify - the original should accept this as a solution
                                                                                  org.junit.Assert.assertTrue("Should return a valid result", 
                                                                                      result >= 0 && result <= 1);
                                                                              }

    @Test
                                                                          public void testSolve_DetectsMaxPointWhenValueIsBelowAccuracyThreshold() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                              // Setup
                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                              when(f.value(anyDouble())).thenReturn(1.0); // default return
                                                                              when(f.value(1.0)).thenReturn(0.5); // initial guess
                                                                              when(f.value(0.0)).thenReturn(1.0); // min
                                                                              when(f.value(2.0)).thenReturn(0.999999E-7); // max (just below 1E-6 accuracy)
                                                                              
                                                                              BrentSolver solver = new BrentSolver(f);
                                                                              solver.setFunctionValueAccuracy(1E-6);
                                                                              
                                                                              // Test - should return max point since |f(max)| < accuracy
                                                                              double result = solver.solve(0.0, 2.0, 1.0);
                                                                              
                                                                              // Verify - original would return max (2.0), mutant would proceed to other checks
                                                                              assertEquals(2.0, result, 0.0);
                                                                              
                                                                              // Verify interactions
                                                                              verify(f).value(1.0); // initial
                                                                              verify(f).value(0.0); // min
                                                                              verify(f).value(2.0); // max
                                                                          }

    @Test
                                                                          public void testSolve_ShouldReturnMaxWhenYMaxWithinAccuracy() throws Exception {
                                                                              // Setup
                                                                              double min = 0;
                                                                              double max = 10;
                                                                              double accuracy = 1E-6; // Default function value accuracy
                                                                              
                                                                              // Create a mock function that returns a value within accuracy at max
                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                              when(f.value(min)).thenReturn(-1.0); // Some negative value
                                                                              when(f.value(max)).thenReturn(accuracy / 2); // Within accuracy threshold
                                                                              
                                                                              BrentSolver solver = new BrentSolver(f);
                                                                              
                                                                              // Test
                                                                              double result = solver.solve(min, max);
                                                                              
                                                                              // Verify - original should return max since yMax is within accuracy
                                                                              // Mutant would continue computation instead of returning
                                                                              assertEquals(max, result, 0.0);
                                                                              
                                                                              // Verify function was evaluated at min and max
                                                                              verify(f).value(min);
                                                                              verify(f).value(max);
                                                                          }

    @Test
                                                                          public void testSolve_ShouldReturnMaxWhenFunctionValueAtMaxIsWithinAccuracy() throws Exception {
                                                                              // Setup
                                                                              double min = 0.0;
                                                                              double max = 1.0;
                                                                              double initial = 0.5;
                                                                              double functionValueAccuracy = 1e-6;
                                                                              
                                                                              // Create a mock function that returns a value within accuracy at max
                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                              when(f.value(min)).thenReturn(-1.0);  // negative at min
                                                                              when(f.value(max)).thenReturn(1e-7);  // positive but within accuracy at max
                                                                              
                                                                              // Create solver with default accuracy (1e-6)
                                                                              BrentSolver solver = new BrentSolver();
                                                                              
                                                                              // Test
                                                                              double result = solver.solve(f, min, max, initial);
                                                                              
                                                                              // Verify
                                                                              // Original code should return max since f(max) is within accuracy
                                                                              // Mutant would continue processing and potentially return something else
                                                                              assertEquals(max, result, 0.0);
                                                                              
                                                                              // Verify the function was evaluated at max
                                                                              verify(f).value(max);
                                                                          }

    @Test
                                                                          public void testSolve_ReturnsMaxWhenFunctionValueAtMaxIsZero() throws Exception {
                                                                              // Setup
                                                                              double min = 0.0;
                                                                              double max = 2.0;
                                                                              double initial = 1.0;
                                                                              double functionValueAccuracy = 1E-6;
                                                                              
                                                                              // Create a mock function where f(max) = 0 (within accuracy)
                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                              when(f.value(min)).thenReturn(1.0);  // Not zero
                                                                              when(f.value(initial)).thenReturn(0.5);  // Not zero
                                                                              when(f.value(max)).thenReturn(0.0);  // Exactly zero
                                                                              
                                                                              // Create solver with default accuracy (1E-6)
                                                                              BrentSolver solver = new BrentSolver();
                                                                              
                                                                              // Test
                                                                              double result = solver.solve(f, min, max, initial);
                                                                              
                                                                              // Verify - should return max since f(max) = 0
                                                                              assertEquals(max, result, 0.0);
                                                                              
                                                                              // Verify interactions
                                                                              verify(f).value(min);
                                                                              verify(f).value(initial);
                                                                              verify(f).value(max);
                                                                          }

    @Test
                                                                     public void testSolve_ShouldReturnWhenFunctionValueWithinAccuracy() throws Exception {
                                                                         // Setup
                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                         BrentSolver solver = new BrentSolver(f);
                                                                         
                                                                         // Set up values where y1 is within functionValueAccuracy (1E-6 by default)
                                                                         double x0 = 0.0;
                                                                         double y0 = 1.0;  // arbitrary
                                                                         double x1 = 1.0;
                                                                         double y1 = 1E-7;  // within accuracy
                                                                         double x2 = 2.0;
                                                                         double y2 = 1.0;   // arbitrary
                                                                         
                                                                         // Mock behavior
                                                                         when(f.value(x1)).thenReturn(y1);
                                                                         
                                                                         Method solveMethod = null;
                                                                         try {
                                                                             // Use reflection to access private solve method
                                                                             solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                 "solve", 
                                                                                 UnivariateRealFunction.class, 
                                                                                 double.class, double.class, 
                                                                                 double.class, double.class, 
                                                                                 double.class, double.class);
                                                                             solveMethod.setAccessible(true);
                                                                             
                                                                             // Invoke the method
                                                                             double result = (double) solveMethod.invoke(
                                                                                 solver, f, x0, y0, x1, y1, x2, y2);
                                                                             
                                                                             // Verify it returned x1 immediately
                                                                             assertEquals(x1, result, 0.0);
                                                                             
                                                                             // Verify minimal computation was done (only one function evaluation)
                                                                             verify(f, times(1)).value(x1);
                                                                         } finally {
                                                                             if (solveMethod != null) {
                                                                                 solveMethod.setAccessible(false);
                                                                             }
                                                                         }
                                                                     }

    @Test
                                                                 public void testSolve_ShouldReturnMaxWhenYMaxIsWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                     // Setup
                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                     when(f.value(1.0)).thenReturn(1.0); // yMin
                                                                     when(f.value(2.0)).thenReturn(1e-7); // yMax (within default accuracy 1e-6)
                                                                     
                                                                     BrentSolver solver = new BrentSolver(f);
                                                                     solver.setFunctionValueAccuracy(1e-6); // Set accuracy threshold
                                                                     
                                                                     // Test
                                                                     double result = solver.solve(1.0, 2.0);
                                                                     
                                                                     // Verify - should return max (2.0) since yMax is within accuracy
                                                                     // But mutant will not return it due to if(false)
                                                                     assertEquals(2.0, result, 0.0);
                                                                     
                                                                     // Verify interactions
                                                                     verify(f).value(1.0);
                                                                     verify(f).value(2.0);
                                                                 }

    @Test
                                                                 public void testSolve_ReturnsMaxBoundWhenFunctionDoesNotCrossZero() throws Exception {
                                                                     // Create a mock function that's always positive in the interval
                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                     when(f.value(anyDouble())).thenReturn(1.0); // Always returns positive
                                                                     
                                                                     // Create solver with the mock function
                                                                     BrentSolver solver = new BrentSolver(f);
                                                                     
                                                                     // Test interval where function doesn't cross zero
                                                                     double min = 0.0;
                                                                     double max = 10.0;
                                                                     double result = solver.solve(min, max);
                                                                     
                                                                     // Verify the result is at max bound (would fail if mutant is present)
                                                                     assertEquals(max, result, 0.0001);
                                                                     
                                                                     // Alternatively, if we had access to the result storage, we could verify:
                                                                     // that setResult was called with max, not min
                                                                 }

    @Test
                                                             public void testSolveReturnsMaxWhenRootIsNearMax() throws Exception {
                                                                 // Create a mock function that has root near max (1.0)
                                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                 when(f.value(0.0)).thenReturn(-1.0);  // min
                                                                 when(f.value(0.5)).thenReturn(-0.1);  // midpoint
                                                                 when(f.value(1.0)).thenReturn(0.001); // max (near root)
                                                                 
                                                                 // Create solver with tight accuracy
                                                                 BrentSolver solver = new BrentSolver(f);
                                                                 solver.setAbsoluteAccuracy(1e-3);
                                                                 
                                                                 // Test data where solution should converge to max
                                                                 double x0 = 0.0, y0 = -1.0;  // min
                                                                 double x1 = 0.5, y1 = -0.1;  // midpoint
                                                                 double x2 = 1.0, y2 = 0.001; // max (near root)
                                                                 
                                                                 // Call private method via reflection
                                                                 Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                     "solve", 
                                                                     UnivariateRealFunction.class, 
                                                                     double.class, double.class, 
                                                                     double.class, double.class, 
                                                                     double.class, double.class
                                                                 );
                                                                 solveMethod.setAccessible(true);
                                                                 
                                                                 double result = (double) solveMethod.invoke(
                                                                     solver, 
                                                                     f, x0, y0, x1, y1, x2, y2
                                                                 );
                                                                 
                                                                 // Verify result is max (1.0) - this would fail if mutant is present
                                                                 assertEquals(1.0, result, 1e-6);
                                                                 
                                                                 // Also verify the function was evaluated at expected points
                                                                 verify(f).value(0.0);
                                                                 verify(f).value(0.5);
                                                                 verify(f).value(1.0);
                                                             }

    @Test
                                                            public void testSolveDetectsSetResultMutation() throws Exception {
                                                                // Create a mock function that returns values with opposite signs at min and max
                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                when(f.value(1.0)).thenReturn(-1.0);  // min value
                                                                when(f.value(5.0)).thenReturn(1.0);   // max value
                                                                
                                                                // Create the solver and call the method
                                                                BrentSolver solver = new BrentSolver(f);
                                                                double result = 0;
                                                                try {
                                                                    result = solver.solve(1.0, 5.0);
                                                                } catch (FunctionEvaluationException | MaxIterationsExceededException e) {
                                                                    fail("Unexpected exception: " + e.getMessage());
                                                                }
                                                                
                                                                // The original would set result near max when certain conditions are met,
                                                                // while mutant would set it near min. We verify it's closer to max
                                                                double distanceToMin = Math.abs(result - 1.0);
                                                                double distanceToMax = Math.abs(result - 5.0);
                                                                assertTrue("Result should be closer to max than min", distanceToMax < distanceToMin);
                                                                
                                                                // Additional verification that result is within expected bounds
                                                                assertTrue(result > 1.0 && result <= 5.0);
                                                            }

    @Test
                                                            public void testSolve_ShouldReturnMaxWhenMaxIsSolution() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                // Setup mock function where max is a solution (yMax = 0)
                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                when(f.value(1.0)).thenReturn(1.0);  // yMin
                                                                when(f.value(2.0)).thenReturn(1.0);  // yInitial
                                                                when(f.value(3.0)).thenReturn(0.0);  // yMax (solution)
                                                                
                                                                // Create solver with low accuracy threshold to detect 0.0 as solution
                                                                BrentSolver solver = new BrentSolver(f);
                                                                solver.setFunctionValueAccuracy(1e-12);
                                                                
                                                                // Call solve with min=1.0, max=3.0, initial=2.0
                                                                double result = solver.solve(1.0, 3.0, 2.0);
                                                                
                                                                // Verify it returns max (3.0) since yMax is solution
                                                                assertEquals(3.0, result, 1e-12);
                                                                
                                                                // Verify f.value() was called with max (3.0)
                                                                verify(f).value(3.0);
                                                            }

    @Test
                                                            public void testSolve_DetectsMutatedSetResultForMax() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                // Setup
                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                when(f.value(1.0)).thenReturn(0.1);  // yMin not close to zero
                                                                when(f.value(2.0)).thenReturn(1e-7); // yMax within functionValueAccuracy (1e-6)
                                                                
                                                                BrentSolver solver = new BrentSolver(f);
                                                                solver.setFunctionValueAccuracy(1e-6); // Set accuracy threshold
                                                                
                                                                // Test
                                                                double result = solver.solve(1.0, 2.0);
                                                                
                                                                // Verify
                                                                // Original would return 2.0 (max), mutant would return 1.0 (min)
                                                                assertEquals(2.0, result, 0.0);
                                                                
                                                                // Additional verification that setResult was called with correct parameters
                                                                // This would require either:
                                                                // 1. Using a spy to verify setResult was called with (max, 0)
                                                                // 2. Or checking internal state if possible
                                                                // Since we don't have access to the result storage mechanism in the given code,
                                                                // we rely on the return value which should reflect the setResult call
                                                            }

    @Test
                                                            public void testSolve_ShouldSetResultWithMaxWhenRootIsAtMax() throws Exception {
                                                                // Create a mock function that has root at max
                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                when(f.value(anyDouble())).thenReturn(-1.0); // negative for most values
                                                                when(f.value(5.0)).thenReturn(0.0); // root at max=5
                                                                
                                                                // Create solver and test
                                                                BrentSolver solver = new BrentSolver(f);
                                                                double result = solver.solve(0, 5);
                                                                
                                                                // Verify the result is set with max value (5.0)
                                                                // Since we can't directly access the result, we verify the returned value
                                                                // which should be the max when root is at max
                                                                assertEquals(5.0, result, 0.0001);
                                                                
                                                                // The mutant would have used some initial value instead of max,
                                                                // so this test would fail if the mutant is present
                                                            }

    @Test
                                                            public void testSolve_ShouldSetResultAtMaxWhenRootIsAtMax() throws Exception {
                                                                // Create a mock function that returns 0 at max (root at max)
                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                when(f.value(anyDouble())).thenReturn(1.0); // default return
                                                                when(f.value(10.0)).thenReturn(0.0); // root at max=10
                                                                
                                                                // Create solver and test with initial value different from max
                                                                BrentSolver solver = new BrentSolver(f);
                                                                double initial = 5.0;
                                                                double min = 0.0;
                                                                double max = 10.0;
                                                                
                                                                double result = solver.solve(min, max, initial);
                                                                
                                                                // Verify the result is at max (10.0), not initial (5.0)
                                                                assertEquals(10.0, result, 0.0001);
                                                                
                                                                // Additional verification that function was evaluated at max
                                                                verify(f).value(10.0);
                                                            }

    @Test
                                                       public void testSolve_ImmediateConvergence_ShouldReturnMaxNotInitial() throws Exception {
                                                           // Setup
                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                           when(f.value(anyDouble())).thenReturn(0.0); // Function returns 0 at root
                                                           
                                                           // Test values where max is the root, initial is different
                                                           double x0 = 1.0;
                                                           double y0 = 1.0;
                                                           double x1 = 2.0; // initial
                                                           double y1 = 0.0; // already converged
                                                           double x2 = 3.0; // max
                                                           double y2 = 1.0;
                                                           
                                                           // Create solver with relaxed accuracy to allow immediate convergence
                                                           BrentSolver solver = new BrentSolver(f);
                                                           
                                                           // Set private fields using reflection
                                                           Field relativeAccuracyField = BrentSolver.class.getDeclaredField("relativeAccuracy");
                                                           relativeAccuracyField.setAccessible(true);
                                                           relativeAccuracyField.set(solver, 1.0);
                                                           
                                                           Field absoluteAccuracyField = BrentSolver.class.getDeclaredField("absoluteAccuracy");
                                                           absoluteAccuracyField.setAccessible(true);
                                                           absoluteAccuracyField.set(solver, 1.0);
                                                           
                                                           Field functionValueAccuracyField = BrentSolver.class.getDeclaredField("functionValueAccuracy");
                                                           functionValueAccuracyField.setAccessible(true);
                                                           functionValueAccuracyField.set(solver, 1.0);
                                                           
                                                           // Call private method using reflection
                                                           Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                               "solve", 
                                                               UnivariateRealFunction.class, 
                                                               double.class, double.class, 
                                                               double.class, double.class, 
                                                               double.class, double.class);
                                                           solveMethod.setAccessible(true);
                                                           
                                                           double result = (double) solveMethod.invoke(
                                                               solver, f, x0, y0, x1, y1, x2, y2);
                                                           
                                                           // Verify result is max (x2) not initial (x1)
                                                           assertEquals("Should return max value when converged immediately", 
                                                               x2, result, 0.0);
                                                       }

    @Test
                                               public void testSolve_DetectsMaxAsRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                   // Setup
                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                   when(f.value(1.0)).thenReturn(0.5);  // initial not a root
                                                   when(f.value(0.0)).thenReturn(0.5);  // min not a root
                                                   when(f.value(2.0)).thenReturn(0.0);  // max is a root
                                                   
                                                   BrentSolver solver = new BrentSolver(f);
                                                   solver.setFunctionValueAccuracy(1e-6);
                                                   
                                                   // Test
                                                   double result = solver.solve(0.0, 2.0, 1.0);
                                                   
                                                   // Verify
                                                   // Original should return max (2.0) since it's a root
                                                   // Mutant would return initial (1.0) instead
                                                   assertEquals(2.0, result, 1e-6);
                                                   
                                                   // Verify f.value() was called exactly 3 times (for initial, min, max)
                                                   verify(f, times(3)).value(anyDouble());
                                                   verify(f).value(1.0);
                                                   verify(f).value(0.0);
                                                   verify(f).value(2.0);
                                               }

    @Test
                                               public void testSolve_DetectsMutatedSetResultForMaxNearZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                   // Create a mock function where f(min) is positive and f(max) is very close to zero
                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                   when(f.value(1.0)).thenReturn(1.0);  // yMin = 1.0
                                                   when(f.value(2.0)).thenReturn(1e-7); // yMax = 1e-7 (very close to zero)
                                                   
                                                   // Create solver with low functionValueAccuracy (1e-6 by default in constructor)
                                                   BrentSolver solver = new BrentSolver(f);
                                                   
                                                   // Call the method with min=1.0, max=2.0, initial=1.5
                                                   double result = solver.solve(1.0, 2.0, 1.5);
                                                   
                                                   // Verify the correct result is returned (should be 2.0 since f(2.0) is very close to zero)
                                                   assertEquals(2.0, result, 0.0);
                                                   
                                                   // Removed verification of protected setResult method
                                                   // The test now verifies the behavior through the public solve method's return value
                                               }

    @Test
                                               public void testSolveDetectsMaxAsRoot() throws Exception {
                                                   // Create a mock function where f(max) = 0 (max is root)
                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                   double min = 0.0;
                                                   double max = 2.0;
                                                   double initial = 1.0;
                                                   
                                                   // Setup mock behavior
                                                   when(f.value(min)).thenReturn(-1.0);  // f(min) < 0
                                                   when(f.value(max)).thenReturn(0.0);   // f(max) = 0 (root)
                                                   when(f.value(initial)).thenReturn(0.5); // f(initial) > 0
                                                   
                                                   // Create solver and test
                                                   BrentSolver solver = new BrentSolver(f);
                                                   double result = solver.solve(f, min, max, initial);
                                                   
                                                   // Verify max was correctly identified as root
                                                   assertEquals(max, result, 1e-6);
                                                   
                                                   // This assertion would catch the mutant - verify function value at max is 0
                                                   // Mutant would set this to 1 instead of 0
                                                   assertEquals(0.0, f.value(result), 1e-6);
                                                   
                                                   // Verify mock interactions
                                                   verify(f, atLeastOnce()).value(min);
                                                   verify(f, atLeastOnce()).value(max);
                                                   verify(f, atLeastOnce()).value(initial);
                                               }

    @Test
                                          public void testSolveReportsZeroIterationsWhenSolutionFoundImmediately() throws Exception {
                                              // Setup
                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                              when(f.value(anyDouble())).thenReturn(0.0); // y1 is already 0 (solution found)
                                              
                                              BrentSolver solver = new BrentSolver(f);
                                              // Use reflection to access private solve method
                                              Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                  "solve", 
                                                  UnivariateRealFunction.class, 
                                                  double.class, double.class, 
                                                  double.class, double.class, 
                                                  double.class, double.class);
                                              solveMethod.setAccessible(true);
                                              
                                              // Test inputs where y1 is already at solution (0.0)
                                              double x0 = 1.0, y0 = 1.0;
                                              double x1 = 2.0, y1 = 0.0; // y1 meets functionValueAccuracy
                                              double x2 = 3.0, y2 = 1.0;
                                              
                                              // Using Mockito spy to verify internal behavior
                                              BrentSolver spySolver = spy(solver);
                                              
                                              // Execute
                                              solveMethod.invoke(spySolver, f, x0, y0, x1, y1, x2, y2);
                                              
                                              // Verify that the solution was found immediately (0 iterations)
                                              // We can verify this by checking the result field through reflection
                                              Field resultField = BrentSolver.class.getSuperclass().getDeclaredField("result");
                                              resultField.setAccessible(true);
                                              double result = resultField.getDouble(spySolver);
                                              
                                              Field iterationCountField = BrentSolver.class.getSuperclass().getDeclaredField("iterationCount");
                                              iterationCountField.setAccessible(true);
                                              int iterations = iterationCountField.getInt(spySolver);
                                              
                                              assertEquals(x1, result, 0.0);
                                              assertEquals(0, iterations);
                                          }

    @Test
                              public void testSolveWhenSolutionIsAtMaxBound() throws Exception {
                                  // Create a mock function that returns 0 at max bound
                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                  double min = 0.0;
                                  double max = 1.0;
                                  when(f.value(min)).thenReturn(-1.0); // negative at min
                                  when(f.value(max)).thenReturn(0.0);   // exactly 0 at max
                                  
                                  // Create solver
                                  BrentSolver solver = new BrentSolver(f);
                                  
                                  // Call the method with correct signature
                                  double result = solver.solve(min, max);
                                  
                                  // Verify the result is max (since f(max) = 0)
                                  assertEquals(max, result, 0.0001);
                              }

    @Test
                          public void testSolve_ExactSolutionAtMax_ShouldReturnZeroIterations() throws Exception {
                              // Setup a mock function where max is exactly a root
                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                              when(f.value(1.0)).thenReturn(0.0);  // max is root
                              when(f.value(0.0)).thenReturn(-1.0);  // min is not root
                              when(f.value(0.5)).thenReturn(-0.5);  // initial is not root
                              
                              // Create solver with tight accuracy settings
                              BrentSolver solver = new BrentSolver(f);
                              solver.setFunctionValueAccuracy(1e-12);
                              
                              try {
                                  // Call solve with min=0, max=1 (root at max)
                                  double result = solver.solve(0.0, 1.0, 0.5);
                                  
                                  // Verify result is correct
                                  assertEquals(1.0, result, 1e-12);
                                  
                                  // The key assertion - verify iteration count is 0 (not 1 as in mutant)
                                  // This assumes the solver stores iteration count in a field we can access
                                  // If not directly accessible, we might need to extend the class or use reflection
                                  // For this test, I'll assume there's a getIterationCount() method
                                  assertEquals(0, solver.getIterationCount());
                              } catch (FunctionEvaluationException e) {
                                  fail("Unexpected FunctionEvaluationException: " + e.getMessage());
                              } catch (MaxIterationsExceededException e) {
                                  fail("Unexpected MaxIterationsExceededException: " + e.getMessage());
                              }
                          }

    @Test
                          public void testSolve_WhenMaxIsWithinAccuracy_ShouldSetResultWithZeroIterations() {
                              // Setup
                              double min = 0.0;
                              double max = 1.0;
                              double accuracy = 1E-6; // Default functionValueAccuracy
                              
                              // Create a mock function where f(max) is within accuracy
                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                              try {
                                  when(f.value(min)).thenReturn(1.0); // yMin > 0
                                  when(f.value(max)).thenReturn(0.5 * accuracy); // yMax within accuracy
                              } catch (FunctionEvaluationException e) {
                                  fail("Mock setup failed: " + e.getMessage());
                              }
                              
                              // Create solver with mocked function
                              BrentSolver solver = new BrentSolver(f);
                              
                              // Use reflection to access and modify protected fields for verification
                              try {
                                  Field setResultCalledField = BrentSolver.class.getDeclaredField("resultComputed");
                                  setResultCalledField.setAccessible(true);
                                  Field resultXField = BrentSolver.class.getDeclaredField("result");
                                  resultXField.setAccessible(true);
                                  Field resultIterationsField = BrentSolver.class.getDeclaredField("iterationCount");
                                  resultIterationsField.setAccessible(true);
                                  
                                  // Execute
                                  double result = solver.solve(min, max);
                                  
                                  // Verify
                                  assertEquals(max, result, 0.0);
                                  assertTrue("result should be computed", (Boolean)setResultCalledField.get(solver));
                                  assertEquals("Result x should be max", max, (Double)resultXField.get(solver), 0.0);
                                  assertEquals("Iteration count should be 0", 0, ((Integer)resultIterationsField.get(solver)).intValue());
                              } catch (Exception e) {
                                  fail("Reflection failed: " + e.getMessage());
                              }
                          }

    @Test
                          public void testSolve_DetectsMaxAsRootWithCorrectFunctionValue() throws Exception {
                              // Setup
                              double min = 0.0;
                              double max = 1.0;
                              double initial = 0.5;
                              
                              // Create a mock function that returns 0 at max (root condition)
                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                              when(f.value(min)).thenReturn(-1.0);  // negative at min
                              when(f.value(max)).thenReturn(0.0);   // zero at max (root)
                              when(f.value(initial)).thenReturn(-0.5); // negative at initial
                              
                              // Create solver and solve
                              BrentSolver solver = new BrentSolver(f);
                              double result = solver.solve(f, min, max, initial);
                              
                              // Verify the root is correctly found at max
                              assertEquals(max, result, 0.0001);
                              
                              // This assertion would catch the mutant - the function value should be 0 at the root
                              // The mutant would set it to -1 instead
                              // Note: This assumes the solver exposes the function value at solution somehow
                              // If not directly exposed, we might need to verify through mock interactions
                              verify(f).value(max);  // Verify the function was evaluated at max
                              // In a real implementation, we might need to access solver's internal state
                              // to verify the function value was properly recorded as 0
                          }

    @Test
                      public void testSolve_WhenMaxIsRoot_ShouldSetIterationCountToZero() throws Exception {
                          // Setup
                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                          double min = 0.0;
                          double max = 2.0;
                          double initial = 1.0;
                          double functionValueAtMax = 0.0; // max is a root
                          
                          // Mock behavior
                          when(f.value(initial)).thenReturn(1.0); // not a root
                          when(f.value(min)).thenReturn(0.5); // not a root
                          when(f.value(max)).thenReturn(functionValueAtMax); // is a root
                          
                          // Create solver with tight accuracy to catch exact roots
                          BrentSolver solver = new BrentSolver(f);
                          solver.setFunctionValueAccuracy(1e-12);
                          
                          // Execute
                          double result = solver.solve(min, max, initial);
                          
                          // Verify - both the value and iteration count should be correct
                          assertEquals(max, result, 1e-12);
                          assertEquals(0, solver.getIterationCount()); // This will fail if mutant is present
                      }

    @Test
                      public void testImmediateConvergenceReportsZeroIterations() throws Exception {
                          // Setup - create a case that converges immediately (y1 within accuracy)
                          double x0 = 0.0;
                          double x1 = 1.0;
                          double x2 = 2.0;
                          double y0 = -1.0;
                          double y1 = 1e-10;  // Within default accuracy
                          double y2 = 1.0;
                          
                          // Mock the function to return our test values
                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                          when(f.value(x1)).thenReturn(y1);
                          
                          // Create solver with tight accuracy settings
                          BrentSolver solver = new BrentSolver(f);
                          // Use reflection to access private solve method
                          Method solveMethod = BrentSolver.class.getDeclaredMethod(
                              "solve", 
                              UnivariateRealFunction.class, 
                              double.class, double.class, 
                              double.class, double.class, 
                              double.class, double.class);
                          solveMethod.setAccessible(true);
                          
                          // Invoke the method
                          double result = (double) solveMethod.invoke(
                              solver, f, x0, y0, x1, y1, x2, y2);
                          
                          // Verify the iteration count was set to 0 (not -1)
                          // Assuming setResult stores iterations in a field we can access
                          Field iterationsField = BrentSolver.class.getDeclaredField("iterationCount");
                          iterationsField.setAccessible(true);
                          int iterations = (int) iterationsField.get(solver);
                          
                          assertEquals("Solution value should be x1", x1, result, 1e-12);
                          assertEquals("Iteration count should be 0 for immediate convergence", 
                              0, iterations);
                      }

    @Test
             public void testSolve_DetectsSetResultMutationWhenMaxIsCloseToZero() throws Exception {
                 // Setup
                 double min = 0.0;
                 double max = 1.0;
                 double functionValueAccuracy = 1E-6;
                 double yMax = 0.5E-6; // Within accuracy
                 
                 // Mock the function
                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                 when(f.value(min)).thenReturn(1.0); // yMin
                 when(f.value(max)).thenReturn(yMax); // yMax within accuracy
                 
                 // Create solver with mocked function
                 BrentSolver solver = spy(new BrentSolver(f));
                 
                 // Set accuracy to known value for test
                 when(solver.getFunctionValueAccuracy()).thenReturn(functionValueAccuracy);
                 
                 // Execute
                 double result = solver.solve(min, max);
                 
                 // Verify
                 assertEquals(max, result, 0.0);
                 
                 // Use reflection to verify setResult was called with expected parameters
                 Method setResultMethod = UnivariateRealSolverImpl.class.getDeclaredMethod(
                     "setResult", double.class, double.class, int.class);
                 setResultMethod.setAccessible(true);
                 
                 // Get the actual invocation arguments using reflection
                 Field resultField = UnivariateRealSolverImpl.class.getDeclaredField("result");
                 resultField.setAccessible(true);
                 double actualResult = resultField.getDouble(solver);
                 
                 Field functionValueField = UnivariateRealSolverImpl.class.getDeclaredField("functionValue");
                 functionValueField.setAccessible(true);
                 double actualFunctionValue = functionValueField.getDouble(solver);
                 
                 Field iterationCountField = UnivariateRealSolverImpl.class.getDeclaredField("iterationCount");
                 iterationCountField.setAccessible(true);
                 int actualIterationCount = iterationCountField.getInt(solver);
                 
                 // Verify the values were set correctly
                 assertEquals(max, actualResult, 0.0);
                 assertEquals(yMax, actualFunctionValue, 0.0);
                 assertEquals(0, actualIterationCount);
             }

    @Test
         public void testSolveWithRootAtMaxBoundary() throws Exception {
             // Create a mock function that returns 0 at max (root at max)
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(anyDouble())).thenReturn(1.0); // default return
             when(f.value(5.0)).thenReturn(0.0); // root at max=5.0
             
             // Create solver and test
             BrentSolver solver = new BrentSolver(f);
             double result = solver.solve(0.0, 5.0);
             
             // Verify the result is max (5.0)
             assertEquals(5.0, result, 1e-6);
             
             // The key assertion - verify setResult was called with correct parameters
             // This would fail for the mutant which uses -1 instead of 0
             // Note: This assumes we can access the result object or verify the setResult call
             // Since we can't directly verify internal calls, we can verify the function value at result
             assertEquals(0.0, f.value(result), 1e-6);
         }

    @Test
         public void testSolveWithRootAtMaxBoundary1() throws FunctionEvaluationException, MaxIterationsExceededException {
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(anyDouble())).thenReturn(1.0);
             when(f.value(5.0)).thenReturn(0.0);
             
             BrentSolver solver = new BrentSolver(f);
             double result = solver.solve(0.0, 5.0);
             
             assertEquals(5.0, result, 1e-6);
         }

    @Test
         public void testSolveReturnsInitialWhenItIsRoot() throws Exception {
             // Setup
             double min = 0.0;
             double max = 2.0;
             double initial = 1.0;
             double functionValueAccuracy = 1E-6;
             
             // Mock the function to return 0 at initial and non-zero elsewhere
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(initial)).thenReturn(0.0);  // initial is root
             when(f.value(min)).thenReturn(1.0);      // min is not root
             when(f.value(max)).thenReturn(1.0);      // max is not root
             
             // Create solver with mocked function
             BrentSolver solver = new BrentSolver(f);
             // Set accuracy to match our test case
             solver.setFunctionValueAccuracy(functionValueAccuracy);
             
             // Test
             double result = solver.solve(f, min, max, initial);
             
             // Verify - should return initial (1.0), not max (2.0)
             assertEquals("Should return initial when it's a root", initial, result, 0.0);
             
             // Verify interactions
             verify(f).value(initial);
             verify(f).value(min);
             verify(f).value(max);
         }

    @Test
         public void testSolveReturnsActualRootNotMax1() throws Exception {
             // Create a mock function that has a root at 2.0 (not at max)
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(1.0)).thenReturn(-1.0);  // f(min) = -1
             when(f.value(3.0)).thenReturn(1.0);   // f(max) = 1
             when(f.value(2.0)).thenReturn(0.0);    // root at 2.0
             
             // Create solver and set accuracy
             BrentSolver solver = new BrentSolver(f);
             solver.setFunctionValueAccuracy(1e-6);
             
             // Call solve - should return the root (2.0), not max (3.0)
             double result = solver.solve(1.0, 3.0);
             
             // Verify the result is the actual root, not max
             assertEquals(2.0, result, 1e-6);
             
             // Verify interactions with the mock
             verify(f).value(1.0);
             verify(f).value(3.0);
         }

    @Test
         public void testSolveReturnsCorrectResultNotMax() throws Exception {
             // Create a mock function that returns y = x - 2 (root at x=2)
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(anyDouble())).thenAnswer(invocation -> {
                 double x = (Double)invocation.getArguments()[0];
                 return x - 2.0;  // Simple linear function with root at x=2
             });
     
             // Create solver and test parameters
             BrentSolver solver = new BrentSolver(f);
             double x0 = 1.0, y0 = -1.0;  // y0 = f(x0)
             double x1 = 3.0, y1 = 1.0;    // y1 = f(x1)
             double x2 = 4.0, y2 = 2.0;    // y2 = f(x2)
             
             // The max value in our test case is 4.0 (x2)
             // If mutant exists, it would return 4.0 instead of the actual root ~2.0
             
             // Call the method (using reflection since it's private)
             java.lang.reflect.Method solveMethod = BrentSolver.class.getDeclaredMethod(
                 "solve", 
                 UnivariateRealFunction.class, 
                 double.class, double.class, 
                 double.class, double.class,
                 double.class, double.class
             );
             solveMethod.setAccessible(true);
             double result = (Double)solveMethod.invoke(
                 solver, f, x0, y0, x1, y1, x2, y2
             );
             
             // Verify the result is close to the actual root (2.0) not the max (4.0)
             assertEquals(2.0, result, 0.0001);
             
             // Additional check to ensure it's not returning x2 (max)
             assertNotEquals(x2, result, 0.0001);
         }

    @Test
    public void testSolveReturnsActualRootNotMax() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Create a mock function that has a root at 2.5 (between 1 and 3)
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(1.0)).thenReturn(-1.0);  // f(1) = -1
        when(f.value(2.5)).thenReturn(0.0);   // f(2.5) = 0 (root)
        when(f.value(3.0)).thenReturn(1.0);   // f(3) = 1
        
        // Create solver and solve
        BrentSolver solver = new BrentSolver();
        double result = solver.solve(f, 1.0, 3.0);
        
        // Verify the result is close to the actual root (2.5) not the max (3.0)
        // Using delta of 0.1 to account for possible approximation errors
        assertEquals("Should return value close to actual root", 2.5, result, 0.1);
        
        // Additional verification that the result isn't just returning max
        assertNotEquals("Should not simply return max value", 3.0, result, 0.0);
        
        // Verify the function was evaluated at the result point
        verify(f).value(result);
    }

    @Test
    public void testSolveReturnsActualResultNotMaxBound() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Create a mock function that crosses zero at x=0.5 (between 0 and 1)
        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
        when(mockFunction.value(0.0)).thenReturn(-1.0);
        when(mockFunction.value(0.5)).thenReturn(0.0);
        when(mockFunction.value(1.0)).thenReturn(1.0);
        
        // Create solver and test
        BrentSolver solver = new BrentSolver();
        double result = solver.solve(mockFunction, 0.0, 1.0);
        
        // Verify the result is the actual root (0.5) not the max bound (1.0)
        assertEquals(0.5, result, 1e-6);
        assertNotEquals(1.0, result, 1e-6);
        
        // Verify interactions with the mock
        verify(mockFunction, atLeastOnce()).value(0.0);
        verify(mockFunction, atLeastOnce()).value(1.0);
        verify(mockFunction, atLeastOnce()).value(0.5);
    }


}
