package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.io.PrintStream;
 
public class FastMathTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                          public void testCosh_NaN() {
                                                                                                                              double nan = Double.NaN;
                                                                                                                              assertEquals(nan, FastMath.cosh(nan), 0.0);
                                                                                                                          }

 @Test
                                                                                                                          public void testCosh_MediumRange() {
                                                                                                                              // Positive values
                                                                                                                              assertEquals(1.0, FastMath.cosh(0.0), 1e-15);
                                                                                                                              assertEquals(1.5430806348152437, FastMath.cosh(1.0), 1e-15);
                                                                                                                              assertEquals(3.7621956910836314, FastMath.cosh(2.0), 1e-15);
                                                                                                                              assertEquals(10.067661995777765, FastMath.cosh(3.0), 1e-15);
                                                                                                                              
                                                                                                                              // Negative values (should be same as positive due to even function property)
                                                                                                                              assertEquals(1.5430806348152437, FastMath.cosh(-1.0), 1e-15);
                                                                                                                              assertEquals(3.7621956910836314, FastMath.cosh(-2.0), 1e-15);
                                                                                                                          }

 @Test
                                                                                                                          public void testCosh_ThresholdBoundary() {
                                                                                                                              double x = 19.9;
                                                                                                                              double expected = (Math.exp(x) + Math.exp(-x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                              
                                                                                                                              x = 20.1;
                                                                                                                              expected = 0.5 * Math.exp(x);
                                                                                                                              assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                              
                                                                                                                              x = -19.9;
                                                                                                                              expected = (Math.exp(-x) + Math.exp(x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                              
                                                                                                                              x = -20.1;
                                                                                                                              expected = 0.5 * Math.exp(-x);
                                                                                                                              assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                          }

 @Test
                                                                                                                          public void testCosh_SpecialValues() {
                                                                                                                              // Zero
                                                                                                                              assertEquals(1.0, FastMath.cosh(0.0), 0.0);
                                                                                                                              
                                                                                                                              // Positive infinity
                                                                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.cosh(Double.POSITIVE_INFINITY), 0.0);
                                                                                                                              
                                                                                                                              // Negative infinity
                                                                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.cosh(Double.NEGATIVE_INFINITY), 0.0);
                                                                                                                          }

 @Test
                                                                                                                          public void testCosh_Precision() {
                                                                                                                              double x = 0.5;
                                                                                                                              double expected = (Math.exp(x) + Math.exp(-x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.cosh(x), 1e-16 * expected);
                                                                                                                              
                                                                                                                              x = -1.5;
                                                                                                                              expected = (Math.exp(-x) + Math.exp(x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.cosh(x), 1e-16 * expected);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_NaN() {
                                                                                                                              double nan = Double.NaN;
                                                                                                                              assertEquals(nan, FastMath.sinh(nan), 0.0);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_Zero() {
                                                                                                                              assertEquals(0.0, FastMath.sinh(0.0), 0.0);
                                                                                                                              assertEquals(-0.0, FastMath.sinh(-0.0), 0.0);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_LargePositive() {
                                                                                                                              // Regular large value case
                                                                                                                              double x = 25.0;
                                                                                                                              double expected = 0.5 * Math.exp(x);
                                                                                                                              assertEquals(expected, FastMath.sinh(x), expected * 1e-15);
                                                                                                                      
                                                                                                                              // Very large value case (avoiding overflow)
                                                                                                                              x = 1000.0;
                                                                                                                              double t = Math.exp(0.5 * x);
                                                                                                                              expected = 0.5 * t * t;
                                                                                                                              assertEquals(expected, FastMath.sinh(x), expected * 1e-15);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_LargeNegative() {
                                                                                                                              // Regular large negative value case
                                                                                                                              double x = -25.0;
                                                                                                                              double expected = -0.5 * Math.exp(-x);
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                      
                                                                                                                              // Very large negative value case (avoiding overflow)
                                                                                                                              x = -1000.0;
                                                                                                                              double t = Math.exp(-0.5 * x);
                                                                                                                              expected = -0.5 * t * t;
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_SmallPositive() {
                                                                                                                              double x = 0.1;
                                                                                                                              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_SmallNegative() {
                                                                                                                              double x = -0.1;
                                                                                                                              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_MediumPositive() {
                                                                                                                              double x = 5.0;
                                                                                                                              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_MediumNegative() {
                                                                                                                              double x = -5.0;
                                                                                                                              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_BoundaryAroundQuarter() {
                                                                                                                              double x = 0.25;
                                                                                                                              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                      
                                                                                                                              x = 0.26;
                                                                                                                              expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_BoundaryAroundTwenty() {
                                                                                                                              double x = 20.0;
                                                                                                                              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                      
                                                                                                                              x = 20.1;
                                                                                                                              expected = 0.5 * Math.exp(x);
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_BoundaryAroundMinusTwenty() {
                                                                                                                              double x = -20.0;
                                                                                                                              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                      
                                                                                                                              x = -20.1;
                                                                                                                              expected = -0.5 * Math.exp(-x);
                                                                                                                              assertEquals(expected, FastMath.sinh(x), Math.abs(expected) * 1e-15);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_VerySmallValues() {
                                                                                                                              double x = 1e-10;
                                                                                                                              double expected = x; // sinh(x) ≈ x for very small x
                                                                                                                              assertEquals(expected, FastMath.sinh(x), 1e-20);
                                                                                                                      
                                                                                                                              x = -1e-10;
                                                                                                                              expected = x;
                                                                                                                              assertEquals(expected, FastMath.sinh(x), 1e-20);
                                                                                                                          }

 @Test
                                                                                                                          public void testSinh_Infinity() {
                                                                                                                              double x = Double.POSITIVE_INFINITY;
                                                                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.sinh(x), 0.0);
                                                                                                                      
                                                                                                                              x = Double.NEGATIVE_INFINITY;
                                                                                                                              assertEquals(Double.NEGATIVE_INFINITY, FastMath.sinh(x), 0.0);
                                                                                                                          }

 @Test
                                                                                                                  public void testCosh_LargePositive() {
                                                                                                                      // Value just above threshold
                                                                                                                      double x = 20.1;
                                                                                                                      double expected = 0.5 * Math.exp(x);
                                                                                                                      assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                      
                                                                                                                      // Very large value (should use overflow protection)
                                                                                                                      // Using Math.log(Double.MAX_VALUE) instead of FastMath.LOG_MAX_VALUE
                                                                                                                      x = Math.log(Double.MAX_VALUE) + 1;
                                                                                                                      double t = Math.exp(0.5 * x);
                                                                                                                      expected = (0.5 * t) * t;
                                                                                                                      assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                  }

 @Test
                                                                                                                  public void testCosh_LargeNegative() {
                                                                                                                      // Value just below threshold
                                                                                                                      double x = -20.1;
                                                                                                                      double expected = 0.5 * Math.exp(-x);
                                                                                                                      assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                      
                                                                                                                      // Very large negative value (should use overflow protection)
                                                                                                                      x = -Math.log(Double.MAX_VALUE) - 1;
                                                                                                                      double t = Math.exp(-0.5 * x);
                                                                                                                      expected = (0.5 * t) * t;
                                                                                                                      assertEquals(expected, FastMath.cosh(x), expected * 1e-15);
                                                                                                                  }

 @Test
                                                                                                              public void testSinhBoundaryAt() {
                                                                                                                  // Test the boundary case where x=20
                                                                                                                  double x = 20.0;
                                                                                                                  
                                                                                                                  // Expected value using precise calculation (original behavior)
                                                                                                                  double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                                                                  
                                                                                                                  // Actual value from FastMath
                                                                                                                  double actual = FastMath.sinh(x);
                                                                                                                  
                                                                                                                  // Verify they match with a small tolerance
                                                                                                                  assertEquals("Sinh of 20 should use precise calculation", 
                                                                                                                              expected, actual, 1e-10);
                                                                                                                  
                                                                                                                  // Also test a value slightly above 20 to ensure fast path works
                                                                                                                  double xAbove = 20.0001;
                                                                                                                  double expectedAbove = 0.5 * Math.exp(xAbove);
                                                                                                                  double actualAbove = FastMath.sinh(xAbove);
                                                                                                                  assertEquals("Sinh above 20 should use fast approximation",
                                                                                                                              expectedAbove, actualAbove, 1e-10);
                                                                                                              }

 @Test
                                                                                                                 public void testSinhForValuesBetween10And() {
                                                                                                                     // Test a value between 10 and 20 where original and mutant behavior differ
                                                                                                                     double x = 15.0;
                                                                                                                     
                                                                                                                     // Calculate expected value using original behavior (precise calculation)
                                                                                                                     // We'll compute this by comparing with Math.sinh which should be accurate
                                                                                                                     double expected = Math.sinh(x);
                                                                                                                     
                                                                                                                     // Calculate actual value from FastMath
                                                                                                                     double actual = FastMath.sinh(x);
                                                                                                                     
                                                                                                                     // The mutant would use simplified calculation (0.5 * exp(x)) for x > 10
                                                                                                                     double mutantValue = 0.5 * Math.exp(x);
                                                                                                                     
                                                                                                                     // Verify actual is close to expected (original behavior)
                                                                                                                     assertEquals(expected, actual, 1e-10);
                                                                                                                     
                                                                                                                     // Additionally verify it's significantly different from mutant behavior
                                                                                                                     assertTrue(Math.abs(actual - mutantValue) > 1e-5);
                                                                                                                     
                                                                                                                     // For completeness, verify the relative difference
                                                                                                                     double relativeDiff = Math.abs((actual - mutantValue)/actual);
                                                                                                                     assertTrue(relativeDiff > 0.001); // Should be at least 0.1% different
                                                                                                                 }

 @Test
                                                                                                            public void testSinhAtLogMaxValue() {
                                                                                                                // Get the LOG_MAX_VALUE constant value through reflection since it's private
                                                                                                                double logMaxValue = 0;
                                                                                                                try {
                                                                                                                    Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                                                                                    field.setAccessible(true);
                                                                                                                    logMaxValue = field.getDouble(null);
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Failed to access LOG_MAX_VALUE field");
                                                                                                                }
                                                                                                                
                                                                                                                // Test exactly at LOG_MAX_VALUE boundary
                                                                                                                double x = logMaxValue;
                                                                                                                
                                                                                                                // Calculate expected value using the overflow-safe path (0.5*t)*t
                                                                                                                double expected = 0.5 * FastMath.exp(0.5 * x);
                                                                                                                expected = expected * expected;
                                                                                                                
                                                                                                                // Actual result from sinh
                                                                                                                double actual = FastMath.sinh(x);
                                                                                                                
                                                                                                                // Verify the result matches the overflow-safe calculation
                                                                                                                assertEquals("sinh should use overflow-safe calculation at LOG_MAX_VALUE boundary", 
                                                                                                                            expected, actual, 1e-10);
                                                                                                                
                                                                                                                // Also verify it's not using the simple 0.5*exp(x) calculation
                                                                                                                double simpleCalculation = 0.5 * FastMath.exp(x);
                                                                                                                assertNotEquals("sinh should not use simple calculation at LOG_MAX_VALUE boundary",
                                                                                                                               simpleCalculation, actual, 1e-10);
                                                                                                            }

 @Test
                                                                                                          public void testSinhLargePositiveValueAboveLogMax() {
                                                                                                              // Setup
                                                                                                              double logMaxValue = Math.log(Double.MAX_VALUE);
                                                                                                              double x = logMaxValue + 1.0; // Value just above LOG_MAX_VALUE
                                                                                                              
                                                                                                              // Expected behavior: should use overflow protection path (0.5 * t * t)
                                                                                                              // Mutated behavior: would use regular path (0.5 * exp(x))
                                                                                                              double expected = 0.5 * FastMath.exp(0.5 * x);
                                                                                                              expected = expected * expected;
                                                                                                              
                                                                                                              // Test
                                                                                                              double result = FastMath.sinh(x);
                                                                                                              
                                                                                                              // Verify
                                                                                                              assertEquals("sinh of large positive value above LOG_MAX_VALUE should use overflow protection", 
                                                                                                                          expected, result, 1.0e-10);
                                                                                                              
                                                                                                              // Additional verification that we're testing the right path
                                                                                                              double wrongPathResult = 0.5 * FastMath.exp(x);
                                                                                                              assertNotEquals("Should not use simple exp path for x > LOG_MAX_VALUE",
                                                                                                                             wrongPathResult, result, 1.0e10);
                                                                                                          }

 @Test
                                                                                                      public void testSinhLargeValueBelowLogMax() {
                                                                                                          // Setup
                                                                                                          double x = 21.0; // Value > 20 but < LOG_MAX_VALUE
                                                                                                          
                                                                                                          // Calculate expected value using original logic (0.5 * exp(x))
                                                                                                          double expected = 0.5 * FastMath.exp(x);
                                                                                                          
                                                                                                          // Calculate actual value
                                                                                                          double actual = FastMath.sinh(x);
                                                                                                          
                                                                                                          // Verify the result matches expected calculation
                                                                                                          assertEquals("Sinh of large value below LOG_MAX_VALUE should use normal calculation", 
                                                                                                                       expected, actual, 1e-10);
                                                                                                          
                                                                                                          // Additional verification that we're not using overflow protection
                                                                                                          // Overflow protection would give (0.5 * t) * t where t = exp(0.5 * x)
                                                                                                          double overflowProtectedResult = 0.5 * FastMath.exp(0.5 * x);
                                                                                                          overflowProtectedResult *= overflowProtectedResult;
                                                                                                          assertNotEquals("Should not use overflow protection for this value",
                                                                                                                          overflowProtectedResult, actual, 1e-10);
                                                                                                      }

 @Test
                                                                                                     public void testSinhLargePositiveValueAvoidOverflow() {
                                                                                                         // Get LOG_MAX_VALUE through reflection since it's private
                                                                                                         double LOG_MAX_VALUE;
                                                                                                         try {
                                                                                                             Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                                                                             field.setAccessible(true);
                                                                                                             LOG_MAX_VALUE = field.getDouble(null);
                                                                                                         } catch (Exception e) {
                                                                                                             throw new RuntimeException("Failed to access LOG_MAX_VALUE", e);
                                                                                                         }
                                                                                                     
                                                                                                         // Test value slightly larger than LOG_MAX_VALUE where exp(x) would overflow
                                                                                                         // but exp(0.5*x) wouldn't
                                                                                                         double x = LOG_MAX_VALUE + 1.0;
                                                                                                         
                                                                                                         // Expected value calculation using original formula: 0.5 * exp(0.5*x)^2
                                                                                                         double expected = 0.5 * Math.exp(0.5 * x) * Math.exp(0.5 * x);
                                                                                                         
                                                                                                         // Actual value from FastMath
                                                                                                         double actual = FastMath.sinh(x);
                                                                                                         
                                                                                                         // Verify the result matches expected calculation
                                                                                                         assertEquals("Sinh of large positive value should avoid overflow", 
                                                                                                                     expected, actual, 1.0e-10 * Math.abs(expected));
                                                                                                         
                                                                                                         // Also verify it's not infinity (which would happen if exp(x) was used directly)
                                                                                                         assertFalse("Result should not be infinite", Double.isInfinite(actual));
                                                                                                     }

 @Test
                                                                                                   public void testSinhLargePositiveValue() throws Exception {
                                                                                                       // Use reflection to access private LOG_MAX_VALUE field
                                                                                                       Field logMaxValueField = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                                                                       logMaxValueField.setAccessible(true);
                                                                                                       double logMaxValue = logMaxValueField.getDouble(null);
                                                                                                       
                                                                                                       // Test with x >= LOG_MAX_VALUE to hit the mutated branch
                                                                                                       double x = logMaxValue;
                                                                                                       
                                                                                                       // Calculate expected value using original formula
                                                                                                       double expectedT = Math.exp(0.5 * x);
                                                                                                       double expected = 0.5 * expectedT * expectedT;
                                                                                                       
                                                                                                       // Get actual value from FastMath.sinh
                                                                                                       double actual = FastMath.sinh(x);
                                                                                                       
                                                                                                       // Verify the result matches expected calculation
                                                                                                       assertEquals("sinh of large positive value incorrect", 
                                                                                                                   expected, actual, 0.0);
                                                                                                       
                                                                                                       // Test with even larger value
                                                                                                       x = logMaxValue * 2;
                                                                                                       expectedT = Math.exp(0.5 * x);
                                                                                                       expected = 0.5 * expectedT * expectedT;
                                                                                                       actual = FastMath.sinh(x);
                                                                                                       assertEquals("sinh of very large positive value incorrect",
                                                                                                                   expected, actual, 0.0);
                                                                                                   }

 @Test
                                                                                              public void testSinhLargePositiveValue1() throws Exception {
                                                                                                  // Setup
                                                                                                  // Get LOG_MAX_VALUE using reflection
                                                                                                  Field logMaxValueField = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                                                                  logMaxValueField.setAccessible(true);
                                                                                                  double LOG_MAX_VALUE = logMaxValueField.getDouble(null);
                                                                                                  
                                                                                                  double x = LOG_MAX_VALUE + 1; // Value guaranteed to be >= LOG_MAX_VALUE
                                                                                                  
                                                                                                  // Calculate expected value using the original formula
                                                                                                  double expected = 0.5 * (Math.exp(x) - Math.exp(-x));
                                                                                                  
                                                                                                  // Action
                                                                                                  double actual = FastMath.sinh(x);
                                                                                                  
                                                                                                  // Assertion
                                                                                                  // The mutant would return a value twice as large as expected
                                                                                                  assertEquals("Sinh of large positive value should be correctly calculated", 
                                                                                                              expected, actual, Math.ulp(expected) * 10);
                                                                                                  
                                                                                                  // Additional check to ensure we're testing the right branch
                                                                                                  assertTrue(x > 20);
                                                                                                  assertTrue(x >= LOG_MAX_VALUE);
                                                                                              }

 @Test
                                                                                         public void testSinhLargePositiveValue2() throws Exception {
                                                                                             // Get private LOG_MAX_VALUE field using reflection
                                                                                             Field logMaxValueField = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                                                             logMaxValueField.setAccessible(true);
                                                                                             double LOG_MAX_VALUE = logMaxValueField.getDouble(null);
                                                                                             
                                                                                             // Setup
                                                                                             double x = LOG_MAX_VALUE + 1; // Value guaranteed to trigger the overflow path
                                                                                             
                                                                                             // Expected calculation:
                                                                                             // sinh(x) ≈ 0.5 * e^x when x is large positive
                                                                                             // But since we're in overflow prevention path, it uses (0.5 * t) * t where t = e^(0.5x)
                                                                                             // So expected = 0.5 * e^x
                                                                                             double expected = 0.5 * Math.exp(x);
                                                                                             
                                                                                             // Action
                                                                                             double actual = FastMath.sinh(x);
                                                                                             
                                                                                             // Assertion
                                                                                             assertEquals("Large positive sinh value incorrect", expected, actual, Math.ulp(expected) * 10);
                                                                                             
                                                                                             // Additional test with even larger value
                                                                                             x = LOG_MAX_VALUE * 2;
                                                                                             expected = 0.5 * Math.exp(x);
                                                                                             actual = FastMath.sinh(x);
                                                                                             assertEquals("Very large positive sinh value incorrect", expected, actual, Math.ulp(expected) * 10);
                                                                                         }

 @Test
                                                                                         public void testSinhBoundaryNegative() {
                                                                                             // Test the boundary case where x is exactly -20
                                                                                             double x = -20.0;
                                                                                             
                                                                                             // Calculate expected value using original behavior (general case)
                                                                                             // sinh(-20) = -sinh(20) ≈ -2.4258259770489514E8
                                                                                             double expected = -0.5 * Math.exp(20.0); // Simplified expected value
                                                                                             
                                                                                             // Call the method
                                                                                             double actual = FastMath.sinh(x);
                                                                                             
                                                                                             // Verify the result matches expected with appropriate delta for floating point
                                                                                             assertEquals("sinh(-20) should use general case calculation", 
                                                                                                         expected, actual, 1.0e-10 * Math.abs(expected));
                                                                                             
                                                                                             // Additional verification - check if it's using the correct calculation path
                                                                                             // For x=-20, original would use general case while mutant would use approximation
                                                                                             // The results should be significantly different
                                                                                             double mutantApproximation = -0.5 * FastMath.exp(-x);
                                                                                             assertNotEquals("Test should fail if mutant is present (using approximation for x=-20)",
                                                                                                            mutantApproximation, actual, 1.0e-10);
                                                                                         }

 @Test
                                                                                        public void testSinhNegativeBetween20And() {
                                                                                            // Test a value between -20 and -10 that would be affected by the mutation
                                                                                            double x = -15.0;
                                                                                            
                                                                                            // Expected value using precise calculation (what original method should return)
                                                                                            // sinh(-15) = (e^-15 - e^15)/2 ≈ -1.6345089E6
                                                                                            double expected = -1.6345089E6;
                                                                                            
                                                                                            // Calculate with original method (would use precise calculation)
                                                                                            double actual = FastMath.sinh(x);
                                                                                            
                                                                                            // Assert with tolerance since we're dealing with floating point
                                                                                            assertEquals("sinh(-15) should use precise calculation", 
                                                                                                        expected, actual, Math.abs(expected) * 1e-6);
                                                                                            
                                                                                            // Additional test near the boundary
                                                                                            x = -10.1;
                                                                                            expected = -1.3396E4; // Approximate expected value
                                                                                            actual = FastMath.sinh(x);
                                                                                            assertEquals("sinh(-10.1) should use precise calculation",
                                                                                                        expected, actual, Math.abs(expected) * 1e-6);
                                                                                            
                                                                                            // Test just below -20 to ensure it uses approximation
                                                                                            x = -20.1;
                                                                                            expected = -0.5 * Math.exp(-x); // Approximation formula
                                                                                            actual = FastMath.sinh(x);
                                                                                            assertEquals("sinh(-20.1) should use approximation",
                                                                                                        expected, actual, Math.abs(expected) * 1e-6);
                                                                                        }

 @Test
                                                                                   public void testSinhNegativeLogMaxValue() {
                                                                                       // Get the LOG_MAX_VALUE constant value using reflection since it's private
                                                                                       double logMaxValue = 0;
                                                                                       try {
                                                                                           Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                                                           field.setAccessible(true);
                                                                                           logMaxValue = field.getDouble(null);
                                                                                       } catch (Exception e) {
                                                                                           fail("Failed to access LOG_MAX_VALUE");
                                                                                       }
                                                                                       
                                                                                       // Test the boundary case where x exactly equals -LOG_MAX_VALUE
                                                                                       double x = -logMaxValue;
                                                                                       double result = FastMath.sinh(x);
                                                                                       
                                                                                       // Verify the result is calculated using the overflow protection formula
                                                                                       // (0.5 * t) * t where t = exp(-0.5 * x)
                                                                                       double expected = 0.5 * Math.exp(x);  // This would be wrong for the original code
                                                                                       double t = Math.exp(-0.5 * x);
                                                                                       expected = (-0.5 * t) * t;  // Correct calculation for original code
                                                                                       
                                                                                       // The test will fail for the mutant since it would use direct exp calculation
                                                                                       assertEquals("sinh(-LOG_MAX_VALUE) should use overflow protection formula", 
                                                                                                   expected, result, 1e-10);
                                                                                   }

 @Test
                                                                                  public void testSinhForLargeNegativeValueBelowLogMax() {
                                                                                      // Setup: Create a value that is < -20 and <= -LOG_MAX_VALUE
                                                                                      // Assuming LOG_MAX_VALUE is around 709.78 (typical value for double)
                                                                                      double x = -710.0; // Clearly <= -LOG_MAX_VALUE
                                                                                      
                                                                                      // Expected behavior: should use overflow protection path
                                                                                      // Calculate expected value manually
                                                                                      double expected = -0.5 * Math.exp(-x); // Simplified version of the overflow protection
                                                                                      
                                                                                      // Test
                                                                                      double result = FastMath.sinh(x);
                                                                                      
                                                                                      // Verify the result matches expected behavior
                                                                                      // Using delta for floating point comparison
                                                                                      assertEquals("Sinh of very large negative number should use overflow protection", 
                                                                                                  expected, result, 1e-10);
                                                                                      
                                                                                      // Additional verification that we're testing the right path
                                                                                      // The mutated version would return a different value since it skips overflow protection
                                                                                      double mutatedVersionResult = 0.5 * Math.exp(x); // What mutated version would return
                                                                                      assertNotEquals("Test should detect mutation by showing different results", 
                                                                                                     mutatedVersionResult, result, 1e-10);
                                                                                  }

 @Test
                                                                                     public void testSinhNegativeBetweenThresholds() {
                                                                                         // Choose a value that is < -20 but > -LOG_MAX_VALUE
                                                                                         // Assuming LOG_MAX_VALUE is around 709.78 (natural log of Double.MAX_VALUE)
                                                                                         double testValue = -30.0;
                                                                                         
                                                                                         // Expected behavior (original code):
                                                                                         // Since -30 > -LOG_MAX_VALUE, should use -0.5 * exp(-x) path
                                                                                         double expected = -0.5 * Math.exp(-testValue);
                                                                                         
                                                                                         // Actual result from FastMath.sinh
                                                                                         double actual = FastMath.sinh(testValue);
                                                                                         
                                                                                         // Verify the result matches expected calculation
                                                                                         assertEquals("sinh of -30 should use standard calculation", 
                                                                                                     expected, actual, 1e-10);
                                                                                         
                                                                                         // For mutated version (if (true) instead of if (x <= -LOG_MAX_VALUE)):
                                                                                         // It would use the overflow protection path and return a different value
                                                                                         // This assertion would fail for the mutant
                                                                                     }

 @Test
                                                                                    public void testSinhLargeNegativeValue() {
                                                                                        // Test with a very large negative value that would trigger the overflow avoidance path
                                                                                        double x = -710.0; // exp(710) is near Double.MAX_VALUE
                                                                                        
                                                                                        // Calculate expected value using original formula: -0.5 * exp(-x) when x <= -LOG_MAX_VALUE
                                                                                        // But since we're testing the overflow avoidance path, we need to compute it differently
                                                                                        double expectedT = Math.exp(-0.5 * x);
                                                                                        double expectedResult = -0.5 * expectedT * expectedT;
                                                                                        
                                                                                        // Mutated version would compute t as exp(-x) which would overflow
                                                                                        double actualResult = FastMath.sinh(x);
                                                                                        
                                                                                        // Verify the result matches the expected value with a small tolerance
                                                                                        assertEquals("sinh of large negative value", expectedResult, actualResult, 1.0e-10);
                                                                                        
                                                                                        // Additional check: verify the result has the correct sign
                                                                                        assertTrue("Result should be negative", actualResult < 0);
                                                                                    }

 @Test
                                                                              public void testSinhForLargeNegativeValues() throws Exception {
                                                                                  // Choose a value significantly less than -LOG_MAX_VALUE
                                                                                  // Assuming LOG_MAX_VALUE is around 709.78 (natural log of Double.MAX_VALUE)
                                                                                  double x = -1000.0;
                                                                                  
                                                                                  // Calculate expected value using original formula
                                                                                  double expectedT = Math.exp(-0.5 * x);
                                                                                  double expectedResult = (-0.5 * expectedT) * expectedT;
                                                                                  
                                                                                  // Call the method
                                                                                  double actualResult = FastMath.sinh(x);
                                                                                  
                                                                                  // Verify the result
                                                                                  assertEquals("sinh of very large negative value", expectedResult, actualResult, 1e-10);
                                                                                  
                                                                                  // Get LOG_MAX_VALUE using reflection
                                                                                  Field logMaxValueField = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                                                  logMaxValueField.setAccessible(true);
                                                                                  double LOG_MAX_VALUE = logMaxValueField.getDouble(null);
                                                                                  
                                                                                  // Also test a value just below -LOG_MAX_VALUE boundary
                                                                                  double boundaryX = -LOG_MAX_VALUE - 1;
                                                                                  double boundaryExpectedT = Math.exp(-0.5 * boundaryX);
                                                                                  double boundaryExpectedResult = (-0.5 * boundaryExpectedT) * boundaryExpectedT;
                                                                                  double boundaryActualResult = FastMath.sinh(boundaryX);
                                                                                  
                                                                                  assertEquals("sinh at -LOG_MAX_VALUE boundary", 
                                                                                              boundaryExpectedResult, boundaryActualResult, 1e-10);
                                                                              }

 @Test
                                                                         public void testSinhForVeryLargeNegativeValues() throws Exception {
                                                                             // Get private LOG_MAX_VALUE field using reflection
                                                                             Field logMaxValueField = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                                             logMaxValueField.setAccessible(true);
                                                                             double LOG_MAX_VALUE = logMaxValueField.getDouble(null);
                                                                             
                                                                             // Setup
                                                                             double x = -LOG_MAX_VALUE - 1; // Value guaranteed to be < -LOG_MAX_VALUE
                                                                             
                                                                             // Calculate expected value using original formula: (-0.5 * t) * t where t = exp(-0.5 * x)
                                                                             double t = FastMath.exp(-0.5 * x);
                                                                             double expected = (-0.5 * t) * t;
                                                                             
                                                                             // Mutated version would return (-t) * t which is 2*expected
                                                                             
                                                                             // Execute
                                                                             double actual = FastMath.sinh(x);
                                                                             
                                                                             // Verify
                                                                             assertEquals("Sinh calculation for very large negative values", expected, actual, 1e-10);
                                                                             
                                                                             // Additional check to ensure we're testing the right path
                                                                             assertTrue("Input value should be < -LOG_MAX_VALUE", x < -LOG_MAX_VALUE);
                                                                             
                                                                             // Check that the mutant would fail this test
                                                                             double mutantResult = (-t) * t;
                                                                             assertNotEquals("Test should detect mutant", mutantResult, actual, 1e-10);
                                                                         }

 @Test
                                                                    public void testSinhForLargeNegativeValues1() {
                                                                        // Setup
                                                                        double logMaxValue;
                                                                        try {
                                                                            Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                                            field.setAccessible(true);
                                                                            logMaxValue = field.getDouble(null);
                                                                        } catch (Exception e) {
                                                                            throw new RuntimeException("Failed to access LOG_MAX_VALUE field", e);
                                                                        }
                                                                        
                                                                        double x = -logMaxValue - 1; // Value that triggers overflow protection
                                                                        
                                                                        // Calculate expected value using original formula
                                                                        double t = FastMath.exp(-0.5 * x);
                                                                        double expected = (-0.5 * t) * t;
                                                                        
                                                                        // Action
                                                                        double actual = FastMath.sinh(x);
                                                                        
                                                                        // Verification
                                                                        assertEquals("sinh of very large negative value should match expected calculation", 
                                                                                    expected, actual, 1e-10);
                                                                        
                                                                        // Additional verification that mutant would fail
                                                                        double mutantExpected = (-0.25 * t) * t;
                                                                        assertNotEquals("Test should detect the mutant by showing different results", 
                                                                                       mutantExpected, actual, 1e-10);
                                                                    }

 @Test
                                                                    public void testSinhZero() {
                                                                        // Test the special case of x = 0
                                                                        double input = 0.0;
                                                                        double expected = 0.0; // sinh(0) = 0
                                                                        
                                                                        double result = FastMath.sinh(input);
                                                                        
                                                                        // This assertion will fail with the mutant but pass with original
                                                                        assertEquals("sinh(0) should return 0", expected, result, 0.0);
                                                                        
                                                                        // Additional test for x=1 to show mutant behavior
                                                                        double input1 = 1.0;
                                                                        double expected1 = (Math.exp(1) - Math.exp(-1)) / 2; // Proper sinh(1) value
                                                                        
                                                                        double result1 = FastMath.sinh(input1);
                                                                        assertEquals("sinh(1) should return proper value", expected1, result1, 1e-15);
                                                                    }

 @Test
                                                                   public void testSinhZero1() {
                                                                       // Test the special case of x=0
                                                                       double input = 0.0;
                                                                       
                                                                       // Original behavior should return exactly 0
                                                                       double result = FastMath.sinh(input);
                                                                       
                                                                       // Assert exact equality for the special case
                                                                       assertEquals("sinh(0) should return exactly 0", 0.0, result, 0.0);
                                                                       
                                                                       // Additionally, we can verify it doesn't do unnecessary calculations
                                                                       // by checking no exp/log operations were called (though this would require mocking)
                                                                   }

 @Test
                                                              public void testSinhWithNaNInput() {
                                                                  // Test NaN input - should return NaN
                                                                  double nanInput = Double.NaN;
                                                                  double result = FastMath.sinh(nanInput);
                                                                  
                                                                  // Verify the result is NaN (original behavior)
                                                                  assertTrue("Sinh of NaN should return NaN", Double.isNaN(result));
                                                                  
                                                                  // Also verify it's not 0 (mutated behavior)
                                                                  assertNotEquals("Sinh of NaN should not return 0", 0.0, result, 0.0);
                                                              }

 @Test
                                                             public void testSinhDetectsNegativeConditionMutant() {
                                                                 // Test x=0 (should return 0 without any negation)
                                                                 // This will catch the mutant since mutated version would try to negate 0
                                                                 assertEquals(0.0, FastMath.sinh(0.0), 0.0);
                                                                 
                                                                 // Test small positive value (should be positive)
                                                                 double smallPos = 0.5;
                                                                 double posResult = FastMath.sinh(smallPos);
                                                                 assertTrue(posResult > 0);
                                                                 
                                                                 // Test small negative value (should be negative)
                                                                 double smallNeg = -0.5;
                                                                 double negResult = FastMath.sinh(smallNeg);
                                                                 assertTrue(negResult < 0);
                                                                 
                                                                 // Test boundary case just below 0
                                                                 double justBelowZero = -Double.MIN_VALUE;
                                                                 double justBelowResult = FastMath.sinh(justBelowZero);
                                                                 assertTrue(justBelowResult < 0);
                                                                 
                                                                 // Test boundary case just above 0
                                                                 double justAboveZero = Double.MIN_VALUE;
                                                                 double justAboveResult = FastMath.sinh(justAboveZero);
                                                                 assertTrue(justAboveResult > 0);
                                                                 
                                                                 // Verify exact value for a known case
                                                                 assertEquals(1.1752011936438014, FastMath.sinh(1.0), 1e-15);
                                                                 assertEquals(-1.1752011936438014, FastMath.sinh(-1.0), 1e-15);
                                                             }

 @Test
                                                            public void testSinhNegativeInput() {
                                                                // Test with negative input where negate starts false (normal case)
                                                                double negativeInput = -1.0;
                                                                double result = FastMath.sinh(negativeInput);
                                                                
                                                                // Verify result is negative (sinh(-x) = -sinh(x))
                                                                assertTrue("Result should be negative for negative input", result < 0);
                                                                
                                                                // Verify the magnitude is correct
                                                                assertEquals(-Math.sinh(1.0), result, 1e-15);
                                                                
                                                                // Test with negative input where negate would start true if mutated
                                                                // This would catch the negate = !negate mutation
                                                                double negativeInput2 = -0.5;
                                                                double result2 = FastMath.sinh(negativeInput2);
                                                                
                                                                // Verify result is still negative
                                                                assertTrue("Result should be negative for negative input", result2 < 0);
                                                                
                                                                // Verify the magnitude is correct
                                                                assertEquals(-Math.sinh(0.5), result2, 1e-15);
                                                            }

 @Test
                                                           public void testSinhBoundaryCondition() {
                                                               // Test the exact boundary value that triggers different paths
                                                               double boundaryValue = 0.25;
                                                               
                                                               // Calculate expected value using original behavior (should use expm1 path)
                                                               double expected = (Math.exp(boundaryValue) - Math.exp(-boundaryValue)) / 2;
                                                               
                                                               // Test the method
                                                               double result = FastMath.sinh(boundaryValue);
                                                               
                                                               // Verify the result matches expected hyperbolic sine calculation
                                                               assertEquals("sinh(0.25) should use expm1 path", expected, result, 1e-15);
                                                               
                                                               // Also test values just below and above the boundary
                                                               double justBelow = 0.24999999999999999;
                                                               double justAbove = 0.25000000000000001;
                                                               
                                                               double resultBelow = FastMath.sinh(justBelow);
                                                               double resultAbove = FastMath.sinh(justAbove);
                                                               
                                                               // Verify the transition is smooth (no sudden jumps from path change)
                                                               assertTrue("Results near boundary should be close", 
                                                                         Math.abs(resultBelow - result) < Math.abs(resultAbove - resultBelow));
                                                               
                                                               // Verify the exact boundary case is handled consistently with nearby values
                                                               assertTrue("Boundary value result should be between adjacent values",
                                                                         (result > resultBelow && result < resultAbove) ||
                                                                         (result < resultBelow && result > resultAbove));
                                                           }

 @Test
                                                          public void testSinhBoundaryConditionForMutant() {
                                                              // Test a value between 0.25 and 0.5 to catch the mutant
                                                              double x = 0.3;
                                                              
                                                              // Expected value calculated using standard math library
                                                              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                              
                                                              // Actual value from FastMath
                                                              double actual = FastMath.sinh(x);
                                                              
                                                              // Verify the result is accurate to within reasonable tolerance
                                                              assertEquals("sinh(0.3) should use more accurate calculation path", 
                                                                          expected, actual, 1e-15);
                                                              
                                                              // Additionally test the exact boundary case
                                                              double boundary = 0.25;
                                                              double expectedBoundary = (Math.exp(boundary) - Math.exp(-boundary)) / 2;
                                                              double actualBoundary = FastMath.sinh(boundary);
                                                              assertEquals("sinh(0.25) should use more accurate calculation path",
                                                                          expectedBoundary, actualBoundary, 1e-15);
                                                          }

 @Test
                                                             public void testSinhBoundaryAt1() {
                                                                 // Test the boundary case x = 20
                                                                 double x = 20.0;
                                                                 
                                                                 // Calculate expected value using full formula (exp(x) - exp(-x))/2
                                                                 double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                                 
                                                                 // Call the method (would be FastMath.sinh(x) in real test)
                                                                 double actual = FastMath.sinh(x);
                                                                 
                                                                 // Verify the result matches the full calculation (not the approximation)
                                                                 assertEquals("sinh(20) should use full calculation, not approximation", 
                                                                             expected, actual, 1e-10);
                                                                 
                                                                 // Additional assertion to specifically catch the mutant
                                                                 // The approximation would be 0.5 * exp(20)
                                                                 double approx = 0.5 * Math.exp(x);
                                                                 assertNotEquals("sinh(20) should not use approximation", 
                                                                                approx, actual, 1e-10);
                                                             }

 @Test
                                                       public void testSinhBetween10And() {
                                                           // Test a value between 10 and 20 where original and mutant behavior differ
                                                           double x = 15.0;
                                                           
                                                           // Expected value calculated using original method's logic
                                                           // For original (x > 20 would be false), it would use complex calculation
                                                           // For mutant (x > 10 would be true), it would use simplified calculation
                                                           
                                                           // Calculate expected value using original logic (complex path)
                                                           boolean negate = false;
                                                           if (x < 0.0) {
                                                               x = -x;
                                                               negate = true;
                                                           }
                                                           
                                                           // Use public exp method instead of private one
                                                           double expX = FastMath.exp(x);
                                                           double ya = expX;
                                                           double yb = 0.0; // Simplified since we can't access high precision parts
                                                           
                                                           // Define HEX_40000000 value locally (2^52)
                                                           final double HEX_40000000 = 0x1.0p52;
                                                           
                                                           double temp = ya * HEX_40000000;
                                                           double yaa = ya + temp - temp;
                                                           double yab = ya - yaa;
                                                           
                                                           double recip = 1.0/ya;
                                                           temp = recip * HEX_40000000;
                                                           double recipa = recip + temp - temp;
                                                           double recipb = recip - recipa;
                                                           
                                                           recipb += (1.0 - yaa*recipa - yaa*recipb - yab*recipa - yab*recipb) * recip;
                                                           recipb += -yb * recip * recip;
                                                           
                                                           recipa = -recipa;
                                                           recipb = -recipb;
                                                           
                                                           temp = ya + recipa;
                                                           yb += -(temp - ya - recipa);
                                                           ya = temp;
                                                           temp = ya + recipb;
                                                           yb += -(temp - ya - recipb);
                                                           ya = temp;
                                                           
                                                           double expected = ya + yb;
                                                           expected *= 0.5;
                                                           if (negate) {
                                                               expected = -expected;
                                                           }
                                                           
                                                           // Calculate value using simplified path (mutant would take this path)
                                                           double mutantValue = 0.5 * FastMath.exp(x);
                                                           if (negate) {
                                                               mutantValue = -mutantValue;
                                                           }
                                                           
                                                           // The actual result should match the complex calculation, not the simplified one
                                                           double actual = FastMath.sinh(x);
                                                           
                                                           // Verify actual matches expected complex calculation
                                                           assertEquals("Sinh calculation for x between 10 and 20 should use complex path", 
                                                                       expected, actual, 1e-10);
                                                           
                                                           // Verify actual doesn't match mutant's simplified calculation
                                                           assertNotEquals("Sinh calculation should not match mutant's simplified path", 
                                                                          mutantValue, actual, 1e-10);
                                                       }

 @Test
                                                   public void testSinhAtLogMaxValue1() {
                                                       // Get the LOG_MAX_VALUE constant value through reflection since it's private
                                                       double logMaxValue = 0;
                                                       try {
                                                           Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                           field.setAccessible(true);
                                                           logMaxValue = field.getDouble(null);
                                                       } catch (Exception e) {
                                                           fail("Failed to access LOG_MAX_VALUE field");
                                                       }
                                                       
                                                       // Test with x exactly equal to LOG_MAX_VALUE
                                                       double x = logMaxValue;
                                                       double result = FastMath.sinh(x);
                                                       
                                                       // Verify the result is finite (no overflow occurred)
                                                       assertTrue("Result should be finite", Double.isFinite(result));
                                                       
                                                       // Verify the result is positive (since x > 20)
                                                       assertTrue("Result should be positive", result > 0);
                                                       
                                                       // Verify the result is large but not infinite
                                                       assertTrue("Result should be large", result > 1e100);
                                                       
                                                       // Additional verification - compare with expected behavior
                                                       // The original code would use (0.5*t)*t calculation
                                                       double expected = FastMath.exp(0.5 * x);
                                                       expected = (0.5 * expected) * expected;
                                                       assertEquals(expected, result, expected * 1e-15);
                                                   }

 @Test
                                                  public void testSinhLargePositiveValueAboveLogMaxValue() {
                                                      // Get LOG_MAX_VALUE through reflection since it's private
                                                      double logMaxValue = 0;
                                                      try {
                                                          Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                          field.setAccessible(true);
                                                          logMaxValue = field.getDouble(null);
                                                      } catch (Exception e) {
                                                          fail("Failed to access LOG_MAX_VALUE");
                                                      }
                                                      
                                                      // Test value significantly larger than LOG_MAX_VALUE
                                                      double x = logMaxValue + 10;
                                                      
                                                      // Calculate expected value using original formula
                                                      double expectedT = Math.exp(0.5 * x);
                                                      double expectedResult = (0.5 * expectedT) * expectedT;
                                                      
                                                      // Compare with actual result
                                                      double actualResult = FastMath.sinh(x);
                                                      
                                                      // The mutant would calculate t = exp(0.25*x) instead, leading to a different result
                                                      double mutantT = Math.exp(0.25 * x);
                                                      double mutantResult = (0.5 * mutantT) * mutantT;
                                                      
                                                      // Verify actual result matches expected, not mutant
                                                      assertEquals(expectedResult, actualResult, 0.0);
                                                      
                                                      // Additional verification that mutant would produce different result
                                                      assertNotEquals(mutantResult, actualResult, 0.0);
                                                  }

 @Test
                                                public void testSinhNegativeTwentyDetectsMutant() {
                                                    // Test the boundary case where x is exactly -20
                                                    double x = -20.0;
                                                    
                                                    // Expected behavior (original code):
                                                    // Should fall through to general case calculation since x is not less than -20
                                                    // Mutated behavior:
                                                    // Would enter the x <= -20 branch and use approximation
                                                    
                                                    // Get LOG_MAX_VALUE using reflection
                                                    double logMaxValue;
                                                    try {
                                                        Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                        field.setAccessible(true);
                                                        logMaxValue = field.getDouble(null);
                                                    } catch (Exception e) {
                                                        throw new RuntimeException("Failed to access LOG_MAX_VALUE via reflection", e);
                                                    }
                                                    
                                                    // Calculate expected value using original logic path
                                                    // For x=-20, original would negate x and set negate flag
                                                    double negatedX = 20.0;
                                                    double expected;
                                                    if (negatedX >= logMaxValue) {
                                                        final double t = FastMath.exp(0.5 * negatedX);
                                                        expected = (-0.5 * t) * t;
                                                    } else {
                                                        expected = -0.5 * FastMath.exp(negatedX);
                                                    }
                                                    
                                                    // The actual result from the method
                                                    double actual = FastMath.sinh(x);
                                                    
                                                    // Verify the result matches the expected calculation path
                                                    // Using delta for floating point comparison
                                                    assertEquals("Test should detect x<-20 vs x<=-20 mutant", expected, actual, 1e-10);
                                                    
                                                    // Additional verification that we're not using the large negative approximation
                                                    // The precise calculation should be different from the approximation
                                                    double approxResult = -0.5 * FastMath.exp(20.0);
                                                    assertNotEquals("Should not use approximation for x=-20", 
                                                                   approxResult, actual, 1e-10);
                                                }

 @Test
                                                public void testSinhNegativeBetween20And1() {
                                                    // Test value between -20 and -10 that would be affected by the mutation
                                                    double x = -15.0;
                                                    
                                                    // Expected value calculated using standard math library
                                                    double expected = -1.6345089E6; // Approximate value of sinh(-15)
                                                    
                                                    // Calculate actual value
                                                    double actual = FastMath.sinh(x);
                                                    
                                                    // Verify the result is correct (with some tolerance for floating point)
                                                    assertEquals("sinh(-15) should use precise calculation", 
                                                                expected, actual, 1.0);
                                                    
                                                    // Additionally verify the result is not using the approximation path
                                                    // The approximation for x < -20 would be -0.5*exp(-x)
                                                    double approxValue = -0.5 * FastMath.exp(-x);
                                                    assertNotEquals("sinh(-15) should not use approximation path", 
                                                                   approxValue, actual, 1.0E6);
                                                }

 @Test
                                          public void testSinhNegativeLogMaxValueBoundary() {
                                              try {
                                                  // Get the private LOG_MAX_VALUE field using reflection
                                                  Field logMaxValueField = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                                  logMaxValueField.setAccessible(true);
                                                  double logMaxValue = logMaxValueField.getDouble(null);
                                                  
                                                  // Get the exact boundary value
                                                  double boundaryValue = -logMaxValue;
                                                  
                                                  // Calculate expected value using the overflow-avoidance path
                                                  double expected;
                                                  final double t = FastMath.exp(0.5 * boundaryValue);
                                                  expected = (-0.5 * t) * t;
                                                  
                                                  // Test the actual implementation
                                                  double actual = FastMath.sinh(boundaryValue);
                                                  
                                                  // Verify it took the correct path by checking against expected value
                                                  assertEquals("Should use overflow-avoidance path when x == -LOG_MAX_VALUE", 
                                                              expected, actual, 1e-15);
                                              } catch (Exception e) {
                                                  fail("Failed to access LOG_MAX_VALUE field: " + e.getMessage());
                                              }
                                          }

 @Test
                                     public void testSinhNegativeValueBetweenThresholds() throws Exception {
                                         // Setup
                                         double x = -21.0; // Value between -20 and -LOG_MAX_VALUE
                                         
                                         // Get the private LOG_MAX_VALUE field using reflection
                                         Field logMaxValueField = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                         logMaxValueField.setAccessible(true);
                                         double LOG_MAX_VALUE = logMaxValueField.getDouble(null);
                                         
                                         // Calculate expected value using original logic (without overflow protection)
                                         double expected = -0.5 * FastMath.exp(-x);
                                         
                                         // Test
                                         double result = FastMath.sinh(x);
                                         
                                         // Verify the result matches expected value without overflow protection
                                         assertEquals(expected, result, 1e-10);
                                         
                                         // Additional verification that we're testing the right case
                                         assertTrue(x < -20);
                                         assertTrue(x > -LOG_MAX_VALUE);
                                     }

 @Test
                                 public void testSinhNegativeLargeValueWithOverflowRisk() {
                                     // Setup: We need a value x where x < -20 and x <= -LOG_MAX_VALUE
                                     // Since LOG_MAX_VALUE is private, we'll use a value that's definitely below it
                                     // Typical LOG_MAX_VALUE is around 709.78, so we'll use -710
                                     
                                     double x = -710.0;
                                     
                                     // Expected calculation based on original code:
                                     // final double t = exp(-0.5 * x); // exp(355)
                                     // expected = (0.5 * t) * t;
                                     // But since we can't directly compute exp(355) due to overflow,
                                     // we'll verify the behavior by checking the calculation path
                                     
                                     // The key point is that with the mutation, the code will compute exp(-x) = exp(710)
                                     // which should overflow, but the original code computes exp(355) which is large but manageable
                                     
                                     try {
                                         double result = FastMath.sinh(x);
                                         
                                         // If we get here with the original code, it means the overflow protection worked
                                         // With the mutated code, we would likely get Infinity or overflow
                                         
                                         // Verify the result is finite (original code path would produce finite result)
                                         assertTrue("Result should be finite for original code", Double.isFinite(result));
                                         
                                         // Additional verification - the result should be negative
                                         assertTrue("Result should be negative", result < 0);
                                         
                                         // Verify the magnitude is very large (as expected for sinh(-710))
                                         assertTrue("Result should be very large negative", result < -1e300);
                                         
                                     } catch (ArithmeticException e) {
                                         // If we get here with mutated code, the test should fail
                                         fail("Mutated code caused overflow when original shouldn't");
                                     }
                                 }

 @Test
                                public void testSinhVeryLargeNegativeValue() {
                                    // Use a value significantly below -LOG_MAX_VALUE to trigger the overflow case
                                    double x = -1000.0;
                                    
                                    // Calculate expected value manually with the correct formula
                                    double t = FastMath.exp(-0.5 * x);
                                    double expected = (-0.5 * t) * t;
                                    
                                    // Call the method
                                    double actual = FastMath.sinh(x);
                                    
                                    // Verify the result matches expected value
                                    assertEquals("Sinh of very large negative value", expected, actual, 1e-10);
                                    
                                    // Additional assertion to specifically catch the mutant
                                    // The mutant would return (-t)*t which is 2*expected
                                    assertFalse("Should detect mutant", Math.abs(2*expected - actual) < 1e-10);
                                }

 @Test
                                   public void testSinhZero2() {
                                       // Test the special case of x = 0
                                       double input = 0.0;
                                       double expected = 0.0;
                                       
                                       // Verify the result is exactly 0 (no delta needed for exact match)
                                       double result = FastMath.sinh(input);
                                       assertEquals("sinh(0) should return exactly 0", expected, result, 0.0);
                                       
                                       // Additional verification that it's not NaN or infinite
                                       assertFalse("sinh(0) should not be NaN", Double.isNaN(result));
                                       assertFalse("sinh(0) should not be infinite", Double.isInfinite(result));
                                   }

 @Test
                                  public void testSinhWithNaN() {
                                      // Test NaN input
                                      double nan = Double.NaN;
                                      double result = FastMath.sinh(nan);
                                      // Original should return NaN, mutant would return 0
                                      assertTrue("Sinh of NaN should be NaN", Double.isNaN(result));
                                      
                                      // Additional edge cases for completeness
                                      double posInf = Double.POSITIVE_INFINITY;
                                      double negInf = Double.NEGATIVE_INFINITY;
                                      
                                      // Test positive infinity
                                      result = FastMath.sinh(posInf);
                                      assertEquals("Sinh of +Inf should be +Inf", posInf, result, 0.0);
                                      
                                      // Test negative infinity
                                      result = FastMath.sinh(negInf);
                                      assertEquals("Sinh of -Inf should be -Inf", negInf, result, 0.0);
                                      
                                      // Test zero
                                      result = FastMath.sinh(0.0);
                                      assertEquals("Sinh of 0 should be 0", 0.0, result, 0.0);
                                  }

 @Test
                             public void testSinhZeroAndNegative() {
                                 // Test x = 0 (should return 0 directly without negation)
                                 double zeroResult = FastMath.sinh(0.0);
                                 assertEquals(0.0, zeroResult, 0.0);
                                 
                                 // Test x = -0.0 (should also return 0 directly without negation)
                                 double negZeroResult = FastMath.sinh(-0.0);
                                 assertEquals(0.0, negZeroResult, 0.0);
                                 
                                 // Test a small negative value to ensure normal negative handling works
                                 double smallNegResult = FastMath.sinh(-0.5);
                                 assertEquals(-0.5210953054937474, smallNegResult, 1e-15);
                                 
                                 // Test a larger negative value
                                 double largerNegResult = FastMath.sinh(-10.0);
                                 assertEquals(-11013.232874703393, largerNegResult, 1e-11);
                             }

 @Test
                                public void testSinhNegativeInput1() {
                                    // Test with a negative value where x < -20 (to test the mutation in different code paths)
                                    double x = -25.0;
                                    double expected = -FastMath.sinh(-x); // manually compute expected value by flipping sign
                                    double actual = FastMath.sinh(x);
                                    
                                    // The mutant would fail this assertion if negate was toggled incorrectly
                                    assertEquals("sinh of negative value should be negated", expected, actual, 1e-10);
                                    
                                    // Additional test with a negative value where -20 < x < -0.25
                                    x = -1.0;
                                    expected = -FastMath.sinh(-x);
                                    actual = FastMath.sinh(x);
                                    assertEquals("sinh of negative value should be negated", expected, actual, 1e-10);
                                    
                                    // Test with a negative value where -0.25 < x < 0
                                    x = -0.1;
                                    expected = -FastMath.sinh(-x);
                                    actual = FastMath.sinh(x);
                                    assertEquals("sinh of negative value should be negated", expected, actual, 1e-10);
                                }

 @Test
                          public void testSinhBoundaryCondition1() {
                              // Test the boundary condition x = 0.25 where the mutation occurs
                              double x = 0.25;
                              
                              // Calculate expected result using public methods
                              // For x = 0.25, we know the correct sinh value
                              double expectedOriginal = 0.2526123168081683; // precomputed value
                              
                              // The actual test - should use the else branch (original behavior)
                              double actual = FastMath.sinh(x);
                              
                              // Verify the result matches the expected original behavior
                              assertEquals(expectedOriginal, actual, 1e-15);
                              
                              // Additional verification that we're testing the right boundary
                              // Test a value slightly above 0.25 to ensure it uses the if branch
                              double xAbove = 0.2500001;
                              double actualAbove = FastMath.sinh(xAbove);
                              assertNotEquals(actual, actualAbove, 1e-15);
                          }

 @Test
                      public void testSinhBoundaryConditionForPrecisionChange() {
                          // Test values around the boundary condition that was mutated
                          // These values are between 0.25 and 0.5 where the behavior changes
                          
                          // Value just above original threshold (0.25)
                          double x1 = 0.26;
                          double expected1 = (Math.exp(x1) - Math.exp(-x1)) / 2;
                          double actual1 = FastMath.sinh(x1);
                          assertEquals("sinh(0.26) should use high precision path", expected1, actual1, 1e-15);
                          
                          // Value in middle of range
                          double x2 = 0.3;
                          double expected2 = (Math.exp(x2) - Math.exp(-x2)) / 2;
                          double actual2 = FastMath.sinh(x2);
                          assertEquals("sinh(0.3) should use high precision path", expected2, actual2, 1e-15);
                          
                          // Value just below mutated threshold (0.5)
                          double x3 = 0.49;
                          double expected3 = (Math.exp(x3) - Math.exp(-x3)) / 2;
                          double actual3 = FastMath.sinh(x3);
                          assertEquals("sinh(0.49) should use high precision path", expected3, actual3, 1e-15);
                          
                          // Negative value in the same range
                          double x4 = -0.3;
                          double expected4 = (Math.exp(x4) - Math.exp(-x4)) / 2;
                          double actual4 = FastMath.sinh(x4);
                          assertEquals("sinh(-0.3) should use high precision path", expected4, actual4, 1e-15);
                      }

 @Test
                    public void testSinhBoundaryAt2() throws Exception {
                        // Test the boundary case x = 20.0
                        double x = 20.0;
                        
                        // Calculate expected value using precise calculation (what original would do)
                        double expected;
                        boolean negate = false;
                        if (x < 0.0) {
                            x = -x;
                            negate = true;
                        }
                        
                        double result;
                        double hiPrec[] = new double[2];
                        
                        // Use reflection to access private exp method
                        Method expMethod = FastMath.class.getDeclaredMethod("exp", double.class, double.class, double[].class);
                        expMethod.setAccessible(true);
                        expMethod.invoke(null, x, 0.0, hiPrec);
                        
                        double ya = hiPrec[0] + hiPrec[1];
                        double yb = -(ya - hiPrec[0] - hiPrec[1]);
                        
                        // Use reflection to access private HEX_40000000 field
                        Field hexField = FastMath.class.getDeclaredField("HEX_40000000");
                        hexField.setAccessible(true);
                        double HEX_40000000 = hexField.getDouble(null);
                        
                        double temp = ya * HEX_40000000;
                        double yaa = ya + temp - temp;
                        double yab = ya - yaa;
                        
                        double recip = 1.0/ya;
                        temp = recip * HEX_40000000;
                        double recipa = recip + temp - temp;
                        double recipb = recip - recipa;
                        
                        recipb += (1.0 - yaa*recipa - yaa*recipb - yab*recipa - yab*recipb) * recip;
                        recipb += -yb * recip * recip;
                        
                        recipa = -recipa;
                        recipb = -recipb;
                        
                        temp = ya + recipa;
                        yb += -(temp - ya - recipa);
                        ya = temp;
                        temp = ya + recipb;
                        yb += -(temp - ya - recipb);
                        ya = temp;
                        
                        result = ya + yb;
                        result *= 0.5;
                        
                        if (negate) {
                            result = -result;
                        }
                        expected = result;
                        
                        // Compare with actual FastMath.sinh
                        double actual = FastMath.sinh(20.0);
                        
                        // The mutant would give a different result (0.5 * exp(20))
                        assertEquals("Test for x=20 boundary case", expected, actual, 1e-10);
                    }

 @Test
               public void testSinhAtLogMaxValue2() {
                   try {
                       // Get the private LOG_MAX_VALUE field from FastMath using reflection
                       Field logMaxValueField = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                       logMaxValueField.setAccessible(true);
                       double logMaxValue = logMaxValueField.getDouble(null);
                       
                       // Calculate expected value using the overflow-avoiding formula
                       double t = FastMath.exp(0.5 * logMaxValue);
                       double expected = (0.5 * t) * t;
                       
                       // Test the method at exactly LOG_MAX_VALUE
                       double actual = FastMath.sinh(logMaxValue);
                       
                       // Verify the result matches the overflow-avoiding calculation
                       assertEquals("sinh(LOG_MAX_VALUE) should use overflow-avoiding calculation", 
                                   expected, actual, 1e-10);
                       
                       // Additional verification that we're not getting the simple calculation
                       double simpleCalculation = 0.5 * FastMath.exp(logMaxValue);
                       assertNotEquals("sinh(LOG_MAX_VALUE) should not use simple calculation",
                                      simpleCalculation, actual, 1e-10);
                   } catch (Exception e) {
                       fail("Failed to access LOG_MAX_VALUE field: " + e.getMessage());
                   }
               }

 @Test
               public void testSinhBoundaryNegative1() {
                   // Test the boundary case where x = -20
                   double x = -20.0;
                   
                   // Calculate expected value using general computation path
                   // (what original code would do)
                   double expectedGeneral = (Math.exp(x) - Math.exp(-x)) / 2;
                   
                   // Calculate what mutated code would produce
                   double expectedMutated = -0.5 * Math.exp(-x);
                   
                   // Actual result from FastMath.sinh
                   double actual = FastMath.sinh(x);
                   
                   // Verify the result matches the general computation path
                   // and not the mutated path
                   assertEquals(expectedGeneral, actual, 1e-10);
                   assertNotEquals(expectedMutated, actual, 1e-10);
                   
                   // Additional verification that we're in the right computation range
                   assertTrue(actual > -1.0); // sinh(-20) is very small but not -infinity
               }

 @Test
          public void testSinhForNegativeValuesBetween20And() {
              // Test a value between -20 and -10 that should use precise calculation
              double x = -15.0;
              
              // Expected value calculated using precise formula
              double expected = (Math.exp(x) - Math.exp(-x)) / 2;
              
              // Actual value from FastMath
              double actual = FastMath.sinh(x);
              
              // Verify the result is correct and not using the approximation
              assertEquals("sinh(-15) should use precise calculation", expected, actual, 1e-10);
              
              // Also test boundary case just above -20
              x = -20.1;
              expected = (Math.exp(x) - Math.exp(-x)) / 2;
              actual = FastMath.sinh(x);
              assertEquals("sinh(-20.1) should use approximation", expected, actual, 1e-10);
              
              // Test boundary case just below -10
              x = -9.9;
              expected = (Math.exp(x) - Math.exp(-x)) / 2;
              actual = FastMath.sinh(x);
              assertEquals("sinh(-9.9) should use precise calculation", expected, actual, 1e-10);
          }

 @Test
         public void testSinhNegativeLogMaxValue1() {
             // Get the LOG_MAX_VALUE constant value using reflection since it's private
             double logMaxValue = 0;
             try {
                 Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                 field.setAccessible(true);
                 logMaxValue = field.getDouble(null);
             } catch (Exception e) {
                 fail("Failed to access LOG_MAX_VALUE field");
             }
             
             // Test with x exactly equal to -LOG_MAX_VALUE
             double x = -logMaxValue;
             
             // Calculate expected result - should use overflow protection branch
             double expected = -0.5 * Math.exp(logMaxValue); // Simplified expected value
             
             // The actual test - this will fail if the mutation is present
             double actual = FastMath.sinh(x);
             
             // Verify the result is finite (no overflow occurred)
             assertTrue("Result should be finite", Double.isFinite(actual));
             
             // Verify the value is approximately correct
             assertEquals(expected, actual, Math.abs(expected) * 1e-10);
         }

 @Test
        public void testSinhNegativeLargeValues() {
            // Get the LOG_MAX_VALUE constant value through reflection since it's private
            double LOG_MAX_VALUE;
            try {
                Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                field.setAccessible(true);
                LOG_MAX_VALUE = field.getDouble(null);
            } catch (Exception e) {
                throw new RuntimeException("Failed to access LOG_MAX_VALUE", e);
            }
        
            // Test case 1: x is exactly -LOG_MAX_VALUE
            double x1 = -LOG_MAX_VALUE;
            double result1 = FastMath.sinh(x1);
            // Should use overflow protection (0.5 * t * t)
            // Just verify it's finite (overflow protection worked)
            assertTrue("Result should be finite", Double.isFinite(result1));
            
            // Test case 2: x is slightly more negative than -LOG_MAX_VALUE
            double x2 = -LOG_MAX_VALUE - 1.0;
            double result2 = FastMath.sinh(x2);
            // Should use overflow protection (0.5 * t * t)
            assertTrue("Result should be finite", Double.isFinite(result2));
            
            // Test case 3: x is negative but not extreme enough for overflow protection
            double x3 = -LOG_MAX_VALUE + 1.0;
            double result3 = FastMath.sinh(x3);
            // Should use regular calculation (-0.5 * exp(-x))
            // Verify it's not using overflow protection by checking against direct calculation
            double expected3 = -0.5 * Math.exp(-x3);
            assertEquals(expected3, result3, Math.ulp(expected3));
            
            // The mutant will incorrectly apply overflow protection in case 3
            // causing result3 to be very different from expected3
        }

 @Test
           public void testSinhNegativeLargeButNotExtreme() {
               // Setup
               double x = -21.0;  // < -20 but > -LOG_MAX_VALUE (which is typically around -709)
               
               // Mock the exp() method since it's used in the calculation
               // We need to mock it to return a predictable value
               FastMath fastMath = spy(FastMath.class);
               doReturn(Math.exp(21.0)).when(fastMath).exp(-x);
               
               // Expected result: -0.5 * exp(-x)
               double expected = -0.5 * Math.exp(21.0);
               
               // Actual result
               double actual = fastMath.sinh(x);
               
               // Assert
               assertEquals("sinh(-21) should use simple calculation", expected, actual, 1e-10);
               
               // Additional verification that we didn't take the overflow protection path
               verify(fastMath, never()).exp(-0.5 * x);  // This would be called in the mutated version
           }

 @Test
          public void testSinhZero3() {
              // Test the special case of x = 0
              double input = 0.0;
              double result = FastMath.sinh(input);
              
              // Should return exactly 0 for input 0
              assertEquals(0.0, result, 0.0);
              
              // Also test negative zero case
              double negativeZero = -0.0;
              double negativeResult = FastMath.sinh(negativeZero);
              assertEquals(0.0, negativeResult, 0.0);
              
              // The result should be exactly equal to input for zero case
              assertTrue(Double.doubleToRawLongBits(input) == Double.doubleToRawLongBits(result));
          }

 @Test
     public void testSinhWithNaNInput1() {
         // Test NaN input
         double nanInput = Double.NaN;
         
         // Original should return NaN, mutant returns 0
         double result = FastMath.sinh(nanInput);
         
         // Verify result is NaN (original behavior)
         assertTrue("Sinh of NaN should return NaN", Double.isNaN(result));
         
         // Additional check that it's not 0 (would pass mutant)
         assertFalse("Sinh of NaN should not return 0", result == 0.0);
     }

 @Test
        public void testSinhWithZeroInput() {
            // Test with x = 0.0 (should return 0.0 directly)
            double result = FastMath.sinh(0.0);
            assertEquals("sinh(0.0) should be 0.0", 0.0, result, 0.0);
            
            // Test with small positive value
            double smallPositive = FastMath.sinh(0.1);
            assertTrue("sinh(0.1) should be positive", smallPositive > 0);
            
            // Test with small negative value
            double smallNegative = FastMath.sinh(-0.1);
            assertTrue("sinh(-0.1) should be negative", smallNegative < 0);
            
            // Verify sinh(-x) == -sinh(x)
            assertEquals("sinh(-0.1) should equal -sinh(0.1)", 
                        -smallPositive, smallNegative, 0.0000001);
        }

 @Test
   public void testSinhNegativeValue() {
       // Test with a simple negative value (-1.0)
       double negativeInput = -1.0;
       double expected = -FastMath.sinh(1.0); // Expected negative of positive equivalent
       double actual = FastMath.sinh(negativeInput);
       
       // Verify the result is negative (would fail with mutant)
       assertEquals("Negative input should produce negative result", expected, actual, 1e-15);
       
       // Test with a larger negative value to ensure different code path
       negativeInput = -5.0;
       expected = -FastMath.sinh(5.0);
       actual = FastMath.sinh(negativeInput);
       assertEquals("Negative input should produce negative result", expected, actual, 1e-15);
       
       // Test with a very small negative value
       negativeInput = -0.1;
       expected = -FastMath.sinh(0.1);
       actual = FastMath.sinh(negativeInput);
       assertEquals("Negative input should produce negative result", expected, actual, 1e-15);
       
       // Test with a very large negative value (exercises different branch)
       negativeInput = -25.0;
       expected = -FastMath.sinh(25.0);
       actual = FastMath.sinh(negativeInput);
       assertEquals("Large negative input should produce negative result", expected, actual, 1e-10);
   }

 @Test
  public void testSinhBoundaryAtQuarter() {
      // Test the boundary condition at x = 0.25
      // Original: should use expm1 path (x > 0.25 is false)
      // Mutant: would use exp path (x >= 0.25 is true)
      
      // Expected value calculated via standard math library
      double expected = (Math.exp(0.25) - Math.exp(-0.25)) / 2;
      
      // Actual value from FastMath
      double actual = FastMath.sinh(0.25);
      
      // Verify the result is correct (should use expm1 path)
      assertEquals("sinh(0.25) should use expm1 path", expected, actual, 1e-15);
      
      // Additionally verify negative case
      double expectedNeg = (Math.exp(-0.25) - Math.exp(0.25)) / 2;
      double actualNeg = FastMath.sinh(-0.25);
      assertEquals("sinh(-0.25) should use expm1 path", expectedNeg, actualNeg, 1e-15);
  }

 @Test
 public void testSinhBoundaryCondition2() {
     // Test a value between 0.25 and 0.5 to catch the mutant
     double x = 0.3;
     
     // Expected value calculated using standard math library
     double expected = (Math.exp(x) - Math.exp(-x)) / 2;
     
     // Actual value from FastMath
     double actual = FastMath.sinh(x);
     
     // Verify the result is correct to within reasonable tolerance
     assertEquals("sinh(0.3) should use exp-based calculation", 
                 expected, actual, 1.0e-15);
     
     // Additional verification that we're in the right calculation path
     // For x=0.3, the original would use exp path, mutant would use expm1 path
     // The results would be different enough to detect the mutant
 }

}
