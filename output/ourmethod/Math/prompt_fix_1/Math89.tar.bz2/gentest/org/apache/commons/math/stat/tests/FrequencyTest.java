package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                                          public void testAddValue_WithComparableObject() {
                                              // Setup
                                              Frequency frequency = new Frequency();
                                              Comparable<String> comparableString = mock(Comparable.class);
                                              
                                              // Test
                                              frequency.addValue(comparableString);
                                              
                                              // Verify - No exception should be thrown
                                              // The actual addition would be verified through other methods like getCount()
                                          }

 @Test
                                          public void testAddValue_WithNonComparableObject() {
                                              // Setup
                                              Frequency frequency = new Frequency();
                                              Object nonComparable = new Object();
                                              
                                              // Expect exception
                                              thrown.expect(IllegalArgumentException.class);
                                              thrown.expectMessage("Object must implement Comparable");
                                              
                                              // Test
                                              frequency.addValue(nonComparable);
                                          }

 @Test
                                          public void testAddValue_WithStringObject() {
                                              // Setup
                                              Frequency frequency = new Frequency();
                                              String testString = "test";
                                              
                                              // Test
                                              frequency.addValue(testString);
                                              
                                              // Verify - No exception should be thrown
                                              assertEquals(1, frequency.getCount(testString));
                                          }

 @Test
                                          public void testAddValue_WithIntegerObject() {
                                              // Setup
                                              Frequency frequency = new Frequency();
                                              Integer testInt = 42;
                                              
                                              // Test
                                              frequency.addValue(testInt);
                                              
                                              // Verify
                                              assertEquals(1, frequency.getCount(testInt));
                                          }

 @Test
                                          public void testAddValue_WithNullObject() {
                                              // Setup
                                              Frequency frequency = new Frequency();
                                              
                                              // Expect exception - null doesn't implement Comparable
                                              thrown.expect(IllegalArgumentException.class);
                                              thrown.expectMessage("Object must implement Comparable");
                                              
                                              // Test
                                              frequency.addValue(null);
                                          }

 @Test
                                          public void testAddValue_WithCustomComparableObject() {
                                              // Setup
                                              Frequency frequency = new Frequency();
                                              Comparable<Object> customComparable = new Comparable<Object>() {
                                                  @Override
                                                  public int compareTo(Object o) {
                                                      return 0;
                                                  }
                                              };
                                              
                                              // Test
                                              frequency.addValue(customComparable);
                                              
                                              // Verify - No exception should be thrown
                                              assertEquals(1, frequency.getCount(customComparable));
                                          }

 @Test
                                          public void testAddValue_WithComparatorInConstructor() {
                                              // Setup
                                              Comparator<String> comparator = mock(Comparator.class);
                                              Frequency frequency = new Frequency(comparator);
                                              String testString = "test";
                                              
                                              // Test
                                              frequency.addValue(testString);
                                              
                                              // Verify - No exception should be thrown
                                              assertEquals(1, frequency.getCount(testString));
                                          }

 @Test
                                          public void testAddValue_IntegerInput() {
                                              Frequency frequency = new Frequency();
                                              Integer value = 5;
                                              
                                              // First addition
                                              frequency.addValue(value);
                                              assertEquals(1L, frequency.getCount(value));
                                              
                                              // Second addition
                                              frequency.addValue(value);
                                              assertEquals(2L, frequency.getCount(value));
                                          }

 @Test
                                          public void testAddValue_IntInput() {
                                              Frequency frequency = new Frequency();
                                              int value = 10;
                                              
                                              frequency.addValue(value);
                                              assertEquals(1L, frequency.getCount(value));
                                              
                                              frequency.addValue(value);
                                              assertEquals(2L, frequency.getCount(value));
                                          }

 @Test
                                          public void testAddValue_LongInput() {
                                              Frequency frequency = new Frequency();
                                              long value = 100L;
                                              
                                              frequency.addValue(value);
                                              assertEquals(1L, frequency.getCount(value));
                                          }

 @Test
                                          public void testAddValue_CharInput() {
                                              Frequency frequency = new Frequency();
                                              char value = 'A';
                                              
                                              frequency.addValue(value);
                                              assertEquals(1L, frequency.getCount(value));
                                          }

 @Test
                                          public void testAddValue_ComparableObject() {
                                              Frequency frequency = new Frequency();
                                              String value = "test";
                                              
                                              frequency.addValue(value);
                                              assertEquals(1L, frequency.getCount(value));
                                          }

 @Test
                                          public void testAddValue_NullInput() {
                                              Frequency frequency = new Frequency();
                                              
                                              thrown.expect(IllegalArgumentException.class);
                                              thrown.expectMessage("Value not comparable to existing values.");
                                              frequency.addValue(null);
                                          }

 @Test
                                          public void testAddValue_NonComparableObject() {
                                              Frequency frequency = new Frequency();
                                              Object nonComparable = new Object();
                                              
                                              thrown.expect(IllegalArgumentException.class);
                                              thrown.expectMessage("Value not comparable to existing values.");
                                              frequency.addValue(nonComparable);
                                          }

 @Test
                                          public void testAddValue_MixedTypesWithComparator() {
                                              Comparator<Object> comparator = (o1, o2) -> 0; // Accepts all types
                                              Frequency frequency = new Frequency(comparator);
                                              
                                              frequency.addValue(1);
                                              frequency.addValue("test");
                                              frequency.addValue(1.5);
                                              
                                              assertEquals(1L, frequency.getCount(1));
                                              assertEquals(1L, frequency.getCount("test"));
                                              assertEquals(1L, frequency.getCount(1.5));
                                          }

 @Test
                                          public void testAddValue_IntegerConversion() {
                                              Frequency frequency = new Frequency();
                                              Integer value = Integer.MAX_VALUE;
                                              
                                              frequency.addValue(value);
                                              // Verify it was stored as Long
                                              assertEquals(1L, frequency.getCount((long)value));
                                          }

 @Test
                                          public void testAddValue_ExistingValueIncrement() {
                                              Frequency frequency = new Frequency();
                                              String value = "existing";
                                              
                                              frequency.addValue(value);
                                              frequency.addValue(value);
                                              frequency.addValue(value);
                                              
                                              assertEquals(3L, frequency.getCount(value));
                                          }

 @Test
                                          public void testAddValue_WithCustomComparator() {
                                              Comparator<String> reverseComparator = (s1, s2) -> s2.compareTo(s1);
                                              Frequency frequency = new Frequency(reverseComparator);
                                              String value = "test";
                                              
                                              frequency.addValue(value);
                                              assertEquals(1L, frequency.getCount(value));
                                          }

 @Test
                                          public void testAddValue_Long_AddsNewValueToEmptyTable() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(5L);
                                              
                                              assertEquals(1, frequency.getCount(5L));
                                              assertEquals(1, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_IncrementsExistingValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(10L);
                                              frequency.addValue(10L);
                                              
                                              assertEquals(2, frequency.getCount(10L));
                                              assertEquals(2, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_HandlesMultipleDifferentValues() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(1L);
                                              frequency.addValue(2L);
                                              frequency.addValue(1L);
                                              frequency.addValue(3L);
                                              
                                              assertEquals(2, frequency.getCount(1L));
                                              assertEquals(1, frequency.getCount(2L));
                                              assertEquals(1, frequency.getCount(3L));
                                              assertEquals(4, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_HandlesZeroValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(0L);
                                              frequency.addValue(0L);
                                              
                                              assertEquals(2, frequency.getCount(0L));
                                              assertEquals(2, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_HandlesNegativeValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(-100L);
                                              frequency.addValue(-100L);
                                              frequency.addValue(-200L);
                                              
                                              assertEquals(2, frequency.getCount(-100L));
                                              assertEquals(1, frequency.getCount(-200L));
                                              assertEquals(3, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_HandlesMaxLongValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(Long.MAX_VALUE);
                                              
                                              assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                              assertEquals(1, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_HandlesMinLongValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(Long.MIN_VALUE);
                                              
                                              assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                              assertEquals(1, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_WorksWithCustomComparator() {
                                              Comparator<Long> reverseComparator = (a, b) -> Long.compare(b, a);
                                              Frequency frequency = new Frequency(reverseComparator);
                                              
                                              frequency.addValue(100L);
                                              frequency.addValue(200L);
                                              frequency.addValue(100L);
                                              
                                              assertEquals(2, frequency.getCount(100L));
                                              assertEquals(1, frequency.getCount(200L));
                                              assertEquals(3, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_AfterClearOperation() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(5L);
                                              frequency.clear();
                                              frequency.addValue(10L);
                                              
                                              assertEquals(0, frequency.getCount(5L));
                                              assertEquals(1, frequency.getCount(10L));
                                              assertEquals(1, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_AddsNewValueToEmptyTable1() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(5L);
                                              
                                              assertEquals(1, frequency.getCount(5L));
                                              assertEquals(1, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_IncrementsExistingValue1() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(10L);
                                              frequency.addValue(10L);
                                              
                                              assertEquals(2, frequency.getCount(10L));
                                              assertEquals(2, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_MultipleDifferentValues() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(1L);
                                              frequency.addValue(2L);
                                              frequency.addValue(1L);
                                              frequency.addValue(3L);
                                              
                                              assertEquals(2, frequency.getCount(1L));
                                              assertEquals(1, frequency.getCount(2L));
                                              assertEquals(1, frequency.getCount(3L));
                                              assertEquals(4, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_ZeroValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(0L);
                                              frequency.addValue(0L);
                                              frequency.addValue(0L);
                                              
                                              assertEquals(3, frequency.getCount(0L));
                                              assertEquals(3, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_NegativeValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(-5L);
                                              frequency.addValue(-5L);
                                              frequency.addValue(-10L);
                                              
                                              assertEquals(2, frequency.getCount(-5L));
                                              assertEquals(1, frequency.getCount(-10L));
                                              assertEquals(3, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_MaxValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(Long.MAX_VALUE);
                                              
                                              assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                              assertEquals(1, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_MinValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(Long.MIN_VALUE);
                                              
                                              assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                              assertEquals(1, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_WithCustomComparator() {
                                              Comparator<Long> reverseComparator = (a, b) -> Long.compare(b, a);
                                              Frequency frequency = new Frequency(reverseComparator);
                                              
                                              frequency.addValue(5L);
                                              frequency.addValue(10L);
                                              frequency.addValue(5L);
                                              
                                              assertEquals(2, frequency.getCount(5L));
                                              assertEquals(1, frequency.getCount(10L));
                                              assertEquals(3, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Long_AfterClear() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(1L);
                                              frequency.addValue(2L);
                                              frequency.clear();
                                              frequency.addValue(3L);
                                              
                                              assertEquals(0, frequency.getCount(1L));
                                              assertEquals(0, frequency.getCount(2L));
                                              assertEquals(1, frequency.getCount(3L));
                                              assertEquals(1, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_NewLongValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(5L);
                                              assertEquals(1, frequency.getCount(5L));
                                          }

 @Test
                                          public void testAddValue_ExistingLongValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(10L);
                                              frequency.addValue(10L);
                                              assertEquals(2, frequency.getCount(10L));
                                          }

 @Test
                                          public void testAddValue_MultipleDifferentLongValues() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(1L);
                                              frequency.addValue(2L);
                                              frequency.addValue(3L);
                                              assertEquals(1, frequency.getCount(1L));
                                              assertEquals(1, frequency.getCount(2L));
                                              assertEquals(1, frequency.getCount(3L));
                                          }

 @Test
                                          public void testAddValue_ZeroValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(0L);
                                              assertEquals(1, frequency.getCount(0L));
                                          }

 @Test
                                          public void testAddValue_NegativeValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(-100L);
                                              assertEquals(1, frequency.getCount(-100L));
                                          }

 @Test
                                          public void testAddValue_LongMaxValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(Long.MAX_VALUE);
                                              assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                          }

 @Test
                                          public void testAddValue_LongMinValue() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(Long.MIN_VALUE);
                                              assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                          }

 @Test
                                          public void testAddValue_WithCustomComparator1() {
                                              Comparator<Long> reverseComparator = (o1, o2) -> o2.compareTo(o1);
                                              Frequency frequency = new Frequency(reverseComparator);
                                              
                                              frequency.addValue(5L);
                                              frequency.addValue(10L);
                                              frequency.addValue(5L);
                                              
                                              assertEquals(2, frequency.getCount(5L));
                                              assertEquals(1, frequency.getCount(10L));
                                          }

 @Test
                                          public void testAddValue_AfterClear() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(20L);
                                              frequency.clear();
                                              frequency.addValue(30L);
                                              assertEquals(0, frequency.getCount(20L));
                                              assertEquals(1, frequency.getCount(30L));
                                          }

 @Test
                                          public void testAddValue_MixedWithOtherAddMethods() {
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(100L);  // long version
                                              frequency.addValue(new Long(100));  // Object version
                                              frequency.addValue(100);    // int version
                                              assertEquals(3, frequency.getCount(100L));
                                          }

 @Test
                                          public void testAddValue_Char_AddSingleCharacter() {
                                              Frequency frequency = new Frequency();
                                              char testChar = 'a';
                                              
                                              frequency.addValue(testChar);
                                              
                                              assertEquals(1, frequency.getCount(testChar));
                                              assertEquals(1, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Char_AddMultipleSameCharacters() {
                                              Frequency frequency = new Frequency();
                                              char testChar = 'b';
                                              
                                              frequency.addValue(testChar);
                                              frequency.addValue(testChar);
                                              frequency.addValue(testChar);
                                              
                                              assertEquals(3, frequency.getCount(testChar));
                                              assertEquals(3, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Char_AddDifferentCharacters() {
                                              Frequency frequency = new Frequency();
                                              char char1 = 'x';
                                              char char2 = 'y';
                                              char char3 = 'z';
                                              
                                              frequency.addValue(char1);
                                              frequency.addValue(char2);
                                              frequency.addValue(char3);
                                              frequency.addValue(char2);
                                              
                                              assertEquals(1, frequency.getCount(char1));
                                              assertEquals(2, frequency.getCount(char2));
                                              assertEquals(1, frequency.getCount(char3));
                                              assertEquals(4, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Char_AddSpecialCharacters() {
                                              Frequency frequency = new Frequency();
                                              char space = ' ';
                                              char newline = '\n';
                                              char tab = '\t';
                                              
                                              frequency.addValue(space);
                                              frequency.addValue(newline);
                                              frequency.addValue(tab);
                                              
                                              assertEquals(1, frequency.getCount(space));
                                              assertEquals(1, frequency.getCount(newline));
                                              assertEquals(1, frequency.getCount(tab));
                                              assertEquals(3, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Char_WithCustomComparator() {
                                              Comparator<Character> caseInsensitiveComparator = (c1, c2) -> 
                                                  Character.toLowerCase(c1) - Character.toLowerCase(c2);
                                              Frequency frequency = new Frequency(caseInsensitiveComparator);
                                              
                                              frequency.addValue('A');
                                              frequency.addValue('a');
                                              frequency.addValue('B');
                                              
                                              assertEquals(2, frequency.getCount('A'));
                                              assertEquals(2, frequency.getCount('a'));
                                              assertEquals(1, frequency.getCount('B'));
                                              assertEquals(3, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Char_AfterClear() {
                                              Frequency frequency = new Frequency();
                                              char testChar = 'c';
                                              
                                              frequency.addValue(testChar);
                                              frequency.clear();
                                              frequency.addValue(testChar);
                                              
                                              assertEquals(1, frequency.getCount(testChar));
                                              assertEquals(1, frequency.getSumFreq());
                                          }

 @Test
                                          public void testAddValue_Char_UnicodeCharacters() {
                                              Frequency frequency = new Frequency();
                                              char euro = '€';
                                              char chinese = '中';
                                              
                                              frequency.addValue(euro);
                                              frequency.addValue(chinese);
                                              frequency.addValue(euro);
                                              
                                              assertEquals(2, frequency.getCount(euro));
                                              assertEquals(1, frequency.getCount(chinese));
                                              assertEquals(3, frequency.getSumFreq());
                                          }

 @Test
                                      public void testAddValueWithNullShouldNotCheckInstanceOf() {
                                          Frequency frequency = new Frequency();
                                          
                                          // Set expectation for the original behavior (would pass null to addValue(Comparable))
                                          // No exception expected in original version
                                          
                                          // For mutated version, we expect IllegalArgumentException
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("Object must implement Comparable");
                                          
                                          // Test with null input
                                          frequency.addValue((Object)null);
                                          
                                          // If we reach here in original version, the test passes (mutant not detected)
                                          // If mutated version is present, the exception will be thrown and caught by ExpectedException
                                      }

 @Test
                                      public void testAddValueWithNonComparableShouldThrowException() {
                                          Frequency frequency = new Frequency();
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("Object must implement Comparable");
                                          
                                          // Test with non-Comparable object
                                          frequency.addValue(new Object());
                                      }

 @Test
                                      public void testAddValueWithComparableShouldPass() {
                                          Frequency frequency = new Frequency();
                                          
                                          // Test with Comparable object (should pass in both original and mutated versions)
                                          frequency.addValue("test string"); // String implements Comparable
                                          
                                          // If we reach here, the test passes
                                          // No assertion needed as we're testing it doesn't throw exception
                                      }

 @Test(expected = NullPointerException.class)
                                      public void testAddValueWithNullShouldThrowNPE() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          
                                          // This should throw NullPointerException in original code
                                          // If it doesn't throw, the mutant survived
                                          frequency.addValue((Object)null);
                                          
                                          // If we reach here, the mutant survived (null check was added)
                                          fail("Expected NullPointerException but none was thrown");
                                      }

 @Test
                                      public void testAddValueWithNullShouldNotModifyFrequencyTable() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          
                                          try {
                                              frequency.addValue((Object)null);
                                              fail("Expected NullPointerException but none was thrown");
                                          } catch (NullPointerException e) {
                                              // Expected behavior for original code
                                          }
                                          
                                          // Additional verification that freqTable wasn't modified
                                          assertEquals(0, frequency.getSumFreq());
                                      }

 @Test(expected = NullPointerException.class)
                                      public void testAddValueWithNullShouldThrowException() {
                                          Frequency frequency = new Frequency();
                                          // This should throw NullPointerException in original code
                                          // but would pass silently in mutated code
                                          frequency.addValue((Object)null);
                                      }

 @Test
                                      public void testAddValueWithNullShouldThrowNPE1() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          
                                          // Expect NPE to be thrown
                                          thrown.expect(NullPointerException.class);
                                          
                                          // Execute with null input
                                          frequency.addValue((Object)null);
                                      }

 @Test
                                      public void testAddValueWithNullShouldNotThrowException() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          
                                          // Test null value - should be handled gracefully
                                          frequency.addValue((Object)null);
                                          
                                          // Verify the null was not added to the frequency table
                                          assertEquals(0, frequency.getCount(null));
                                      }

 @Test
                                      public void testAddValueWithNonNullComparable() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          Long testValue = 123L;
                                          
                                          // Test with non-null Comparable
                                          frequency.addValue(testValue);
                                          
                                          // Verify the value was added to the frequency table
                                          assertEquals(1, frequency.getCount(testValue));
                                      }

 @Test(expected = NullPointerException.class)
                                      public void testAddValueCharacterWithNullShouldThrowException() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          Character nullChar = null;
                                          
                                          // This should throw NullPointerException in original code
                                          // Mutated version would not throw exception
                                          frequency.addValue(nullChar);
                                          
                                          // If we reach here in original code, the test fails
                                          // For mutated code, it would reach here but we expect exception
                                      }

 @Test
                                 public void testAddValueCharacterWithNullShouldNotModifyFrequencyTable() throws Exception {
                                     // Setup
                                     Frequency frequency = new Frequency();
                                     
                                     // Get original freqTable using reflection
                                     Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                     freqTableField.setAccessible(true);
                                     @SuppressWarnings("unchecked")
                                     TreeMap<Comparable<?>, Long> originalTable = new TreeMap<>(
                                         (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency)
                                     );
                                     
                                     Character nullChar = null;
                                     
                                     try {
                                         frequency.addValue(nullChar);
                                         // If we reach here, it's the mutated version
                                         @SuppressWarnings("unchecked")
                                         TreeMap<Comparable<?>, Long> currentTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                                         assertEquals("Frequency table should not change when adding null", 
                                                     originalTable, currentTable);
                                     } catch (NullPointerException e) {
                                         // This is expected for original code
                                         // Test will pass for original code
                                     }
                                 }

 @Test
                                 public void testAddValueWithComparableShouldNotThrowException() {
                                     // Setup
                                     Frequency frequency = new Frequency();
                                     Comparable<?> mockComparable = mock(Comparable.class);
                                     
                                     // Test - should not throw exception for Comparable input
                                     try {
                                         frequency.addValue(mockComparable);
                                         // Verify the specialized method was called
                                         // This assertion would fail with the mutant since it would throw exception instead
                                         verify(frequency).addValue(mockComparable);
                                     } catch (IllegalArgumentException e) {
                                         fail("Should not throw exception for Comparable input");
                                     }
                                 }

 @Test(expected = IllegalArgumentException.class)
                                 public void testAddValueWithNonComparableShouldThrowException1() {
                                     // Setup
                                     Frequency frequency = new Frequency();
                                     Object nonComparable = new Object();
                                     
                                     // Test - should throw exception
                                     frequency.addValue(nonComparable);
                                 }

 @Test(expected = IllegalArgumentException.class)
                                 public void testAddValueWithNonComparableObject() {
                                     // Create a Frequency instance
                                     Frequency frequency = new Frequency();
                                     
                                     // Create a non-comparable object
                                     Object nonComparable = new Object() {
                                         @Override
                                         public String toString() {
                                             return "NonComparableObject";
                                         }
                                     };
                                     
                                     // This should throw IllegalArgumentException in original code
                                     // But will throw ClassCastException or nothing in mutant
                                     frequency.addValue(nonComparable);
                                 }

 @Test
                                 public void testAddValueWithComparableObject() {
                                     // Create a Frequency instance
                                     Frequency frequency = new Frequency();
                                     
                                     // Create a comparable object (String is Comparable)
                                     String comparable = "test";
                                     
                                     try {
                                         frequency.addValue(comparable);
                                         // Verify the count was updated
                                         assertEquals(1L, frequency.getCount(comparable));
                                     } catch (Exception e) {
                                         fail("Should not throw exception for comparable objects");
                                     }
                                 }

 @Test
                                 public void testAddValueWithNonComparableObject1() {
                                     // Create test objects
                                     Frequency frequency = new Frequency();
                                     Object nonComparable = new Object(); // Object doesn't implement Comparable
                                     
                                     try {
                                         // Call the method with non-Comparable object
                                         frequency.addValue(nonComparable);
                                         
                                         // Verify the object wasn't added to freqTable (original behavior)
                                         assertEquals(0, frequency.getCount(nonComparable));
                                         assertEquals(0, frequency.getSumFreq());
                                     } catch (Exception e) {
                                         // If we get here, the mutant was detected (it tried to process non-Comparable)
                                         fail("Mutant detected - method threw exception with non-Comparable input");
                                     }
                                 }

 @Test
                                 public void testAddValueWithComparableShouldAddToFrequencyTable() {
                                     // Setup
                                     Frequency frequency = new Frequency();
                                     Long testValue = 123L;
                                     
                                     // Action
                                     frequency.addValue(testValue);
                                     
                                     // Verification
                                     // Original code would have count = 1, mutant would have count = 0
                                     assertEquals("Comparable value should be added to frequency table", 
                                                  1L, frequency.getCount(testValue));
                                 }

 @Test
                                 public void testAddValueCharShouldAddToFrequencyTable() {
                                     // Setup
                                     Frequency frequency = new Frequency();
                                     char testChar = 'a';
                                     
                                     // Execute
                                     frequency.addValue(testChar);
                                     
                                     // Verify
                                     // Original version would have count=1, mutated version would have count=0
                                     assertEquals("Character should be added to frequency table", 
                                                  1L, frequency.getCount(testChar));
                                     
                                     // Additional verification that the value exists in the table
                                     assertEquals("Character should be added to frequency table", 
                                                  1L, frequency.getCount(Character.valueOf(testChar)));
                                 }

 @Test
                            public void testAddValueWithComparableObject1() {
                                // Setup
                                Frequency frequency = new Frequency();
                                String comparableValue = "testValue"; // String implements Comparable
                                
                                // Action
                                frequency.addValue(comparableValue);
                                
                                // Verification
                                try {
                                    Field field = Frequency.class.getDeclaredField("freqTable");
                                    field.setAccessible(true);
                                    TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                                    
                                    // The original code would have added the value, mutant would skip
                                    assertTrue("Comparable value should be in freqTable", 
                                        freqTable.containsKey(comparableValue));
                                    assertEquals("Count should be 1 for new value", 
                                        1L, (long)freqTable.get(comparableValue));
                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                    fail("Failed to access freqTable field: " + e.getMessage());
                                }
                            }

 @Test
                            public void testAddValueWithComparableObject2() {
                                // Create test objects
                                Frequency frequency = new Frequency();
                                Comparable<Integer> comparable = Integer.valueOf(123);
                                
                                try {
                                    // Call the method with Comparable object
                                    frequency.addValue(comparable);
                                    
                                    // Verify the object was added to freqTable
                                    assertEquals(1, frequency.getCount(comparable));
                                    assertEquals(1, frequency.getSumFreq());
                                } catch (Exception e) {
                                    fail("Method threw unexpected exception with Comparable input");
                                }
                            }

 @Test(expected = IllegalArgumentException.class)
                            public void testAddValueWithNonComparableObject2() {
                                // Create an object that doesn't implement Comparable
                                Object nonComparable = new Object();
                                
                                // Create a Frequency instance
                                Frequency frequency = new Frequency();
                                
                                // This should throw IllegalArgumentException in the original code
                                // The mutant would call addValue(Object) directly without throwing
                                frequency.addValue(nonComparable);
                            }

 @Test
                            public void testAddValueWithComparableObject3() {
                                // Create a mock Comparable object
                                Comparable<String> comparable = mock(Comparable.class);
                                
                                // Create a Frequency instance
                                Frequency frequency = new Frequency();
                                
                                // This should work fine in both original and mutated code
                                frequency.addValue(comparable);
                                
                                // Verify the object was added (assuming addValue(Comparable) updates freqTable)
                                assertTrue(frequency.getCount(comparable) > 0);
                            }

 @Test(expected = IllegalArgumentException.class)
                            public void testAddValueWithNonComparableObject3() {
                                // Create a non-comparable object
                                class NonComparable {}
                                Object nonComparable = new NonComparable();
                                
                                // Create frequency instance
                                Frequency frequency = new Frequency();
                                
                                try {
                                    frequency.addValue(nonComparable);
                                    fail("Expected IllegalArgumentException for non-comparable object");
                                } catch (IllegalArgumentException e) {
                                    // Verify the exception message comes from our explicit check, not TreeMap
                                    assertEquals("Value not comparable to existing values.", e.getMessage());
                                    throw e; // rethrow for the expected exception
                                }
                            }

 @Test
                            public void testAddValueWithComparableObject4() {
                                // Create a comparable object (String)
                                String comparable = "test";
                                
                                // Create frequency instance
                                Frequency frequency = new Frequency();
                                
                                // Should not throw exception
                                frequency.addValue(comparable);
                                
                                // Verify the count was incremented
                                assertEquals(1, frequency.getCount(comparable));
                            }

 @Test
                            public void testAddValueCallsComparableVersion() {
                                // Create a mock Frequency object
                                Frequency frequency = mock(Frequency.class);
                                
                                // Test value that needs to be cast to Comparable
                                Object testValue = 123L; // Using Long value
                                
                                // Call the method that should cast to Comparable
                                // This would be the original code's behavior
                                frequency.addValue((Comparable<?>) testValue);
                                
                                // Verify the correct method was called
                                verify(frequency).addValue((Comparable<?>) testValue);
                                
                                // The mutant version would fail this test because it would call:
                                // frequency.addValue(testValue) instead
                                // which would be a different method call
                            }

 @Test
                            public void testAddValueWithNonComparable() {
                                // Create a real Frequency object
                                Frequency frequency = new Frequency();
                                
                                // Create a non-Comparable object
                                Object nonComparable = new Object() {
                                    @Override
                                    public String toString() {
                                        return "NonComparable";
                                    }
                                };
                                
                                try {
                                    // Original code would cast to Comparable and fail
                                    frequency.addValue((Comparable<?>) nonComparable);
                                    // If we get here, the test should fail
                                    org.junit.Assert.fail("Expected ClassCastException");
                                } catch (ClassCastException e) {
                                    // Expected behavior for original code
                                }
                                
                                // Mutant version would call addValue(Object) which might work differently
                                // This test helps detect if the casting behavior changed
                            }

 @Test
                            public void testAddValueWithNonComparableNumber() {
                                // Create a custom Number implementation that doesn't implement Comparable
                                class NonComparableNumber extends Number {
                                    private final long value;
                                    
                                    public NonComparableNumber(long value) {
                                        this.value = value;
                                    }
                                    
                                    @Override
                                    public int intValue() {
                                        return (int)value;
                                    }
                                    
                                    @Override
                                    public long longValue() {
                                        return value;
                                    }
                                    
                                    @Override
                                    public float floatValue() {
                                        return value;
                                    }
                                    
                                    @Override
                                    public double doubleValue() {
                                        return value;
                                    }
                                }
                                
                                Frequency frequency = new Frequency();
                                Number testValue = new NonComparableNumber(42L);
                                
                                try {
                                    // This should work in original version (converts to Long)
                                    frequency.addValue(testValue);
                                    
                                    // Verify the value was added correctly
                                    assertEquals(1L, frequency.getCount(42L));
                                } catch (ClassCastException e) {
                                    // This indicates the mutant was caught - it tried to add the raw value
                                    fail("Mutant detected: Method tried to add non-Comparable value directly");
                                }
                            }

 @Test
                        public void testAddValueWithNonComparableObject4() {
                            // Create a non-Comparable object
                            Object nonComparable = new Object() {
                                @Override
                                public String toString() {
                                    return "testObject";
                                }
                            };
                            
                            // Create a mock Frequency object to verify method calls
                            Frequency frequency = mock(Frequency.class);
                            
                            // Call the method - in original version this would cast to Comparable first
                            // In mutated version it would call addValue(Object) directly
                            try {
                                // This is the line that would be in the production code
                                frequency.addValue((Comparable<?>) nonComparable);
                            } catch (ClassCastException e) {
                                // Expected in original version since we can't cast to Comparable
                            }
                            
                            // Verify behavior
                            verify(frequency, never()).addValue(nonComparable); // Original should never call this
                            verify(frequency, never()).addValue(any(Comparable.class)); // Original would try but fail
                            
                            // Now test the mutated version's behavior
                            reset(frequency);
                            frequency.addValue(nonComparable); // This is what the mutant does
                            
                            // Verify the mutant calls addValue(Object) directly
                            verify(frequency).addValue(nonComparable);
                            verify(frequency, never()).addValue(any(Comparable.class));
                        }

 @Test
                            public void testAddValueCharCallsCorrectOverload() {
                                // Create a spy of the Frequency class to verify method calls
                                Frequency frequency = spy(new Frequency());
                                
                                // Test with a character value
                                char testChar = 'a';
                                frequency.addValue(testChar);
                                
                                // Verify that addValue(Character) was called, not the raw value version
                                verify(frequency).addValue(Character.valueOf(testChar));
                                
                                // Also verify the value was actually added to the frequency table
                                assertEquals(1, frequency.getCount(testChar));
                            }

 @Test(expected = IllegalArgumentException.class)
                           public void testAddValueWithNonComparableObject5() {
                               // Create a Frequency instance
                               Frequency frequency = new Frequency();
                               
                               // Create a non-Comparable object
                               Object nonComparable = new Object();
                               
                               try {
                                   // This should throw IllegalArgumentException in original code
                                   frequency.addValue(nonComparable);
                               } catch (IllegalArgumentException e) {
                                   // Verify the exception message
                                   assertEquals("Value not comparable to existing values.", e.getMessage());
                                   throw e; // rethrow to satisfy expected exception
                               }
                               
                               // The mutant would either:
                               // 1. Not throw the exception (fail the test)
                               // 2. Throw a different exception like NullPointerException (fail the test)
                           }

 @Test
                           public void testAddValueWithComparableObject5() {
                               // Create a Frequency instance
                               Frequency frequency = new Frequency();
                               
                               // Add a Comparable object (String)
                               String comparable = "test";
                               frequency.addValue(comparable);
                               
                               // Verify it was added correctly
                               assertEquals(1, frequency.getCount(comparable));
                           }

 @Test
                           public void testAddValueWithInteger() {
                               // Create a Frequency instance
                               Frequency frequency = new Frequency();
                               
                               // Add an Integer (should be converted to Long)
                               Integer value = 5;
                               frequency.addValue(value);
                               
                               // Verify it was converted and counted
                               assertEquals(1, frequency.getCount(5L));
                           }

 @Test
                       public void testAddValueShouldNotPassNull() {
                           // Setup
                           Frequency frequency = new Frequency();
                           Object testValue = 5L; // Using a Long value
                           
                           // Action
                           frequency.addValue(testValue);
                           
                           // Verification
                           // Verify the actual value was counted
                           assertEquals(1L, frequency.getCount(testValue));
                           
                           // Verify null wasn't counted
                           assertEquals(0L, frequency.getCount(null));
                           
                           // Verify total count is correct
                           assertEquals(1L, frequency.getSumFreq());
                           
                           // Verify the value exists in the table (indirectly)
                           assertTrue(frequency.getPct(testValue) > 0);
                       }

 @Test
                       public void testAddValueCharDetectsNullMutation() {
                           // Setup
                           Frequency frequency = new Frequency();
                           char testChar = 'a';
                           
                           // Exercise
                           frequency.addValue(testChar);
                           
                           // Verify
                           // Original behavior should count the character, mutant would count null
                           assertEquals("Character count should be 1", 1, frequency.getCount(testChar));
                           assertEquals("Null count should be 0", 0, frequency.getCount(null));
                           
                           // Additional verification using getPct to be thorough
                           assertEquals("Character percentage should be 100%", 1.0, frequency.getPct(testChar), 0.0001);
                           assertEquals("Null percentage should be 0%", 0.0, frequency.getPct(null), 0.0001);
                       }

 @Test
                      public void testAddValueWithComparableShouldCallAddValueWithActualObject() {
                          // Arrange
                          Comparable<String> testValue = "testValue";
                          Frequency frequency = new Frequency();
                          
                          // Create a mock for the frequency table
                          @SuppressWarnings("unchecked")
                          TreeMap<Comparable<?>, Long> mockFreqTable = mock(TreeMap.class);
                          
                          // Use reflection to inject the mock into the frequency object
                          try {
                              Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                              freqTableField.setAccessible(true);
                              freqTableField.set(frequency, mockFreqTable);
                          } catch (Exception e) {
                              fail("Failed to inject mock frequency table");
                          }
                          
                          // Act
                          frequency.addValue(testValue);
                          
                          // Assert
                          // Verify that addValue was called with the actual object, not null
                          verify(mockFreqTable).put(eq(testValue), anyLong());
                      }

 @Test(expected = IllegalArgumentException.class)
                      public void testAddValueWithNonComparableShouldThrowException2() {
                          // Arrange
                          Frequency frequency = new Frequency();
                          Object nonComparable = new Object();
                          
                          // Act & Assert
                          frequency.addValue(nonComparable);
                      }

 @Test
                      public void testAddValueShouldNotAcceptNull() {
                          // Setup
                          Frequency frequency = new Frequency();
                          Object testValue = null;
                          
                          // Action - this should either throw an exception or maintain empty freqTable
                          try {
                              frequency.addValue(testValue);
                              
                              // If no exception thrown, verify freqTable wasn't modified
                              Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                              freqTableField.setAccessible(true);
                              @SuppressWarnings("unchecked")
                              TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                              assertTrue("Frequency table should remain empty after adding null", 
                                        freqTable.isEmpty());
                          } catch (NullPointerException e) {
                              // This is acceptable behavior
                              assertTrue(true);
                          } catch (IllegalArgumentException e) {
                              // Also acceptable behavior
                              assertTrue(true);
                          } catch (NoSuchFieldException | IllegalAccessException e) {
                              fail("Failed to access freqTable field: " + e.getMessage());
                          }
                      }

 @Test
                      public void testAddValueWithNonNull() {
                          // Setup
                          Frequency frequency = new Frequency();
                          Comparable<Long> testValue = 5L; // Using a Long value
                          
                          // Action
                          frequency.addValue(testValue);
                          
                          // Verification
                          try {
                              Field field = Frequency.class.getDeclaredField("freqTable");
                              field.setAccessible(true);
                              @SuppressWarnings("unchecked")
                              TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                              assertEquals("Frequency table should have one entry", 1, freqTable.size());
                              assertEquals("Count should be 1 for added value", 
                                          Long.valueOf(1), freqTable.get(testValue));
                          } catch (Exception e) {
                              fail("Reflection failed: " + e.getMessage());
                          }
                      }

 @Test
                      public void testAddValueShouldAddActualValueNotNull() {
                          // Setup
                          Frequency frequency = new Frequency();
                          Integer testValue = 5;
                          
                          // Action
                          frequency.addValue(testValue);
                          
                          // Verification
                          // Verify the count for this value is 1 (which implicitly verifies it was added)
                          assertEquals("Count for test value should be 1", 
                              1L, frequency.getCount(testValue));
                      }

 @Test(expected = IllegalArgumentException.class)
                      public void testAddValueObjectWithNonComparable() {
                          // Setup
                          Frequency frequency = new Frequency();
                          Object nonComparableValue = new Object(); // Object doesn't implement Comparable
                          
                          // Test - should throw exception
                          frequency.addValue(nonComparableValue);
                      }

 @Test
                  public void testAddValueWithComparableShouldHandleComparableSpecially() {
                      // Setup
                      Frequency frequency = new Frequency();
                      Comparable<String> comparableValue = "testValue"; // String implements Comparable
                      
                      // Test
                      frequency.addValue(comparableValue);
                      
                      // Verify
                      // If the mutation is present, the count would be 1 (treated as regular Object)
                      // Original code would handle it through addValue(Comparable) which might have different behavior
                      assertEquals("Comparable value should be counted once", 1L, frequency.getCount(comparableValue));
                      
                      // Add another to verify increment works
                      frequency.addValue(comparableValue);
                      assertEquals("Comparable value count should increment", 2L, frequency.getCount(comparableValue));
                      
                      // Verify it's properly stored in the TreeMap (would throw ClassCastException if not Comparable)
                      try {
                          frequency.addValue(new Object()); // Non-comparable object
                          fail("Should throw IllegalArgumentException for non-comparable objects");
                      } catch (IllegalArgumentException e) {
                          assertEquals("Value not comparable to existing values.", e.getMessage());
                      }
                  }

 @Test
                  public void testAddValueLongDetectsMutant() {
                      // Create frequency object
                      Frequency freq = new Frequency();
                      
                      // Add a long value that would be affected by the mutation
                      long testValue = 12345L;
                      freq.addValue(testValue);
                      
                      // Verify the value was added correctly by checking count
                      // If mutation is present, this might throw ClassCastException or return 0
                      assertEquals("Value should be present in frequency table", 
                                   1L, freq.getCount(testValue));
                      
                      // Additional check to ensure the correct overload was called
                      // If mutation is present, this might return different results
                      assertEquals("Value should be present when queried as Object", 
                                   1L, freq.getCount((Object)testValue));
                  }

 @Test(expected = NumberFormatException.class)
                      public void testAddValueWithNonNumberComparable() {
                          // Create a mock Comparable that isn't a Number
                          Comparable<String> nonNumberComparable = mock(Comparable.class);
                          when(nonNumberComparable.toString()).thenReturn("abc");
                          
                          Frequency frequency = new Frequency();
                          
                          // This should throw NumberFormatException in the mutated version
                          // because it tries to convert "abc" to Long
                          frequency.addValue(nonNumberComparable);
                          
                          // If the mutation is present (commented out Comparable path),
                          // the test will pass because it throws the expected exception
                          // If the original code is present, it would handle the Comparable
                          // without throwing an exception, causing the test to fail
                      }

 @Test
                      public void testAddValueLongDetectsMutant1() {
                          // Setup
                          Frequency frequency = new Frequency();
                          long testValue = 12345L;
                          
                          // Action
                          frequency.addValue(testValue);
                          
                          // Verification
                          // Original behavior would have count = 1, mutant would have count = 0
                          assertEquals("Value should be added to frequency table", 
                                       1L, frequency.getCount(testValue));
                          
                          // Additional verification that the value was added as a Long object
                          assertEquals("Value should be added as Long object", 
                                       1L, frequency.getCount(Long.valueOf(testValue)));
                      }

 @Test
                  public void testAddValueCharShouldIncrementCount() {
                      // Setup
                      Frequency frequency = new Frequency();
                      char testChar = 'a';
                      
                      // Action
                      frequency.addValue(testChar);
                      
                      // Verification
                      assertEquals("Character count should be 1 after adding", 1, frequency.getCount(testChar));
                  }

 @Test
                 public void testAddValueObjectWithComparable() {
                     // Setup
                     Frequency frequency = new Frequency();
                     String comparableValue = "testValue"; // String implements Comparable
                     
                     // Test
                     frequency.addValue((Object)comparableValue);
                     
                     // Verify the value was added to freqTable
                     try {
                         Field field = Frequency.class.getDeclaredField("freqTable");
                         field.setAccessible(true);
                         @SuppressWarnings("unchecked")
                         TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                         assertTrue("Comparable value should be in freqTable", 
                             freqTable.containsKey(comparableValue));
                         assertEquals("Count should be 1", 
                             1L, (long)freqTable.get(comparableValue));
                     } catch (NoSuchFieldException | IllegalAccessException e) {
                         fail("Failed to access freqTable field: " + e.getMessage());
                     }
                 }

 @Test
             public void testAddValueObjectShouldTrackActualValueNotDummyObject() {
                 // Setup
                 Frequency frequency = new Frequency();
                 Integer testValue = 42;
                 
                 // Action
                 frequency.addValue(testValue);
                 
                 // Verification
                 // Check that the actual value was tracked, not a dummy object
                 Long count = frequency.getCount(testValue);
                 assertEquals("Count should be 1 for the added value", 1L, count.longValue());
                 
                 // Additional check to ensure it's tracking the Long version of the Integer
                 Long longValue = Long.valueOf(testValue);
                 count = frequency.getCount(longValue);
                 assertEquals("Count should be 1 for the Long version of the value", 1L, count.longValue());
                 
                 // Verify no dummy objects were inserted
                 assertEquals("Should only have one entry in freqTable", 1, frequency.getSumFreq());
             }

 @Test
             public void testAddValueLongShouldAddToFrequencyTable() {
                 // Setup
                 Frequency frequency = new Frequency();
                 long testValue = 123L;
                 
                 // Test original behavior
                 frequency.addValue(testValue);
                 
                 // Verify the value was properly added
                 assertEquals(1L, frequency.getCount(testValue));
                 assertEquals(1L, frequency.getSumFreq());
                 
                 // Test that mutated version would fail
                 try {
                     // This simulates what the mutated code would do
                     frequency.addValue((Comparable<?>) new Object());
                     fail("Expected ClassCastException when adding non-Comparable object");
                 } catch (ClassCastException e) {
                     // Expected behavior - TreeMap would throw when trying to compare
                 }
                 
                 // Verify original value is still intact
                 assertEquals(1L, frequency.getCount(testValue));
                 assertEquals(1L, frequency.getSumFreq());
             }

 @Test
             public void testAddValueObjectWithLongShouldStoreCorrectValue() {
                 // Setup
                 Frequency frequency = new Frequency();
                 Long testValue = 12345L;
                 
                 // Execute
                 frequency.addValue((Object) testValue);
                 
                 // Verify
                 // The mutation would fail here because it tries to add an Object instead of our Long
                 assertEquals(1L, frequency.getCount(testValue));
                 
                 // Additional verification that the exact value was stored
                 // This would fail with the mutant since it stores a different object
                 assertEquals(1L, frequency.getCount(12345L));
             }

 @Test
             public void testAddValueCharDetectsMutant() {
                 // Setup
                 Frequency frequency = new Frequency();
                 char testChar = 'a';
                 
                 // Action - add the character twice
                 frequency.addValue(testChar);
                 frequency.addValue(testChar);
                 
                 // Verification
                 // Original behavior: count should be 2 for 'a'
                 assertEquals("Character count should be 2", 2, frequency.getCount(testChar));
                 
                 // Mutant check: 
                 // The mutant would add Object() instead, so:
                 // 1. testChar count would be 0
                 // 2. Total count would be 2 but we can't verify what was added
                 // 3. Alternatively, we could verify no ClassCastException occurred
                 
                 // Additional verification that sum of frequencies matches expected
                 assertEquals("Total count should be 2", 2, frequency.getSumFreq());
             }

 @Test
            public void testAddValueObjectPassesCorrectComparable() {
                // Create a Frequency instance
                Frequency frequency = new Frequency();
                
                // Create a test Comparable object
                Comparable<String> testComparable = mock(Comparable.class);
                
                // Call the method under test
                frequency.addValue(testComparable);
                
                // Verify the correct object was passed to the specialized method
                // Note: Since we're testing a real object, not a mock, we can't verify interactions
                // Instead, we should verify the state change
                assertEquals(1, frequency.getCount(testComparable));
            }

 @Test
            public void testAddValueLongShouldStoreActualValue() {
                // Setup
                Frequency frequency = new Frequency();
                Long testValue = 12345L;
                
                // Action
                frequency.addValue(testValue);
                
                // Verification
                // Verify the freqTable contains exactly our test value
                // We can do this by checking the count for our test value is 1
                assertEquals(1L, frequency.getCount(testValue));
                
                // Additionally verify no other values were added by checking sum of frequencies
                assertEquals(1L, frequency.getSumFreq());
                
                // Verify the key in the table is our testValue by checking count is 1
                assertEquals(1L, frequency.getCount(testValue));
            }

 @Test
            public void testAddValueWithNullShouldThrowException1() {
                Frequency frequency = new Frequency();
                
                // Set up expectation for the original behavior
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("Object must implement Comparable");
                
                // This test will fail on the mutated version since null would bypass the exception
                frequency.addValue(null);
            }

 @Test
            public void testAddValueWithNonComparableShouldThrowException3() {
                Frequency frequency = new Frequency();
                
                // Test with a non-Comparable, non-null object
                Object nonComparable = new Object();
                
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("Object must implement Comparable");
                
                frequency.addValue(nonComparable);
            }

 @Test
            public void testAddValueWithComparableShouldNotThrow() {
                Frequency frequency = new Frequency();
                
                // Test with a Comparable object (using String which implements Comparable)
                frequency.addValue("test string");
                
                // No exception should be thrown
                // Additional verification could check if value was added to freqTable
            }

 @Test
            public void testAddValueNullIncrement() {
                // Setup
                Frequency frequency = new Frequency();
                TreeMap<Object, Long> freqTable = new TreeMap<>();
                
                // Using reflection to access private field for testing (alternative would be to check via getCount)
                try {
                    java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                    field.setAccessible(true);
                    field.set(frequency, freqTable);
                } catch (Exception e) {
                    fail("Failed to set up test due to reflection error");
                }
                
                // First add null (count will be 1)
                freqTable.put(null, 1L);
                
                // Test adding null again - should increment to 2
                frequency.addValue(null);
                
                // Verify
                assertEquals("Count should be 2 for null after increment", 
                    Long.valueOf(2), freqTable.get(null));
            }

 @Test
            public void testAddValueLongWithNull() {
                // Setup
                Frequency frequency = new Frequency();
                TreeMap<Long, Long> spyMap = spy(new TreeMap<Long, Long>());
                
                // Use reflection to inject the spy into the Frequency object
                try {
                    java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                    field.setAccessible(true);
                    field.set(frequency, spyMap);
                } catch (Exception e) {
                    fail("Failed to inject spy into Frequency object");
                }
                
                // Test null value
                frequency.addValue((Long)null);
                
                // Verify the behavior
                verify(spyMap, never()).put(any(), any()); // Original would call put in else branch
                verify(spyMap, never()).containsKey(any()); // Mutant would skip entirely
                
                // Additional assertion to check state
                assertEquals(0, frequency.getCount((Long)null));
            }

 @Test
            public void testAddValueLongWithNull1() {
                // Setup
                Frequency frequency = new Frequency();
                TreeMap<Long, Long> spyMap = spy(new TreeMap<Long, Long>());
                
                // Use reflection to inject the spy since freqTable is private
                try {
                    java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                    field.setAccessible(true);
                    field.set(frequency, spyMap);
                } catch (Exception e) {
                    fail("Failed to inject spy into freqTable");
                }
                
                // Test null value
                frequency.addValue((Long)null);
                
                // Verify the map was not modified (original behavior would handle null in else block)
                verify(spyMap, never()).put(any(), any());
                verify(spyMap, never()).merge(any(), any(), any());
                
                // Also verify no interactions at all (in case implementation uses different methods)
                verifyNoInteractions(spyMap);
            }

 @Test
            public void testAddValueLong_NullInput() {
                // Create a fresh Frequency object
                Frequency frequency = new Frequency();
                
                // Add a null value
                frequency.addValue((Long)null);
                
                // Verify the null was counted (original behavior)
                // The mutant would skip counting nulls
                assertEquals("Null value should be counted", 1, frequency.getCount((Object)null));
                
                // Also verify the sum frequency reflects the addition
                assertEquals("Total count should be 1", 1, frequency.getSumFreq());
            }

 @Test
            public void testAddValueCharShouldAddToFrequencyTable1() {
                // Setup
                Frequency frequency = new Frequency();
                char testChar = 'a';
                
                // Action
                frequency.addValue(testChar);
                
                // Verification
                assertEquals(1L, frequency.getCount(testChar));
                // Verify the value was added by checking count
                // This would fail if the mutated else-if prevented adding
            }

 @Test
            public void testAddValueCharShouldIncrementExistingCount() {
                // Setup
                Frequency frequency = new Frequency();
                char testChar = 'b';
                frequency.addValue(testChar); // Add once first
                
                // Action
                frequency.addValue(testChar); // Add again
                
                // Verification
                assertEquals(2L, frequency.getCount(testChar));
                // Verify count increments properly
                // This would fail if the mutated else-if prevented adding
            }

 @Test
           public void testAddValueWithSameComparableTypes() {
               // Setup
               Frequency frequency = new Frequency();
               
               // Add two Strings (same Comparable type)
               frequency.addValue("test1");
               frequency.addValue("test2");
               
               // Verify counts were properly incremented
               assertEquals(1L, frequency.getCount("test1"));
               assertEquals(1L, frequency.getCount("test2"));
           }

 @Test
       public void testAddValueCharPreservesGenericTypeInformation() {
           // Setup
           Frequency frequency = new Frequency();
           char testChar = 'a';
           
           // Action
           frequency.addValue(testChar);
           
           // Verification
           // Get the underlying TreeMap through reflection to verify the type information
           try {
               Field freqTableField = Frequency.class.getDeclaredField("freqTable");
               freqTableField.setAccessible(true);
               TreeMap<?, ?> freqTable = (TreeMap<?, ?>) freqTableField.get(frequency);
               
               // Verify the key is of type Character (not raw Comparable)
               for (Object key : freqTable.keySet()) {
                   assertTrue("Key should be of type Character", key instanceof Character);
                   assertFalse("Key should not be raw Comparable", key instanceof Comparable && 
                       key.getClass().getTypeParameters().length == 0);
               }
               
               // Verify the count is correct
               assertEquals(1L, frequency.getCount(testChar));
           } catch (Exception e) {
               fail("Reflection failed: " + e.getMessage());
           }
       }

 @Test
      public void testAddValueWithGenericComparable() {
          // Create a frequency instance and mock comparable object
          Frequency frequency = mock(Frequency.class);
          Comparable<Integer> comparableInt = mock(Comparable.class);
          
          // Call the method under test
          frequency.addValue(comparableInt);
          
          // Verify the correct overloaded method was called with proper generic type
          verify(frequency).addValue((Comparable<?>) comparableInt);
          
          // The mutant would fail this verification because it would call 
          // addValue(Comparable) instead of addValue(Comparable<?>)
      }

 @Test
      public void testAddValueWithRawComparable() {
          // Initialize frequency object
          Frequency frequency = new Frequency();
          
          // Create a raw comparable object
          Comparable rawComparable = mock(Comparable.class);
          
          // Call the method under test
          frequency.addValue(rawComparable);
          
          // Verify the correct overloaded method was called
          verify(frequency).addValue((Comparable<?>) rawComparable);
      }

 @Test
      public void testAddValueWithDifferentComparableTypes() {
          // Setup
          org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
          
          // First add a String value (which is Comparable)
          frequency.addValue("test");
          
          // Then try to add a Date (which is also Comparable but shouldn't be comparable with String)
          // This should throw IllegalArgumentException in original code
          // But mutant might allow it due to raw Comparable type
          try {
              frequency.addValue(new java.util.Date());
              // If we reach here, the mutant survived
              fail("Expected IllegalArgumentException for incompatible Comparable types");
          } catch (IllegalArgumentException e) {
              // Expected exception
          }
      }

 @Test
      public void testAddValueWithLongShouldCallSpecificOverload() throws Exception {
          // Create a spy of Frequency to verify method calls
          Frequency frequencySpy = spy(new Frequency());
          
          // Create a TreeMap spy to verify the actual storage
          TreeMap<Comparable<?>, Long> treeMapSpy = spy(new TreeMap<>());
          
          // Use reflection to set the private freqTable field
          Field freqTableField = Frequency.class.getDeclaredField("freqTable");
          freqTableField.setAccessible(true);
          freqTableField.set(frequencySpy, treeMapSpy);
          
          long testValue = 123L;
          
          // Call the method
          frequencySpy.addValue(Long.valueOf(testValue));
          
          // Verify the correct overload was called
          verify(frequencySpy).addValue(eq(testValue)); // Verify long overload was called
          
          // Also verify the value was actually put in the map
          verify(treeMapSpy).put(eq(testValue), anyLong());
          
          // Additional verification that the raw Comparable version wasn't called
          verify(frequencySpy, never()).addValue(any(Comparable.class));
      }

 @Test
      public void testAddValueWithNonNumberComparable1() {
          // Create a custom Comparable that isn't a Number
          class CustomComparable implements Comparable<CustomComparable> {
              private final String value;
              
              public CustomComparable(String value) {
                  this.value = value;
              }
              
              @Override
              public int compareTo(CustomComparable o) {
                  return this.value.compareTo(o.value);
              }
              
              @Override
              public boolean equals(Object obj) {
                  if (!(obj instanceof CustomComparable)) return false;
                  return this.value.equals(((CustomComparable)obj).value);
              }
          }
          
          Frequency frequency = new Frequency();
          CustomComparable input = new CustomComparable("test");
          
          // This should work with both original and mutated code,
          // but the mutation loses type safety information
          frequency.addValue(input);
          
          // Verify the value was added correctly
          assertEquals(1L, frequency.getCount(input));
          
          // Verify the type was preserved in the frequency table using reflection
          try {
              Field freqTableField = Frequency.class.getDeclaredField("freqTable");
              freqTableField.setAccessible(true);
              TreeMap<?, ?> table = (TreeMap<?, ?>) freqTableField.get(frequency);
              assertTrue(table.containsKey(input));
          } catch (NoSuchFieldException | IllegalAccessException e) {
              fail("Failed to access freqTable field: " + e.getMessage());
          }
      }

 @Test
      public void testAddValueLongWithGenericSafety() {
          // Create a frequency object with a custom comparator that checks generic type safety
          Frequency frequency = new Frequency(new Comparator<Comparable<Long>>() {
              @Override
              public int compare(Comparable<Long> o1, Comparable<Long> o2) {
                  // This will throw ClassCastException if raw types are used
                  return o1.compareTo((Long)o2);
              }
          });
          
          long testValue = 12345L;
          
          // This should work fine with the original code but might fail with the mutant
          frequency.addValue(testValue);
          
          // Verify the value was added correctly
          assertEquals(1L, frequency.getCount(testValue));
          
          // Test with another comparable to ensure generic safety
          frequency.addValue(67890L);
          assertEquals(1L, frequency.getCount(67890L));
      }

 @Test
      public void testAddValueObjectWithNonComparable1() {
          Frequency frequency = new Frequency();
          Object nonComparable = new Object(); // Object doesn't implement Comparable
          
          try {
              frequency.addValue(nonComparable);
              fail("Expected IllegalArgumentException");
          } catch (IllegalArgumentException e) {
              assertEquals("Object must implement Comparable", e.getMessage());
          } catch (RuntimeException e) {
              fail("Should only throw IllegalArgumentException");
          }
      }

 @Test
      public void testAddValueObjectWithComparable1() {
          Frequency frequency = new Frequency();
          Comparable<String> comparable = "test"; // String implements Comparable
          
          try {
              frequency.addValue(comparable); // Should not throw any exception
          } catch (RuntimeException e) {
              fail("Should not throw any RuntimeException for Comparable objects");
          }
      }

 @Test
      public void testAddValueExceptionDeclarations() throws Exception {
          // Get the method via reflection
          Method method = Frequency.class.getMethod("addValue", Object.class);
          
          // Verify it doesn't declare RuntimeException in throws clause
          Class<?>[] exceptionTypes = method.getExceptionTypes();
          for (Class<?> exceptionType : exceptionTypes) {
              assertFalse("Method should not declare RuntimeException",
                         RuntimeException.class.isAssignableFrom(exceptionType));
          }
          
          // Verify it declares IllegalArgumentException
          boolean declaresIllegalArgumentException = false;
          for (Class<?> exceptionType : exceptionTypes) {
              if (IllegalArgumentException.class.isAssignableFrom(exceptionType)) {
                  declaresIllegalArgumentException = true;
                  break;
              }
          }
          assertTrue("Method should declare IllegalArgumentException", 
                    declaresIllegalArgumentException);
      }

 @Test
      public void testAddValueWithNonComparableObject6() {
          Frequency frequency = new Frequency();
          Object nonComparable = new Object(); // Object is not Comparable
          
          try {
              frequency.addValue(nonComparable);
              fail("Expected IllegalArgumentException");
          } catch (Exception e) {
              assertTrue("Should throw IllegalArgumentException",
                        e instanceof IllegalArgumentException);
              assertFalse("Should not throw RuntimeException",
                         e instanceof RuntimeException);
          }
      }

 @Test
      public void testAddValueObjectDoesNotThrowException() {
          // Setup
          Frequency frequency = new Frequency();
          Object testValue = new Object(); // Any non-null object
          
          // Exercise and Verify
          try {
              frequency.addValue(testValue);
              // If we get here, the test passes (no exception thrown)
          } catch (RuntimeException e) {
              fail("addValue(Object) should not throw RuntimeException");
          }
          
          // Additional verification that the value was actually added
          assertTrue(frequency.getCount(testValue) > 0);
      }

 @Test
      public void testAddValueObject_ValidInput() {
          Frequency frequency = new Frequency();
          // Test with valid Long input
          frequency.addValue(Long.valueOf(5L));
          // Verify the value was added by checking count
          assertEquals(1L, frequency.getCount(5L));
      }

 @Test
      public void testAddValueObject_InvalidInput() {
          Frequency frequency = new Frequency();
          // Test with invalid input that might cause RuntimeException
          // This will catch the mutant if it throws RuntimeException
          frequency.addValue(new Object());
          // If no exception is thrown, the test passes (original behavior)
          // If exception is thrown, the mutant is detected
      }

 @Test
      public void testAddValueObject_NullInput() {
          Frequency frequency = new Frequency();
          // Test with null input
          thrown.expect(NullPointerException.class);
          frequency.addValue(null);
      }

 @Test
      public void testAddValueObjectDoesNotThrowException1() {
          // Setup
          Frequency frequency = new Frequency();
          Object testValue = new Object();
          
          // Test - should not throw exception in original version
          try {
              frequency.addValue(testValue);
              // If we get here, test passes (original behavior)
          } catch (RuntimeException e) {
              // If we get here, test fails (mutated behavior)
              fail("addValue(Object) should not throw RuntimeException");
          }
          
          // Verify the value was added
          assertTrue(frequency.getCount(testValue) > 0);
      }

 @Test(expected = RuntimeException.class)
      public void testAddValueObjectThrowsRuntimeException() {
          // Setup
          Frequency frequency = new Frequency();
          // Create a mock object that will cause RuntimeException when added
          Object problematicValue = new Object() {
              @Override
              public boolean equals(Object obj) {
                  throw new RuntimeException("Test exception");
              }
              
              @Override
              public int hashCode() {
                  throw new RuntimeException("Test exception");
              }
          };
          
          // Test - should throw RuntimeException in mutated version
          frequency.addValue(problematicValue);
      }

 @Test
      public void testAddValueObjectShouldNotThrowException() {
          // Setup
          Frequency frequency = new Frequency();
          Character testChar = 'a';
          
          // Exercise and Verify
          try {
              frequency.addValue(testChar);
              // If we get here, the test passes - no exception was thrown
          } catch (RuntimeException e) {
              fail("addValue(Object) should not throw RuntimeException for valid Character input");
          }
          
          // Additional verification that the value was actually added
          assertEquals("Character should be added to frequency table", 
                      1L, frequency.getCount(testChar));
      }

 @Test
      public void testAddValueObjectWithNullShouldNotThrowException() {
          // Setup
          Frequency frequency = new Frequency();
          
          // Exercise and Verify
          try {
              frequency.addValue(null);
              // If we get here, the test passes - no exception was thrown
          } catch (RuntimeException e) {
              fail("addValue(Object) should not throw RuntimeException for null input");
          }
          
          // Additional verification that null was handled (assuming the class handles null)
          assertEquals("Null should be handled properly", 
                      1L, frequency.getCount(null));
      }

 @Test
 public void testAddValueWithComparableShouldNotThrowException1() {
     // Setup
     Frequency frequency = new Frequency();
     String comparableValue = "test"; // String implements Comparable
     
     try {
         // Exercise
         frequency.addValue(comparableValue);
         
         // Verify - if we get here, the test passes (no exception thrown)
         // Additional verification that the value was actually added
         long count = frequency.getCount(comparableValue);
         assertEquals("Comparable value should have been added", 1, count);
     } catch (IllegalArgumentException e) {
         fail("Should not throw IllegalArgumentException for Comparable object");
     }
 }

 @Test(expected = IllegalArgumentException.class)
 public void testAddValueWithNonComparableShouldThrowException4() {
     // Setup
     Frequency frequency = new Frequency();
     Object nonComparableValue = new Object(); // Object doesn't implement Comparable
     
     // Exercise & Verify
     frequency.addValue(nonComparableValue);
 }

 @Test(expected = IllegalArgumentException.class)
     public void testAddValueWithNonComparableObject7() {
         // Create a Frequency object
         Frequency frequency = new Frequency();
         
         // Create a non-comparable object
         Object nonComparable = new Object() {
             @Override
             public String toString() {
                 return "NonComparableObject";
             }
         };
         
         // This should throw IllegalArgumentException in original code
         // Mutated code would throw ClassCastException (from TreeMap) which is wrapped in IllegalArgumentException
         frequency.addValue(nonComparable);
         
         // If we reach here, the test fails (no exception was thrown)
         fail("Expected IllegalArgumentException for non-comparable object");
     }

 @Test
     public void testAddValueWithComparableObject6() {
         // Create a Frequency object
         Frequency frequency = new Frequency();
         
         // Create a comparable object (String implements Comparable)
         String comparable = "testString";
         
         try {
             frequency.addValue(comparable);
             // If no exception is thrown, the test passes
             // Verify the count was incremented
             assertEquals(1L, frequency.getCount(comparable));
         } catch (Exception e) {
             fail("Should not throw exception for comparable object");
         }
     }

 @Test
     public void testAddValueWithComparableObjectShouldAddToFrequencyTable() {
         // Setup
         Frequency frequency = new Frequency();
         Long testValue = Long.valueOf(123L);
         
         // Execute
         frequency.addValue(testValue);
         
         // Verify
         // Check if the value was added to freqTable by getting its count
         long count = frequency.getCount(testValue);
         assertEquals("Comparable object should be added to frequency table", 1, count);
         
         // Additional verification by checking the TreeMap directly
         // Since freqTable is private, we use the public getCount method
         // If the mutation is present, getCount would return 0 instead of 1
     }

 @Test
 public void testAddValueWithComparableObjectShouldHandleSpecially() {
     // Setup
     Frequency frequency = new Frequency();
     Long testValue = 123L; // Long implements Comparable
     
     // Action
     frequency.addValue(testValue);
     
     // Verification
     // If the mutant is present, getCount would return 0 since the value wasn't properly added
     assertEquals("Comparable object should be properly added to frequency table", 
                  1L, frequency.getCount(testValue));
     
     // Additional check to verify it was added to the underlying table
     assertEquals("Frequency sum should reflect the added value", 
                  1L, frequency.getSumFreq());
 }

 @Test
 public void testAddValueWithComparableShouldAddToFrequencyTable1() {
     // Setup
     Frequency frequency = new Frequency();
     Long testValue = 123L;
     
     // Action
     frequency.addValue(testValue);
     
     // Verification
     // Original code should have count=1, mutant will have count=0
     assertEquals("Comparable value should be added to frequency table", 
         1L, frequency.getCount(testValue));
 }

 @Test
 public void testAddValue_CharacterShouldBeHandledAsComparable() {
     // Setup
     Frequency frequency = new Frequency();
     char testChar = 'a';
     
     // Action
     frequency.addValue(testChar);
     
     // Verification
     // Verify the character was counted (would fail with mutant)
     assertEquals(1L, frequency.getCount(testChar));
     
     // Verify it's treated as Comparable by checking cumulative frequency
     // (would also fail with mutant if special Comparable handling affects this)
     assertEquals(1L, frequency.getCumFreq(testChar));
 }

}
