package gentest.org.apache.commons.math3.analysis.differentiation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.analysis.differentiation.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class DSCompilerTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                                                  public void testAtan2_PositiveX() {
                                                      // Setup
                                                      DSCompiler compiler = mock(DSCompiler.class);
                                                      when(compiler.getSize()).thenReturn(2);
                                                      
                                                      double[] y = {1.0, 0.5};
                                                      int yOffset = 0;
                                                      double[] x = {1.0, 0.3};
                                                      int xOffset = 0;
                                                      double[] result = new double[2];
                                                      int resultOffset = 0;
                                                      
                                                      // Mock the required method calls
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(4);
                                                          res[0] = x[0] * x[0]; // x^2
                                                          res[1] = x[1] * x[1];
                                                          return null;
                                                      }).when(compiler).multiply(eq(x), eq(xOffset), eq(x), eq(xOffset), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(4);
                                                          res[0] = y[0] * y[0]; // y^2
                                                          res[1] = y[1] * y[1];
                                                          return null;
                                                      }).when(compiler).multiply(eq(y), eq(yOffset), eq(y), eq(yOffset), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(4);
                                                          res[0] = x[0] * x[0] + y[0] * y[0]; // x^2 + y^2
                                                          res[1] = x[1] * x[1] + y[1] * y[1];
                                                          return null;
                                                      }).when(compiler).add(any(double[].class), eq(0), any(double[].class), eq(0), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(3);
                                                          res[0] = Math.sqrt(x[0] * x[0] + y[0] * y[0]); // r = sqrt(x^2 + y^2)
                                                          res[1] = Math.sqrt(x[1] * x[1] + y[1] * y[1]);
                                                          return null;
                                                      }).when(compiler).rootN(any(double[].class), eq(0), eq(2), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(4);
                                                          double r = Math.sqrt(x[0] * x[0] + y[0] * y[0]);
                                                          res[0] = r + x[0]; // r + x
                                                          res[1] = Math.sqrt(x[1] * x[1] + y[1] * y[1]) + x[1];
                                                          return null;
                                                      }).when(compiler).add(any(double[].class), eq(0), eq(x), eq(xOffset), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(4);
                                                          res[0] = y[0] / (Math.sqrt(x[0] * x[0] + y[0] * y[0]) + x[0]); // y/(r + x)
                                                          res[1] = y[1] / (Math.sqrt(x[1] * x[1] + y[1] * y[1]) + x[1]);
                                                          return null;
                                                      }).when(compiler).divide(eq(y), eq(yOffset), any(double[].class), eq(0), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(3);
                                                          double val = y[0] / (Math.sqrt(x[0] * x[0] + y[0] * y[0]) + x[0]);
                                                          res[0] = Math.atan(val); // atan(y/(r + x))
                                                          res[1] = Math.atan(y[1] / (Math.sqrt(x[1] * x[1] + y[1] * y[1]) + x[1]));
                                                          return null;
                                                      }).when(compiler).atan(any(double[].class), eq(0), any(double[].class), eq(0));
                                                      
                                                      // Execute
                                                      compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                      
                                                      // Verify
                                                      assertEquals(2 * Math.atan(y[0] / (Math.sqrt(x[0] * x[0] + y[0] * y[0]) + x[0])), result[0], 1e-10);
                                                      assertEquals(2 * Math.atan(y[1] / (Math.sqrt(x[1] * x[1] + y[1] * y[1]) + x[1])), result[1], 1e-10);
                                                      assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-10);
                                                  }

 @Test
                                                  public void testAtan2_NegativeX_PositiveY() {
                                                      // Setup
                                                      DSCompiler compiler = mock(DSCompiler.class);
                                                      when(compiler.getSize()).thenReturn(2);
                                                      
                                                      double[] y = {1.0, 0.5};
                                                      int yOffset = 0;
                                                      double[] x = {-1.0, -0.3};
                                                      int xOffset = 0;
                                                      double[] result = new double[2];
                                                      int resultOffset = 0;
                                                      
                                                      // Mock the required method calls
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(4);
                                                          res[0] = x[0] * x[0]; // x^2
                                                          res[1] = x[1] * x[1];
                                                          return null;
                                                      }).when(compiler).multiply(eq(x), eq(xOffset), eq(x), eq(xOffset), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(4);
                                                          res[0] = y[0] * y[0]; // y^2
                                                          res[1] = y[1] * y[1];
                                                          return null;
                                                      }).when(compiler).multiply(eq(y), eq(yOffset), eq(y), eq(yOffset), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(4);
                                                          res[0] = x[0] * x[0] + y[0] * y[0]; // x^2 + y^2
                                                          res[1] = x[1] * x[1] + y[1] * y[1];
                                                          return null;
                                                      }).when(compiler).add(any(double[].class), eq(0), any(double[].class), eq(0), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(3);
                                                          res[0] = Math.sqrt(x[0] * x[0] + y[0] * y[0]); // r = sqrt(x^2 + y^2)
                                                          res[1] = Math.sqrt(x[1] * x[1] + y[1] * y[1]);
                                                          return null;
                                                      }).when(compiler).rootN(any(double[].class), eq(0), eq(2), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(4);
                                                          double r = Math.sqrt(x[0] * x[0] + y[0] * y[0]);
                                                          res[0] = r - x[0]; // r - x
                                                          res[1] = Math.sqrt(x[1] * x[1] + y[1] * y[1]) - x[1];
                                                          return null;
                                                      }).when(compiler).subtract(any(double[].class), eq(0), eq(x), eq(xOffset), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(4);
                                                          res[0] = y[0] / (Math.sqrt(x[0] * x[0] + y[0] * y[0]) - x[0]); // y/(r - x)
                                                          res[1] = y[1] / (Math.sqrt(x[1] * x[1] + y[1] * y[1]) - x[1]);
                                                          return null;
                                                      }).when(compiler).divide(eq(y), eq(yOffset), any(double[].class), eq(0), any(double[].class), eq(0));
                                                      
                                                      doAnswer(invocation -> {
                                                          double[] res = invocation.getArgument(3);
                                                          double val = y[0] / (Math.sqrt(x[0] * x[0] + y[0] * y[0]) - x[0]);
                                                          res[0] = Math.atan(val); // atan(y/(r - x))
                                                          res[1] = Math.atan(y[1] / (Math.sqrt(x[1] * x[1] + y[1] * y[1]) - x[1]));
                                                          return null;
                                                      }).when(compiler).atan(any(double[].class), eq(0), any(double[].class), eq(0));
                                                      
                                                      // Execute
                                                      compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                                                      
                                                      // Verify
                                                      assertEquals(FastMath.PI - 2 * Math.atan(y[0] / (Math.sqrt(x[0] * x[0] + y[0] * y[0]) - x[0])), result[0], 1e-10);
                                                      assertEquals(-2 * Math.atan(y[1] / (Math.sqrt(x[1] * x[1] + y[1] * y[1]) - x[1])), result[1], 1e-10);
                                                      assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-10);
                                                  }

 @Test
                                                  public void testAtan2_SpecialCases() {
                                                      // Setup
                                                      DSCompiler compiler = mock(DSCompiler.class);
                                                      when(compiler.getSize()).thenReturn(1);
                                                      
                                                      // Test +0/+0
                                                      double[] y1 = {0.0};
                                                      double[] x1 = {0.0};
                                                      double[] result1 = new double[1];
                                                      compiler.atan2(y1, 0, x1, 0, result1, 0);
                                                      assertEquals(FastMath.atan2(0.0, 0.0), result1[0], 1e-10);
                                                      
                                                      // Test +0/-0
                                                      double[] y2 = {0.0};
                                                      double[] x2 = {-0.0};
                                                      double[] result2 = new double[1];
                                                      compiler.atan2(y2, 0, x2, 0, result2, 0);
                                                      assertEquals(FastMath.atan2(0.0, -0.0), result2[0], 1e-10);
                                                      
                                                      // Test -0/+0
                                                      double[] y3 = {-0.0};
                                                      double[] x3 = {0.0};
                                                      double[] result3 = new double[1];
                                                      compiler.atan2(y3, 0, x3, 0, result3, 0);
                                                      assertEquals(FastMath.atan2(-0.0, 0.0), result3[0], 1e-10);
                                                      
                                                      // Test -0/-0
                                                      double[] y4 = {-0.0};
                                                      double[] x4 = {-0.0};
                                                      double[] result4 = new double[1];
                                                      compiler.atan2(y4, 0, x4, 0, result4, 0);
                                                      assertEquals(FastMath.atan2(-0.0, -0.0), result4[0], 1e-10);
                                                      
                                                      // Test +infinity/+infinity
                                                      double[] y5 = {Double.POSITIVE_INFINITY};
                                                      double[] x5 = {Double.POSITIVE_INFINITY};
                                                      double[] result5 = new double[1];
                                                      compiler.atan2(y5, 0, x5, 0, result5, 0);
                                                      assertEquals(FastMath.atan2(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY), result5[0], 1e-10);
                                                  }

 @Test
                                                  public void testAtan2_NullArrays() {
                                                      // Setup
                                                      DSCompiler compiler = mock(DSCompiler.class);
                                                      when(compiler.getSize()).thenReturn(1);
                                                      
                                                      thrown.expect(NullPointerException.class);
                                                      
                                                      // Execute
                                                      compiler.atan2(null, 0, new double[1], 0, new double[1], 0);
                                                  }

 @Test
                                                  public void testAtan2_InvalidOffsets() {
                                                      // Setup
                                                      DSCompiler compiler = mock(DSCompiler.class);
                                                      when(compiler.getSize()).thenReturn(1);
                                                      
                                                      thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                      
                                                      // Execute
                                                      compiler.atan2(new double[1], -1, new double[1], 0, new double[1], 0);
                                                  }

 @Test
                                         public void testAtan2DetectsArgumentSwapMutant() {
                                             // Create test instance using public factory method
                                             DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                             
                                             // Test inputs where x != y to detect argument swap
                                             double[] x = {3.0, 0.0, 0.0}; // x value
                                             double[] y = {4.0, 0.0, 0.0}; // y value
                                             double[] result = new double[3];
                                             
                                             // Expected value from correct atan2(y,x)
                                             double expected = FastMath.atan2(y[0], x[0]);
                                             
                                             // Call the method
                                             compiler.atan2(y, 0, x, 0, result, 0);
                                             
                                             // Verify the result matches atan2(y,x) not atan2(x,y)
                                             assertEquals("Result should match FastMath.atan2(y,x)", 
                                                          expected, result[0], 1e-15);
                                             
                                             // Additional assertion to explicitly check against the mutant behavior
                                             assertNotEquals("Result should not match FastMath.atan2(x,y)", 
                                                            FastMath.atan2(x[0], y[0]), result[0], 1e-15);
                                             
                                             // Test edge case where x = y = 0
                                             compiler.atan2(y, 1, x, 1, result, 0);
                                             assertEquals("Special case (0,0) should be handled correctly",
                                                         FastMath.atan2(y[1], x[1]), result[0], 1e-15);
                                         }

 @Test
                                    public void testAtan2DetectsMutant() {
                                        // Setup - use getCompiler instead of private constructor
                                        DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Assuming 2 parameters, order 2
                                        
                                        // Test case where x is negative to expose quadrant difference
                                        double[] y = {1.0, 0.0, 0.0}; // y value
                                        double[] x = {-1.0, 0.0, 0.0}; // x value (negative)
                                        double[] result = new double[3];
                                        
                                        // Expected values
                                        double expectedAtan2 = FastMath.atan2(y[0], x[0]); // Correct quadrant handling
                                        double mutantAtan = FastMath.atan(y[0] / x[0]); // Incorrect quadrant handling
                                        
                                        // Verify they're different for this case
                                        assertNotEquals(expectedAtan2, mutantAtan, 0.0001);
                                        
                                        // Execute
                                        compiler.atan2(y, 0, x, 0, result, 0);
                                        
                                        // Assert - should use atan2 not atan
                                        assertEquals(expectedAtan2, result[0], 0.0001);
                                        
                                        // Additional check for special case (0,0)
                                        double[] yZero = {0.0, 0.0, 0.0};
                                        double[] xZero = {0.0, 0.0, 0.0};
                                        double[] resultZero = new double[3];
                                        
                                        compiler.atan2(yZero, 0, xZero, 0, resultZero, 0);
                                        assertEquals(FastMath.atan2(0.0, 0.0), resultZero[0], 0.0001);
                                    }

 @Test
                                    public void testAtan2EdgeCases() {
                                        // Create a compiler instance (parameters and order values are arbitrary for this test)
                                        DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                        
                                        // Test case where FastMath and Math would differ (very small values)
                                        double[] y = {1.0e-20};
                                        double[] x = {1.0e-20};
                                        double[] result = new double[1];
                                        
                                        compiler.atan2(y, 0, x, 0, result, 0);
                                        
                                        // The mutation would use Math.atan2 instead of FastMath.atan2 here
                                        // For very small values, FastMath is more accurate
                                        double expected = FastMath.atan2(y[0], x[0]);
                                        assertEquals("Should use FastMath.atan2 for small values", expected, result[0], 1.0e-25);
                                        
                                        // Test special case of (+0.0, +0.0)
                                        y[0] = +0.0;
                                        x[0] = +0.0;
                                        compiler.atan2(y, 0, x, 0, result, 0);
                                        expected = FastMath.atan2(y[0], x[0]);
                                        assertEquals("Should use FastMath.atan2 for (+0.0, +0.0)", expected, result[0], 0.0);
                                        
                                        // Test special case of (-0.0, -0.0)
                                        y[0] = -0.0;
                                        x[0] = -0.0;
                                        compiler.atan2(y, 0, x, 0, result, 0);
                                        expected = FastMath.atan2(y[0], x[0]);
                                        assertEquals("Should use FastMath.atan2 for (-0.0, -0.0)", expected, result[0], 0.0);
                                    }

 @Test
                              public void testAtan2SpecialCases() {
                                  // Create test instance using public factory method
                                  DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                                  
                                  // Test case 1: both zeros (should return 0)
                                  double[] x1 = {0.0};
                                  double[] y1 = {0.0};
                                  double[] result1 = new double[1];
                                  compiler.atan2(y1, 0, x1, 0, result1, 0);
                                  assertEquals(FastMath.atan2(0.0, 0.0), result1[0], 0.0001);
                                  
                                  // Test case 2: positive zero and negative zero
                                  double[] x2 = {0.0};
                                  double[] y2 = {-0.0};
                                  double[] result2 = new double[1];
                                  compiler.atan2(y2, 0, x2, 0, result2, 0);
                                  assertEquals(FastMath.atan2(-0.0, 0.0), result2[0], 0.0001);
                                  
                                  // Test case 3: positive infinity and finite value
                                  double[] x3 = {Double.POSITIVE_INFINITY};
                                  double[] y3 = {1.0};
                                  double[] result3 = new double[1];
                                  compiler.atan2(y3, 0, x3, 0, result3, 0);
                                  assertEquals(FastMath.atan2(1.0, Double.POSITIVE_INFINITY), result3[0], 0.0001);
                                  
                                  // Test case 4: negative infinity and positive infinity
                                  double[] x4 = {Double.NEGATIVE_INFINITY};
                                  double[] y4 = {Double.POSITIVE_INFINITY};
                                  double[] result4 = new double[1];
                                  compiler.atan2(y4, 0, x4, 0, result4, 0);
                                  assertEquals(FastMath.atan2(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY), result4[0], 0.0001);
                              }

 @Test
                          public void testAtan2SpecialCases1() {
                              // Create test inputs for special cases
                              double[] x = {0.0, 0.0, -0.0, -0.0};
                              double[] y = {0.0, -0.0, 0.0, -0.0};
                              double[] result = new double[4];
                              
                              // Create mock DSCompiler with size 1
                              DSCompiler compiler = mock(DSCompiler.class);
                              when(compiler.getSize()).thenReturn(1);
                              
                              // Test each special case
                              for (int i = 0; i < x.length; i++) {
                                  double[] singleX = {x[i]};
                                  double[] singleY = {y[i]};
                                  double[] singleResult = new double[1];
                                  
                                  // Call the method
                                  compiler.atan2(singleY, 0, singleX, 0, singleResult, 0);
                                  
                                  // Verify the result matches FastMath.atan2
                                  assertEquals(FastMath.atan2(y[i], x[i]), singleResult[0], 0.0001);
                              }
                              
                              // Also test with infinity cases
                              double[] infX = {Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY};
                              double[] infY = {Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY};
                              for (int i = 0; i < infX.length; i++) {
                                  for (int j = 0; j < infY.length; j++) {
                                      double[] singleX = {infX[i]};
                                      double[] singleY = {infY[j]};
                                      double[] singleResult = new double[1];
                                      
                                      compiler.atan2(singleY, 0, singleX, 0, singleResult, 0);
                                      
                                      assertEquals(FastMath.atan2(infY[j], infX[i]), singleResult[0], 0.0001);
                                  }
                              }
                          }

 @Test
                    public void testAtan2DetectsMutant1() {
                        // Create test inputs where atan2 result is not PI
                        double[] y = {1.0};
                        double[] x = {1.0};  // atan2(1,1) should be π/4 ≈ 0.785
                        
                        // Create result array
                        double[] result = new double[1];
                        
                        // Create mock compiler with size 1
                        DSCompiler compiler = mock(DSCompiler.class);
                        when(compiler.getSize()).thenReturn(1);
                        
                        // Mock the required operations
                        doAnswer(inv -> {
                            double[] res = (double[]) inv.getArguments()[4];
                            res[0] = 1.0; // x^2 and y^2 will both be 1.0
                            return null;
                        }).when(compiler).multiply(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                        
                        doAnswer(inv -> {
                            double[] res = (double[]) inv.getArguments()[4];
                            res[0] = 2.0; // x^2 + y^2 = 2.0
                            return null;
                        }).when(compiler).add(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                        
                        doAnswer(inv -> {
                            double[] res = (double[]) inv.getArguments()[3];
                            res[0] = Math.sqrt(2.0); // sqrt(2.0)
                            return null;
                        }).when(compiler).rootN(any(double[].class), anyInt(), anyInt(), any(double[].class), anyInt());
                        
                        doAnswer(inv -> {
                            double[] res = (double[]) inv.getArguments()[4];
                            res[0] = 1.0/(1.0 + Math.sqrt(2.0)); // y/(r + x)
                            return null;
                        }).when(compiler).divide(any(double[].class), anyInt(), any(double[].class), anyInt(), any(double[].class), anyInt());
                        
                        doAnswer(inv -> {
                            double[] res = (double[]) inv.getArguments()[2];
                            res[0] = Math.atan(1.0/(1.0 + Math.sqrt(2.0)));
                            return null;
                        }).when(compiler).atan(any(double[].class), anyInt(), any(double[].class), anyInt());
                        
                        // Call the method
                        compiler.atan2(y, 0, x, 0, result, 0);
                        
                        // Verify the result matches FastMath.atan2, not PI
                        assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-10);
                        
                        // Also test a negative x case
                        x[0] = -1.0;
                        compiler.atan2(y, 0, x, 0, result, 0);
                        assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-10);
                        
                        // Test special case (0,0)
                        y[0] = 0.0;
                        x[0] = 0.0;
                        compiler.atan2(y, 0, x, 0, result, 0);
                        assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-10);
                    }

 @Test
                public void testAtan2DetectsSignMutation() {
                    // Setup
                    DSCompiler compiler = mock(DSCompiler.class);
                    when(compiler.getSize()).thenReturn(1);
                    
                    // Test data - case where x>0 and y>0
                    double[] x = {1.0};
                    double[] y = {1.0};
                    double[] result = new double[1];
                    
                    // Expected value
                    double expected = FastMath.atan2(y[0], x[0]);
                    
                    // Call method
                    compiler.atan2(y, 0, x, 0, result, 0);
                    
                    // Verify - mutation would give FastMath.atan2(-1.0, 1.0) instead
                    assertEquals("Result should match FastMath.atan2(y,x)", 
                                 expected, result[0], 1e-15);
                    
                    // Additional case where y is negative
                    y[0] = -1.0;
                    expected = FastMath.atan2(y[0], x[0]);
                    compiler.atan2(y, 0, x, 0, result, 0);
                    assertEquals("Result should match FastMath.atan2(y,x) for negative y",
                                 expected, result[0], 1e-15);
                }

 @Test
               public void testAtan2DetectsSignFlipMutant() {
                   // Setup test data with positive x value
                   double[] x = {1.0};
                   double[] y = {1.0};
                   double[] result = new double[1];
                   int xOffset = 0;
                   int yOffset = 0;
                   int resultOffset = 0;
                   
                   // Create compiler instance (simplified for test)
                   DSCompiler compiler = mock(DSCompiler.class);
                   when(compiler.getSize()).thenReturn(1);
                   
                   // Mock the internal method calls
                   doAnswer(invocation -> {
                       double[] res = invocation.getArgument(4);
                       res[0] = 1.0; // mock x^2 result
                       return null;
                   }).when(compiler).multiply(any(), anyInt(), any(), anyInt(), any(), anyInt());
                   
                   doAnswer(invocation -> {
                       double[] res = invocation.getArgument(4);
                       res[0] = 1.0; // mock y^2 result
                       return null;
                   }).when(compiler).multiply(any(), anyInt(), any(), anyInt(), any(), anyInt());
                   
                   doAnswer(invocation -> {
                       double[] res = invocation.getArgument(4);
                       res[0] = 2.0; // mock x^2 + y^2 result
                       return null;
                   }).when(compiler).add(any(), anyInt(), any(), anyInt(), any(), anyInt());
                   
                   doAnswer(invocation -> {
                       double[] res = invocation.getArgument(3);
                       res[0] = Math.sqrt(2); // mock sqrt(x^2 + y^2) result
                       return null;
                   }).when(compiler).rootN(any(), anyInt(), anyInt(), any(), anyInt());
                   
                   doAnswer(invocation -> {
                       double[] res = invocation.getArgument(4);
                       res[0] = Math.sqrt(2) + 1.0; // mock r + x result
                       return null;
                   }).when(compiler).add(any(), anyInt(), any(), anyInt(), any(), anyInt());
                   
                   doAnswer(invocation -> {
                       double[] res = invocation.getArgument(4);
                       res[0] = 1.0 / (Math.sqrt(2) + 1.0); // mock y/(r + x) result
                       return null;
                   }).when(compiler).divide(any(), anyInt(), any(), anyInt(), any(), anyInt());
                   
                   doAnswer(invocation -> {
                       double[] res = invocation.getArgument(2);
                       res[0] = Math.atan(1.0 / (Math.sqrt(2) + 1.0)); // mock atan result
                       return null;
                   }).when(compiler).atan(any(), anyInt(), any(), anyInt());
                   
                   // Call the method
                   compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                   
                   // Verify the result matches expected atan2 value
                   double expected = Math.atan2(y[yOffset], x[xOffset]);
                   assertEquals("Final atan2 adjustment should match standard Math.atan2", 
                               expected, result[resultOffset], 1e-10);
                   
                   // Additional verification that the mutant would fail
                   double mutantValue = Math.atan2(y[yOffset], -x[xOffset]);
                   assertNotEquals("Test should detect mutant by showing different values", 
                                  mutantValue, result[resultOffset], 1e-10);
               }

 @Test
             public void testAtan2DetectsMutant2() {
                 // Create test inputs with non-zero y value
                 double[] y = {1.0};  // non-zero y
                 int yOffset = 0;
                 double[] x = {1.0};  // positive x
                 int xOffset = 0;
                 double[] result = new double[1];
                 int resultOffset = 0;
                 
                 // Get a compiler instance using the public static method
                 DSCompiler compiler = DSCompiler.getCompiler(2, 2);
                 
                 // Call the method
                 compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                 
                 // Verify the result matches the expected FastMath.atan2 calculation
                 // This will fail if the mutant is present because it would use 0.0 instead of y[yOffset]
                 assertEquals(FastMath.atan2(y[yOffset], x[xOffset]), result[resultOffset], 1e-15);
                 
                 // Also test with negative x to cover both branches
                 x[0] = -1.0;
                 compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                 assertEquals(FastMath.atan2(y[yOffset], x[xOffset]), result[resultOffset], 1e-15);
                 
                 // Test with different non-zero y value
                 y[0] = 2.0;
                 x[0] = 0.5;
                 compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
                 assertEquals(FastMath.atan2(y[yOffset], x[xOffset]), result[resultOffset], 1e-15);
             }

 @Test
         public void testAtan2DetectsMutant3() {
             // Setup test data with non-zero x value
             DSCompiler compiler = DSCompiler.getCompiler(1, 1); // Using simplest case with 1 parameter and order 1
             double[] y = new double[compiler.getSize()];
             double[] x = new double[compiler.getSize()];
             double[] result = new double[compiler.getSize()];
             
             // Set test values (x != 0)
             y[0] = 1.0;  // y coordinate
             x[0] = 1.0;  // x coordinate (non-zero)
             
             // Call the method
             compiler.atan2(y, 0, x, 0, result, 0);
             
             // Verify the final correction uses the actual x value
             // This will fail if the mutant is present (which uses 0.0 instead of x[0])
             assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-15);
             
             // Test with negative x value
             x[0] = -1.0;
             compiler.atan2(y, 0, x, 0, result, 0);
             assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-15);
             
             // Test with different non-zero x value
             x[0] = 2.5;
             compiler.atan2(y, 0, x, 0, result, 0);
             assertEquals(FastMath.atan2(y[0], x[0]), result[0], 1e-15);
         }

 @Test
        public void testAtan2FinalCorrectionUsesCorrectXValue() {
            // Setup test data with x ≠ 1.0
            double[] y = {1.0};
            double[] x = {2.0}; // Using x=2.0 to ensure it's different from 1.0
            double[] result = new double[1];
            
            // Create a mock DSCompiler that returns size 1 for getSize()
            DSCompiler compiler = mock(DSCompiler.class);
            when(compiler.getSize()).thenReturn(1);
            
            // Mock the behavior of called methods to focus on the final correction
            doAnswer(invocation -> {
                double[] res = invocation.getArgument(5);
                res[0] = 0.5; // Mock some intermediate value
                return null;
            }).when(compiler).atan(any(double[].class), anyInt(), any(double[].class), anyInt());
            
            // Call the method
            compiler.atan2(y, 0, x, 0, result, 0);
            
            // Verify the final correction uses the actual x value (2.0) not 1.0
            // The expected value should be FastMath.atan2(y[0], x[0]) = FastMath.atan2(1.0, 2.0)
            assertEquals(FastMath.atan2(1.0, 2.0), result[0], 1e-10);
            
            // Test with negative x value
            x[0] = -2.0;
            compiler.atan2(y, 0, x, 0, result, 0);
            assertEquals(FastMath.atan2(1.0, -2.0), result[0], 1e-10);
        }

 @Test
       public void testAtan2DetectsMutant4() {
           // Setup test data where y[yOffset] != 1.0
           double[] y = {2.0};  // y value is 2.0 (not 1.0)
           int yOffset = 0;
           double[] x = {0.0};  // x is 0 to trigger special case handling
           int xOffset = 0;
           double[] result = new double[1];
           int resultOffset = 0;
           
           // Mock DSCompiler with size 1
           DSCompiler compiler = mock(DSCompiler.class);
           when(compiler.getSize()).thenReturn(1);
           
           // Call the method
           compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
           
           // Verify the result - should be atan2(2.0, 0.0) = π/2
           // If mutant is present, it would be atan2(1.0, 0.0) = π/2 (same in this case)
           // So we need another test case where y is negative
           
           // Second test with negative y
           y[0] = -2.0;
           compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
           
           // Should be atan2(-2.0, 0.0) = -π/2
           // Mutant would give atan2(1.0, 0.0) = π/2 (wrong)
           assertEquals(-Math.PI/2, result[resultOffset], 1e-10);
           
           // Third test with x=1, y=2 (not special case)
           x[0] = 1.0;
           y[0] = 2.0;
           compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
           
           // Should be atan2(2.0, 1.0)
           // Mutant would give atan2(1.0, 1.0) (wrong)
           assertEquals(Math.atan2(2.0, 1.0), result[resultOffset], 1e-10);
       }

 @Test
     public void testAtan2DetectsNaNMutation() {
         // Setup test data
         DSCompiler compiler = DSCompiler.getCompiler(2, 2); // Using public factory method instead of private constructor
         double[] y = {1.0}; // Valid y value
         int yOffset = 0;
         double[] x = {1.0}; // Valid x value
         int xOffset = 0;
         double[] result = new double[compiler.getSize()];
         int resultOffset = 0;
         
         // Call the method
         compiler.atan2(y, yOffset, x, xOffset, result, resultOffset);
         
         // Verify the result is not NaN (which would happen with the mutant)
         assertFalse("Result should not be NaN", Double.isNaN(result[resultOffset]));
         
         // Additional verification that the value is correct
         double expected = FastMath.atan2(y[yOffset], x[xOffset]);
         assertEquals(expected, result[resultOffset], 1e-10);
     }

 @Test
 public void testAtan2SpecialCases2() {
     // Create test instance
     DSCompiler compiler = DSCompiler.getCompiler(2, 2); // arbitrary parameters
     
     // Test special cases that need correction
     double[] y = {0.0};
     double[] x = {0.0};
     double[] result = new double[compiler.getSize()];
     
     // Call method
     compiler.atan2(y, 0, x, 0, result, 0);
     
     // Verify first element isn't NaN and matches FastMath.atan2
     assertFalse("Result should not be NaN", Double.isNaN(result[0]));
     assertEquals("Special case handling incorrect", 
                  FastMath.atan2(y[0], x[0]), 
                  result[0], 
                  0.0001);
     
     // Test another special case
     y[0] = -0.0;
     x[0] = 0.0;
     compiler.atan2(y, 0, x, 0, result, 0);
     assertFalse("Result should not be NaN", Double.isNaN(result[0]));
     assertEquals("Special case handling incorrect", 
                  FastMath.atan2(y[0], x[0]), 
                  result[0], 
                  0.0001);
     
     // Test positive infinity case
     y[0] = Double.POSITIVE_INFINITY;
     x[0] = Double.POSITIVE_INFINITY;
     compiler.atan2(y, 0, x, 0, result, 0);
     assertFalse("Result should not be NaN", Double.isNaN(result[0]));
     assertEquals("Special case handling incorrect", 
                  FastMath.atan2(y[0], x[0]), 
                  result[0], 
                  0.0001);
 }

}
