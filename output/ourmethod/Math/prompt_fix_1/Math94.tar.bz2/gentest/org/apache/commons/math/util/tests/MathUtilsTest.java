package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                   public void testGcd_TypicalPositiveNumbers() {
                       assertEquals(6, MathUtils.gcd(12, 18));
                       assertEquals(1, MathUtils.gcd(13, 17));
                       assertEquals(4, MathUtils.gcd(16, 12));
                       assertEquals(5, MathUtils.gcd(15, 25));
                   }

 @Test
                   public void testGcd_OneZeroInput() {
                       assertEquals(5, MathUtils.gcd(0, 5));
                       assertEquals(7, MathUtils.gcd(7, 0));
                       assertEquals(0, MathUtils.gcd(0, 0));
                   }

 @Test
                   public void testGcd_NegativeNumbers() {
                       assertEquals(6, MathUtils.gcd(-12, 18));
                       assertEquals(6, MathUtils.gcd(12, -18));
                       assertEquals(6, MathUtils.gcd(-12, -18));
                   }

 @Test
                   public void testGcd_EqualNumbers() {
                       assertEquals(1, MathUtils.gcd(1, 1));
                       assertEquals(5, MathUtils.gcd(5, 5));
                       assertEquals(100, MathUtils.gcd(100, 100));
                   }

 @Test
                   public void testGcd_CoPrimeNumbers() {
                       assertEquals(1, MathUtils.gcd(8, 15));
                       assertEquals(1, MathUtils.gcd(14, 25));
                       assertEquals(1, MathUtils.gcd(21, 22));
                   }

 @Test
                   public void testGcd_LargeNumbers() {
                       assertEquals(1000, MathUtils.gcd(1000, 1000000));
                       assertEquals(12345, MathUtils.gcd(12345, 123450));
                       assertEquals(1, MathUtils.gcd(Integer.MAX_VALUE, Integer.MAX_VALUE - 1));
                   }

 @Test
                   public void testGcd_EdgeCases() {
                       assertEquals(Integer.MIN_VALUE, MathUtils.gcd(Integer.MIN_VALUE, 0));
                       assertEquals(Integer.MAX_VALUE, MathUtils.gcd(Integer.MAX_VALUE, 0));
                       assertEquals(1, MathUtils.gcd(Integer.MAX_VALUE, Integer.MIN_VALUE));
                   }

 @Test
                   public void testGcd_PowersOfTwo() {
                       assertEquals(8, MathUtils.gcd(16, 24));
                       assertEquals(16, MathUtils.gcd(16, 16));
                       assertEquals(4, MathUtils.gcd(12, 8));
                   }

 @Test
                   public void testGcd_OddNumbers() {
                       assertEquals(3, MathUtils.gcd(15, 21));
                       assertEquals(1, MathUtils.gcd(17, 23));
                       assertEquals(5, MathUtils.gcd(25, 35));
                   }

 @Test
           public void testGcd_OverflowCase() {
               org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
               exceptionRule.expect(ArithmeticException.class);
               exceptionRule.expectMessage("overflow: gcd is 2^31");
               MathUtils.gcd(Integer.MIN_VALUE, Integer.MIN_VALUE);
           }

 @Test
           public void testFactorialLogWithZero() {
               // This test will catch the mutant by verifying n=0 returns 0 instead of throwing exception
               double result = MathUtils.factorialLog(0);
               assertEquals(0.0, result, 0.0001);
           }

 @Test(expected = IllegalArgumentException.class)
           public void testFactorialLogWithNegative() {
               // Verify negative numbers still throw exception
               MathUtils.factorialLog(-1);
           }

 @Test
           public void testFactorialLogWithPositive() {
               // Additional test case to verify normal behavior
               double result = MathUtils.factorialLog(5);
               double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
               assertEquals(expected, result, 0.0001);
           }

 @Test
      public void testFactorialLogNegativeInputExceptionMessage() {
          try {
              MathUtils.factorialLog(-1);
              fail("Expected IllegalArgumentException to be thrown");
          } catch (IllegalArgumentException e) {
              assertEquals("must have n > 0 for n!", e.getMessage());
          }
      }

 @Test
         public void testFactorialLogForN1ShouldReturn() {
             // Test case for n=1 where loop doesn't execute
             // Original: returns 0 (correct)
             // Mutant: returns 1 (incorrect)
             double result = MathUtils.factorialLog(1);
             assertEquals("Log factorial of 1 should be 0", 0.0, result, 0.0001);
         }

 @Test
         public void testFactorialLogForN0ShouldReturn() {
             // Test case for n=0 where loop doesn't execute
             // Original: returns 0 (correct)
             // Mutant: returns 1 (incorrect)
             double result = MathUtils.factorialLog(0);
             assertEquals("Log factorial of 0 should be 0", 0.0, result, 0.0001);
         }

 @Test
         public void testFactorialLogForN2ShouldReturnLog() {
             // Additional test case for n=2 where loop executes once
             // Original: returns log(2) (correct)
             // Mutant: returns 1 + log(2) (incorrect)
             double result = MathUtils.factorialLog(2);
             assertEquals("Log factorial of 2 should be log(2)", Math.log(2), result, 0.0001);
         }

 @Test
        public void testFactorialLogForN1ShouldNotCallLog() {
            // Create a spy of Math.class to track log calls
            Math mathSpy = spy(Math.class);
            
            // Test n=1 case
            double result = MathUtils.factorialLog(1);
            
            // Verify no log calls were made (since loop starts at 2 and 2>1)
            verify(mathSpy, never()).log(anyDouble());
            assertEquals(0.0, result, 0.0001);
        }

 @Test
        public void testFactorialLogForN2ShouldCallLogOnce() {
            // Create a spy of Math.class to track log calls
            Math mathSpy = spy(Math.class);
            
            // Test n=2 case
            double result = MathUtils.factorialLog(2);
            
            // Verify exactly one log call was made (for i=2)
            verify(mathSpy, times(1)).log(2.0);
            assertEquals(Math.log(2.0), result, 0.0001);
        }

 @Test
    public void testFactorialLogEdgeCases() {
        // n=0 case
        assertEquals(0.0, MathUtils.factorialLog(0), 0.0001);
        
        // n=1 case - should return same as original (0) but mutant would calculate log(1)
        assertEquals(0.0, MathUtils.factorialLog(1), 0.0001);
        
        // n=2 case - should return log(2)
        assertEquals(Math.log(2), MathUtils.factorialLog(2), 0.0001);
        
        // n=3 case - should return log(2) + log(3)
        assertEquals(Math.log(2) + Math.log(3), MathUtils.factorialLog(3), 0.0001);
    }

 @Test
       public void testFactorialLogDetectsSubtractionMutant() {
           // Test with n=2 (simple case)
           // Expected: log(2) ≈ 0.6931471805599453
           double expected = Math.log(2);
           double actual = MathUtils.factorialLog(2);
           assertEquals("Factorial log for n=2 should be log(2)", 
                       expected, actual, MathUtils.EPSILON);
           
           // Test with n=3 (sum of two terms)
           // Expected: log(2) + log(3) ≈ 1.791759469228055
           expected = Math.log(2) + Math.log(3);
           actual = MathUtils.factorialLog(3);
           assertEquals("Factorial log for n=3 should be log(2)+log(3)", 
                       expected, actual, MathUtils.EPSILON);
           
           // Test with n=4 (sum of three terms)
           // Expected: log(2) + log(3) + log(4) ≈ 3.1780538303479458
           expected = Math.log(2) + Math.log(3) + Math.log(4);
           actual = MathUtils.factorialLog(4);
           assertEquals("Factorial log for n=4 should be log(2)+log(3)+log(4)", 
                       expected, actual, MathUtils.EPSILON);
       }

 @Test
      public void testGcdWithZero() {
          // Test case to detect the u >= 0 mutation
          // Original behavior: gcd(0, 5) should return 5
          // Mutated behavior might return different value if u=0 case is handled differently
          int result = MathUtils.gcd(0, 5);
          assertEquals("GCD of 0 and 5 should be 5", 5, result);
          
          // Additional test cases to verify behavior with zero
          assertEquals("GCD of 5 and 0 should be 5", 5, MathUtils.gcd(5, 0));
          assertEquals("GCD of 0 and 0 should be 0", 0, MathUtils.gcd(0, 0));
          assertEquals("GCD of 0 and -5 should be 5", 5, MathUtils.gcd(0, -5));
          assertEquals("GCD of -5 and 0 should be 5", 5, MathUtils.gcd(-5, 0));
      }

 @Test
     public void testFactorialLogWithZero1() {
         // Test n=0 case which should return 0 (sum of empty series)
         double result = MathUtils.factorialLog(0);
         assertEquals(0.0, result, 0.000001);
         
         // Additional test cases for thoroughness
         // Test n=1 (same as n=0 case)
         result = MathUtils.factorialLog(1);
         assertEquals(0.0, result, 0.000001);
         
         // Test n=2 (log(2))
         result = MathUtils.factorialLog(2);
         assertEquals(Math.log(2), result, 0.000001);
         
         // Test n=5 (log(2)+log(3)+log(4)+log(5))
         result = MathUtils.factorialLog(5);
         double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
         assertEquals(expected, result, 0.000001);
     }

 @Test(expected = IllegalArgumentException.class)
     public void testFactorialLogWithNegative1() {
         // Test negative input
         MathUtils.factorialLog(-1);
     }

}
