package gentest.org.apache.commons.math3.optim.nonlinear.vector.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optim.nonlinear.vector.*;
import org.apache.commons.math3.optim.OptimizationData;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.DiagonalMatrix;
import org.apache.commons.math3.linear.NonSquareMatrixException;
 
public class WeightTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testConstructor_ValidWeights() {
                // Arrange
                double[] weights = {1.0, 2.0, 3.5};
                
                // Act
                Weight weight = new Weight(weights);
                RealMatrix result = weight.getWeight();
                
                // Assert
                assertNotNull(result);
                assertTrue(result instanceof DiagonalMatrix);
                assertEquals(1.0, result.getEntry(0, 0), 0.0001);
                assertEquals(2.0, result.getEntry(1, 1), 0.0001);
                assertEquals(3.5, result.getEntry(2, 2), 0.0001);
            }

    @Test
            public void testConstructor_EmptyArray() {
                // Arrange
                double[] emptyWeights = {};
                
                // Expect exception
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("Weight array cannot be empty");
                
                // Act
                new Weight(emptyWeights);
            }

    @Test
            public void testConstructor_NullInput() {
                // Arrange
                double[] nullWeights = null;
                
                // Expect exception
                thrown.expect(NullPointerException.class);
                thrown.expectMessage("Weight array cannot be null");
                
                // Act
                new Weight(nullWeights);
            }

    @Test
            public void testConstructor_ZeroValues() {
                // Arrange
                double[] weights = {0.0, 0.0, 0.0};
                
                // Act
                Weight weight = new Weight(weights);
                RealMatrix result = weight.getWeight();
                
                // Assert
                assertNotNull(result);
                assertEquals(0.0, result.getEntry(0, 0), 0.0001);
                assertEquals(0.0, result.getEntry(1, 1), 0.0001);
                assertEquals(0.0, result.getEntry(2, 2), 0.0001);
            }

    @Test
            public void testConstructor_NegativeValues() {
                // Arrange
                double[] weights = {-1.0, -2.5, -0.1};
                
                // Act
                Weight weight = new Weight(weights);
                RealMatrix result = weight.getWeight();
                
                // Assert
                assertNotNull(result);
                assertEquals(-1.0, result.getEntry(0, 0), 0.0001);
                assertEquals(-2.5, result.getEntry(1, 1), 0.0001);
                assertEquals(-0.1, result.getEntry(2, 2), 0.0001);
            }

    @Test
            public void testConstructor_LargeValues() {
                // Arrange
                double[] weights = {Double.MAX_VALUE, Double.MIN_VALUE};
                
                // Act
                Weight weight = new Weight(weights);
                RealMatrix result = weight.getWeight();
                
                // Assert
                assertNotNull(result);
                assertEquals(Double.MAX_VALUE, result.getEntry(0, 0), 0.0001);
                assertEquals(Double.MIN_VALUE, result.getEntry(1, 1), 0.0001);
            }

    @Test
            public void testConstructor_ValidSquareMatrix() {
                // Arrange
                RealMatrix mockMatrix = mock(RealMatrix.class);
                when(mockMatrix.getColumnDimension()).thenReturn(3);
                when(mockMatrix.getRowDimension()).thenReturn(3);
                when(mockMatrix.copy()).thenReturn(mockMatrix);
                
                // Act
                Weight weight = new Weight(mockMatrix);
                
                // Assert
                assertSame(mockMatrix, weight.getWeight());
                verify(mockMatrix).getColumnDimension();
                verify(mockMatrix).getRowDimension();
                verify(mockMatrix).copy();
            }

    @Test
            public void testConstructor_NonSquareMatrix_ThrowsException() {
                // Arrange
                RealMatrix mockMatrix = mock(RealMatrix.class);
                when(mockMatrix.getColumnDimension()).thenReturn(3);
                when(mockMatrix.getRowDimension()).thenReturn(2);
                
                // Expect exception
                thrown.expect(NonSquareMatrixException.class);
                thrown.expectMessage("3 != 2");
                
                // Act
                new Weight(mockMatrix);
            }

    @Test
            public void testConstructor_MatrixIsCopiedNotReferenced() {
                // Arrange
                RealMatrix originalMatrix = mock(RealMatrix.class);
                RealMatrix copiedMatrix = mock(RealMatrix.class);
                when(originalMatrix.getColumnDimension()).thenReturn(2);
                when(originalMatrix.getRowDimension()).thenReturn(2);
                when(originalMatrix.copy()).thenReturn(copiedMatrix);
                
                // Act
                Weight weight = new Weight(originalMatrix);
                
                // Assert
                assertSame(copiedMatrix, weight.getWeight());
                assertNotSame(originalMatrix, weight.getWeight());
                verify(originalMatrix).copy();
            }

    @Test
            public void testConstructor_1x1Matrix() {
                // Arrange
                RealMatrix mockMatrix = mock(RealMatrix.class);
                when(mockMatrix.getColumnDimension()).thenReturn(1);
                when(mockMatrix.getRowDimension()).thenReturn(1);
                when(mockMatrix.copy()).thenReturn(mockMatrix);
                
                // Act
                Weight weight = new Weight(mockMatrix);
                
                // Assert
                assertSame(mockMatrix, weight.getWeight());
            }

    @Test
    public void testConstructor_NullMatrix_ThrowsNullPointerException() {
        // Expect exception
        thrown.expect(NullPointerException.class);
        
        // Act - explicitly cast null to RealMatrix to avoid ambiguity
        new Weight((RealMatrix) null);
    }


}
