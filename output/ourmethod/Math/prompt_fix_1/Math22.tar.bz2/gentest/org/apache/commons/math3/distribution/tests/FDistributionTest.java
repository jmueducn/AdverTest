package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.special.Beta;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class FDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                            public void testGetDenominatorDegreesOfFreedom_InvalidValues() {
                                // Test that constructor throws exception for invalid denominator degrees
                                thrown.expect(NotStrictlyPositiveException.class);
                                thrown.expectMessage("degrees of freedom");
                                new FDistribution(5.0, 0.0);
                            }

 @Test
                            public void testGetDenominatorDegreesOfFreedom_InvalidNegativeValues() {
                                // Test that constructor throws exception for negative denominator degrees
                                thrown.expect(NotStrictlyPositiveException.class);
                                thrown.expectMessage("degrees of freedom");
                                new FDistribution(5.0, -1.0);
                            }

 @Test
                            public void testIsSupportLowerBoundInclusive_ReturnsFalseForDifferentDegreesOfFreedom() {
                                // Arrange
                                FDistribution dist1 = new FDistribution(1.0, 1.0);
                                FDistribution dist2 = new FDistribution(100.0, 100.0);
                                FDistribution dist3 = new FDistribution(0.5, 0.5); // Though in practice DF should be > 0
                                
                                // Act & Assert
                                assertFalse(dist1.isSupportLowerBoundInclusive());
                                assertFalse(dist2.isSupportLowerBoundInclusive());
                                assertFalse(dist3.isSupportLowerBoundInclusive());
                            }

 @Test
                    public void testGetDenominatorDegreesOfFreedom_PositiveValues() {
                        // Define test accuracy constant
                        final double TEST_ACCURACY = 1e-10;
                        
                        // Test with typical positive values
                        FDistribution dist = new FDistribution(5.0, 10.0);
                        assertEquals(10.0, dist.getDenominatorDegreesOfFreedom(), TEST_ACCURACY);
                        
                        // Test with different values
                        dist = new FDistribution(3.0, 7.5);
                        assertEquals(7.5, dist.getDenominatorDegreesOfFreedom(), TEST_ACCURACY);
                        
                        // Test with very large values
                        dist = new FDistribution(100.0, 1000.0);
                        assertEquals(1000.0, dist.getDenominatorDegreesOfFreedom(), TEST_ACCURACY);
                        
                        // Test with small positive values
                        dist = new FDistribution(0.1, 0.1);
                        assertEquals(0.1, dist.getDenominatorDegreesOfFreedom(), TEST_ACCURACY);
                    }

 @Test
                    public void testGetDenominatorDegreesOfFreedom_WithRandomGenerator() {
                        // Test with random generator constructor
                        double testAccuracy = 1e-12; // Define test accuracy
                        org.apache.commons.math3.random.Well19937c randomGenerator = new org.apache.commons.math3.random.Well19937c();
                        FDistribution dist = new FDistribution(randomGenerator, 2.0, 3.0, testAccuracy);
                        assertEquals(3.0, dist.getDenominatorDegreesOfFreedom(), testAccuracy);
                    }

 @Test
                    public void testGetDenominatorDegreesOfFreedom_WithInverseCumAccuracy() {
                        // Define test accuracy constant
                        final double TEST_ACCURACY = 1.0e-12;
                        
                        // Test with inverse cumulative accuracy constructor
                        FDistribution dist = new FDistribution(4.0, 8.0, TEST_ACCURACY);
                        assertEquals(8.0, dist.getDenominatorDegreesOfFreedom(), TEST_ACCURACY);
                    }

 @Test
                    public void testGetDenominatorDegreesOfFreedom_AfterConstruction() {
                        // Define test accuracy constant
                        final double TEST_ACCURACY = 1e-12;
                        
                        // Verify the value doesn't change after construction
                        double initialValue = 15.0;
                        FDistribution dist = new FDistribution(10.0, initialValue);
                        assertEquals(initialValue, dist.getDenominatorDegreesOfFreedom(), TEST_ACCURACY);
                        
                        // Verify multiple calls return same value
                        assertEquals(initialValue, dist.getDenominatorDegreesOfFreedom(), TEST_ACCURACY);
                        assertEquals(initialValue, dist.getDenominatorDegreesOfFreedom(), TEST_ACCURACY);
                    }

 @Test
                    public void testGetSolverAbsoluteAccuracy_DefaultConstructor() throws Exception {
                        // Test with default inverse accuracy
                        double numeratorDof = 5.0;
                        double denominatorDof = 10.0;
                        FDistribution dist = new FDistribution(numeratorDof, denominatorDof);
                        
                        // Use reflection to access protected method
                        Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                        method.setAccessible(true);
                        double accuracy = (Double) method.invoke(dist);
                        
                        assertEquals(FDistribution.DEFAULT_INVERSE_ABSOLUTE_ACCURACY, accuracy, 1e-12);
                    }

 @Test
                    public void testGetSolverAbsoluteAccuracy_CustomAccuracy() throws Exception {
                        // Test with custom inverse accuracy
                        double numeratorDof = 3.0;
                        double denominatorDof = 7.0;
                        double customAccuracy = 1e-12;
                        double EPSILON = 1e-15; // Define EPSILON if not already defined
                        FDistribution dist = new FDistribution(numeratorDof, denominatorDof, customAccuracy);
                        
                        // Use reflection to access protected method
                        Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                        method.setAccessible(true);
                        double actualAccuracy = (Double) method.invoke(dist);
                        
                        assertEquals(customAccuracy, actualAccuracy, EPSILON);
                    }

 @Test
                    public void testGetSolverAbsoluteAccuracy_FullConstructor() throws Exception {
                        // Test with full constructor including RandomGenerator
                        double numeratorDof = 2.0;
                        double denominatorDof = 5.0;
                        double customAccuracy = 1e-8;
                        double EPSILON = 1e-15;
                        FDistribution dist = new FDistribution(new Well19937c(), 
                                                              numeratorDof, 
                                                              denominatorDof, 
                                                              customAccuracy);
                        
                        // Use reflection to access protected method
                        Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                        method.setAccessible(true);
                        double accuracy = (Double) method.invoke(dist);
                        
                        assertEquals(customAccuracy, accuracy, EPSILON);
                    }

 @Test
                    public void testGetSolverAbsoluteAccuracy_ZeroAccuracy() throws Exception {
                        // Test with zero accuracy (edge case)
                        double numeratorDof = 1.0;
                        double denominatorDof = 1.0;
                        double zeroAccuracy = 0.0;
                        double EPSILON = 1e-15; // Define EPSILON if not already defined
                        FDistribution dist = new FDistribution(numeratorDof, denominatorDof, zeroAccuracy);
                        
                        // Use reflection to access protected method
                        Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                        method.setAccessible(true);
                        double accuracy = (Double) method.invoke(dist);
                        
                        assertEquals(zeroAccuracy, accuracy, EPSILON);
                    }

 @Test
                    public void testGetSolverAbsoluteAccuracy_VerySmallAccuracy() throws Exception {
                        // Test with very small accuracy value
                        double numeratorDof = 10.0;
                        double denominatorDof = 20.0;
                        double smallAccuracy = Double.MIN_VALUE;
                        FDistribution dist = new FDistribution(numeratorDof, denominatorDof, smallAccuracy);
                        
                        // Use reflection to access protected method
                        Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                        method.setAccessible(true);
                        double actualAccuracy = (Double) method.invoke(dist);
                        
                        assertEquals(smallAccuracy, actualAccuracy, Double.MIN_VALUE);
                    }

 @Test
                    public void testGetSolverAbsoluteAccuracy_VeryLargeAccuracy() throws Exception {
                        // Test with very large accuracy value
                        double numeratorDof = 15.0;
                        double denominatorDof = 30.0;
                        double largeAccuracy = Double.MAX_VALUE;
                        double EPSILON = 1e-15;
                        FDistribution dist = new FDistribution(numeratorDof, denominatorDof, largeAccuracy);
                        
                        // Use reflection to access protected method
                        Method method = FDistribution.class.getDeclaredMethod("getSolverAbsoluteAccuracy");
                        method.setAccessible(true);
                        double actualAccuracy = (Double) method.invoke(dist);
                        
                        assertEquals(largeAccuracy, actualAccuracy, EPSILON);
                    }

 @Test
                    public void testIsSupportLowerBoundInclusive_ReturnsFalseForDefaultConstructor() {
                        // Arrange
                        double numeratorDF = 5.0;  // example value for numerator degrees of freedom
                        double denominatorDF = 10.0;  // example value for denominator degrees of freedom
                        FDistribution dist = new FDistribution(numeratorDF, denominatorDF);
                        
                        // Act & Assert
                        assertFalse(dist.isSupportLowerBoundInclusive());
                    }

 @Test
                    public void testIsSupportLowerBoundInclusive_ReturnsFalseForFullConstructor() {
                        // Arrange
                        RandomGenerator mockRng = mock(RandomGenerator.class);
                        double numeratorDF = 5.0;
                        double denominatorDF = 10.0;
                        double inverseCumAccuracy = 1e-9;
                        FDistribution dist = new FDistribution(mockRng, numeratorDF, denominatorDF, inverseCumAccuracy);
                        
                        // Act & Assert
                        assertFalse(dist.isSupportLowerBoundInclusive());
                    }

 @Test
                    public void testIsSupportLowerBoundInclusive_ReturnsFalseAfterOtherOperations() {
                        // Arrange
                        double numeratorDF = 5.0;  // example value for numerator degrees of freedom
                        double denominatorDF = 10.0; // example value for denominator degrees of freedom
                        FDistribution dist = new FDistribution(numeratorDF, denominatorDF);
                        
                        // Perform some operations that might affect state
                        dist.getNumericalMean();
                        dist.getNumericalVariance();
                        dist.density(1.0);
                        dist.cumulativeProbability(1.0);
                        
                        // Act & Assert
                        assertFalse(dist.isSupportLowerBoundInclusive());
                    }

 @Test
                    public void testGetDenominatorDegreesOfFreedom() {
                        // Test with normal value
                        double testValue1 = 5.0;
                        FDistribution dist1 = new FDistribution(2.0, testValue1);
                        assertEquals("Getter should return constructor value", 
                            testValue1, dist1.getDenominatorDegreesOfFreedom(), 0.0001);
                        
                        // Test with different value
                        double testValue2 = 10.5;
                        FDistribution dist2 = new FDistribution(3.0, testValue2);
                        assertEquals("Getter should return different constructor value",
                            testValue2, dist2.getDenominatorDegreesOfFreedom(), 0.0001);
                            
                        // Test with very small positive value (boundary case)
                        double testValue3 = Double.MIN_VALUE;
                        FDistribution dist3 = new FDistribution(1.0, testValue3);
                        assertEquals("Getter should handle very small positive values",
                            testValue3, dist3.getDenominatorDegreesOfFreedom(), 0.0);
                            
                        // Test with large value
                        double testValue4 = 1e300;
                        FDistribution dist4 = new FDistribution(1.0, testValue4);
                        assertEquals("Getter should handle very large values",
                            testValue4, dist4.getDenominatorDegreesOfFreedom(), 0.0);
                    }

 @Test
                   public void testGetDenominatorDegreesOfFreedomWithNegativeValue() throws Exception {
                       // Create an FDistribution object with positive values (as required by constructor)
                       FDistribution fDist = new FDistribution(5.0, 10.0);
                       
                       // Use reflection to change the denominatorDegreesOfFreedom to a negative value
                       Field field = FDistribution.class.getDeclaredField("denominatorDegreesOfFreedom");
                       field.setAccessible(true);
                       field.set(fDist, -10.0);
                       
                       // Test that the getter returns the exact value, not absolute value
                       assertEquals(-10.0, fDist.getDenominatorDegreesOfFreedom(), 0.0001);
                       
                       // This test will fail if the mutant is present because:
                       // - Original code returns -10.0 (passes this test)
                       // - Mutant returns Math.abs(-10.0) = 10.0 (fails this test)
                   }

 @Test
                   public void testGetDenominatorDegreesOfFreedomWithPositiveValue() {
                       // Normal case with positive value
                       FDistribution fDist = new FDistribution(5.0, 10.0);
                       assertEquals(10.0, fDist.getDenominatorDegreesOfFreedom(), 0.0001);
                       
                       // This test passes for both original and mutant since Math.abs(10.0) = 10.0
                       // Included for completeness
                   }

 @Test
                  public void testGetDenominatorDegreesOfFreedomWithZeroValue() throws Exception {
                      // Create instance with valid parameters
                      FDistribution dist = new FDistribution(1.0, 1.0);
                      
                      // Use reflection to set denominatorDegreesOfFreedom to 0
                      Field field = FDistribution.class.getDeclaredField("denominatorDegreesOfFreedom");
                      field.setAccessible(true);
                      field.set(dist, 0.0);
                      
                      // Test that the method returns exactly what was set (should be 0)
                      assertEquals(0.0, dist.getDenominatorDegreesOfFreedom(), 0.0);
                      
                      // For the mutant version, this would return 1.0 instead of 0.0
                      // So this test would fail for the mutant, catching it
                  }

 @Test
                 public void testGetDenominatorDegreesOfFreedomWithInfinity() {
                     // Create FDistribution with infinite denominator degrees of freedom
                     FDistribution dist = new FDistribution(5.0, Double.POSITIVE_INFINITY);
                     
                     // Verify the getter returns positive infinity (original behavior)
                     // This will fail if the mutant (returning negative infinity) is present
                     assertEquals(Double.POSITIVE_INFINITY, dist.getDenominatorDegreesOfFreedom(), 0.0);
                 }

 @Test
                 public void testGetDenominatorDegreesOfFreedomWithFiniteValue() {
                     // Test with finite value to ensure normal cases still work
                     double testValue = 10.0;
                     FDistribution dist = new FDistribution(5.0, testValue);
                     
                     assertEquals(testValue, dist.getDenominatorDegreesOfFreedom(), 0.0);
                 }

 @Test
                public void testGetDenominatorDegreesOfFreedomWithInfinity1() {
                    // Create FDistribution with infinite denominator degrees of freedom
                    FDistribution dist = new FDistribution(5.0, Double.POSITIVE_INFINITY);
                    
                    // Verify the getter returns infinity, not MAX_VALUE
                    assertEquals("Should return POSITIVE_INFINITY for infinite degrees of freedom",
                                Double.POSITIVE_INFINITY, 
                                dist.getDenominatorDegreesOfFreedom(), 
                                0.0);
                }

 @Test
               public void testGetDenominatorDegreesOfFreedom1() {
                   // Test with normal positive value
                   FDistribution dist1 = new FDistribution(5.0, 10.0);
                   assertEquals(10.0, dist1.getDenominatorDegreesOfFreedom(), 0.0001);
                   
                   // Test with very large value
                   FDistribution dist2 = new FDistribution(5.0, Double.MAX_VALUE);
                   assertEquals(Double.MAX_VALUE, dist2.getDenominatorDegreesOfFreedom(), 0.0);
                   
                   // Test with positive infinity
                   FDistribution dist3 = new FDistribution(5.0, Double.POSITIVE_INFINITY);
                   assertEquals(Double.POSITIVE_INFINITY, dist3.getDenominatorDegreesOfFreedom(), 0.0);
               }

 @Test
              public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue() {
                  // Arrange
                  double numeratorDof = 5.0;
                  double denominatorDof = 10.0;
                  FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
                  
                  // Act
                  double result = fDist.getDenominatorDegreesOfFreedom();
                  
                  // Assert
                  assertEquals("Denominator degrees of freedom should match constructor value", 
                              denominatorDof, result, 0.0001);
                  assertFalse("Should not return NaN", Double.isNaN(result));
              }

 @Test
             public void testGetDenominatorDegreesOfFreedomReturnsPositiveInfinity() {
                 // Create FDistribution with very large denominator degrees of freedom
                 // that would result in positive infinity
                 double numeratorDof = 5.0;
                 double denominatorDof = Double.POSITIVE_INFINITY;
                 
                 FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
                 
                 // Verify the method returns positive infinity (original behavior)
                 // This will fail if the mutant (returning negative infinity) is present
                 assertEquals(Double.POSITIVE_INFINITY, fDist.getDenominatorDegreesOfFreedom(), 0.0);
             }

 @Test
            public void testGetDenominatorDegreesOfFreedomForInfiniteCase() {
                // Create an FDistribution with very large denominator degrees of freedom
                // that should be treated as infinity
                double numeratorDof = 10.0;
                double denominatorDof = Double.POSITIVE_INFINITY;
                FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
                
                // Verify the getter returns POSITIVE_INFINITY, not MAX_VALUE
                assertEquals("For infinite denominator degrees of freedom, should return POSITIVE_INFINITY",
                    Double.POSITIVE_INFINITY, fDist.getDenominatorDegreesOfFreedom(), 0.0);
                
                // Additional check to ensure it's not returning MAX_VALUE
                assertNotEquals("Should not return MAX_VALUE for infinite case",
                    Double.MAX_VALUE, fDist.getDenominatorDegreesOfFreedom(), 0.0);
            }

 @Test
            public void testGetDenominatorDegreesOfFreedomForFiniteCase() {
                // Test with normal finite values
                double numeratorDof = 10.0;
                double denominatorDof = 20.0;
                FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
                
                assertEquals("Should return exact denominator degrees of freedom",
                    denominatorDof, fDist.getDenominatorDegreesOfFreedom(), 0.0);
            }

 @Test
           public void testGetDenominatorDegreesOfFreedom2() {
               // Test with normal value
               double testValue = 5.0;
               FDistribution dist = new FDistribution(2.0, testValue);
               assertEquals("Getter should return constructor-set value", 
                           testValue, 
                           dist.getDenominatorDegreesOfFreedom(), 
                           0.0001);
               
               // Test with another value
               double testValue2 = 10.5;
               FDistribution dist2 = new FDistribution(3.0, testValue2);
               assertEquals("Getter should return different constructor-set value",
                           testValue2,
                           dist2.getDenominatorDegreesOfFreedom(),
                           0.0001);
           }

 @Test
          public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue1() {
              // Arrange
              double numeratorDof = 5.0;
              double denominatorDof = 10.0;
              FDistribution fDistribution = new FDistribution(numeratorDof, denominatorDof);
              
              // Act
              double result = fDistribution.getDenominatorDegreesOfFreedom();
              
              // Assert
              assertEquals("Denominator degrees of freedom should match the constructor argument", 
                          denominatorDof, result, 0.0001);
          }

 @Test
          public void testGetDenominatorDegreesOfFreedomWithDifferentValues() {
              // Arrange
              double numeratorDof = 3.0;
              double denominatorDof = 7.5;
              FDistribution fDistribution = new FDistribution(numeratorDof, denominatorDof);
              
              // Act
              double result = fDistribution.getDenominatorDegreesOfFreedom();
              
              // Assert
              assertEquals("Denominator degrees of freedom should match the constructor argument", 
                          denominatorDof, result, 0.0001);
          }

 @Test
         public void testGetDenominatorDegreesOfFreedomWithInfinity2() {
             // Test case where denominator should be infinite
             double numerator = 10.0;
             double denominator = Double.POSITIVE_INFINITY;
             FDistribution dist = new FDistribution(numerator, denominator);
             
             // The original method should return infinity, mutant would return MAX_VALUE
             assertEquals(Double.POSITIVE_INFINITY, dist.getDenominatorDegreesOfFreedom(), 0.0);
         }

 @Test
         public void testGetDenominatorDegreesOfFreedomWithLargeValue() {
             // Test case with large but finite denominator
             double numerator = 10.0;
             double denominator = Double.MAX_VALUE;
             FDistribution dist = new FDistribution(numerator, denominator);
             
             // Both original and mutant would return MAX_VALUE here
             assertEquals(Double.MAX_VALUE, dist.getDenominatorDegreesOfFreedom(), 0.0);
         }

 @Test
         public void testGetDenominatorDegreesOfFreedomWithNormalValue() {
             // Test case with normal finite denominator
             double numerator = 10.0;
             double denominator = 20.0;
             FDistribution dist = new FDistribution(numerator, denominator);
             
             // Both original and mutant would return the set value
             assertEquals(20.0, dist.getDenominatorDegreesOfFreedom(), 0.0);
         }

 @Test
        public void testGetDenominatorDegreesOfFreedomReturnsCorrectValue2() {
            // Arrange
            double numeratorDof = 5.0;
            double denominatorDof = 10.0;
            FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
            
            // Act
            double result = fDist.getDenominatorDegreesOfFreedom();
            
            // Assert
            assertEquals("Denominator degrees of freedom should match constructor argument", 
                        denominatorDof, result, 0.0001);
        }

 @Test
        public void testGetDenominatorDegreesOfFreedomWithDifferentValues1() {
            // Arrange - test with a different value to ensure it's not hardcoded
            double numeratorDof = 3.0;
            double denominatorDof = 7.5;
            FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
            
            // Act
            double result = fDist.getDenominatorDegreesOfFreedom();
            
            // Assert
            assertEquals("Denominator degrees of freedom should match constructor argument", 
                        denominatorDof, result, 0.0001);
        }

 @Test
       public void testGetDenominatorDegreesOfFreedomReturnsActualValue() {
           // Arrange
           double numeratorDof = 5.0;
           double denominatorDof = 10.0;
           FDistribution fDist = new FDistribution(numeratorDof, denominatorDof);
           
           // Act
           double result = fDist.getDenominatorDegreesOfFreedom();
           
           // Assert
           assertEquals("Denominator degrees of freedom should match constructor argument", 
                        denominatorDof, result, 0.0001);
           assertFalse("Should not return NaN", Double.isNaN(result));
       }

 @Test
      public void testGetDenominatorDegreesOfFreedomWithInfinity3() {
          // Create FDistribution with infinite denominator degrees of freedom
          FDistribution dist = new FDistribution(5.0, Double.POSITIVE_INFINITY);
          
          // Verify the getter returns positive infinity (original behavior)
          assertEquals(Double.POSITIVE_INFINITY, dist.getDenominatorDegreesOfFreedom(), 0.0);
          
          // This test will fail if the mutant (returning NEGATIVE_INFINITY) is present
      }

 @Test
      public void testGetDenominatorDegreesOfFreedomWithFiniteValue1() {
          // Test with finite value to ensure normal cases still work
          double testValue = 10.0;
          FDistribution dist = new FDistribution(5.0, testValue);
          
          assertEquals(testValue, dist.getDenominatorDegreesOfFreedom(), 0.0);
      }

 @Test
     public void testGetDenominatorDegreesOfFreedomWithInfinity4() {
         // Create FDistribution with infinite denominator degrees of freedom
         FDistribution dist = new FDistribution(5.0, Double.POSITIVE_INFINITY);
         
         // Verify the getter returns infinity, not MAX_VALUE
         assertEquals("For infinite denominator degrees of freedom, should return POSITIVE_INFINITY",
                     Double.POSITIVE_INFINITY, 
                     dist.getDenominatorDegreesOfFreedom(), 
                     0.0);
     }

 @Test
     public void testGetDenominatorDegreesOfFreedomWithFiniteValue2() {
         // Test with a regular finite value
         double testValue = 10.5;
         FDistribution dist = new FDistribution(5.0, testValue);
         
         assertEquals("For finite denominator degrees of freedom, should return exact value",
                     testValue,
                     dist.getDenominatorDegreesOfFreedom(),
                     0.0);
     }

}
