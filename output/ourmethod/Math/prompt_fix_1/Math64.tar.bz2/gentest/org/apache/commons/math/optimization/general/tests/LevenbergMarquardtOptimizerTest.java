package gentest.org.apache.commons.math.optimization.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.general.*;
import java.util.Arrays;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.optimization.OptimizationException;
import org.apache.commons.math.optimization.VectorialPointValuePair;
import org.apache.commons.math.util.MathUtils;
 
public class LevenbergMarquardtOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                            public void testDoOptimize_ConvergenceOnFirstIteration() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                                LevenbergMarquardtOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                
                                                                                                                                                // Use reflection to set private fields
                                                                                                                                                Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                                                                                                solvedColsField.setAccessible(true);
                                                                                                                                                solvedColsField.set(spyOptimizer, 2);
                                                                                                                                                
                                                                                                                                                Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                                                                                                                diagRField.setAccessible(true);
                                                                                                                                                diagRField.set(spyOptimizer, new double[]{1.0, 1.0});
                                                                                                                                                
                                                                                                                                                Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                                                jacNormField.setAccessible(true);
                                                                                                                                                jacNormField.set(spyOptimizer, new double[]{1.0, 1.0});
                                                                                                                                                
                                                                                                                                                Field permutationField = LevenbergMarquardtOptimizer.class.getDeclaredField("permutation");
                                                                                                                                                permutationField.setAccessible(true);
                                                                                                                                                permutationField.set(spyOptimizer, new int[]{0, 1});
                                                                                                                                                
                                                                                                                                                Field lmDirField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmDir");
                                                                                                                                                lmDirField.setAccessible(true);
                                                                                                                                                lmDirField.set(spyOptimizer, new double[2]);
                                                                                                                                                
                                                                                                                                                Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                                                costField.setAccessible(true);
                                                                                                                                                costField.set(spyOptimizer, 1.0);
                                                                                                                                                
                                                                                                                                                // Mock protected methods using doCallRealMethod() pattern
                                                                                                                                                // Create a spy that will call real methods by default
                                                                                                                                                LevenbergMarquardtOptimizer realSpy = spy(optimizer);
                                                                                                                                                doCallRealMethod().when(realSpy).getConvergenceChecker();
                                                                                                                                                
                                                                                                                                                // Set tolerances to ensure convergence
                                                                                                                                                spyOptimizer.setOrthoTolerance(0.1);
                                                                                                                                                spyOptimizer.setCostRelativeTolerance(0.1);
                                                                                                                                                spyOptimizer.setParRelativeTolerance(0.1);
                                                                                                                                                
                                                                                                                                                // Test
                                                                                                                                                Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                doOptimizeMethod.setAccessible(true);
                                                                                                                                                VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(spyOptimizer);
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                assertNotNull(result);
                                                                                                                                                // Verify interactions using the real spy
                                                                                                                                                verify(realSpy, atLeastOnce()).getConvergenceChecker();
                                                                                                                                            }

    @Test
                                                                                                                    public void testDoOptimize_ThrowsWhenParametersToleranceTooSmall() throws Exception {
                                                                                                                        // Setup
                                                                                                                        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                        LevenbergMarquardtOptimizer spyOptimizer = spy(optimizer);
                                                                                                                        
                                                                                                                        // Use reflection to set private fields
                                                                                                                        Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                                                                        solvedColsField.setAccessible(true);
                                                                                                                        solvedColsField.setInt(spyOptimizer, 2);
                                                                                                                        
                                                                                                                        Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                                                                                        diagRField.setAccessible(true);
                                                                                                                        diagRField.set(spyOptimizer, new double[]{1.0, 1.0});
                                                                                                                        
                                                                                                                        Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                                                                        jacNormField.setAccessible(true);
                                                                                                                        jacNormField.set(spyOptimizer, new double[]{1.0, 1.0});
                                                                                                                        
                                                                                                                        Field permutationField = LevenbergMarquardtOptimizer.class.getDeclaredField("permutation");
                                                                                                                        permutationField.setAccessible(true);
                                                                                                                        permutationField.set(spyOptimizer, new int[]{0, 1});
                                                                                                                        
                                                                                                                        Field lmDirField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmDir");
                                                                                                                        lmDirField.setAccessible(true);
                                                                                                                        lmDirField.set(spyOptimizer, new double[2]);
                                                                                                                        
                                                                                                                        Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                        costField.setAccessible(true);
                                                                                                                        costField.set(spyOptimizer, 1.0);
                                                                                                                        
                                                                                                                        Field xNormField = AbstractLeastSquaresOptimizer.class.getDeclaredField("xNorm");
                                                                                                                        xNormField.setAccessible(true);
                                                                                                                        xNormField.set(spyOptimizer, 1.0);
                                                                                                                        
                                                                                                                        // Instead of trying to mock private methods, we'll let them execute normally
                                                                                                                        // since they're private and we can't mock them directly
                                                                                                                        
                                                                                                                        // Set very tight parameter tolerance
                                                                                                                        spyOptimizer.setParRelativeTolerance(1.0e-20);
                                                                                                                        
                                                                                                                        // Expect exception
                                                                                                                        ExpectedException thrown = ExpectedException.none();
                                                                                                                        thrown.expect(OptimizationException.class);
                                                                                                                        thrown.expectMessage("too small parameters relative tolerance");
                                                                                                                        
                                                                                                                        // Use reflection to call protected doOptimize method
                                                                                                                        Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                        doOptimizeMethod.setAccessible(true);
                                                                                                                        doOptimizeMethod.invoke(spyOptimizer);
                                                                                                                    }

    @Test
                                                                        public void testDoOptimize_SuccessfulConvergenceAfterMultipleIterations() throws Exception {
                                                                            // Setup
                                                                            LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                            LevenbergMarquardtOptimizer spyOptimizer = spy(optimizer);
                                                                            
                                                                            // Use reflection to set private fields
                                                                            Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                            solvedColsField.setAccessible(true);
                                                                            solvedColsField.set(spyOptimizer, 2);
                                                                            
                                                                            Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                                            diagRField.setAccessible(true);
                                                                            diagRField.set(spyOptimizer, new double[]{1.0, 1.0});
                                                                            
                                                                            Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                            jacNormField.setAccessible(true);
                                                                            jacNormField.set(spyOptimizer, new double[]{1.0, 1.0});
                                                                            
                                                                            Field permutationField = LevenbergMarquardtOptimizer.class.getDeclaredField("permutation");
                                                                            permutationField.setAccessible(true);
                                                                            permutationField.set(spyOptimizer, new int[]{0, 1});
                                                                            
                                                                            Field lmDirField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmDir");
                                                                            lmDirField.setAccessible(true);
                                                                            lmDirField.set(spyOptimizer, new double[2]);
                                                                            
                                                                            // Set protected cost field from parent class
                                                                            Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                            costField.setAccessible(true);
                                                                            costField.set(spyOptimizer, 1.0);
                                                                            
                                                                            // Instead of mocking the protected method, we'll use a different approach
                                                                            // by creating a subclass that overrides the protected method
                                                                            LevenbergMarquardtOptimizer testOptimizer = new LevenbergMarquardtOptimizer() {
                                                                                @Override
                                                                                protected void updateResidualsAndCost() {
                                                                                    try {
                                                                                        double currentCost = (Double) costField.get(this);
                                                                                        if (currentCost > 0.01) {
                                                                                            costField.set(this, currentCost * 0.5);
                                                                                        }
                                                                                        super.updateResidualsAndCost();
                                                                                    } catch (Exception e) {
                                                                                        throw new RuntimeException(e);
                                                                                    }
                                                                                }
                                                                            };
                                                                            
                                                                            // Copy all the field values to our test instance
                                                                            solvedColsField.set(testOptimizer, 2);
                                                                            diagRField.set(testOptimizer, new double[]{1.0, 1.0});
                                                                            jacNormField.set(testOptimizer, new double[]{1.0, 1.0});
                                                                            permutationField.set(testOptimizer, new int[]{0, 1});
                                                                            lmDirField.set(testOptimizer, new double[2]);
                                                                            costField.set(testOptimizer, 1.0);
                                                                            
                                                                            // Set tolerances
                                                                            testOptimizer.setCostRelativeTolerance(1.0e-10);
                                                                            testOptimizer.setParRelativeTolerance(1.0e-10);
                                                                            testOptimizer.setOrthoTolerance(1.0e-10);
                                                                            
                                                                            // Test
                                                                            Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                            doOptimizeMethod.setAccessible(true);
                                                                            VectorialPointValuePair result = (VectorialPointValuePair) doOptimizeMethod.invoke(testOptimizer);
                                                                            
                                                                            // Verify
                                                                            assertNotNull(result);
                                                                            assertTrue((Double) costField.get(testOptimizer) <= 0.01);
                                                                        }

    @Test
                                                                    public void testDoOptimize_WithCheckerConvergence() throws Exception {
                                                                        // Setup
                                                                        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer optimizer = 
                                                                            new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                                                                        
                                                                        // Get and set private fields
                                                                        java.lang.reflect.Field solvedColsField = org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                                                        solvedColsField.setAccessible(true);
                                                                        solvedColsField.setInt(optimizer, 2);
                                                                        
                                                                        java.lang.reflect.Field diagRField = org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                                                        diagRField.setAccessible(true);
                                                                        diagRField.set(optimizer, new double[]{1.0, 1.0});
                                                                        
                                                                        java.lang.reflect.Field jacNormField = org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                                                        jacNormField.setAccessible(true);
                                                                        jacNormField.set(optimizer, new double[]{1.0, 1.0});
                                                                        
                                                                        java.lang.reflect.Field permutationField = org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer.class.getDeclaredField("permutation");
                                                                        permutationField.setAccessible(true);
                                                                        permutationField.set(optimizer, new int[]{0, 1});
                                                                        
                                                                        java.lang.reflect.Field lmDirField = org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer.class.getDeclaredField("lmDir");
                                                                        lmDirField.setAccessible(true);
                                                                        lmDirField.set(optimizer, new double[2]);
                                                                        
                                                                        java.lang.reflect.Field costField = org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                        costField.setAccessible(true);
                                                                        costField.setDouble(optimizer, 1.0);
                                                                        
                                                                        // Mock convergence checker
                                                                        org.apache.commons.math.optimization.SimpleVectorialValueChecker checker = 
                                                                            new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
                                                                        optimizer.setConvergenceChecker(checker);
                                                                        
                                                                        // Test
                                                                        java.lang.reflect.Method doOptimizeMethod = org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                                                        doOptimizeMethod.setAccessible(true);
                                                                        org.apache.commons.math.optimization.VectorialPointValuePair result = 
                                                                            (org.apache.commons.math.optimization.VectorialPointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                        
                                                                        // Verify
                                                                        org.junit.Assert.assertNotNull(result);
                                                                    }

    @Test
                                    public void testDoOptimize_WithFailedIteration() throws Exception {
                                        // Setup
                                        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                        
                                        // Use reflection to set private fields
                                        Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
                                        solvedColsField.setAccessible(true);
                                        solvedColsField.set(optimizer, 2);
                                        
                                        Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
                                        diagRField.setAccessible(true);
                                        diagRField.set(optimizer, new double[]{1.0, 1.0});
                                        
                                        Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
                                        jacNormField.setAccessible(true);
                                        jacNormField.set(optimizer, new double[]{1.0, 1.0});
                                        
                                        Field permutationField = LevenbergMarquardtOptimizer.class.getDeclaredField("permutation");
                                        permutationField.setAccessible(true);
                                        permutationField.set(optimizer, new int[]{0, 1});
                                        
                                        Field lmDirField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmDir");
                                        lmDirField.setAccessible(true);
                                        lmDirField.set(optimizer, new double[2]);
                                        
                                        // Get protected cost field from parent class
                                        Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                        costField.setAccessible(true);
                                        costField.set(optimizer, 1.0);
                                        
                                        // Create a spy to intercept method calls
                                        LevenbergMarquardtOptimizer spyOptimizer = spy(optimizer);
                                        
                                        // Instead of mocking the private method, we'll simulate the failed iteration by
                                        // directly manipulating the cost field when the optimization is in progress
                                        // We'll use reflection to call the private method and manipulate the cost
                                        doAnswer(invocation -> {
                                            // Simulate a failed iteration by setting the cost back to a higher value
                                            costField.set(spyOptimizer, 2.0); // Higher cost means worse solution
                                            return null;
                                        }).when(spyOptimizer).getIterations();
                                        
                                        // Test
                                        Method doOptimize = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
                                        doOptimize.setAccessible(true);
                                        VectorialPointValuePair result = (VectorialPointValuePair) doOptimize.invoke(spyOptimizer);
                                        
                                        // Verify that the method continues despite failed iteration
                                        assertNotNull(result);
                                    }

    @Test
    public void testDoOptimize_ThrowsWhenCostToleranceTooSmall() throws Exception {
        // Setup
        LevenbergMarquardtOptimizer optimizer = new LevenbergMarquardtOptimizer();
        
        // Use reflection to set private fields
        Field solvedColsField = LevenbergMarquardtOptimizer.class.getDeclaredField("solvedCols");
        solvedColsField.setAccessible(true);
        solvedColsField.set(optimizer, 2);
        
        Field diagRField = LevenbergMarquardtOptimizer.class.getDeclaredField("diagR");
        diagRField.setAccessible(true);
        diagRField.set(optimizer, new double[]{1.0, 1.0});
        
        Field jacNormField = LevenbergMarquardtOptimizer.class.getDeclaredField("jacNorm");
        jacNormField.setAccessible(true);
        jacNormField.set(optimizer, new double[]{1.0, 1.0});
        
        Field permutationField = LevenbergMarquardtOptimizer.class.getDeclaredField("permutation");
        permutationField.setAccessible(true);
        permutationField.set(optimizer, new int[]{0, 1});
        
        Field lmDirField = LevenbergMarquardtOptimizer.class.getDeclaredField("lmDir");
        lmDirField.setAccessible(true);
        lmDirField.set(optimizer, new double[2]);
        
        Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
        costField.setAccessible(true);
        costField.set(optimizer, 1.0);
        
        // Create spy after setting fields
        LevenbergMarquardtOptimizer spyOptimizer = spy(optimizer);
        
        // For protected method, we need to use doAnswer() with the correct syntax
        // We need to get the method from the parent class
        Method updateResidualsAndCostMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("updateResidualsAndCost");
        updateResidualsAndCostMethod.setAccessible(true);
        
        // Mock the protected method using doAnswer with correct Mockito syntax
        // We need to use the method object to mock it
        doAnswer(invocation -> {
            Object spy = invocation.getMock();
            costField.set(spy, (Double)costField.get(spy) * 0.999999);
            return null;
}
        
        // Set very tight tolerances
        // Expect exception
        try {
            Method doOptimizeMethod = LevenbergMarquardtOptimizer.class.getDeclaredMethod("doOptimize");
            doOptimizeMethod.setAccessible(true);
            doOptimizeMethod.invoke(spyOptimizer);
            fail("Expected OptimizationException");
}{
            assertTrue(e.getCause() instanceof OptimizationException);
            assertTrue(e.getCause().getMessage().contains("too small cost relative tolerance"));
        }
    }


}
