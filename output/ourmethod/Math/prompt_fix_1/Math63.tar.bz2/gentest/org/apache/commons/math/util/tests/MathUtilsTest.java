package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.util.Localizable;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.exception.NonMonotonousSequenceException;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                          public void testEquals_IdenticalValues() {
                                                              assertTrue(MathUtils.equals(0.0, 0.0));
                                                              assertTrue(MathUtils.equals(1.0, 1.0));
                                                              assertTrue(MathUtils.equals(-1.0, -1.0));
                                                              assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE));
                                                              assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE));
                                                          }

 @Test
                                                          public void testEquals_WithinDefaultEpsilon() {
                                                              // Test values within default epsilon (1)
                                                              assertTrue(MathUtils.equals(1.0, 1.5));
                                                              assertTrue(MathUtils.equals(1.5, 1.0));
                                                              assertTrue(MathUtils.equals(-1.0, -1.5));
                                                              assertTrue(MathUtils.equals(-1.5, -1.0));
                                                          }

 @Test
                                                          public void testEquals_OutsideDefaultEpsilon() {
                                                              // Test values outside default epsilon (1)
                                                              assertFalse(MathUtils.equals(1.0, 2.1));
                                                              assertFalse(MathUtils.equals(2.1, 1.0));
                                                              assertFalse(MathUtils.equals(-1.0, -2.1));
                                                              assertFalse(MathUtils.equals(-2.1, -1.0));
                                                          }

 @Test
                                                          public void testEquals_NaNValues() {
                                                              // NaN should not equal NaN with default equals
                                                              assertFalse(MathUtils.equals(Double.NaN, Double.NaN));
                                                              assertFalse(MathUtils.equals(Double.NaN, 1.0));
                                                              assertFalse(MathUtils.equals(1.0, Double.NaN));
                                                          }

 @Test
                                                          public void testEquals_InfiniteValues() {
                                                              // Infinity cases
                                                              assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY));
                                                              assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY));
                                                              assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY));
                                                              assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY));
                                                              assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.MAX_VALUE));
                                                              assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, -Double.MAX_VALUE));
                                                          }

 @Test
                                                          public void testEquals_ExtremeValues() {
                                                              // Very large values that might have floating point representation issues
                                                              double largeValue = 1e300;
                                                              double slightlyDifferent = largeValue + (largeValue * MathUtils.EPSILON * 0.5);
                                                              assertTrue(MathUtils.equals(largeValue, slightlyDifferent));
                                                              
                                                              double tooDifferent = largeValue + (largeValue * MathUtils.EPSILON * 2);
                                                              assertFalse(MathUtils.equals(largeValue, tooDifferent));
                                                          }

 @Test
                                                          public void testEquals_ZeroAndNegativeZero() {
                                                              // 0.0 and -0.0 should be considered equal
                                                              assertTrue(MathUtils.equals(0.0, -0.0));
                                                          }

 @Test
                                                          public void testEquals_SubnormalNumbers() {
                                                              // Test with subnormal numbers
                                                              assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE));
                                                              assertFalse(MathUtils.equals(Double.MIN_VALUE, 0.0));
                                                          }

 @Test
                                                          public void testEquals_ExactlyEqualValues() {
                                                              assertTrue(MathUtils.equals(5.0, 5.0, 0.1));
                                                              assertTrue(MathUtils.equals(-3.14, -3.14, 0.001));
                                                              assertTrue(MathUtils.equals(0.0, 0.0, 0.0));
                                                          }

 @Test
                                                          public void testEquals_WithinEpsilon() {
                                                              assertTrue(MathUtils.equals(1.0, 1.09, 0.1));
                                                              assertTrue(MathUtils.equals(2.5, 2.45, 0.05));
                                                              assertTrue(MathUtils.equals(-10.0, -10.05, 0.1));
                                                          }

 @Test
                                                          public void testEquals_OutsideEpsilon() {
                                                              assertFalse(MathUtils.equals(1.0, 1.11, 0.1));
                                                              assertFalse(MathUtils.equals(100.0, 100.2, 0.1));
                                                              assertFalse(MathUtils.equals(-5.0, -5.11, 0.1));
                                                          }

 @Test
                                                          public void testEquals_WithZeroEpsilon() {
                                                              assertTrue(MathUtils.equals(3.0, 3.0, 0.0));
                                                              assertFalse(MathUtils.equals(3.0, 3.0000001, 0.0));
                                                          }

 @Test
                                                          public void testEquals_WithNaNs() {
                                                              assertFalse(MathUtils.equals(Double.NaN, 5.0, 0.1));
                                                              assertFalse(MathUtils.equals(5.0, Double.NaN, 0.1));
                                                              assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 0.1));
                                                          }

 @Test
                                                          public void testEquals_WithInfinities() {
                                                              assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 0.1));
                                                              assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.1));
                                                              assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.1));
                                                              assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, 1.0E308, 0.1));
                                                          }

 @Test
                                                          public void testEquals_WithVerySmallValues() {
                                                              assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE, 0.0));
                                                              assertTrue(MathUtils.equals(Double.MIN_VALUE, 0.0, Double.MIN_VALUE));
                                                              assertFalse(MathUtils.equals(Double.MIN_VALUE, 0.0, Double.MIN_VALUE / 2));
                                                          }

 @Test
                                                          public void testEquals_WithVeryLargeValues() {
                                                              double largeValue = 1.0E300;
                                                              assertTrue(MathUtils.equals(largeValue, largeValue, 0.0));
                                                              assertTrue(MathUtils.equals(largeValue, largeValue * (1.0 + 1.0E-15), largeValue * 1.0E-15));
                                                              assertFalse(MathUtils.equals(largeValue, largeValue * (1.0 + 1.0E-14), largeValue * 1.0E-15));
                                                          }

 @Test
                                                          public void testEquals_UsingClassEpsilonConstant() {
                                                              assertTrue(MathUtils.equals(1.0, 1.0 + MathUtils.EPSILON / 2, MathUtils.EPSILON));
                                                              assertFalse(MathUtils.equals(1.0, 1.0 + MathUtils.EPSILON * 2, MathUtils.EPSILON));
                                                          }

 @Test
                                                          public void testEquals_ExactValues() {
                                                              assertTrue(MathUtils.equals(0.0, 0.0, 1));
                                                              assertTrue(MathUtils.equals(1.0, 1.0, 1));
                                                              assertTrue(MathUtils.equals(-1.0, -1.0, 1));
                                                              assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE, 1));
                                                              assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE, 1));
                                                          }

 @Test
                                                          public void testEquals_WithinUlps() {
                                                              // Test values that are very close but not exactly equal
                                                              double a = 1.23456789;
                                                              double b = a + Math.ulp(a) * 2; // 2 ULPs apart
                                                              assertTrue(MathUtils.equals(a, b, 2));
                                                              assertFalse(MathUtils.equals(a, b, 1));
                                                      
                                                              // Test with negative numbers
                                                              double c = -3.14159265;
                                                              double d = c - Math.ulp(c) * 3; // 3 ULPs apart
                                                              assertTrue(MathUtils.equals(c, d, 3));
                                                              assertFalse(MathUtils.equals(c, d, 2));
                                                          }

 @Test
                                                          public void testEquals_NotEqualValues() {
                                                              assertFalse(MathUtils.equals(1.0, 2.0, 1000));
                                                              assertFalse(MathUtils.equals(-1.0, 1.0, 1000));
                                                              assertFalse(MathUtils.equals(Double.MAX_VALUE, Double.MIN_VALUE, Integer.MAX_VALUE));
                                                          }

 @Test
                                                          public void testEquals_NaNValues1() {
                                                              assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 1));
                                                              assertFalse(MathUtils.equals(1.0, Double.NaN, 1));
                                                              assertFalse(MathUtils.equals(Double.NaN, 1.0, 1));
                                                          }

 @Test
                                                          public void testEquals_InfinityValues() {
                                                              assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 1));
                                                              assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 1));
                                                              assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 1));
                                                              assertFalse(MathUtils.equals(1.0, Double.POSITIVE_INFINITY, 1));
                                                          }

 @Test
                                                          public void testEquals_ZeroValues() {
                                                              assertTrue(MathUtils.equals(0.0, -0.0, 1)); // +0 and -0 should be equal
                                                              assertTrue(MathUtils.equals(-0.0, 0.0, 1));
                                                          }

 @Test
                                                          public void testEquals_EdgeCaseValues() {
                                                              // Test with values near Double.MIN_VALUE
                                                              double tiny1 = Double.MIN_VALUE;
                                                              double tiny2 = Double.MIN_VALUE + Math.ulp(Double.MIN_VALUE);
                                                              assertTrue(MathUtils.equals(tiny1, tiny2, 1));
                                                              assertFalse(MathUtils.equals(tiny1, tiny2 * 2, 1));
                                                      
                                                              // Test with values near Double.MAX_VALUE
                                                              double huge1 = Double.MAX_VALUE;
                                                              double huge2 = Double.MAX_VALUE - Math.ulp(Double.MAX_VALUE) * 2;
                                                              assertTrue(MathUtils.equals(huge1, huge2, 2));
                                                              assertFalse(MathUtils.equals(huge1, huge2, 1));
                                                          }

 @Test
                                                          public void testEquals_SymmetricProperty() {
                                                              double x = 1.2345;
                                                              double y = x + Math.ulp(x) * 5;
                                                              assertEquals(MathUtils.equals(x, y, 5), MathUtils.equals(y, x, 5));
                                                          }

 @Test
                                                          public void testEquals_BothArraysNull() {
                                                              assertTrue(MathUtils.equals(null, null));
                                                          }

 @Test
                                                          public void testEquals_FirstArrayNull() {
                                                              double[] y = {1.0, 2.0};
                                                              assertFalse(MathUtils.equals(null, y));
                                                          }

 @Test
                                                          public void testEquals_SecondArrayNull() {
                                                              double[] x = {1.0, 2.0};
                                                              assertFalse(MathUtils.equals(x, null));
                                                          }

 @Test
                                                          public void testEquals_DifferentLengths() {
                                                              double[] x = {1.0, 2.0};
                                                              double[] y = {1.0};
                                                              assertFalse(MathUtils.equals(x, y));
                                                          }

 @Test
                                                          public void testEquals_EmptyArrays() {
                                                              double[] x = {};
                                                              double[] y = {};
                                                              assertTrue(MathUtils.equals(x, y));
                                                          }

 @Test
                                                          public void testEquals_EqualArrays() {
                                                              double[] x = {1.0, 2.0, 3.0};
                                                              double[] y = {1.0, 2.0, 3.0};
                                                              assertTrue(MathUtils.equals(x, y));
                                                          }

 @Test
                                                          public void testEquals_UnequalArrays() {
                                                              double[] x = {1.0, 2.0, 3.0};
                                                              double[] y = {1.0, 2.0, 4.0};
                                                              assertFalse(MathUtils.equals(x, y));
                                                          }

 @Test
                                                          public void testEquals_ArraysWithNaN() {
                                                              double[] x = {1.0, Double.NaN, 3.0};
                                                              double[] y = {1.0, Double.NaN, 3.0};
                                                              // Regular equals should return false for NaN values
                                                              assertFalse(MathUtils.equals(x, y));
                                                          }

 @Test
                                                          public void testEquals_ArraysWithDifferentNaN() {
                                                              double[] x = {1.0, Double.NaN, 3.0};
                                                              double[] y = {1.0, 2.0, 3.0};
                                                              assertFalse(MathUtils.equals(x, y));
                                                          }

 @Test
                                                          public void testEquals_ArraysWithInfinities() {
                                                              double[] x = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                              double[] y = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                              assertTrue(MathUtils.equals(x, y));
                                                          }

 @Test
                                                          public void testEquals_ArraysWithDifferentInfinities() {
                                                              double[] x = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                              double[] y = {1.0, Double.NEGATIVE_INFINITY, 3.0};
                                                              assertFalse(MathUtils.equals(x, y));
                                                          }

 @Test
                                                          public void testEquals_ArraysWithEpsilonDifference() {
                                                              double[] x = {1.0, 2.0 + MathUtils.EPSILON/2, 3.0};
                                                              double[] y = {1.0, 2.0, 3.0};
                                                              // Regular equals should be exact, so this should return false
                                                              assertFalse(MathUtils.equals(x, y));
                                                          }

 @Test
                                                          public void testEquals_LargeArrays() {
                                                              double[] x = new double[1000];
                                                              double[] y = new double[1000];
                                                              for (int i = 0; i < 1000; i++) {
                                                                  x[i] = i;
                                                                  y[i] = i;
                                                              }
                                                              assertTrue(MathUtils.equals(x, y));
                                                              
                                                              // Change one element
                                                              y[500] = 500.1;
                                                              assertFalse(MathUtils.equals(x, y));
                                                          }

 @Test
                                              public void testEquals_WithNegativeEpsilon() {
                                                  boolean result = MathUtils.equals(1.0, 1.1, -0.1);
                                                  // Add assertion if needed, for example:
                                                  // assertFalse(result);
                                              }

 @Test
              public void testCosh() {
                  // Test with 0 - should be 1 (e^0 + e^-0)/2 = (1+1)/2 = 1
                  assertEquals(1.0, MathUtils.cosh(0.0), 1e-15);
                  
                  // Test with positive value
                  double x = 1.5;
                  double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                  assertEquals(expected, MathUtils.cosh(x), 1e-15);
                  
                  // Test with negative value to check symmetry
                  double negX = -1.5;
                  assertEquals(expected, MathUtils.cosh(negX), 1e-15);
                  
                  // Test with larger value
                  x = 3.0;
                  expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                  assertEquals(expected, MathUtils.cosh(x), 1e-15);
              }

 @Test
             public void testCosh1() {
                 // Test with x = 1.0
                 // Expected: (e^1 + e^-1)/2 ≈ (2.71828 + 0.36788)/2 ≈ 1.54308
                 double input = 1.0;
                 double expected = (Math.exp(input) + Math.exp(-input)) / 2.0;
                 double actual = MathUtils.cosh(input);
                 
                 // Use delta of 1e-10 for floating point comparison
                 assertEquals("cosh(1.0) should return correct hyperbolic cosine", 
                             expected, actual, 1e-10);
                 
                 // Test with x = 0.0 (edge case)
                 // Expected: (e^0 + e^-0)/2 = (1 + 1)/2 = 1.0
                 assertEquals("cosh(0.0) should return 1.0", 
                             1.0, MathUtils.cosh(0.0), 1e-10);
                 
                 // Test with negative value (x = -2.0)
                 // Expected: (e^-2 + e^2)/2 ≈ (0.13534 + 7.38906)/2 ≈ 3.76220
                 input = -2.0;
                 expected = (Math.exp(input) + Math.exp(-input)) / 2.0;
                 actual = MathUtils.cosh(input);
                 assertEquals("cosh(-2.0) should return correct hyperbolic cosine",
                             expected, actual, 1e-10);
             }

 @Test
            public void testCoshDetectsMutant() {
                // Test with positive value
                double x = 1.0;
                double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                double actual = MathUtils.cosh(x);
                assertEquals("Cosh of positive value incorrect", expected, actual, 1e-10);
                
                // Test with negative value (this will catch the mutant)
                x = -1.0;
                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                actual = MathUtils.cosh(x);
                assertEquals("Cosh of negative value incorrect - mutant not detected", 
                            expected, actual, 1e-10);
                
                // Test with zero (both implementations would return same result)
                x = 0.0;
                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                actual = MathUtils.cosh(x);
                assertEquals("Cosh of zero incorrect", expected, actual, 1e-10);
            }

 @Test
           public void testCoshDetectsMutant1() {
               // Test with positive value where exp(x) != exp(-x)
               double x = 1.0;
               double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
               double actual = MathUtils.cosh(x);
               assertEquals("Cosh calculation is incorrect", expected, actual, 1e-10);
               
               // Test with negative value where exp(x) != exp(-x)
               x = -1.0;
               expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
               actual = MathUtils.cosh(x);
               assertEquals("Cosh calculation is incorrect", expected, actual, 1e-10);
               
               // Test with zero (only case where mutant would pass)
               x = 0.0;
               expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
               actual = MathUtils.cosh(x);
               assertEquals("Cosh calculation is incorrect", expected, actual, 1e-10);
           }

 @Test
          public void testCosh2() {
              // Test x = 0 (simplest case)
              assertEquals(1.0, MathUtils.cosh(0.0), 1e-15);
              
              // Test x = 1 (known value)
              double expected1 = (Math.exp(1) + Math.exp(-1)) / 2.0;
              assertEquals(expected1, MathUtils.cosh(1.0), 1e-15);
              
              // Test x = -1 (cosh is even function)
              assertEquals(expected1, MathUtils.cosh(-1.0), 1e-15);
              
              // Test x = 2 (another known value)
              double expected2 = (Math.exp(2) + Math.exp(-2)) / 2.0;
              assertEquals(expected2, MathUtils.cosh(2.0), 1e-15);
              
              // Test a larger value (x = 5)
              double expected5 = (Math.exp(5) + Math.exp(-5)) / 2.0;
              assertEquals(expected5, MathUtils.cosh(5.0), 1e-10);
          }

 @Test
         public void testCoshDetectsDivisionByZeroMutant() {
             // Test with a standard value (0 is a good choice as cosh(0) = 1)
             double input = 0.0;
             
             // Calculate expected value using original formula
             double expected = (Math.exp(input) + Math.exp(-input)) / 2.0;
             
             // Call the method and get actual value
             double actual = MathUtils.cosh(input);
             
             // Verify the result is finite and equals expected value
             assertTrue("Result should be finite", Double.isFinite(actual));
             assertEquals("Cosh calculation incorrect", expected, actual, MathUtils.EPSILON);
             
             // Additional check that would fail for the mutant
             assertNotEquals("Division by zero should not return normal value", 
                            Double.POSITIVE_INFINITY, actual, MathUtils.EPSILON);
             assertNotEquals("Division by zero should not return normal value", 
                            Double.NEGATIVE_INFINITY, actual, MathUtils.EPSILON);
             assertFalse("Division by zero should not return NaN", Double.isNaN(actual));
         }

 @Test
        public void testCosh3() {
            // Test with x = 0 (cosh(0) = 1)
            assertEquals(1.0, MathUtils.cosh(0.0), 1e-15);
            
            // Test with x = 1 (cosh(1) ≈ 1.543080634815244)
            assertEquals(1.543080634815244, MathUtils.cosh(1.0), 1e-15);
            
            // Test with x = -1 (cosh(-1) ≈ 1.543080634815244)
            assertEquals(1.543080634815244, MathUtils.cosh(-1.0), 1e-15);
            
            // Test with x = 2 (cosh(2) ≈ 3.7621956910836314)
            assertEquals(3.7621956910836314, MathUtils.cosh(2.0), 1e-15);
        }

 @Test
       public void testCoshDetectsAdditionToDivisionMutant() {
           // Test with x = 1.0 where the difference between original and mutant is significant
           double x = 1.0;
           
           // Expected value using correct formula: (e^x + e^-x)/2
           double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
           
           // Actual value from MathUtils.cosh()
           double actual = MathUtils.cosh(x);
           
           // Assert with delta for floating point precision
           assertEquals("Cosh calculation should use addition of exponentials, not division", 
                       expected, actual, 1e-15);
           
           // Additional test with x = -1.0 to ensure symmetry
           x = -1.0;
           expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
           actual = MathUtils.cosh(x);
           assertEquals("Cosh should be symmetric for positive and negative inputs",
                       expected, actual, 1e-15);
       }

 @Test
      public void testCoshWithEqualsParameterOrder() {
          // Test that equals method is called with correct parameter order
          double x = 1.0;
          double y = 1.0000000001; // Very close but not exactly equal
          
          // The original equals(x,y,1) would return true for these values
          // The mutated equals(y,x,1) would also return true (same result)
          // So we need to test the equals method directly
          
          // Test the equals method with different values to detect parameter order swap
          assertTrue(MathUtils.equals(x, y, 1)); // Should pass
          assertTrue(MathUtils.equals(y, x, 1)); // Should also pass (commutative)
          
          // To actually detect the parameter order swap, we need to test edge cases
          // where the order matters due to floating point precision
          double a = Double.MIN_VALUE;
          double b = Double.MIN_VALUE * 2;
          
          // These should be considered equal with maxUlps=1
          assertTrue(MathUtils.equals(a, b, 1));
          // If parameter order is swapped, this might fail due to floating point comparison
          assertTrue(MathUtils.equals(b, a, 1));
          
          // Test the cosh method itself with values that would reveal parameter order issues
          double result1 = MathUtils.cosh(1.0);
          double result2 = MathUtils.cosh(-1.0);
          assertEquals(result1, result2, 0.0001); // cosh is even function
          
          // Test with zero
          assertEquals(1.0, MathUtils.cosh(0.0), 0.0001);
      }

 @Test
  public void testCoshCalculation() {
      // Test basic functionality
      double x = 1.0;
      double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
      assertEquals(expected, MathUtils.cosh(x), 0.0001);
      
      // Test negative input (cosh is even function)
      assertEquals(MathUtils.cosh(x), MathUtils.cosh(-x), 0.0001);
      
      // Test zero input
      assertEquals(1.0, MathUtils.cosh(0.0), 0.0001);
      
      // Test large input
      double largeX = 100.0;
      double largeExpected = (Math.exp(largeX) + Math.exp(-largeX)) / 2.0;
      assertEquals(largeExpected, MathUtils.cosh(largeX), 0.0001);
      
      // Test very small input
      double smallX = 1e-10;
      double smallExpected = (Math.exp(smallX) + Math.exp(-smallX)) / 2.0;
      assertEquals(smallExpected, MathUtils.cosh(smallX), 0.0001);
  }

 @Test
     public void testEqualsWithOneUlpDifference() {
         // Test with numbers differing by exactly 1 ULP
         double base = 1.0;
         double oneUlpDiff = base + Math.ulp(base);
         
         // Should be considered equal in original (maxUlps=1)
         assertTrue(MathUtils.equals(base, oneUlpDiff, 1));
         
         // Test would fail if mutant (maxUlps=2) was present
         // because it would still return true
     }

 @Test
     public void testEqualsWithTwoUlpsDifference() {
         // Test with numbers differing by exactly 2 ULPs
         double base = 1.0;
         double twoUlpsDiff = base + 2 * Math.ulp(base);
         
         // Should be considered unequal in original (maxUlps=1)
         assertFalse(MathUtils.equals(base, twoUlpsDiff, 1));
         
         // Would return true in mutant (maxUlps=2)
         // So this test would catch the mutant
     }

 @Test
     public void testEqualsWithFractionalUlps() {
         // Test with numbers differing by fractional ULPs
         double base = 1.0;
         double halfUlpDiff = base + 0.5 * Math.ulp(base);
         
         // Should be considered equal in both original and mutant
         assertTrue(MathUtils.equals(base, halfUlpDiff, 1));
     }

}
