package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testDivide_ByNull() {
                thrown.expect(NullPointerException.class);
                Complex complex = new Complex(2, 3);
                complex.divide(null);
            }

    @Test
            public void testDivide_NaN() {
                Complex complex1 = new Complex(Double.NaN, 2);
                Complex complex2 = new Complex(1, 1);
                assertEquals(Complex.NaN, complex1.divide(complex2));
        
                Complex complex3 = new Complex(1, 2);
                Complex complex4 = new Complex(Double.NaN, 1);
                assertEquals(Complex.NaN, complex3.divide(complex4));
            }

    @Test
            public void testDivide_ByZero() {
                Complex complex1 = new Complex(2, 3);
                Complex zero = new Complex(0, 0);
                assertEquals(Complex.NaN, complex1.divide(zero));
        
                Complex complex2 = new Complex(0, 0);
                assertEquals(Complex.NaN, complex2.divide(zero));
            }

    @Test
            public void testDivide_ByInfinite() {
                Complex complex1 = new Complex(2, 3);
                Complex infinite = new Complex(Double.POSITIVE_INFINITY, 0);
                assertEquals(Complex.ZERO, complex1.divide(infinite));
        
                Complex complex2 = new Complex(0, 0);
                assertEquals(Complex.ZERO, complex2.divide(infinite));
            }

    @Test
            public void testDivide_RegularCase_AbsCGreaterThanAbsD() {
                Complex complex1 = new Complex(4, 2);
                Complex complex2 = new Complex(3, 1);
                Complex result = complex1.divide(complex2);
                
                // Expected: (4*3 + 2*1)/(3² + 1²) + i(2*3 - 4*1)/(3² + 1²) = 1.4 + 0.2i
                assertEquals(1.4, result.getReal(), 0.0001);
                assertEquals(0.2, result.getImaginary(), 0.0001);
            }

    @Test
            public void testDivide_RegularCase_AbsCLessThanAbsD() {
                Complex complex1 = new Complex(2, 4);
                Complex complex2 = new Complex(1, 3);
                Complex result = complex1.divide(complex2);
                
                // Expected: (2*1 + 4*3)/(1² + 3²) + i(4*1 - 2*3)/(1² + 3²) = 1.4 - 0.2i
                assertEquals(1.4, result.getReal(), 0.0001);
                assertEquals(-0.2, result.getImaginary(), 0.0001);
            }

    @Test
            public void testDivide_ByRealNumber() {
                Complex complex1 = new Complex(4, 8);
                Complex complex2 = new Complex(2, 0);
                Complex result = complex1.divide(complex2);
                
                assertEquals(2.0, result.getReal(), 0.0001);
                assertEquals(4.0, result.getImaginary(), 0.0001);
            }

    @Test
            public void testDivide_ByImaginaryNumber() {
                Complex complex1 = new Complex(6, 3);
                Complex complex2 = new Complex(0, 3);
                Complex result = complex1.divide(complex2);
                
                assertEquals(1.0, result.getReal(), 0.0001);
                assertEquals(-2.0, result.getImaginary(), 0.0001);
            }

    @Test
            public void testDivide_ComplexConjugates() {
                Complex complex1 = new Complex(3, 4);
                Complex complex2 = new Complex(3, -4);
                Complex result = complex1.divide(complex2);
                
                // Expected: (9-16)/25 + i(12+12)/25 = -0.28 + 0.96i
                assertEquals(-0.28, result.getReal(), 0.0001);
                assertEquals(0.96, result.getImaginary(), 0.0001);
            }

    @Test
            public void testDivide_RegularDivision() {
                Complex complex = new Complex(4.0, 6.0);
                Complex result = complex.divide(2.0);
                assertEquals(2.0, result.getReal(), 0.0001);
                assertEquals(3.0, result.getImaginary(), 0.0001);
            }

    @Test
            public void testDivide_DivisorIsZero() {
                Complex complex = new Complex(4.0, 6.0);
                Complex result = complex.divide(0.0);
                assertTrue(Double.isNaN(result.getReal()));
                assertTrue(Double.isNaN(result.getImaginary()));
            }

    @Test
            public void testDivide_DivisorIsNaN() {
                Complex complex = new Complex(4.0, 6.0);
                Complex result = complex.divide(Double.NaN);
                assertSame(Complex.NaN, result);
            }

    @Test
            public void testDivide_ComplexIsNaN() {
                Complex complex = new Complex(Double.NaN, Double.NaN);
                Complex result = complex.divide(2.0);
                assertSame(Complex.NaN, result);
            }

    @Test
            public void testDivide_DivisorIsInfinite_ComplexIsFinite() {
                Complex complex = new Complex(4.0, 6.0);
                Complex result = complex.divide(Double.POSITIVE_INFINITY);
                assertSame(Complex.ZERO, result);
            }

    @Test
            public void testDivide_DivisorIsInfinite_ComplexIsInfinite() {
                Complex complex = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                Complex result = complex.divide(Double.POSITIVE_INFINITY);
                assertSame(Complex.NaN, result);
            }

    @Test
            public void testDivide_ComplexIsZero() {
                Complex complex = new Complex(0.0, 0.0);
                Complex result = complex.divide(2.0);
                assertEquals(0.0, result.getReal(), 0.0001);
                assertEquals(0.0, result.getImaginary(), 0.0001);
            }

    @Test
            public void testDivide_ComplexHasZeroRealPart() {
                Complex complex = new Complex(0.0, 6.0);
                Complex result = complex.divide(2.0);
                assertEquals(0.0, result.getReal(), 0.0001);
                assertEquals(3.0, result.getImaginary(), 0.0001);
            }

    @Test
            public void testDivide_ComplexHasZeroImaginaryPart() {
                Complex complex = new Complex(4.0, 0.0);
                Complex result = complex.divide(2.0);
                assertEquals(2.0, result.getReal(), 0.0001);
                assertEquals(0.0, result.getImaginary(), 0.0001);
            }

    @Test
            public void testDivide_NegativeDivisor() {
                Complex complex = new Complex(4.0, 6.0);
                Complex result = complex.divide(-2.0);
                assertEquals(-2.0, result.getReal(), 0.0001);
                assertEquals(-3.0, result.getImaginary(), 0.0001);
            }

    @Test
            public void testDivide_ComplexWithNegativeValues() {
                Complex complex = new Complex(-4.0, -6.0);
                Complex result = complex.divide(2.0);
                assertEquals(-2.0, result.getReal(), 0.0001);
                assertEquals(-3.0, result.getImaginary(), 0.0001);
            }

    @Test
    public void testDivide_WithMock() {
        Complex mockDivisor = mock(Complex.class);
        when(mockDivisor.isNaN()).thenReturn(false);
        // Replace isZero() method check with field check through getters
        when(mockDivisor.getReal()).thenReturn(2.0);  // non-zero real
        when(mockDivisor.getImaginary()).thenReturn(1.0);  // non-zero imaginary
        when(mockDivisor.isInfinite()).thenReturn(false);
        
        Complex complex = new Complex(4, 2);
        Complex result = complex.divide(mockDivisor);
        
        verify(mockDivisor).isNaN();
        verify(mockDivisor).isInfinite();
        verify(mockDivisor, atLeastOnce()).getReal();
        verify(mockDivisor, atLeastOnce()).getImaginary();
        
        // Expected: (4*2 + 2*1)/5 + i(2*2 - 4*1)/5 = 2 + 0i
        assertEquals(2.0, result.getReal(), 0.0001);
        assertEquals(0.0, result.getImaginary(), 0.0001);
    }


}
