package gentest.org.apache.commons.math3.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.threed.*;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.geometry.Vector;
import org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.Embedding;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Precision;
 
public class LineTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                         public void testRevert_WithSpecificVectors() {
                             // Arrange
                             Vector3D direction = new Vector3D(1, 2, 3);
                             Vector3D zero = new Vector3D(0, 0, 0);
                             Line line = new Line(zero, direction);
                             
                             // Act
                             Line reverted = line.revert();
                             
                             // Assert
                             assertEquals("Direction should be negated", 
                                          new Vector3D(-1, -2, -3), reverted.getDirection());
                             assertEquals("Origin should remain unchanged", 
                                          zero, reverted.getOrigin());
                         }

 @Test
                         public void testRevert_TwiceReturnsOriginalDirection() {
                             // Arrange
                             Vector3D direction = new Vector3D(1, 0, 0);
                             Vector3D zero = new Vector3D(0, 0, 0);
                             Line line = new Line(zero, direction);
                             
                             // Act
                             Line revertedOnce = line.revert();
                             Line revertedTwice = revertedOnce.revert();
                             
                             // Assert
                             assertEquals("Double revert should return original direction", 
                                          direction, revertedTwice.getDirection());
                         }

 @Test
                 public void testRevert_ReturnsNewInstance() {
                     // Arrange
                     Vector3D p1 = new Vector3D(1, 0, 0);
                     Vector3D p2 = new Vector3D(0, 1, 0);
                     Line originalLine = new Line(p1, p2);
                     
                     // Act
                     Line reverted = originalLine.revert();
                     
                     // Assert
                     assertNotSame("Reverted line should be a new instance", originalLine, reverted);
                 }

 @Test
                 public void testRevert_NegatesDirectionVector() {
                     // Arrange
                     Vector3D mockDirection = mock(Vector3D.class);
                     Vector3D negatedDirection = mock(Vector3D.class);
                     Vector3D origin = mock(Vector3D.class);
                     Line originalLine = new Line(origin, mockDirection);
                     
                     when(mockDirection.negate()).thenReturn(negatedDirection);
                     
                     // Act
                     Line reverted = originalLine.revert();
                     
                     // Assert
                     verify(mockDirection).negate();
                     assertEquals("Direction should be negated", negatedDirection, reverted.getDirection());
                 }

 @Test
                 public void testRevert_PreservesOrigin() {
                     // Arrange
                     Vector3D p1 = new Vector3D(1, 0, 0);
                     Vector3D p2 = new Vector3D(0, 1, 0);
                     Line originalLine = new Line(p1, p2);
                     Vector3D expectedOrigin = originalLine.getOrigin();
                     
                     // Act
                     Line reverted = originalLine.revert();
                     
                     // Assert
                     assertEquals("Origin should remain unchanged", expectedOrigin, reverted.getOrigin());
                 }

 @Test
             public void testRvertNegatesDirection() {
                 // Create original direction vector
                 Vector3D originalDirection = new Vector3D(1, 2, 3);
                 
                 // Create a mock Line with known direction
                 Line originalLine = mock(Line.class);
                 when(originalLine.getDirection()).thenReturn(originalDirection);
                 when(originalLine.getOrigin()).thenReturn(Vector3D.ZERO);
                 
                 // Create actual Line instance using copy constructor
                 Line line = new Line(originalLine);
                 
                 // Call revert method
                 Line reverted = line.revert();
                 
                 // Verify the direction was negated
                 Vector3D expectedDirection = originalDirection.negate();
                 assertEquals(expectedDirection, reverted.getDirection());
                 
                 // Verify original direction remains unchanged
                 assertEquals(originalDirection, line.getDirection());
                 
                 // Verify zero point remains the same
                 assertEquals(line.getOrigin(), reverted.getOrigin());
             }

 @Test
                public void testRvertNegatesCorrectDirection() {
                    // Setup original line with known direction
                    Vector3D originalDirection = new Vector3D(1, 2, 3);
                    Vector3D origin = new Vector3D(0, 0, 0);
                    Line originalLine = new Line(origin, originalDirection);
                    
                    // Call revert
                    Line revertedLine = originalLine.revert();
                    
                    // Verify original line direction remains unchanged
                    assertEquals(originalDirection, originalLine.getDirection());
                    
                    // Verify reverted line has properly negated direction
                    Vector3D expectedRevertedDirection = originalDirection.negate();
                    assertEquals(expectedRevertedDirection, revertedLine.getDirection());
                    
                    // Additional check to ensure it's not just using original direction
                    assertNotEquals(originalDirection, revertedLine.getDirection());
                }

 @Test
               public void testRevertNegatesDirection() {
                   // Create original line with a non-normalized direction
                   Vector3D originalDirection = new Vector3D(1, 2, 3);
                   Vector3D origin = new Vector3D(0, 0, 0);
                   Line originalLine = new Line(origin, originalDirection);
                   
                   // Get original direction (should be normalized)
                   Vector3D normalizedOriginal = originalLine.getDirection();
                   
                   // Create reverted line
                   Line revertedLine = originalLine.revert();
                   
                   // Verify the direction is exactly negated (not just normalized)
                   Vector3D expectedDirection = normalizedOriginal.negate();
                   Vector3D actualDirection = revertedLine.getDirection();
                   
                   // Check both direction and magnitude
                   assertEquals("X component should be negated", 
                       expectedDirection.getX(), actualDirection.getX(), 1e-10);
                   assertEquals("Y component should be negated", 
                       expectedDirection.getY(), actualDirection.getY(), 1e-10);
                   assertEquals("Z component should be negated", 
                       expectedDirection.getZ(), actualDirection.getZ(), 1e-10);
                       
                   // Also verify the magnitude is still 1 (normalized)
                   assertEquals(1.0, actualDirection.getNorm(), 1e-10);
               }

 @Test
              public void testRevertNegatesDirection1() {
                  // Setup original line with known direction
                  Vector3D originalDirection = new Vector3D(1, 2, 3);
                  Vector3D point1 = new Vector3D(0, 0, 0);
                  Vector3D point2 = originalDirection; // second point defines direction
                  Line originalLine = new Line(point1, point2);
                  
                  // Call revert
                  Line revertedLine = originalLine.revert();
                  
                  // Verify the direction is properly negated
                  Vector3D expectedDirection = originalDirection.negate();
                  Vector3D actualDirection = revertedLine.getDirection();
                  
                  assertEquals("Reverted line direction should be negated", 
                               expectedDirection, actualDirection);
                  
                  // Also verify the original line's direction wasn't changed
                  assertEquals("Original line direction should remain unchanged",
                              originalDirection, originalLine.getDirection());
              }

 @Test
         public void testRevertNegatesDirection2() {
             // Setup original direction vector
             Vector3D originalDirection = new Vector3D(1, 2, 3);
             
             // Create original line
             Line originalLine = new Line(Vector3D.ZERO, originalDirection);
             
             // Call revert()
             Line revertedLine = originalLine.revert();
             
             // Verify the reverted line has negated direction
             Vector3D expectedDirection = originalDirection.negate();
             Vector3D actualDirection = revertedLine.getDirection();
             
             // Assert direction was negated
             assertEquals("Reverted line should have negated direction", 
                          expectedDirection, actualDirection);
             
             // Also verify original line wasn't modified
             assertEquals("Original line direction should remain unchanged",
                          originalDirection, originalLine.getDirection());
         }

 @Test
            public void testRevertDirection() {
                // Create original line with known direction
                Vector3D originalDirection = new Vector3D(1.0, 2.0, 3.0);
                Line originalLine = new Line(Vector3D.ZERO, originalDirection);
                
                // Get reverted line
                Line revertedLine = originalLine.revert();
                Vector3D revertedDirection = revertedLine.getDirection();
                
                // Verify the direction was properly negated
                // This will catch the scalarMultiply(-1) mutant because:
                // 1. It explicitly checks for negate() behavior
                // 2. There might be subtle differences in implementation between negate() and scalarMultiply(-1)
                assertEquals(originalDirection.negate(), revertedDirection);
                
                // Additional check to ensure the direction is exactly negated
                assertEquals(-1.0, revertedDirection.getX() / originalDirection.getX(), 1e-15);
                assertEquals(-1.0, revertedDirection.getY() / originalDirection.getY(), 1e-15);
                assertEquals(-1.0, revertedDirection.getZ() / originalDirection.getZ(), 1e-15);
                
                // Test with edge case - zero vector (though this shouldn't happen in normal Line usage)
                Vector3D zeroDirection = Vector3D.ZERO;
                Line zeroLine = new Line(Vector3D.ZERO, zeroDirection);
                Line revertedZeroLine = zeroLine.revert();
                assertEquals(zeroDirection, revertedZeroLine.getDirection());
            }

 @Test
           public void testRvertMaintainsImmutability() {
               // Setup original line
               Vector3D p1 = new Vector3D(1, 0, 0);
               Vector3D p2 = new Vector3D(2, 0, 0);
               Line original = new Line(p1, p2);
               Vector3D originalDirection = original.getDirection();
               
               // Call revert
               Line reverted = original.revert();
               
               // Verify the reverted line has negated direction
               assertEquals(originalDirection.negate(), reverted.getDirection());
               
               // Verify original line remains unchanged
               assertEquals(originalDirection, original.getDirection());
               
               // Verify we got a new instance
               assertNotSame(original, reverted);
               
               // The following would not compile in original version but would in mutated version
               // To detect the mutant, we can verify the method consistently returns proper Line objects
               // by calling revert multiple times and checking consistency
               Line reverted2 = original.revert();
               assertEquals(reverted.getDirection(), reverted2.getDirection());
               assertNotSame(reverted, reverted2);
           }

 @Test
          public void testRvertPreservesOriginalDirection() {
              // Setup original line with known direction
              Vector3D originalDirection = new Vector3D(1, 2, 3);
              Vector3D origin = new Vector3D(0, 0, 0);
              Line originalLine = new Line(origin, originalDirection);
              
              // Call revert
              Line revertedLine = originalLine.revert();
              
              // Verify original line's direction wasn't changed
              assertEquals(originalDirection, originalLine.getDirection());
              
              // Verify reverted line has negated direction
              assertEquals(originalDirection.negate(), revertedLine.getDirection());
          }

 @Test
         public void testRvertPreservesOriginalDirection1() {
             // Setup original line with known direction
             Vector3D originalDirection = new Vector3D(1, 0, 0);
             Vector3D p1 = new Vector3D(0, 0, 0);
             Vector3D p2 = new Vector3D(1, 0, 0);
             Line originalLine = new Line(p1, p2);
             
             // Store original direction for comparison
             Vector3D storedOriginalDirection = originalLine.getDirection();
             
             // Create reverted line
             Line revertedLine = originalLine.revert();
             
             // Verify original line's direction wasn't modified
             assertEquals("Original line direction should remain unchanged", 
                         storedOriginalDirection, 
                         originalLine.getDirection());
             
             // Verify reverted line has opposite direction
             assertEquals("Reverted line should have negated direction",
                         storedOriginalDirection.negate(),
                         revertedLine.getDirection());
         }

 @Test
         public void testRvertWithModifiedDirection() {
             // Setup original line
             Vector3D p1 = new Vector3D(0, 0, 0);
             Vector3D p2 = new Vector3D(1, 0, 0);
             Line originalLine = new Line(p1, p2);
             
             // Modify the direction before reverting
             Vector3D newDirection = new Vector3D(0, 1, 0);
             // Note: Since direction is private, we need to use reflection or assume there's a way to modify it
             // For this test, we'll assume there's a way to modify the direction
             // This would catch the mutant because the mutant uses the current direction
             
             // Using reflection to modify private field for test purposes
             try {
                 java.lang.reflect.Field directionField = Line.class.getDeclaredField("direction");
                 directionField.setAccessible(true);
                 directionField.set(originalLine, newDirection);
             } catch (Exception e) {
                 fail("Failed to modify direction field for testing");
             }
             
             // Create reverted line
             Line revertedLine = originalLine.revert();
             
             // Verify the reverted line has the negated NEW direction
             assertEquals("Reverted line should have negated current direction",
                         newDirection.negate(),
                         revertedLine.getDirection());
         }

 @Test
        public void testRevertWithSpecialVector() {
            // Create a line with a special direction vector that might expose differences
            // between negate() and scalarMultiply(-1)
            Vector3D specialDirection = new Vector3D(Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY);
            Line originalLine = new Line(Vector3D.ZERO, specialDirection);
            
            // Call the revert method
            Line revertedLine = originalLine.revert();
            
            // Get the original and reverted directions
            Vector3D originalDirection = originalLine.getDirection();
            Vector3D revertedDirection = revertedLine.getDirection();
            
            // Verify the reverted direction is exactly the negated version
            // This will fail if scalarMultiply(-1) was used instead of negate()
            // because they handle special values differently
            assertEquals(originalDirection.negate(), revertedDirection);
            
            // Additional check to ensure it's not just scalarMultiply(-1)
            assertNotEquals(originalDirection.scalarMultiply(-1), revertedDirection);
        }

 @Test
        public void testRevertWithNormalVector() {
            // Test with normal vector to ensure basic functionality works
            Vector3D normalDirection = new Vector3D(1, 2, 3);
            Line originalLine = new Line(Vector3D.ZERO, normalDirection);
            
            Line revertedLine = originalLine.revert();
            Vector3D revertedDirection = revertedLine.getDirection();
            
            // For normal vectors, both operations should produce same result
            // This ensures the test doesn't fail for correct implementations
            assertEquals(normalDirection.negate(), revertedDirection);
            assertEquals(normalDirection.scalarMultiply(-1), revertedDirection);
        }

 @Test
   public void testRvertReturnsConsistentFinalLine() {
       // Setup original line
       Vector3D origin = new Vector3D(1, 2, 3);
       Vector3D direction = new Vector3D(4, 5, 6);
       Line originalLine = new Line(origin, direction);
       
       // Call revert
       Line revertedLine = originalLine.revert();
       
       // Verify the returned line is properly reversed
       assertEquals(originalLine.getOrigin(), revertedLine.getOrigin());
       assertEquals(originalLine.getDirection().negate(), revertedLine.getDirection());
       
       // Verify the returned line is a new instance
       assertNotSame(originalLine, revertedLine);
       
       // Additional verification that the returned line maintains its state
       Line secondRevert = revertedLine.revert();
       assertEquals(originalLine.getDirection(), secondRevert.getDirection());
       assertEquals(originalLine.getOrigin(), secondRevert.getOrigin());
       
       // This test would catch if the 'reverted' variable was reassigned later in the method
       // due to missing 'final' modifier, as the second revert wouldn't match expectations
   }

 @Test(expected = MathIllegalArgumentException.class)
  public void testRevertWithZeroDirectionThrowsProperException() {
      // Create a line with zero direction vector
      Vector3D zeroVector = new Vector3D(0, 0, 0);
      Vector3D point = new Vector3D(1, 1, 1);
      
      // This should throw exception when direction is zero
      Line line = new Line(point, zeroVector);
      
      try {
          line.revert();
          fail("Expected MathIllegalArgumentException");
      } catch (MathIllegalArgumentException e) {
          // Verify the exception message is not null and matches expected
          assertNotNull("Exception message should not be null", e.getMessage());
          assertEquals(LocalizedFormats.ZERO_NORM.toString(), e.getMessage());
          throw e; // rethrow for @Test expected
      }
  }

 @Test
     public void testRvertThrowsExceptionWithLocalizedMessageWhenDirectionHasZeroNorm() {
         // Create a mock Line with zero direction vector
         Line originalLine = mock(Line.class);
         Vector3D zeroVector = new Vector3D(0, 0, 0);
         when(originalLine.getDirection()).thenReturn(zeroVector);
         
         // Set up expectation for the exception
         thrown.expect(MathIllegalArgumentException.class);
         thrown.expectMessage(LocalizedFormats.ZERO_NORM.toString());
         
         // Call the method that should throw the exception
         originalLine.revert();
     }

}
