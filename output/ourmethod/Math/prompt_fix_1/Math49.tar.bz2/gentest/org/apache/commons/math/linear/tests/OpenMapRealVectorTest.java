package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.OpenIntToDoubleHashMap;
import org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math.util.FastMath;
 
public class OpenMapRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                              public void testEbeDivide_TypicalValues() {
                                  // Setup test vectors
                                  double[] data1 = {4.0, 9.0, 16.0};
                                  double[] data2 = {2.0, 3.0, 4.0};
                                  OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                  OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                  
                                  // Execute operation
                                  OpenMapRealVector result = vector1.ebeDivide(vector2);
                                  
                                  // Verify results
                                  assertEquals(2.0, result.getEntry(0), 0.0001);
                                  assertEquals(3.0, result.getEntry(1), 0.0001);
                                  assertEquals(4.0, result.getEntry(2), 0.0001);
                              }

    @Test
                              public void testEbeDivide_SparseVectors() {
                                  // Setup sparse vectors (some zero/default values)
                                  double[] data1 = {0.0, 5.0, 0.0, 10.0};
                                  double[] data2 = {1.0, 2.0, 1.0, 5.0};
                                  OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                  OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                  
                                  // Execute operation
                                  OpenMapRealVector result = vector1.ebeDivide(vector2);
                                  
                                  // Verify results (default value for 0/1 should be 0)
                                  assertEquals(0.0, result.getEntry(0), 0.0001);
                                  assertEquals(2.5, result.getEntry(1), 0.0001);
                                  assertEquals(0.0, result.getEntry(2), 0.0001);
                                  assertEquals(2.0, result.getEntry(3), 0.0001);
                              }

    @Test
                              public void testEbeDivide_DimensionMismatch() {
                                  // Setup vectors with different dimensions
                                  double[] data1 = {1.0, 2.0};
                                  double[] data2 = {1.0, 2.0, 3.0};
                                  OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                  OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                  
                                  // Expect exception
                                  thrown.expect(IllegalArgumentException.class);
                                  thrown.expectMessage("vector length mismatch");
                                  
                                  // Execute operation
                                  vector1.ebeDivide(vector2);
                              }

    @Test
                              public void testEbeDivide_DivideByZero() {
                                  // Setup vectors with zero in divisor
                                  double[] data1 = {1.0, 2.0, 3.0};
                                  double[] data2 = {1.0, 0.0, 1.0};
                                  OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                  OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                  
                                  // Expect exception
                                  thrown.expect(ArithmeticException.class);
                                  thrown.expectMessage("/ by zero");
                                  
                                  // Execute operation
                                  vector1.ebeDivide(vector2);
                              }

    @Test
                              public void testEbeDivide_WithMock() {
                                  // Create mock RealVector
                                  RealVector mockVector = mock(RealVector.class);
                                  when(mockVector.getDimension()).thenReturn(3);
                                  when(mockVector.getEntry(0)).thenReturn(2.0);
                                  when(mockVector.getEntry(1)).thenReturn(4.0);
                                  when(mockVector.getEntry(2)).thenReturn(8.0);
                                  
                                  // Setup test vector
                                  double[] data = {4.0, 8.0, 16.0};
                                  OpenMapRealVector vector = new OpenMapRealVector(data);
                                  
                                  // Execute operation
                                  OpenMapRealVector result = vector.ebeDivide(mockVector);
                                  
                                  // Verify results
                                  assertEquals(2.0, result.getEntry(0), 0.0001);
                                  assertEquals(2.0, result.getEntry(1), 0.0001);
                                  assertEquals(2.0, result.getEntry(2), 0.0001);
                                  
                                  // Verify mock interactions
                                  verify(mockVector, times(1)).getDimension();
                                  verify(mockVector, times(1)).getEntry(0);
                                  verify(mockVector, times(1)).getEntry(1);
                                  verify(mockVector, times(1)).getEntry(2);
                              }

    @Test
                              public void testEbeDivide_EmptyVector() {
                                  // Setup empty vectors
                                  OpenMapRealVector vector1 = new OpenMapRealVector(0);
                                  OpenMapRealVector vector2 = new OpenMapRealVector(0);
                                  
                                  // Execute operation (should not throw)
                                  OpenMapRealVector result = vector1.ebeDivide(vector2);
                                  
                                  // Verify result is empty
                                  assertEquals(0, result.getDimension());
                              }

    @Test
                              public void testEbeDivide_TypicalValues1() {
                                  // Setup test vector with some non-zero entries
                                  double[] values = {1.0, 0.0, 3.0, 0.0, 5.0};
                                  OpenMapRealVector vector = new OpenMapRealVector(values);
                                  
                                  // Setup divisor array
                                  double[] divisor = {2.0, 1.0, 3.0, 1.0, 5.0};
                                  
                                  // Perform operation
                                  OpenMapRealVector result = vector.ebeDivide(divisor);
                                  
                                  // Verify results
                                  assertEquals(0.5, result.getEntry(0), 0.0001);
                                  assertEquals(0.0, result.getEntry(1), 0.0001); // remains 0
                                  assertEquals(1.0, result.getEntry(2), 0.0001);
                                  assertEquals(0.0, result.getEntry(3), 0.0001); // remains 0
                                  assertEquals(1.0, result.getEntry(4), 0.0001);
                              }

    @Test
                              public void testEbeDivide_WithZeroInDivisor() {
                                  // Setup test vector
                                  double[] values = {1.0, 2.0, 3.0};
                                  OpenMapRealVector vector = new OpenMapRealVector(values);
                                  
                                  // Setup divisor with zero
                                  double[] divisor = {1.0, 0.0, 3.0};
                                  
                                  // Perform operation - should divide by zero
                                  OpenMapRealVector result = vector.ebeDivide(divisor);
                                  
                                  // Verify division by zero results in Infinity
                                  assertEquals(1.0, result.getEntry(0), 0.0001);
                                  assertTrue(Double.isInfinite(result.getEntry(1)));
                                  assertEquals(1.0, result.getEntry(2), 0.0001);
                              }

    @Test
                              public void testEbeDivide_DimensionMismatch1() {
                                  // Setup test vector
                                  double[] values = {1.0, 2.0};
                                  OpenMapRealVector vector = new OpenMapRealVector(values);
                                  
                                  // Setup divisor with wrong dimension
                                  double[] divisor = {1.0, 2.0, 3.0};
                                  
                                  // Expect exception
                                  thrown.expect(IllegalArgumentException.class);
                                  thrown.expectMessage("vector length mismatch");
                                  
                                  // Perform operation
                                  vector.ebeDivide(divisor);
                              }

    @Test
                              public void testEbeDivide_EmptyVector1() {
                                  // Setup empty vector
                                  OpenMapRealVector vector = new OpenMapRealVector(0);
                                  
                                  // Setup empty divisor
                                  double[] divisor = {};
                                  
                                  // Perform operation
                                  OpenMapRealVector result = vector.ebeDivide(divisor);
                                  
                                  // Verify result is empty
                                  assertEquals(0, result.getDimension());
                              }

    @Test
                              public void testEbeDivide_SparseVector() {
                                  // Setup sparse vector (only index 2 has value)
                                  OpenMapRealVector vector = new OpenMapRealVector(3);
                                  vector.setEntry(2, 6.0);
                                  
                                  // Setup divisor
                                  double[] divisor = {1.0, 1.0, 3.0};
                                  
                                  // Perform operation
                                  OpenMapRealVector result = vector.ebeDivide(divisor);
                                  
                                  // Verify only the non-zero entry was divided
                                  assertEquals(0.0, result.getEntry(0), 0.0001);
                                  assertEquals(0.0, result.getEntry(1), 0.0001);
                                  assertEquals(2.0, result.getEntry(2), 0.0001);
                              }

    @Test
                              public void testEbeDivide_WithNegativeValues() {
                                  // Setup test vector with negative values
                                  double[] values = {-4.0, 0.0, 9.0};
                                  OpenMapRealVector vector = new OpenMapRealVector(values);
                                  
                                  // Setup divisor with negative values
                                  double[] divisor = {2.0, 1.0, -3.0};
                                  
                                  // Perform operation
                                  OpenMapRealVector result = vector.ebeDivide(divisor);
                                  
                                  // Verify results
                                  assertEquals(-2.0, result.getEntry(0), 0.0001);
                                  assertEquals(0.0, result.getEntry(1), 0.0001);
                                  assertEquals(-3.0, result.getEntry(2), 0.0001);
                              }

    @Test
                              public void testEbeDivide_OriginalVectorUnchanged() {
                                  // Setup test vector
                                  double[] values = {1.0, 2.0, 3.0};
                                  OpenMapRealVector vector = new OpenMapRealVector(values);
                                  
                                  // Setup divisor
                                  double[] divisor = {1.0, 2.0, 3.0};
                                  
                                  // Perform operation
                                  OpenMapRealVector result = vector.ebeDivide(divisor);
                                  
                                  // Verify original vector unchanged
                                  assertEquals(1.0, vector.getEntry(0), 0.0001);
                                  assertEquals(2.0, vector.getEntry(1), 0.0001);
                                  assertEquals(3.0, vector.getEntry(2), 0.0001);
                              }

    @Test
                              public void testEbeMultiply_TypicalCase() {
                                  // Setup test vectors
                                  double[] data1 = {1.0, 2.0, 3.0};
                                  double[] data2 = {4.0, 5.0, 6.0};
                                  OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                  OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                  
                                  // Perform operation
                                  OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                  
                                  // Verify results
                                  assertEquals(3, result.getDimension());
                                  assertEquals(4.0, result.getEntry(0), 0.0001);
                                  assertEquals(10.0, result.getEntry(1), 0.0001);
                                  assertEquals(18.0, result.getEntry(2), 0.0001);
                              }

    @Test
                              public void testEbeMultiply_WithSparseVectors() {
                                  // Setup sparse vectors (some zero values)
                                  double[] data1 = {0.0, 2.0, 0.0, 4.0};
                                  double[] data2 = {1.0, 0.0, 3.0, 0.0};
                                  OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                  OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                  
                                  // Perform operation
                                  OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                  
                                  // Verify results
                                  assertEquals(4, result.getDimension());
                                  assertEquals(0.0, result.getEntry(0), 0.0001);
                                  assertEquals(0.0, result.getEntry(1), 0.0001);
                                  assertEquals(0.0, result.getEntry(2), 0.0001);
                                  assertEquals(0.0, result.getEntry(3), 0.0001);
                              }

    @Test
                              public void testEbeMultiply_DifferentDimensionsShouldThrowException() {
                                  // Setup vectors with different dimensions
                                  double[] data1 = {1.0, 2.0};
                                  double[] data2 = {1.0, 2.0, 3.0};
                                  OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                  OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                  
                                  // Expect exception
                                  thrown.expect(IllegalArgumentException.class);
                                  thrown.expectMessage("vector length mismatch");
                                  
                                  // Perform operation that should throw
                                  vector1.ebeMultiply(vector2);
                              }

    @Test
                              public void testEbeMultiply_WithEmptyVector() {
                                  // Setup empty vectors
                                  OpenMapRealVector vector1 = new OpenMapRealVector(0);
                                  OpenMapRealVector vector2 = new OpenMapRealVector(0);
                                  
                                  // Perform operation
                                  OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                  
                                  // Verify results
                                  assertEquals(0, result.getDimension());
                              }

    @Test
                              public void testEbeMultiply_WithNegativeValues() {
                                  // Setup vectors with negative values
                                  double[] data1 = {-1.0, -2.0, -3.0};
                                  double[] data2 = {2.0, -3.0, 4.0};
                                  OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                  OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                  
                                  // Perform operation
                                  OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                  
                                  // Verify results
                                  assertEquals(3, result.getDimension());
                                  assertEquals(-2.0, result.getEntry(0), 0.0001);
                                  assertEquals(6.0, result.getEntry(1), 0.0001);
                                  assertEquals(-12.0, result.getEntry(2), 0.0001);
                              }

    @Test
                              public void testEbeMultiply_WithMockedRealVector() {
                                  // Setup mock RealVector
                                  RealVector mockedVector = mock(RealVector.class);
                                  when(mockedVector.getDimension()).thenReturn(3);
                                  when(mockedVector.getEntry(0)).thenReturn(1.0);
                                  when(mockedVector.getEntry(1)).thenReturn(0.0);
                                  when(mockedVector.getEntry(2)).thenReturn(-2.0);
                                  
                                  // Setup test vector
                                  double[] data = {2.0, 3.0, 4.0};
                                  OpenMapRealVector vector = new OpenMapRealVector(data);
                                  
                                  // Perform operation
                                  OpenMapRealVector result = vector.ebeMultiply(mockedVector);
                                  
                                  // Verify results
                                  assertEquals(3, result.getDimension());
                                  assertEquals(2.0, result.getEntry(0), 0.0001);
                                  assertEquals(0.0, result.getEntry(1), 0.0001);
                                  assertEquals(-8.0, result.getEntry(2), 0.0001);
                                  
                                  // Verify interactions with mock
                                  verify(mockedVector, times(1)).getDimension();
                                  verify(mockedVector, times(1)).getEntry(0);
                                  verify(mockedVector, times(1)).getEntry(1);
                                  verify(mockedVector, times(1)).getEntry(2);
                              }

    @Test
                              public void testEbeMultiply_EmptyVector() {
                                  OpenMapRealVector emptyVector = new OpenMapRealVector(0);
                                  double[] emptyArray = {};
                                  
                                  OpenMapRealVector result = emptyVector.ebeMultiply(emptyArray);
                                  assertEquals(0, result.getDimension());
                              }

    @Test
                      public void testEbeMultiply_WithNullVector() {
                          OpenMapRealVector vector = new OpenMapRealVector(new double[]{1.0, 2.0});
                          
                          // Expect exception
                          thrown.expect(NullPointerException.class);
                          
                          // Perform operation that should throw - explicitly use the RealVector version
                          vector.ebeMultiply((RealVector) null);
                      }

    @Test
                      public void testEbeMultiply_TypicalCase1() {
                          // Create the test vector with values [1.0, 0.0, 3.0, 0.0, 5.0]
                          OpenMapRealVector vector = new OpenMapRealVector(5);
                          vector.setEntry(0, 1.0);
                          vector.setEntry(2, 3.0);
                          vector.setEntry(4, 5.0);
                          
                          double[] input = {2.0, 3.0, 4.0, 5.0, 6.0};
                          OpenMapRealVector result = vector.ebeMultiply(input);
                          
                          assertEquals(5, result.getDimension());
                          assertEquals(2.0, result.getEntry(0), 0.0001);  // 1.0 * 2.0
                          assertEquals(0.0, result.getEntry(1), 0.0001);  // 0.0 * 3.0
                          assertEquals(12.0, result.getEntry(2), 0.0001); // 3.0 * 4.0
                          assertEquals(0.0, result.getEntry(3), 0.0001);  // 0.0 * 5.0
                          assertEquals(30.0, result.getEntry(4), 0.0001); // 5.0 * 6.0
                      }

    @Test
                      public void testEbeMultiply_WithZeroVector() {
                          double[] initialValues = {1.0, 2.0, 3.0, 4.0, 5.0}; // Sample initial values
                          OpenMapRealVector vector = new OpenMapRealVector(initialValues);
                          double[] zeroVector = {0.0, 0.0, 0.0, 0.0, 0.0};
                          OpenMapRealVector result = vector.ebeMultiply(zeroVector);
                          
                          assertEquals(5, result.getDimension());
                          for (int i = 0; i < result.getDimension(); i++) {
                              assertEquals(0.0, result.getEntry(i), 0.0001);
                          }
                      }

    @Test
                      public void testEbeMultiply_WithIdentityVector() {
                          // Create a test vector with values [1.0, 0.0, 3.0, 0.0, 5.0]
                          double[] testValues = {1.0, 0.0, 3.0, 0.0, 5.0};
                          OpenMapRealVector vector = new OpenMapRealVector(testValues);
                          
                          double[] identity = {1.0, 1.0, 1.0, 1.0, 1.0};
                          OpenMapRealVector result = vector.ebeMultiply(identity);
                          
                          assertEquals(5, result.getDimension());
                          assertEquals(1.0, result.getEntry(0), 0.0001);
                          assertEquals(0.0, result.getEntry(1), 0.0001);
                          assertEquals(3.0, result.getEntry(2), 0.0001);
                          assertEquals(0.0, result.getEntry(3), 0.0001);
                          assertEquals(5.0, result.getEntry(4), 0.0001);
                      }

    @Test
                      public void testEbeMultiply_WithNegativeValues1() {
                          // Create the test vector with values [1.0, 0.0, 3.0, 0.0, 5.0]
                          double[] initialValues = {1.0, 0.0, 3.0, 0.0, 5.0};
                          OpenMapRealVector vector = new OpenMapRealVector(initialValues);
                          
                          double[] negativeValues = {-1.0, -2.0, -3.0, -4.0, -5.0};
                          OpenMapRealVector result = vector.ebeMultiply(negativeValues);
                          
                          assertEquals(5, result.getDimension());
                          assertEquals(-1.0, result.getEntry(0), 0.0001);  // 1.0 * -1.0
                          assertEquals(0.0, result.getEntry(1), 0.0001);   // 0.0 * -2.0
                          assertEquals(-9.0, result.getEntry(2), 0.0001);  // 3.0 * -3.0
                          assertEquals(0.0, result.getEntry(3), 0.0001);   // 0.0 * -4.0
                          assertEquals(-25.0, result.getEntry(4), 0.0001); // 5.0 * -5.0
                      }

    @Test(expected = IllegalArgumentException.class)
                      public void testEbeMultiply_DimensionMismatch() {
                          // Create a vector with dimension 5
                          OpenMapRealVector vector = new OpenMapRealVector(5);
                          double[] wrongSizeArray = {1.0, 2.0, 3.0}; // Size 3 vs original 5
                          
                          try {
                              vector.ebeMultiply(wrongSizeArray);
                              fail("Expected IllegalArgumentException");
                          } catch (IllegalArgumentException e) {
                              assertEquals("vector length mismatch: 5 != 3", e.getMessage());
                              throw e;
                          }
                      }

    @Test
                      public void testEbeMultiply_WithExtremeValues() {
                          // Create a vector with values that will be multiplied by extreme values
                          double[] initialValues = {1.0, 0.0, 1.0, 0.0, 5.0};
                          OpenMapRealVector vector = new OpenMapRealVector(initialValues);
                          
                          double[] extremeValues = {Double.MAX_VALUE, Double.MIN_VALUE, Double.POSITIVE_INFINITY, 
                                                   Double.NEGATIVE_INFINITY, Double.NaN};
                          OpenMapRealVector result = vector.ebeMultiply(extremeValues);
                          
                          assertEquals(5, result.getDimension());
                          assertEquals(1.0 * Double.MAX_VALUE, result.getEntry(0), 0.0001);
                          assertEquals(0.0, result.getEntry(1), 0.0001);  // 0 * anything is 0
                          assertEquals(Double.POSITIVE_INFINITY, result.getEntry(2), 0.0001);
                          assertEquals(Double.NaN, result.getEntry(3), 0.0001);  // 0 * -Infinity is NaN
                          assertEquals(Double.NaN, result.getEntry(4), 0.0001);  // 5 * NaN is NaN
                      }

    @Test
              public void testEbeMultiply_VerifySparsity() throws Exception {
                  // Initialize test vector with values [1.0, 0.0, 3.0, 0.0, 5.0]
                  double[] testValues = {1.0, 0.0, 3.0, 0.0, 5.0};
                  OpenMapRealVector vector = new OpenMapRealVector(testValues);
                  
                  double[] sparseMultiplier = {1.0, 0.0, 0.0, 1.0, 0.0};
                  OpenMapRealVector result = vector.ebeMultiply(sparseMultiplier);
                  
                  // Verify only non-zero entries are stored
                  assertEquals(1.0, result.getEntry(0), 0.0001);  // 1.0 * 1.0
                  assertEquals(0.0, result.getEntry(1), 0.0001);  // 0.0 * 0.0 (should be default value)
                  assertEquals(0.0, result.getEntry(2), 0.0001);  // 3.0 * 0.0 (should be default value)
                  assertEquals(0.0, result.getEntry(3), 0.0001);  // 0.0 * 1.0 (should be default value)
                  assertEquals(0.0, result.getEntry(4), 0.0001);  // 5.0 * 0.0 (should be default value)
                  
                  // Get the protected isDefaultValue method via reflection
                  Method isDefaultValueMethod = OpenMapRealVector.class.getDeclaredMethod("isDefaultValue", double.class);
                  isDefaultValueMethod.setAccessible(true);
                  
                  // Verify sparsity - only index 0 should be stored
                  assertFalse((Boolean)isDefaultValueMethod.invoke(result, result.getEntry(0)));
                  assertTrue((Boolean)isDefaultValueMethod.invoke(result, result.getEntry(1)));
                  assertTrue((Boolean)isDefaultValueMethod.invoke(result, result.getEntry(2)));
                  assertTrue((Boolean)isDefaultValueMethod.invoke(result, result.getEntry(3)));
                  assertTrue((Boolean)isDefaultValueMethod.invoke(result, result.getEntry(4)));
              }

    @Test
          public void testEbeMultiplyDetectsIteratorAdvanceMutant() {
              // Create original vector with multiple non-zero entries
              double[] originalValues = {1.0, 0.0, 2.0, 0.0, 3.0};
              OpenMapRealVector vector = new OpenMapRealVector(originalValues);
              
              // Create multiplier array
              double[] multiplier = {2.0, 1.0, 3.0, 1.0, 4.0};
              
              // Perform multiplication
              OpenMapRealVector result = vector.ebeMultiply(multiplier);
              
              // Verify all non-zero entries were processed correctly
              assertEquals(2.0, result.getEntry(0), 0.0001);  // 1.0 * 2.0
              assertEquals(0.0, result.getEntry(1), 0.0001);  // 0.0 * 1.0 (should remain 0)
              assertEquals(6.0, result.getEntry(2), 0.0001);  // 2.0 * 3.0
              assertEquals(0.0, result.getEntry(3), 0.0001);  // 0.0 * 1.0 (should remain 0)
              assertEquals(12.0, result.getEntry(4), 0.0001); // 3.0 * 4.0
              
              // Also verify dimension remains the same
              assertEquals(originalValues.length, result.getDimension());
          }

    @Test
         public void testEbeMultiplyWithEmptyAndSingleElementVectors() {
             // Test with empty vectors
             OpenMapRealVector emptyVector1 = new OpenMapRealVector(3); // dimension 3, but no entries
             OpenMapRealVector emptyVector2 = new OpenMapRealVector(3);
             OpenMapRealVector resultEmpty = emptyVector1.ebeMultiply(emptyVector2);
             
             // Should return empty vector of same dimension
             assertEquals(3, resultEmpty.getDimension());
             // Verify all entries are 0 (default value)
             for (int i = 0; i < 3; i++) {
                 assertEquals(0.0, resultEmpty.getEntry(i), 0.0001);
             }
             
             // Test with single element vectors
             double[] values1 = {0, 2.5, 0}; // Only one non-zero entry
             double[] values2 = {0, 3.0, 0};
             OpenMapRealVector singleElementVector1 = new OpenMapRealVector(values1);
             OpenMapRealVector singleElementVector2 = new OpenMapRealVector(values2);
             OpenMapRealVector resultSingle = singleElementVector1.ebeMultiply(singleElementVector2);
             
             // Should have exactly one multiplied entry
             assertEquals(3, resultSingle.getDimension());
             // Verify only index 1 has non-zero value
             assertEquals(0.0, resultSingle.getEntry(0), 0.0001);
             assertEquals(7.5, resultSingle.getEntry(1), 0.0001); // 2.5 * 3.0 = 7.5
             assertEquals(0.0, resultSingle.getEntry(2), 0.0001);
             
             // Test with exactly one element at the end
             double[] values3 = {0, 0, 4.0};
             double[] values4 = {0, 0, 5.0};
             OpenMapRealVector endElementVector1 = new OpenMapRealVector(values3);
             OpenMapRealVector endElementVector2 = new OpenMapRealVector(values4);
             OpenMapRealVector resultEnd = endElementVector1.ebeMultiply(endElementVector2);
             
             // Should have exactly one multiplied entry at index 2
             assertEquals(3, resultEnd.getDimension());
             // Verify only index 2 has non-zero value
             assertEquals(0.0, resultEnd.getEntry(0), 0.0001);
             assertEquals(0.0, resultEnd.getEntry(1), 0.0001);
             assertEquals(20.0, resultEnd.getEntry(2), 0.0001); // 4.0 * 5.0 = 20.0
         }

    @Test
     public void testEbeMultiplyIteratorAdvance() {
         // Create original vector with multiple entries
         double[] data = {1.0, 2.0, 3.0};
         OpenMapRealVector original = new OpenMapRealVector(data);
         
         // Create input vector
         double[] inputData = {2.0, 3.0, 4.0};
         OpenMapRealVector input = new OpenMapRealVector(inputData);
         
         // Mock the iterator to verify advance() is called
         OpenIntToDoubleHashMap.Iterator mockIter = mock(OpenIntToDoubleHashMap.Iterator.class);
         when(mockIter.hasNext()).thenReturn(true, true, true, false);
         when(mockIter.key()).thenReturn(0, 1, 2);
         when(mockIter.value()).thenReturn(1.0, 2.0, 3.0);
         
         // Replace original entries with mocked version
         OpenIntToDoubleHashMap mockedEntries = mock(OpenIntToDoubleHashMap.class);
         when(mockedEntries.iterator()).thenReturn(mockIter);
         
         // Use reflection to inject mocked entries
         try {
             Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
             entriesField.setAccessible(true);
             entriesField.set(original, mockedEntries);
         } catch (Exception e) {
             fail("Failed to inject mock entries");
         }
         
         // Execute the method
         OpenMapRealVector result = original.ebeMultiply(input);
         
         // Verify iterator was advanced properly (would fail if mutated to if(true) advance)
         verify(mockIter, times(3)).advance();
         
         // Also verify the mathematical operation was correct
         assertEquals(2.0, result.getEntry(0), 0.0001);
         assertEquals(6.0, result.getEntry(1), 0.0001);
         assertEquals(12.0, result.getEntry(2), 0.0001);
     }

    @Test
    public void testEbeMultiplyWithMultipleEntries() {
        // Setup original vector with multiple non-zero entries
        double[] originalValues = {1.0, 0.0, 3.0, 0.0, 5.0};
        OpenMapRealVector originalVector = new OpenMapRealVector(originalValues);
        
        // Setup multiplier array
        double[] multiplier = {2.0, 1.0, 4.0, 1.0, 6.0};
        
        // Perform operation
        OpenMapRealVector result = originalVector.ebeMultiply(multiplier);
        
        // Verify all non-zero entries were processed correctly
        assertEquals(2.0, result.getEntry(0), 0.0001);  // 1.0 * 2.0
        assertEquals(0.0, result.getEntry(1), 0.0001);  // remains 0.0
        assertEquals(12.0, result.getEntry(2), 0.0001); // 3.0 * 4.0
        assertEquals(0.0, result.getEntry(3), 0.0001);  // remains 0.0
        assertEquals(30.0, result.getEntry(4), 0.0001); // 5.0 * 6.0
        
        // Verify dimension remains the same
        assertEquals(originalVector.getDimension(), result.getDimension());
        
        // Verify sparsity (number of non-zero entries) is correct by counting manually
        int nonZeroCount = 0;
        for (int i = 0; i < result.getDimension(); i++) {
            if (result.getEntry(i) != 0.0) {
                nonZeroCount++;
            }
        }
        assertEquals(3, nonZeroCount);
    }


}
