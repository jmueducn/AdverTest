package gentest.org.apache.commons.math.optimization.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.general.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxEvaluationsExceededException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction;
import org.apache.commons.math.analysis.MultivariateMatrixFunction;
import org.apache.commons.math.exception.LocalizedFormats;
import org.apache.commons.math.linear.InvalidMatrixException;
import org.apache.commons.math.linear.LUDecompositionImpl;
import org.apache.commons.math.linear.MatrixUtils;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.optimization.OptimizationException;
import org.apache.commons.math.optimization.SimpleVectorialValueChecker;
import org.apache.commons.math.optimization.VectorialConvergenceChecker;
import org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer;
import org.apache.commons.math.optimization.VectorialPointValuePair;
 
public class AbstractLeastSquaresOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                public void testGetRMS_WithPositiveValues() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                                                                    when(optimizer.getChiSquare()).thenReturn(16.0);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set the private rows field
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.setInt(optimizer, 4);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Stub the getRMS method to calculate based on our test values
                                                                                                                                                                                                                                    when(optimizer.getRMS()).thenCallRealMethod();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute & Verify
                                                                                                                                                                                                                                    assertEquals(2.0, optimizer.getRMS(), 0.0001);
                                                                                                                                                                                                                                    verify(optimizer).getChiSquare();
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetRMS_WithZeroChiSquare() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Mock chiSquare to return 0.0
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                                                                    when(spyOptimizer.getChiSquare()).thenReturn(0.0);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Set rows using reflection since it's likely a protected field
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.setInt(spyOptimizer, 5);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute & Verify
                                                                                                                                                                                                                                    assertEquals(0.0, spyOptimizer.getRMS(), 0.0001);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetRMS_WithLargeValues() {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                                                                    when(optimizer.getChiSquare()).thenReturn(1.0E20);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set the private rows field
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                        rowsField.setAccessible(true);
                                                                                                                                                                                                                                        rowsField.set(optimizer, 1000000);
                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                        fail("Failed to set rows field via reflection: " + e.getMessage());
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute & Verify
                                                                                                                                                                                                                                    assertEquals(1.0E7, optimizer.getRMS(), 1.0E-5);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetRMS_WithSmallValues() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set the private rows field
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.setInt(optimizer, 1000000);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Mock getChiSquare() to return a small value
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                                                                    when(spyOptimizer.getChiSquare()).thenReturn(1.0E-20);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute & Verify
                                                                                                                                                                                                                                    assertEquals(1.0E-13, spyOptimizer.getRMS(), 1.0E-18);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetRMS_WithNegativeChiSquare() {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                                                                    when(optimizer.getChiSquare()).thenReturn(-4.0);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set the private rows field
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                        rowsField.setAccessible(true);
                                                                                                                                                                                                                                        rowsField.set(optimizer, 2);
                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                        fail("Failed to set rows field via reflection");
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute & Verify - should return NaN for sqrt of negative number
                                                                                                                                                                                                                                    assertTrue(Double.isNaN(optimizer.getRMS()));
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetRMS_VerifiesCalculation() {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                                                                    when(optimizer.getChiSquare()).thenReturn(9.0);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                        rowsField.setAccessible(true);
                                                                                                                                                                                                                                        rowsField.setInt(optimizer, 9);
                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                        fail("Failed to set rows field via reflection");
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute & Verify
                                                                                                                                                                                                                                    assertEquals(1.0, optimizer.getRMS(), 0.0001);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetChiSquare_WithSingleResidual() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.set(optimizer, 1);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsField.set(optimizer, new double[]{2.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                    residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsWeightsField.set(optimizer, new double[]{1.5});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute and Verify
                                                                                                                                                                                                                                    assertEquals(6.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetChiSquare_WithMultipleResiduals() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.set(optimizer, 3);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                    residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsWeightsField.set(optimizer, new double[]{0.5, 1.0, 1.5});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute and Verify
                                                                                                                                                                                                                                    // Expected: (1²*0.5) + (2²*1.0) + (3²*1.5) = 0.5 + 4 + 13.5 = 18.0
                                                                                                                                                                                                                                    assertEquals(18.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetChiSquare_WithZeroResiduals() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields
                                                                                                                                                                                                                                    Class<?> optimizerClass = optimizer.getClass();
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Set rows field
                                                                                                                                                                                                                                    Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.setInt(optimizer, 2);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Set residuals field
                                                                                                                                                                                                                                    Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsField.set(optimizer, new double[]{0.0, 0.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Set residualsWeights field
                                                                                                                                                                                                                                    Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                    residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute and Verify
                                                                                                                                                                                                                                    assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetChiSquare_WithNegativeResiduals() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.set(optimizer, 2);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsField.set(optimizer, new double[]{-2.0, -3.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                    residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsWeightsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute and Verify
                                                                                                                                                                                                                                    // Expected: ((-2)²*1) + ((-3)²*2) = 4 + 18 = 22.0
                                                                                                                                                                                                                                    assertEquals(22.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetChiSquare_WithZeroWeights() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields since they're not directly accessible
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.set(optimizer, 2);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsField.set(optimizer, new double[]{2.0, 3.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                    weightsField.setAccessible(true);
                                                                                                                                                                                                                                    weightsField.set(optimizer, new double[]{0.0, 0.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute and Verify
                                                                                                                                                                                                                                    assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetChiSquare_WithMixedWeights() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.set(optimizer, 3);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                    residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsWeightsField.set(optimizer, new double[]{0.0, 1.0, 0.5});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute and Verify
                                                                                                                                                                                                                                    // Expected: (1²*0) + (2²*1) + (3²*0.5) = 0 + 4 + 4.5 = 8.5
                                                                                                                                                                                                                                    assertEquals(8.5, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetChiSquare_WithLargeValues() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.set(optimizer, 2);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsField.set(optimizer, new double[]{1e6, 2e6});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                    residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsWeightsField.set(optimizer, new double[]{1e-6, 2e-6});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute and Verify
                                                                                                                                                                                                                                    // Expected: (1e6²*1e-6) + (2e6²*2e-6) = 1e6 + 8e6 = 9e6
                                                                                                                                                                                                                                    assertEquals(9e6, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetChiSquare_WithPrecisionLoss() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.set(optimizer, 2);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsField.set(optimizer, new double[]{1e-10, 2e-10});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                    residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsWeightsField.set(optimizer, new double[]{1e10, 2e10});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute and Verify
                                                                                                                                                                                                                                    // Expected: (1e-10²*1e10) + (2e-10²*2e10) = 1e-10 + 8e-10 = 9e-10
                                                                                                                                                                                                                                    assertEquals(9e-10, optimizer.getChiSquare(), 1e-20);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetChiSquare_WithEmptyResiduals() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.set(optimizer, 0);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsField.set(optimizer, new double[0]);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                    residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsWeightsField.set(optimizer, new double[0]);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute and Verify
                                                                                                                                                                                                                                    assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                                                }

    @Test(expected = NullPointerException.class)
                                                                                                                                                                                                                                public void testGetChiSquare_WithNullResiduals() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.setInt(optimizer, 1);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsField.set(optimizer, null);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // This should throw NullPointerException
                                                                                                                                                                                                                                    optimizer.getChiSquare();
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetChiSquare_WithNullWeights() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields
                                                                                                                                                                                                                                    Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                    rowsField.setAccessible(true);
                                                                                                                                                                                                                                    rowsField.set(optimizer, 1);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                    residualsField.setAccessible(true);
                                                                                                                                                                                                                                    residualsField.set(optimizer, new double[]{1.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                    weightsField.setAccessible(true);
                                                                                                                                                                                                                                    weightsField.set(optimizer, null);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Expect exception
                                                                                                                                                                                                                                    thrown.expect(NullPointerException.class);
                                                                                                                                                                                                                                    optimizer.getChiSquare();
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testGetChiSquare_WithArraysLengthMismatch() {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to set private fields since they're not directly accessible
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                        rowsField.setAccessible(true);
                                                                                                                                                                                                                                        rowsField.set(optimizer, 2);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                                                        residualsField.setAccessible(true);
                                                                                                                                                                                                                                        residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                                        weightsField.setAccessible(true);
                                                                                                                                                                                                                                        weightsField.set(optimizer, new double[]{1.0}); // shorter than residuals
                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                        throw new RuntimeException("Failed to set fields via reflection", e);
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Expect exception
                                                                                                                                                                                                                                    thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                                                                                                                                                    optimizer.getChiSquare();
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                            public void testGetRMS_WithZeroRows() throws Exception {
                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                                                                when(optimizer.getChiSquare()).thenReturn(10.0);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Use reflection to set private rows field
                                                                                                                                                                                                                                Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                                                rowsField.setAccessible(true);
                                                                                                                                                                                                                                rowsField.setInt(optimizer, 0);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Expect exception
                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                    optimizer.getRMS();
                                                                                                                                                                                                                                    fail("Expected ArithmeticException");
                                                                                                                                                                                                                                } catch (ArithmeticException e) {
                                                                                                                                                                                                                                    assertEquals("/ by zero", e.getMessage());
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                       public void testGetChiSquareWithSingleRow() throws Exception {
                                                                                                                                                                                                                           // Setup test data
                                                                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                               protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                                   return null; // Not needed for this test
                                                                                                                                                                                                                               }
                                                                                                                                                                                                                           };
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Use reflection to set protected fields
                                                                                                                                                                                                                           Class<?> optimizerClass = optimizer.getClass();
                                                                                                                                                                                                                           java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                                                                                           rowsField.setAccessible(true);
                                                                                                                                                                                                                           rowsField.set(optimizer, 1);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                                                                                           residualsField.setAccessible(true);
                                                                                                                                                                                                                           residualsField.set(optimizer, new double[]{2.0}); // residual = 2.0
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                           residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                           residualsWeightsField.set(optimizer, new double[]{1.5}); // weight = 1.5
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Expected calculation: 0 + (2.0 * 2.0 * 1.5) = 6.0
                                                                                                                                                                                                                           double expectedChiSquare = 6.0;
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Execute and verify
                                                                                                                                                                                                                           assertEquals("Chi-square calculation should be correct for single row",
                                                                                                                                                                                                                                       expectedChiSquare, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Verify all residuals were processed
                                                                                                                                                                                                                           assertEquals("Should process exactly one row", 1, rowsField.getInt(optimizer));
                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                  public void testGetChiSquareDetectsCostMutation() throws Exception {
                                                                                                                                                                                                                      // Create a concrete instance of the abstract class for testing
                                                                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                              return null; // Not needed for this test
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      };
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Use reflection to set protected fields
                                                                                                                                                                                                                      Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                                                                                                                                      java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                                                                                      rowsField.setAccessible(true);
                                                                                                                                                                                                                      rowsField.set(optimizer, 3);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                                                                                      residualsField.setAccessible(true);
                                                                                                                                                                                                                      residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                      residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                      residualsWeightsField.set(optimizer, new double[]{0.5, 1.0, 1.5});
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      java.lang.reflect.Field costField = optimizerClass.getDeclaredField("cost");
                                                                                                                                                                                                                      costField.setAccessible(true);
                                                                                                                                                                                                                      costField.set(optimizer, 4.0); // This will be mutated
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Get field values using reflection for calculation
                                                                                                                                                                                                                      double[] residuals = (double[]) residualsField.get(optimizer);
                                                                                                                                                                                                                      double[] residualsWeights = (double[]) residualsWeightsField.get(optimizer);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Calculate expected value manually
                                                                                                                                                                                                                      double expectedChiSquare = 0;
                                                                                                                                                                                                                      for (int i = 0; i < 3; i++) {
                                                                                                                                                                                                                          double residual = residuals[i];
                                                                                                                                                                                                                          expectedChiSquare += residual * residual * residualsWeights[i];
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                      expectedChiSquare = Math.sqrt(4.0); // Original behavior
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // The mutated version would square the cost instead (4.0 -> 16.0)
                                                                                                                                                                                                                      // So we assert against the original expected value
                                                                                                                                                                                                                      assertEquals("Chi-square calculation should use sqrt(cost)", 
                                                                                                                                                                                                                                 expectedChiSquare, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Additional assertion to directly catch the mutation
                                                                                                                                                                                                                      assertNotEquals("Should not equal squared cost value",
                                                                                                                                                                                                                                    16.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                             public void testGetChiSquareDetectsSqrtToAbsMutation() throws Exception {
                                                                                                                                                                                                                 // Create a test instance using a spy to observe behavior
                                                                                                                                                                                                                 AbstractLeastSquaresOptimizer optimizer = spy(new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                     protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                         return null; // dummy implementation
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                 });
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Use reflection to set protected fields
                                                                                                                                                                                                                 Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 Field costField = optimizerClass.getDeclaredField("cost");
                                                                                                                                                                                                                 costField.setAccessible(true);
                                                                                                                                                                                                                 costField.set(optimizer, -4.0);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                                                                                 rowsField.setAccessible(true);
                                                                                                                                                                                                                 rowsField.set(optimizer, 2);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                                                                                 residualsField.setAccessible(true);
                                                                                                                                                                                                                 residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                                                                                 residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                                 residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Call the method
                                                                                                                                                                                                                 double result = optimizer.getChiSquare();
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify the behavior
                                                                                                                                                                                                                 // Original would do sqrt(-4) which would be NaN, making chiSquare NaN
                                                                                                                                                                                                                 // Mutated version would do abs(-4) = 4, making chiSquare calculable
                                                                                                                                                                                                                 // So we verify the result is not NaN (which would detect the mutation)
                                                                                                                                                                                                                 assertFalse("Chi-square should not be NaN (would be NaN if sqrt was used on negative)", 
                                                                                                                                                                                                                            Double.isNaN(result));
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Additional verification of expected value with abs behavior
                                                                                                                                                                                                                 // With abs(-4) = 4, residuals are [1,2], weights [1,1]
                                                                                                                                                                                                                 // chiSquare = 1*1*1 + 2*2*1 = 1 + 4 = 5
                                                                                                                                                                                                                 assertEquals(5.0, result, 0.0001);
                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                        public void testGetChiSquare() throws Exception {
                                                                                                                                                                                                            // Create a test instance of the optimizer
                                                                                                                                                                                                            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                                    return null; // Not needed for this test
                                                                                                                                                                                                                }
                                                                                                                                                                                                            };
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Get protected fields via reflection
                                                                                                                                                                                                            Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                                            rowsField.setAccessible(true);
                                                                                                                                                                                                            Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                                            residualsField.setAccessible(true);
                                                                                                                                                                                                            Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                                            residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test case 1: Single row with positive values
                                                                                                                                                                                                            rowsField.set(optimizer, 1);
                                                                                                                                                                                                            residualsField.set(optimizer, new double[]{2.0});
                                                                                                                                                                                                            residualsWeightsField.set(optimizer, new double[]{1.5});
                                                                                                                                                                                                            assertEquals(6.0, optimizer.getChiSquare(), 0.0001); // 2^2 * 1.5 = 6
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test case 2: Multiple rows with mixed values
                                                                                                                                                                                                            rowsField.set(optimizer, 3);
                                                                                                                                                                                                            residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                                                                                            residualsWeightsField.set(optimizer, new double[]{1.0, 0.5, 2.0});
                                                                                                                                                                                                            double expected = (1.0*1.0*1.0) + (2.0*2.0*0.5) + (3.0*3.0*2.0);
                                                                                                                                                                                                            assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test case 3: Empty case (0 rows)
                                                                                                                                                                                                            rowsField.set(optimizer, 0);
                                                                                                                                                                                                            residualsField.set(optimizer, new double[0]);
                                                                                                                                                                                                            residualsWeightsField.set(optimizer, new double[0]);
                                                                                                                                                                                                            assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test case 4: Negative residual values
                                                                                                                                                                                                            rowsField.set(optimizer, 2);
                                                                                                                                                                                                            residualsField.set(optimizer, new double[]{-2.0, -3.0});
                                                                                                                                                                                                            residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                                                                                                                                            assertEquals(13.0, optimizer.getChiSquare(), 0.0001); // (-2)^2 + (-3)^2 = 13
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test case 5: Zero weights
                                                                                                                                                                                                            rowsField.set(optimizer, 2);
                                                                                                                                                                                                            residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                                                                                                                            residualsWeightsField.set(optimizer, new double[]{0.0, 0.0});
                                                                                                                                                                                                            assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                   public void testGetChiSquare1() throws Exception {
                                                                                                                                                                                                       // Create test instance
                                                                                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                           @Override
                                                                                                                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                               return null; // dummy implementation
                                                                                                                                                                                                           }
                                                                                                                                                                                                       };
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Get fields via reflection
                                                                                                                                                                                                       Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                                                                                                                       java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                                                                       java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                                                                       java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Make fields accessible
                                                                                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                                                                                       residualsField.setAccessible(true);
                                                                                                                                                                                                       residualsWeightsField.setAccessible(true);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Set up test data - first case
                                                                                                                                                                                                       int rows = 3;
                                                                                                                                                                                                       rowsField.set(optimizer, rows);
                                                                                                                                                                                                       residualsField.set(optimizer, new double[]{2.0, 3.0, 4.0});
                                                                                                                                                                                                       residualsWeightsField.set(optimizer, new double[]{1.0, 2.0, 1.5});
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Calculate expected value manually:
                                                                                                                                                                                                       // row 0: 2.0^2 * 1.0 = 4.0
                                                                                                                                                                                                       // row 1: 3.0^2 * 2.0 = 18.0
                                                                                                                                                                                                       // row 2: 4.0^2 * 1.5 = 24.0
                                                                                                                                                                                                       // total = 4.0 + 18.0 + 24.0 = 46.0
                                                                                                                                                                                                       double expected = 46.0;
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Call method and verify
                                                                                                                                                                                                       double actual = optimizer.getChiSquare();
                                                                                                                                                                                                       assertEquals("Chi-square calculation incorrect", expected, actual, 0.0001);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Test edge case with empty residuals
                                                                                                                                                                                                       rowsField.set(optimizer, 0);
                                                                                                                                                                                                       residualsField.set(optimizer, new double[0]);
                                                                                                                                                                                                       residualsWeightsField.set(optimizer, new double[0]);
                                                                                                                                                                                                       assertEquals("Empty residuals should return 0", 0.0, optimizer.getChiSquare(), 0.0);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Test single row case
                                                                                                                                                                                                       rowsField.set(optimizer, 1);
                                                                                                                                                                                                       residualsField.set(optimizer, new double[]{5.0});
                                                                                                                                                                                                       residualsWeightsField.set(optimizer, new double[]{0.5});
                                                                                                                                                                                                       assertEquals("Single row calculation incorrect", 12.5, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                               public void testEvaluationCountingWithMaxEvaluations() {
                                                                                                                                                                                                   // Setup test object
                                                                                                                                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                       @Override
                                                                                                                                                                                                       protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                           return null; // dummy implementation
                                                                                                                                                                                                       }
                                                                                                                                                                                                   };
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Set max evaluations to 1
                                                                                                                                                                                                   optimizer.setMaxEvaluations(1);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify initial state
                                                                                                                                                                                                   assertEquals(0, optimizer.getEvaluations());
                                                                                                                                                                                                   
                                                                                                                                                                                                   // First evaluation should be allowed
                                                                                                                                                                                                   optimizer.getChiSquare(); // This would increment counter
                                                                                                                                                                                                   assertEquals(1, optimizer.getEvaluations());
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Second evaluation should be blocked in original, but allowed in mutant
                                                                                                                                                                                                   try {
                                                                                                                                                                                                       optimizer.getChiSquare();
                                                                                                                                                                                                       // If we get here, the mutant survived (post-increment allowed extra evaluation)
                                                                                                                                                                                                       fail("Expected evaluation limit exception but none was thrown");
                                                                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                                                                       // Original behavior would throw exception here
                                                                                                                                                                                                       assertTrue(e.getMessage().contains("maximal number of evaluations"));
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Final verification - mutant would show 2 evaluations here
                                                                                                                                                                                                   assertEquals(1, optimizer.getEvaluations());
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                              public void testEvaluationStoppingCondition() throws Exception {
                                                                                                                                                                                                  // Setup test with mock function
                                                                                                                                                                                                  DifferentiableMultivariateVectorialFunction mockFunction = mock(DifferentiableMultivariateVectorialFunction.class);
                                                                                                                                                                                                  MultivariateMatrixFunction mockJacobian = mock(MultivariateMatrixFunction.class);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create optimizer instance
                                                                                                                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                      @Override
                                                                                                                                                                                                      protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                          return null; // Not needed for this test
                                                                                                                                                                                                      }
                                                                                                                                                                                                  };
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Set parameters
                                                                                                                                                                                                  int maxEvals = 10;
                                                                                                                                                                                                  optimizer.setMaxEvaluations(maxEvals);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Mock behavior
                                                                                                                                                                                                  when(mockFunction.value(any(double[].class))).thenReturn(new double[0]);
                                                                                                                                                                                                  when(mockFunction.jacobian()).thenReturn(mockJacobian);
                                                                                                                                                                                                  when(mockJacobian.value(any(double[].class))).thenReturn(new double[0][0]);
                                                                                                                                                                                                  
                                                                                                                                                                                                  try {
                                                                                                                                                                                                      // Execute optimization
                                                                                                                                                                                                      optimizer.optimize(mockFunction, new double[0], new double[0], new double[0]);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Verify evaluation count
                                                                                                                                                                                                      // Original should allow exactly maxEvals evaluations
                                                                                                                                                                                                      // Mutant would stop at maxEvals
                                                                                                                                                                                                      assertEquals("Should allow exactly maxEvaluations calls", 
                                                                                                                                                                                                                  maxEvals, optimizer.getEvaluations());
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Verify optimization completed (not interrupted)
                                                                                                                                                                                                      assertTrue("Optimization should complete normally", 
                                                                                                                                                                                                                optimizer.getIterations() > 0);
                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                      fail("Optimization should not throw exception");
                                                                                                                                                                                                  }
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                            public void testGetChiSquareThrowsFunctionEvaluationExceptionWithProperCause() throws Exception {
                                                                                                                                                                                                // Setup test object with conditions that will trigger max evaluations exceeded
                                                                                                                                                                                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                    @Override
                                                                                                                                                                                                    protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                        try {
                                                                                                                                                                                                            // Use reflection to access private field
                                                                                                                                                                                                            Field field = AbstractLeastSquaresOptimizer.class.getDeclaredField("objectiveEvaluations");
                                                                                                                                                                                                            field.setAccessible(true);
                                                                                                                                                                                                            field.set(this, Integer.MAX_VALUE);
                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                            throw new RuntimeException(e);
                                                                                                                                                                                                        }
                                                                                                                                                                                                        return null;
                                                                                                                                                                                                    }
                                                                                                                                                                                                };
                                                                                                                                                                                                
                                                                                                                                                                                                // Set a low max evaluations threshold
                                                                                                                                                                                                optimizer.setMaxEvaluations(10);
                                                                                                                                                                                                
                                                                                                                                                                                                // Prepare the exception expectation
                                                                                                                                                                                                thrown.expect(FunctionEvaluationException.class);
                                                                                                                                                                                                thrown.expectCause(org.hamcrest.CoreMatchers.instanceOf(MaxEvaluationsExceededException.class));
                                                                                                                                                                                                
                                                                                                                                                                                                // This should throw the exception when trying to optimize
                                                                                                                                                                                                optimizer.optimize(mock(DifferentiableMultivariateVectorialFunction.class), 
                                                                                                                                                                                                                  new double[0], new double[0], new double[0]);
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                        public void testGetChiSquare_VerifiesFunctionCalledWithCorrectPoint() throws Exception {
                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                            double[] testPoint = {1.0, 2.0};
                                                                                                                                                                                            double[] testResiduals = {0.5, 0.3};
                                                                                                                                                                                            double[] testWeights = {1.0, 1.0};
                                                                                                                                                                                            double[] testObjective = {1.5, 2.3};
                                                                                                                                                                                            
                                                                                                                                                                                            // Create mock function
                                                                                                                                                                                            DifferentiableMultivariateVectorialFunction function = mock(DifferentiableMultivariateVectorialFunction.class);
                                                                                                                                                                                            when(function.value(testPoint)).thenReturn(testObjective);
                                                                                                                                                                                            
                                                                                                                                                                                            // Create test optimizer instance
                                                                                                                                                                                            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                @Override
                                                                                                                                                                                                protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                    return null;
                                                                                                                                                                                                }
                                                                                                                                                                                            };
                                                                                                                                                                                            
                                                                                                                                                                                            // Set protected fields via reflection
                                                                                                                                                                                            Field pointField = AbstractLeastSquaresOptimizer.class.getDeclaredField("point");
                                                                                                                                                                                            pointField.setAccessible(true);
                                                                                                                                                                                            pointField.set(optimizer, testPoint);
                                                                                                                                                                                            
                                                                                                                                                                                            Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                            residualsField.setAccessible(true);
                                                                                                                                                                                            residualsField.set(optimizer, testResiduals);
                                                                                                                                                                                            
                                                                                                                                                                                            Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                            weightsField.setAccessible(true);
                                                                                                                                                                                            weightsField.set(optimizer, testWeights);
                                                                                                                                                                                            
                                                                                                                                                                                            Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                            rowsField.setAccessible(true);
                                                                                                                                                                                            rowsField.set(optimizer, testResiduals.length);
                                                                                                                                                                                            
                                                                                                                                                                                            Field functionField = AbstractLeastSquaresOptimizer.class.getDeclaredField("function");
                                                                                                                                                                                            functionField.setAccessible(true);
                                                                                                                                                                                            functionField.set(optimizer, function);
                                                                                                                                                                                            
                                                                                                                                                                                            // Call method under test
                                                                                                                                                                                            double result = optimizer.getChiSquare();
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify function was called with correct point
                                                                                                                                                                                            verify(function).value(testPoint);
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify calculation
                                                                                                                                                                                            double expectedChiSquare = testResiduals[0] * testResiduals[0] * testWeights[0] 
                                                                                                                                                                                                                    + testResiduals[1] * testResiduals[1] * testWeights[1];
                                                                                                                                                                                            assertEquals(expectedChiSquare, result, 1e-10);
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                      public void testGetChiSquareWithMismatchedDimensionsShouldThrow() throws Exception {
                                                                                                                                                                                          // Create optimizer instance
                                                                                                                                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                              @Override
                                                                                                                                                                                              protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                  return null;
                                                                                                                                                                                              }
                                                                                                                                                                                          };
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to set private fields
                                                                                                                                                                                          Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                          rowsField.setAccessible(true);
                                                                                                                                                                                          rowsField.set(optimizer, 3);
                                                                                                                                                                                          
                                                                                                                                                                                          Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                                                                                          objectiveField.setAccessible(true);
                                                                                                                                                                                          objectiveField.set(optimizer, new double[4]); // Different length than rows
                                                                                                                                                                                          
                                                                                                                                                                                          Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                          residualsField.setAccessible(true);
                                                                                                                                                                                          residualsField.set(optimizer, new double[3]);
                                                                                                                                                                                          
                                                                                                                                                                                          Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                          residualsWeightsField.setAccessible(true);
                                                                                                                                                                                          residualsWeightsField.set(optimizer, new double[3]);
                                                                                                                                                                                          
                                                                                                                                                                                          try {
                                                                                                                                                                                              optimizer.getChiSquare();
                                                                                                                                                                                              fail("Expected IllegalArgumentException for mismatched dimensions");
                                                                                                                                                                                          } catch (IllegalArgumentException e) {
                                                                                                                                                                                              // Expected exception
                                                                                                                                                                                          }
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                      public void testGetChiSquareWithMatchingDimensionsShouldPass() throws Exception {
                                                                                                                                                                                          // Create optimizer instance
                                                                                                                                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                              @Override
                                                                                                                                                                                              protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                                  return null;
                                                                                                                                                                                              }
                                                                                                                                                                                          };
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to set private fields
                                                                                                                                                                                          Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                          rowsField.setAccessible(true);
                                                                                                                                                                                          rowsField.set(optimizer, 3);
                                                                                                                                                                                          
                                                                                                                                                                                          Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                                                                                          objectiveField.setAccessible(true);
                                                                                                                                                                                          objectiveField.set(optimizer, new double[3]);
                                                                                                                                                                                          
                                                                                                                                                                                          Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                          residualsField.setAccessible(true);
                                                                                                                                                                                          residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                                                                          
                                                                                                                                                                                          Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                          residualsWeightsField.setAccessible(true);
                                                                                                                                                                                          residualsWeightsField.set(optimizer, new double[]{0.5, 0.5, 0.5});
                                                                                                                                                                                          
                                                                                                                                                                                          // Call the method under test
                                                                                                                                                                                          double result = optimizer.getChiSquare();
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify calculation (1^2*0.5 + 2^2*0.5 + 3^2*0.5 = 0.5 + 2 + 4.5 = 7.0)
                                                                                                                                                                                          assertEquals(7.0, result, 0.0001);
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                 public void testGetChiSquare_WhenObjectiveLengthLessThanRows_ShouldThrowException() throws Exception {
                                                                                                                                                                                     // Setup test object
                                                                                                                                                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                         @Override
                                                                                                                                                                                         protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                             return null;
                                                                                                                                                                                         }
                                                                                                                                                                                     };
                                                                                                                                                                                     
                                                                                                                                                                                     // Use reflection to set protected fields
                                                                                                                                                                                     Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                                                                                                     java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                                                     rowsField.setAccessible(true);
                                                                                                                                                                                     rowsField.set(optimizer, 5);
                                                                                                                                                                                     
                                                                                                                                                                                     java.lang.reflect.Field objectiveField = optimizerClass.getDeclaredField("objective");
                                                                                                                                                                                     objectiveField.setAccessible(true);
                                                                                                                                                                                     objectiveField.set(optimizer, new double[3]);  // objective array shorter than rows
                                                                                                                                                                                     
                                                                                                                                                                                     java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                                                     residualsField.setAccessible(true);
                                                                                                                                                                                     residualsField.set(optimizer, new double[5]);  // residuals array matches rows
                                                                                                                                                                                     
                                                                                                                                                                                     java.lang.reflect.Field weightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                                                     weightsField.setAccessible(true);
                                                                                                                                                                                     weightsField.set(optimizer, new double[5]);  // weights array matches rows
                                                                                                                                                                                     
                                                                                                                                                                                     // This should throw IllegalArgumentException in original code
                                                                                                                                                                                     // Mutant would either not throw exception or throw ArrayIndexOutOfBoundsException
                                                                                                                                                                                     optimizer.getChiSquare();
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                            public void testGetChiSquareThrowsExceptionWithCorrectPoint() throws Exception {
                                                                                                                                                                                // Create a test instance of the abstract class using a mock
                                                                                                                                                                                AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                
                                                                                                                                                                                // Setup the test data to force dimension mismatch
                                                                                                                                                                                double[] testPoint = {1.0, 2.0, 3.0};
                                                                                                                                                                                
                                                                                                                                                                                // Use reflection to set protected fields
                                                                                                                                                                                Field pointField = AbstractLeastSquaresOptimizer.class.getDeclaredField("point");
                                                                                                                                                                                pointField.setAccessible(true);
                                                                                                                                                                                pointField.set(optimizer, testPoint);
                                                                                                                                                                                
                                                                                                                                                                                Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                                rowsField.setAccessible(true);
                                                                                                                                                                                rowsField.set(optimizer, 3);
                                                                                                                                                                                
                                                                                                                                                                                Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                                residualsField.setAccessible(true);
                                                                                                                                                                                residualsField.set(optimizer, new double[2]); // Different size than rows
                                                                                                                                                                                
                                                                                                                                                                                Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                                residualsWeightsField.setAccessible(true);
                                                                                                                                                                                residualsWeightsField.set(optimizer, new double[2]); // Different size than rows
                                                                                                                                                                                
                                                                                                                                                                                // Configure the mock to call real method for getChiSquare
                                                                                                                                                                                when(optimizer.getChiSquare()).thenCallRealMethod();
                                                                                                                                                                                
                                                                                                                                                                                // Expect the exception and verify its contents
                                                                                                                                                                                thrown.expect(FunctionEvaluationException.class);
                                                                                                                                                                                thrown.expectMessage("dimensions mismatch");
                                                                                                                                                                                // This assertion will fail if the mutant is present (point is null)
                                                                                                                                                                                thrown.expect(new org.hamcrest.BaseMatcher<FunctionEvaluationException>() {
                                                                                                                                                                                    @Override
                                                                                                                                                                                    public boolean matches(Object item) {
                                                                                                                                                                                        if (!(item instanceof FunctionEvaluationException)) {
                                                                                                                                                                                            return false;
                                                                                                                                                                                        }
                                                                                                                                                                                        FunctionEvaluationException ex = (FunctionEvaluationException) item;
                                                                                                                                                                                        try {
                                                                                                                                                                                            Field pointField = FunctionEvaluationException.class.getDeclaredField("point");
                                                                                                                                                                                            pointField.setAccessible(true);
                                                                                                                                                                                            return pointField.get(ex) != null;
                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                            return false;
                                                                                                                                                                                        }
                                                                                                                                                                                    }
                                                                                                                                                                                    
                                                                                                                                                                                    @Override
                                                                                                                                                                                    public void describeTo(org.hamcrest.Description description) {
                                                                                                                                                                                        description.appendText("Exception should contain non-null point");
                                                                                                                                                                                    }
                                                                                                                                                                                });
                                                                                                                                                                                
                                                                                                                                                                                // Trigger the test
                                                                                                                                                                                optimizer.getChiSquare();
                                                                                                                                                                            }

    @Test
                                                                                                                                                                       public void testGetChiSquareDetectsInitialValueMutation() throws Exception {
                                                                                                                                                                           // Setup test object
                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                               @Override
                                                                                                                                                                               protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                                   return null; // dummy implementation
                                                                                                                                                                               }
                                                                                                                                                                           };
                                                                                                                                                                           
                                                                                                                                                                           // Get field references using reflection
                                                                                                                                                                           java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                           rowsField.setAccessible(true);
                                                                                                                                                                           java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                           residualsField.setAccessible(true);
                                                                                                                                                                           java.lang.reflect.Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                           residualsWeightsField.setAccessible(true);
                                                                                                                                                                           
                                                                                                                                                                           // Case 1: Test with zero residuals (should return 0)
                                                                                                                                                                           rowsField.setInt(optimizer, 3);
                                                                                                                                                                           residualsField.set(optimizer, new double[]{0.0, 0.0, 0.0});
                                                                                                                                                                           residualsWeightsField.set(optimizer, new double[]{1.0, 1.0, 1.0});
                                                                                                                                                                           assertEquals(0.0, optimizer.getChiSquare(), 0.0001); // This will fail if mutant is present
                                                                                                                                                                           
                                                                                                                                                                           // Case 2: Test with non-zero residuals
                                                                                                                                                                           rowsField.setInt(optimizer, 2);
                                                                                                                                                                           residualsField.set(optimizer, new double[]{2.0, 3.0});
                                                                                                                                                                           residualsWeightsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                                                                                                           // Expected: 2²*1 + 3²*2 = 4*1 + 9*2 = 4 + 18 = 22
                                                                                                                                                                           assertEquals(22.0, optimizer.getChiSquare(), 0.0001); // This will fail if mutant is present (would return 23)
                                                                                                                                                                           
                                                                                                                                                                           // Case 3: Test with mixed positive/negative residuals
                                                                                                                                                                           rowsField.setInt(optimizer, 2);
                                                                                                                                                                           residualsField.set(optimizer, new double[]{-1.0, 1.0});
                                                                                                                                                                           residualsWeightsField.set(optimizer, new double[]{2.0, 2.0});
                                                                                                                                                                           // Expected: (-1)²*2 + 1²*2 = 1*2 + 1*2 = 2 + 2 = 4
                                                                                                                                                                           assertEquals(4.0, optimizer.getChiSquare(), 0.0001); // This will fail if mutant is present (would return 5)
                                                                                                                                                                       }

    @Test
                                                                                                                                                                  public void testGetChiSquare2() throws Exception {
                                                                                                                                                                      // Create a test instance by extending the abstract class
                                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                          @Override
                                                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                              return null; // Not needed for this test
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      // Get protected fields via reflection
                                                                                                                                                                      Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                      Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                      Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                      
                                                                                                                                                                      // Make fields accessible
                                                                                                                                                                      rowsField.setAccessible(true);
                                                                                                                                                                      residualsField.setAccessible(true);
                                                                                                                                                                      residualsWeightsField.setAccessible(true);
                                                                                                                                                                      
                                                                                                                                                                      // Test case 1: No residuals (rows = 0)
                                                                                                                                                                      rowsField.set(optimizer, 0);
                                                                                                                                                                      residualsField.set(optimizer, new double[0]);
                                                                                                                                                                      residualsWeightsField.set(optimizer, new double[0]);
                                                                                                                                                                      assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                      
                                                                                                                                                                      // Test case 2: Single residual
                                                                                                                                                                      rowsField.set(optimizer, 1);
                                                                                                                                                                      residualsField.set(optimizer, new double[]{2.0});
                                                                                                                                                                      residualsWeightsField.set(optimizer, new double[]{0.5});
                                                                                                                                                                      // Expected: 2.0 * 2.0 * 0.5 = 2.0
                                                                                                                                                                      assertEquals(2.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                      
                                                                                                                                                                      // Test case 3: Multiple residuals
                                                                                                                                                                      rowsField.set(optimizer, 3);
                                                                                                                                                                      residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                                                                                                      residualsWeightsField.set(optimizer, new double[]{0.5, 1.0, 1.5});
                                                                                                                                                                      // Expected: (1*1*0.5) + (2*2*1.0) + (3*3*1.5) = 0.5 + 4 + 13.5 = 18.0
                                                                                                                                                                      assertEquals(18.0, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                                      
                                                                                                                                                                      // Test case 4: Very small residual
                                                                                                                                                                      rowsField.set(optimizer, 1);
                                                                                                                                                                      residualsField.set(optimizer, new double[]{0.0001});
                                                                                                                                                                      residualsWeightsField.set(optimizer, new double[]{1.0});
                                                                                                                                                                      // Expected: 0.0001 * 0.0001 * 1.0 = 0.00000001
                                                                                                                                                                      assertEquals(0.00000001, optimizer.getChiSquare(), 0.0000000001);
                                                                                                                                                                  }

    @Test
                                                                                                                                                             public void testGetChiSquare_DetectsIndexMutation() throws Exception {
                                                                                                                                                                 // Setup test data - we'll use 2 rows with known values
                                                                                                                                                                 double[] residuals = {2.0, 3.0}; // First residual is 2.0
                                                                                                                                                                 double[] weights = {1.0, 1.0};   // Equal weights for simplicity
                                                                                                                                                                 
                                                                                                                                                                 // Create a mock of the abstract class
                                                                                                                                                                 AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                 
                                                                                                                                                                 // Use reflection to set protected fields
                                                                                                                                                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                 rowsField.setAccessible(true);
                                                                                                                                                                 rowsField.set(optimizer, 2);
                                                                                                                                                                 
                                                                                                                                                                 Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                 residualsField.setAccessible(true);
                                                                                                                                                                 residualsField.set(optimizer, residuals);
                                                                                                                                                                 
                                                                                                                                                                 Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                 weightsField.setAccessible(true);
                                                                                                                                                                 weightsField.set(optimizer, weights);
                                                                                                                                                                 
                                                                                                                                                                 // Mock the method call
                                                                                                                                                                 when(optimizer.getChiSquare()).thenCallRealMethod();
                                                                                                                                                                 
                                                                                                                                                                 // Calculate expected value (including first residual)
                                                                                                                                                                 double expected = (2.0 * 2.0 * 1.0) + (3.0 * 3.0 * 1.0); // 4 + 9 = 13
                                                                                                                                                                 
                                                                                                                                                                 // Call the method and verify
                                                                                                                                                                 double actual = optimizer.getChiSquare();
                                                                                                                                                                 
                                                                                                                                                                 // This assertion will fail if the mutant skips the first residual
                                                                                                                                                                 // (which would give just 9 instead of 13)
                                                                                                                                                                 assertEquals("Chi-square calculation should include first residual", 
                                                                                                                                                                             expected, actual, 0.0001);
                                                                                                                                                             }

    @Test
                                                                                                                                                         public void testGetChiSquareDetectsIndexMutant() {
                                                                                                                                                             // Setup test data
                                                                                                                                                             double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                                                             double[] residualsWeights = {0.5, 1.0, 1.5};
                                                                                                                                                             int rows = residuals.length;
                                                                                                                                                             
                                                                                                                                                             // Create partial mock of the abstract class
                                                                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                 @Override
                                                                                                                                                                 protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                     return null; // Not needed for this test
                                                                                                                                                                 }
                                                                                                                                                             };
                                                                                                                                                             
                                                                                                                                                             // Set protected fields using reflection
                                                                                                                                                             try {
                                                                                                                                                                 Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                                 residualsField.setAccessible(true);
                                                                                                                                                                 residualsField.set(optimizer, residuals);
                                                                                                                                                                 
                                                                                                                                                                 Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                                 weightsField.setAccessible(true);
                                                                                                                                                                 weightsField.set(optimizer, residualsWeights);
                                                                                                                                                                 
                                                                                                                                                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                                 rowsField.setAccessible(true);
                                                                                                                                                                 rowsField.set(optimizer, rows);
                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                 fail("Failed to set up test fields via reflection");
                                                                                                                                                             }
                                                                                                                                                             
                                                                                                                                                             // Calculate expected value manually: sum of (residual^2 * weight)
                                                                                                                                                             double expected = (1.0*1.0*0.5) + (2.0*2.0*1.0) + (3.0*3.0*1.5);
                                                                                                                                                             
                                                                                                                                                             // Test and verify
                                                                                                                                                             double actual = optimizer.getChiSquare();
                                                                                                                                                             assertEquals("Chi-square calculation is incorrect", expected, actual, 0.0001);
                                                                                                                                                         }

    @Test
                                                                                                                                                       public void testGetChiSquareDetectsArrayBoundaryMutant() throws Exception {
                                                                                                                                                           // Setup test data
                                                                                                                                                           int testRows = 2;
                                                                                                                                                           double[] testResiduals = {1.0, 2.0};
                                                                                                                                                           double[] testWeights = {0.5, 1.0};
                                                                                                                                                           
                                                                                                                                                           // Create test instance
                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                               @Override
                                                                                                                                                               protected VectorialPointValuePair doOptimize() {
                                                                                                                                                                   return null; // Not needed for this test
                                                                                                                                                               }
                                                                                                                                                           };
                                                                                                                                                           
                                                                                                                                                           // Use reflection to set protected fields
                                                                                                                                                           Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                                                                                                                                                           java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                           rowsField.setAccessible(true);
                                                                                                                                                           rowsField.set(optimizer, testRows);
                                                                                                                                                           
                                                                                                                                                           java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                           residualsField.setAccessible(true);
                                                                                                                                                           residualsField.set(optimizer, testResiduals);
                                                                                                                                                           
                                                                                                                                                           java.lang.reflect.Field weightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                           weightsField.setAccessible(true);
                                                                                                                                                           weightsField.set(optimizer, testWeights);
                                                                                                                                                           
                                                                                                                                                           // Calculate expected value (1.0^2 * 0.5 + 2.0^2 * 1.0 = 0.5 + 4.0 = 4.5)
                                                                                                                                                           double expectedChiSquare = 4.5;
                                                                                                                                                           
                                                                                                                                                           // Test the method
                                                                                                                                                           double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                                           
                                                                                                                                                           // Verify the result
                                                                                                                                                           assertEquals("Chi-square calculation is incorrect", 
                                                                                                                                                                       expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                                                           
                                                                                                                                                           // The mutant would throw ArrayIndexOutOfBoundsException here
                                                                                                                                                           // which would make the test fail
                                                                                                                                                       }

    @Test
                                                                                                                                                  public void testGetChiSquare_ShouldIncludeFirstElement() throws Exception {
                                                                                                                                                      // Setup test data
                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                          @Override
                                                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                                                              return null; // Not needed for this test
                                                                                                                                                          }
                                                                                                                                                      };
                                                                                                                                                      
                                                                                                                                                      // Use reflection to set protected fields
                                                                                                                                                      Class<?> optimizerClass = optimizer.getClass();
                                                                                                                                                      
                                                                                                                                                      // Set rows to 2 to make verification simple
                                                                                                                                                      java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                      rowsField.setAccessible(true);
                                                                                                                                                      rowsField.set(optimizer, 2);
                                                                                                                                                      
                                                                                                                                                      // Create test residuals where first element is significant
                                                                                                                                                      double[] residuals = new double[]{10.0, 1.0}; // First residual is large
                                                                                                                                                      java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                                                                                                                      residualsField.setAccessible(true);
                                                                                                                                                      residualsField.set(optimizer, residuals);
                                                                                                                                                      
                                                                                                                                                      // Create weights (all 1.0 for simplicity)
                                                                                                                                                      double[] weights = new double[]{1.0, 1.0};
                                                                                                                                                      java.lang.reflect.Field weightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                      weightsField.setAccessible(true);
                                                                                                                                                      weightsField.set(optimizer, weights);
                                                                                                                                                      
                                                                                                                                                      // Calculate expected value (include both elements)
                                                                                                                                                      double expected = (10.0 * 10.0 * 1.0) + (1.0 * 1.0 * 1.0); // 100 + 1 = 101
                                                                                                                                                      
                                                                                                                                                      // Verify the actual result matches expected
                                                                                                                                                      assertEquals("Chi-square should include first element", expected, optimizer.getChiSquare(), 0.0001);
                                                                                                                                                      
                                                                                                                                                      // Additional verification: mutant would return only 1.0 (skipping first element)
                                                                                                                                                      // This assertion would fail if the mutant is present
                                                                                                                                                      assertTrue("Chi-square should be greater than just the second element", 
                                                                                                                                                                 optimizer.getChiSquare() > 1.0);
                                                                                                                                                  }

    @Test
                                                                                                                                              public void testGetChiSquareDetectsResidualCalculationMutation() {
                                                                                                                                                  // Setup test data where target - objective != target + objective
                                                                                                                                                  double[] targetValues = {3.0, 5.0, 7.0};
                                                                                                                                                  double[] objective = {1.0, 2.0, 3.0};
                                                                                                                                                  double[] residualsWeights = {1.0, 1.0, 1.0}; // Simple weights for easy verification
                                                                                                                                                  int rows = targetValues.length;
                                                                                                                                                  
                                                                                                                                                  // Create partial mock of the class under test
                                                                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                      @Override
                                                                                                                                                      protected VectorialPointValuePair doOptimize() {
                                                                                                                                                          return null; // Not needed for this test
                                                                                                                                                      }
                                                                                                                                                  };
                                                                                                                                                  
                                                                                                                                                  // Set protected fields using reflection
                                                                                                                                                  try {
                                                                                                                                                      Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("targetValues");
                                                                                                                                                      targetField.setAccessible(true);
                                                                                                                                                      targetField.set(optimizer, targetValues);
                                                                                                                                                      
                                                                                                                                                      Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                                                                      objectiveField.setAccessible(true);
                                                                                                                                                      objectiveField.set(optimizer, objective);
                                                                                                                                                      
                                                                                                                                                      Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                      weightsField.setAccessible(true);
                                                                                                                                                      weightsField.set(optimizer, residualsWeights);
                                                                                                                                                      
                                                                                                                                                      Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                      rowsField.setAccessible(true);
                                                                                                                                                      rowsField.set(optimizer, rows);
                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                      fail("Failed to set up test fields via reflection: " + e.getMessage());
                                                                                                                                                  }
                                                                                                                                                  
                                                                                                                                                  // Calculate expected chi-square (using correct residual calculation)
                                                                                                                                                  double expectedChiSquare = 0.0;
                                                                                                                                                  for (int i = 0; i < rows; i++) {
                                                                                                                                                      double residual = targetValues[i] - objective[i];
                                                                                                                                                      expectedChiSquare += residual * residual * residualsWeights[i];
                                                                                                                                                  }
                                                                                                                                                  
                                                                                                                                                  // Call method and assert
                                                                                                                                                  double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                                  assertEquals("Chi-square calculation is incorrect - mutation not detected", 
                                                                                                                                                              expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                                                  
                                                                                                                                                  // Additional check to ensure the test would fail with the mutation
                                                                                                                                                  // (This is just for verification of our test case, not normally included in production tests)
                                                                                                                                                  double mutatedChiSquare = 0.0;
                                                                                                                                                  for (int i = 0; i < rows; i++) {
                                                                                                                                                      double residual = targetValues[i] + objective[i]; // Simulate the mutation
                                                                                                                                                      mutatedChiSquare += residual * residual * residualsWeights[i];
                                                                                                                                                  }
                                                                                                                                                  assertNotEquals("Test case would not detect mutation - needs adjustment",
                                                                                                                                                                 mutatedChiSquare, actualChiSquare, 0.0001);
                                                                                                                                              }

    @Test
                                                                                                                                            public void testGetChiSquareWithNegativeWeightsDetectsSignChange() throws Exception {
                                                                                                                                                // Setup test data where mutation would produce different results
                                                                                                                                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                    @Override
                                                                                                                                                    protected VectorialPointValuePair doOptimize() {
                                                                                                                                                        return null; // Not needed for this test
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                                
                                                                                                                                                // Use reflection to set protected fields
                                                                                                                                                Class<?> optimizerClass = optimizer.getClass();
                                                                                                                                                
                                                                                                                                                // Set dimensions
                                                                                                                                                Field rowsField = optimizerClass.getDeclaredField("rows");
                                                                                                                                                rowsField.setAccessible(true);
                                                                                                                                                rowsField.set(optimizer, 2);
                                                                                                                                                
                                                                                                                                                Field colsField = optimizerClass.getDeclaredField("cols");
                                                                                                                                                colsField.setAccessible(true);
                                                                                                                                                colsField.set(optimizer, 2); // Not used but needs initialization
                                                                                                                                                
                                                                                                                                                // Setup arrays where target != objective
                                                                                                                                                Field targetValuesField = optimizerClass.getDeclaredField("targetValues");
                                                                                                                                                targetValuesField.setAccessible(true);
                                                                                                                                                targetValuesField.set(optimizer, new double[]{5.0, 4.0});
                                                                                                                                                
                                                                                                                                                Field objectiveField = optimizerClass.getDeclaredField("objective");
                                                                                                                                                objectiveField.setAccessible(true);
                                                                                                                                                objectiveField.set(optimizer, new double[]{3.0, 6.0});
                                                                                                                                                
                                                                                                                                                // Use mixed positive and negative weights
                                                                                                                                                Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                                                                                                                residualsWeightsField.setAccessible(true);
                                                                                                                                                residualsWeightsField.set(optimizer, new double[]{1.0, -2.0});
                                                                                                                                                
                                                                                                                                                // Calculate expected chi-square
                                                                                                                                                double residual1 = 5.0 - 3.0; // 2.0
                                                                                                                                                double residual2 = 4.0 - 6.0; // -2.0
                                                                                                                                                double expectedChiSquare = residual1 * residual1 * 1.0 + residual2 * residual2 * -2.0;
                                                                                                                                                
                                                                                                                                                assertEquals("ChiSquare should match expected calculation", 
                                                                                                                                                            expectedChiSquare, 
                                                                                                                                                            optimizer.getChiSquare(), 
                                                                                                                                                            1e-10);
                                                                                                                                            }

    @Test
                                                                                                                                        public void testGetChiSquareWithNonZeroResiduals() {
                                                                                                                                            // Setup test data
                                                                                                                                            double[] residuals = {1.0, 2.0, 3.0};  // Non-zero residuals
                                                                                                                                            double[] weights = {0.5, 1.0, 1.5};    // Corresponding weights
                                                                                                                                            int rows = residuals.length;
                                                                                                                                            
                                                                                                                                            // Create partial mock of the class under test
                                                                                                                                            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                @Override
                                                                                                                                                protected VectorialPointValuePair doOptimize() {
                                                                                                                                                    return null;  // Not needed for this test
                                                                                                                                                }
                                                                                                                                            };
                                                                                                                                            
                                                                                                                                            // Set protected fields using reflection
                                                                                                                                            try {
                                                                                                                                                Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                                residualsField.setAccessible(true);
                                                                                                                                                residualsField.set(optimizer, residuals);
                                                                                                                                                
                                                                                                                                                Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                                weightsField.setAccessible(true);
                                                                                                                                                weightsField.set(optimizer, weights);
                                                                                                                                                
                                                                                                                                                Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                                rowsField.setAccessible(true);
                                                                                                                                                rowsField.set(optimizer, rows);
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                fail("Failed to set up test fields via reflection");
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            // Calculate expected value manually
                                                                                                                                            double expected = 0;
                                                                                                                                            for (int i = 0; i < rows; i++) {
                                                                                                                                                expected += residuals[i] * residuals[i] * weights[i];
                                                                                                                                            }
                                                                                                                                            
                                                                                                                                            // Test and assert
                                                                                                                                            double actual = optimizer.getChiSquare();
                                                                                                                                            assertEquals("Chi-square calculation should use actual residuals", 
                                                                                                                                                        expected, actual, 1e-10);
                                                                                                                                            
                                                                                                                                            // Additional check that result isn't zero (which mutant would produce)
                                                                                                                                            assertTrue("Chi-square should not be zero with non-zero residuals", 
                                                                                                                                                       actual != 0.0);
                                                                                                                                        }

    @Test
                                                                                                                                       public void testGetChiSquareDetectsResidualMutation() {
                                                                                                                                           // Setup test data - using simple values for easy verification
                                                                                                                                           double[] residuals = {1.0, 2.0, 3.0};  // residuals
                                                                                                                                           double[] weights = {1.0, 1.0, 1.0};    // weights (all 1 for simplicity)
                                                                                                                                           
                                                                                                                                           // Create test instance
                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                               // Anonymous subclass to access protected members
                                                                                                                                               @Override
                                                                                                                                               protected VectorialPointValuePair doOptimize() {
                                                                                                                                                   return null; // Not needed for this test
                                                                                                                                               }
                                                                                                                                           };
                                                                                                                                           
                                                                                                                                           // Set protected fields through reflection
                                                                                                                                           try {
                                                                                                                                               Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                               residualsField.setAccessible(true);
                                                                                                                                               residualsField.set(optimizer, residuals);
                                                                                                                                               
                                                                                                                                               Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                               weightsField.setAccessible(true);
                                                                                                                                               weightsField.set(optimizer, weights);
                                                                                                                                               
                                                                                                                                               Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                               rowsField.setAccessible(true);
                                                                                                                                               rowsField.set(optimizer, residuals.length);
                                                                                                                                           } catch (Exception e) {
                                                                                                                                               fail("Failed to set up test fields via reflection");
                                                                                                                                           }
                                                                                                                                           
                                                                                                                                           // Calculate expected value: sum of squared residuals (since weights are 1)
                                                                                                                                           double expected = 0;
                                                                                                                                           for (double r : residuals) {
                                                                                                                                               expected += r * r;
                                                                                                                                           }
                                                                                                                                           
                                                                                                                                           // Test the method
                                                                                                                                           double actual = optimizer.getChiSquare();
                                                                                                                                           
                                                                                                                                           // Assertion - this will fail if the mutant is present
                                                                                                                                           assertEquals("Chi-square calculation incorrect", expected, actual, 1e-10);
                                                                                                                                           
                                                                                                                                           // Additional check - verify with non-unit weights
                                                                                                                                           double[] newWeights = {0.5, 1.5, 2.0};
                                                                                                                                           try {
                                                                                                                                               Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                               weightsField.setAccessible(true);
                                                                                                                                               weightsField.set(optimizer, newWeights);
                                                                                                                                           } catch (Exception e) {
                                                                                                                                               fail("Failed to update weights via reflection");
                                                                                                                                           }
                                                                                                                                           
                                                                                                                                           // Recalculate expected with new weights
                                                                                                                                           expected = 0;
                                                                                                                                           for (int i = 0; i < residuals.length; i++) {
                                                                                                                                               expected += residuals[i] * residuals[i] * newWeights[i];
                                                                                                                                           }
                                                                                                                                           
                                                                                                                                           // Test again
                                                                                                                                           actual = optimizer.getChiSquare();
                                                                                                                                           assertEquals("Chi-square calculation with weights incorrect", expected, actual, 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                      public void testGetChiSquareDetectsIndexMutation() {
                                                                                                                                          // Setup test data
                                                                                                                                          int rows = 3;
                                                                                                                                          int cols = 2;
                                                                                                                                          double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                                          double[] residualsWeights = {0.5, 1.0, 1.5};
                                                                                                                                          
                                                                                                                                          // Create partial mock of the class under test
                                                                                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                              @Override
                                                                                                                                              protected VectorialPointValuePair doOptimize() {
                                                                                                                                                  return null; // Not needed for this test
                                                                                                                                              }
                                                                                                                                          };
                                                                                                                                          
                                                                                                                                          // Set protected fields using reflection
                                                                                                                                          try {
                                                                                                                                              Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                              rowsField.setAccessible(true);
                                                                                                                                              rowsField.set(optimizer, rows);
                                                                                                                                              
                                                                                                                                              Field colsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cols");
                                                                                                                                              colsField.setAccessible(true);
                                                                                                                                              colsField.set(optimizer, cols);
                                                                                                                                              
                                                                                                                                              Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                              residualsField.setAccessible(true);
                                                                                                                                              residualsField.set(optimizer, residuals);
                                                                                                                                              
                                                                                                                                              Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                              weightsField.setAccessible(true);
                                                                                                                                              weightsField.set(optimizer, residualsWeights);
                                                                                                                                          } catch (Exception e) {
                                                                                                                                              fail("Failed to set up test fields via reflection");
                                                                                                                                          }
                                                                                                                                          
                                                                                                                                          // Calculate expected value manually
                                                                                                                                          double expected = 0;
                                                                                                                                          for (int i = 0; i < rows; i++) {
                                                                                                                                              expected += residuals[i] * residuals[i] * residualsWeights[i];
                                                                                                                                          }
                                                                                                                                          
                                                                                                                                          // Test and verify
                                                                                                                                          double actual = optimizer.getChiSquare();
                                                                                                                                          assertEquals("Chi-square calculation should be correct", expected, actual, 0.0001);
                                                                                                                                          
                                                                                                                                          // Additional check for array bounds
                                                                                                                                          try {
                                                                                                                                              optimizer.getChiSquare(); // Should not throw exception
                                                                                                                                          } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                              fail("Method should not throw ArrayIndexOutOfBoundsException");
                                                                                                                                          }
                                                                                                                                      }

    @Test
                                                                                                                                     public void testGetChiSquareWithMultipleRows() {
                                                                                                                                         // Setup test data
                                                                                                                                         int testRows = 3;
                                                                                                                                         int testCols = 2;
                                                                                                                                         double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                                                                         double[] testWeights = {0.5, 1.0, 1.5};
                                                                                                                                         
                                                                                                                                         // Create instance and set test values
                                                                                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                             // Anonymous subclass for testing
                                                                                                                                             @Override
                                                                                                                                             protected VectorialPointValuePair doOptimize() {
                                                                                                                                                 return null; // Not needed for this test
                                                                                                                                             }
                                                                                                                                         };
                                                                                                                                         
                                                                                                                                         // Set protected fields through reflection for testing
                                                                                                                                         try {
                                                                                                                                             Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                             rowsField.setAccessible(true);
                                                                                                                                             rowsField.set(optimizer, testRows);
                                                                                                                                             
                                                                                                                                             Field colsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cols");
                                                                                                                                             colsField.setAccessible(true);
                                                                                                                                             colsField.set(optimizer, testCols);
                                                                                                                                             
                                                                                                                                             Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                             residualsField.setAccessible(true);
                                                                                                                                             residualsField.set(optimizer, testResiduals);
                                                                                                                                             
                                                                                                                                             Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                             weightsField.setAccessible(true);
                                                                                                                                             weightsField.set(optimizer, testWeights);
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Failed to set test fields via reflection");
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Calculate expected value manually
                                                                                                                                         double expectedChiSquare = 0;
                                                                                                                                         for (int i = 0; i < testRows; i++) {
                                                                                                                                             expectedChiSquare += testResiduals[i] * testResiduals[i] * testWeights[i];
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Test the method
                                                                                                                                         double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                         
                                                                                                                                         // Verify all residuals were processed correctly
                                                                                                                                         assertEquals("Chi-square calculation should process all residuals correctly", 
                                                                                                                                                      expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                                     }

    @Test
                                                                                                                                   public void testGetChiSquareIterationCount() throws Exception {
                                                                                                                                       // Setup test data
                                                                                                                                       int testRows = 3;
                                                                                                                                       double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                                                                       double[] testWeights = {0.5, 0.5, 0.5};
                                                                                                                                       
                                                                                                                                       // Create partial mock of the abstract class
                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = spy(AbstractLeastSquaresOptimizer.class);
                                                                                                                                       
                                                                                                                                       // Use reflection to set the protected fields
                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                       rowsField.set(optimizer, testRows);
                                                                                                                                       
                                                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                       residualsField.setAccessible(true);
                                                                                                                                       residualsField.set(optimizer, testResiduals);
                                                                                                                                       
                                                                                                                                       Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                       weightsField.setAccessible(true);
                                                                                                                                       weightsField.set(optimizer, testWeights);
                                                                                                                                       
                                                                                                                                       // Call the method
                                                                                                                                       double result = optimizer.getChiSquare();
                                                                                                                                       
                                                                                                                                       // Verify the calculation is correct
                                                                                                                                       double expected = (1.0*1.0*0.5) + (2.0*2.0*0.5) + (3.0*3.0*0.5);
                                                                                                                                       assertEquals(expected, result, 0.0001);
                                                                                                                                   }

    @Test
                                                                                                                                   public void testGetChiSquareWithZeroRows() throws Exception {
                                                                                                                                       // Setup test data with zero rows
                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                           @Override
                                                                                                                                           protected VectorialPointValuePair doOptimize() {
                                                                                                                                               return null; // Required abstract method implementation
                                                                                                                                           }
                                                                                                                                       };
                                                                                                                                       
                                                                                                                                       // Use reflection to set protected fields
                                                                                                                                       Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                       rowsField.setAccessible(true);
                                                                                                                                       rowsField.set(optimizer, 0);
                                                                                                                                       
                                                                                                                                       Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                       residualsField.setAccessible(true);
                                                                                                                                       residualsField.set(optimizer, new double[0]);
                                                                                                                                       
                                                                                                                                       Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                       residualsWeightsField.setAccessible(true);
                                                                                                                                       residualsWeightsField.set(optimizer, new double[0]);
                                                                                                                                       
                                                                                                                                       // Call the method
                                                                                                                                       double result = optimizer.getChiSquare();
                                                                                                                                       
                                                                                                                                       // Verify result is 0 when no rows
                                                                                                                                       assertEquals(0.0, result, 0.0001);
                                                                                                                                   }

    @Test
                                                                                                                              public void testGetChiSquareDetectsSqrtToPowMutation() {
                                                                                                                                  // Setup test data
                                                                                                                                  double[] residuals = {1.0, 2.0, 3.0};
                                                                                                                                  double[] residualsWeights = {0.5, 1.0, 1.5};
                                                                                                                                  double expectedChiSquare = 0.0;
                                                                                                                                  
                                                                                                                                  // Calculate expected value manually
                                                                                                                                  for (int i = 0; i < residuals.length; i++) {
                                                                                                                                      expectedChiSquare += residuals[i] * residuals[i] * residualsWeights[i];
                                                                                                                                  }
                                                                                                                                  // Original would take sqrt of cost, but we'll test the direct calculation
                                                                                                                                  
                                                                                                                                  // Create test instance and set fields
                                                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                      @Override
                                                                                                                                      protected VectorialPointValuePair doOptimize() {
                                                                                                                                          return null; // dummy implementation
                                                                                                                                      }
                                                                                                                                  };
                                                                                                                                  
                                                                                                                                  // Set initial cost to a known value that would show the mutation
                                                                                                                                  double initialCost = 4.0; // sqrt(4)=2, pow(4,2)=16
                                                                                                                                  
                                                                                                                                  // Use reflection to set protected fields since they're not publicly accessible
                                                                                                                                  try {
                                                                                                                                      Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                      residualsField.setAccessible(true);
                                                                                                                                      residualsField.set(optimizer, residuals);
                                                                                                                                      
                                                                                                                                      Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                      weightsField.setAccessible(true);
                                                                                                                                      weightsField.set(optimizer, residualsWeights);
                                                                                                                                      
                                                                                                                                      Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                      rowsField.setAccessible(true);
                                                                                                                                      rowsField.set(optimizer, residuals.length);
                                                                                                                                      
                                                                                                                                      Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                                      costField.setAccessible(true);
                                                                                                                                      costField.set(optimizer, initialCost);
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Failed to set up test fields via reflection: " + e.getMessage());
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Test the method
                                                                                                                                  double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                  
                                                                                                                                  // Verify the result
                                                                                                                                  // The mutation would affect the cost field but not the chiSquare calculation directly
                                                                                                                                  // However, if the cost is used in chiSquare calculation elsewhere, this would catch it
                                                                                                                                  assertEquals("ChiSquare calculation should match manual computation", 
                                                                                                                                              expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                                  
                                                                                                                                  // Additional verification to catch the mutation
                                                                                                                                  try {
                                                                                                                                      Field costField = AbstractLeastSquaresOptimizer.class.getDeclaredField("cost");
                                                                                                                                      costField.setAccessible(true);
                                                                                                                                      double finalCost = (double) costField.get(optimizer);
                                                                                                                                      
                                                                                                                                      // Original would have sqrt(4) = 2, mutated would have 4^2 = 16
                                                                                                                                      assertTrue("Cost should not be squared (mutated behavior)", 
                                                                                                                                                finalCost <= Math.sqrt(initialCost) * 1.1); // Allow small floating point differences
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Failed to verify cost field via reflection: " + e.getMessage());
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                                                              public void testGetChiSquareDetectsSqrtToAbsMutation1() {
                                                                                                                                  // Create a test instance by mocking the abstract class
                                                                                                                                  AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class, 
                                                                                                                                      CALLS_REAL_METHODS);
                                                                                                                                  
                                                                                                                                  // Setup test data where sqrt and abs would produce different results
                                                                                                                                  double testCost = 4.0; // sqrt(4) = 2, abs(4) = 4
                                                                                                                                  double[] residuals = {1.0, 2.0};
                                                                                                                                  double[] weights = {1.0, 1.0};
                                                                                                                                  
                                                                                                                                  // Set the protected fields using reflection
                                                                                                                                  try {
                                                                                                                                      java.lang.reflect.Field costField = AbstractLeastSquaresOptimizer.class
                                                                                                                                          .getDeclaredField("cost");
                                                                                                                                      costField.setAccessible(true);
                                                                                                                                      costField.set(optimizer, testCost);
                                                                                                                                      
                                                                                                                                      java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class
                                                                                                                                          .getDeclaredField("residuals");
                                                                                                                                      residualsField.setAccessible(true);
                                                                                                                                      residualsField.set(optimizer, residuals);
                                                                                                                                      
                                                                                                                                      java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class
                                                                                                                                          .getDeclaredField("residualsWeights");
                                                                                                                                      weightsField.setAccessible(true);
                                                                                                                                      weightsField.set(optimizer, weights);
                                                                                                                                      
                                                                                                                                      java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                                                                                                                                          .getDeclaredField("rows");
                                                                                                                                      rowsField.setAccessible(true);
                                                                                                                                      rowsField.set(optimizer, residuals.length);
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                  }
                                                                                                                                  
                                                                                                                                  // Calculate expected value with sqrt transformation
                                                                                                                                  double expectedChiSquare = 0;
                                                                                                                                  for (int i = 0; i < residuals.length; i++) {
                                                                                                                                      expectedChiSquare += residuals[i] * residuals[i] * weights[i];
                                                                                                                                  }
                                                                                                                                  expectedChiSquare = Math.sqrt(testCost) * expectedChiSquare;
                                                                                                                                  
                                                                                                                                  // The mutated version would use abs instead of sqrt
                                                                                                                                  double mutatedChiSquare = Math.abs(testCost) * expectedChiSquare / Math.sqrt(testCost);
                                                                                                                                  
                                                                                                                                  // Verify the method returns the sqrt-based calculation
                                                                                                                                  double actualChiSquare = optimizer.getChiSquare();
                                                                                                                                  assertNotEquals("Mutation not detected: abs used instead of sqrt", 
                                                                                                                                      mutatedChiSquare, actualChiSquare, 0.0001);
                                                                                                                                  assertEquals("Correct chi-square calculation with sqrt", 
                                                                                                                                      expectedChiSquare, actualChiSquare, 0.0001);
                                                                                                                              }

    @Test
                                                                                                                         public void testGetChiSquareBoundaryCondition() {
                                                                                                                             // Setup test data with minimum rows (1)
                                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                 @Override
                                                                                                                                 protected VectorialPointValuePair doOptimize() {
                                                                                                                                     return null; // dummy implementation
                                                                                                                                 }
                                                                                                                             };
                                                                                                                             
                                                                                                                             // Using reflection to set protected fields since they're not publicly accessible
                                                                                                                             try {
                                                                                                                                 Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                                 residualsField.setAccessible(true);
                                                                                                                                 residualsField.set(optimizer, new double[]{2.0}); // single residual
                                                                                                                                 
                                                                                                                                 Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                                 weightsField.setAccessible(true);
                                                                                                                                 weightsField.set(optimizer, new double[]{1.5}); // single weight
                                                                                                                                 
                                                                                                                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                                 rowsField.setAccessible(true);
                                                                                                                                 rowsField.set(optimizer, 1); // only 1 row
                                                                                                                             } catch (Exception e) {
                                                                                                                                 fail("Failed to setup test data via reflection");
                                                                                                                             }
                                                                                                                             
                                                                                                                             // Test the method
                                                                                                                             double result = optimizer.getChiSquare();
                                                                                                                             
                                                                                                                             // Verify the calculation (residual^2 * weight)
                                                                                                                             assertEquals(2.0 * 2.0 * 1.5, result, 0.0001);
                                                                                                                             
                                                                                                                             // Implicitly verifies no ArrayIndexOutOfBoundsException occurred
                                                                                                                             // which would happen if mutant (i <= rows) was present
                                                                                                                         }

    @Test
                                                                                                                       public void testGetChiSquare3() throws Exception {
                                                                                                                           // Setup test object
                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                               @Override
                                                                                                                               protected VectorialPointValuePair doOptimize() {
                                                                                                                                   return null; // dummy implementation
                                                                                                                               }
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Get protected fields via reflection
                                                                                                                           java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                           rowsField.setAccessible(true);
                                                                                                                           java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                           residualsField.setAccessible(true);
                                                                                                                           java.lang.reflect.Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                           residualsWeightsField.setAccessible(true);
                                                                                                                           
                                                                                                                           // Test case 1: Empty arrays (0 rows)
                                                                                                                           rowsField.setInt(optimizer, 0);
                                                                                                                           residualsField.set(optimizer, new double[0]);
                                                                                                                           residualsWeightsField.set(optimizer, new double[0]);
                                                                                                                           assertEquals(0.0, optimizer.getChiSquare(), 0.0);
                                                                                                                           
                                                                                                                           // Test case 2: Single row with positive residual
                                                                                                                           rowsField.setInt(optimizer, 1);
                                                                                                                           residualsField.set(optimizer, new double[]{2.0});
                                                                                                                           residualsWeightsField.set(optimizer, new double[]{1.5});
                                                                                                                           assertEquals(6.0, optimizer.getChiSquare(), 0.0); // 2^2 * 1.5 = 6
                                                                                                                           
                                                                                                                           // Test case 3: Multiple rows with mixed residuals
                                                                                                                           rowsField.setInt(optimizer, 3);
                                                                                                                           residualsField.set(optimizer, new double[]{1.0, -2.0, 0.5});
                                                                                                                           residualsWeightsField.set(optimizer, new double[]{2.0, 1.0, 4.0});
                                                                                                                           double expected = (1.0*1.0*2.0) + ((-2.0)*(-2.0)*1.0) + (0.5*0.5*4.0);
                                                                                                                           assertEquals(expected, optimizer.getChiSquare(), 0.0);
                                                                                                                           
                                                                                                                           // Test case 4: Edge case with zero weight
                                                                                                                           rowsField.setInt(optimizer, 2);
                                                                                                                           residualsField.set(optimizer, new double[]{3.0, 4.0});
                                                                                                                           residualsWeightsField.set(optimizer, new double[]{0.0, 1.0});
                                                                                                                           assertEquals(16.0, optimizer.getChiSquare(), 0.0); // 4^2 * 1 = 16
                                                                                                                           
                                                                                                                           // Test case 5: Large values
                                                                                                                           rowsField.setInt(optimizer, 1);
                                                                                                                           residualsField.set(optimizer, new double[]{Double.MAX_VALUE});
                                                                                                                           residualsWeightsField.set(optimizer, new double[]{1.0});
                                                                                                                           assertEquals(Double.POSITIVE_INFINITY, optimizer.getChiSquare(), 0.0);
                                                                                                                       }

    @Test
                                                                                                                  public void testEvaluationCountingWithMaxEvaluations1() {
                                                                                                                      // Setup test object
                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                          @Override
                                                                                                                          protected VectorialPointValuePair doOptimize() {
                                                                                                                              return null; // dummy implementation
                                                                                                                          }
                                                                                                                      };
                                                                                                                      
                                                                                                                      // Set max evaluations to 1
                                                                                                                      optimizer.setMaxEvaluations(1);
                                                                                                                      
                                                                                                                      // Verify initial state
                                                                                                                      assertEquals(0, optimizer.getEvaluations());
                                                                                                                      
                                                                                                                      // Mock the function to be optimized
                                                                                                                      DifferentiableMultivariateVectorialFunction function = mock(DifferentiableMultivariateVectorialFunction.class);
                                                                                                                      try {
                                                                                                                          when(function.value(any(double[].class))).thenReturn(new double[0]);
                                                                                                                      } catch (FunctionEvaluationException e) {
                                                                                                                          fail("Unexpected exception during mocking");
                                                                                                                      }
                                                                                                                      
                                                                                                                      // Create dummy parameters
                                                                                                                      double[] target = new double[0];
                                                                                                                      double[] weights = new double[0];
                                                                                                                      double[] startPoint = new double[0];
                                                                                                                      
                                                                                                                      try {
                                                                                                                          // Attempt optimization
                                                                                                                          optimizer.optimize(function, target, weights, startPoint);
                                                                                                                          
                                                                                                                          // With original code, should throw exception after 1 evaluation
                                                                                                                          // With mutant, might allow 2 evaluations
                                                                                                                          fail("Expected exception not thrown");
                                                                                                                      } catch (Exception e) {
                                                                                                                          // Verify exactly 1 evaluation occurred
                                                                                                                          assertEquals(1, optimizer.getEvaluations());
                                                                                                                      }
                                                                                                                      
                                                                                                                      // Additional verification that mutant would fail
                                                                                                                      // Mutant would report 1 evaluation but actually did 2
                                                                                                                      assertTrue(optimizer.getEvaluations() <= optimizer.getMaxEvaluations());
                                                                                                                  }

    @Test
                                                                                                              public void testGetChiSquareEvaluationBoundary() throws Exception {
                                                                                                                  // Setup test data
                                                                                                                  int testRows = 3;
                                                                                                                  double[] testResiduals = {1.0, 2.0, 3.0};
                                                                                                                  double[] testWeights = {0.5, 0.5, 0.5};
                                                                                                                  
                                                                                                                  // Create test instance using reflection since constructor is protected
                                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                      @Override
                                                                                                                      protected VectorialPointValuePair doOptimize() {
                                                                                                                          return null; // Not needed for this test
                                                                                                                      }
                                                                                                                  };
                                                                                                                  
                                                                                                                  // Set protected fields using reflection
                                                                                                                  Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                                                  rowsField.setAccessible(true);
                                                                                                                  rowsField.set(optimizer, testRows);
                                                                                                                  
                                                                                                                  Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                                                  residualsField.setAccessible(true);
                                                                                                                  residualsField.set(optimizer, testResiduals);
                                                                                                                  
                                                                                                                  Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                                                  weightsField.setAccessible(true);
                                                                                                                  weightsField.set(optimizer, testWeights);
                                                                                                                  
                                                                                                                  // Set evaluation boundary condition
                                                                                                                  Field maxEvalField = AbstractLeastSquaresOptimizer.class.getDeclaredField("maxEvaluations");
                                                                                                                  maxEvalField.setAccessible(true);
                                                                                                                  maxEvalField.set(optimizer, 1);
                                                                                                                  
                                                                                                                  Field objEvalField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objectiveEvaluations");
                                                                                                                  objEvalField.setAccessible(true);
                                                                                                                  objEvalField.set(optimizer, 1); // Exactly equals maxEvaluations
                                                                                                                  
                                                                                                                  // Test - should complete normally (mutant would fail here)
                                                                                                                  double result = optimizer.getChiSquare();
                                                                                                                  
                                                                                                                  // Verify calculation (0.5*1^2 + 0.5*2^2 + 0.5*3^2 = 0.5 + 2.0 + 4.5 = 7.0)
                                                                                                                  assertEquals(7.0, result, 0.0001);
                                                                                                                  
                                                                                                                  // Verify evaluation count wasn't incremented (would happen if mutant triggered)
                                                                                                                  assertEquals(1, objEvalField.getInt(optimizer));
                                                                                                              }

    @Test
                                                                                    public void testGetChiSquareThrowsFunctionEvaluationExceptionWithCorrectCause() throws Exception {
                                                                                        // Setup test object
                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                            @Override
                                                                                            protected VectorialPointValuePair doOptimize() {
                                                                                                // Force evaluation count to exceed max
                                                                                                try {
                                                                                                    incrementIterationsCounter();
                                                                                                    incrementIterationsCounter();
                                                                                                } catch (OptimizationException e) {
                                                                                                    // Expected exception
                                                                                                }
                                                                                                return null;
                                                                                            }
                                                                                        };
                                                                                        
                                                                                        // Set max evaluations to a low number
                                                                                        optimizer.setMaxEvaluations(1);
                                                                                        
                                                                                        // Use reflection to set protected fields needed for chi-square calculation
                                                                                        Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                        residualsField.setAccessible(true);
                                                                                        residualsField.set(optimizer, new double[]{1.0, 2.0});
                                                                                        
                                                                                        Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                        residualsWeightsField.setAccessible(true);
                                                                                        residualsWeightsField.set(optimizer, new double[]{1.0, 1.0});
                                                                                        
                                                                                        Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                        rowsField.setAccessible(true);
                                                                                        rowsField.set(optimizer, 2);
                                                                                        
                                                                                        // This should throw MaxEvaluationsExceededException during optimization
                                                                                        optimizer.optimize(null, null, null, null);
                                                                                    }

    @Test
                                                                               public void testGetChiSquare_verifiesFunctionValueCalledWithPoint() throws Exception {
                                                                                   // Setup test data
                                                                                   int testRows = 2;
                                                                                   double[] testResiduals = {1.0, 2.0};
                                                                                   double[] testWeights = {0.5, 0.5};
                                                                                   double[] testPoint = {1.0, 2.0};
                                                                                   double[] testObjective = {3.0, 4.0};
                                                                                   
                                                                                   // Create partial mock of the optimizer
                                                                                   AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                   
                                                                                   // Setup mock behavior
                                                                                   when(optimizer.getChiSquare()).thenCallRealMethod();
                                                                                   
                                                                                   // Mock the function
                                                                                   DifferentiableMultivariateVectorialFunction function = mock(DifferentiableMultivariateVectorialFunction.class);
                                                                                   when(function.value(testPoint)).thenReturn(testObjective);
                                                                                   
                                                                                   // Set internal state using reflection
                                                                                   Field functionField = AbstractLeastSquaresOptimizer.class.getDeclaredField("function");
                                                                                   functionField.setAccessible(true);
                                                                                   functionField.set(optimizer, function);
                                                                                   
                                                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                   rowsField.setAccessible(true);
                                                                                   rowsField.set(optimizer, testRows);
                                                                                   
                                                                                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                   residualsField.setAccessible(true);
                                                                                   residualsField.set(optimizer, testResiduals);
                                                                                   
                                                                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                   weightsField.setAccessible(true);
                                                                                   weightsField.set(optimizer, testWeights);
                                                                                   
                                                                                   Field pointField = AbstractLeastSquaresOptimizer.class.getDeclaredField("point");
                                                                                   pointField.setAccessible(true);
                                                                                   pointField.set(optimizer, testPoint);
                                                                                   
                                                                                   // Execute and verify
                                                                                   double result = optimizer.getChiSquare();
                                                                                   
                                                                                   // Verify function was called with correct point
                                                                                   verify(function).value(testPoint);
                                                                                   
                                                                                   // Verify calculation is correct
                                                                                   double expectedChiSquare = testResiduals[0] * testResiduals[0] * testWeights[0] 
                                                                                                           + testResiduals[1] * testResiduals[1] * testWeights[1];
                                                                                   assertEquals(expectedChiSquare, result, 0.0001);
                                                                               }

    @Test
                                                                          public void testGetChiSquareWithMatchingLengths() throws Exception {
                                                                              // Create optimizer instance
                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                  @Override
                                                                                  protected VectorialPointValuePair doOptimize() {
                                                                                      return null;
                                                                                  }
                                                                              };
                                                                              
                                                                              // Use reflection to set private fields
                                                                              Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                              rowsField.setAccessible(true);
                                                                              rowsField.set(optimizer, 3);
                                                                              
                                                                              Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                              objectiveField.setAccessible(true);
                                                                              objectiveField.set(optimizer, new double[3]);
                                                                              
                                                                              Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                              residualsField.setAccessible(true);
                                                                              residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                              
                                                                              Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                              residualsWeightsField.setAccessible(true);
                                                                              residualsWeightsField.set(optimizer, new double[]{0.5, 0.5, 0.5});
                                                                              
                                                                              // Original should calculate chi-square, mutant should throw exception
                                                                              try {
                                                                                  double result = optimizer.getChiSquare();
                                                                                  // Verify calculation is correct
                                                                                  double expected = 1.0*1.0*0.5 + 2.0*2.0*0.5 + 3.0*3.0*0.5;
                                                                                  assertEquals(expected, result, 0.0001);
                                                                              } catch (Exception e) {
                                                                                  fail("Original should not throw exception when lengths match");
                                                                              }
                                                                          }

    @Test(expected = IllegalArgumentException.class)
                                                                          public void testGetChiSquareWithNonMatchingLengths() {
                                                                              // Create a concrete instance of the abstract class for testing
                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                  protected VectorialPointValuePair doOptimize() {
                                                                                      return null;
                                                                                  }
                                                                              };
                                                                              
                                                                              // Use reflection to set private fields since they're not directly accessible
                                                                              try {
                                                                                  Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                                  rowsField.setAccessible(true);
                                                                                  rowsField.set(optimizer, 3);
                                                                                  
                                                                                  Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                  objectiveField.setAccessible(true);
                                                                                  objectiveField.set(optimizer, new double[2]); // length doesn't match rows
                                                                                  
                                                                                  Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                                  residualsField.setAccessible(true);
                                                                                  residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                                                  
                                                                                  Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                                  residualsWeightsField.setAccessible(true);
                                                                                  residualsWeightsField.set(optimizer, new double[]{0.5, 0.5, 0.5});
                                                                              } catch (Exception e) {
                                                                                  throw new RuntimeException("Failed to set fields via reflection", e);
                                                                              }
                                                                              
                                                                              // This should throw IllegalArgumentException due to length mismatch
                                                                              optimizer.getChiSquare();
                                                                          }

    @Test(expected = IllegalArgumentException.class)
                                                                     public void testGetChiSquareWhenObjectiveShorterThanRows() throws Exception {
                                                                         // Create an instance of the concrete optimizer class
                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                             protected VectorialPointValuePair doOptimize() {
                                                                                 return null;
                                                                             }
                                                                         };
                                                                         
                                                                         // Use reflection to set private fields since they're not directly accessible
                                                                         Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                         rowsField.setAccessible(true);
                                                                         rowsField.setInt(optimizer, 5);
                                                                         
                                                                         Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                         objectiveField.setAccessible(true);
                                                                         objectiveField.set(optimizer, new double[4]); // shorter than rows
                                                                         
                                                                         Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                         residualsField.setAccessible(true);
                                                                         residualsField.set(optimizer, new double[5]);
                                                                         
                                                                         Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                         residualsWeightsField.setAccessible(true);
                                                                         residualsWeightsField.set(optimizer, new double[5]);
                                                                         
                                                                         // This should throw IllegalArgumentException because dimensions don't match
                                                                         optimizer.getChiSquare();
                                                                     }

    @Test(expected = IllegalArgumentException.class)
                                                                     public void testGetChiSquareWhenObjectiveLongerThanRows() throws Exception {
                                                                         // Create optimizer instance
                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                             protected VectorialPointValuePair doOptimize() {
                                                                                 return null;
                                                                             }
                                                                         };
                                                                         
                                                                         // Use reflection to set private/protected fields
                                                                         Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                         rowsField.setAccessible(true);
                                                                         rowsField.set(optimizer, 5);
                                                                         
                                                                         Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                         objectiveField.setAccessible(true);
                                                                         objectiveField.set(optimizer, new double[6]); // longer than rows
                                                                         
                                                                         Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                         residualsField.setAccessible(true);
                                                                         residualsField.set(optimizer, new double[5]);
                                                                         
                                                                         Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                         residualsWeightsField.setAccessible(true);
                                                                         residualsWeightsField.set(optimizer, new double[5]);
                                                                         
                                                                         // Should throw IllegalArgumentException
                                                                         optimizer.getChiSquare();
                                                                     }

    @Test
                                                                     public void testGetChiSquareWhenDimensionsMatch() throws Exception {
                                                                         // Create optimizer instance
                                                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                             protected VectorialPointValuePair doOptimize() {
                                                                                 return null;
                                                                             }
                                                                         };
                                                                         
                                                                         // Use reflection to set private fields
                                                                         Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                                         rowsField.setAccessible(true);
                                                                         rowsField.set(optimizer, 5);
                                                                         
                                                                         Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                         objectiveField.setAccessible(true);
                                                                         objectiveField.set(optimizer, new double[5]);
                                                                         
                                                                         Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                                         residualsField.setAccessible(true);
                                                                         residualsField.set(optimizer, new double[5]);
                                                                         
                                                                         Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                                         residualsWeightsField.setAccessible(true);
                                                                         residualsWeightsField.set(optimizer, new double[5]);
                                                                         
                                                                         // Get fields to populate test data
                                                                         double[] residuals = (double[]) residualsField.get(optimizer);
                                                                         double[] residualsWeights = (double[]) residualsWeightsField.get(optimizer);
                                                                         
                                                                         // Fill with test data
                                                                         for (int i = 0; i < 5; i++) {
                                                                             residuals[i] = i + 1;
                                                                             residualsWeights[i] = 0.5;
                                                                         }
                                                                         
                                                                         // Calculate expected value
                                                                         double expected = 0;
                                                                         for (int i = 0; i < 5; i++) {
                                                                             expected += (i+1) * (i+1) * 0.5;
                                                                         }
                                                                         
                                                                         assertEquals(expected, optimizer.getChiSquare(), 0.0001);
                                                                     }

    @Test
                                                    public void testGetChiSquareThrowsExceptionWithPointData() throws Exception {
                                                        // Setup test object with inconsistent dimensions to trigger exception
                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                            @Override
                                                            protected VectorialPointValuePair doOptimize() {
                                                                return null;
                                                            }
                                                        };
                                                        
                                                        // Use reflection to set protected fields
                                                        Class<?> optimizerClass = optimizer.getClass();
                                                        
                                                        // Set rows
                                                        java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                                        rowsField.setAccessible(true);
                                                        rowsField.setInt(optimizer, 2);
                                                        
                                                        // Set cols
                                                        java.lang.reflect.Field colsField = optimizerClass.getDeclaredField("cols");
                                                        colsField.setAccessible(true);
                                                        colsField.setInt(optimizer, 3);
                                                        
                                                        // Set residuals
                                                        java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                                        residualsField.setAccessible(true);
                                                        residualsField.set(optimizer, new double[2]);
                                                        
                                                        // Set residualsWeights (incorrect size)
                                                        java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                                        residualsWeightsField.setAccessible(true);
                                                        residualsWeightsField.set(optimizer, new double[3]);
                                                        
                                                        // Set point
                                                        double[] point = new double[]{1.0, 2.0, 3.0};
                                                        java.lang.reflect.Field pointField = optimizerClass.getDeclaredField("point");
                                                        pointField.setAccessible(true);
                                                        pointField.set(optimizer, point);
                                                        
                                                        try {
                                                            optimizer.getChiSquare();
                                                            fail("Expected exception");
                                                        } catch (Exception e) {
                                                            // Verify exception message
                                                            assertTrue("Exception message should contain 'dimensions mismatch'", 
                                                                      e.getMessage().contains("dimensions mismatch"));
                                                        }
                                                    }

    @Test
                                               public void testGetChiSquareDetectsInitializationMutant() throws Exception {
                                                   // Setup test object and data
                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                       @Override
                                                       protected VectorialPointValuePair doOptimize() {
                                                           return null; // Not needed for this test
                                                       }
                                                   };
                                                   
                                                   // Get field references using reflection
                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                   Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                   
                                                   // Make fields accessible
                                                   rowsField.setAccessible(true);
                                                   residualsField.setAccessible(true);
                                                   residualsWeightsField.setAccessible(true);
                                                   
                                                   // Test case 1: Empty residuals (should return 0)
                                                   rowsField.setInt(optimizer, 0);
                                                   residualsField.set(optimizer, new double[0]);
                                                   residualsWeightsField.set(optimizer, new double[0]);
                                                   assertEquals(0.0, optimizer.getChiSquare(), 0.0001);
                                                   
                                                   // Test case 2: Single residual with weight 1 (should return residual^2)
                                                   rowsField.setInt(optimizer, 1);
                                                   residualsField.set(optimizer, new double[]{2.0});
                                                   residualsWeightsField.set(optimizer, new double[]{1.0});
                                                   assertEquals(4.0, optimizer.getChiSquare(), 0.0001);
                                                   
                                                   // Test case 3: Multiple residuals with different weights
                                                   rowsField.setInt(optimizer, 3);
                                                   residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                                                   residualsWeightsField.set(optimizer, new double[]{1.0, 0.5, 2.0});
                                                   // Expected: 1*1*1 + 2*2*0.5 + 3*3*2 = 1 + 2 + 18 = 21
                                                   assertEquals(21.0, optimizer.getChiSquare(), 0.0001);
                                                   
                                                   // Test case 4: Very small values
                                                   rowsField.setInt(optimizer, 2);
                                                   residualsField.set(optimizer, new double[]{0.001, 0.002});
                                                   residualsWeightsField.set(optimizer, new double[]{1000.0, 1000.0});
                                                   // Expected: 0.001^2*1000 + 0.002^2*1000 = 0.001 + 0.004 = 0.005
                                                   assertEquals(0.005, optimizer.getChiSquare(), 0.0000001);
                                               }

    @Test
                                           public void testGetChiSquareDetectsInitializationMutation() {
                                               // Setup test data
                                               double[] residuals = {1.0, 2.0, 3.0};
                                               double[] residualsWeights = {0.5, 1.0, 1.5};
                                               int rows = residuals.length;
                                               
                                               // Create partial mock of the class under test
                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                   @Override
                                                   protected VectorialPointValuePair doOptimize() {
                                                       return null; // Not needed for this test
                                                   }
                                               };
                                               
                                               // Set protected fields using reflection
                                               try {
                                                   Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                                   residualsField.setAccessible(true);
                                                   residualsField.set(optimizer, residuals);
                                                   
                                                   Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                                   weightsField.setAccessible(true);
                                                   weightsField.set(optimizer, residualsWeights);
                                                   
                                                   Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                                   rowsField.setAccessible(true);
                                                   rowsField.set(optimizer, rows);
                                               } catch (Exception e) {
                                                   fail("Failed to set up test fields via reflection");
                                               }
                                               
                                               // Calculate expected value manually
                                               double expected = 0.0; // Original starts from 0
                                               for (int i = 0; i < rows; i++) {
                                                   expected += residuals[i] * residuals[i] * residualsWeights[i];
                                               }
                                               
                                               // Test and assert
                                               double actual = optimizer.getChiSquare();
                                               assertEquals("Chi-square calculation should start from 0", expected, actual, 1e-10);
                                               
                                               // Additional check: if the mutant exists (starting from -1), this would fail
                                               // as actual would be (expected - 1)
                                           }

    @Test
                                         public void testGetChiSquare_ShouldIncludeFirstRow() throws Exception {
                                             // Setup test data
                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                 @Override
                                                 protected VectorialPointValuePair doOptimize() {
                                                     return null; // Not needed for this test
                                                 }
                                             };
                                             
                                             // Use reflection to set protected fields
                                             Class<?> optimizerClass = optimizer.getClass();
                                             java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                             rowsField.setAccessible(true);
                                             rowsField.setInt(optimizer, 3);
                                             
                                             java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                             residualsField.setAccessible(true);
                                             residualsField.set(optimizer, new double[]{2.0, 3.0, 4.0});
                                             
                                             java.lang.reflect.Field weightsField = optimizerClass.getDeclaredField("residualsWeights");
                                             weightsField.setAccessible(true);
                                             weightsField.set(optimizer, new double[]{1.0, 2.0, 1.0});
                                             
                                             // Calculate expected chiSquare (including first row)
                                             double expectedChiSquare = 
                                                 (2.0 * 2.0 * 1.0) +  // first row contribution (would be skipped by mutant)
                                                 (3.0 * 3.0 * 2.0) + 
                                                 (4.0 * 4.0 * 1.0);
                                             
                                             // Call method and assert
                                             double actualChiSquare = optimizer.getChiSquare();
                                             assertEquals("Chi-square calculation should include first row", 
                                                         expectedChiSquare, 
                                                         actualChiSquare, 
                                                         0.0001);
                                             
                                             // Additional check: verify first row's contribution is included
                                             double firstRowContribution = 2.0 * 2.0 * 1.0;
                                             assertTrue("First row's contribution is missing", 
                                                        actualChiSquare > firstRowContribution);
                                         }

    @Test
                                         public void testGetChiSquareCalculatesCorrectValue() {
                                             // Create a test instance by mocking the abstract class
                                             AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class, 
                                                 CALLS_REAL_METHODS);
                                             
                                             // Setup test data
                                             double[] residuals = {1.0, 2.0, 3.0};
                                             double[] weights = {0.5, 1.0, 1.5};
                                             
                                             // Set protected fields using reflection
                                             try {
                                                 java.lang.reflect.Field residualsField = AbstractLeastSquaresOptimizer.class
                                                     .getDeclaredField("residuals");
                                                 residualsField.setAccessible(true);
                                                 residualsField.set(optimizer, residuals);
                                                 
                                                 java.lang.reflect.Field weightsField = AbstractLeastSquaresOptimizer.class
                                                     .getDeclaredField("residualsWeights");
                                                 weightsField.setAccessible(true);
                                                 weightsField.set(optimizer, weights);
                                                 
                                                 java.lang.reflect.Field rowsField = AbstractLeastSquaresOptimizer.class
                                                     .getDeclaredField("rows");
                                                 rowsField.setAccessible(true);
                                                 rowsField.set(optimizer, residuals.length);
                                             } catch (Exception e) {
                                                 fail("Failed to set up test fields via reflection");
                                             }
                                             
                                             // Calculate expected value manually
                                             double expected = 0;
                                             for (int i = 0; i < residuals.length; i++) {
                                                 expected += residuals[i] * residuals[i] * weights[i];
                                             }
                                             
                                             // Test the method
                                             double actual = optimizer.getChiSquare();
                                             
                                             // Verify the result
                                             assertEquals("Chi-square calculation is incorrect", 
                                                 expected, actual, 0.0001);
                                         }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                                    public void testGetChiSquareDetectsMutant() {
                                        // Setup test data with 2 rows
                                        int testRows = 2;
                                        double[] testResiduals = {1.0, 2.0};
                                        double[] testWeights = {0.5, 0.5};
                                        
                                        // Create test instance and set protected fields via reflection
                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                            protected VectorialPointValuePair doOptimize() {
                                                return null; // dummy implementation
                                            }
                                        };
                                        
                                        // Set protected fields using reflection
                                        try {
                                            Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                            rowsField.setAccessible(true);
                                            rowsField.set(optimizer, testRows);
                                            
                                            Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                                            residualsField.setAccessible(true);
                                            residualsField.set(optimizer, testResiduals);
                                            
                                            Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                            weightsField.setAccessible(true);
                                            weightsField.set(optimizer, testWeights);
                                        } catch (Exception e) {
                                            fail("Failed to set up test fields via reflection");
                                        }
                                        
                                        // This should throw ArrayIndexOutOfBoundsException for the mutant
                                        optimizer.getChiSquare();
                                        
                                        // If we get here, the test fails (mutant not detected)
                                        fail("Mutant not detected - loop condition was not properly tested");
                                    }

    @Test
                                  public void testGetChiSquare_ShouldIncludeFirstResidual() throws Exception {
                                      // Setup test data
                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                          @Override
                                          protected VectorialPointValuePair doOptimize() {
                                              return null; // dummy implementation
                                          }
                                      };
                                      
                                      // Use reflection to set protected fields
                                      Class<?> optimizerClass = optimizer.getClass();
                                      java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                                      rowsField.setAccessible(true);
                                      rowsField.set(optimizer, 2);
                                      
                                      java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
                                      residualsField.setAccessible(true);
                                      residualsField.set(optimizer, new double[]{10.0, 1.0}); // first residual is large
                                      
                                      java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                                      residualsWeightsField.setAccessible(true);
                                      residualsWeightsField.set(optimizer, new double[]{1.0, 1.0}); // equal weights
                                      
                                      // Calculate expected value (including first residual)
                                      double expected = (10.0 * 10.0 * 1.0) + (1.0 * 1.0 * 1.0); // = 100 + 1 = 101
                                      
                                      // Call method and assert
                                      double actual = optimizer.getChiSquare();
                                      assertEquals("Chi-square calculation should include first residual", 
                                                  expected, actual, 0.0001);
                                      
                                      // Additional check: verify the test would fail if first residual was skipped
                                      double mutantExpected = 1.0; // if first residual was skipped
                                      assertNotEquals("Test should fail if first residual was skipped", 
                                                     mutantExpected, actual, 0.0001);
                                  }

    @Test
                             public void testGetChiSquareDetectsResidualCalculationMutation1() throws Exception {
                                 // Setup test data where target and objective values are different
                                 double[] targetValues = {3.0, 5.0, 7.0};
                                 double[] objective = {1.0, 2.0, 3.0};
                                 double[] residualsWeights = {1.0, 1.0, 1.0}; // Simple weights for easy calculation
                                 int rows = targetValues.length;
                                 
                                 // Create mock of the class to test getChiSquare()
                                 AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                 
                                 // Use reflection to set protected fields
                                 Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                                 rowsField.setAccessible(true);
                                 rowsField.set(optimizer, rows);
                                 
                                 Field targetValuesField = AbstractLeastSquaresOptimizer.class.getDeclaredField("targetValues");
                                 targetValuesField.setAccessible(true);
                                 targetValuesField.set(optimizer, targetValues);
                                 
                                 Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                 objectiveField.setAccessible(true);
                                 objectiveField.set(optimizer, objective);
                                 
                                 Field residualsWeightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                                 residualsWeightsField.setAccessible(true);
                                 residualsWeightsField.set(optimizer, residualsWeights);
                                 
                                 // Call the real method (not mocked) for testing
                                 when(optimizer.getChiSquare()).thenCallRealMethod();
                                 
                                 // Calculate expected value with correct residual calculation (target - objective)
                                 double expectedChiSquare = 0;
                                 for (int i = 0; i < rows; i++) {
                                     double residual = targetValues[i] - objective[i];
                                     expectedChiSquare += residual * residual * residualsWeights[i];
                                 }
                                 
                                 // Calculate what the mutant would produce (target + objective)
                                 double mutantChiSquare = 0;
                                 for (int i = 0; i < rows; i++) {
                                     double residual = targetValues[i] + objective[i];
                                     mutantChiSquare += residual * residual * residualsWeights[i];
                                 }
                                 
                                 // Verify the actual result matches expected (not mutant) calculation
                                 double actualChiSquare = optimizer.getChiSquare();
                                 assertEquals(expectedChiSquare, actualChiSquare, 0.0001);
                                 
                                 // Additional assertion to ensure we would catch the mutant
                                 assertNotEquals(mutantChiSquare, actualChiSquare, 0.0001);
                             }

    @Test
                        public void testGetChiSquareWithNegativeWeightsDetectsSignMutation() throws Exception {
                            // Setup test data with negative weights
                            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                @Override
                                protected VectorialPointValuePair doOptimize() {
                                    return null; // Not needed for this test
                                }
                            };
                            
                            // Use reflection to set protected fields
                            Class<?> optimizerClass = optimizer.getClass().getSuperclass();
                            
                            // Set dimensions
                            java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
                            rowsField.setAccessible(true);
                            rowsField.set(optimizer, 2);
                            
                            java.lang.reflect.Field colsField = optimizerClass.getDeclaredField("cols");
                            colsField.setAccessible(true);
                            colsField.set(optimizer, 2); // Not used but needs initialization
                            
                            // Set test data where target != objective
                            java.lang.reflect.Field targetValuesField = optimizerClass.getDeclaredField("targetValues");
                            targetValuesField.setAccessible(true);
                            targetValuesField.set(optimizer, new double[]{1.0, 2.0});
                            
                            java.lang.reflect.Field objectiveField = optimizerClass.getDeclaredField("objective");
                            objectiveField.setAccessible(true);
                            objectiveField.set(optimizer, new double[]{3.0, 4.0});
                            
                            // Set weights with at least one negative value
                            java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
                            residualsWeightsField.setAccessible(true);
                            residualsWeightsField.set(optimizer, new double[]{1.0, -1.0});
                            
                            // Calculate expected chi-square with correct residual signs
                            double expected = 0;
                            for (int i = 0; i < (int)rowsField.get(optimizer); i++) {
                                double correctResidual = ((double[])targetValuesField.get(optimizer))[i] - 
                                                       ((double[])objectiveField.get(optimizer))[i];
                                expected += correctResidual * correctResidual * 
                                           ((double[])residualsWeightsField.get(optimizer))[i];
                            }
                            
                            // Call the method and assert
                            double actual = optimizer.getChiSquare();
                            assertEquals("Chi-square calculation should be sensitive to residual sign with negative weights", 
                                        expected, actual, 1e-10);
                            
                            // Additional check to ensure the test would fail with the mutant
                            double mutantExpected = 0;
                            for (int i = 0; i < (int)rowsField.get(optimizer); i++) {
                                double mutantResidual = ((double[])objectiveField.get(optimizer))[i] - 
                                                      ((double[])targetValuesField.get(optimizer))[i]; // Mutant version
                                mutantExpected += mutantResidual * mutantResidual * 
                                                 ((double[])residualsWeightsField.get(optimizer))[i];
                            }
                            assertNotEquals("Test should detect mutant by showing different results", 
                                           mutantExpected, actual, 1e-10);
                        }

    @Test
                   public void testGetChiSquare_ShouldNotModifyResidualsArray() {
                       // Setup test data
                       int testRows = 3;
                       double[] testResiduals = {1.5, 2.0, 3.5};
                       double[] testWeights = {0.5, 1.0, 1.5};
                       double[] originalResidualsCopy = new double[testResiduals.length];
                       System.arraycopy(testResiduals, 0, originalResidualsCopy, 0, testResiduals.length);
                       
                       // Create partial mock of the class under test
                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                           @Override
                           protected VectorialPointValuePair doOptimize() {
                               return null; // Not needed for this test
                           }
                       };
                       
                       // Set protected fields using reflection
                       try {
                           Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                           residualsField.setAccessible(true);
                           residualsField.set(optimizer, testResiduals);
                           
                           Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                           weightsField.setAccessible(true);
                           weightsField.set(optimizer, testWeights);
                           
                           Field rowsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("rows");
                           rowsField.setAccessible(true);
                           rowsField.set(optimizer, testRows);
                       } catch (Exception e) {
                           fail("Failed to set up test fields via reflection: " + e.getMessage());
                       }
                       
                       // Call method under test
                       double result = optimizer.getChiSquare();
                       
                       // Verify residuals array was not modified
                       for (int i = 0; i < testResiduals.length; i++) {
                           assertEquals("Residuals array should remain unchanged", 
                                       originalResidualsCopy[i], 
                                       testResiduals[i], 
                                       0.0001);
                       }
                       
                       // Additional verification that chi-square was calculated correctly
                       double expectedChiSquare = 0;
                       for (int i = 0; i < testRows; i++) {
                           expectedChiSquare += originalResidualsCopy[i] * originalResidualsCopy[i] * testWeights[i];
                       }
                       assertEquals(expectedChiSquare, result, 0.0001);
                   }

    @Test
              public void testGetChiSquareDetectsResidualMutation1() {
                  // Setup test data with small residuals where +1 would make significant difference
                  double[] residuals = {0.1, 0.2, 0.3};
                  double[] weights = {1.0, 1.0, 1.0};
                  int rows = residuals.length;
                  
                  // Create partial mock of the optimizer
                  AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                  
                  // Set up the mock behavior
                  when(optimizer.getChiSquare()).thenCallRealMethod();
                  
                  // Use reflection to set protected fields since we can't access them directly
                  try {
                      Field residualsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residuals");
                      residualsField.setAccessible(true);
                      residualsField.set(optimizer, residuals);
                      
                      Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("residualsWeights");
                      weightsField.setAccessible(true);
                      weightsField.set(optimizer, weights);
                  } catch (Exception e) {
                      fail("Failed to set up test due to reflection error: " + e.getMessage());
                  }
                  
                  // Calculate expected value manually: sum of (residual^2 * weight)
                  double expected = 0.0;
                  for (int i = 0; i < rows; i++) {
                      expected += residuals[i] * residuals[i] * weights[i];
                  }
                  
                  // Get actual value from method
                  double actual = optimizer.getChiSquare();
                  
                  // Assert exact match - will fail if mutation (+1) is present
                  assertEquals("Chi-square calculation incorrect - possible residual mutation not detected", 
                              expected, actual, 0.000001);
              }

    @Test
         public void testGetChiSquareCalculatesCorrectValue1() throws Exception {
             // Setup test data
             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                 @Override
                 protected VectorialPointValuePair doOptimize() {
                     return null; // dummy implementation
                 }
             };
             
             // Use reflection to set protected fields
             Class<?> optimizerClass = optimizer.getClass().getSuperclass();
             java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
             rowsField.setAccessible(true);
             rowsField.set(optimizer, 3);
             
             java.lang.reflect.Field colsField = optimizerClass.getDeclaredField("cols");
             colsField.setAccessible(true);
             colsField.set(optimizer, 2); // Important for mutation detection
             
             java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
             residualsField.setAccessible(true);
             residualsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
             
             java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
             residualsWeightsField.setAccessible(true);
             residualsWeightsField.set(optimizer, new double[]{0.5, 1.0, 1.5});
             
             // Calculate expected value manually
             double expected = 0;
             double[] residuals = (double[]) residualsField.get(optimizer);
             double[] weights = (double[]) residualsWeightsField.get(optimizer);
             int rows = (int) rowsField.get(optimizer);
             
             for (int i = 0; i < rows; i++) {
                 expected += residuals[i] * residuals[i] * weights[i];
             }
             
             // Test the method
             double actual = optimizer.getChiSquare();
             
             // Verify
             assertEquals("Chi-square calculation is incorrect", expected, actual, 0.0001);
             
             // Additional test to catch the mutation
             // The mutation would cause incorrect behavior when cols > 0
             // We'll verify with a different cols value
             colsField.set(optimizer, 1);
             residualsField.set(optimizer, new double[]{1.0, 1.0, 1.0});
             residualsWeightsField.set(optimizer, new double[]{1.0, 1.0, 1.0});
             
             expected = 3.0; // 1^2*1 + 1^2*1 + 1^2*1 = 3
             actual = optimizer.getChiSquare();
             assertEquals("Chi-square calculation fails with cols=1", expected, actual, 0.0001);
         }

    @Test
    public void testGetChiSquareWithMultipleRows1() throws Exception {
        // Create a test instance by extending the abstract class
        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
            @Override
            protected VectorialPointValuePair doOptimize() {
                return null; // Not needed for this test
            }
        };
        
        // Use reflection to set protected fields
        Class<?> optimizerClass = optimizer.getClass().getSuperclass();
        
        // Set rows field
        java.lang.reflect.Field rowsField = optimizerClass.getDeclaredField("rows");
        rowsField.setAccessible(true);
        rowsField.setInt(optimizer, 3);
        
        // Set cols field (not used in calculation but part of original test)
        java.lang.reflect.Field colsField = optimizerClass.getDeclaredField("cols");
        colsField.setAccessible(true);
        colsField.setInt(optimizer, 2);
        
        // Set up test data with 3 rows
        double[] residuals = {1.0, 2.0, 3.0};
        double[] residualsWeights = {0.5, 1.0, 1.5};
        
        // Set residuals field
        java.lang.reflect.Field residualsField = optimizerClass.getDeclaredField("residuals");
        residualsField.setAccessible(true);
        residualsField.set(optimizer, residuals);
        
        // Set residualsWeights field
        java.lang.reflect.Field residualsWeightsField = optimizerClass.getDeclaredField("residualsWeights");
        residualsWeightsField.setAccessible(true);
        residualsWeightsField.set(optimizer, residualsWeights);
        
        // Calculate expected chi-square manually
        double expected = 0;
        for (int i = 0; i < residuals.length; i++) {
            expected += residuals[i] * residuals[i] * residualsWeights[i];
        }
        
        // Call the method and verify
        double actual = optimizer.getChiSquare();
        assertEquals("Chi-square calculation should be correct", expected, actual, 0.0001);
        
        // Additional verification that all rows were processed
        assertEquals("Should process all 3 rows", 
                    residuals[0] * residuals[0] * residualsWeights[0] +
                    residuals[1] * residuals[1] * residualsWeights[1] +
                    residuals[2] * residuals[2] * residualsWeights[2],
                    actual, 0.0001);
    }


}
