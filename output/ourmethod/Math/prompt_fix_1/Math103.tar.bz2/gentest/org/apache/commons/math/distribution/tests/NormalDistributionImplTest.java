package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.special.Erf;
 
public class NormalDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                                                                              public void testConstructor_InvalidStandardDeviation() {
                                                                                                                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                  new NormalDistributionImpl(0.0, 0.0); // Zero standard deviation
                                                                                                                                                                              }

 @Test
                                                                                                                                                                              public void testConstructor_NegativeStandardDeviation() {
                                                                                                                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                  new NormalDistributionImpl(0.0, -1.0); // Negative standard deviation
                                                                                                                                                                              }

 @Test
                                                                                                                                                                      public void testCumulativeProbability_TypicalValues() throws MathException {
                                                                                                                                                                          NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0); // Standard normal distribution
                                                                                                                                                                          
                                                                                                                                                                          // Test values around the mean
                                                                                                                                                                          assertEquals(0.5, dist.cumulativeProbability(0.0), 1e-6);
                                                                                                                                                                          
                                                                                                                                                                          // Test positive values
                                                                                                                                                                          assertEquals(0.8413, dist.cumulativeProbability(1.0), 1e-4);
                                                                                                                                                                          assertEquals(0.9772, dist.cumulativeProbability(2.0), 1e-4);
                                                                                                                                                                          
                                                                                                                                                                          // Test negative values
                                                                                                                                                                          assertEquals(0.1587, dist.cumulativeProbability(-1.0), 1e-4);
                                                                                                                                                                          assertEquals(0.0228, dist.cumulativeProbability(-2.0), 1e-4);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testCumulativeProbability_ExtremeValues() throws MathException {
                                                                                                                                                                          NormalDistributionImpl dist = new NormalDistributionImpl(100.0, 5.0);
                                                                                                                                                                          
                                                                                                                                                                          // Test extremely low value (more than 20 SDs below mean)
                                                                                                                                                                          assertEquals(0.0, dist.cumulativeProbability(-10.0), 1e-6);
                                                                                                                                                                          
                                                                                                                                                                          // Test extremely high value (more than 20 SDs above mean)
                                                                                                                                                                          assertEquals(1.0, dist.cumulativeProbability(210.0), 1e-6);
                                                                                                                                                                          
                                                                                                                                                                          // Test just below the 20 SD threshold (should not return 0 or 1)
                                                                                                                                                                          NormalDistributionImpl dist2 = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                          double result = dist2.cumulativeProbability(-19.9);
                                                                                                                                                                          assertTrue(result > 0.0 && result < 1.0);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testCumulativeProbability_NonStandardDistribution() throws MathException {
                                                                                                                                                                          NormalDistributionImpl dist = new NormalDistributionImpl(50.0, 10.0);
                                                                                                                                                                          
                                                                                                                                                                          assertEquals(0.6915, dist.cumulativeProbability(55.0), 1e-4);
                                                                                                                                                                          assertEquals(0.3085, dist.cumulativeProbability(45.0), 1e-4);
                                                                                                                                                                          assertEquals(0.5, dist.cumulativeProbability(50.0), 1e-6);
                                                                                                                                                                      }

 @Test(expected = MaxIterationsExceededException.class)
                                                                                                                                                                      public void testCumulativeProbability_MaxIterationsExceededInMiddleRange() throws MathException {
                                                                                                                                                                          NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0) {
                                                                                                                                                                              @Override
                                                                                                                                                                              public double cumulativeProbability(double x) throws MaxIterationsExceededException {
                                                                                                                                                                                  throw new MaxIterationsExceededException(100);
                                                                                                                                                                              }
                                                                                                                                                                          };
                                                                                                                                                                          
                                                                                                                                                                          dist.cumulativeProbability(0.5); // Value within reasonable range
                                                                                                                                                                      }

 @Test
                                                                                                                                                                      public void testSetStandardDeviation_ZeroValue_ThrowsExceptionWithCorrectMessage() {
                                                                                                                                                                          NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                          
                                                                                                                                                                          // Expect exception
                                                                                                                                                                          thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                          thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                          
                                                                                                                                                                          // Trigger the exception
                                                                                                                                                                          distribution.setStandardDeviation(0.0);
                                                                                                                                                                      }

 @Test
                                                                                                                                                                     public void testSetStandardDeviation_NonPositiveValue_ThrowsExceptionWithCorrectMessage() {
                                                                                                                                                                         // Arrange
                                                                                                                                                                         NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                         double invalidSd = 0.0; // non-positive value
                                                                                                                                                                         
                                                                                                                                                                         // Set expectation for the exception
                                                                                                                                                                         thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                         thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                         
                                                                                                                                                                         // Act
                                                                                                                                                                         distribution.setStandardDeviation(invalidSd);
                                                                                                                                                                     }

 @Test
                                                                                                                                                                     public void testSetStandardDeviation_NegativeValue_ThrowsExceptionWithCorrectMessage() {
                                                                                                                                                                         // Arrange
                                                                                                                                                                         NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                         double invalidSd = -1.0; // negative value
                                                                                                                                                                         
                                                                                                                                                                         // Set expectation for the exception
                                                                                                                                                                         thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                         thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                         
                                                                                                                                                                         // Act
                                                                                                                                                                         distribution.setStandardDeviation(invalidSd);
                                                                                                                                                                     }

 @Test
                                                                                                                                                                     public void testSetStandardDeviation_PositiveValue_SetsCorrectly() {
                                                                                                                                                                         // Arrange
                                                                                                                                                                         NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                         double validSd = 1.5; // positive value
                                                                                                                                                                         
                                                                                                                                                                         // Act
                                                                                                                                                                         distribution.setStandardDeviation(validSd);
                                                                                                                                                                         
                                                                                                                                                                         // Assert
                                                                                                                                                                         assertEquals(validSd, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                     }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                    public void testSetStandardDeviation_NonPositive() {
                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                        dist.setStandardDeviation(0.0); // should throw
                                                                                                                                                                    }

 @Test
                                                                                                                                                                    public void testSetStandardDeviation_NegativeValue() {
                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                        try {
                                                                                                                                                                            dist.setStandardDeviation(-1.5);
                                                                                                                                                                            fail("Should have thrown IllegalArgumentException");
                                                                                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                                                                                            // Expected for negative value
                                                                                                                                                                        }
                                                                                                                                                                    }

 @Test
                                                                                                                                                                    public void testSetStandardDeviation_PositiveValue() {
                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                        double testValue = 2.5;
                                                                                                                                                                        dist.setStandardDeviation(testValue);
                                                                                                                                                                        assertEquals(testValue, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                    }

 @Test
                                                                                                                                                                    public void testSetStandardDeviation_DetectMutant() {
                                                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                        double negativeValue = -3.7;
                                                                                                                                                                        
                                                                                                                                                                        // This should throw in original, but mutant would accept it
                                                                                                                                                                        try {
                                                                                                                                                                            dist.setStandardDeviation(negativeValue);
                                                                                                                                                                            // If we get here, mutant might have passed validation
                                                                                                                                                                            double storedValue = dist.getStandardDeviation();
                                                                                                                                                                            // Original would never get here, mutant would store positive value
                                                                                                                                                                            assertNotEquals("Mutant detected: Negative value was stored as positive", 
                                                                                                                                                                                          Math.abs(negativeValue), storedValue, 0.0001);
                                                                                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                                                                                            // Expected behavior for original
                                                                                                                                                                        }
                                                                                                                                                                    }

 @Test
                                                                                                                                                                   public void testSetStandardDeviationWithPositiveValue() {
                                                                                                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                       double validSd = 1.5;
                                                                                                                                                                       dist.setStandardDeviation(validSd);
                                                                                                                                                                       assertEquals(validSd, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                   }

 @Test
                                                                                                                                                                   public void testSetStandardDeviationWithVerySmallPositiveValue() {
                                                                                                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                       double smallSd = Double.MIN_VALUE;
                                                                                                                                                                       dist.setStandardDeviation(smallSd);
                                                                                                                                                                       assertEquals(smallSd, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                   }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                   public void testSetStandardDeviationWithZero() {
                                                                                                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                       dist.setStandardDeviation(0.0);
                                                                                                                                                                   }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                   public void testSetStandardDeviationWithNegativeValue() {
                                                                                                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                       dist.setStandardDeviation(-1.0);
                                                                                                                                                                   }

 @Test(expected = RuntimeException.class)
                                                                                                                                                                   public void testExceptionHandlingBehavior() {
                                                                                                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl() {
                                                                                                                                                                           @Override
                                                                                                                                                                           public void setStandardDeviation(double sd) {
                                                                                                                                                                               // First do the original validation
                                                                                                                                                                               if (sd <= 0.0) {
                                                                                                                                                                                   throw new IllegalArgumentException(
                                                                                                                                                                                       "Standard deviation must be positive.");
                                                                                                                                                                               }
                                                                                                                                                                               // Then throw a different exception to test handling
                                                                                                                                                                               throw new RuntimeException("Test exception");
                                                                                                                                                                           }
                                                                                                                                                                       };
                                                                                                                                                                       
                                                                                                                                                                       dist.setStandardDeviation(1.0); // This should throw RuntimeException
                                                                                                                                                                   }

 @Test
                                                                                                                                                             public void testCumulativeProbabilityAtLowerBoundary() throws MathException {
                                                                                                                                                                 // Setup
                                                                                                                                                                 double mean = 10.0;
                                                                                                                                                                 double sd = 1.0;
                                                                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                 
                                                                                                                                                                 // Calculate the exact boundary value
                                                                                                                                                                 double boundaryValue = mean - 20 * sd;
                                                                                                                                                                 
                                                                                                                                                                 // Test the boundary value
                                                                                                                                                                 double probability = dist.cumulativeProbability(boundaryValue);
                                                                                                                                                                 
                                                                                                                                                                 // The original should return a very small probability (near 0)
                                                                                                                                                                 // The mutant would potentially return a different value
                                                                                                                                                                 assertTrue("Probability at boundary should be very small", 
                                                                                                                                                                            probability < 1e-20);
                                                                                                                                                                 
                                                                                                                                                                 // Also test a value just below the boundary
                                                                                                                                                                 double justBelow = boundaryValue - 1e-10;
                                                                                                                                                                 double probBelow = dist.cumulativeProbability(justBelow);
                                                                                                                                                                 assertTrue(probBelow < 1e-20);
                                                                                                                                                                 
                                                                                                                                                                 // And test a value just above the boundary
                                                                                                                                                                 double justAbove = boundaryValue + 1e-10;
                                                                                                                                                                 double probAbove = dist.cumulativeProbability(justAbove);
                                                                                                                                                                 assertTrue(probAbove > probBelow);
                                                                                                                                                             }

 @Test
                                                                                                                                                        public void testCumulativeProbabilityForExtremeLowValues() throws org.apache.commons.math.MathException {
                                                                                                                                                            // Setup
                                                                                                                                                            double mean = 100.0;
                                                                                                                                                            double sd = 5.0;
                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                                            
                                                                                                                                                            // Test value between mean-20σ and mean-10σ
                                                                                                                                                            double x = mean - 15 * sd; // 100 - 15*5 = 25
                                                                                                                                                            
                                                                                                                                                            // Original should return small but positive probability
                                                                                                                                                            // Mutant would return 0
                                                                                                                                                            double probability = dist.cumulativeProbability(x);
                                                                                                                                                            
                                                                                                                                                            // Assert
                                                                                                                                                            assertTrue("Probability should be greater than 0 for x = mean - 15σ", 
                                                                                                                                                                      probability > 0);
                                                                                                                                                            
                                                                                                                                                            // Additional check to verify it's a very small probability
                                                                                                                                                            assertTrue("Probability should be very small", 
                                                                                                                                                                      probability < 1e-10);
                                                                                                                                                        }

 @Test
                                                                                                                                                   public void testCumulativeProbabilityBoundaryCondition() throws MathException {
                                                                                                                                                       // Setup
                                                                                                                                                       double mean = 0.0;
                                                                                                                                                       double sd = 1.0;
                                                                                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                                       
                                                                                                                                                       // Test point that's 19.9σ below mean (should be in extreme left tail)
                                                                                                                                                       double x1 = mean - 19.9 * sd;
                                                                                                                                                       double prob1 = dist.cumulativeProbability(x1);
                                                                                                                                                       assertTrue("Probability should be very small for x 19.9σ below mean", prob1 < 0.0001);
                                                                                                                                                       
                                                                                                                                                       // Test point that's 19.9σ above mean (should be close to 1)
                                                                                                                                                       double x2 = mean + 19.9 * sd;
                                                                                                                                                       double prob2 = dist.cumulativeProbability(x2);
                                                                                                                                                       assertTrue("Probability should be very close to 1 for x 19.9σ above mean", prob2 > 0.9999);
                                                                                                                                                       
                                                                                                                                                       // Test point that's 20.1σ below mean (should be 0)
                                                                                                                                                       double x3 = mean - 20.1 * sd;
                                                                                                                                                       double prob3 = dist.cumulativeProbability(x3);
                                                                                                                                                       assertEquals("Probability should be 0 for x 20.1σ below mean", 0.0, prob3, 0.0);
                                                                                                                                                       
                                                                                                                                                       // Test point that's 20.1σ above mean (should be 1)
                                                                                                                                                       double x4 = mean + 20.1 * sd;
                                                                                                                                                       double prob4 = dist.cumulativeProbability(x4);
                                                                                                                                                       assertEquals("Probability should be 1 for x 20.1σ above mean", 1.0, prob4, 0.0);
                                                                                                                                                       
                                                                                                                                                       // Critical test - point that's 19.9σ below mean vs mutant behavior
                                                                                                                                                       // Original would treat this as extreme left tail, mutant would treat it normally
                                                                                                                                                       double x5 = mean - 19.9 * sd;
                                                                                                                                                       double prob5 = dist.cumulativeProbability(x5);
                                                                                                                                                       // This would fail if mutant is present since mutant would treat x5 as normal case
                                                                                                                                                       assertTrue("Probability should be very small for x 19.9σ below mean", prob5 < 0.0001);
                                                                                                                                                   }

 @Test
                                                                                                                                              public void testCumulativeProbabilityDoesNotAlwaysTakeTrueBranch() throws MathException {
                                                                                                                                                  // Setup - create distribution with mean 0 and sd 1
                                                                                                                                                  NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                  
                                                                                                                                                  // Test value that should NOT trigger the original condition (x > mean - 20*sd)
                                                                                                                                                  // For mean=0, sd=1, condition would be x < -20
                                                                                                                                                  double x = -10.0; // Within 10 standard deviations
                                                                                                                                                  
                                                                                                                                                  // Call the method - if mutant is present, it will take the true branch
                                                                                                                                                  // even though it shouldn't for this x value
                                                                                                                                                  double result = dist.cumulativeProbability(x);
                                                                                                                                                  
                                                                                                                                                  // Verify the result is not what we'd get if the condition was always true
                                                                                                                                                  // The exact expected value would depend on the implementation,
                                                                                                                                                  // but we know it shouldn't be 0.0 (which might be the case if true branch taken)
                                                                                                                                                  assertNotEquals(0.0, result, 0.0001);
                                                                                                                                                  
                                                                                                                                                  // Also test a value that should trigger the condition
                                                                                                                                                  double extremeX = -25.0; // Beyond 20 standard deviations
                                                                                                                                                  double extremeResult = dist.cumulativeProbability(extremeX);
                                                                                                                                                  // This should be very close to 0 (or whatever the true branch returns)
                                                                                                                                                  assertEquals(0.0, extremeResult, 0.0001);
                                                                                                                                              }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                              public void testSetStandardDeviation_ZeroValueShouldThrowException() {
                                                                                                                                                  NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                  distribution.setStandardDeviation(0.0);
                                                                                                                                                  // If mutant exists, this line will be reached and test will fail
                                                                                                                                              }

 @Test
                                                                                                                                              public void testSetStandardDeviation_PositiveValueShouldSetField() {
                                                                                                                                                  NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                  double testValue = 1.5;
                                                                                                                                                  distribution.setStandardDeviation(testValue);
                                                                                                                                                  assertEquals(testValue, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                              }

 @Test
                                                                                                                                              public void testSetStandardDeviation_NegativeValueShouldThrowException() {
                                                                                                                                                  try {
                                                                                                                                                      NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                      distribution.setStandardDeviation(-1.0);
                                                                                                                                                      fail("Expected IllegalArgumentException for negative value");
                                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                                      assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                  }
                                                                                                                                              }

 @Test
                                                                                                                                             public void testSetStandardDeviation_AcceptsSmallPositiveValue() {
                                                                                                                                                 // Test that values between 0.0 and 0.5 are accepted
                                                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                 
                                                                                                                                                 // This value should be accepted by original but rejected by mutant
                                                                                                                                                 double smallPositiveValue = 0.1;
                                                                                                                                                 
                                                                                                                                                 try {
                                                                                                                                                     dist.setStandardDeviation(smallPositiveValue);
                                                                                                                                                     // If we get here, no exception was thrown (original behavior)
                                                                                                                                                     assertEquals(smallPositiveValue, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                                                                     // If mutant is present, we'll get here
                                                                                                                                                     fail("Original should accept 0.1 but mutant rejects it");
                                                                                                                                                 }
                                                                                                                                             }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                             public void testSetStandardDeviation_RejectsZero() {
                                                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                 dist.setStandardDeviation(0.0);
                                                                                                                                             }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                             public void testSetStandardDeviation_RejectsNegative() {
                                                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                 dist.setStandardDeviation(-1.0);
                                                                                                                                             }

 @Test
                                                                                                                                             public void testSetStandardDeviation_AcceptsNormalPositiveValue() {
                                                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                 double validValue = 1.0;
                                                                                                                                                 dist.setStandardDeviation(validValue);
                                                                                                                                                 assertEquals(validValue, dist.getStandardDeviation(), 0.0001);
                                                                                                                                             }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                            public void testSetStandardDeviation_ShouldRejectNegativeValues() {
                                                                                                                                                // This test will fail on the mutant because it allows -0.5
                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                dist.setStandardDeviation(-0.5); // Should throw exception
                                                                                                                                            }

 @Test
                                                                                                                                            public void testSetStandardDeviation_ShouldAcceptPositiveValues() {
                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                dist.setStandardDeviation(1.5);
                                                                                                                                                assertEquals(1.5, dist.getStandardDeviation(), 0.0001);
                                                                                                                                            }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                            public void testSetStandardDeviation_ShouldRejectZero() {
                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                dist.setStandardDeviation(0.0); // Should throw exception
                                                                                                                                            }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                            public void testSetStandardDeviation_ShouldRejectLargeNegativeValues() {
                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                dist.setStandardDeviation(-1.5); // Should throw exception
                                                                                                                                            }

 @Test
                                                                                                                                           public void testSetStandardDeviationWithPositiveValue1() {
                                                                                                                                               NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                               dist.setStandardDeviation(5.0);
                                                                                                                                               assertEquals(5.0, dist.getStandardDeviation(), 0.0);
                                                                                                                                           }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                           public void testSetStandardDeviationWithZero1() {
                                                                                                                                               NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                               dist.setStandardDeviation(0.0);
                                                                                                                                           }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                           public void testSetStandardDeviationWithNegative() {
                                                                                                                                               NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                               dist.setStandardDeviation(-1.0);
                                                                                                                                           }

 @Test
                                                                                                                                      public void testCumulativeProbabilityAtUpperBoundary() throws org.apache.commons.math.MathException {
                                                                                                                                          // Setup test with known values
                                                                                                                                          double mean = 10.0;
                                                                                                                                          double sd = 2.0;
                                                                                                                                          NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                          
                                                                                                                                          // Calculate the exact boundary value
                                                                                                                                          double boundaryValue = mean + 20 * sd;
                                                                                                                                          
                                                                                                                                          // Call the method with the exact boundary value
                                                                                                                                          double result = dist.cumulativeProbability(boundaryValue);
                                                                                                                                          
                                                                                                                                          // Verify the result - should be very close to 1.0 but not exactly 1.0
                                                                                                                                          // The mutant would return exactly 1.0 at this boundary
                                                                                                                                          assertTrue("Result should be very close to but not exactly 1.0 at boundary", 
                                                                                                                                                     result < 1.0);
                                                                                                                                          assertEquals(1.0, result, 1e-10); // Allowing very small difference
                                                                                                                                      }

 @Test
                                                                                                                                 public void testCumulativeProbabilityForExtremeValues() throws Exception {
                                                                                                                                     // Setup: create distribution with mean=0, sd=1
                                                                                                                                     NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                     
                                                                                                                                     // Test value at 15 standard deviations from mean
                                                                                                                                     // This is between 10-20σ, so should detect the mutant
                                                                                                                                     double x = 15.0;
                                                                                                                                     
                                                                                                                                     // Calculate probability
                                                                                                                                     double prob = dist.cumulativeProbability(x);
                                                                                                                                     
                                                                                                                                     // In original, 15σ should be considered within bounds and return ~1
                                                                                                                                     // In mutant, it would be considered extreme and might return different value
                                                                                                                                     // We use a very small delta due to floating point precision
                                                                                                                                     assertEquals(1.0, prob, 1e-10);
                                                                                                                                     
                                                                                                                                     // Additional assertion to ensure it's not just returning 1 for any input
                                                                                                                                     // Test a value within a few standard deviations
                                                                                                                                     double probMid = dist.cumulativeProbability(2.0);
                                                                                                                                     assertTrue(probMid > 0.9 && probMid < 1.0);
                                                                                                                                 }

 @Test
                                                                                                                            public void testCumulativeProbabilityForLargeX() throws MathException {
                                                                                                                                // Setup
                                                                                                                                double mean = 0.0;
                                                                                                                                double sd = 1.0;
                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                                                
                                                                                                                                // Test value that is > mean + 20*sd (20 standard deviations above mean)
                                                                                                                                double extremeValue = mean + 21 * sd;
                                                                                                                                
                                                                                                                                // In original code, this should return a value very close to 1.0 (practically 1.0)
                                                                                                                                // In mutated code, it would follow different logic since 21 > (0 - 20*1) = -20
                                                                                                                                double probability = distribution.cumulativeProbability(extremeValue);
                                                                                                                                
                                                                                                                                // Assert that the probability is effectively 1.0 for such extreme values
                                                                                                                                assertEquals(1.0, probability, 1e-10);
                                                                                                                                
                                                                                                                                // Also test a value between mean-20*sd and mean+20*sd
                                                                                                                                double moderateValue = mean + 15 * sd;
                                                                                                                                double moderateProbability = distribution.cumulativeProbability(moderateValue);
                                                                                                                                
                                                                                                                                // This should be very close to 1.0 but not exactly 1.0
                                                                                                                                assertTrue(moderateProbability < 1.0);
                                                                                                                                assertTrue(moderateProbability > 0.999999);
                                                                                                                            }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                            public void testSetStandardDeviation_ZeroValueShouldThrowException1() {
                                                                                                                                // Arrange
                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                
                                                                                                                                // Act - should throw exception for 0.0 input
                                                                                                                                distribution.setStandardDeviation(0.0);
                                                                                                                                
                                                                                                                                // Assert - exception expected
                                                                                                                            }

 @Test
                                                                                                                            public void testSetStandardDeviation_PositiveValueShouldBeSet() {
                                                                                                                                // Arrange
                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                double validSd = 1.5;
                                                                                                                                
                                                                                                                                // Act
                                                                                                                                distribution.setStandardDeviation(validSd);
                                                                                                                                
                                                                                                                                // Assert
                                                                                                                                assertEquals(validSd, distribution.getStandardDeviation(), 0.0001);
                                                                                                                            }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                            public void testSetStandardDeviation_NegativeValueShouldThrowException1() {
                                                                                                                                // Arrange
                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                
                                                                                                                                // Act - should throw exception for negative input
                                                                                                                                distribution.setStandardDeviation(-0.1);
                                                                                                                                
                                                                                                                                // Assert - exception expected
                                                                                                                            }

 @Test
                                                                                                                           public void testSetStandardDeviationWithSmallPositiveValue() {
                                                                                                                               // Test with a value between 0.0 and 0.5 that should be accepted by original
                                                                                                                               // but rejected by the mutant (0.25)
                                                                                                                               NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                               
                                                                                                                               try {
                                                                                                                                   distribution.setStandardDeviation(0.25);
                                                                                                                                   // If we get here, original behavior is working
                                                                                                                                   assertEquals(0.25, distribution.getStandardDeviation(), 0.0001);
                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                   // If we get here, mutant behavior is detected
                                                                                                                                   fail("Mutant detected: 0.25 should be accepted but was rejected");
                                                                                                                               }
                                                                                                                           }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                           public void testSetStandardDeviationWithZeroShouldThrow() {
                                                                                                                               NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                               distribution.setStandardDeviation(0.0);
                                                                                                                           }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                           public void testSetStandardDeviationWithNegativeShouldThrow() {
                                                                                                                               NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                               distribution.setStandardDeviation(-1.0);
                                                                                                                           }

 @Test
                                                                                                                           public void testSetStandardDeviationWithValidValue() {
                                                                                                                               NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                               distribution.setStandardDeviation(1.0);
                                                                                                                               assertEquals(1.0, distribution.getStandardDeviation(), 0.0001);
                                                                                                                           }

 @Test
                                                                                                                          public void testSetStandardDeviation_ShouldRejectValuesBetweenZeroAndTwo() {
                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                              
                                                                                                                              // Test value between 0 and 2 (should throw exception in original)
                                                                                                                              try {
                                                                                                                                  dist.setStandardDeviation(1.5);
                                                                                                                                  fail("Expected IllegalArgumentException for sd = 1.5");
                                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                                  assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Test boundary at 0
                                                                                                                              try {
                                                                                                                                  dist.setStandardDeviation(0.0);
                                                                                                                                  fail("Expected IllegalArgumentException for sd = 0.0");
                                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                                  assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Test negative value
                                                                                                                              try {
                                                                                                                                  dist.setStandardDeviation(-1.0);
                                                                                                                                  fail("Expected IllegalArgumentException for sd = -1.0");
                                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                                  assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Test valid positive value
                                                                                                                              dist.setStandardDeviation(2.1);
                                                                                                                              assertEquals(2.1, dist.getStandardDeviation(), 0.0001);
                                                                                                                          }

 @Test
                                                                                                                         public void testSetStandardDeviation_NonPositiveValue_ThrowsIllegalArgumentException() {
                                                                                                                             NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                             
                                                                                                                             // Expect IllegalArgumentException for zero value
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                             distribution.setStandardDeviation(0.0);
                                                                                                                         }

 @Test
                                                                                                                         public void testSetStandardDeviation_NegativeValue_ThrowsIllegalArgumentException() {
                                                                                                                             NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                             
                                                                                                                             // Expect IllegalArgumentException for negative value
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                             distribution.setStandardDeviation(-1.0);
                                                                                                                         }

 @Test
                                                                                                                         public void testSetStandardDeviation_PositiveValue_SetsCorrectly1() {
                                                                                                                             NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                             double validSd = 1.5;
                                                                                                                             
                                                                                                                             distribution.setStandardDeviation(validSd);
                                                                                                                             
                                                                                                                             assertEquals(validSd, distribution.getStandardDeviation(), 0.0001);
                                                                                                                         }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                        public void testSetStandardDeviation_NonPositiveValue_ShouldThrowException() {
                                                                                                                            // Arrange
                                                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                            double originalSd = distribution.getStandardDeviation();
                                                                                                                            double invalidSd = -1.0; // Non-positive value
                                                                                                                            
                                                                                                                            // Act
                                                                                                                            try {
                                                                                                                                distribution.setStandardDeviation(invalidSd);
                                                                                                                                
                                                                                                                                // If we get here, the mutant survived (no exception thrown)
                                                                                                                                // Verify the field wasn't changed to 0.5 (mutant behavior)
                                                                                                                                double newSd = distribution.getStandardDeviation();
                                                                                                                                assertNotEquals("Mutant detected: Method returned instead of throwing exception", 
                                                                                                                                               0.5, newSd, 0.0001);
                                                                                                                                assertEquals("Standard deviation should remain unchanged", 
                                                                                                                                            originalSd, newSd, 0.0001);
                                                                                                                                
                                                                                                                                // Force test to fail since we expected an exception
                                                                                                                                fail("Expected IllegalArgumentException but none was thrown");
                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                // Verify exception message
                                                                                                                                assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                
                                                                                                                                // Verify standard deviation wasn't changed
                                                                                                                                assertEquals(originalSd, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                
                                                                                                                                // Re-throw to satisfy @Test(expected)
                                                                                                                                throw e;
                                                                                                                            }
                                                                                                                        }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                  public void testSetStandardDeviation_ThrowsExceptionForNegativeValue() {
                                                                                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                      normalDistribution.setStandardDeviation(-1.0);
                                                                                                                  }

 @Test
                                                                                                                  public void testSetStandardDeviation_DetectsAbsMutation() {
                                                                                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                      try {
                                                                                                                          normalDistribution.setStandardDeviation(-2.5);
                                                                                                                          // If we get here, the exception wasn't thrown (mutated behavior)
                                                                                                                          assertEquals("Mutated version stores absolute value", 
                                                                                                                                       2.5, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                          // Fail the test since we should have gotten an exception
                                                                                                                          fail("Expected IllegalArgumentException for negative standard deviation");
                                                                                                                      } catch (IllegalArgumentException e) {
                                                                                                                          // This is expected behavior for original code
                                                                                                                          assertTrue("Original behavior throws exception", true);
                                                                                                                      }
                                                                                                                  }

 @Test
                                                                                                                  public void testSetStandardDeviation_PositiveValue1() {
                                                                                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                      normalDistribution.setStandardDeviation(3.0);
                                                                                                                      assertEquals(3.0, normalDistribution.getStandardDeviation(), 0.0001);
                                                                                                                  }

 @Test
                                                                                                                  public void testSetStandardDeviation_ZeroValue() {
                                                                                                                      NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                                                                      normalDistribution.setStandardDeviation(0.0);
                                                                                                                  }

 @Test
                                                                                                             public void testCumulativeProbabilityWithStandardDeviation() throws MathException {
                                                                                                                 // Create distribution with mean=0 and sd=1 (standard normal)
                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                 
                                                                                                                 // Test a known value where we can calculate the expected result
                                                                                                                 // For standard normal distribution, P(X <= 1) ≈ 0.8413
                                                                                                                 double x = 1.0;
                                                                                                                 double expected = 0.8413447460685429; // pre-calculated value
                                                                                                                 
                                                                                                                 // The mutant would produce a different result because it uses sqrt(1.0) instead of sqrt(2.0)
                                                                                                                 // in internal calculations
                                                                                                                 double actual = dist.cumulativeProbability(x);
                                                                                                                 
                                                                                                                 // Assert with delta for floating point precision
                                                                                                                 assertEquals("Cumulative probability calculation is incorrect", 
                                                                                                                             expected, actual, 1e-10);
                                                                                                                 
                                                                                                                 // Additional test with different standard deviation
                                                                                                                 dist.setStandardDeviation(2.0);
                                                                                                                 x = 2.0;
                                                                                                                 expected = 0.8413447460685429; // same probability but at 2σ for sd=2
                                                                                                                 actual = dist.cumulativeProbability(x);
                                                                                                                 assertEquals("Cumulative probability with different sd is incorrect",
                                                                                                                             expected, actual, 1e-10);
                                                                                                             }

 @Test(expected = IllegalArgumentException.class)
                                                                                                             public void testSetStandardDeviation_NonPositiveValue() {
                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                 dist.setStandardDeviation(0.0); // Should throw IllegalArgumentException
                                                                                                             }

 @Test
                                                                                                             public void testSetStandardDeviation_PositiveValue2() {
                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                 dist.setStandardDeviation(1.5);
                                                                                                                 assertEquals(1.5, dist.getStandardDeviation(), 0.0001);
                                                                                                             }

 @Test
                                                                                                             public void testSetStandardDeviation_ExceptionHandling() {
                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl() {
                                                                                                                     @Override
                                                                                                                     public double getStandardDeviation() {
                                                                                                                         throw new RuntimeException("Test exception");
                                                                                                                     }
                                                                                                                 };
                                                                                                                 
                                                                                                                 try {
                                                                                                                     dist.setStandardDeviation(1.0);
                                                                                                                     fail("Expected RuntimeException to be thrown");
                                                                                                                 } catch (RuntimeException e) {
                                                                                                                     assertEquals("Test exception", e.getMessage());
                                                                                                                 }
                                                                                                             }

 @Test
                                                                                                       public void testCumulativeProbabilityAtLowerBoundary1() throws MathException {
                                                                                                           // Setup
                                                                                                           double mean = 10.0;
                                                                                                           double sd = 1.0;
                                                                                                           NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                           
                                                                                                           // Calculate the exact boundary value
                                                                                                           double boundaryValue = mean - 20 * sd;
                                                                                                           
                                                                                                           // Test the boundary value
                                                                                                           double result = distribution.cumulativeProbability(boundaryValue);
                                                                                                           
                                                                                                           // The original code would treat this as outside the lower bound (should be 0)
                                                                                                           // The mutant would include this value in calculation (result > 0)
                                                                                                           assertEquals("Value exactly at lower boundary should return 0", 
                                                                                                                       0.0, result, 0.000001);
                                                                                                       }

 @Test
                                                                                                  public void testCumulativeProbabilityForExtremeValues1() throws MathException {
                                                                                                      // Setup
                                                                                                      double mean = 100.0;
                                                                                                      double sd = 5.0;
                                                                                                      NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                      
                                                                                                      // Test value between 10σ and 20σ below mean (x = mean - 15σ)
                                                                                                      double x = mean - 15 * sd; // 100 - 15*5 = 25
                                                                                                      
                                                                                                      // Calculate cumulative probability
                                                                                                      double probability = distribution.cumulativeProbability(x);
                                                                                                      
                                                                                                      // Verify the probability is very small but not treated as outlier
                                                                                                      // Original would calculate probability for 15σ, mutant would treat as outlier
                                                                                                      assertTrue("Probability should be very small but not zero", 
                                                                                                                 probability > 0 && probability < 1E-20);
                                                                                                      
                                                                                                      // Additional test case exactly at 10σ boundary
                                                                                                      x = mean - 10 * sd; // 100 - 10*5 = 50
                                                                                                      probability = distribution.cumulativeProbability(x);
                                                                                                      assertTrue("Probability at 10σ boundary should be calculated", 
                                                                                                                 probability > 0);
                                                                                                  }

 @Test
                                                                                             public void testCumulativeProbabilityForExtremeLowValues1() {
                                                                                                 // Setup normal distribution with mean=0, sd=1
                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                 
                                                                                                 // Test value 21 SDs below mean (should be detected as extreme in original)
                                                                                                 double extremeLowValue = 0.0 - 21.0 * 1.0;
                                                                                                 
                                                                                                 try {
                                                                                                     // Original would treat this as extreme low (returning very small probability)
                                                                                                     // Mutant would calculate normally (incorrectly)
                                                                                                     double probability = dist.cumulativeProbability(extremeLowValue);
                                                                                                     
                                                                                                     // Verify probability is very small (original behavior)
                                                                                                     // The exact value isn't important, just that it's extremely small
                                                                                                     assertTrue("Probability for extreme low value should be very small", 
                                                                                                               probability < 1e-100);
                                                                                                     
                                                                                                     // Additional test with value just below 20 SDs
                                                                                                     double borderlineValue = 0.0 - 20.1 * 1.0;
                                                                                                     double borderlineProb = dist.cumulativeProbability(borderlineValue);
                                                                                                     assertTrue("Probability just below 20 SDs should be very small",
                                                                                                               borderlineProb < 1e-100);
                                                                                                 } catch (MathException e) {
                                                                                                     fail("Unexpected MathException: " + e.getMessage());
                                                                                                 }
                                                                                             }

 @Test
                                                                                             public void testCumulativeProbabilityForExtremeHighValues() throws MathException {
                                                                                                 // Setup normal distribution with mean=0, sd=1
                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                 
                                                                                                 // Test value 21 SDs above mean (should be detected as extreme high)
                                                                                                 double extremeHighValue = 0.0 + 21.0 * 1.0;
                                                                                                 double probability = dist.cumulativeProbability(extremeHighValue);
                                                                                                 
                                                                                                 // Verify probability is very close to 1
                                                                                                 assertEquals("Probability for extreme high value should be ~1.0", 
                                                                                                             1.0, probability, 1e-10);
                                                                                             }

 @Test
                                                                                        public void testCumulativeProbabilityDoesNotAlwaysTakeTrueBranch1() throws MathException {
                                                                                            // Setup normal distribution with mean=0, sd=1
                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                            
                                                                                            // Test value that is within 20 standard deviations from mean
                                                                                            double x = -19.0; // Should not trigger the original condition
                                                                                            
                                                                                            // Calculate probability
                                                                                            double probability = dist.cumulativeProbability(x);
                                                                                            
                                                                                            // Verify the result is not 0.0 (which would be returned if true branch taken)
                                                                                            // For standard normal distribution, P(X < -19) is very small but not exactly 0
                                                                                            assertNotEquals("Mutant detected: always taking true branch returns incorrect probability", 
                                                                                                            0.0, probability, 0.0000001);
                                                                                            
                                                                                            // Also verify the probability is very small but positive
                                                                                            assertTrue("Probability should be positive", probability > 0.0);
                                                                                        }

 @Test
                                                                                        public void testSetStandardDeviation_ZeroValue1() {
                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                            
                                                                                            try {
                                                                                                distribution.setStandardDeviation(0.0);
                                                                                                fail("Expected IllegalArgumentException for zero standard deviation");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                            }
                                                                                            
                                                                                            // Verify standard deviation wasn't set
                                                                                            assertNotEquals(0.0, distribution.getStandardDeviation(), 0.0001);
                                                                                        }

 @Test
                                                                                        public void testSetStandardDeviation_NegativeValue1() {
                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                            
                                                                                            try {
                                                                                                distribution.setStandardDeviation(-1.0);
                                                                                                fail("Expected IllegalArgumentException for negative standard deviation");
                                                                                            } catch (IllegalArgumentException e) {
                                                                                                assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                            }
                                                                                        }

 @Test
                                                                                        public void testSetStandardDeviation_PositiveValue3() {
                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                            
                                                                                            distribution.setStandardDeviation(2.5);
                                                                                            assertEquals(2.5, distribution.getStandardDeviation(), 0.0001);
                                                                                        }

 @Test
                                                                                       public void testSetStandardDeviationBoundaryCondition() {
                                                                                           NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                           
                                                                                           // Test value that should be accepted by original but rejected by mutant
                                                                                           try {
                                                                                               dist.setStandardDeviation(0.25);
                                                                                               // If we get here, original behavior is working
                                                                                               assertEquals(0.25, dist.getStandardDeviation(), 0.0001);
                                                                                           } catch (IllegalArgumentException e) {
                                                                                               fail("Original should accept 0.25 but mutant rejects it");
                                                                                           }
                                                                                           
                                                                                           // Test value that should be rejected by both
                                                                                           try {
                                                                                               dist.setStandardDeviation(0.0);
                                                                                               fail("Both original and mutant should reject 0.0");
                                                                                           } catch (IllegalArgumentException e) {
                                                                                               // Expected for both
                                                                                           }
                                                                                           
                                                                                           // Test value that should be accepted by both
                                                                                           try {
                                                                                               dist.setStandardDeviation(1.0);
                                                                                               assertEquals(1.0, dist.getStandardDeviation(), 0.0001);
                                                                                           } catch (IllegalArgumentException e) {
                                                                                               fail("Both should accept 1.0");
                                                                                           }
                                                                                       }

 @Test(expected = IllegalArgumentException.class)
                                                                                       public void testSetStandardDeviationNegativeValue() {
                                                                                           NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                           dist.setStandardDeviation(-0.1);
                                                                                       }

 @Test(expected = IllegalArgumentException.class)
                                                                                      public void testSetStandardDeviation_ZeroValue2() {
                                                                                          // This test will catch the mutant because:
                                                                                          // Original: should throw exception for 0.0
                                                                                          // Mutant: will not throw exception for 0.0
                                                                                          NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                          dist.setStandardDeviation(0.0);
                                                                                      }

 @Test
                                                                                      public void testSetStandardDeviation_PositiveValue4() {
                                                                                          NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                          double testValue = 1.5;
                                                                                          dist.setStandardDeviation(testValue);
                                                                                          assertEquals(testValue, dist.getStandardDeviation(), 0.0001);
                                                                                      }

 @Test(expected = IllegalArgumentException.class)
                                                                                      public void testSetStandardDeviation_NegativeValue2() {
                                                                                          NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                          dist.setStandardDeviation(-1.0);
                                                                                      }

 @Test(expected = IllegalArgumentException.class)
                                                                                     public void testSetStandardDeviationWithNonPositiveValue() {
                                                                                         NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                         distribution.setStandardDeviation(0.0); // Should throw exception
                                                                                     }

 @Test
                                                                                     public void testSetStandardDeviationWithPositiveValue2() {
                                                                                         NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                         double testSd = 1.5;
                                                                                         distribution.setStandardDeviation(testSd);
                                                                                         assertEquals(testSd, distribution.getStandardDeviation(), 0.0001);
                                                                                     }

 @Test
                                                                                public void testCumulativeProbabilityAtUpperBoundary1() throws MathException {
                                                                                    // Setup
                                                                                    double mean = 10.0;
                                                                                    double sd = 2.0;
                                                                                    NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                    
                                                                                    // Boundary value where x exactly equals mean + 20*sd
                                                                                    double boundaryX = mean + 20 * sd;
                                                                                    
                                                                                    // Test - this should detect the mutant
                                                                                    // Original would process this x differently than the mutant
                                                                                    double result = distribution.cumulativeProbability(boundaryX);
                                                                                    
                                                                                    // In original, this should be treated as beyond the upper bound
                                                                                    // and return a value very close to 1.0 (but exact value depends on implementation)
                                                                                    // The important part is that it's different from what the mutant would return
                                                                                    assertTrue("Should return value indicating upper tail probability", 
                                                                                              result > 0.999999);
                                                                                }

 @Test(expected = IllegalArgumentException.class)
                                                                                public void testSetStandardDeviationWithNonPositiveValue1() {
                                                                                    NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                    distribution.setStandardDeviation(0.0); // Should throw exception
                                                                                }

 @Test
                                                                                public void testSetStandardDeviationWithValidValue1() {
                                                                                    NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                    distribution.setStandardDeviation(2.5);
                                                                                    assertEquals(2.5, distribution.getStandardDeviation(), 1e-10);
                                                                                }

 @Test
                                                                           public void testCumulativeProbabilityAtHighStandardDeviations() throws MathException {
                                                                               // Setup
                                                                               double mean = 0.0;
                                                                               double sd = 1.0;
                                                                               NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                               
                                                                               // Test value at 15 standard deviations from mean
                                                                               double x = mean + 15 * sd;
                                                                               double probability = distribution.cumulativeProbability(x);
                                                                               
                                                                               // In original version, 15 standard deviations would be treated as extreme right tail
                                                                               // In mutated version (10*SD), it would be treated differently
                                                                               // We expect probability to be very close to 1.0 (practically 1.0 for 15 SDs)
                                                                               assertEquals(1.0, probability, 1e-10);
                                                                               
                                                                               // Additional test at exactly 20 standard deviations
                                                                               x = mean + 20 * sd;
                                                                               probability = distribution.cumulativeProbability(x);
                                                                               assertEquals(1.0, probability, 1e-10);
                                                                               
                                                                               // Test at 10 standard deviations (boundary case for mutant)
                                                                               x = mean + 10 * sd;
                                                                               probability = distribution.cumulativeProbability(x);
                                                                               assertEquals(1.0, probability, 1e-10);
                                                                           }

 @Test
                                                                      public void testCumulativeProbabilityForLargeX1() throws org.apache.commons.math.MathException {
                                                                          // Setup a normal distribution with mean=0 and sd=1
                                                                          NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                          
                                                                          // Test with x value that is more than 20 standard deviations above mean
                                                                          double x = 25.0; // 25 standard deviations above mean
                                                                          
                                                                          // The cumulative probability should be very close to 1.0 for such large x
                                                                          double probability = dist.cumulativeProbability(x);
                                                                          
                                                                          // Assert that the probability is very close to 1.0 (with tolerance for floating point)
                                                                          assertEquals(1.0, probability, 1e-10);
                                                                          
                                                                          // Also test with x value that is more than 20 standard deviations below mean
                                                                          // to ensure the mutant doesn't affect this case
                                                                          x = -25.0;
                                                                          probability = dist.cumulativeProbability(x);
                                                                          assertEquals(0.0, probability, 1e-10);
                                                                      }

 @Test(expected = IllegalArgumentException.class)
                                                                      public void testSetStandardDeviation_ZeroValueShouldThrowException2() {
                                                                          NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                          dist.setStandardDeviation(0.0); // Should throw exception
                                                                      }

 @Test
                                                                      public void testSetStandardDeviation_PositiveValueShouldBeSet1() {
                                                                          NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                          double testValue = 1.5;
                                                                          dist.setStandardDeviation(testValue);
                                                                          assertEquals(testValue, dist.getStandardDeviation(), 0.0001);
                                                                      }

 @Test(expected = IllegalArgumentException.class)
                                                                      public void testSetStandardDeviation_NegativeValueShouldThrowException2() {
                                                                          NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                          dist.setStandardDeviation(-1.0); // Should throw exception
                                                                      }

 @Test
                                                                     public void testSetStandardDeviationWithBoundaryValue() {
                                                                         NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                         
                                                                         // Test with value that should pass (0.6 > 0.5)
                                                                         try {
                                                                             dist.setStandardDeviation(0.6);
                                                                             assertEquals(0.6, dist.getStandardDeviation(), 0.0001);
                                                                         } catch (IllegalArgumentException e) {
                                                                             fail("Should accept values greater than 0.5");
                                                                         }
                                                                         
                                                                         // Test with value that should pass in original but fail in mutant (0.4)
                                                                         try {
                                                                             dist.setStandardDeviation(0.4);
                                                                             // If we get here in original, verify the value was set
                                                                             assertEquals(0.4, dist.getStandardDeviation(), 0.0001);
                                                                         } catch (IllegalArgumentException e) {
                                                                             // This is where the mutant would fail
                                                                             fail("Original should accept 0.4 but mutant rejects it");
                                                                         }
                                                                         
                                                                         // Test with 0.0 (should fail in both)
                                                                         try {
                                                                             dist.setStandardDeviation(0.0);
                                                                             fail("Should throw exception for 0.0");
                                                                         } catch (IllegalArgumentException e) {
                                                                             // Expected in both original and mutant
                                                                             assertTrue(e.getMessage().contains("Standard deviation must be positive"));
                                                                         }
                                                                         
                                                                         // Test with negative value (should fail in both)
                                                                         try {
                                                                             dist.setStandardDeviation(-1.0);
                                                                             fail("Should throw exception for negative values");
                                                                         } catch (IllegalArgumentException e) {
                                                                             // Expected in both original and mutant
                                                                             assertTrue(e.getMessage().contains("Standard deviation must be positive"));
                                                                         }
                                                                     }

 @Test
                                                                    public void testSetStandardDeviationBoundaryConditions() {
                                                                        NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                        
                                                                        // Test valid positive value (original and mutant both accept)
                                                                        dist.setStandardDeviation(1.0);
                                                                        assertEquals(1.0, dist.getStandardDeviation(), 0.0001);
                                                                        
                                                                        // Test zero value (original and mutant both reject)
                                                                        try {
                                                                            dist.setStandardDeviation(0.0);
                                                                            fail("Expected IllegalArgumentException for 0.0");
                                                                        } catch (IllegalArgumentException e) {
                                                                            // expected
                                                                        }
                                                                        
                                                                        // Test negative value (original and mutant both reject)
                                                                        try {
                                                                            dist.setStandardDeviation(-1.0);
                                                                            fail("Expected IllegalArgumentException for -1.0");
                                                                        } catch (IllegalArgumentException e) {
                                                                            // expected
                                                                        }
                                                                        
                                                                        // Test boundary value that exposes the mutant (1.0 < x <= 2.0)
                                                                        // Original should accept, mutant should reject
                                                                        dist.setStandardDeviation(1.5);
                                                                        assertEquals(1.5, dist.getStandardDeviation(), 0.0001);
                                                                        
                                                                        // Test exact mutation boundary (2.0)
                                                                        // Original should accept, mutant should reject
                                                                        dist.setStandardDeviation(2.0);
                                                                        assertEquals(2.0, dist.getStandardDeviation(), 0.0001);
                                                                        
                                                                        // Test value above mutation boundary (> 2.0)
                                                                        // Original should accept, mutant should reject
                                                                        dist.setStandardDeviation(2.1);
                                                                        assertEquals(2.1, dist.getStandardDeviation(), 0.0001);
                                                                    }

 @Test
                                                                   public void testSetStandardDeviation_NonPositiveValue_ThrowsIllegalArgumentException1() {
                                                                       NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                       
                                                                       // Expect IllegalArgumentException to be thrown
                                                                       thrown.expect(IllegalArgumentException.class);
                                                                       thrown.expectMessage("Standard deviation must be positive.");
                                                                       
                                                                       // This should throw IllegalArgumentException (original behavior)
                                                                       // If it throws MathException instead (mutant behavior), the test will fail
                                                                       distribution.setStandardDeviation(0.0);
                                                                   }

 @Test
                                                                   public void testSetStandardDeviation_PositiveValue_SetsCorrectly2() {
                                                                       NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                       double validSd = 1.5;
                                                                       
                                                                       distribution.setStandardDeviation(validSd);
                                                                       
                                                                       assertEquals(validSd, distribution.getStandardDeviation(), 0.0001);
                                                                   }

 @Test
                                                                   public void testSetStandardDeviation_NegativeValue_ThrowsIllegalArgumentException1() {
                                                                       NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                       
                                                                       thrown.expect(IllegalArgumentException.class);
                                                                       thrown.expectMessage("Standard deviation must be positive.");
                                                                       
                                                                       distribution.setStandardDeviation(-0.5);
                                                                   }

 @Test(expected = IllegalArgumentException.class)
                                                                  public void testSetStandardDeviation_NonPositiveValue_ShouldThrowException1() {
                                                                      NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                      dist.setStandardDeviation(0.0);  // Should throw exception
                                                                  }

 @Test
                                                                  public void testSetStandardDeviation_PositiveValue_ShouldSetCorrectly() {
                                                                      NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                      double validSd = 1.5;
                                                                      dist.setStandardDeviation(validSd);
                                                                      assertEquals(validSd, dist.getStandardDeviation(), 0.0001);
                                                                  }

 @Test(expected = IllegalArgumentException.class)
                                                                  public void testSetStandardDeviation_NegativeValue_ShouldThrowException() {
                                                                      NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                      dist.setStandardDeviation(-0.1);  // Should throw exception
                                                                  }

 @Test(expected = IllegalArgumentException.class)
                                                                 public void testSetStandardDeviation_NegativeValueThrowsException() {
                                                                     NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                     dist.setStandardDeviation(-1.0); // Should throw exception
                                                                 }

 @Test
                                                                 public void testSetStandardDeviation_PositiveValueStoredCorrectly() {
                                                                     NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                     double testValue = 2.5;
                                                                     dist.setStandardDeviation(testValue);
                                                                     assertEquals(testValue, dist.getStandardDeviation(), 0.0001);
                                                                 }

 @Test
                                                                 public void testSetStandardDeviation_DetectsAbsMutant() {
                                                                     NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                     try {
                                                                         dist.setStandardDeviation(-3.0);
                                                                         fail("Expected IllegalArgumentException");
                                                                     } catch (IllegalArgumentException e) {
                                                                         // Expected behavior - test passes
                                                                     }
                                                                     // Additional check to ensure value wasn't stored as absolute value
                                                                     // This would catch the mutant that uses Math.abs()
                                                                     assertEquals(1.0, dist.getStandardDeviation(), 0.0001); // Should remain default value
                                                                 }

 @Test(expected = IllegalArgumentException.class)
                                                                public void testSetStandardDeviation_NonPositiveValue1() {
                                                                    NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                    dist.setStandardDeviation(0.0); // Should throw
                                                                }

 @Test
                                                                public void testSetStandardDeviation_PositiveValue5() {
                                                                    NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                    dist.setStandardDeviation(1.5);
                                                                    assertEquals(1.5, dist.getStandardDeviation(), 0.0001);
                                                                }

 @Test
                                                   public void testExceptionPropagation() throws Exception {
                                                       NormalDistributionImpl dist = new NormalDistributionImpl() {
                                                           @Override
                                                           public void setStandardDeviation(double sd) {
                                                               try {
                                                                   // Some operation that might throw different exceptions
                                                                   if (sd < 0) {
                                                                       throw new MaxIterationsExceededException(100);
                                                                   }
                                                                   super.setStandardDeviation(sd);
                                                               } catch (MaxIterationsExceededException ex) { // Original
                                                                   throw new IllegalArgumentException("Invalid sd");
                                                               }
                                                               // Mutant would catch Exception instead
                                                           }
                                                       };
                                                   
                                                       try {
                                                           dist.setStandardDeviation(-1);
                                                           fail("Should have thrown an exception");
                                                       } catch (IllegalArgumentException e) {
                                                           // This is expected for both original and mutant
                                                           assertEquals("Invalid sd", e.getMessage());
                                                       }
                                                   }

 @Test
                                              public void testCumulativeProbabilityAtBoundary() throws MathException {
                                                  // Setup
                                                  double mean = 10.0;
                                                  double sd = 1.0;
                                                  NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                  
                                                  // Calculate the exact boundary value
                                                  double boundaryX = mean - 20 * sd;
                                                  
                                                  // Test the boundary case
                                                  double result = dist.cumulativeProbability(boundaryX);
                                                  
                                                  // Original behavior would return 0 for x == boundary (not <)
                                                  // Mutant would potentially return non-zero
                                                  assertEquals("Should return 0 at exact boundary", 0.0, result, 0.0001);
                                                  
                                                  // Also test a value just below boundary to ensure original behavior
                                                  double belowBoundary = boundaryX - 0.0001;
                                                  double belowResult = dist.cumulativeProbability(belowBoundary);
                                                  assertEquals("Should return 0 below boundary", 0.0, belowResult, 0.0001);
                                                  
                                                  // Test a value just above boundary to ensure different behavior
                                                  double aboveBoundary = boundaryX + 0.0001;
                                                  double aboveResult = dist.cumulativeProbability(aboveBoundary);
                                                  assertTrue("Should return >0 just above boundary", aboveResult > 0);
                                              }

 @Test
                                         public void testCumulativeProbabilityAtLowSigmaRange() throws org.apache.commons.math.MathException {
                                             // Setup
                                             double mean = 100.0;
                                             double sd = 5.0;
                                             NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                             
                                             // Test point between 10σ and 20σ below mean
                                             double x = mean - 15 * sd; // 100 - 15*5 = 25
                                             
                                             // Calculate cumulative probability
                                             double prob = dist.cumulativeProbability(x);
                                             
                                             // Verify the probability is very small (should be < 1e-20 for 15σ)
                                             // The mutant (10σ) would return a different (larger) value
                                             assertTrue("Probability should be extremely small for 15σ below mean", 
                                                       prob < 1e-20);
                                             
                                             // Additional check for exact value if known expected behavior
                                             // This would depend on the exact implementation details
                                         }

 @Test
                                    public void testCumulativeProbabilityForExtremeValues2() throws MathException {
                                        // Setup with mean=0 and standard deviation=1 for simplicity
                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                        
                                        // Test value far below mean (-21σ)
                                        double extremeLow = -21.0;
                                        double probLow = dist.cumulativeProbability(extremeLow);
                                        
                                        // Test value far above mean (+21σ)
                                        double extremeHigh = 21.0;
                                        double probHigh = dist.cumulativeProbability(extremeHigh);
                                        
                                        // In original code, extremeLow should be treated as extreme case (prob ≈ 0)
                                        // while extremeHigh should be treated normally (prob ≈ 1)
                                        // The mutation would treat both cases the same
                                        assertTrue("Probability for extreme low value should be very small", 
                                                  probLow < 1e-20);
                                        assertTrue("Probability for extreme high value should be very close to 1",
                                                  probHigh > 1 - 1e-15);
                                        
                                        // Additional check to ensure the values are different
                                        assertNotEquals("Extreme low and high probabilities should differ",
                                                      probLow, probHigh, 1e-10);
                                    }

 @Test
                               public void testCumulativeProbabilityDetectsMutant() throws Exception {
                                   // Setup normal distribution with mean 0 and sd 1
                                   NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                   
                                   // Test x value that is NOT < (mean - 20*sd) = -20
                                   // Original should return normal probability, mutant would return different value
                                   double x = 0.0; // clearly not < -20
                                   
                                   // Get probability for this x value
                                   double probability = dist.cumulativeProbability(x);
                                   
                                   // Verify probability is as expected for standard normal distribution at x=0
                                   // The mutant would return a different value since it takes the if(true) branch
                                   assertEquals(0.5, probability, 0.0001);
                                   
                                   // Test another x value that would be affected
                                   x = -10.0; // still not < -20
                                   probability = dist.cumulativeProbability(x);
                                   // Expected value for standard normal at x=-10 (very small but not zero)
                                   assertTrue(probability > 0.0);
                                   assertTrue(probability < 0.0001);
                               }

 @Test(expected = IllegalArgumentException.class)
                               public void testSetStandardDeviation_ZeroValue3() {
                                   // This should throw exception in original, but pass in mutated version
                                   NormalDistributionImpl dist = new NormalDistributionImpl();
                                   dist.setStandardDeviation(0.0);
                               }

 @Test
                               public void testSetStandardDeviation_PositiveValue6() {
                                   NormalDistributionImpl dist = new NormalDistributionImpl();
                                   double testValue = 1.5;
                                   dist.setStandardDeviation(testValue);
                                   assertEquals(testValue, dist.getStandardDeviation(), 0.0001);
                               }

 @Test(expected = IllegalArgumentException.class)
                               public void testSetStandardDeviation_NegativeValue3() {
                                   NormalDistributionImpl dist = new NormalDistributionImpl();
                                   dist.setStandardDeviation(-0.1);
                               }

 @Test
                              public void testSetStandardDeviationWithSmallPositiveValue1() {
                                  NormalDistributionImpl dist = new NormalDistributionImpl();
                                  
                                  // This value would be accepted by original but rejected by mutant
                                  double smallPositive = 0.25;
                                  
                                  try {
                                      dist.setStandardDeviation(smallPositive);
                                      
                                      // Verify the value was set correctly
                                      assertEquals(smallPositive, dist.getStandardDeviation(), 0.0001);
                                  } catch (IllegalArgumentException e) {
                                      // If we get here, the mutant was detected
                                      fail("Mutant detected: 0.25 should be accepted but was rejected");
                                  }
                              }

 @Test(expected = IllegalArgumentException.class)
                              public void testSetStandardDeviationWithZeroShouldThrow1() {
                                  NormalDistributionImpl dist = new NormalDistributionImpl();
                                  dist.setStandardDeviation(0.0);
                              }

 @Test(expected = IllegalArgumentException.class)
                              public void testSetStandardDeviationWithNegativeShouldThrow1() {
                                  NormalDistributionImpl dist = new NormalDistributionImpl();
                                  dist.setStandardDeviation(-1.0);
                              }

 @Test
                              public void testSetStandardDeviationWithValidValue2() {
                                  NormalDistributionImpl dist = new NormalDistributionImpl();
                                  double validValue = 1.0;
                                  dist.setStandardDeviation(validValue);
                                  assertEquals(validValue, dist.getStandardDeviation(), 0.0001);
                              }

 @Test(expected = IllegalArgumentException.class)
                             public void testSetStandardDeviation_ZeroValueShouldThrowException3() {
                                 NormalDistributionImpl distribution = new NormalDistributionImpl();
                                 distribution.setStandardDeviation(0.0);
                             }

 @Test
                             public void testSetStandardDeviation_PositiveValueShouldBeSet2() {
                                 NormalDistributionImpl distribution = new NormalDistributionImpl();
                                 double testValue = 1.5;
                                 distribution.setStandardDeviation(testValue);
                                 assertEquals(testValue, distribution.getStandardDeviation(), 0.0001);
                             }

 @Test(expected = IllegalArgumentException.class)
                             public void testSetStandardDeviation_NegativeValueShouldThrowException3() {
                                 NormalDistributionImpl distribution = new NormalDistributionImpl();
                                 distribution.setStandardDeviation(-1.0);
                             }

 @Test
                       public void testCumulativeProbabilityAt20SigmaBoundary() throws org.apache.commons.math.MathException {
                           // Setup
                           double mean = 0.0;
                           double sd = 1.0;
                           NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                           
                           // Calculate the exact boundary point
                           double boundary = mean + 20 * sd;
                           
                           // Test behavior at boundary
                           // Original: x > boundary would be in the else case
                           // Mutant: x >= boundary would be in the else case
                           // So we need to test exactly at boundary
                           double result = dist.cumulativeProbability(boundary);
                           
                           // The exact value isn't specified, but we know it should be very close to 1.0
                           // The key is that the mutant would process this point differently
                           // So we assert it's greater than some threshold (say 0.999999)
                           assertTrue("Value at 20σ boundary should be very close to 1.0", 
                                     result > 0.999999);
                           
                           // Also test a point just above the boundary to ensure both cases are covered
                           double resultAbove = dist.cumulativeProbability(boundary + 0.000001);
                           assertTrue("Value just above 20σ should be even closer to 1.0",
                                     resultAbove > result);
                       }

 @Test
                  public void testCumulativeProbabilityForLargeDeviations() throws Exception {
                      // Setup
                      double mean = 0.0;
                      double sd = 1.0;
                      NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                      
                      // Test value between 10σ and 20σ from mean
                      double x = 15.0; // 15σ from mean (between 10 and 20)
                      
                      // Get probability from original method
                      double originalProbability = dist.cumulativeProbability(x);
                      
                      // The original should return a very small but non-zero probability
                      // The mutant would potentially return 1.0 or handle it as edge case
                      assertTrue("Probability for 15σ should be very small", 
                                 originalProbability > 0.0 && originalProbability < 1.0);
                      
                      // Additional assertion to ensure it's not treated as edge case
                      double xAt20Sigma = 20.0;
                      double probAt20Sigma = dist.cumulativeProbability(xAt20Sigma);
                      assertTrue(originalProbability > probAt20Sigma);
                  }

 @Test
             public void testCumulativeProbabilityForLargeValues() throws MathException {
                 // Setup with mean=0 and SD=1 for simplicity
                 NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                 
                 // Test value that is > mean + 20*SD (21 > 0 + 20*1)
                 double veryLargeValue = 21.0;
                 // Should be very close to 1.0 for original code
                 assertEquals(1.0, dist.cumulativeProbability(veryLargeValue), 0.0001);
                 
                 // Test value that is > mean - 20*SD but < mean + 20*SD (e.g., -19 > 0 - 20*1 is false)
                 double largeNegativeValue = -19.0;
                 // Original code would treat this differently than mutated code
                 assertTrue(dist.cumulativeProbability(largeNegativeValue) < 1.0);
                 
                 // Test value that is < mean - 20*SD (e.g., -21 < 0 - 20*1)
                 double verySmallValue = -21.0;
                 // Should be very close to 0.0 for both original and mutated code
                 assertEquals(0.0, dist.cumulativeProbability(verySmallValue), 0.0001);
             }

 @Test(expected = IllegalArgumentException.class)
        public void testSetStandardDeviation_ZeroValue_ThrowsException() {
            // This test will catch the mutant by verifying exception is thrown for 0.0
            NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
            normalDistribution.setStandardDeviation(0.0);
        }

 @Test
        public void testSetStandardDeviation_ZeroValue_FieldNotSet() {
            NormalDistributionImpl normalDistribution = new NormalDistributionImpl(); // Uses default constructor (mean=0.0, sd=1.0)
            try {
                normalDistribution.setStandardDeviation(0.0);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                // Verify standardDeviation wasn't changed (should still be 1.0 from constructor)
                assertEquals(1.0, normalDistribution.getStandardDeviation(), 0.0001);
            }
        }

 @Test
        public void testSetStandardDeviation_PositiveValue_SetsCorrectly3() {
            NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
            normalDistribution.setStandardDeviation(5.0);
            assertEquals(5.0, normalDistribution.getStandardDeviation(), 0.0001);
        }

 @Test(expected = IllegalArgumentException.class)
        public void testSetStandardDeviation_NegativeValue_ThrowsException() {
            NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
            normalDistribution.setStandardDeviation(-1.0);
        }

 @Test
        public void testSetStandardDeviation_ShouldRejectZeroAndNegative() {
            NormalDistributionImpl dist = new NormalDistributionImpl();
            
            // Test that 0.0 throws exception
            try {
                dist.setStandardDeviation(0.0);
                fail("Expected IllegalArgumentException for 0.0");
            } catch (IllegalArgumentException e) {
                assertEquals("Standard deviation must be positive.", e.getMessage());
            }
            
            // Test that negative throws exception
            try {
                dist.setStandardDeviation(-1.0);
                fail("Expected IllegalArgumentException for negative");
            } catch (IllegalArgumentException e) {
                assertEquals("Standard deviation must be positive.", e.getMessage());
            }
        }

 @Test
        public void testSetStandardDeviation_ShouldRejectSmallPositiveValues() {
            NormalDistributionImpl dist = new NormalDistributionImpl();
            
            // This is the key test that catches the mutant
            // The mutant would accept 0.4 when it should reject
            try {
                dist.setStandardDeviation(0.4);
                fail("Expected IllegalArgumentException for 0.4");
            } catch (IllegalArgumentException e) {
                assertEquals("Standard deviation must be positive.", e.getMessage());
            }
            
            // Also test just above and below the 0.5 boundary
            try {
                dist.setStandardDeviation(0.499);
                fail("Expected IllegalArgumentException for 0.499");
            } catch (IllegalArgumentException e) {
                assertEquals("Standard deviation must be positive.", e.getMessage());
            }
            
            // This should be accepted
            dist.setStandardDeviation(0.501);
            assertEquals(0.501, dist.getStandardDeviation(), 0.0001);
        }

 @Test
        public void testSetStandardDeviation_AcceptsValidValues() {
            NormalDistributionImpl dist = new NormalDistributionImpl();
            
            // Test normal positive value
            dist.setStandardDeviation(1.0);
            assertEquals(1.0, dist.getStandardDeviation(), 0.0001);
            
            // Test large value
            dist.setStandardDeviation(1000.0);
            assertEquals(1000.0, dist.getStandardDeviation(), 0.0001);
        }

 @Test
       public void testSetStandardDeviation() {
           NormalDistributionImpl dist = new NormalDistributionImpl();
           
           // Test valid positive value > 0
           double validSD = 0.5;
           dist.setStandardDeviation(validSD);
           assertEquals(validSD, dist.getStandardDeviation(), 0.0001);
           
           // Test boundary case - should throw exception for 0
           try {
               dist.setStandardDeviation(0.0);
               fail("Expected IllegalArgumentException for 0.0");
           } catch (IllegalArgumentException e) {
               assertEquals("Standard deviation must be positive.", e.getMessage());
           }
           
           // Test negative value - should throw exception
           try {
               dist.setStandardDeviation(-1.0);
               fail("Expected IllegalArgumentException for negative value");
           } catch (IllegalArgumentException e) {
               assertEquals("Standard deviation must be positive.", e.getMessage());
           }
           
           // Test small positive value that would be rejected by mutant (0 < value <= 1)
           double smallPositive = 0.0001;
           dist.setStandardDeviation(smallPositive);
           assertEquals(smallPositive, dist.getStandardDeviation(), 0.0001);
       }

 @Test
      public void testSetStandardDeviation_NonPositiveValue_ThrowsIllegalArgumentException2() {
          NormalDistributionImpl dist = new NormalDistributionImpl();
          
          // Test boundary case (0.0)
          thrown.expect(IllegalArgumentException.class);
          thrown.expectMessage("Standard deviation must be positive.");
          dist.setStandardDeviation(0.0);
          
          // Test clearly negative case
          thrown.expect(IllegalArgumentException.class);
          thrown.expectMessage("Standard deviation must be positive.");
          dist.setStandardDeviation(-1.0);
      }

 @Test
      public void testSetStandardDeviation_PositiveValue_SetsCorrectly4() {
          NormalDistributionImpl dist = new NormalDistributionImpl();
          
          // Test valid positive value
          dist.setStandardDeviation(1.5);
          assertEquals(1.5, dist.getStandardDeviation(), 0.0001);
          
          // Test another valid positive value
          dist.setStandardDeviation(0.0001); // very small but still positive
          assertEquals(0.0001, dist.getStandardDeviation(), 0.0000001);
      }

 @Test
     public void testSetStandardDeviation_NonPositiveValue_ShouldThrowException2() {
         // Arrange
         NormalDistributionImpl distribution = new NormalDistributionImpl();
         double invalidSd = -1.0;
         
         // Set expectation for exception
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Standard deviation must be positive.");
         
         // Act
         distribution.setStandardDeviation(invalidSd);
         
         // Assert - exception should be thrown before reaching here
         // If mutant survives, no exception will be thrown and test will fail
     }

 @Test
     public void testSetStandardDeviation_NonPositiveValue_ShouldNotChangeField() {
         // Arrange
         NormalDistributionImpl distribution = new NormalDistributionImpl();
         double originalSd = distribution.getStandardDeviation();
         double invalidSd = 0.0;
         
         try {
             // Act
             distribution.setStandardDeviation(invalidSd);
             // If we get here, mutant has survived (no exception thrown)
             
             // Assert
             assertEquals("Standard deviation should remain unchanged when invalid value is provided",
                         originalSd, distribution.getStandardDeviation(), 0.0001);
         } catch (IllegalArgumentException e) {
             // Original behavior - test passes
             assertTrue(true);
         }
     }

}
