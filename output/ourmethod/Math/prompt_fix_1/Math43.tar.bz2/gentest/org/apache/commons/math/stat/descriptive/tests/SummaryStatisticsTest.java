package gentest.org.apache.commons.math.stat.descriptive.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.descriptive.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.moment.GeometricMean;
import org.apache.commons.math.stat.descriptive.moment.Mean;
import org.apache.commons.math.stat.descriptive.moment.SecondMoment;
import org.apache.commons.math.stat.descriptive.moment.Variance;
import org.apache.commons.math.stat.descriptive.rank.Max;
import org.apache.commons.math.stat.descriptive.rank.Min;
import org.apache.commons.math.stat.descriptive.summary.Sum;
import org.apache.commons.math.stat.descriptive.summary.SumOfLogs;
import org.apache.commons.math.stat.descriptive.summary.SumOfSquares;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.Precision;
import org.apache.commons.math.util.FastMath;
 
public class SummaryStatisticsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                  public void testAddValue_StandardCase() {
                                                      // Create mock objects for all implementations
                                                      StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic meanImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic varianceImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic geoMeanImpl = mock(StorelessUnivariateStatistic.class);
                                                      
                                                      // Create the stats object and set all implementations
                                                      SummaryStatistics stats = new SummaryStatistics();
                                                      stats.setSumImpl(sumImpl);
                                                      stats.setSumsqImpl(sumsqImpl);
                                                      stats.setMinImpl(minImpl);
                                                      stats.setMaxImpl(maxImpl);
                                                      stats.setSumLogImpl(sumLogImpl);
                                                      stats.setMeanImpl(meanImpl);
                                                      stats.setVarianceImpl(varianceImpl);
                                                      stats.setGeoMeanImpl(geoMeanImpl);
                                                      
                                                      // Set second moment through reflection since it might be private
                                                      try {
                                                          Field secondMomentField = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                          secondMomentField.setAccessible(true);
                                                          secondMomentField.set(stats, secondMoment);
                                                      } catch (Exception e) {
                                                          fail("Failed to set secondMoment field through reflection");
                                                      }
                                                      
                                                      double value = 5.0;
                                                      
                                                      // Call the method
                                                      stats.addValue(value);
                                                      
                                                      // Verify all implementations were called
                                                      verify(sumImpl).increment(value);
                                                      verify(sumsqImpl).increment(value);
                                                      verify(minImpl).increment(value);
                                                      verify(maxImpl).increment(value);
                                                      verify(sumLogImpl).increment(value);
                                                      verify(secondMoment).increment(value);
                                                      
                                                      // Verify mean/variance/geoMean were NOT called (since they equal their impls by default)
                                                      verify(meanImpl, never()).increment(value);
                                                      verify(varianceImpl, never()).increment(value);
                                                      verify(geoMeanImpl, never()).increment(value);
                                                      
                                                      // Verify n was incremented
                                                      assertEquals(1, stats.getN());
                                                  }

 @Test
                                                  public void testAddValue_WithOverriddenMeanVarianceGeoMean() {
                                                      double value = 10.0;
                                                      
                                                      // Create mock instances for all required statistics
                                                      StorelessUnivariateStatistic customMean = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic customVariance = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic customGeoMean = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                      
                                                      // Create the stats object and set all implementations
                                                      SummaryStatistics stats = new SummaryStatistics();
                                                      stats.setMeanImpl(customMean);
                                                      stats.setVarianceImpl(customVariance);
                                                      stats.setGeoMeanImpl(customGeoMean);
                                                      stats.setSumImpl(sumImpl);
                                                      stats.setSumsqImpl(sumsqImpl);
                                                      stats.setMinImpl(minImpl);
                                                      stats.setMaxImpl(maxImpl);
                                                      stats.setSumLogImpl(sumLogImpl);
                                                      stats.setVarianceImpl(secondMoment); // Assuming secondMoment is used for variance
                                                      
                                                      // Call the method
                                                      stats.addValue(value);
                                                      
                                                      // Verify all standard implementations were called
                                                      verify(sumImpl).increment(value);
                                                      verify(sumsqImpl).increment(value);
                                                      verify(minImpl).increment(value);
                                                      verify(maxImpl).increment(value);
                                                      verify(sumLogImpl).increment(value);
                                                      verify(secondMoment).increment(value);
                                                      
                                                      // Verify custom implementations were called
                                                      verify(customMean).increment(value);
                                                      verify(customVariance).increment(value);
                                                      verify(customGeoMean).increment(value);
                                                      
                                                      // Verify n was incremented
                                                      assertEquals(1, stats.getN());
                                                  }

 @Test
                                                  public void testAddValue_MultipleValues() {
                                                      // Create test objects
                                                      SummaryStatistics stats = new SummaryStatistics();
                                                      StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                      stats.setSumImpl(sumImpl);
                                                      
                                                      // Test values
                                                      double value1 = 2.0;
                                                      double value2 = 4.0;
                                                      double value3 = 6.0;
                                                      
                                                      // Add multiple values
                                                      stats.addValue(value1);
                                                      stats.addValue(value2);
                                                      stats.addValue(value3);
                                                      
                                                      // Verify increments were called for each value
                                                      verify(sumImpl).increment(value1);
                                                      verify(sumImpl).increment(value2);
                                                      verify(sumImpl).increment(value3);
                                                      
                                                      // Verify n was incremented correctly
                                                      assertEquals(3, stats.getN());
                                                  }

 @Test
                                                  public void testAddValue_ZeroValue() {
                                                      // Create mock implementations
                                                      StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                      
                                                      // Create stats object and set the mock implementations
                                                      SummaryStatistics stats = new SummaryStatistics();
                                                      stats.setSumImpl(sumImpl);
                                                      stats.setSumsqImpl(sumsqImpl);
                                                      stats.setMinImpl(minImpl);
                                                      stats.setMaxImpl(maxImpl);
                                                      stats.setSumLogImpl(sumLogImpl);
                                                      
                                                      // Use reflection to set the private secondMoment field
                                                      try {
                                                          Field field = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                          field.setAccessible(true);
                                                          field.set(stats, secondMoment);
                                                      } catch (Exception e) {
                                                          fail("Failed to set secondMoment field via reflection");
                                                      }
                                                      
                                                      double value = 0.0;
                                                      
                                                      stats.addValue(value);
                                                      
                                                      verify(sumImpl).increment(value);
                                                      verify(sumsqImpl).increment(value);
                                                      verify(minImpl).increment(value);
                                                      verify(maxImpl).increment(value);
                                                      verify(sumLogImpl).increment(value);
                                                      verify(secondMoment).increment(value);
                                                      
                                                      assertEquals(1, stats.getN());
                                                  }

 @Test
                                                  public void testAddValue_NegativeValue() {
                                                      // Create the stats object
                                                      SummaryStatistics stats = new SummaryStatistics();
                                                      
                                                      // Create mock implementations
                                                      StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                      
                                                      // Set the mock implementations
                                                      stats.setSumImpl(sumImpl);
                                                      stats.setSumsqImpl(sumsqImpl);
                                                      stats.setMinImpl(minImpl);
                                                      stats.setMaxImpl(maxImpl);
                                                      stats.setSumLogImpl(sumLogImpl);
                                                      stats.setVarianceImpl(secondMoment);
                                                      
                                                      double value = -5.5;
                                                      
                                                      // Test the method
                                                      stats.addValue(value);
                                                      
                                                      // Verify the interactions
                                                      verify(sumImpl).increment(value);
                                                      verify(sumsqImpl).increment(value);
                                                      verify(minImpl).increment(value);
                                                      verify(maxImpl).increment(value);
                                                      verify(sumLogImpl).increment(value);
                                                      verify(secondMoment).increment(value);
                                                      
                                                      // Verify the count
                                                      assertEquals(1, stats.getN());
                                                  }

 @Test
                                                  public void testAddValue_ExtremeValue() {
                                                      SummaryStatistics stats = new SummaryStatistics();
                                                      double value = Double.MAX_VALUE;
                                                      
                                                      stats.addValue(value);
                                                      
                                                      assertEquals(1, stats.getN());
                                                      assertEquals(value, stats.getMax(), 0.0);
                                                      assertEquals(value, stats.getMin(), 0.0);
                                                      assertEquals(value, stats.getSum(), 0.0);
                                                      assertEquals(value * value, stats.getSumsq(), 0.0);
                                                  }

 @Test
                                                  public void testAddValue_NaNValue() {
                                                      SummaryStatistics stats = new SummaryStatistics();
                                                      double value = Double.NaN;
                                                      
                                                      stats.addValue(value);
                                                      
                                                      // Verify that NaN values are counted in N but don't affect other statistics
                                                      assertEquals(1, stats.getN());
                                                      assertTrue(Double.isNaN(stats.getSum()));
                                                      assertTrue(Double.isNaN(stats.getSumsq()));
                                                      assertTrue(Double.isNaN(stats.getMean()));
                                                      assertTrue(Double.isNaN(stats.getMax()));
                                                      assertTrue(Double.isNaN(stats.getMin()));
                                                      assertTrue(Double.isNaN(stats.getSumOfLogs()));
                                                      assertTrue(Double.isNaN(stats.getGeometricMean()));
                                                  }

 @Test
                                                  public void testAddValue_InfinityValue() {
                                                      // Create the stats object
                                                      SummaryStatistics stats = new SummaryStatistics();
                                                      
                                                      // Create mock implementations
                                                      StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                      StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                      
                                                      // Set the mock implementations
                                                      stats.setSumImpl(sumImpl);
                                                      stats.setSumsqImpl(sumsqImpl);
                                                      stats.setMinImpl(minImpl);
                                                      stats.setMaxImpl(maxImpl);
                                                      stats.setSumLogImpl(sumLogImpl);
                                                      
                                                      // Use reflection to set the private secondMoment field
                                                      try {
                                                          Field field = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                          field.setAccessible(true);
                                                          field.set(stats, secondMoment);
                                                      } catch (Exception e) {
                                                          fail("Failed to set secondMoment field via reflection");
                                                      }
                                                      
                                                      double value = Double.POSITIVE_INFINITY;
                                                      
                                                      stats.addValue(value);
                                                      
                                                      // Verify the interactions
                                                      verify(sumImpl).increment(value);
                                                      verify(sumsqImpl).increment(value);
                                                      verify(minImpl).increment(value);
                                                      verify(maxImpl).increment(value);
                                                      verify(sumLogImpl).increment(value);
                                                      verify(secondMoment).increment(value);
                                                      
                                                      assertEquals(1, stats.getN());
                                                  }

 @Test
                                             public void testAddValueSecondMoment() throws Exception {
                                                 // Setup
                                                 SummaryStatistics stats = new SummaryStatistics();
                                                 double testValue = 5.0;
                                                 
                                                 // Mock the second moment to verify it gets the correct value
                                                 SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                 
                                                 // Use reflection to set the protected secondMoment field
                                                 Field secondMomentField = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                 secondMomentField.setAccessible(true);
                                                 secondMomentField.set(stats, mockSecondMoment);
                                                 
                                                 // Execute
                                                 stats.addValue(testValue);
                                                 
                                                 // Verify secondMoment was called with the correct value
                                                 verify(mockSecondMoment).increment(testValue); // This will fail if mutant is present
                                                 
                                                 // Additional verification with real calculation
                                                 stats = new SummaryStatistics();
                                                 stats.addValue(testValue);
                                                 stats.addValue(testValue * 2);
                                                 
                                                 // Second moment should be sum of squares: 5² + 10² = 125
                                                 double expectedSecondMoment = 125.0;
                                                 assertEquals("Second moment calculation is incorrect", 
                                                             expectedSecondMoment, 
                                                             stats.getSecondMoment(), 
                                                             0.0001);
                                                 
                                                 // For mutated version, it would be (-5)² + (-10)² = 125
                                                 // So we need another test with mixed signs
                                                 stats.clear();
                                                 stats.addValue(testValue);
                                                 stats.addValue(-testValue);
                                                 
                                                 // Should be 5² + (-5)² = 50
                                                 expectedSecondMoment = 50.0;
                                                 assertEquals("Second moment calculation with mixed signs is incorrect",
                                                             expectedSecondMoment,
                                                             stats.getSecondMoment(),
                                                             0.0001);
                                             }

 @Test
                                        public void testAddValueWithOverriddenMeanImpl() throws Exception {
                                            // Create the object to test
                                            SummaryStatistics stats = new SummaryStatistics();
                                            
                                            // Create mock implementations
                                            StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
                                            StorelessUnivariateStatistic mockMean = mock(StorelessUnivariateStatistic.class);
                                            StorelessUnivariateStatistic mockSum = mock(StorelessUnivariateStatistic.class);
                                            StorelessUnivariateStatistic mockSumsq = mock(StorelessUnivariateStatistic.class);
                                            StorelessUnivariateStatistic mockMin = mock(StorelessUnivariateStatistic.class);
                                            StorelessUnivariateStatistic mockMax = mock(StorelessUnivariateStatistic.class);
                                            StorelessUnivariateStatistic mockSumLog = mock(StorelessUnivariateStatistic.class);
                                            StorelessUnivariateStatistic mockSecondMoment = mock(StorelessUnivariateStatistic.class);
                                            
                                            // Set up the test scenario where meanImpl is different from mean
                                            stats.setMeanImpl(mockMeanImpl);
                                            
                                            // Use reflection to set private fields
                                            Field meanField = SummaryStatistics.class.getDeclaredField("mean");
                                            meanField.setAccessible(true);
                                            meanField.set(stats, mockMean);
                                            
                                            Field sumImplField = SummaryStatistics.class.getDeclaredField("sumImpl");
                                            sumImplField.setAccessible(true);
                                            sumImplField.set(stats, mockSum);
                                            
                                            Field sumsqImplField = SummaryStatistics.class.getDeclaredField("sumsqImpl");
                                            sumsqImplField.setAccessible(true);
                                            sumsqImplField.set(stats, mockSumsq);
                                            
                                            Field minImplField = SummaryStatistics.class.getDeclaredField("minImpl");
                                            minImplField.setAccessible(true);
                                            minImplField.set(stats, mockMin);
                                            
                                            Field maxImplField = SummaryStatistics.class.getDeclaredField("maxImpl");
                                            maxImplField.setAccessible(true);
                                            maxImplField.set(stats, mockMax);
                                            
                                            Field sumLogImplField = SummaryStatistics.class.getDeclaredField("sumLogImpl");
                                            sumLogImplField.setAccessible(true);
                                            sumLogImplField.set(stats, mockSumLog);
                                            
                                            Field secondMomentField = SummaryStatistics.class.getDeclaredField("secondMoment");
                                            secondMomentField.setAccessible(true);
                                            secondMomentField.set(stats, mockSecondMoment);
                                            
                                            // Add a test value
                                            double testValue = 5.0;
                                            stats.addValue(testValue);
                                            
                                            // Verify that meanImpl.increment() was called (original behavior)
                                            verify(mockMeanImpl).increment(testValue);
                                            
                                            // Verify mean.increment() was NOT called
                                            verify(mockMean, never()).increment(anyDouble());
                                            
                                            // Verify other required increments were called
                                            verify(mockSum).increment(testValue);
                                            verify(mockSumsq).increment(testValue);
                                            verify(mockMin).increment(testValue);
                                            verify(mockMax).increment(testValue);
                                            verify(mockSumLog).increment(testValue);
                                            verify(mockSecondMoment).increment(testValue);
                                            
                                            // Verify n was incremented
                                            assertEquals(1, stats.getN());
                                        }

 @Test
                                   public void testAddValueDoesNotCallMeanImplWhenNotOverridden() throws Exception {
                                       // Setup
                                       SummaryStatistics stats = new SummaryStatistics();
                                       
                                       // Create mock implementations
                                       StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
                                       StorelessUnivariateStatistic mockMean = mock(StorelessUnivariateStatistic.class);
                                       
                                       // Set meanImpl to be the same as mean (not overridden)
                                       stats.setMeanImpl(mockMeanImpl);
                                       
                                       // Use reflection to set the mean field
                                       Field meanField = SummaryStatistics.class.getDeclaredField("mean");
                                       meanField.setAccessible(true);
                                       meanField.set(stats, mockMeanImpl);
                                       
                                       // Get private fields for verification
                                       Field sumImplField = SummaryStatistics.class.getDeclaredField("sumImpl");
                                       sumImplField.setAccessible(true);
                                       StorelessUnivariateStatistic sumImpl = (StorelessUnivariateStatistic) sumImplField.get(stats);
                                       
                                       Field sumsqImplField = SummaryStatistics.class.getDeclaredField("sumsqImpl");
                                       sumsqImplField.setAccessible(true);
                                       StorelessUnivariateStatistic sumsqImpl = (StorelessUnivariateStatistic) sumsqImplField.get(stats);
                                       
                                       Field minImplField = SummaryStatistics.class.getDeclaredField("minImpl");
                                       minImplField.setAccessible(true);
                                       StorelessUnivariateStatistic minImpl = (StorelessUnivariateStatistic) minImplField.get(stats);
                                       
                                       Field maxImplField = SummaryStatistics.class.getDeclaredField("maxImpl");
                                       maxImplField.setAccessible(true);
                                       StorelessUnivariateStatistic maxImpl = (StorelessUnivariateStatistic) maxImplField.get(stats);
                                       
                                       Field sumLogImplField = SummaryStatistics.class.getDeclaredField("sumLogImpl");
                                       sumLogImplField.setAccessible(true);
                                       StorelessUnivariateStatistic sumLogImpl = (StorelessUnivariateStatistic) sumLogImplField.get(stats);
                                       
                                       Field secondMomentField = SummaryStatistics.class.getDeclaredField("secondMoment");
                                       secondMomentField.setAccessible(true);
                                       StorelessUnivariateStatistic secondMoment = (StorelessUnivariateStatistic) secondMomentField.get(stats);
                                       
                                       // Test
                                       stats.addValue(5.0);
                                       
                                       // Verify meanImpl.increment() was NOT called since meanImpl == mean
                                       verify(mockMeanImpl, never()).increment(anyDouble());
                                       
                                       // Additional verifications for other required increments
                                       verify(sumImpl).increment(5.0);
                                       verify(sumsqImpl).increment(5.0);
                                       verify(minImpl).increment(5.0);
                                       verify(maxImpl).increment(5.0);
                                       verify(sumLogImpl).increment(5.0);
                                       verify(secondMoment).increment(5.0);
                                   }

 @Test
                              public void testAddValueWithOverriddenMeanImplementation() {
                                  // Create the object under test
                                  SummaryStatistics stats = new SummaryStatistics();
                                  
                                  // Create mock implementations
                                  StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
                                  Mean mockMean = mock(Mean.class);
                                  
                                  // Set up the test scenario where meanImpl is different from mean
                                  stats.setMeanImpl(mockMeanImpl);
                                  
                                  // Use reflection to set the protected mean field
                                  try {
                                      Field meanField = SummaryStatistics.class.getDeclaredField("mean");
                                      meanField.setAccessible(true);
                                      meanField.set(stats, mockMean);
                                  } catch (Exception e) {
                                      fail("Failed to set mean field via reflection: " + e.getMessage());
                                  }
                                  
                                  double testValue = 5.0;
                                  
                                  // Call the method
                                  stats.addValue(testValue);
                                  
                                  // Verify that meanImpl.increment() was called with the test value
                                  verify(mockMeanImpl).increment(testValue);
                                  
                                  // Also verify that the original mean wasn't called (though this isn't strictly necessary)
                                  verify(mockMean, never()).increment(anyDouble());
                              }

 @Test
                         public void testAddValueWithCustomMeanImplementation() {
                             // Create the object under test
                             SummaryStatistics stats = new SummaryStatistics();
                             
                             // Create and set mock implementations
                             StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
                             StorelessUnivariateStatistic mockVariance = mock(StorelessUnivariateStatistic.class);
                             
                             // Set the mock implementations
                             stats.setMeanImpl(mockMeanImpl);
                             stats.setVarianceImpl(mockVariance); // This makes varianceImpl != variance
                             
                             // Mock other required implementations to avoid NPE
                             stats.setSumImpl(mock(StorelessUnivariateStatistic.class));
                             stats.setSumsqImpl(mock(StorelessUnivariateStatistic.class));
                             stats.setMinImpl(mock(StorelessUnivariateStatistic.class));
                             stats.setMaxImpl(mock(StorelessUnivariateStatistic.class));
                             stats.setSumLogImpl(mock(StorelessUnivariateStatistic.class));
                             stats.setGeoMeanImpl(mock(StorelessUnivariateStatistic.class));
                             
                             // Test value
                             double testValue = 5.0;
                             
                             // Call the method
                             stats.addValue(testValue);
                             
                             // Verify meanImpl was called with the actual value, not 0
                             verify(mockMeanImpl).increment(testValue);
                             
                             // Additional verification that other implementations were called
                             verify(stats.getSumImpl()).increment(testValue);
                             verify(stats.getSumsqImpl()).increment(testValue);
                             verify(stats.getMinImpl()).increment(testValue);
                             verify(stats.getMaxImpl()).increment(testValue);
                             verify(stats.getSumLogImpl()).increment(testValue);
                         }

 @Test
                    public void testAddValueWithOverriddenMean() {
                        // Setup
                        SummaryStatistics stats = new SummaryStatistics();
                        
                        // Create mock implementation
                        StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
                        
                        // Configure the test scenario with overridden mean implementation
                        stats.setMeanImpl(mockMeanImpl);
                        
                        // Test value
                        double testValue = 5.0;
                        
                        // Execute
                        stats.addValue(testValue);
                        
                        // Verify meanImpl was called with the correct value
                        verify(mockMeanImpl).increment(testValue);
                        
                        // Verify the default mean implementation wasn't used
                        // (This is now implicit since we didn't set a separate mean)
                    }

 @Test
               public void testAddValueDoesNotCallVarianceImplWhenSameAsVariance() {
                   // Setup
                   SummaryStatistics stats = new SummaryStatistics();
                   
                   // Create mock implementation
                   StorelessUnivariateStatistic mockVariance = mock(StorelessUnivariateStatistic.class);
                   
                   // Set varianceImpl to be the mock
                   stats.setVarianceImpl(mockVariance);
                   
                   // Add a test value
                   double testValue = 5.0;
                   stats.addValue(testValue);
                   
                   // Verify varianceImpl.increment() was called (since it's the implementation)
                   verify(mockVariance, times(1)).increment(testValue);
                   
                   // Now test when varianceImpl is not set (should use default implementation)
                   SummaryStatistics stats2 = new SummaryStatistics();
                   StorelessUnivariateStatistic mockVarianceImpl = mock(StorelessUnivariateStatistic.class);
                   stats2.setVarianceImpl(mockVarianceImpl);
                   
                   // The variance field will be different from varianceImpl
                   stats2.addValue(testValue);
                   
                   // Verify varianceImpl.increment() was called
                   verify(mockVarianceImpl, times(1)).increment(testValue);
               }

 @Test
          public void testAddValueWithCustomGeoMeanImpl() throws Exception {
              // Setup
              SummaryStatistics stats = new SummaryStatistics();
              StorelessUnivariateStatistic customGeoMean = mock(StorelessUnivariateStatistic.class);
              
              // Get private implementations using reflection
              Field sumImplField = SummaryStatistics.class.getDeclaredField("sumImpl");
              sumImplField.setAccessible(true);
              StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
              sumImplField.set(stats, sumImpl);
              
              Field sumsqImplField = SummaryStatistics.class.getDeclaredField("sumsqImpl");
              sumsqImplField.setAccessible(true);
              StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
              sumsqImplField.set(stats, sumsqImpl);
              
              Field minImplField = SummaryStatistics.class.getDeclaredField("minImpl");
              minImplField.setAccessible(true);
              StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
              minImplField.set(stats, minImpl);
              
              Field maxImplField = SummaryStatistics.class.getDeclaredField("maxImpl");
              maxImplField.setAccessible(true);
              StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
              maxImplField.set(stats, maxImpl);
              
              Field sumLogImplField = SummaryStatistics.class.getDeclaredField("sumLogImpl");
              sumLogImplField.setAccessible(true);
              StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
              sumLogImplField.set(stats, sumLogImpl);
              
              Field secondMomentField = SummaryStatistics.class.getDeclaredField("secondMoment");
              secondMomentField.setAccessible(true);
              StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
              secondMomentField.set(stats, secondMoment);
              
              // Set custom geoMean implementation (different from default)
              stats.setGeoMeanImpl(customGeoMean);
              
              // Add test value
              double testValue = 5.0;
              stats.addValue(testValue);
              
              // Verify custom implementation was called
              verify(customGeoMean).increment(testValue);
              
              // Also verify other standard increments happened
              verify(sumImpl).increment(testValue);
              verify(sumsqImpl).increment(testValue);
              verify(minImpl).increment(testValue);
              verify(maxImpl).increment(testValue);
              verify(sumLogImpl).increment(testValue);
              verify(secondMoment).increment(testValue);
              
              // Verify n was incremented
              assertEquals(1, stats.getN());
          }

 @Test
     public void testAddValueWithCustomGeoMeanImplementation() throws Exception {
         // Create the object under test
         SummaryStatistics stats = new SummaryStatistics();
         
         // Create and set a mock geoMeanImpl that's different from default geoMean
         StorelessUnivariateStatistic mockGeoMeanImpl = mock(StorelessUnivariateStatistic.class);
         stats.setGeoMeanImpl(mockGeoMeanImpl);
         
         // Use reflection to get the secondMoment field for verification
         Field secondMomentField = SummaryStatistics.class.getDeclaredField("secondMoment");
         secondMomentField.setAccessible(true);
         StorelessUnivariateStatistic secondMoment = (StorelessUnivariateStatistic) secondMomentField.get(stats);
         StorelessUnivariateStatistic mockSecondMoment = mock(StorelessUnivariateStatistic.class);
         secondMomentField.set(stats, mockSecondMoment);
         
         // Add a test value (non-zero to detect the mutant)
         double testValue = 5.0;
         stats.addValue(testValue);
         
         // Verify geoMeanImpl was called with the actual value (not 0)
         verify(mockGeoMeanImpl).increment(testValue);
         
         // Additional verification that other required increments happened
         verify(stats.getSumImpl()).increment(testValue);
         verify(stats.getSumsqImpl()).increment(testValue);
         verify(stats.getMinImpl()).increment(testValue);
         verify(stats.getMaxImpl()).increment(testValue);
         verify(stats.getSumLogImpl()).increment(testValue);
         verify(mockSecondMoment).increment(testValue);
         
         // Verify count was incremented
         assertEquals(1, stats.getN());
     }

 @Test
 public void testAddValueGeoMeanIncrement() {
     // Setup
     SummaryStatistics stats = new SummaryStatistics();
     StorelessUnivariateStatistic mockGeoMeanImpl = mock(StorelessUnivariateStatistic.class);
     stats.setGeoMeanImpl(mockGeoMeanImpl);
     
     // The test value - must be positive since geometric mean requires positive numbers
     double testValue = 5.0;
     
     // Execute
     stats.addValue(testValue);
     
     // Verify geoMeanImpl was called with the correct value
     verify(mockGeoMeanImpl).increment(testValue);
     
     // Additional verification that other stats were updated
     assertEquals(1, stats.getN());
     // Note: We can't verify other increments directly since they're private,
     // but we can verify through public getters if needed
 }

}
