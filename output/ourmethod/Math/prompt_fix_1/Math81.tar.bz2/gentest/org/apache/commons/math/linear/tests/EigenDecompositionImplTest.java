package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.util.MathUtils;
 
public class EigenDecompositionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                      public void testComputeGershgorinCircles_WithNegativeValues() throws Exception {
                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                          double[] main = new double[]{-1.0, -2.0, -3.0};
                                                                                                                                                                                                                          double[] secondary = new double[]{0.5, 1.5};
                                                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-12);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Access private work array using reflection
                                                                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                                                                          double[] work = (double[]) workField.get(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          double[] expectedLower = {-2.0, -4.0, -4.5};
                                                                                                                                                                                                                          double[] expectedUpper = {0.0, 0.0, -1.5};
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                                          Method computeGershgorinCircles = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                                          computeGershgorinCircles.setAccessible(true);
                                                                                                                                                                                                                          computeGershgorinCircles.invoke(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                                          Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                                          lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                                          assertEquals(-4.5, (Double)lowerSpectraField.get(eigenDecomposition), 1e-10);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                                          upperSpectraField.setAccessible(true);
                                                                                                                                                                                                                          assertEquals(0.0, (Double)upperSpectraField.get(eigenDecomposition), 1e-10);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          int m = main.length;
                                                                                                                                                                                                                          for (int i = 0; i < m; i++) {
                                                                                                                                                                                                                              assertEquals(expectedLower[i], work[4*m + i], 1e-10);
                                                                                                                                                                                                                              assertEquals(expectedUpper[i], work[5*m + i], 1e-10);
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                      public void testComputeGershgorinCircles_SingleElementMatrix() throws Exception {
                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                          double[] main = new double[]{5.0};
                                                                                                                                                                                                                          double[] secondary = new double[]{};
                                                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-12);
                                                                                                                                                                                                                          double[] work = new double[6 * main.length];
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to set private field
                                                                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                                                                          workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                                          Method computeGershgorinCircles = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                                          computeGershgorinCircles.setAccessible(true);
                                                                                                                                                                                                                          computeGershgorinCircles.invoke(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to get private fields for verification
                                                                                                                                                                                                                          Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                                          lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                                          double lowerSpectra = (Double) lowerSpectraField.get(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                                          upperSpectraField.setAccessible(true);
                                                                                                                                                                                                                          double upperSpectra = (Double) upperSpectraField.get(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                                          assertEquals(5.0, lowerSpectra, 1e-10);
                                                                                                                                                                                                                          assertEquals(5.0, upperSpectra, 1e-10);
                                                                                                                                                                                                                          assertEquals(5.0, work[4], 1e-10); // lowerStart + 0
                                                                                                                                                                                                                          assertEquals(5.0, work[5], 1e-10); // upperStart + 0
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                      public void testComputeGershgorinCircles_ZeroSecondaryElements() throws Exception {
                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                          double[] main = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                                                                          double[] secondary = new double[]{0.0, 0.0};
                                                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-12);
                                                                                                                                                                                                                          double[] work = new double[6 * main.length];
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to set private field
                                                                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                                                                          workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                                          Method computeGershgorinCircles = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                                          computeGershgorinCircles.setAccessible(true);
                                                                                                                                                                                                                          computeGershgorinCircles.invoke(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                                          Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                                          lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                                          double lowerSpectra = (Double) lowerSpectraField.get(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                                          upperSpectraField.setAccessible(true);
                                                                                                                                                                                                                          double upperSpectra = (Double) upperSpectraField.get(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          assertEquals(1.0, lowerSpectra, 1e-10);
                                                                                                                                                                                                                          assertEquals(3.0, upperSpectra, 1e-10);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          int m = main.length;
                                                                                                                                                                                                                          for (int i = 0; i < m; i++) {
                                                                                                                                                                                                                              assertEquals(main[i], work[4*m + i], 1e-10); // lower = main[i] - 0
                                                                                                                                                                                                                              assertEquals(main[i], work[5*m + i], 1e-10); // upper = main[i] + 0
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                      public void testComputeGershgorinCircles_LargeValues() throws Exception {
                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                          double[] main = new double[]{1.0e100, 2.0e100, 3.0e100};
                                                                                                                                                                                                                          double[] secondary = new double[]{0.5e100, 1.5e100};
                                                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-12);
                                                                                                                                                                                                                          double[] work = new double[6 * main.length];
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to set private field
                                                                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                                                                          workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                                          Method computeGershgorinCircles = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                                          computeGershgorinCircles.setAccessible(true);
                                                                                                                                                                                                                          computeGershgorinCircles.invoke(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to get private fields for verification
                                                                                                                                                                                                                          Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                                          lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                                          double lowerSpectra = lowerSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                                          upperSpectraField.setAccessible(true);
                                                                                                                                                                                                                          double upperSpectra = upperSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                                          assertEquals(0.0, lowerSpectra / 1.0e100, 1e-10);
                                                                                                                                                                                                                          assertEquals(4.5, upperSpectra / 1.0e100, 1e-10);
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                      public void testProcessGeneralBlock_AlreadyDiagonalMatrix() throws Exception {
                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                          double[] work = {1.0, 0.0, 0.0, 0.0,   // First row (diagonal element + zeros)
                                                                                                                                                                                                                                           2.0, 0.0, 0.0, 0.0};  // Second row (diagonal element + zeros)
                                                                                                                                                                                                                          EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1.0, 2.0}, new double[1], 1e-6);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to set private work field
                                                                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                                                                          workField.set(decomposition, work);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to access private processGeneralBlock method
                                                                                                                                                                                                                          Method processGeneralBlockMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                                          processGeneralBlockMethod.setAccessible(true);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Execute - should return immediately as matrix is already diagonal
                                                                                                                                                                                                                          processGeneralBlockMethod.invoke(decomposition, 2);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify no changes were made to work array
                                                                                                                                                                                                                          assertEquals(1.0, work[0], 0.0);
                                                                                                                                                                                                                          assertEquals(0.0, work[2], 0.0);
                                                                                                                                                                                                                          assertEquals(2.0, work[4], 0.0);
                                                                                                                                                                                                                          assertEquals(0.0, work[6], 0.0);
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                      public void testProcessGeneralBlock_InitialStateSetup() throws Exception {
                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                          double[] work = {1.0, 0.0, 0.5, 0.0,   // First row with off-diagonal
                                                                                                                                                                                                                                           2.0, 0.0, 0.3, 0.0};  // Second row with off-diagonal
                                                                                                                                                                                                                          EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1.0, 2.0}, new double[]{0.5, 0.3}, 1e-6);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Set private work field using reflection
                                                                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                                                                          workField.set(decomposition, work);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Get private processGeneralBlock method using reflection
                                                                                                                                                                                                                          Method processGeneralBlockMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                                          processGeneralBlockMethod.setAccessible(true);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                                          processGeneralBlockMethod.invoke(decomposition, 2);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify initial state was set correctly using reflection
                                                                                                                                                                                                                          Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                          tTypeField.setAccessible(true);
                                                                                                                                                                                                                          assertEquals(0, tTypeField.getInt(decomposition));
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                                                                                                          dMin1Field.setAccessible(true);
                                                                                                                                                                                                                          assertEquals(0.0, dMin1Field.getDouble(decomposition), 0.0);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                                                                                                                          dMin2Field.setAccessible(true);
                                                                                                                                                                                                                          assertEquals(0.0, dMin2Field.getDouble(decomposition), 0.0);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                                                                                          dNField.setAccessible(true);
                                                                                                                                                                                                                          assertEquals(0.0, dNField.getDouble(decomposition), 0.0);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                                                                                          dN1Field.setAccessible(true);
                                                                                                                                                                                                                          assertEquals(0.0, dN1Field.getDouble(decomposition), 0.0);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                                                          dN2Field.setAccessible(true);
                                                                                                                                                                                                                          assertEquals(0.0, dN2Field.getDouble(decomposition), 0.0);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                          tauField.setAccessible(true);
                                                                                                                                                                                                                          assertEquals(0.0, tauField.getDouble(decomposition), 0.0);
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                  public void testComputeGershgorinCircles_TypicalCase() {
                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                      double[] main = {1.0, 2.0, 3.0}; // Example main diagonal values
                                                                                                                                                                                                                      double[] secondary = {0.5, 1.5}; // Example secondary diagonal values
                                                                                                                                                                                                                      double splitTolerance = 1.0e-10;
                                                                                                                                                                                                                      EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      double[] expectedLower = {0.0, 0.0, 1.5}; // 1-0.5-0, 2-0.5-1.5, 3-1.5
                                                                                                                                                                                                                      double[] expectedUpper = {2.0, 4.0, 4.5}; // 1+0.5+0, 2+0.5+1.5, 3+1.5
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Use reflection to access private fields and methods
                                                                                                                                                                                                                      try {
                                                                                                                                                                                                                          // Get private fields
                                                                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                                                                          double[] work = (double[]) workField.get(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                                          lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                                          upperSpectraField.setAccessible(true);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Get and invoke private method
                                                                                                                                                                                                                          Method computeGershgorinCirclesMethod = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                                          computeGershgorinCirclesMethod.setAccessible(true);
                                                                                                                                                                                                                          computeGershgorinCirclesMethod.invoke(eigenDecomposition);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                                          assertEquals(0.0, lowerSpectraField.getDouble(eigenDecomposition), 1e-10);
                                                                                                                                                                                                                          assertEquals(4.5, upperSpectraField.getDouble(eigenDecomposition), 1e-10);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Check work array values
                                                                                                                                                                                                                          int m = main.length;
                                                                                                                                                                                                                          for (int i = 0; i < m; i++) {
                                                                                                                                                                                                                              assertEquals(expectedLower[i], work[4*m + i], 1e-10);
                                                                                                                                                                                                                              assertEquals(expectedUpper[i], work[5*m + i], 1e-10);
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                                                                                          fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                  public void testComputeGershgorinCircles_MinPivotCalculation() throws Exception {
                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                      double[] main = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                                                                      double[] secondary = new double[]{1.0e-150, 1.0e-150}; // Very small secondary values
                                                                                                                                                                                                                      EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-12);
                                                                                                                                                                                                                      double[] work = new double[6 * main.length];
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Use reflection to set private field
                                                                                                                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                                                                                      workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Use reflection to access private method
                                                                                                                                                                                                                      Method computeGershgorinCircles = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                                      computeGershgorinCircles.setAccessible(true);
                                                                                                                                                                                                                      computeGershgorinCircles.invoke(eigenDecomposition);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Get minPivot field using reflection
                                                                                                                                                                                                                      Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                                                      minPivotField.setAccessible(true);
                                                                                                                                                                                                                      double minPivot = minPivotField.getDouble(eigenDecomposition);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Verify minPivot is properly calculated considering SAFE_MIN
                                                                                                                                                                                                                      assertTrue(minPivot > 0);
                                                                                                                                                                                                                      assertTrue(minPivot <= MathUtils.SAFE_MIN * 1.0e-300);
                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                              public void testComputeShiftIncrement_NegativeDMin() {
                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                  double[] main = new double[11]; // length needs to be > end index (10)
                                                                                                                                                                                                                  double[] secondary = new double[10];
                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to set private fields since they're not publicly accessible
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                                      dMinField.setAccessible(true);
                                                                                                                                                                                                                      dMinField.set(eigenDecomposition, -1.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                      tauField.setAccessible(true);
                                                                                                                                                                                                                      tauField.set(eigenDecomposition, 0.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                      tTypeField.setAccessible(true);
                                                                                                                                                                                                                      tTypeField.set(eigenDecomposition, 0);
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      fail("Failed to set fields via reflection: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Execute - use reflection to call private method
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                          "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                      computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                                                      computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      fail("Failed to invoke computeShiftIncrement via reflection: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                      tauField.setAccessible(true);
                                                                                                                                                                                                                      double tau = (Double) tauField.get(eigenDecomposition);
                                                                                                                                                                                                                      assertEquals(1.0, tau, 0.0001);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                      tTypeField.setAccessible(true);
                                                                                                                                                                                                                      int tType = (Integer) tTypeField.get(eigenDecomposition);
                                                                                                                                                                                                                      assertEquals(-1, tType);
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      fail("Failed to get fields via reflection: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testComputeShiftIncrement_Case() {
                                                                                                                                                                                                                  // Create eigenDecomposition instance with required constructor parameters
                                                                                                                                                                                                                  double[] main = new double[10];
                                                                                                                                                                                                                  double[] secondary = new double[9];
                                                                                                                                                                                                                  double splitTolerance = 0.0;
                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      // Set private fields using reflection
                                                                                                                                                                                                                      Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                                      dMinField.setAccessible(true);
                                                                                                                                                                                                                      dMinField.set(eigenDecomposition, 1.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                                                                                      dNField.setAccessible(true);
                                                                                                                                                                                                                      dNField.set(eigenDecomposition, 1.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                                                                                                      dMin1Field.setAccessible(true);
                                                                                                                                                                                                                      dMin1Field.set(eigenDecomposition, 2.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                                                                                      dN1Field.setAccessible(true);
                                                                                                                                                                                                                      dN1Field.set(eigenDecomposition, 2.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                                                                                                                      dMin2Field.setAccessible(true);
                                                                                                                                                                                                                      dMin2Field.set(eigenDecomposition, 3.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                                                      dN2Field.setAccessible(true);
                                                                                                                                                                                                                      dN2Field.set(eigenDecomposition, 3.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                                                                                                                      pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                                                                      endField.setAccessible(true);
                                                                                                                                                                                                                      endField.set(eigenDecomposition, 10);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Initialize work array
                                                                                                                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                                                                                      double[] work = new double[4 * 10];
                                                                                                                                                                                                                      workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Setup work array values needed for this case
                                                                                                                                                                                                                      int nn = 4 * 10 + 0 - 1;
                                                                                                                                                                                                                      work[nn - 3] = 4.0;  // sqrt(4)*sqrt(16) = 2*4 = 8
                                                                                                                                                                                                                      work[nn - 5] = 16.0;
                                                                                                                                                                                                                      work[nn - 7] = 9.0;  // sqrt(9)*sqrt(25) = 3*5 = 15
                                                                                                                                                                                                                      work[nn - 9] = 25.0;
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Get and invoke private method
                                                                                                                                                                                                                      Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                          "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                      computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                                                      computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Verify results
                                                                                                                                                                                                                      Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                      tauField.setAccessible(true);
                                                                                                                                                                                                                      double tau = (Double)tauField.get(eigenDecomposition);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                      tTypeField.setAccessible(true);
                                                                                                                                                                                                                      int tType = (Integer)tTypeField.get(eigenDecomposition);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      assertEquals(0.333, tau, 0.001);
                                                                                                                                                                                                                      assertEquals(-3, tType);
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      fail("Failed to access private field or method: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testComputeShiftIncrement_Case1() throws Exception {
                                                                                                                                                                                                                  // Create EigenDecompositionImpl instance with required parameters
                                                                                                                                                                                                                  double[] main = new double[10];
                                                                                                                                                                                                                  double[] secondary = new double[9];
                                                                                                                                                                                                                  double splitTolerance = 1.0e-6;
                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to access private fields
                                                                                                                                                                                                                  Class<?> clazz = eigenDecomposition.getClass();
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set private fields
                                                                                                                                                                                                                  Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                                                                  dMinField.setAccessible(true);
                                                                                                                                                                                                                  dMinField.set(eigenDecomposition, 1.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field dNField = clazz.getDeclaredField("dN");
                                                                                                                                                                                                                  dNField.setAccessible(true);
                                                                                                                                                                                                                  dNField.set(eigenDecomposition, 1.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                                                                                                                                                  dMin1Field.setAccessible(true);
                                                                                                                                                                                                                  dMin1Field.set(eigenDecomposition, 2.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field dN1Field = clazz.getDeclaredField("dN1");
                                                                                                                                                                                                                  dN1Field.setAccessible(true);
                                                                                                                                                                                                                  dN1Field.set(eigenDecomposition, 3.0); // Different to trigger case 4
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                  pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field endField = clazz.getDeclaredField("end");
                                                                                                                                                                                                                  endField.setAccessible(true);
                                                                                                                                                                                                                  endField.set(eigenDecomposition, 10);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Initialize work array
                                                                                                                                                                                                                  Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                  workField.set(eigenDecomposition, new double[4 * 10]);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Setup work array values
                                                                                                                                                                                                                  int nn = 4 * 10 + 0 - 1;
                                                                                                                                                                                                                  double[] work = (double[]) workField.get(eigenDecomposition);
                                                                                                                                                                                                                  work[nn - 5] = 4.0;
                                                                                                                                                                                                                  work[nn - 7] = 8.0; // work[nn-5] < work[nn-7] to avoid early return
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Execute private method
                                                                                                                                                                                                                  Method computeShiftIncrementMethod = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                  computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                                                  computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                                  assertEquals(-4, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                                  assertTrue(tauField.getDouble(eigenDecomposition) > 0);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testComputeShiftIncrement_Case2() throws Exception {
                                                                                                                                                                                                                  // Initialize eigenDecomposition with required constructor
                                                                                                                                                                                                                  double[] main = new double[10];
                                                                                                                                                                                                                  double[] secondary = new double[9];
                                                                                                                                                                                                                  double splitTolerance = 1.0e-6;
                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get private fields using reflection
                                                                                                                                                                                                                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                                  dMinField.setAccessible(true);
                                                                                                                                                                                                                  Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                                                  dN2Field.setAccessible(true);
                                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                  Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                                                                  endField.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Setup for case 5 (dMin == dN2)
                                                                                                                                                                                                                  dMinField.setDouble(eigenDecomposition, 1.0);
                                                                                                                                                                                                                  dN2Field.setDouble(eigenDecomposition, 1.0);
                                                                                                                                                                                                                  pingPongField.setInt(eigenDecomposition, 0);
                                                                                                                                                                                                                  endField.setInt(eigenDecomposition, 10);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Initialize work array
                                                                                                                                                                                                                  double[] work = new double[4 * (Integer)endField.get(eigenDecomposition)];
                                                                                                                                                                                                                  int np = 4 * 10 + 0 - 1 - 2 * 0;
                                                                                                                                                                                                                  work[np - 2] = 2.0;
                                                                                                                                                                                                                  work[np - 6] = 3.0;
                                                                                                                                                                                                                  work[np - 8] = 1.0; // Must be <= b2 (3.0)
                                                                                                                                                                                                                  work[np - 4] = 1.0;  // Must be <= b1 (2.0)
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set work array in eigenDecomposition using reflection
                                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get private method using reflection
                                                                                                                                                                                                                  Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                      "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                  computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Execute
                                                                                                                                                                                                                  computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify results using reflection
                                                                                                                                                                                                                  Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  assertEquals(-5, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                                                  assertTrue((Double)tauField.getDouble(eigenDecomposition) > 0);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testComputeShiftIncrement_Case3() throws Exception {
                                                                                                                                                                                                                  // Create eigenDecomposition instance with required constructor parameters
                                                                                                                                                                                                                  double[] main = new double[10];
                                                                                                                                                                                                                  double[] secondary = new double[10];
                                                                                                                                                                                                                  double splitTolerance = 0.0;
                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get private fields using reflection
                                                                                                                                                                                                                  Class<?> clazz = EigenDecompositionImpl.class;
                                                                                                                                                                                                                  Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                                                                                                                                                  dMin1Field.setAccessible(true);
                                                                                                                                                                                                                  Field dN1Field = clazz.getDeclaredField("dN1");
                                                                                                                                                                                                                  dN1Field.setAccessible(true);
                                                                                                                                                                                                                  Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                                                                                                                                  dMin2Field.setAccessible(true);
                                                                                                                                                                                                                  Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                                                                  dN2Field.setAccessible(true);
                                                                                                                                                                                                                  Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                  Field endField = clazz.getDeclaredField("end");
                                                                                                                                                                                                                  endField.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set private fields
                                                                                                                                                                                                                  dMin1Field.set(eigenDecomposition, 1.0);
                                                                                                                                                                                                                  dN1Field.set(eigenDecomposition, 1.0);
                                                                                                                                                                                                                  dMin2Field.set(eigenDecomposition, 2.0);
                                                                                                                                                                                                                  dN2Field.set(eigenDecomposition, 2.0);
                                                                                                                                                                                                                  pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                                                                  endField.set(eigenDecomposition, 10);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Setup work array
                                                                                                                                                                                                                  Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                  double[] work = new double[4 * 10]; // Size based on nn calculation
                                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Setup work array values
                                                                                                                                                                                                                  int nn = 4 * 10 + 0 - 1;
                                                                                                                                                                                                                  work[nn - 5] = 2.0;
                                                                                                                                                                                                                  work[nn - 7] = 4.0; // work[nn-5] < work[nn-7] to avoid early return
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get and invoke private method
                                                                                                                                                                                                                  Method computeShiftIncrementMethod = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                  computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                                                  computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 1);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify results
                                                                                                                                                                                                                  Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                                  int tType = (int) tTypeField.get(eigenDecomposition);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                                  double tau = (double) tauField.get(eigenDecomposition);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  assertEquals(-7, tType);
                                                                                                                                                                                                                  assertTrue(tau > 0);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testComputeShiftIncrement_Case4() throws Exception {
                                                                                                                                                                                                                  // Initialize EigenDecompositionImpl with required parameters
                                                                                                                                                                                                                  double[] main = new double[10];
                                                                                                                                                                                                                  double[] secondary = new double[10];
                                                                                                                                                                                                                  double splitTolerance = 1.0e-6;
                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Initialize work array
                                                                                                                                                                                                                  double[] work = new double[4 * 10];
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                                                                                  Class<?> clazz = EigenDecompositionImpl.class;
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set dMin2
                                                                                                                                                                                                                  Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                                                                                                                                  dMin2Field.setAccessible(true);
                                                                                                                                                                                                                  dMin2Field.set(eigenDecomposition, 1.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set dN2
                                                                                                                                                                                                                  Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                                                                  dN2Field.setAccessible(true);
                                                                                                                                                                                                                  dN2Field.set(eigenDecomposition, 1.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set pingPong
                                                                                                                                                                                                                  Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                  pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set end
                                                                                                                                                                                                                  Field endField = clazz.getDeclaredField("end");
                                                                                                                                                                                                                  endField.setAccessible(true);
                                                                                                                                                                                                                  endField.set(eigenDecomposition, 10);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Setup work array values
                                                                                                                                                                                                                  int nn = 4 * 10 + 0 - 1;
                                                                                                                                                                                                                  work[nn - 5] = 2.0;
                                                                                                                                                                                                                  work[nn - 7] = 5.0; // 2*2 < 5 to trigger case 10
                                                                                                                                                                                                                  work[nn - 9] = 3.0;
                                                                                                                                                                                                                  work[nn - 11] = 4.0;
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set work array
                                                                                                                                                                                                                  Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get computeShiftIncrement method
                                                                                                                                                                                                                  Method computeShiftIncrementMethod = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                  computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Execute
                                                                                                                                                                                                                  computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 2);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  // Get tType field
                                                                                                                                                                                                                  Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                                  int tType = (int) tTypeField.get(eigenDecomposition);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get tau field
                                                                                                                                                                                                                  Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                                  double tau = (double) tauField.get(eigenDecomposition);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  assertEquals(-10, tType);
                                                                                                                                                                                                                  assertTrue(tau > 0);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testComputeShiftIncrement_Case5() {
                                                                                                                                                                                                                  // Setup for case 12 (deflated > 2)
                                                                                                                                                                                                                  double[] main = new double[11]; // Need at least 11 elements since end=10 is used
                                                                                                                                                                                                                  double[] secondary = new double[10];
                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set required field using reflection since dMin is private
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                                      dMinField.setAccessible(true);
                                                                                                                                                                                                                      dMinField.set(eigenDecomposition, 1.0);
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      fail("Failed to set dMin field: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Execute computeShiftIncrement using reflection since it's private
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                          "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                      computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                                                      computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 3);
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      fail("Failed to invoke computeShiftIncrement: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify results using reflection since tType and tau are private
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                      tTypeField.setAccessible(true);
                                                                                                                                                                                                                      int tType = (int) tTypeField.get(eigenDecomposition);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                      tauField.setAccessible(true);
                                                                                                                                                                                                                      double tau = (double) tauField.get(eigenDecomposition);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Expected:
                                                                                                                                                                                                                      // tType should be -12
                                                                                                                                                                                                                      // tau should be 0.0
                                                                                                                                                                                                                      assertEquals(-12, tType);
                                                                                                                                                                                                                      assertEquals(0.0, tau, 0.0001);
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      fail("Failed to verify results: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testComputeShiftIncrement_Case6() {
                                                                                                                                                                                                                  // Initialize EigenDecompositionImpl with required parameters
                                                                                                                                                                                                                  double[] main = new double[0];
                                                                                                                                                                                                                  double[] secondary = new double[0];
                                                                                                                                                                                                                  double splitTolerance = 0.0;
                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to set private fields since they're not publicly accessible
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                                      dMinField.setAccessible(true);
                                                                                                                                                                                                                      dMinField.set(eigenDecomposition, 1.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                                                                                      dNField.setAccessible(true);
                                                                                                                                                                                                                      dNField.set(eigenDecomposition, 2.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                                                                                      dN1Field.setAccessible(true);
                                                                                                                                                                                                                      dN1Field.set(eigenDecomposition, 3.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                                                      dN2Field.setAccessible(true);
                                                                                                                                                                                                                      dN2Field.set(eigenDecomposition, 4.0);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                      tTypeField.setAccessible(true);
                                                                                                                                                                                                                      tTypeField.set(eigenDecomposition, -6);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field gField = EigenDecompositionImpl.class.getDeclaredField("g");
                                                                                                                                                                                                                      gField.setAccessible(true);
                                                                                                                                                                                                                      gField.set(eigenDecomposition, 0.5);
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      fail("Failed to set field values via reflection: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Execute using reflection to access private method
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                          "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                      computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                                                      computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      fail("Failed to invoke computeShiftIncrement via reflection: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                      tTypeField.setAccessible(true);
                                                                                                                                                                                                                      assertEquals(-6, tTypeField.get(eigenDecomposition));
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                      tauField.setAccessible(true);
                                                                                                                                                                                                                      assertEquals(0.666, (Double)tauField.get(eigenDecomposition), 0.001);
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      fail("Failed to verify field values via reflection: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testProcessGeneralBlock_MaxIterationsExceeded() throws Exception {
                                                                                                                                                                                                                  // Setup - matrix that will require many iterations
                                                                                                                                                                                                                  double[] work = {1.0, 0.0, 1.0, 0.0,   // First row with large off-diagonal
                                                                                                                                                                                                                                   1.0, 0.0, 1.0, 0.0,   // Second row with large off-diagonal
                                                                                                                                                                                                                                   1.0, 0.0, 1.0, 0.0};  // Third row with large off-diagonal
                                                                                                                                                                                                                  EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1.0, 1.0, 1.0}, new double[]{1.0, 1.0}, 1e-6);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set private work field using reflection
                                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                  workField.set(decomposition, work);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set up test to force max iterations
                                                                                                                                                                                                                  // We'll modify the iteration count directly through reflection
                                                                                                                                                                                                                  Field iterationsField = EigenDecompositionImpl.class.getDeclaredField("iterations");
                                                                                                                                                                                                                  iterationsField.setAccessible(true);
                                                                                                                                                                                                                  iterationsField.set(decomposition, Integer.MAX_VALUE);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Expect exception
                                                                                                                                                                                                                  ExpectedException exception = ExpectedException.none();
                                                                                                                                                                                                                  exception.expect(InvalidMatrixException.class);
                                                                                                                                                                                                                  exception.expectMessage("MaxIterationsExceededException");
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Execute private method using reflection
                                                                                                                                                                                                                  Method processGeneralBlockMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                                  processGeneralBlockMethod.setAccessible(true);
                                                                                                                                                                                                                  processGeneralBlockMethod.invoke(decomposition, 3);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                      public void testProcessGeneralBlock_WithSplits() throws Exception {
                                                                                                                                                                                                          // Setup - matrix that will trigger splits
                                                                                                                                                                                                          double[] work = {1.0, 0.0, 1e-10, 0.0,   // First row with tiny off-diagonal
                                                                                                                                                                                                                           2.0, 0.0, 1e-10, 0.0,   // Second row with tiny off-diagonal
                                                                                                                                                                                                                           3.0, 0.0, 1e-10, 0.0};  // Third row with tiny off-diagonal
                                                                                                                                                                                                          EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1.0, 2.0, 3.0}, new double[]{1e-10, 1e-10}, 1e-6);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to set private fields
                                                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                                                          workField.set(decomposition, work);
                                                                                                                                                                                                          
                                                                                                                                                                                                          Field toleranceField = EigenDecompositionImpl.class.getDeclaredField("TOLERANCE_2");
                                                                                                                                                                                                          toleranceField.setAccessible(true);
                                                                                                                                                                                                          toleranceField.set(decomposition, 1e-8);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                          Method processMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                          processMethod.setAccessible(true);
                                                                                                                                                                                                          processMethod.invoke(decomposition, 3);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify sigma was updated
                                                                                                                                                                                                          Field sigmaField = EigenDecompositionImpl.class.getDeclaredField("sigma");
                                                                                                                                                                                                          sigmaField.setAccessible(true);
                                                                                                                                                                                                          double sigma = (Double) sigmaField.get(decomposition);
                                                                                                                                                                                                          assertEquals(-1e-10, sigma, 1e-12);
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                              public void testProcessGeneralBlock_WithPingPongBehavior() throws Exception {
                                                                                                                                                                                                  // Setup - matrix that will trigger ping-pong behavior
                                                                                                                                                                                                  double[] work = {1.0, 0.0, 0.5, 0.0,   // First row with off-diagonal
                                                                                                                                                                                                                   1.0, 0.0, 0.5, 0.0,   // Second row with off-diagonal
                                                                                                                                                                                                                   1.0, 0.0, 0.5, 0.0};  // Third row with off-diagonal
                                                                                                                                                                                                  EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1.0, 1.0, 1.0}, new double[]{0.5, 0.5}, 1e-6);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Set private work field using reflection
                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  workField.set(decomposition, work);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create a spy of the decomposition
                                                                                                                                                                                                  EigenDecompositionImpl spy = spy(decomposition);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Instead of trying to mock the private goodStep method, we'll set up the conditions
                                                                                                                                                                                                  // that will make it behave as we want through reflection
                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                  pingPongField.set(spy, 0); // Initial ping-pong value
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Get private processGeneralBlock method
                                                                                                                                                                                                  Method processGeneralBlockMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                  processGeneralBlockMethod.setAccessible(true);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Execute
                                                                                                                                                                                                  processGeneralBlockMethod.invoke(spy, 3);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify ping-pong behavior (0 -> 1 -> 0)
                                                                                                                                                                                                  int pingPongValue = (int) pingPongField.get(spy);
                                                                                                                                                                                                  assertEquals(0, pingPongValue);
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                  public void testProcessGeneralBlock_NonDiagonalMatrix() throws Exception {
                                                                                                                                                                                      // Setup - matrix with off-diagonal elements
                                                                                                                                                                                      double[] work = {1.0, 0.0, 0.5, 0.0,   // First row with off-diagonal element
                                                                                                                                                                                                       2.0, 0.0, 0.0, 0.0};  // Second row (diagonal element + zeros)
                                                                                                                                                                                      EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1.0, 2.0}, new double[]{0.5}, 1e-6);
                                                                                                                                                                                      
                                                                                                                                                                                      // Set private work field using reflection
                                                                                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                                                      workField.set(decomposition, work);
                                                                                                                                                                                      
                                                                                                                                                                                      // Create spy
                                                                                                                                                                                      EigenDecompositionImpl spy = spy(decomposition);
                                                                                                                                                                                      
                                                                                                                                                                                      // Get method references for verification
                                                                                                                                                                                      Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                      flipMethod.setAccessible(true);
                                                                                                                                                                                      
                                                                                                                                                                                      Method splitsMethod = EigenDecompositionImpl.class.getDeclaredMethod("initialSplits", int.class);
                                                                                                                                                                                      splitsMethod.setAccessible(true);
                                                                                                                                                                                      
                                                                                                                                                                                      Method goodStepMethod = EigenDecompositionImpl.class.getDeclaredMethod("goodStep", int.class, int.class);
                                                                                                                                                                                      goodStepMethod.setAccessible(true);
                                                                                                                                                                                      
                                                                                                                                                                                      // Execute processGeneralBlock using reflection
                                                                                                                                                                                      Method processMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                      processMethod.setAccessible(true);
                                                                                                                                                                                      processMethod.invoke(spy, 2);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify helper methods were called using reflection
                                                                                                                                                                                      flipMethod.invoke(spy, anyInt(), anyInt());
                                                                                                                                                                                      splitsMethod.invoke(spy, anyInt());
                                                                                                                                                                                      goodStepMethod.invoke(spy, anyInt(), anyInt());
                                                                                                                                                                                      
                                                                                                                                                                                      // Alternative verification approach since we can't verify private method calls directly
                                                                                                                                                                                      // We can verify the effects of these methods instead
                                                                                                                                                                                      // For example, check if the work array was modified as expected
                                                                                                                                                                                      double[] modifiedWork = (double[]) workField.get(spy);
                                                                                                                                                                                      assertNotNull(modifiedWork);
                                                                                                                                                                                      // Add more assertions based on expected behavior
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                             public void testComputeShiftIncrementCase5DetectsDivisionMutant() throws Exception {
                                                                                                                                                                                 // Setup test case for case 5 where dMin == dN2 and deflated == 0
                                                                                                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                                                                                 
                                                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                                                 Class<?> clazz = eigen.getClass();
                                                                                                                                                                                 
                                                                                                                                                                                 // Set required field values to enter case 5
                                                                                                                                                                                 Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                                 dMinField.setAccessible(true);
                                                                                                                                                                                 dMinField.set(eigen, 4.0);
                                                                                                                                                                                 
                                                                                                                                                                                 Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                                 dN2Field.setAccessible(true);
                                                                                                                                                                                 dN2Field.set(eigen, 4.0);  // dMin == dN2
                                                                                                                                                                                 
                                                                                                                                                                                 Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                                                                 pingPongField.set(eigen, 0);
                                                                                                                                                                                 
                                                                                                                                                                                 // Setup work array values that will make the division vs multiplication difference obvious
                                                                                                                                                                                 // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*10 + 0 -1 -0 = 39
                                                                                                                                                                                 // So np-8 = 31, np-4 = 35, np-2 = 37, np-6 = 33
                                                                                                                                                                                 double[] work = new double[40];
                                                                                                                                                                                 work[31] = 10.0;  // work[np-8]
                                                                                                                                                                                 work[33] = 2.0;   // work[np-6] = b2
                                                                                                                                                                                 work[35] = 6.0;   // work[np-4]
                                                                                                                                                                                 work[37] = 3.0;   // work[np-2] = b1
                                                                                                                                                                                 
                                                                                                                                                                                 // Set other required fields
                                                                                                                                                                                 Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                                 workField.setAccessible(true);
                                                                                                                                                                                 workField.set(eigen, work);
                                                                                                                                                                                 
                                                                                                                                                                                 Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                 tTypeField.setAccessible(true);
                                                                                                                                                                                 tTypeField.set(eigen, 0);
                                                                                                                                                                                 
                                                                                                                                                                                 // Call the private method
                                                                                                                                                                                 Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                 computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                 computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify results - original calculation:
                                                                                                                                                                                 // b1 = 3.0, b2 = 2.0
                                                                                                                                                                                 // a2 = (10.0/2.0) * (1 + 6.0/3.0) = 5.0 * 3.0 = 15.0
                                                                                                                                                                                 // Then in the code, a2 gets multiplied by cnst3 (1.05) later
                                                                                                                                                                                 // Since a2 (15.75) > cnst1 (0.563), tau should be s (0.25 * dMin = 1.0)
                                                                                                                                                                                 Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                 tauField.setAccessible(true);
                                                                                                                                                                                 assertEquals(1.0, (Double)tauField.get(eigen), 1e-10);
                                                                                                                                                                                 
                                                                                                                                                                                 assertEquals(-5, tTypeField.get(eigen));
                                                                                                                                                                                 
                                                                                                                                                                                 // The mutant would calculate:
                                                                                                                                                                                 // a2 = (10.0*2.0) * (1 + 6.0/3.0) = 20.0 * 3.0 = 60.0
                                                                                                                                                                                 // Which would lead to different behavior and likely different tau
                                                                                                                                                                             }

    @Test
                                                                                                                                                                        public void testComputeShiftIncrementCase5DetectsMutant() throws Exception {
                                                                                                                                                                            // Setup test data to trigger case 5 (dMin == dN2 and deflated=0)
                                                                                                                                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set private fields
                                                                                                                                                                            Class<?> clazz = eigen.getClass();
                                                                                                                                                                            
                                                                                                                                                                            // Set dMin
                                                                                                                                                                            Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                            dMinField.setAccessible(true);
                                                                                                                                                                            dMinField.set(eigen, 4.0);
                                                                                                                                                                            
                                                                                                                                                                            // Set dN2
                                                                                                                                                                            Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                            dN2Field.setAccessible(true);
                                                                                                                                                                            dN2Field.set(eigen, 4.0);
                                                                                                                                                                            
                                                                                                                                                                            // Set pingPong
                                                                                                                                                                            Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                            pingPongField.setAccessible(true);
                                                                                                                                                                            pingPongField.set(eigen, 1);
                                                                                                                                                                            
                                                                                                                                                                            // Set work array
                                                                                                                                                                            double[] work = new double[20];
                                                                                                                                                                            work[10] = 2.0;  // work[np-8]
                                                                                                                                                                            work[12] = 1.0;  // b2
                                                                                                                                                                            work[14] = 0.5;  // work[np-4]
                                                                                                                                                                            work[16] = 1.0;  // b1
                                                                                                                                                                            Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                            workField.setAccessible(true);
                                                                                                                                                                            workField.set(eigen, work);
                                                                                                                                                                            
                                                                                                                                                                            // Call the private method using reflection
                                                                                                                                                                            Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                            computeShiftIncrement.setAccessible(true);
                                                                                                                                                                            computeShiftIncrement.invoke(eigen, 0, 5, 0);
                                                                                                                                                                            
                                                                                                                                                                            // Calculate expected a2 value (original version)
                                                                                                                                                                            double expectedA2 = (work[10] / work[12]) * (1 + work[14] / work[16]);
                                                                                                                                                                            expectedA2 = 2.0 * (1 + 0.5);  // = 3.0
                                                                                                                                                                            
                                                                                                                                                                            // Verify the calculated tau
                                                                                                                                                                            Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                            tauField.setAccessible(true);
                                                                                                                                                                            double tau = (Double) tauField.get(eigen);
                                                                                                                                                                            assertEquals(1.0, tau, 1e-10);
                                                                                                                                                                            
                                                                                                                                                                            // Verify tType was set correctly for case 5
                                                                                                                                                                            Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                            tTypeField.setAccessible(true);
                                                                                                                                                                            int tType = (Integer) tTypeField.get(eigen);
                                                                                                                                                                            assertEquals(-5, tType);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                    public void testComputeShiftIncrementCase5DetectsMutant1() {
                                                                                                                                                                        // Setup test data to trigger case 5
                                                                                                                                                                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to set private fields since we need to test a private method
                                                                                                                                                                        try {
                                                                                                                                                                            // Set fields needed for case 5
                                                                                                                                                                            Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                            dMinField.setAccessible(true);
                                                                                                                                                                            dMinField.set(eigen, 10.0); // dMin
                                                                                                                                                                            
                                                                                                                                                                            Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                            dN2Field.setAccessible(true);
                                                                                                                                                                            dN2Field.set(eigen, 10.0); // dMin == dN2
                                                                                                                                                                            
                                                                                                                                                                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                            workField.setAccessible(true);
                                                                                                                                                                            // Setup work array values that will make multiplication and addition produce different results
                                                                                                                                                                            // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*end - pingPong - 1
                                                                                                                                                                            // For simplicity, set end=2, pingPong=0 => np=7
                                                                                                                                                                            double[] work = new double[20];
                                                                                                                                                                            work[7-8] = 4.0; // work[np-8]
                                                                                                                                                                            work[7-6] = 2.0; // work[np-6]
                                                                                                                                                                            work[7-4] = 3.0; // work[np-4]
                                                                                                                                                                            work[7-2] = 1.0; // work[np-2]
                                                                                                                                                                            workField.set(eigen, work);
                                                                                                                                                                            
                                                                                                                                                                            Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                            endField.setAccessible(true);
                                                                                                                                                                            endField.set(eigen, 2);
                                                                                                                                                                            
                                                                                                                                                                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                            pingPongField.setAccessible(true);
                                                                                                                                                                            pingPongField.set(eigen, 0);
                                                                                                                                                                            
                                                                                                                                                                            // Get the method
                                                                                                                                                                            Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                                                                int.class, int.class, int.class);
                                                                                                                                                                            method.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Call the method (deflated=0 for case 5)
                                                                                                                                                                            method.invoke(eigen, 0, 2, 0);
                                                                                                                                                                            
                                                                                                                                                                            // Verify results
                                                                                                                                                                            Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                            tauField.setAccessible(true);
                                                                                                                                                                            double tau = tauField.getDouble(eigen);
                                                                                                                                                                            
                                                                                                                                                                            // Calculate expected value based on original formula
                                                                                                                                                                            double b1 = work[7-2]; // 1.0
                                                                                                                                                                            double b2 = work[7-6]; // 2.0
                                                                                                                                                                            double expectedA2 = (work[7-8]/b2) * (1 + work[7-4]/b1); // (4/2)*(1+3/1) = 2*4 = 8
                                                                                                                                                                            double expectedTau;
                                                                                                                                                                            if (expectedA2 < 0.563) { // cnst1
                                                                                                                                                                                expectedTau = 10.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                                                                            } else {
                                                                                                                                                                                expectedTau = 0.25 * 10.0; // s = 0.25 * dMin
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            // Assert the tau value matches expected calculation
                                                                                                                                                                            assertEquals("Tau value should match expected calculation", expectedTau, tau, 1e-10);
                                                                                                                                                                            
                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                            fail("Exception during test: " + e.getMessage());
                                                                                                                                                                        }
                                                                                                                                                                    }

    @Test
                                                                                                                                                                  public void testComputeShiftIncrementCase5DetectsMutant2() throws Exception {
                                                                                                                                                                      // Setup test case for case 5 (dMin == dN2)
                                                                                                                                                                      EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                                      Class<?> clazz = eigen.getClass();
                                                                                                                                                                      
                                                                                                                                                                      // Set required field values for case 5
                                                                                                                                                                      Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                      dMinField.setAccessible(true);
                                                                                                                                                                      dMinField.setDouble(eigen, 4.0);
                                                                                                                                                                      
                                                                                                                                                                      Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                      dN2Field.setAccessible(true);
                                                                                                                                                                      dN2Field.setDouble(eigen, 4.0);  // dMin == dN2 triggers case 5
                                                                                                                                                                      
                                                                                                                                                                      Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                      tTypeField.setAccessible(true);
                                                                                                                                                                      tTypeField.setInt(eigen, 0);   // Reset type
                                                                                                                                                                      
                                                                                                                                                                      Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                                                                      pingPongField.setInt(eigen, 0);
                                                                                                                                                                      
                                                                                                                                                                      // Setup work array with specific values where b1 ≠ b2
                                                                                                                                                                      // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*end - pingPong - 1
                                                                                                                                                                      // For pingPong=0, np = 4*end - 1
                                                                                                                                                                      // We'll set end=2 (so np=7) and populate work array accordingly
                                                                                                                                                                      int end = 2;
                                                                                                                                                                      Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                                      workField.set(eigen, new double[20]); // Large enough array
                                                                                                                                                                      
                                                                                                                                                                      // Set values that will make the mutation detectable (b1 ≠ b2)
                                                                                                                                                                      // np-2=5, np-6=1, np-8=-1 (but array index must be >=0)
                                                                                                                                                                      // Let's adjust to have all indices positive
                                                                                                                                                                      end = 3; // np = 4*3 - 0 - 1 = 11
                                                                                                                                                                      double[] work = (double[]) workField.get(eigen);
                                                                                                                                                                      work[11-2] = 4.0; // b1 = work[np-2] = work[9] = 4.0
                                                                                                                                                                      work[11-6] = 2.0; // b2 = work[np-6] = work[5] = 2.0
                                                                                                                                                                      work[11-8] = 3.0; // work[np-8] = work[3] = 3.0
                                                                                                                                                                      work[11-4] = 1.0; // work[np-4] = work[7] = 1.0
                                                                                                                                                                      
                                                                                                                                                                      // Calculate expected a2 value for original code
                                                                                                                                                                      double expectedB1 = 4.0;
                                                                                                                                                                      double expectedB2 = 2.0;
                                                                                                                                                                      double expectedA2 = (3.0 / expectedB2) * (1 + 1.0 / expectedB1);
                                                                                                                                                                      
                                                                                                                                                                      // Calculate expected tau (case where a2 < cnst1)
                                                                                                                                                                      double expectedTau;
                                                                                                                                                                      if (expectedA2 < 0.563) { // cnst1 = 0.563
                                                                                                                                                                          expectedTau = 4.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                                                                      } else {
                                                                                                                                                                          expectedTau = 0.25 * 4.0; // s = 0.25 * dMin
                                                                                                                                                                      }
                                                                                                                                                                      
                                                                                                                                                                      // Call private method using reflection
                                                                                                                                                                      Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                      computeShiftIncrement.setAccessible(true);
                                                                                                                                                                      computeShiftIncrement.invoke(eigen, 0, end, 0); // deflated=0 for case 5
                                                                                                                                                                      
                                                                                                                                                                      // Verify results
                                                                                                                                                                      assertEquals(-5, tTypeField.getInt(eigen)); // Should be case 5
                                                                                                                                                                      
                                                                                                                                                                      Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                      tauField.setAccessible(true);
                                                                                                                                                                      assertEquals(expectedTau, tauField.getDouble(eigen), 1e-10);
                                                                                                                                                                      
                                                                                                                                                                      // The mutant would calculate a2 differently:
                                                                                                                                                                      // mutatedA2 = (3.0/4.0) * (1 + 1.0/2.0) = 0.75 * 1.5 = 1.125
                                                                                                                                                                      // Which would be different from expectedA2 = (3.0/2.0)*(1 + 1.0/4.0) = 1.5*1.25 = 1.875
                                                                                                                                                                      // This difference would propagate to tau calculation
                                                                                                                                                                  }

    @Test
                                                                                                                                                             public void testComputeShiftIncrementCase5BoundaryCondition() throws Exception {
                                                                                                                                                                 // Setup
                                                                                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                 
                                                                                                                                                                 // Use reflection to access private fields
                                                                                                                                                                 Class<?> clazz = eigen.getClass();
                                                                                                                                                                 
                                                                                                                                                                 // Set up case 5 conditions (dMin == dN2)
                                                                                                                                                                 Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                 dMinField.setAccessible(true);
                                                                                                                                                                 dMinField.setDouble(eigen, 1.0);
                                                                                                                                                                 
                                                                                                                                                                 Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                 dN2Field.setAccessible(true);
                                                                                                                                                                 dN2Field.setDouble(eigen, 1.0);
                                                                                                                                                                 
                                                                                                                                                                 Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                 tTypeField.setAccessible(true);
                                                                                                                                                                 tTypeField.setInt(eigen, 0);
                                                                                                                                                                 
                                                                                                                                                                 // Set boundary condition (end - start == 3)
                                                                                                                                                                 int start = 0;
                                                                                                                                                                 int end = 3;
                                                                                                                                                                 
                                                                                                                                                                 // Setup work array for case 5
                                                                                                                                                                 Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                 workField.setAccessible(true);
                                                                                                                                                                 double[] work = new double[20];
                                                                                                                                                                 work[0] = 1.0;  // work[np-8]
                                                                                                                                                                 work[1] = 1.0;  // work[np-4]
                                                                                                                                                                 work[2] = 1.0;  // b1 (work[np-2])
                                                                                                                                                                 work[6] = 1.0;  // b2 (work[np-6])
                                                                                                                                                                 workField.set(eigen, work);
                                                                                                                                                                 
                                                                                                                                                                 // Setup pingPong
                                                                                                                                                                 Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                                                 pingPongField.setInt(eigen, 0);
                                                                                                                                                                 
                                                                                                                                                                 // Call private method using reflection
                                                                                                                                                                 Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                 computeShiftIncrement.setAccessible(true);
                                                                                                                                                                 computeShiftIncrement.invoke(eigen, start, end, 0);
                                                                                                                                                                 
                                                                                                                                                                 // Verify behavior - original should skip the block (tau = s = 0.25*dMin)
                                                                                                                                                                 Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                 tauField.setAccessible(true);
                                                                                                                                                                 double tau = tauField.getDouble(eigen);
                                                                                                                                                                 
                                                                                                                                                                 double dMin = dMinField.getDouble(eigen);
                                                                                                                                                                 assertEquals(0.25 * dMin, tau, 1e-10);
                                                                                                                                                                 
                                                                                                                                                                 // Additional verification that we're in case 5
                                                                                                                                                                 int tType = tTypeField.getInt(eigen);
                                                                                                                                                                 assertEquals(-5, tType);
                                                                                                                                                             }

    @Test
                                                                                                                                                         public void testComputeShiftIncrementCase5BoundaryCondition1() {
                                                                                                                                                             // Setup test case where:
                                                                                                                                                             // - deflated = 0 (no eigenvalues deflated)
                                                                                                                                                             // - dMin = dN2 (case 5)
                                                                                                                                                             // - end - start = 3 (boundary case)
                                                                                                                                                             
                                                                                                                                                             // Create instance using constructor that takes main and secondary arrays
                                                                                                                                                             double[] main = new double[20]; // size large enough for our test
                                                                                                                                                             double[] secondary = new double[19];
                                                                                                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(main, secondary, 1.0e-6);
                                                                                                                                                             
                                                                                                                                                             // Set required field values through reflection since they're private
                                                                                                                                                             try {
                                                                                                                                                                 // Set deflated = 0 (case 0)
                                                                                                                                                                 Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                                                                                 deflatedField.setAccessible(true);
                                                                                                                                                                 deflatedField.setInt(eigen, 0);
                                                                                                                                                                 
                                                                                                                                                                 // Set dMin = dN2 (case 5)
                                                                                                                                                                 Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                 dMinField.setAccessible(true);
                                                                                                                                                                 dMinField.setDouble(eigen, 1.0);
                                                                                                                                                                 
                                                                                                                                                                 Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                 dN2Field.setAccessible(true);
                                                                                                                                                                 dN2Field.setDouble(eigen, 1.0);
                                                                                                                                                                 
                                                                                                                                                                 // Set work array values needed for case 5 calculations
                                                                                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                 workField.setAccessible(true);
                                                                                                                                                                 double[] work = new double[20];
                                                                                                                                                                 work[0] = 1.0;  // work[np-8]
                                                                                                                                                                 work[1] = 1.0;  // work[np-4]
                                                                                                                                                                 work[2] = 1.0;  // work[np-2]
                                                                                                                                                                 work[3] = 1.0;  // work[np-6]
                                                                                                                                                                 work[13] = 1.0; // work[nn-13]
                                                                                                                                                                 work[15] = 1.0; // work[nn-15]
                                                                                                                                                                 workField.set(eigen, work);
                                                                                                                                                                 
                                                                                                                                                                 // Set pingPong
                                                                                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                                                 pingPongField.setInt(eigen, 0);
                                                                                                                                                                 
                                                                                                                                                                 // Set end and start such that end - start = 3
                                                                                                                                                                 int start = 0;
                                                                                                                                                                 int end = 3;
                                                                                                                                                                 
                                                                                                                                                                 // Call the method
                                                                                                                                                                 Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                     "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                 computeShiftIncrement.setAccessible(true);
                                                                                                                                                                 computeShiftIncrement.invoke(eigen, start, end, 0);
                                                                                                                                                                 
                                                                                                                                                                 // Verify results
                                                                                                                                                                 Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                 tauField.setAccessible(true);
                                                                                                                                                                 double tau = tauField.getDouble(eigen);
                                                                                                                                                                 
                                                                                                                                                                 Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                 tTypeField.setAccessible(true);
                                                                                                                                                                 int tType = tTypeField.getInt(eigen);
                                                                                                                                                                 
                                                                                                                                                                 // In original code, with end-start=3, the if condition is false,
                                                                                                                                                                 // so tau should be gam*(1-Math.sqrt(a2))/(1+a2) or s (0.25*dMin)
                                                                                                                                                                 // The mutated code would execute the additional calculations
                                                                                                                                                                 // We expect tau to be 0.25 (since dMin=1.0) in original code
                                                                                                                                                                 assertEquals(0.25, tau, 1.0e-12);
                                                                                                                                                                 assertEquals(-5, tType);
                                                                                                                                                                 
                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                 fail("Exception during test: " + e.getMessage());
                                                                                                                                                             }
                                                                                                                                                         }

    @Test
                                                                                                                                                       public void testComputeShiftIncrementCase5WithSmallRange() throws Exception {
                                                                                                                                                           // Setup test case where deflated == 0 and dMin == dN2 (case 5)
                                                                                                                                                           // with end - start <= 3 to detect the mutant
                                                                                                                                                           
                                                                                                                                                           // Create instance
                                                                                                                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                           
                                                                                                                                                           // Use reflection to set private fields
                                                                                                                                                           Class<?> clazz = eigen.getClass();
                                                                                                                                                           
                                                                                                                                                           // Set fields to trigger case 5
                                                                                                                                                           Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                           dMinField.setAccessible(true);
                                                                                                                                                           dMinField.set(eigen, 5.0);
                                                                                                                                                           
                                                                                                                                                           Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                           dN2Field.setAccessible(true);
                                                                                                                                                           dN2Field.set(eigen, 5.0);
                                                                                                                                                           
                                                                                                                                                           Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                           tTypeField.setAccessible(true);
                                                                                                                                                           tTypeField.set(eigen, 0);
                                                                                                                                                           
                                                                                                                                                           Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                           pingPongField.setAccessible(true);
                                                                                                                                                           pingPongField.set(eigen, 0);
                                                                                                                                                           
                                                                                                                                                           // Set work array values needed for calculations
                                                                                                                                                           int nn = 4 * 5 + 0 - 1; // end=5, pingPong=0
                                                                                                                                                           double[] work = new double[nn];
                                                                                                                                                           work[nn - 2] = 1.0;  // b1
                                                                                                                                                           work[nn - 6] = 1.0;  // b2
                                                                                                                                                           work[nn - 8] = 0.5;  // should be <= b2
                                                                                                                                                           work[nn - 4] = 0.5;  // should be <= b1
                                                                                                                                                           
                                                                                                                                                           Field workField = clazz.getDeclaredField("work");
                                                                                                                                                           workField.setAccessible(true);
                                                                                                                                                           workField.set(eigen, work);
                                                                                                                                                           
                                                                                                                                                           // Set start and end such that end - start <= 3
                                                                                                                                                           int start = 3;
                                                                                                                                                           int end = 5;  // end - start = 2
                                                                                                                                                           
                                                                                                                                                           // Call private method using reflection
                                                                                                                                                           Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                           computeShiftIncrement.setAccessible(true);
                                                                                                                                                           computeShiftIncrement.invoke(eigen, start, end, 0);
                                                                                                                                                           
                                                                                                                                                           // Verify results - with original code, inner block shouldn't execute
                                                                                                                                                           // With mutant, inner block executes and changes a2 calculation
                                                                                                                                                           // Check tau value is different from what it would be if inner block didn't execute
                                                                                                                                                           double expectedTau = 0.25 * (Double)dMinField.get(eigen); // Expected when inner block doesn't execute
                                                                                                                                                           
                                                                                                                                                           Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                           tauField.setAccessible(true);
                                                                                                                                                           double actualTau = (Double)tauField.get(eigen);
                                                                                                                                                           
                                                                                                                                                           assertNotEquals("Mutant not detected - tau should differ when inner block is skipped", 
                                                                                                                                                                          expectedTau, actualTau, 0.0001);
                                                                                                                                                           
                                                                                                                                                           // Additional verification of tType
                                                                                                                                                           assertEquals("tType should be -5 for case 5", -5, tTypeField.get(eigen));
                                                                                                                                                       }

    @Test
                                                                                                                                                  public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant() throws Exception {
                                                                                                                                                      // Setup test case to reach the mutated code (case 5)
                                                                                                                                                      EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to set private fields
                                                                                                                                                      Class<?> clazz = eigen.getClass();
                                                                                                                                                      
                                                                                                                                                      // Set dMin
                                                                                                                                                      Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                      dMinField.setAccessible(true);
                                                                                                                                                      dMinField.setDouble(eigen, 4.0);
                                                                                                                                                      
                                                                                                                                                      // Set dN2
                                                                                                                                                      Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                      dN2Field.setAccessible(true);
                                                                                                                                                      dN2Field.setDouble(eigen, 4.0);  // dMin == dN2
                                                                                                                                                      
                                                                                                                                                      // Set pingPong
                                                                                                                                                      Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                                                      pingPongField.setInt(eigen, 1);
                                                                                                                                                      
                                                                                                                                                      // Setup work array with values where division != multiplication
                                                                                                                                                      // work[nn-13] / work[nn-15] would be 4/2=2, but 4*2=8
                                                                                                                                                      int end = 10;
                                                                                                                                                      int start = 2;   // end - start > 3
                                                                                                                                                      int deflated = 0;
                                                                                                                                                      int pingPong = 1;
                                                                                                                                                      
                                                                                                                                                      double[] work = new double[4 * end + pingPong - 1];
                                                                                                                                                      int nn = work.length;
                                                                                                                                                      work[nn - 3] = 1.0;  // These values just need to pass other conditions
                                                                                                                                                      work[nn - 5] = 1.0;
                                                                                                                                                      work[nn - 7] = 1.0;
                                                                                                                                                      work[nn - 8] = 1.0;  // work[np-8] > b2 condition
                                                                                                                                                      work[nn - 4] = 1.0;  // work[np-4] > b1 condition
                                                                                                                                                      work[nn - 13] = 4.0; // These are the critical values
                                                                                                                                                      work[nn - 15] = 2.0;
                                                                                                                                                      
                                                                                                                                                      // Set other required work array values
                                                                                                                                                      work[nn - 6] = 1.0;  // b2 in case 5
                                                                                                                                                      work[nn - 2] = 1.0;  // b1 in case 5
                                                                                                                                                      
                                                                                                                                                      // Inject our work array
                                                                                                                                                      Field workField = clazz.getDeclaredField("work");
                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                      workField.set(eigen, work);
                                                                                                                                                      
                                                                                                                                                      // Call the method
                                                                                                                                                      Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                      computeShiftIncrement.setAccessible(true);
                                                                                                                                                      computeShiftIncrement.invoke(eigen, start, end, deflated);
                                                                                                                                                      
                                                                                                                                                      // Verify the results - these values are based on original division operation
                                                                                                                                                      // With mutation (multiplication), these assertions would fail
                                                                                                                                                      Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                      tTypeField.setAccessible(true);
                                                                                                                                                      assertEquals(-5, tTypeField.getInt(eigen));
                                                                                                                                                      
                                                                                                                                                      Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                      tauField.setAccessible(true);
                                                                                                                                                      double tau = tauField.getDouble(eigen);
                                                                                                                                                      assertTrue(tau > 0.0);  // Exact value depends on complex calculations
                                                                                                                                                                              // but with multiplication mutant it would be different
                                                                                                                                                      
                                                                                                                                                      // More precise verification - calculate expected value based on division
                                                                                                                                                      double expectedB2 = 4.0 / 2.0;  // Original operation
                                                                                                                                                      double expectedA2 = (work[nn-8]/work[nn-6]) * (1 + work[nn-4]/work[nn-2]);
                                                                                                                                                      expectedA2 += expectedB2;
                                                                                                                                                      expectedA2 = 1.05 * expectedA2;  // cnst3 multiplication
                                                                                                                                                      
                                                                                                                                                      double expectedTau;
                                                                                                                                                      if (expectedA2 < 0.563) {  // cnst1
                                                                                                                                                          expectedTau = 4.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                                                      } else {
                                                                                                                                                          expectedTau = 0.25 * 4.0;
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      assertEquals(expectedTau, tau, 1e-10);
                                                                                                                                                  }

    @Test
                                                                                                                                             public void testComputeShiftIncrementCase5DetectsMutant3() throws Exception {
                                                                                                                                                 // Setup test case for case 5 (dMin == dN2)
                                                                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                                                 
                                                                                                                                                 // Helper method to set private fields
                                                                                                                                                 java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                 dMinField.setAccessible(true);
                                                                                                                                                 dMinField.set(eigen, 5.0);
                                                                                                                                                 
                                                                                                                                                 java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                 dN2Field.setAccessible(true);
                                                                                                                                                 dN2Field.set(eigen, 5.0);
                                                                                                                                                 
                                                                                                                                                 java.lang.reflect.Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                                                                 deflatedField.setAccessible(true);
                                                                                                                                                 deflatedField.set(eigen, 0);
                                                                                                                                                 
                                                                                                                                                 java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                                 pingPongField.set(eigen, 1);
                                                                                                                                                 
                                                                                                                                                 java.lang.reflect.Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                 endField.setAccessible(true);
                                                                                                                                                 endField.set(eigen, 10); // nn = 4*10 + 1 - 1 = 40
                                                                                                                                                 
                                                                                                                                                 // Create work array with specific values at indices that will be used
                                                                                                                                                 double[] work = new double[40];
                                                                                                                                                 work[40 - 13] = 4.0; // work[27]
                                                                                                                                                 work[40 - 15] = 2.0; // work[25]
                                                                                                                                                 work[40 - 8] = 1.0;  // These values ensure we don't hit early returns
                                                                                                                                                 work[40 - 4] = 1.0;
                                                                                                                                                 work[40 - 6] = 1.0;
                                                                                                                                                 work[40 - 2] = 1.0;
                                                                                                                                                 
                                                                                                                                                 java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                 workField.setAccessible(true);
                                                                                                                                                 workField.set(eigen, work);
                                                                                                                                                 
                                                                                                                                                 // Call the method
                                                                                                                                                 Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                     "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                 computeShiftIncrement.setAccessible(true);
                                                                                                                                                 computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                                                                                                 
                                                                                                                                                 // Verify results
                                                                                                                                                 java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                 tauField.setAccessible(true);
                                                                                                                                                 double tau = (Double) tauField.get(eigen);
                                                                                                                                                 
                                                                                                                                                 java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                 tTypeField.setAccessible(true);
                                                                                                                                                 int tType = (Integer) tTypeField.get(eigen);
                                                                                                                                                 
                                                                                                                                                 // Original calculation would be:
                                                                                                                                                 // b2 = 4.0/2.0 = 2.0
                                                                                                                                                 // a2 = (work[32]/b2)*(1 + work[36]/b1) = (1.0/1.0)*(1 + 1.0/1.0) = 2.0
                                                                                                                                                 // Then a2 becomes 2.0 + 2.0 = 4.0
                                                                                                                                                 // cnst3*a2 = 1.05*4.0 = 4.2
                                                                                                                                                 // Since a2 (4.2) > cnst1 (0.563), tau = s (0.25*dMin = 1.25)
                                                                                                                                                 
                                                                                                                                                 // Mutated calculation would be:
                                                                                                                                                 // b2 = 2.0/4.0 = 0.5
                                                                                                                                                 // a2 = (1.0/1.0)*(1 + 1.0/1.0) = 2.0
                                                                                                                                                 // Then a2 becomes 2.0 + 0.5 = 2.5
                                                                                                                                                 // cnst3*a2 = 1.05*2.5 = 2.625
                                                                                                                                                 // Still > cnst1, but the intermediate calculations are different
                                                                                                                                                 
                                                                                                                                                 // We can assert the exact expected tau value from original calculation
                                                                                                                                                 assertEquals(1.25, tau, 1e-10);
                                                                                                                                                 assertEquals(-5, tType);
                                                                                                                                             }

    @Test
                                                                                                                                         public void testComputeShiftIncrementCase4DetectsAdditionMutation() {
                                                                                                                                             // Setup test case for case 4 (dMin == dN but dMin1 != dN1)
                                                                                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                                             
                                                                                                                                             // Use reflection to set private fields since we need specific conditions
                                                                                                                                             try {
                                                                                                                                                 Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                 dMinField.setAccessible(true);
                                                                                                                                                 dMinField.set(eigen, 1.0); // dMin = 1.0
                                                                                                                                                 
                                                                                                                                                 Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                 dNField.setAccessible(true);
                                                                                                                                                 dNField.set(eigen, 1.0); // dN = 1.0 (dMin == dN)
                                                                                                                                                 
                                                                                                                                                 Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                                 dMin1Field.setAccessible(true);
                                                                                                                                                 dMin1Field.set(eigen, 2.0); // dMin1 != dN1
                                                                                                                                                 
                                                                                                                                                 Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                 dN1Field.setAccessible(true);
                                                                                                                                                 dN1Field.set(eigen, 3.0); // dN1 = 3.0
                                                                                                                                                 
                                                                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                 workField.setAccessible(true);
                                                                                                                                                 // Setup work array to trigger the loop with non-zero b2 values
                                                                                                                                                 // nn = 4*end + pingPong - 1 (we'll use end=5, pingPong=0 -> nn=19)
                                                                                                                                                 double[] work = new double[20];
                                                                                                                                                 work[16] = 2.0; // work[nn-3] = work[16]
                                                                                                                                                 work[14] = 3.0; // work[nn-5] = work[14]
                                                                                                                                                 work[12] = 4.0; // work[nn-7] = work[12]
                                                                                                                                                 work[10] = 5.0; // work[nn-9] = work[10]
                                                                                                                                                 work[8] = 1.0;  // work[nn-11] = work[8]
                                                                                                                                                 work[6] = 0.5;  // work[nn-13] = work[6]
                                                                                                                                                 work[4] = 0.25; // work[nn-15] = work[4]
                                                                                                                                                 work[2] = 0.125; // work[nn-17] = work[2]
                                                                                                                                                 work[0] = 0.0625; // work[nn-19] = work[0]
                                                                                                                                                 workField.set(eigen, work);
                                                                                                                                                 
                                                                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                                 pingPongField.set(eigen, 0);
                                                                                                                                                 
                                                                                                                                                 // Call the method with deflated=0 (case 4)
                                                                                                                                                 Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                     "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                 computeShiftIncrement.setAccessible(true);
                                                                                                                                                 computeShiftIncrement.invoke(eigen, 0, 5, 0);
                                                                                                                                                 
                                                                                                                                                 // Verify tau value
                                                                                                                                                 Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                 tauField.setAccessible(true);
                                                                                                                                                 double tau = tauField.getDouble(eigen);
                                                                                                                                                 
                                                                                                                                                 // Expected value calculated with original addition
                                                                                                                                                 // The mutation would make this calculation wrong
                                                                                                                                                 double expectedTau = 0.25; // This is the initial s value in case 4
                                                                                                                                                 // The actual expected value might need adjustment based on exact calculations,
                                                                                                                                                 // but the key point is it will be different with the mutation
                                                                                                                                                 assertEquals("Tau value should match expected calculation", 
                                                                                                                                                     expectedTau, tau, 1e-10);
                                                                                                                                                 
                                                                                                                                             } catch (Exception e) {
                                                                                                                                                 fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                             }
                                                                                                                                         }

    @Test
                                                                                                                                   public void testComputeShiftIncrementCase4DetectsMutant() throws Exception {
                                                                                                                                       // Setup test case for case 4 (dMin == dN but dMin1 != dN1)
                                                                                                                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1.0, 2.0, 3.0}, new double[]{0.5, 0.6}, 1.0e-6);
                                                                                                                                       
                                                                                                                                       // Reflection utility to set private fields
                                                                                                                                       java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                       dMinField.setAccessible(true);
                                                                                                                                       dMinField.set(eigen, 1.0);
                                                                                                                                       
                                                                                                                                       java.lang.reflect.Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                       dNField.setAccessible(true);
                                                                                                                                       dNField.set(eigen, 1.0);
                                                                                                                                       
                                                                                                                                       java.lang.reflect.Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                       dMin1Field.setAccessible(true);
                                                                                                                                       dMin1Field.set(eigen, 2.0);  // different from dN1 to trigger case 4
                                                                                                                                       
                                                                                                                                       java.lang.reflect.Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                       dN1Field.setAccessible(true);
                                                                                                                                       dN1Field.set(eigen, 3.0);
                                                                                                                                       
                                                                                                                                       java.lang.reflect.Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                                       dMin2Field.setAccessible(true);
                                                                                                                                       dMin2Field.set(eigen, 4.0);
                                                                                                                                       
                                                                                                                                       java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                       dN2Field.setAccessible(true);
                                                                                                                                       dN2Field.set(eigen, 5.0);
                                                                                                                                       
                                                                                                                                       java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                                       pingPongField.set(eigen, 0);
                                                                                                                                       
                                                                                                                                       java.lang.reflect.Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                       endField.setAccessible(true);
                                                                                                                                       endField.set(eigen, 5);
                                                                                                                                       
                                                                                                                                       java.lang.reflect.Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                                                       startField.setAccessible(true);
                                                                                                                                       startField.set(eigen, 0);
                                                                                                                                       
                                                                                                                                       // Setup work array to ensure loop executes multiple times
                                                                                                                                       double[] work = new double[4 * 5 + 0 - 1]; // nn = 4*end + pingPong - 1
                                                                                                                                       work[work.length - 5] = 0.4;  // nn-5
                                                                                                                                       work[work.length - 7] = 0.5;  // nn-7 (work[nn-5] <= work[nn-7] to enter case 4)
                                                                                                                                       work[work.length - 9] = 0.6;  // nn-9
                                                                                                                                       work[work.length - 11] = 0.7; // nn-11
                                                                                                                                       
                                                                                                                                       // Set values to ensure loop continues
                                                                                                                                       for (int i = 4 * 0 + 2 + 0; i <= 4 * 5 + 2 + 0; i += 4) {
                                                                                                                                           if (i < work.length && i-2 >= 0) {
                                                                                                                                               work[i] = 0.1;    // current
                                                                                                                                               work[i-2] = 0.2;   // previous (work[i] <= work[i-2])
                                                                                                                                           }
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                       workField.setAccessible(true);
                                                                                                                                       workField.set(eigen, work);
                                                                                                                                       
                                                                                                                                       // Call the private method using reflection
                                                                                                                                       java.lang.reflect.Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                           "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                       computeShiftIncrement.setAccessible(true);
                                                                                                                                       computeShiftIncrement.invoke(eigen, 0, 5, 0);
                                                                                                                                       
                                                                                                                                       // Get the results using reflection
                                                                                                                                       java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                       tauField.setAccessible(true);
                                                                                                                                       double tau = (Double) tauField.get(eigen);
                                                                                                                                       
                                                                                                                                       java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                       tTypeField.setAccessible(true);
                                                                                                                                       int tType = (Integer) tTypeField.get(eigen);
                                                                                                                                       
                                                                                                                                       // Verify the results - the mutated version would produce different tau
                                                                                                                                       // because a2 wouldn't accumulate properly
                                                                                                                                       assertEquals(-4, tType);
                                                                                                                                       assertTrue(tau > 0);  // Exact value depends on proper accumulation
                                                                                                                                   }

    @Test
                                                                                                                               public void testComputeShiftIncrementCase5DetectsLoopIncrementMutant() {
                                                                                                                                   // Setup
                                                                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                   
                                                                                                                                   // Use reflection to set private fields since we need specific conditions
                                                                                                                                   try {
                                                                                                                                       Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                       dMinField.setAccessible(true);
                                                                                                                                       dMinField.set(eigen, 1.0); // dMin == dN2 will be set later
                                                                                                                                       
                                                                                                                                       Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                       dN2Field.setAccessible(true);
                                                                                                                                       dN2Field.set(eigen, 1.0); // dMin == dN2
                                                                                                                                       
                                                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                       workField.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Create a work array that will make the loop execute multiple times
                                                                                                                                       // The array needs to be large enough for the loop in case 5
                                                                                                                                       double[] work = new double[100];
                                                                                                                                       // Setup values that will make the loop execute
                                                                                                                                       for (int i = 0; i < work.length; i++) {
                                                                                                                                           work[i] = 1.0 - (i * 0.01); // Decreasing values to satisfy conditions
                                                                                                                                       }
                                                                                                                                       workField.set(eigen, work);
                                                                                                                                       
                                                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                                       pingPongField.set(eigen, 0); // pingPong = 0
                                                                                                                                       
                                                                                                                                       Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                       endField.setAccessible(true);
                                                                                                                                       endField.set(eigen, 10); // end = 10 to make loop execute
                                                                                                                                       
                                                                                                                                       // Execute
                                                                                                                                       Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                           int.class, int.class, int.class);
                                                                                                                                       method.setAccessible(true);
                                                                                                                                       method.invoke(eigen, 0, 10, 0); // start=0, end=10, deflated=0
                                                                                                                                       
                                                                                                                                       // Verify
                                                                                                                                       Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                       tauField.setAccessible(true);
                                                                                                                                       double tau = tauField.getDouble(eigen);
                                                                                                                                       
                                                                                                                                       // The exact expected value depends on the precise calculations,
                                                                                                                                       // but we know it should be less than 0.25*dMin (which would be 0.25)
                                                                                                                                       assertTrue("Tau should be less than 0.25", tau < 0.25);
                                                                                                                                       
                                                                                                                                       // More precise assertion would require duplicating the exact calculation
                                                                                                                                       // This is a simplified check that would catch the mutant
                                                                                                                                       // since the mutant would process different elements and likely produce a different tau
                                                                                                                                       assertEquals(0.0, tau, 0.1); // Allowing some tolerance
                                                                                                                                       
                                                                                                                                   } catch (Exception e) {
                                                                                                                                       fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                   }
                                                                                                                               }

    @Test
                                                                                                                             public void testComputeShiftIncrementCase5LoopBoundary() throws Exception {
                                                                                                                                 // Setup test case for scenario 5 (dMin == dN2)
                                                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                 
                                                                                                                                 // Use reflection to set private fields
                                                                                                                                 Class<?> clazz = eigen.getClass();
                                                                                                                                 
                                                                                                                                 // Set dMin and dN2
                                                                                                                                 Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                 dMinField.setAccessible(true);
                                                                                                                                 dMinField.setDouble(eigen, 1.0);
                                                                                                                                 
                                                                                                                                 Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                 dN2Field.setAccessible(true);
                                                                                                                                 dN2Field.setDouble(eigen, 1.0);  // dMin == dN2
                                                                                                                                 
                                                                                                                                 // Configure work array - needs to be large enough for nn-17 access
                                                                                                                                 int nn = 100; // arbitrary large enough value
                                                                                                                                 double[] work = new double[nn];
                                                                                                                                 
                                                                                                                                 Field workField = clazz.getDeclaredField("work");
                                                                                                                                 workField.setAccessible(true);
                                                                                                                                 workField.set(eigen, work);
                                                                                                                                 
                                                                                                                                 Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                 pingPongField.setInt(eigen, 0); // makes boundary difference exactly 2
                                                                                                                                 
                                                                                                                                 // Fill work array with values that will show difference with extra iterations
                                                                                                                                 // We need values that will pass the work[i4] > work[i4-2] check
                                                                                                                                 for (int i = 0; i < nn; i++) {
                                                                                                                                     work[i] = 1.0 - (i * 0.01); // decreasing values
                                                                                                                                 }
                                                                                                                                 
                                                                                                                                 // Set some specific values that will be used in calculations
                                                                                                                                 work[nn-2] = 0.5;
                                                                                                                                 work[nn-6] = 0.5;
                                                                                                                                 work[nn-8] = 0.4; // must be <= work[nn-6]
                                                                                                                                 work[nn-4] = 0.4; // must be <= work[nn-2]
                                                                                                                                 work[nn-13] = 0.3;
                                                                                                                                 work[nn-15] = 0.5;
                                                                                                                                 
                                                                                                                                 // Call the method
                                                                                                                                 Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                 computeShiftIncrement.setAccessible(true);
                                                                                                                                 computeShiftIncrement.invoke(eigen, 10, nn/4, 0); // start=10, deflated=0
                                                                                                                                 
                                                                                                                                 // Get tau value using reflection
                                                                                                                                 Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                 tauField.setAccessible(true);
                                                                                                                                 double tau = tauField.getDouble(eigen);
                                                                                                                                 
                                                                                                                                 // Get dMin value for comparison
                                                                                                                                 double dMin = dMinField.getDouble(eigen);
                                                                                                                                 
                                                                                                                                 // The mutated version will process 2 more elements in the loop,
                                                                                                                                 // which should affect the final tau value
                                                                                                                                 // We can't predict exact value due to complexity, but we can verify
                                                                                                                                 // it's within expected bounds
                                                                                                                                 assertTrue("Tau should be positive", tau > 0);
                                                                                                                                 assertTrue("Tau should be less than dMin", tau < dMin);
                                                                                                                                 
                                                                                                                                 // More precise check - the original would stop 2 iterations earlier
                                                                                                                                 // so we can calculate what the value should be approximately
                                                                                                                                 double expectedTau = 0.25 * dMin; // base value
                                                                                                                                 // The mutated version would process more elements and likely have smaller tau
                                                                                                                                 assertTrue("Tau should be smaller than 0.25*dMin due to extra iterations", 
                                                                                                                                            tau < expectedTau);
                                                                                                                             }

    @Test
                                                                                                                         public void testComputeShiftIncrementCase5BoundaryCondition2() {
                                                                                                                             // Setup test data to enter case 5 (dMin == dN2)
                                                                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                             
                                                                                                                             // Use reflection to set private fields since we need specific conditions
                                                                                                                             try {
                                                                                                                                 Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                 dMinField.setAccessible(true);
                                                                                                                                 dMinField.set(eigen, 1.0);
                                                                                                                                 
                                                                                                                                 Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                 dN2Field.setAccessible(true);
                                                                                                                                 dN2Field.set(eigen, 1.0);
                                                                                                                                 
                                                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                 workField.setAccessible(true);
                                                                                                                                 double[] work = new double[100];
                                                                                                                                 // Setup work array to enter the loop and hit the boundary condition
                                                                                                                                 work[83] = 1.0;  // nn-17 (100-17=83)
                                                                                                                                 work[81] = 1.0;  // nn-15 (100-15=85)
                                                                                                                                 work[85] = 1.0;  // nn-13 (100-13=87)
                                                                                                                                 work[87] = 1.0;  // nn-11 (100-11=89)
                                                                                                                                 work[89] = 1.0;  // nn-9 (100-9=91)
                                                                                                                                 work[91] = 1.0;  // nn-7 (100-7=93)
                                                                                                                                 work[93] = 1.0;  // nn-5 (100-5=95)
                                                                                                                                 work[95] = 1.0;  // nn-3 (100-3=97)
                                                                                                                                 work[97] = 1.0;  // nn-1 (100-1=99)
                                                                                                                                 workField.set(eigen, work);
                                                                                                                                 
                                                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                 pingPongField.set(eigen, 0);
                                                                                                                                 
                                                                                                                                 Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                 endField.setAccessible(true);
                                                                                                                                 endField.set(eigen, 20);  // nn = 4*20 + 0 -1 = 79
                                                                                                                                 
                                                                                                                                 // Call the method with parameters that will hit the boundary condition
                                                                                                                                 Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                     "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                 computeShiftIncrement.setAccessible(true);
                                                                                                                                 computeShiftIncrement.invoke(eigen, 20, 20, 0);  // deflated=0 for case 5
                                                                                                                                 
                                                                                                                                 // Get the tau value
                                                                                                                                 Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                 tauField.setAccessible(true);
                                                                                                                                 double tau = tauField.getDouble(eigen);
                                                                                                                                 
                                                                                                                                 // Verify the tau value is as expected (would be different with the mutant)
                                                                                                                                 // The exact expected value depends on the calculations, but we know it should
                                                                                                                                 // be greater than 0 due to proper loop execution
                                                                                                                                 assertTrue("Tau should be positive when loop executes fully", tau > 0);
                                                                                                                                 
                                                                                                                             } catch (Exception e) {
                                                                                                                                 fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                             }
                                                                                                                         }

    @Test
                                                                                                                       public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant1() throws Exception {
                                                                                                                           // Setup test case to trigger case 5 (dMin == dN2)
                                                                                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                           
                                                                                                                           // Use reflection to set private fields
                                                                                                                           Class<?> clazz = eigen.getClass();
                                                                                                                           
                                                                                                                           // Set dMin
                                                                                                                           Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                           dMinField.setAccessible(true);
                                                                                                                           dMinField.setDouble(eigen, 4.0);
                                                                                                                           
                                                                                                                           // Set dN2
                                                                                                                           Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                           dN2Field.setAccessible(true);
                                                                                                                           dN2Field.setDouble(eigen, 4.0);  // dMin == dN2 triggers case 5
                                                                                                                           
                                                                                                                           // Set pingPong
                                                                                                                           Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                           pingPongField.setAccessible(true);
                                                                                                                           pingPongField.setInt(eigen, 1);
                                                                                                                           
                                                                                                                           // Setup work array with specific values that will show difference between / and *
                                                                                                                           // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*10 + 1 - 1 - 2*1 = 38
                                                                                                                           // So np-8 = 30, np-4 = 34, np-2 = 36, np-6 = 32
                                                                                                                           double[] work = new double[40];
                                                                                                                           work[30] = 2.0;  // work[np-8]
                                                                                                                           work[32] = 4.0;  // work[np-6] (b2)
                                                                                                                           work[34] = 3.0;  // work[np-4]
                                                                                                                           work[36] = 6.0;  // work[np-2] (b1)
                                                                                                                           
                                                                                                                           // Set work array
                                                                                                                           Field workField = clazz.getDeclaredField("work");
                                                                                                                           workField.setAccessible(true);
                                                                                                                           workField.set(eigen, work);
                                                                                                                           
                                                                                                                           // Calculate expected a2 value with original division
                                                                                                                           double expectedB1 = work[36];
                                                                                                                           double expectedB2 = work[32];
                                                                                                                           double expectedA2 = (work[30] / expectedB2) * (1 + work[34] / expectedB1);
                                                                                                                           
                                                                                                                           // Calculate expected tau
                                                                                                                           double expectedTau;
                                                                                                                           if (expectedA2 < 0.563) {  // cnst1
                                                                                                                               expectedTau = 4.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);  // Using 4.0 directly since we know dN2 is 4.0
                                                                                                                           } else {
                                                                                                                               expectedTau = 0.25 * 4.0;  // Using 4.0 directly since we know dMin is 4.0
                                                                                                                           }
                                                                                                                           
                                                                                                                           // Call the private method using reflection
                                                                                                                           Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                           computeShiftIncrement.setAccessible(true);
                                                                                                                           computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                                                                           
                                                                                                                           // Verify the results using reflection
                                                                                                                           Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                           tTypeField.setAccessible(true);
                                                                                                                           int tType = tTypeField.getInt(eigen);
                                                                                                                           assertEquals("Case 5 tType should be -5", -5, tType);
                                                                                                                           
                                                                                                                           Field tauField = clazz.getDeclaredField("tau");
                                                                                                                           tauField.setAccessible(true);
                                                                                                                           double tau = tauField.getDouble(eigen);
                                                                                                                           assertEquals("Tau value should match expected calculation", 
                                                                                                                                        expectedTau, tau, 1e-10);
                                                                                                                       }

    @Test
                                                                                                                  public void testComputeShiftIncrementCase5DetectsMutant4() throws Exception {
                                                                                                                      // Setup test case for case 5 (tType = -5)
                                                                                                                      EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                      
                                                                                                                      // Helper method to set private fields
                                                                                                                      java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                      dMinField.setAccessible(true);
                                                                                                                      dMinField.set(eigen, 10.0);
                                                                                                                      
                                                                                                                      java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                      dN2Field.setAccessible(true);
                                                                                                                      dN2Field.set(eigen, 10.0);  // triggers case 5
                                                                                                                      
                                                                                                                      java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                      pingPongField.set(eigen, 0);
                                                                                                                      
                                                                                                                      java.lang.reflect.Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                      endField.setAccessible(true);
                                                                                                                      endField.set(eigen, 10);
                                                                                                                      
                                                                                                                      java.lang.reflect.Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                                      startField.setAccessible(true);
                                                                                                                      startField.set(eigen, 0);
                                                                                                                      
                                                                                                                      java.lang.reflect.Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                                      deflatedField.setAccessible(true);
                                                                                                                      deflatedField.set(eigen, 0);
                                                                                                                      
                                                                                                                      // Create work array with specific values that will make the mutation detectable
                                                                                                                      double[] work = new double[100];
                                                                                                                      int np = 4 * 10 + 0 - 1 - 2 * 0; // nn = 4*end + pingPong -1, np = nn - 2*pingPong
                                                                                                                      work[np - 2] = 4.0;  // b1
                                                                                                                      work[np - 6] = 2.0;  // b2
                                                                                                                      work[np - 8] = 3.0;  // numerator for first term
                                                                                                                      work[np - 4] = 1.0;  // numerator for second term
                                                                                                                      
                                                                                                                      java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                      workField.setAccessible(true);
                                                                                                                      workField.set(eigen, work);
                                                                                                                      
                                                                                                                      // Call the private method using reflection
                                                                                                                      java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                          "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                      method.setAccessible(true);
                                                                                                                      method.invoke(eigen, 0, 10, 0);
                                                                                                                      
                                                                                                                      // Calculate expected a2 value from original formula
                                                                                                                      double b1 = 4.0;
                                                                                                                      double b2 = 2.0;
                                                                                                                      double expectedA2 = (3.0 / b2) * (1 + 1.0 / b1);
                                                                                                                      double expectedTau;
                                                                                                                      if (expectedA2 < 0.563) {  // cnst1
                                                                                                                          expectedTau = 10.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                      } else {
                                                                                                                          expectedTau = 0.25 * 10.0;
                                                                                                                      }
                                                                                                                      
                                                                                                                      // Verify tau matches expected value
                                                                                                                      java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                      tauField.setAccessible(true);
                                                                                                                      double actualTau = (Double)tauField.get(eigen);
                                                                                                                      assertEquals("Tau value should match expected calculation", expectedTau, actualTau, 1e-10);
                                                                                                                      
                                                                                                                      // Verify tType is set correctly
                                                                                                                      java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                      tTypeField.setAccessible(true);
                                                                                                                      int actualTType = (Integer)tTypeField.get(eigen);
                                                                                                                      assertEquals("tType should be -5 for this case", -5, actualTType);
                                                                                                                  }

    @Test
                                                                                                              public void testComputeShiftIncrementCase5DetectsMultiplicationMutant() {
                                                                                                                  // Setup test data to trigger case 5
                                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                  
                                                                                                                  // Use reflection to access private fields since we need to test a private method
                                                                                                                  try {
                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                      workField.setAccessible(true);
                                                                                                                      Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                      dMinField.setAccessible(true);
                                                                                                                      Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                      dN2Field.setAccessible(true);
                                                                                                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                      Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                      endField.setAccessible(true);
                                                                                                                      Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                                      startField.setAccessible(true);
                                                                                                                      
                                                                                                                      // Set values to trigger case 5
                                                                                                                      double[] work = new double[100];
                                                                                                                      // Setup work array values that will produce different results for * vs +
                                                                                                                      work[92] = 4.0;  // work[np-8] where np = nn - 2*pingPong = 100 - 2*0 -1 - 2*0 = 99?
                                                                                                                      work[96] = 3.0;  // work[np-4]
                                                                                                                      work[94] = 2.0;  // b2 = work[np-6]
                                                                                                                      work[98] = 1.0;  // b1 = work[np-2]
                                                                                                                      
                                                                                                                      workField.set(eigen, work);
                                                                                                                      dMinField.set(eigen, 10.0);
                                                                                                                      dN2Field.set(eigen, 10.0);  // dMin == dN2 to trigger case 5
                                                                                                                      pingPongField.set(eigen, 0);
                                                                                                                      endField.set(eigen, 25);     // end > start + 3 to enter the inner loop
                                                                                                                      startField.set(eigen, 0);
                                                                                                                      
                                                                                                                      // Get the method to test
                                                                                                                      Method method = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                          "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                      method.setAccessible(true);
                                                                                                                      
                                                                                                                      // Invoke the method (deflated = 0 for case 5)
                                                                                                                      method.invoke(eigen, 0, 25, 0);
                                                                                                                      
                                                                                                                      // Get the tau value
                                                                                                                      Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                      tauField.setAccessible(true);
                                                                                                                      double tau = tauField.getDouble(eigen);
                                                                                                                      
                                                                                                                      // Calculate expected value
                                                                                                                      // Original calculation would be:
                                                                                                                      // a2 = (4/2) * (1 + 3/1) = 2 * 4 = 8
                                                                                                                      // Mutated calculation would be:
                                                                                                                      // a2 = (4/2) + (1 + 3/1) = 2 + 4 = 6
                                                                                                                      // Since cnst3 = 1.05 and cnst1 = 0.563
                                                                                                                      // a2 = 1.05 * 8 = 8.4 (original) or 1.05 * 6 = 6.3 (mutated)
                                                                                                                      // Since a2 > cnst1, tau would be s = 0.25 * dMin = 2.5 (original)
                                                                                                                      // The mutated version would also get tau = 2.5 in this case, so we need different values
                                                                                                                      
                                                                                                                      // Let's adjust values to make the test more sensitive
                                                                                                                      work[92] = 0.5;  // work[np-8]
                                                                                                                      work[96] = 0.5;  // work[np-4]
                                                                                                                      work[94] = 1.0;  // b2
                                                                                                                      work[98] = 1.0;  // b1
                                                                                                                      
                                                                                                                      // Re-invoke
                                                                                                                      method.invoke(eigen, 0, 25, 0);
                                                                                                                      tau = tauField.getDouble(eigen);
                                                                                                                      
                                                                                                                      // Now original: a2 = (0.5/1) * (1 + 0.5/1) = 0.5 * 1.5 = 0.75
                                                                                                                      // Mutated: a2 = 0.5 + 1.5 = 2.0
                                                                                                                      // Original: a2 = 1.05 * 0.75 = 0.7875 > cnst1 (0.563) -> tau = 2.5
                                                                                                                      // Mutated: a2 = 1.05 * 2.0 = 2.1 > cnst1 -> tau = 2.5
                                                                                                                      // Still same, need to make a2 < cnst1 in original but > in mutated
                                                                                                                      
                                                                                                                      // Final adjustment
                                                                                                                      work[92] = 0.3;  // work[np-8]
                                                                                                                      work[96] = 0.3;  // work[np-4]
                                                                                                                      work[94] = 1.0;  // b2
                                                                                                                      work[98] = 1.0;  // b1
                                                                                                                      
                                                                                                                      // Re-invoke
                                                                                                                      method.invoke(eigen, 0, 25, 0);
                                                                                                                      tau = tauField.getDouble(eigen);
                                                                                                                      
                                                                                                                      // Original: a2 = (0.3/1) * (1 + 0.3/1) = 0.3 * 1.3 = 0.39
                                                                                                                      // a2 = 1.05 * 0.39 = 0.4095 < cnst1 (0.563)
                                                                                                                      // tau = gam * (1 - sqrt(a2))/(1 + a2) = 10 * (1 - sqrt(0.4095))/1.4095 ≈ 3.57
                                                                                                                      // Mutated: a2 = 0.3 + 1.3 = 1.6
                                                                                                                      // a2 = 1.05 * 1.6 = 1.68 > cnst1 -> tau = 2.5
                                                                                                                      // Now we can detect the difference
                                                                                                                      
                                                                                                                      // Verify tau is approximately 3.57 (original) not 2.5 (mutated)
                                                                                                                      assertEquals(3.57, tau, 0.1);
                                                                                                                      
                                                                                                                  } catch (Exception e) {
                                                                                                                      fail("Failed due to reflection exception: " + e.getMessage());
                                                                                                                  }
                                                                                                              }

    @Test
                                                                                                            public void testComputeShiftIncrementCase5DetectsMutant5() throws Exception {
                                                                                                                // Setup test data to trigger case 5
                                                                                                                EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                
                                                                                                                // Use reflection to access private fields
                                                                                                                Class<?> clazz = decomposition.getClass();
                                                                                                                
                                                                                                                // Set fields to enter case 5
                                                                                                                Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                dMinField.setAccessible(true);
                                                                                                                dMinField.setDouble(decomposition, 5.0);
                                                                                                                
                                                                                                                Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                dN2Field.setAccessible(true);
                                                                                                                dN2Field.setDouble(decomposition, 5.0);  // dMin == dN2
                                                                                                                
                                                                                                                Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                pingPongField.setAccessible(true);
                                                                                                                pingPongField.setInt(decomposition, 1);
                                                                                                                
                                                                                                                int end = 10;
                                                                                                                
                                                                                                                // Create work array with specific values where b1 != b2
                                                                                                                Field workField = clazz.getDeclaredField("work");
                                                                                                                workField.setAccessible(true);
                                                                                                                workField.set(decomposition, new double[4 * end + 2]); // nn = 4*end + pingPong - 1 = 40
                                                                                                                
                                                                                                                int np = 4 * end + 1 - 2 * (Integer)pingPongField.get(decomposition); // np = 39
                                                                                                                
                                                                                                                // Set values to make b1 and b2 different
                                                                                                                double[] work = (double[]) workField.get(decomposition);
                                                                                                                work[np - 2] = 4.0;  // b1
                                                                                                                work[np - 6] = 2.0;  // b2
                                                                                                                work[np - 8] = 3.0;  // work[np-8]
                                                                                                                work[np - 4] = 6.0;  // work[np-4]
                                                                                                                
                                                                                                                // Calculate expected a2 value from original formula
                                                                                                                double expectedB1 = 4.0;
                                                                                                                double expectedB2 = 2.0;
                                                                                                                double expectedA2 = (3.0 / expectedB2) * (1 + 6.0 / expectedB1);
                                                                                                                
                                                                                                                // Calculate expected tau
                                                                                                                double expectedTau;
                                                                                                                if (expectedA2 < 0.563) {  // cnst1
                                                                                                                    expectedTau = 5.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                } else {
                                                                                                                    expectedTau = 0.25 * 5.0;
                                                                                                                }
                                                                                                                
                                                                                                                // Call the private method using reflection
                                                                                                                Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                computeShiftIncrement.setAccessible(true);
                                                                                                                computeShiftIncrement.invoke(decomposition, 0, end, 0);
                                                                                                                
                                                                                                                // Verify the results using reflection
                                                                                                                Field tauField = clazz.getDeclaredField("tau");
                                                                                                                tauField.setAccessible(true);
                                                                                                                double actualTau = tauField.getDouble(decomposition);
                                                                                                                
                                                                                                                Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                tTypeField.setAccessible(true);
                                                                                                                int actualTType = tTypeField.getInt(decomposition);
                                                                                                                
                                                                                                                assertEquals("tau should match expected calculation", expectedTau, actualTau, 1e-10);
                                                                                                                assertEquals("tType should be -5 for case 5", -5, actualTType);
                                                                                                            }

    @Test
                                                                                                       public void testComputeShiftIncrementCase5BoundaryCondition3() throws Exception {
                                                                                                           // Setup test case where end - start == 3 to catch the mutation
                                                                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                           
                                                                                                           // Use reflection to access private fields
                                                                                                           Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                           deflatedField.setAccessible(true);
                                                                                                           deflatedField.setInt(eigen, 0);
                                                                                                           
                                                                                                           Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                           dMinField.setAccessible(true);
                                                                                                           dMinField.setDouble(eigen, 1.0);
                                                                                                           
                                                                                                           Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                           dN2Field.setAccessible(true);
                                                                                                           dN2Field.setDouble(eigen, 1.0);
                                                                                                           
                                                                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                           workField.setAccessible(true);
                                                                                                           double[] work = new double[100]; // Large enough for nn-8 access
                                                                                                           workField.set(eigen, work);
                                                                                                           
                                                                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                           pingPongField.setAccessible(true);
                                                                                                           pingPongField.setInt(eigen, 0);
                                                                                                           
                                                                                                           // Set end - start = 3
                                                                                                           int start = 0;
                                                                                                           int end = 3;
                                                                                                           
                                                                                                           // Calculate np
                                                                                                           int pingPong = (Integer) pingPongField.get(eigen);
                                                                                                           int np = 4 * end + pingPong - 1 - 2 * pingPong;
                                                                                                           
                                                                                                           // Set values in work array
                                                                                                           work[np - 2] = 10.0; // b1
                                                                                                           work[np - 6] = 10.0; // b2
                                                                                                           work[np - 8] = 5.0;  // < b2
                                                                                                           work[np - 4] = 5.0;  // < b1
                                                                                                           
                                                                                                           // Calculate nn (assuming it's related to work array length)
                                                                                                           int nn = work.length;
                                                                                                           
                                                                                                           // Set values that would make a2 < cnst1 if the loop executes
                                                                                                           work[nn - 13] = 0.1;
                                                                                                           work[nn - 15] = 1.0;
                                                                                                           
                                                                                                           // Call the method using reflection
                                                                                                           Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                               "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                           computeShiftIncrement.setAccessible(true);
                                                                                                           computeShiftIncrement.invoke(eigen, start, end, 0);
                                                                                                           
                                                                                                           // Get tau value using reflection
                                                                                                           Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                           tauField.setAccessible(true);
                                                                                                           double tau = tauField.getDouble(eigen);
                                                                                                           
                                                                                                           // In original code, the loop wouldn't execute (end-start=3 not >3)
                                                                                                           // so a2 would be just the initial value and tau would be s (0.25*dMin)
                                                                                                           double dMin = dMinField.getDouble(eigen);
                                                                                                           double expectedTau = 0.25 * dMin; // Original behavior
                                                                                                           assertEquals("Tau value should match original behavior for end-start=3", 
                                                                                                                       expectedTau, tau, 1e-10);
                                                                                                           
                                                                                                           // Also verify tType was set correctly
                                                                                                           Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                           tTypeField.setAccessible(true);
                                                                                                           int tType = tTypeField.getInt(eigen);
                                                                                                           assertEquals("tType should be -5 for case 5", -5, tType);
                                                                                                       }

    @Test
                                                                                              public void testComputeShiftIncrementCase5BoundaryCondition4() throws Exception {
                                                                                                  // Setup test case where end - start = 3 (boundary case)
                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                  
                                                                                                  // Set required fields through reflection since they're private
                                                                                                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                  dMinField.setAccessible(true);
                                                                                                  dMinField.set(eigen, 1.0);
                                                                                                  
                                                                                                  Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                  dN2Field.setAccessible(true);
                                                                                                  dN2Field.set(eigen, 1.0);  // triggers case 5
                                                                                                  
                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                  pingPongField.setAccessible(true);
                                                                                                  pingPongField.set(eigen, 0);
                                                                                                  
                                                                                                  Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                  deflatedField.setAccessible(true);
                                                                                                  deflatedField.set(eigen, 0);
                                                                                                  
                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                  workField.setAccessible(true);
                                                                                                  workField.set(eigen, new double[100]); // large enough array
                                                                                                  
                                                                                                  Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                  tTypeField.setAccessible(true);
                                                                                                  tTypeField.set(eigen, 0);
                                                                                                  
                                                                                                  // Initialize work array with values that won't trigger early returns
                                                                                                  double[] work = (double[]) workField.get(eigen);
                                                                                                  work[0] = 1.0; work[1] = 2.0; // etc. - values that won't trigger returns
                                                                                                  
                                                                                                  // Call private method using reflection
                                                                                                  Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                      "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                  computeShiftIncrement.setAccessible(true);
                                                                                                  computeShiftIncrement.invoke(eigen, 0, 3, 0);
                                                                                                  
                                                                                                  // Get results
                                                                                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                  tauField.setAccessible(true);
                                                                                                  double tau = (Double) tauField.get(eigen);
                                                                                                  
                                                                                                  int tType = (Integer) tTypeField.get(eigen);
                                                                                                  
                                                                                                  // Verify behavior - original should use simple calculation (s = 0.25 * dMin)
                                                                                                  assertEquals(-5, tType);
                                                                                                  assertEquals(0.25, tau, 1e-10);
                                                                                                  
                                                                                                  // If the mutant was present, tau would be calculated differently
                                                                                                  // because the inner calculations would have executed
                                                                                              }

    @Test
                                                                                         public void testComputeShiftIncrementCase5WithSmallRange1() throws Exception {
                                                                                             // Setup
                                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                             
                                                                                             // Use reflection to access private fields
                                                                                             Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                             dMinField.setAccessible(true);
                                                                                             dMinField.set(eigen, 5.0);
                                                                                             
                                                                                             Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                             dN2Field.setAccessible(true);
                                                                                             dN2Field.set(eigen, 5.0);
                                                                                             
                                                                                             Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                             tTypeField.setAccessible(true);
                                                                                             tTypeField.set(eigen, 0);
                                                                                             
                                                                                             Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                             workField.setAccessible(true);
                                                                                             workField.set(eigen, new double[100]);
                                                                                             
                                                                                             Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                             pingPongField.setAccessible(true);
                                                                                             pingPongField.set(eigen, 0);
                                                                                             
                                                                                             int deflated = 0;
                                                                                             int start = 0;
                                                                                             int end = 3;
                                                                                             
                                                                                             // Get work array reference
                                                                                             double[] work = (double[]) workField.get(eigen);
                                                                                             int pingPong = (int) pingPongField.get(eigen);
                                                                                             int nn = 4 * end + pingPong - 1;
                                                                                             
                                                                                             // Set values needed for case 5 calculations
                                                                                             work[nn - 2] = 1.0;  // b1
                                                                                             work[nn - 6] = 1.0;  // b2
                                                                                             work[nn - 8] = 0.5;  // should be <= b2
                                                                                             work[nn - 4] = 0.5;  // should be <= b1
                                                                                             
                                                                                             // Get and invoke private method
                                                                                             Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                 "computeShiftIncrement", int.class, int.class, int.class);
                                                                                             computeShiftIncrement.setAccessible(true);
                                                                                             computeShiftIncrement.invoke(eigen, start, end, deflated);
                                                                                             
                                                                                             // Verify results
                                                                                             double dMin = (double) dMinField.get(eigen);
                                                                                             double expectedTau = 0.25 * dMin;
                                                                                             
                                                                                             Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                             tauField.setAccessible(true);
                                                                                             double tau = (double) tauField.get(eigen);
                                                                                             
                                                                                             assertEquals("Tau should equal 0.25*dMin when end-start <= 3", 
                                                                                                         expectedTau, tau, 1e-10);
                                                                                             
                                                                                             int tType = (int) tTypeField.get(eigen);
                                                                                             assertEquals("tType should be -5 for case 5", -5, tType);
                                                                                         }

    @Test
                                                                                    public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant2() throws Exception {
                                                                                        // Setup test case to trigger case 5 where the mutation occurs
                                                                                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                        
                                                                                        // Use reflection to set private fields
                                                                                        Class<?> clazz = eigen.getClass();
                                                                                        
                                                                                        // Set required field values to enter case 5
                                                                                        Field dMinField = clazz.getDeclaredField("dMin");
                                                                                        dMinField.setAccessible(true);
                                                                                        dMinField.set(eigen, 4.0);
                                                                                        
                                                                                        Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                        dN2Field.setAccessible(true);
                                                                                        dN2Field.set(eigen, 4.0);  // dMin == dN2 triggers case 5
                                                                                        
                                                                                        Field deflatedField = clazz.getDeclaredField("deflated");
                                                                                        deflatedField.setAccessible(true);
                                                                                        deflatedField.set(eigen, 0);
                                                                                        
                                                                                        Field endField = clazz.getDeclaredField("end");
                                                                                        endField.setAccessible(true);
                                                                                        endField.set(eigen, 10);    // Large enough to ensure nn-15 is valid
                                                                                        
                                                                                        Field startField = clazz.getDeclaredField("start");
                                                                                        startField.setAccessible(true);
                                                                                        startField.set(eigen, 0);
                                                                                        
                                                                                        Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                        pingPongField.setAccessible(true);
                                                                                        pingPongField.set(eigen, 0);
                                                                                        
                                                                                        // Setup work array with values that will produce different results for division vs multiplication
                                                                                        // We need work[nn-13] and work[nn-15] where a/b != a*b
                                                                                        // Using 2 and 4: 2/4=0.5 vs 2*4=8
                                                                                        int endValue = (Integer) endField.get(eigen);
                                                                                        int pingPongValue = (Integer) pingPongField.get(eigen);
                                                                                        double[] work = new double[4 * endValue + pingPongValue];
                                                                                        int nn = 4 * endValue + pingPongValue - 1;
                                                                                        work[nn - 13] = 2.0;  // a
                                                                                        work[nn - 15] = 4.0;   // b
                                                                                        // Other required work array values
                                                                                        work[nn - 2] = 1.0;
                                                                                        work[nn - 6] = 1.0;
                                                                                        work[nn - 8] = 0.5;   // Must be <= b2 (work[nn-6])
                                                                                        work[nn - 4] = 0.5;    // Must be <= b1 (work[nn-2])
                                                                                        
                                                                                        // Set other required fields
                                                                                        Field workField = clazz.getDeclaredField("work");
                                                                                        workField.setAccessible(true);
                                                                                        workField.set(eigen, work);
                                                                                        
                                                                                        Field tTypeField = clazz.getDeclaredField("tType");
                                                                                        tTypeField.setAccessible(true);
                                                                                        tTypeField.set(eigen, 0);       // Reset type
                                                                                        
                                                                                        // Call the method
                                                                                        Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                        computeShiftIncrement.setAccessible(true);
                                                                                        computeShiftIncrement.invoke(eigen, startField.get(eigen), endField.get(eigen), deflatedField.get(eigen));
                                                                                        
                                                                                        // Verify the results - these values are specific to the original division behavior
                                                                                        // The mutated multiplication would produce different values
                                                                                        assertEquals(-5, tTypeField.get(eigen));  // Verify we're in case 5
                                                                                        
                                                                                        // Calculate expected value based on original division behavior
                                                                                        double expectedB2 = work[nn - 13] / work[nn - 15];  // 0.5
                                                                                        double expectedA2 = (work[nn - 8] / work[nn - 6]) * (1 + work[nn - 4] / work[nn - 2]);
                                                                                        expectedA2 += expectedB2;  // From the loop
                                                                                        expectedA2 = 1.05 * expectedA2;  // cnst3 multiplication
                                                                                        
                                                                                        double expectedTau;
                                                                                        if (expectedA2 < 0.563) {  // cnst1
                                                                                            expectedTau = (Double) dN2Field.get(eigen) * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                        } else {
                                                                                            expectedTau = 0.25 * (Double) dMinField.get(eigen);
                                                                                        }
                                                                                        
                                                                                        Field tauField = clazz.getDeclaredField("tau");
                                                                                        tauField.setAccessible(true);
                                                                                        assertEquals(expectedTau, (Double) tauField.get(eigen), 1e-10);
                                                                                    }

    @Test
                                                                               public void testComputeShiftIncrementCase5DetectsDivisionOrderMutant() throws Exception {
                                                                                   // Setup test case for case 5 (dMin == dN2)
                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                   
                                                                                   // Use reflection to set private fields
                                                                                   Class<?> clazz = eigen.getClass();
                                                                                   
                                                                                   // Set required field values to trigger case 5
                                                                                   Field dMinField = clazz.getDeclaredField("dMin");
                                                                                   dMinField.setAccessible(true);
                                                                                   dMinField.setDouble(eigen, 4.0);
                                                                                   
                                                                                   Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                   dN2Field.setAccessible(true);
                                                                                   dN2Field.setDouble(eigen, 4.0);
                                                                                   
                                                                                   Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                   dMin1Field.setAccessible(true);
                                                                                   dMin1Field.setDouble(eigen, 3.0);
                                                                                   
                                                                                   Field dN1Field = clazz.getDeclaredField("dN1");
                                                                                   dN1Field.setAccessible(true);
                                                                                   dN1Field.setDouble(eigen, 2.0);
                                                                                   
                                                                                   Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                   dMin2Field.setAccessible(true);
                                                                                   dMin2Field.setDouble(eigen, 4.0);
                                                                                   
                                                                                   Field tTypeField = clazz.getDeclaredField("tType");
                                                                                   tTypeField.setAccessible(true);
                                                                                   tTypeField.setInt(eigen, 0);
                                                                                   
                                                                                   Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                   pingPongField.setAccessible(true);
                                                                                   pingPongField.setInt(eigen, 0);
                                                                                   
                                                                                   Field endField = clazz.getDeclaredField("end");
                                                                                   endField.setAccessible(true);
                                                                                   endField.setInt(eigen, 10); // nn = 4*10 + 0 - 1 = 39
                                                                                   
                                                                                   // Setup work array with specific values at critical indices
                                                                                   double[] work = new double[40];
                                                                                   work[39 - 13] = 8.0; // work[nn-13] = work[26]
                                                                                   work[39 - 15] = 2.0; // work[nn-15] = work[24]
                                                                                   // Other required work array values
                                                                                   work[39 - 2] = 1.0;  // work[37]
                                                                                   work[39 - 6] = 1.0;  // work[33]
                                                                                   work[39 - 8] = 0.5;  // work[31]
                                                                                   work[39 - 4] = 0.5;  // work[35]
                                                                                   work[39 - 17] = 1.0; // work[22]
                                                                                   work[39 - 15] = 2.0; // work[24] (already set)
                                                                                   
                                                                                   Field workField = clazz.getDeclaredField("work");
                                                                                   workField.setAccessible(true);
                                                                                   workField.set(eigen, work);
                                                                                   
                                                                                   // Call the private method using reflection
                                                                                   Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                   computeShiftIncrement.setAccessible(true);
                                                                                   computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                                   
                                                                                   // Calculate expected values based on original code
                                                                                   double expectedB2 = 8.0 / 2.0; // 4.0
                                                                                   double expectedA2 = (0.5 / 1.0) * (1 + 0.5 / 1.0) + expectedB2; // 0.5*1.5 + 4 = 4.75
                                                                                   expectedA2 = 1.05 * expectedA2; // cnst3 = 1.05
                                                                                   double expectedTau;
                                                                                   if (expectedA2 < 0.563) { // cnst1 = 0.563
                                                                                       expectedTau = 4.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                   } else {
                                                                                       expectedTau = 0.25 * 4.0; // 1.0
                                                                                   }
                                                                                   
                                                                                   // Verify tau matches expected calculation
                                                                                   Field tauField = clazz.getDeclaredField("tau");
                                                                                   tauField.setAccessible(true);
                                                                                   double actualTau = tauField.getDouble(eigen);
                                                                                   assertEquals("Tau should match expected calculation", expectedTau, actualTau, 1e-10);
                                                                                   
                                                                                   // Also verify tType was set correctly
                                                                                   int actualTType = tTypeField.getInt(eigen);
                                                                                   assertEquals("tType should be -5 for case 5", -5, actualTType);
                                                                               }

    @Test
                                                                          public void testComputeShiftIncrementCase4DetectsAdditionMutation1() {
                                                                              // Setup test case for case 4 (dMin == dN but dMin1 != dN1)
                                                                              EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                              
                                                                              // Use reflection to set private fields since we need specific conditions
                                                                              try {
                                                                                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                  dMinField.setAccessible(true);
                                                                                  dMinField.set(eigen, 1.0);
                                                                                  
                                                                                  Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                  dNField.setAccessible(true);
                                                                                  dNField.set(eigen, 1.0);
                                                                                  
                                                                                  Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                  dMin1Field.setAccessible(true);
                                                                                  dMin1Field.set(eigen, 2.0); // Different from dN1 to trigger case 4
                                                                                  
                                                                                  Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                  dN1Field.setAccessible(true);
                                                                                  dN1Field.set(eigen, 3.0);
                                                                                  
                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                  workField.setAccessible(true);
                                                                                  // Setup work array to trigger the loop with multiple iterations
                                                                                  // nn = 4*end + pingPong - 1 = 4*1 + 0 - 1 = 3 (assuming end=1, pingPong=0)
                                                                                  // We need work[nn-5] (= work[-2]) to be <= work[nn-7] (= work[-4])
                                                                                  // So we'll create a work array with size 20 and set appropriate values
                                                                                  double[] work = new double[20];
                                                                                  work[14] = 2.0; // work[nn-5] when nn=19 (for end=5, pingPong=0)
                                                                                  work[12] = 3.0; // work[nn-7]
                                                                                  work[10] = 4.0; // work[nn-9]
                                                                                  work[8] = 1.0;  // work[nn-11]
                                                                                  work[4] = 0.5;  // work[i4] values that will be compared in loop
                                                                                  work[0] = 0.25;
                                                                                  workField.set(eigen, work);
                                                                                  
                                                                                  Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                  endField.setAccessible(true);
                                                                                  endField.set(eigen, 5); // So nn=19
                                                                                  
                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                  pingPongField.setAccessible(true);
                                                                                  pingPongField.set(eigen, 0);
                                                                                  
                                                                                  Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                  startField.setAccessible(true);
                                                                                  startField.set(eigen, 0);
                                                                                  
                                                                                  // Use reflection to access the private method
                                                                                  Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                      "computeShiftIncrement", int.class, int.class, int.class);
                                                                                  computeShiftIncrement.setAccessible(true);
                                                                                  computeShiftIncrement.invoke(eigen, 0, 5, 0);
                                                                                  
                                                                              } catch (Exception e) {
                                                                                  fail("Failed to set up test via reflection: " + e.getMessage());
                                                                              }
                                                                              
                                                                              // Verify the results
                                                                              try {
                                                                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                  tauField.setAccessible(true);
                                                                                  double tau = tauField.getDouble(eigen);
                                                                                  
                                                                                  // The exact expected value depends on the complex calculations,
                                                                                  // but we know it should be greater than what the mutant would produce
                                                                                  // since the mutant subtracts instead of adds in the accumulation
                                                                                  assertTrue("Tau value should be positive", tau > 0);
                                                                                  
                                                                                  // For this specific setup, we can calculate approximately what we expect
                                                                                  // The original code would produce a tau around 0.25 while the mutant would produce a negative value
                                                                                  assertEquals("Tau value not as expected", 0.25, tau, 0.1);
                                                                                  
                                                                              } catch (Exception e) {
                                                                                  fail("Failed to verify results: " + e.getMessage());
                                                                              }
                                                                          }

    @Test
                                                                      public void testComputeShiftIncrementCase4DetectsMutant1() {
                                                                          // Setup test data to trigger case 4
                                                                          EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{0.0}, new double[]{0.0}, 1.0);
                                                                          
                                                                          // Use reflection to access private fields since we need to set them up
                                                                          try {
                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                              workField.setAccessible(true);
                                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                              dMinField.setAccessible(true);
                                                                              Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                              dNField.setAccessible(true);
                                                                              Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                              dMin1Field.setAccessible(true);
                                                                              Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                              dN1Field.setAccessible(true);
                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                              pingPongField.setAccessible(true);
                                                                              Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                              endField.setAccessible(true);
                                                                              Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                              startField.setAccessible(true);
                                                                              
                                                                              // Set up values to trigger case 4
                                                                              double[] work = new double[100];
                                                                              // Setup work array values that will be used in calculations
                                                                              work[91] = 2.0;  // nn-9 (when nn=100)
                                                                              work[93] = 1.0;  // nn-7
                                                                              work[95] = 1.0;  // nn-5
                                                                              work[97] = 0.5;  // nn-3
                                                                              work[87] = 0.5;  // nn-13
                                                                              work[83] = 0.5;  // nn-17
                                                                              work[79] = 0.5;  // nn-21 (for the loop)
                                                                              
                                                                              workField.set(decomposition, work);
                                                                              dMinField.setDouble(decomposition, 1.0);  // dMin == dN
                                                                              dNField.setDouble(decomposition, 1.0);
                                                                              dMin1Field.setDouble(decomposition, 2.0);  // dMin1 != dN1
                                                                              dN1Field.setDouble(decomposition, 3.0);
                                                                              pingPongField.setInt(decomposition, 0);
                                                                              endField.setInt(decomposition, 25);  // nn = 4*25 + 0 - 1 = 99
                                                                              startField.setInt(decomposition, 0);
                                                                              
                                                                              // Call the method with deflated=0 to trigger case 4
                                                                              Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                  int.class, int.class, int.class);
                                                                              method.setAccessible(true);
                                                                              method.invoke(decomposition, 0, 25, 0);
                                                                              
                                                                              // Get the resulting tau value
                                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                              tauField.setAccessible(true);
                                                                              double tau = tauField.getDouble(decomposition);
                                                                              
                                                                              // Verify the tau value is calculated correctly (with accumulation)
                                                                              // The exact expected value depends on the calculations, but it should be > 0
                                                                              // and different from what the mutant would produce
                                                                              assertTrue("Tau should be positive", tau > 0);
                                                                              
                                                                              // For the specific case, we can calculate approximately what we expect
                                                                              // The original code accumulates b2 values, while mutant just assigns
                                                                              // So we expect a significant difference
                                                                              double expectedTau = 0.25 * 1.0;  // Initial s value
                                                                              assertNotEquals("Tau should not match mutant value", expectedTau, tau, 0.0001);
                                                                              
                                                                          } catch (Exception e) {
                                                                              fail("Test failed due to reflection exception: " + e.getMessage());
                                                                          }
                                                                      }

    @Test
                                                                    public void testComputeShiftIncrementCase5DetectsLoopIncrementMutation() throws Exception {
                                                                        // Setup test case for case 5 (dMin == dN2)
                                                                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                        
                                                                        // Reflection utility to set private fields
                                                                        Class<?> clazz = eigen.getClass();
                                                                        
                                                                        // Set required fields through reflection since they're private
                                                                        Field dMinField = clazz.getDeclaredField("dMin");
                                                                        dMinField.setAccessible(true);
                                                                        dMinField.set(eigen, 1.0);
                                                                        
                                                                        Field dN2Field = clazz.getDeclaredField("dN2");
                                                                        dN2Field.setAccessible(true);
                                                                        dN2Field.set(eigen, 1.0);  // Triggers case 5
                                                                        
                                                                        Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                        pingPongField.setAccessible(true);
                                                                        pingPongField.setInt(eigen, 0);
                                                                        
                                                                        Field startField = clazz.getDeclaredField("start");
                                                                        startField.setAccessible(true);
                                                                        startField.setInt(eigen, 0);
                                                                        
                                                                        Field endField = clazz.getDeclaredField("end");
                                                                        endField.setAccessible(true);
                                                                        endField.setInt(eigen, 10);  // Need end-start > 3 to enter the loop
                                                                        
                                                                        // Create work array where processing every 2nd vs 4th element makes a difference
                                                                        double[] work = new double[100];
                                                                        work[80] = 1.0;  // np-8 (nn=4*end+pingPong-1=39, np=nn-2*pingPong=39)
                                                                        work[76] = 2.0;  // np-4
                                                                        work[75] = 3.0;  // np-3 (b1)
                                                                        work[74] = 4.0;  // np-2 (b1)
                                                                        work[73] = 5.0;  // np-1
                                                                        work[72] = 6.0;  // np (b2)
                                                                        work[71] = 7.0;  // np+1
                                                                        work[70] = 8.0;  // np+2
                                                                        work[26] = 0.5;  // nn-13 (4*10+0-1=39, 39-13=26)
                                                                        work[24] = 0.6;  // nn-15
                                                                        work[22] = 0.4;  // Will be accessed with i4 -= 4
                                                                        work[20] = 0.3;
                                                                        work[18] = 0.2;
                                                                        
                                                                        Field workField = clazz.getDeclaredField("work");
                                                                        workField.setAccessible(true);
                                                                        workField.set(eigen, work);
                                                                        
                                                                        // Call the private method using reflection
                                                                        Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                        computeShiftIncrement.setAccessible(true);
                                                                        computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                        
                                                                        // Get the results using reflection
                                                                        Field tauField = clazz.getDeclaredField("tau");
                                                                        tauField.setAccessible(true);
                                                                        double tau = tauField.getDouble(eigen);
                                                                        
                                                                        Field tTypeField = clazz.getDeclaredField("tType");
                                                                        tTypeField.setAccessible(true);
                                                                        int tType = tTypeField.getInt(eigen);
                                                                        
                                                                        // Verify the results
                                                                        // The exact expected value depends on the precise calculations,
                                                                        // but the key is that with i4 -=4, it should process different elements
                                                                        // than with i4 -=2, leading to a different tau
                                                                        assertEquals(-5, tType);
                                                                        // This value would be different if the loop increment was mutated
                                                                        assertEquals(0.25, tau, 1e-10);
                                                                    }

    @Test
                                                               public void testComputeShiftIncrementCase5LoopBoundary1() throws Exception {
                                                                   // Setup test case for case 5 where loop boundary matters
                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0e-6);
                                                                   
                                                                   // Helper method to set private fields
                                                                   java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                   dMinField.setAccessible(true);
                                                                   dMinField.set(eigen, 1.0);
                                                                   
                                                                   java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                   dN2Field.setAccessible(true);
                                                                   dN2Field.set(eigen, 1.0);  // triggers case 5
                                                                   
                                                                   java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                   pingPongField.setAccessible(true);
                                                                   pingPongField.set(eigen, 0);
                                                                   
                                                                   java.lang.reflect.Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                   startField.setAccessible(true);
                                                                   startField.set(eigen, 1);
                                                                   
                                                                   java.lang.reflect.Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                   endField.setAccessible(true);
                                                                   endField.set(eigen, 5);  // end-start > 3
                                                                   
                                                                   java.lang.reflect.Field nnField = EigenDecompositionImpl.class.getDeclaredField("nn");
                                                                   nnField.setAccessible(true);
                                                                   nnField.set(eigen, 25);  // nn = 4*end + pingPong - 1
                                                                   
                                                                   // Setup work array to control loop behavior
                                                                   double[] work = new double[30];
                                                                   // Values that will make the loop terminate based on boundary condition
                                                                   work[25-8] = 1.0;  // work[np-8]
                                                                   work[25-4] = 1.0;  // work[np-4]
                                                                   work[25-13] = 1.0; // work[nn-13]
                                                                   work[25-15] = 1.0; // work[nn-15]
                                                                   // Setup values that would make the loop stop at boundary
                                                                   for (int i = 4*1 + 2; i <= 25-17; i += 4) {
                                                                       work[i] = 0.5;    // work[i4]
                                                                       work[i-2] = 1.0;  // work[i4-2]
                                                                   }
                                                                   
                                                                   java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                   workField.setAccessible(true);
                                                                   workField.set(eigen, work);
                                                                   
                                                                   // Call the method
                                                                   java.lang.reflect.Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                       "computeShiftIncrement", int.class, int.class, int.class);
                                                                   computeShiftIncrement.setAccessible(true);
                                                                   computeShiftIncrement.invoke(eigen, 1, 5, 0);
                                                                   
                                                                   // Get results
                                                                   java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                   tauField.setAccessible(true);
                                                                   double tau = (Double) tauField.get(eigen);
                                                                   
                                                                   java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                   tTypeField.setAccessible(true);
                                                                   int tType = (Integer) tTypeField.get(eigen);
                                                                   
                                                                   // Verify results - the mutated version would process one extra iteration
                                                                   // leading to different tau value
                                                                   assertEquals(-5, tType);
                                                                   // The exact expected value depends on the implementation details,
                                                                   // but we know it should be 0.25 * dMin (which is 0.25) if a2 >= cnst1
                                                                   // or calculated value if a2 < cnst1
                                                                   // The mutation would affect a2 calculation
                                                                   assertTrue(tau == 0.25 || (tau > 0 && tau < 0.25));
                                                               }

    @Test
                                                          public void testComputeShiftIncrement_Case5_BoundaryCondition() throws Exception {
                                                              // Setup test case for case 5 (dMin == dN2)
                                                              EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                              
                                                              // Helper method to set private fields
                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                              dMinField.setAccessible(true);
                                                              dMinField.set(eigen, 1.0);
                                                              
                                                              Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                              dN2Field.setAccessible(true);
                                                              dN2Field.set(eigen, 1.0);
                                                              
                                                              Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                              tTypeField.setAccessible(true);
                                                              tTypeField.set(eigen, 0);
                                                              
                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                              pingPongField.setAccessible(true);
                                                              pingPongField.set(eigen, 0);
                                                              
                                                              Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                              endField.setAccessible(true);
                                                              endField.set(eigen, 5);  // This will make nn = 4*5 + 0 - 1 = 19
                                                              
                                                              // Create work array with specific values that will make the loop execute exactly on boundary
                                                              double[] work = new double[30];
                                                              work[19 - 2] = 1.0;   // np-2
                                                              work[19 - 6] = 1.0;    // np-6
                                                              work[19 - 8] = 0.5;    // np-8
                                                              work[19 - 4] = 0.5;    // np-4
                                                              work[19 - 13] = 0.1;   // nn-13
                                                              work[19 - 15] = 1.0;   // nn-15
                                                              
                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                              workField.setAccessible(true);
                                                              workField.set(eigen, work);
                                                              
                                                              // Set start to 0 which makes boundary condition: 4*0 + 2 + 0 = 2
                                                              Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                              startField.setAccessible(true);
                                                              startField.set(eigen, 0);
                                                              
                                                              // Call the private method using reflection
                                                              Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                  "computeShiftIncrement", int.class, int.class, int.class);
                                                              computeShiftIncrement.setAccessible(true);
                                                              computeShiftIncrement.invoke(eigen, 0, 5, 0);
                                                              
                                                              // Verify results
                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                              tauField.setAccessible(true);
                                                              double tau = (Double)tauField.get(eigen);
                                                              assertEquals(0.25, tau, 1e-10);  // Expected value when loop runs boundary case
                                                              
                                                              // Also verify tType was set correctly
                                                              int tType = (Integer)tTypeField.get(eigen);
                                                              assertEquals(-5, tType);
                                                          }

    @Test
                                                      public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant3() {
                                                          // Setup test data to trigger case 5
                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                          
                                                          // Use reflection to set private fields since we need specific conditions
                                                          try {
                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                              dMinField.setAccessible(true);
                                                              dMinField.set(eigen, 5.0);
                                                              
                                                              Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                              dN2Field.setAccessible(true);
                                                              dN2Field.set(eigen, 5.0);
                                                              
                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                              workField.setAccessible(true);
                                                              
                                                              // Create work array with specific values that will show difference between / and *
                                                              // np = nn - 2 * pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*end - pingPong - 1
                                                              // For end=1, pingPong=0: np=3
                                                              // So we need work[np-8] = work[-5] - but negative indices are invalid
                                                              // Let's use end=3, pingPong=0: np=11
                                                              // Then work[np-8]=work[3], work[np-4]=work[7], work[np-2]=work[9], work[np-6]=work[5]
                                                              double[] work = new double[20];
                                                              work[3] = 2.0;  // work[np-8]
                                                              work[5] = 4.0;  // b2
                                                              work[7] = 3.0;  // work[np-4]
                                                              work[9] = 6.0;  // b1
                                                              work[11] = 1.0; // work[np]
                                                              workField.set(eigen, work);
                                                              
                                                              Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                              endField.setAccessible(true);
                                                              endField.set(eigen, 3);
                                                              
                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                              pingPongField.setAccessible(true);
                                                              pingPongField.set(eigen, 0);
                                                              
                                                              // Call the method with deflated=0 to enter case 5
                                                              Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                  int.class, int.class, int.class);
                                                              method.setAccessible(true);
                                                              method.invoke(eigen, 0, 3, 0);
                                                              
                                                              // Verify tau value - original would be:
                                                              // a2 = (2/4)*(1 + 3/6) = 0.5*1.5 = 0.75
                                                              // mutant would be: 2*4*(1 + 3/6) = 8*1.5 = 12.0
                                                              // Then tau would be gam*(1-sqrt(a2))/(1+a2) = 5*(1-sqrt(0.75))/(1.75) ≈ 0.669179
                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                              tauField.setAccessible(true);
                                                              double tau = tauField.getDouble(eigen);
                                                              
                                                              assertEquals(0.669179, tau, 0.0001);
                                                              
                                                          } catch (Exception e) {
                                                              fail("Failed due to reflection exception: " + e.getMessage());
                                                          }
                                                      }

    @Test
                                                     public void testComputeShiftIncrementCase5DetectsMutant6() {
                                                         // Setup test case for case 5 (dMin == dN2)
                                                         EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                         
                                                         // Use reflection to access private fields since we need to set them for the test
                                                         try {
                                                             Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                             dMinField.setAccessible(true);
                                                             dMinField.set(eigen, 10.0); // Set dMin
                                                             
                                                             Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                             dN2Field.setAccessible(true);
                                                             dN2Field.set(eigen, 10.0); // Set dN2 = dMin to trigger case 5
                                                             
                                                             Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                             workField.setAccessible(true);
                                                             
                                                             // Create work array with specific values that will make the mutation detectable
                                                             // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*end - pingPong - 1
                                                             // For end=5, pingPong=0: np=19
                                                             // So np-8=11, np-4=15, np-2=17, np-6=13
                                                             double[] work = new double[20];
                                                             work[11] = 4.0;  // work[np-8]
                                                             work[15] = 3.0;  // work[np-4]
                                                             work[17] = 2.0;  // b1 = work[np-2]
                                                             work[13] = 2.0;  // b2 = work[np-6]
                                                             workField.set(eigen, work);
                                                             
                                                             Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                             pingPongField.setAccessible(true);
                                                             pingPongField.set(eigen, 0);
                                                             
                                                             Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                             endField.setAccessible(true);
                                                             endField.set(eigen, 5);
                                                             
                                                             // Call the method with deflated=0 (case 5 is in deflated=0 branch)
                                                             Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                 "computeShiftIncrement", int.class, int.class, int.class);
                                                             computeShiftIncrement.setAccessible(true);
                                                             computeShiftIncrement.invoke(eigen, 0, 5, 0);
                                                             
                                                             // Get the tau value
                                                             Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                             tauField.setAccessible(true);
                                                             double tau = tauField.getDouble(eigen);
                                                             
                                                             // Calculate expected value
                                                             double b1 = 2.0; // work[17]
                                                             double b2 = 2.0; // work[13]
                                                             double a2 = (4.0/2.0) * (1 + 3.0/2.0); // (work[11]/b2)*(1 + work[15]/b1)
                                                             double expectedTau = 0.25 * 10.0; // s = 0.25*dMin
                                                             if (a2 < 0.563) { // cnst1
                                                                 double gam = 10.0; // dN2
                                                                 expectedTau = gam * (1 - Math.sqrt(a2)) / (1 + a2);
                                                             }
                                                             
                                                             // Verify tau matches expected calculation
                                                             assertEquals("Tau value should match expected calculation for case 5", 
                                                                         expectedTau, tau, 1e-10);
                                                             
                                                         } catch (Exception e) {
                                                             fail("Test failed due to reflection exception: " + e.getMessage());
                                                         }
                                                     }

    @Test
                                                   public void testComputeShiftIncrementCase5DetectsMutant7() throws Exception {
                                                       // Setup test case for case 5 (dMin == dN2)
                                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                       
                                                       // Use reflection to set private fields
                                                       Class<?> clazz = eigen.getClass();
                                                       
                                                       // Set required field values to enter case 5
                                                       Field dMinField = clazz.getDeclaredField("dMin");
                                                       dMinField.setAccessible(true);
                                                       dMinField.setDouble(eigen, 4.0);
                                                       
                                                       Field dN2Field = clazz.getDeclaredField("dN2");
                                                       dN2Field.setAccessible(true);
                                                       dN2Field.setDouble(eigen, 4.0);
                                                       
                                                       Field deflatedField = clazz.getDeclaredField("deflated");
                                                       deflatedField.setAccessible(true);
                                                       deflatedField.setInt(eigen, 0);
                                                       
                                                       Field endField = clazz.getDeclaredField("end");
                                                       endField.setAccessible(true);
                                                       endField.setInt(eigen, 10);
                                                       
                                                       Field pingPongField = clazz.getDeclaredField("pingPong");
                                                       pingPongField.setAccessible(true);
                                                       pingPongField.setInt(eigen, 1);
                                                       
                                                       Field tTypeField = clazz.getDeclaredField("tType");
                                                       tTypeField.setAccessible(true);
                                                       tTypeField.setInt(eigen, 0);
                                                       
                                                       // Create work array with specific values that will make the mutation detectable
                                                       // Choose values where (a/b)*(1+c/d) != (a/b)+(1+c/d)
                                                       double[] work = new double[100];
                                                       int np = 4 * (Integer)endField.get(eigen) + (Integer)pingPongField.get(eigen) - 1 - 2 * (Integer)pingPongField.get(eigen); // np = nn - 2*pingPong
                                                       work[np - 2] = 2.0;  // b1
                                                       work[np - 4] = 3.0;   // work[np-4]
                                                       work[np - 6] = 4.0;   // b2
                                                       work[np - 8] = 5.0;   // work[np-8]
                                                       
                                                       // Fill other required work array elements
                                                       work[np - 13] = 1.0;
                                                       work[np - 15] = 1.0;
                                                       work[np - 17] = 1.0;
                                                       
                                                       // Set the work array
                                                       Field workField = clazz.getDeclaredField("work");
                                                       workField.setAccessible(true);
                                                       workField.set(eigen, work);
                                                       
                                                       // Calculate expected a2 value from original code
                                                       double expectedA2 = (work[np - 8] / work[np - 6]) * (1 + work[np - 4] / work[np - 2]);
                                                       
                                                       // Call the method
                                                       Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                       computeShiftIncrement.setAccessible(true);
                                                       computeShiftIncrement.invoke(eigen, 0, (Integer)endField.get(eigen), (Integer)deflatedField.get(eigen));
                                                       
                                                       // Verify the results would be different with the mutant
                                                       // In original code, a2 would be (5/4)*(1+3/2) = 1.25*2.5 = 3.125
                                                       // In mutant code, a2 would be (5/4)+(1+3/2) = 1.25+2.5 = 3.75
                                                       // This difference should propagate to tau calculation
                                                       
                                                       // Calculate what tau should be with original a2 value
                                                       double cnst3 = 1.05;
                                                       double cnst1 = 0.563;
                                                       double gam = (Double)dN2Field.get(eigen);
                                                       double s = 0.25 * (Double)dMinField.get(eigen);
                                                       double a2 = cnst3 * (expectedA2 + 1.0); // simplified for test case
                                                       
                                                       double expectedTau;
                                                       if (a2 < cnst1) {
                                                           expectedTau = gam * (1 - Math.sqrt(a2)) / (1 + a2);
                                                       } else {
                                                           expectedTau = s;
                                                       }
                                                       
                                                       // Get tau value using reflection
                                                       Field tauField = clazz.getDeclaredField("tau");
                                                       tauField.setAccessible(true);
                                                       double actualTau = (Double)tauField.get(eigen);
                                                       
                                                       // Assert that tau matches expected value from original calculation
                                                       assertEquals("Tau value should match original calculation", expectedTau, actualTau, 1e-10);
                                                       
                                                       // Also verify tType was set correctly
                                                       int actualTType = (Integer)tTypeField.get(eigen);
                                                       assertEquals("tType should be -5 for case 5", -5, actualTType);
                                                   }

    @Test
                                              public void testComputeShiftIncrementCase5DetectsMutant8() throws Exception {
                                                  // Setup test data for case 5 (dMin == dN2)
                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                  
                                                  // Use reflection to set private fields
                                                  Class<?> clazz = EigenDecompositionImpl.class;
                                                  
                                                  // Set dMin
                                                  Field dMinField = clazz.getDeclaredField("dMin");
                                                  dMinField.setAccessible(true);
                                                  dMinField.set(eigen, 4.0);  // Will be used as dN2
                                                  
                                                  // Set dN2
                                                  Field dN2Field = clazz.getDeclaredField("dN2");
                                                  dN2Field.setAccessible(true);
                                                  dN2Field.set(eigen, 4.0);
                                                  
                                                  // Set pingPong
                                                  Field pingPongField = clazz.getDeclaredField("pingPong");
                                                  pingPongField.setAccessible(true);
                                                  pingPongField.setInt(eigen, 0);
                                                  
                                                  // Set end (assuming it's a field in the class)
                                                  Field endField = clazz.getDeclaredField("end");
                                                  endField.setAccessible(true);
                                                  endField.setInt(eigen, 10);  // end affects nn calculation
                                                  
                                                  // Setup work array values for case 5
                                                  // np = nn - 2*pingPong = (4*end + pingPong -1) - 2*pingPong = 4*10 + 0 -1 -0 = 39
                                                  // So np-8 = 31, np-4 = 35, np-6 = 33, np-2 = 37
                                                  Field workField = clazz.getDeclaredField("work");
                                                  workField.setAccessible(true);
                                                  double[] work = new double[40];  // Need at least 39 elements
                                                  work[31] = 8.0;  // work[np-8]
                                                  work[35] = 4.0;  // work[np-4]
                                                  work[33] = 2.0;  // b2 = work[np-6]
                                                  work[37] = 6.0;  // b1 = work[np-2]
                                                  workField.set(eigen, work);
                                                  
                                                  // Calculate expected a2 using original formula
                                                  double expectedB1 = 6.0;
                                                  double expectedB2 = 2.0;
                                                  double expectedA2 = (8.0/expectedB2) * (1 + 4.0/expectedB1);
                                                  
                                                  // Call the private method using reflection
                                                  Method computeShiftIncrementMethod = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                  computeShiftIncrementMethod.setAccessible(true);
                                                  computeShiftIncrementMethod.invoke(eigen, 0, 10, 0);
                                                  
                                                  // Verify results
                                                  // Since a2 < cnst1 (0.563), tau should be gam*(1-sqrt(a2))/(1+a2)
                                                  // gam = dN2 = 4.0
                                                  double expectedTau = 4.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                  
                                                  // Get tau field value
                                                  Field tauField = clazz.getDeclaredField("tau");
                                                  tauField.setAccessible(true);
                                                  double actualTau = tauField.getDouble(eigen);
                                                  
                                                  // Get tType field value
                                                  Field tTypeField = clazz.getDeclaredField("tType");
                                                  tTypeField.setAccessible(true);
                                                  int actualTType = tTypeField.getInt(eigen);
                                                  
                                                  assertEquals("Tau value should match expected calculation", 
                                                              expectedTau, actualTau, 1e-10);
                                                  assertEquals("Type should be -5 for case 5", -5, actualTType);
                                              }

    @Test
                                         public void testComputeShiftIncrementCase5WithEndStartEquals() throws Exception {
                                             // Setup test case where end - start = 3 (boundary case)
                                             int start = 0;
                                             int end = 3;
                                             int deflated = 0; // case 0 in switch
                                             int pingPong = 0;
                                             
                                             // Create instance
                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                             
                                             // Use reflection to set private fields
                                             Class<?> clazz = eigen.getClass();
                                             
                                             // Set tType
                                             Field tTypeField = clazz.getDeclaredField("tType");
                                             tTypeField.setAccessible(true);
                                             tTypeField.setInt(eigen, 0);
                                             
                                             // Set dMin
                                             Field dMinField = clazz.getDeclaredField("dMin");
                                             dMinField.setAccessible(true);
                                             dMinField.setDouble(eigen, 1.0);
                                             
                                             // Set dN2
                                             Field dN2Field = clazz.getDeclaredField("dN2");
                                             dN2Field.setAccessible(true);
                                             dN2Field.setDouble(eigen, 1.0); // triggers case 5
                                             
                                             // Set pingPong
                                             Field pingPongField = clazz.getDeclaredField("pingPong");
                                             pingPongField.setAccessible(true);
                                             pingPongField.setInt(eigen, pingPong);
                                             
                                             // Setup work array (size depends on nn = 4*end + pingPong -1 = 11)
                                             double[] work = new double[12]; // index up to 11
                                             work[11-2] = 1.0;  // work[np-2] = work[9] = b1
                                             work[11-6] = 1.0;  // work[np-6] = work[5] = b2
                                             work[11-8] = 0.5;  // work[np-8] = work[3] (should be <= b2)
                                             work[11-4] = 0.5;  // work[np-4] = work[7] (should be <= b1)
                                             
                                             // For the case where end-start=3, we need to set values for nn-13 to nn-15
                                             // Note: These indices are invalid (negative) and will cause ArrayIndexOutOfBoundsException
                                             // So we'll skip these lines as they don't make sense in the test
                                             
                                             // Set work array
                                             Field workField = clazz.getDeclaredField("work");
                                             workField.setAccessible(true);
                                             workField.set(eigen, work);
                                             
                                             // Get computeShiftIncrement method
                                             Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                             computeShiftIncrement.setAccessible(true);
                                             computeShiftIncrement.invoke(eigen, start, end, deflated);
                                             
                                             // Verify behavior - original would skip the inner block when end-start=3
                                             // and use the initial s value (0.25 * dMin)
                                             double expectedTau = 0.25 * (Double)dMinField.get(eigen);
                                             
                                             // Get tau field
                                             Field tauField = clazz.getDeclaredField("tau");
                                             tauField.setAccessible(true);
                                             double tau = (Double)tauField.get(eigen);
                                             
                                             assertEquals("Tau should equal initial s value when end-start=3", 
                                                         expectedTau, tau, 1e-10);
                                             
                                             // Also verify tType was set correctly
                                             int tType = (Integer)tTypeField.get(eigen);
                                             assertEquals("tType should be -5 for this case", -5, tType);
                                         }

    @Test
                                    public void testComputeShiftIncrementCase5Boundary() throws Exception {
                                        // Setup test case where end - start = 3 to catch the mutant
                                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                        
                                        // Use reflection to access private fields
                                        Class<?> clazz = eigen.getClass();
                                        
                                        // Set up case 5 conditions (deflated=0, dMin=dN2)
                                        Field deflatedField = clazz.getDeclaredField("deflated");
                                        deflatedField.setAccessible(true);
                                        deflatedField.setInt(eigen, 0);
                                        
                                        Field dMinField = clazz.getDeclaredField("dMin");
                                        dMinField.setAccessible(true);
                                        dMinField.setDouble(eigen, 1.0);
                                        
                                        Field dN2Field = clazz.getDeclaredField("dN2");
                                        dN2Field.setAccessible(true);
                                        dN2Field.setDouble(eigen, 1.0);
                                        
                                        // Set up work array values needed for case 5 calculations
                                        Field workField = clazz.getDeclaredField("work");
                                        workField.setAccessible(true);
                                        double[] work = new double[20];
                                        work[14] = 1.0;  // work[np-8] = work[14] when nn=18, pingPong=0
                                        work[16] = 1.0;  // work[np-6] = work[16]
                                        work[12] = 1.0;  // work[np-4] = work[12]
                                        work[14] = 1.0;  // work[np-2] = work[14]
                                        workField.set(eigen, work);
                                        
                                        // Set start and end so that end - start = 3
                                        int start = 0;
                                        int end = 3;
                                        
                                        // Call the private method using reflection
                                        Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                        computeShiftIncrement.setAccessible(true);
                                        computeShiftIncrement.invoke(eigen, start, end, 0);
                                        
                                        // Verify the tau value - with end-start=3, original would skip the block
                                        // and use s=0.25*dMin, while mutant would execute the block and potentially
                                        // calculate a different tau
                                        Field tauField = clazz.getDeclaredField("tau");
                                        tauField.setAccessible(true);
                                        assertEquals(0.25, tauField.getDouble(eigen), 1e-10);
                                        
                                        // Also verify tType is set correctly for case 5
                                        Field tTypeField = clazz.getDeclaredField("tType");
                                        tTypeField.setAccessible(true);
                                        assertEquals(-5, tTypeField.getInt(eigen));
                                    }

    @Test
                               public void testComputeShiftIncrementCase5SmallRange() throws Exception {
                                   // Setup
                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                   
                                   // Use reflection to access private fields
                                   Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                   dMinField.setAccessible(true);
                                   dMinField.set(eigen, 5.0);
                                   
                                   Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                   dN2Field.setAccessible(true);
                                   dN2Field.set(eigen, 5.0);
                                   
                                   // Setup work array for case 5 calculations
                                   Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                   workField.setAccessible(true);
                                   double[] work = new double[20];
                                   work[13] = 1.0;  // nn-7 (np-6)
                                   work[9] = 2.0;   // nn-11
                                   work[17] = 1.0;  // nn-13
                                   work[15] = 2.0;  // nn-15
                                   workField.set(eigen, work);
                                   
                                   Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                   pingPongField.setAccessible(true);
                                   pingPongField.set(eigen, 1);
                                   
                                   // Get and invoke private method
                                   Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                       "computeShiftIncrement", int.class, int.class, int.class);
                                   computeShiftIncrementMethod.setAccessible(true);
                                   
                                   // Set small range (end - start <= 3)
                                   int start = 0;
                                   int end = 3;  // end - start = 3
                                   
                                   // Call method
                                   computeShiftIncrementMethod.invoke(eigen, start, end, 0);
                                   
                                   // Verify results - with original condition, inner block shouldn't execute for range=3
                                   // So tau should be just 0.25*dMin (from outer block)
                                   Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                   tauField.setAccessible(true);
                                   double tau = (Double)tauField.get(eigen);
                                   
                                   double expectedTau = 0.25 * (Double)dMinField.get(eigen);
                                   assertEquals("Tau should be 0.25*dMin for small range in case 5", 
                                                expectedTau, tau, 1e-10);
                                   
                                   // Also verify tType is set correctly for case 5
                                   Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                   tTypeField.setAccessible(true);
                                   int tType = (Integer)tTypeField.get(eigen);
                                   assertEquals("tType should be -5 for case 5", -5, tType);
                               }

    @Test
                          public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant4() throws Exception {
                              // Setup test case to trigger case 5 in computeShiftIncrement
                              EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                              
                              // Use reflection to set private fields
                              Class<?> clazz = eigen.getClass();
                              
                              // Set fields needed for case 5
                              Field dMinField = clazz.getDeclaredField("dMin");
                              dMinField.setAccessible(true);
                              dMinField.set(eigen, 4.0);
                              
                              Field dN2Field = clazz.getDeclaredField("dN2");
                              dN2Field.setAccessible(true);
                              dN2Field.set(eigen, 4.0);  // dMin == dN2
                              
                              Field pingPongField = clazz.getDeclaredField("pingPong");
                              pingPongField.setAccessible(true);
                              pingPongField.set(eigen, 0);
                              
                              // Setup work array with specific values that will show difference between / and *
                              // We need values where a/b != a*b
                              double[] work = new double[20];  // needs to be at least nn+1 = 20
                              work[19 - 13] = 6.0;  // work[nn-13] = work[6]
                              work[19 - 15] = 2.0;  // work[nn-15] = work[4]
                              // Original: b2 = 6/2 = 3
                              // Mutant:   b2 = 6*2 = 12
                              
                              Field workField = clazz.getDeclaredField("work");
                              workField.setAccessible(true);
                              workField.set(eigen, work);
                              
                              // Set other required fields
                              Field dMin1Field = clazz.getDeclaredField("dMin1");
                              dMin1Field.setAccessible(true);
                              dMin1Field.set(eigen, 1.0);
                              
                              Field dMin2Field = clazz.getDeclaredField("dMin2");
                              dMin2Field.setAccessible(true);
                              dMin2Field.set(eigen, 1.0);
                              
                              Field dNField = clazz.getDeclaredField("dN");
                              dNField.setAccessible(true);
                              dNField.set(eigen, 1.0);
                              
                              Field dN1Field = clazz.getDeclaredField("dN1");
                              dN1Field.setAccessible(true);
                              dN1Field.set(eigen, 1.0);
                              
                              // Call the private method
                              Method computeShiftIncrementMethod = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                              computeShiftIncrementMethod.setAccessible(true);
                              computeShiftIncrementMethod.invoke(eigen, 0, 5, 0);
                              
                              // Verify results
                              Field tauField = clazz.getDeclaredField("tau");
                              tauField.setAccessible(true);
                              double tau = (Double) tauField.get(eigen);
                              
                              // For this test, we'll verify tau is not 0.25*dMin (which is the default before calculation)
                              assertNotEquals(1.0, tau, 0.0001);
                              
                              // More precise verification would require full calculation, but this is sufficient
                              // to detect the division->multiplication change
                          }

    @Test
                      public void testComputeShiftIncrementCase5DetectsMutant9() {
                          // Setup test conditions for case 5
                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                          
                          // Use reflection to set private fields since we need specific conditions
                          try {
                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                              dMinField.setAccessible(true);
                              dMinField.set(eigen, 5.0); // dMin
                              
                              Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                              dN2Field.setAccessible(true);
                              dN2Field.set(eigen, 5.0); // dMin == dN2
                              
                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                              pingPongField.setAccessible(true);
                              pingPongField.set(eigen, 0); // pingPong
                              
                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                              workField.setAccessible(true);
                              double[] work = new double[100];
                              // Setup work array values that will make the division order matter
                              work[87] = 4.0; // nn-13 (100 - 4*3 + 0 - 1 = 87)
                              work[89] = 2.0; // nn-15
                              // Other required work values
                              work[85] = 1.0; // nn-11
                              work[83] = 1.0; // nn-9
                              work[81] = 1.0; // nn-7
                              work[93] = 1.0; // np-8 (nn-2*0-8=92)
                              work[95] = 1.0; // np-4
                              work[97] = 1.0; // np-2
                              work[91] = 1.0; // np-6
                              workField.set(eigen, work);
                              
                              Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                              endField.setAccessible(true);
                              endField.set(eigen, 10); // end
                              
                              Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                              startField.setAccessible(true);
                              startField.set(eigen, 5); // start (end-start > 3)
                              
                              // Call the method with deflated=0 to reach case 5
                              Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                  int.class, int.class, int.class);
                              method.setAccessible(true);
                              method.invoke(eigen, 5, 10, 0);
                              
                              // Verify results
                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                              tauField.setAccessible(true);
                              double tau = tauField.getDouble(eigen);
                              
                              // Calculate expected value with original division order
                              double expectedB2 = 4.0 / 2.0; // work[nn-13]/work[nn-15]
                              double expectedA2 = (1.0/1.0) * (1 + 1.0/1.0) + expectedB2;
                              expectedA2 = 1.05 * expectedA2; // cnst3
                              double expectedTau;
                              if (expectedA2 < 0.563) { // cnst1
                                  expectedTau = 5.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                              } else {
                                  expectedTau = 0.25 * 5.0;
                              }
                              
                              assertEquals("Tau value should match expected calculation", 
                                  expectedTau, tau, 1e-10);
                              
                          } catch (Exception e) {
                              fail("Test failed due to reflection exception: " + e.getMessage());
                          }
                      }

    @Test
                     public void testComputeShiftIncrementCase4DetectsAMinusBMutant() {
                         // Setup test case for case 4 (dMin == dN but dMin1 != dN1)
                         EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                         
                         // Use reflection to set private fields since we need specific conditions
                         try {
                             Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                             dMinField.setAccessible(true);
                             dMinField.set(eigen, 1.0); // dMin == dN
                             
                             Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                             dNField.setAccessible(true);
                             dNField.set(eigen, 1.0); // dMin == dN
                             
                             Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                             dMin1Field.setAccessible(true);
                             dMin1Field.set(eigen, 2.0); // dMin1 != dN1
                             
                             Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                             dN1Field.setAccessible(true);
                             dN1Field.set(eigen, 3.0); // dMin1 != dN1
                             
                             Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                             endField.setAccessible(true);
                             endField.set(eigen, 10); // arbitrary end value
                             
                             Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                             pingPongField.setAccessible(true);
                             pingPongField.set(eigen, 0); // set pingPong
                             
                             Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                             workField.setAccessible(true);
                             double[] work = new double[100];
                             // Setup work array to have values that will make b2 non-zero in the loop
                             // nn = 4*end + pingPong - 1 = 39
                             work[39-5] = 1.0; // work[nn-5]
                             work[39-7] = 2.0; // work[nn-7] (nn-5 > nn-7 to enter the branch)
                             work[39-9] = 1.0; // work[nn-9]
                             work[39-11] = 1.0; // work[nn-11]
                             // Setup values for the loop
                             for (int i = 4*5 + 2; i <= 39-13; i += 4) {
                                 work[i] = 1.0;   // work[i4]
                                 work[i-2] = 2.0; // work[i4-2] (work[i4] < work[i4-2])
                             }
                             workField.set(eigen, work);
                             
                             Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                             startField.setAccessible(true);
                             startField.set(eigen, 5); // arbitrary start value
                             
                             // Call the method with deflated = 0 to enter case 4
                             Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                 int.class, int.class, int.class);
                             method.setAccessible(true);
                             method.invoke(eigen, 5, 10, 0);
                             
                             // Verify tau value which depends on a2 calculation
                             Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                             tauField.setAccessible(true);
                             double tau = tauField.getDouble(eigen);
                             
                             // The original code would produce a different tau than the mutated one
                             // We know the original should produce a positive tau in this case
                             assertTrue("Tau should be positive", tau > 0);
                             
                             // More precise assertion would require exact calculation, but we know
                             // the mutated version would produce a different (likely smaller) value
                             // due to subtraction instead of addition
                             assertTrue("Tau should be greater than 0.1 in this case", tau > 0.1);
                             
                         } catch (Exception e) {
                             fail("Exception during test: " + e.getMessage());
                         }
                     }

    @Test
                   public void testComputeShiftIncrementCase4DetectsMutant2() throws Exception {
                       // Setup test conditions for case 4
                       EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{1, 1}, new double[]{1}, 0.0);
                       
                       // Use reflection to access private fields
                       Class<?> clazz = decomposition.getClass();
                       
                       // Set required field values for case 4
                       Field dMinField = clazz.getDeclaredField("dMin");
                       dMinField.setAccessible(true);
                       dMinField.setDouble(decomposition, 1.0);  // dMin == dN
                       
                       Field dNField = clazz.getDeclaredField("dN");
                       dNField.setAccessible(true);
                       dNField.setDouble(decomposition, 1.0);
                       
                       Field dMin1Field = clazz.getDeclaredField("dMin1");
                       dMin1Field.setAccessible(true);
                       dMin1Field.setDouble(decomposition, 2.0); // != dN1 to avoid other cases
                       
                       Field pingPongField = clazz.getDeclaredField("pingPong");
                       pingPongField.setAccessible(true);
                       pingPongField.setInt(decomposition, 0);
                       
                       Field workField = clazz.getDeclaredField("work");
                       workField.setAccessible(true);
                       double[] work = new double[100];
                       workField.set(decomposition, work);
                       
                       // Setup work array to trigger the loop with multiple iterations
                       // nn = 4*end + pingPong - 1 = 19 (assuming end=5)
                       work[19 - 5] = 1.0;  // work[nn-5]
                       work[19 - 7] = 2.0;  // work[nn-7]
                       // Setup values for the loop
                       work[19 - 9] = 1.0;  // work[nn-9]
                       work[19 - 11] = 1.0; // work[nn-11]
                       work[10] = 0.5;      // work[i4] in first iteration
                       work[8] = 1.0;       // work[i4-2]
                       work[6] = 0.25;      // work[i4] in second iteration
                       work[4] = 1.0;       // work[i4-2]
                       
                       // Call the private method using reflection
                       Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                       computeShiftIncrement.setAccessible(true);
                       computeShiftIncrement.invoke(decomposition, 0, 5, 0);
                       
                       // Get private fields for verification
                       Field a2Field = clazz.getDeclaredField("a2");
                       a2Field.setAccessible(true);
                       double a2 = a2Field.getDouble(decomposition);
                       
                       Field cnst1Field = clazz.getDeclaredField("cnst1");
                       cnst1Field.setAccessible(true);
                       double cnst1 = cnst1Field.getDouble(decomposition);
                       
                       Field gamField = clazz.getDeclaredField("gam");
                       gamField.setAccessible(true);
                       double gam = gamField.getDouble(decomposition);
                       
                       // Verify results - these values are based on the expected accumulation
                       double expectedTau = 0.0; // Will be set based on a2 calculation
                       if (a2 < cnst1) {
                           expectedTau = gam * (1 - Math.sqrt(a2)) / (1 + a2);
                       }
                       
                       Field tauField = clazz.getDeclaredField("tau");
                       tauField.setAccessible(true);
                       double tau = tauField.getDouble(decomposition);
                       
                       // Verify tau is calculated correctly based on accumulated a2
                       assertEquals("Tau should be calculated based on accumulated a2", 
                                   expectedTau, tau, 1e-10);
                       
                       Field tTypeField = clazz.getDeclaredField("tType");
                       tTypeField.setAccessible(true);
                       int tType = tTypeField.getInt(decomposition);
                       
                       // Also verify tType is set correctly for case 4
                       assertEquals("tType should be -4 for case 4", -4, tType);
                   }

    @Test
              public void testComputeShiftIncrementCase5DetectsLoopIncrementMutation1() throws Exception {
                  // Setup test case for scenario 5 (dMin == dN2)
                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                  
                  // Helper method to set private fields
                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                  dMinField.setAccessible(true);
                  dMinField.set(eigen, 1.0);
                  
                  Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                  dN2Field.setAccessible(true);
                  dN2Field.set(eigen, 1.0);  // Triggers case 5
                  
                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                  pingPongField.setAccessible(true);
                  pingPongField.set(eigen, 0);
                  
                  Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                  endField.setAccessible(true);
                  endField.set(eigen, 10);
                  
                  Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                  startField.setAccessible(true);
                  startField.set(eigen, 0);
                  
                  Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                  deflatedField.setAccessible(true);
                  deflatedField.set(eigen, 0);
                  
                  // Create work array where processing every 2nd vs 4th element makes a difference
                  double[] work = new double[100];
                  // Initialize values so that processing every 2nd element would produce different a2
                  for (int i = 0; i < work.length; i++) {
                      work[i] = (i % 4 == 0) ? 1.0 : 0.5;  // Only every 4th element is 1.0
                  }
                  
                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                  workField.setAccessible(true);
                  workField.set(eigen, work);
                  
                  // Call the private method using reflection
                  Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                      "computeShiftIncrement", int.class, int.class, int.class);
                  computeShiftIncrement.setAccessible(true);
                  computeShiftIncrement.invoke(eigen, 0, 10, 0);
                  
                  // Get the results using reflection
                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                  tauField.setAccessible(true);
                  double tau = (Double) tauField.get(eigen);
                  
                  Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                  tTypeField.setAccessible(true);
                  int tType = (Integer) tTypeField.get(eigen);
                  
                  // Verify the results - these values would differ if loop increment was changed
                  assertEquals(-5, tType);  // Should be case 5
                  // The exact tau value depends on the calculation, but with our setup,
                  // the mutated version would process different elements and produce different tau
                  assertTrue(tau > 0.0 && tau <= 0.25);  // tau should be between 0 and 0.25*dMin
              }

    @Test
         public void testComputeShiftIncrementDetectsLoopConditionMutant() throws Exception {
             // Setup test case for case 5 where the loop condition mutation would be detected
             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0e-6);
             
             // Helper method to set private fields
             Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
             deflatedField.setAccessible(true);
             deflatedField.set(eigen, 0);
             
             Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
             dMinField.setAccessible(true);
             dMinField.set(eigen, 1.0);
             
             Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
             dN2Field.setAccessible(true);
             dN2Field.set(eigen, 1.0); // dMin == dN2
             
             Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
             pingPongField.setAccessible(true);
             pingPongField.set(eigen, 0);
             
             Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
             startField.setAccessible(true);
             startField.set(eigen, 2);
             
             Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
             endField.setAccessible(true);
             endField.set(eigen, 6); // end-start > 3
             
             // Setup work array to control loop behavior
             double[] work = new double[100];
             // Setup values so the loop will be entered and conditions met
             work[4*6 - 2*0 - 8] = 1.0; // work[np-8]
             work[4*6 - 2*0 - 6] = 2.0; // work[np-6] (b2)
             work[4*6 - 2*0 - 4] = 1.0; // work[np-4]
             work[4*6 - 2*0 - 2] = 2.0; // work[np-2] (b1)
             
             // Setup values for the loop iterations
             // We need to make sure the loop runs differently in original vs mutated
             for (int i = 4*2 + 0; i < 4*6 - 17; i++) {
                 work[i] = 1.0;       // work[i4]
                 work[i-2] = 2.0;     // work[i4-2]
             }
             // Add special values at the boundary where the difference occurs
             work[4*2 + 0] = 1.0;     // Would be last iteration in mutated version
             work[4*2 + 0 - 2] = 2.0;
             
             Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
             workField.setAccessible(true);
             workField.set(eigen, work);
             
             // Call the private method using reflection
             Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                 "computeShiftIncrement", int.class, int.class, int.class);
             computeShiftIncrement.setAccessible(true);
             computeShiftIncrement.invoke(eigen, 2, 6, 0);
             
             // Get the results using reflection
             Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
             tauField.setAccessible(true);
             double tau = (Double)tauField.get(eigen);
             
             Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
             tTypeField.setAccessible(true);
             int tType = (Integer)tTypeField.get(eigen);
             
             // Verify the results - the exact values depend on the complex calculations
             // but we know tType should be -5 for this case
             assertEquals(-5, tType);
             // The tau value should be within expected bounds
             assertTrue(tau >= 0.0 && tau <= 0.25 * 1.0); // 0.25 * dMin
         }

    @Test
    public void testComputeShiftIncrement_Case5_LoopBoundary() throws Exception {
        // Setup
        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
        
        // Use reflection to access private fields
        Class<?> clazz = eigen.getClass();
        
        // Set up case 5 conditions (dMin == dN2)
        Field dMinField = clazz.getDeclaredField("dMin");
        dMinField.setAccessible(true);
        dMinField.set(eigen, 1.0);
        
        Field dN2Field = clazz.getDeclaredField("dN2");
        dN2Field.setAccessible(true);
        dN2Field.set(eigen, 1.0);
        
        Field tTypeField = clazz.getDeclaredField("tType");
        tTypeField.setAccessible(true);
        tTypeField.set(eigen, 0);
        
        // Set pingPong and start to create boundary condition
        Field pingPongField = clazz.getDeclaredField("pingPong");
        pingPongField.setAccessible(true);
        pingPongField.set(eigen, 1);
        
        int start = 5;
        int pingPong = (Integer) pingPongField.get(eigen);
        int nn = 4 * start + 2 + pingPong + 17; // So nn-17 == 4*start+2+pingPong
        
        // Initialize work array with values that would be affected by the boundary iteration
        Field workField = clazz.getDeclaredField("work");
        workField.setAccessible(true);
        double[] work = new double[nn];
        workField.set(eigen, work);
        
        work[nn - 2] = 1.0;  // b1
        work[nn - 6] = 1.0;  // b2
        work[nn - 8] = 0.5;  // will be divided by b2
        work[nn - 4] = 0.5;  // will be divided by b1
        work[nn - 13] = 0.1; // initial b2 for inner loop
        work[nn - 15] = 1.0; // denominator
        
        // Set values that would make the boundary iteration matter
        int boundaryIndex = 4 * start + 2 + pingPong;
        work[boundaryIndex] = 0.5;      // numerator
        work[boundaryIndex - 2] = 1.0;  // denominator
        
        // Call private method using reflection
        Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
        computeShiftIncrement.setAccessible(true);
        computeShiftIncrement.invoke(eigen, start, nn/4, 0);
        
        // Verify - the mutant would skip the boundary iteration, resulting in different tau
        // Original code would include the boundary iteration's contribution to a2
        double dMin = (Double) dMinField.get(eigen);
        double expectedTau = 0.25 * dMin; // Should be different if boundary iteration was processed
        
        Field tauField = clazz.getDeclaredField("tau");
        tauField.setAccessible(true);
        double tau = (Double) tauField.get(eigen);
        
        assertNotEquals("Mutant detected: boundary iteration was skipped", 
                       expectedTau, tau, 0.0001);
        
        // Additional verification that we're in the expected case
        int tType = (Integer) tTypeField.get(eigen);
        assertEquals("Test should be in case 5", -5, tType);
    }


}
