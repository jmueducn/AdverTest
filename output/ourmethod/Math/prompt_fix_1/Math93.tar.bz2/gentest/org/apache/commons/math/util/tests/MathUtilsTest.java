package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
               public void testFactorial_NegativeInput() {
                   thrown.expect(IllegalArgumentException.class);
                   thrown.expectMessage("must have n >= 0 for n!");
                   MathUtils.factorial(-1);
               }

 @Test
               public void testFactorial_InputGreaterThan() {
                   thrown.expect(ArithmeticException.class);
                   thrown.expectMessage("factorial value is too large to fit in a long");
                   MathUtils.factorial(21);
               }

 @Test
               public void testFactorial_Zero() {
                   assertEquals(1L, MathUtils.factorial(0));
               }

 @Test
               public void testFactorial_One() {
                   assertEquals(1L, MathUtils.factorial(1));
               }

 @Test
               public void testFactorial_Twenty() {
                   // 20! = 2432902008176640000
                   assertEquals(2432902008176640000L, MathUtils.factorial(20));
               }

 @Test
               public void testFactorial_TypicalValues() {
                   assertEquals(2L, MathUtils.factorial(2));       // 2! = 2
                   assertEquals(6L, MathUtils.factorial(3));       // 3! = 6
                   assertEquals(24L, MathUtils.factorial(4));      // 4! = 24
                   assertEquals(120L, MathUtils.factorial(5));     // 5! = 120
                   assertEquals(720L, MathUtils.factorial(6));     // 6! = 720
                   assertEquals(5040L, MathUtils.factorial(7));    // 7! = 5040
                   assertEquals(40320L, MathUtils.factorial(8));   // 8! = 40320
                   assertEquals(362880L, MathUtils.factorial(9));  // 9! = 362880
                   assertEquals(3628800L, MathUtils.factorial(10)); // 10! = 3628800
               }

 @Test
               public void testFactorial_AllValidValues() {
                   long[] expected = {
                       1L,                   // 0!
                       1L,                   // 1!
                       2L,                   // 2!
                       6L,                   // 3!
                       24L,                  // 4!
                       120L,                 // 5!
                       720L,                 // 6!
                       5040L,                // 7!
                       40320L,               // 8!
                       362880L,              // 9!
                       3628800L,             // 10!
                       39916800L,           // 11!
                       479001600L,           // 12!
                       6227020800L,         // 13!
                       87178291200L,        // 14!
                       1307674368000L,      // 15!
                       20922789888000L,     // 16!
                       355687428096000L,    // 17!
                       6402373705728000L,   // 18!
                       121645100408832000L, // 19!
                       2432902008176640000L // 20!
                   };
           
                   for (int i = 0; i <= 20; i++) {
                       assertEquals(expected[i], MathUtils.factorial(i));
                   }
               }

 @Test
               public void testFactorialDouble_ZeroInput() {
                   assertEquals(1.0, MathUtils.factorialDouble(0), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialDouble_SmallPositiveInputs() {
                   assertEquals(1.0, MathUtils.factorialDouble(1), MathUtils.EPSILON);
                   assertEquals(2.0, MathUtils.factorialDouble(2), MathUtils.EPSILON);
                   assertEquals(6.0, MathUtils.factorialDouble(3), MathUtils.EPSILON);
                   assertEquals(24.0, MathUtils.factorialDouble(4), MathUtils.EPSILON);
                   assertEquals(120.0, MathUtils.factorialDouble(5), MathUtils.EPSILON);
                   assertEquals(720.0, MathUtils.factorialDouble(6), MathUtils.EPSILON);
                   assertEquals(5040.0, MathUtils.factorialDouble(7), MathUtils.EPSILON);
                   assertEquals(40320.0, MathUtils.factorialDouble(8), MathUtils.EPSILON);
                   assertEquals(362880.0, MathUtils.factorialDouble(9), MathUtils.EPSILON);
                   assertEquals(3628800.0, MathUtils.factorialDouble(10), MathUtils.EPSILON);
                   assertEquals(2432902008176640000.0, MathUtils.factorialDouble(20), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialDouble_BoundaryCase() {
                   assertEquals(2432902008176640000.0, MathUtils.factorialDouble(20), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialDouble_BoundaryCase1() {
                   // 21! = 51090942171709440000
                   double expected = 5.109094217170944E19;
                   assertEquals(expected, MathUtils.factorialDouble(21), expected * MathUtils.EPSILON);
               }

 @Test
               public void testFactorialDouble_LargeInputs() {
                   // 25! = 1.5511210043330986E25
                   double expected25 = 1.5511210043330986E25;
                   assertEquals(expected25, MathUtils.factorialDouble(25), expected25 * MathUtils.EPSILON);
           
                   // 30! = 2.6525285981219103E32
                   double expected30 = 2.6525285981219103E32;
                   assertEquals(expected30, MathUtils.factorialDouble(30), expected30 * MathUtils.EPSILON);
           
                   // 50! = 3.0414093201713376E64
                   double expected50 = 3.0414093201713376E64;
                   assertEquals(expected50, MathUtils.factorialDouble(50), expected50 * MathUtils.EPSILON);
               }

 @Test
               public void testFactorialDouble_VeryLargeInput() {
                   // 100! = 9.33262154439441E157
                   double expected100 = 9.33262154439441E157;
                   assertEquals(expected100, MathUtils.factorialDouble(100), expected100 * MathUtils.EPSILON);
               }

 @Test
               public void testFactorialLog_NegativeInput() {
                   thrown.expect(IllegalArgumentException.class);
                   thrown.expectMessage("must have n > 0 for n!");
                   MathUtils.factorialLog(-5);
               }

 @Test
               public void testFactorialLog_ZeroInput() {
                   double result = MathUtils.factorialLog(0);
                   assertEquals(0.0, result, MathUtils.EPSILON);
               }

 @Test
               public void testFactorialLog_SmallValues() {
                   // Test values below 21 (uses factorial lookup)
                   assertEquals(Math.log(1), MathUtils.factorialLog(1), MathUtils.EPSILON);
                   assertEquals(Math.log(2), MathUtils.factorialLog(2), MathUtils.EPSILON);
                   assertEquals(Math.log(6), MathUtils.factorialLog(3), MathUtils.EPSILON);
                   assertEquals(Math.log(24), MathUtils.factorialLog(4), MathUtils.EPSILON);
                   assertEquals(Math.log(120), MathUtils.factorialLog(5), MathUtils.EPSILON);
                   assertEquals(Math.log(2432902008176640000L), MathUtils.factorialLog(20), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialLog_BoundaryValue() {
                   // Test the boundary case where n = 21 (switches to iterative calculation)
                   double expected = 0;
                   for (int i = 2; i <= 21; i++) {
                       expected += Math.log(i);
                   }
                   assertEquals(expected, MathUtils.factorialLog(21), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialLog_LargeValues() {
                   // Test values above 21 (uses iterative calculation)
                   double expected30 = 0;
                   for (int i = 2; i <= 30; i++) {
                       expected30 += Math.log(i);
                   }
                   assertEquals(expected30, MathUtils.factorialLog(30), MathUtils.EPSILON);
                   
                   double expected100 = 0;
                   for (int i = 2; i <= 100; i++) {
                       expected100 += Math.log(i);
                   }
                   assertEquals(expected100, MathUtils.factorialLog(100), MathUtils.EPSILON);
               }

 @Test
               public void testFactorialLog_ConsistencyBetweenMethods() {
                   // Verify that factorialLog(n) equals log(factorial(n)) for n < 21
                   for (int i = 0; i < 21; i++) {
                       double logFact = MathUtils.factorialLog(i);
                       double factLog = Math.log(MathUtils.factorial(i));
                       assertEquals(factLog, logFact, MathUtils.EPSILON);
                   }
               }

 @Test
               public void testFactorialLog_Precision() {
                   // Test precision for various values
                   assertEquals(15.104412573075518, MathUtils.factorialLog(10), MathUtils.EPSILON);
                   assertEquals(42.335616460753485, MathUtils.factorialLog(20), MathUtils.EPSILON);
                   assertEquals(363.73937555556347, MathUtils.factorialLog(100), MathUtils.EPSILON);
               }

 @Test
       public void testFactorialDouble_NegativeInput() {
           ExpectedException exceptionRule = ExpectedException.none();
           exceptionRule.expect(IllegalArgumentException.class);
           exceptionRule.expectMessage("must have n >= 0 for n!");
           MathUtils.factorialDouble(-1);
       }

 @Test
       public void testFactorialLogForLargeN() {
           // Test with n = 21 (boundary where loop is used)
           double expected = Math.log(MathUtils.factorial(20)) + Math.log(21); // log(21!)
           double actual = MathUtils.factorialLog(21);
           
           // Verify the result is correct (should equal log(21!))
           assertEquals(expected, actual, MathUtils.EPSILON);
           
           // Test with n = 5 (should use direct factorial calculation)
           double smallExpected = Math.log(MathUtils.factorial(5));
           double smallActual = MathUtils.factorialLog(5);
           assertEquals(smallExpected, smallActual, MathUtils.EPSILON);
           
           // Test with n = 25 to ensure loop works correctly
           // Calculate expected value by summing logs from 2 to 25
           double logSum = 0.0;
           for (int i = 2; i <= 25; i++) {
               logSum += Math.log(i);
           }
           double largeActual = MathUtils.factorialLog(25);
           assertEquals(logSum, largeActual, MathUtils.EPSILON);
           
           // Test with n = 1 (edge case)
           assertEquals(0.0, MathUtils.factorialLog(1), MathUtils.EPSILON);
       }

 @Test(expected = IllegalArgumentException.class)
       public void testFactorialLogNegativeInput() {
           MathUtils.factorialLog(-1);
       }

 @Test
      public void testFactorialLogPrecisionForLargeN() {
          // Choose a value where the loop will execute (n >= 21)
          int n = 25;
          
          // Calculate expected value using double precision
          double expectedLogSum = 0.0;
          for (int i = 2; i <= n; i++) {
              expectedLogSum += Math.log((double)i);
          }
          
          // Get actual value from the method
          double actualLogSum = MathUtils.factorialLog(n);
          
          // Verify the result matches with high precision
          assertEquals("Log factorial should be calculated with double precision", 
                      expectedLogSum, actualLogSum, 1e-15);
          
          // Additional check: verify it's different from float precision calculation
          double floatPrecisionSum = 0.0;
          for (int i = 2; i <= n; i++) {
              floatPrecisionSum += Math.log((float)i);
          }
          assertNotEquals("Method should not use float precision", 
                         floatPrecisionSum, actualLogSum, 0.0);
      }

 @Test
     public void testFactorialLogLargeValuePrecision() {
         // Test with value large enough to use the loop (n >= 21)
         // and where integer to double conversion precision matters
         int n = 1000;
         
         // Calculate expected value with explicit casting (original behavior)
         double expected = 0.0;
         for (int i = 2; i <= n; i++) {
             expected += Math.log((double)i);
         }
         
         // Get actual value from method
         double actual = MathUtils.factorialLog(n);
         
         // Verify the result matches with high precision
         assertEquals("Log factorial should match with high precision", 
                      expected, actual, MathUtils.EPSILON);
         
         // Additional check - verify the mutant would fail this test
         // Mutant version would do Math.log(i) instead of Math.log((double)i)
         double mutantValue = 0.0;
         for (int i = 2; i <= n; i++) {
             mutantValue += Math.log(i); // This is what the mutant does
         }
         assertNotEquals("Test should detect the precision difference from the mutant",
                        mutantValue, actual, MathUtils.EPSILON);
     }

}
