package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import org.apache.commons.math.util.MathUtils;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
          public void testEquals_Reflexive() {
              Complex c = new Complex(1.0, 2.0);
              assertTrue(c.equals(c));
          }

 @Test
          public void testEquals_Symmetric() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.0, 2.0);
              assertTrue(c1.equals(c2));
              assertTrue(c2.equals(c1));
          }

 @Test
          public void testEquals_Transitive() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.0, 2.0);
              Complex c3 = new Complex(1.0, 2.0);
              assertTrue(c1.equals(c2));
              assertTrue(c2.equals(c3));
              assertTrue(c1.equals(c3));
          }

 @Test
          public void testEquals_NullComparison() {
              Complex c = new Complex(1.0, 2.0);
              assertFalse(c.equals(null));
          }

 @Test
          public void testEquals_DifferentClass() {
              Complex c = new Complex(1.0, 2.0);
              Object o = new Object();
              assertFalse(c.equals(o));
          }

 @Test
          public void testEquals_NaNComparison() {
              Complex nan1 = Complex.NaN;
              Complex nan2 = new Complex(Double.NaN, Double.NaN);
              Complex regular = new Complex(1.0, 2.0);
              
              assertTrue(nan1.equals(nan1));
              assertTrue(nan1.equals(nan2));
              assertTrue(nan2.equals(nan1));
              assertFalse(nan1.equals(regular));
              assertFalse(regular.equals(nan1));
          }

 @Test
          public void testEquals_RealPartDifferent() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.1, 2.0);
              assertFalse(c1.equals(c2));
          }

 @Test
          public void testEquals_ImaginaryPartDifferent() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.0, 2.1);
              assertFalse(c1.equals(c2));
          }

 @Test
          public void testEquals_BothPartsDifferent() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.1, 2.1);
              assertFalse(c1.equals(c2));
          }

 @Test
          public void testEquals_BothPartsSame() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.0, 2.0);
              assertTrue(c1.equals(c2));
          }

 @Test
          public void testEquals_InfinityComparison() {
              Complex inf1 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
              Complex inf2 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
              Complex regular = new Complex(1.0, 2.0);
              
              assertTrue(inf1.equals(inf2));
              assertFalse(inf1.equals(regular));
          }

 @Test
          public void testEquals_SpecialConstants() {
              Complex zero1 = Complex.ZERO;
              Complex zero2 = new Complex(0.0, 0.0);
              Complex one1 = Complex.ONE;
              Complex one2 = new Complex(1.0, 0.0);
              Complex i1 = Complex.I;
              Complex i2 = new Complex(0.0, 1.0);
              
              assertTrue(zero1.equals(zero2));
              assertTrue(one1.equals(one2));
              assertTrue(i1.equals(i2));
              assertFalse(zero1.equals(one1));
              assertFalse(one1.equals(i1));
          }

 @Test
      public void testEqualsWithExceptionThrowingObject() {
          // Create a test object that throws RuntimeException when cast to Complex
          Object exceptionThrowingObject = new Object() {
              @Override
              public boolean equals(Object obj) {
                  throw new RuntimeException("Intentional test exception");
              }
          };
          
          Complex complex = new Complex(1.0, 2.0);
          
          // With original code (catch ClassCastException):
          // This would return false because it only catches ClassCastException
          // and our test object throws RuntimeException
          
          // With mutated code (catch Exception):
          // This would also return false, but for the wrong reason - it catches
          // the RuntimeException when it shouldn't
          
          // To detect the mutant, we need to verify the behavior is consistent
          // with only catching ClassCastException
          boolean result = complex.equals(exceptionThrowingObject);
          
          // The correct behavior should be to propagate the RuntimeException
          // So we expect the test to fail with RuntimeException
          // But since we can't assert that directly in JUnit 4 without ExpectedException,
          // we'll structure the test differently
          
          try {
              complex.equals(exceptionThrowingObject);
              // If we get here, the exception was caught (mutant behavior)
              fail("Expected RuntimeException to be thrown");
          } catch (RuntimeException e) {
              // This is the expected behavior for original code
              assertTrue(true); // pass the test
          } catch (Exception e) {
              fail("Expected RuntimeException but got " + e.getClass());
          }
      }

 @Test
      public void testEqualsWithClassCastException() {
          // Regular test with non-Complex object to ensure basic functionality
          Complex complex = new Complex(1.0, 2.0);
          Object nonComplexObject = new Object();
          
          assertFalse(complex.equals(nonComplexObject));
      }

 @Test
 public void testEqualsWithRuntimeException() {
     // Create a real Complex object for testing
     Complex complex = new Complex(1.0, 2.0);
     
     // Create a mock object that throws RuntimeException when cast
     Object throwingObject = mock(Object.class);
     when(throwingObject.getClass()).thenThrow(new RuntimeException("Mock exception"));
     
     // Test that equals returns false for RuntimeExceptions (original behavior would pass)
     // The mutant catches RuntimeException and returns false, same as original
     // Wait - this actually wouldn't detect the mutant since behavior is same
     
     // Need a different approach - we need to test with an object that would throw
     // a different RuntimeException during the cast attempt
     
     // Alternative approach: create an object that throws RuntimeException during toString()
     // since the equals method might call toString() during comparison
     Object runtimeExceptionThrower = new Object() {
         @Override
         public String toString() {
             throw new RuntimeException("Intentional test exception");
         }
     };
     
     // Original behavior would propagate the RuntimeException
     // Mutated behavior would catch it and return false
     // So we need to verify the exception is thrown (for original) or not (for mutant)
     try {
         complex.equals(runtimeExceptionThrower);
         // If we get here, the mutant caught the exception (bad)
         fail("Expected RuntimeException to be thrown");
     } catch (RuntimeException e) {
         // This is expected for original code
         assertEquals("Intentional test exception", e.getMessage());
     }
     
     // Additional test case for ClassCastException specifically
     Object nonComplexObject = new Object();
     assertFalse(complex.equals(nonComplexObject));
 }

 @Test(expected = RuntimeException.class)
 public void testEqualsWithNonClassCastRuntimeException() {
     Complex complex = new Complex(1.0, 1.0);
     
     // Create an object that throws RuntimeException when cast to Complex
     Object throwingObject = new Object() {
         @Override
         public boolean equals(Object obj) {
             throw new RuntimeException("Test exception");
         }
     };
     
     // Original code should propagate the exception
     // Mutant would catch it and return false
     complex.equals(throwingObject);
     
     // The @Test(expected) verifies the exception is thrown (original behavior)
     // The mutant would fail this test by not throwing the exception
 }

}
