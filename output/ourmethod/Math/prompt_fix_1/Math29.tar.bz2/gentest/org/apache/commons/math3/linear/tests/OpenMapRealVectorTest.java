package gentest.org.apache.commons.math3.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.linear.*;
import java.io.Serializable;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math3.util.FastMath;
 
public class OpenMapRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                    public void testEbeDivide_TypicalValues() {
                        // Setup
                        double[] values1 = {4.0, 9.0, 16.0};
                        double[] values2 = {2.0, 3.0, 4.0};
                        OpenMapRealVector vector1 = new OpenMapRealVector(values1);
                        OpenMapRealVector vector2 = new OpenMapRealVector(values2);
                        
                        // Execute
                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                        
                        // Verify
                        assertEquals(2.0, result.getEntry(0), 0.0001);
                        assertEquals(3.0, result.getEntry(1), 0.0001);
                        assertEquals(4.0, result.getEntry(2), 0.0001);
                    }

 @Test
                    public void testEbeDivide_WithZeroValues() {
                        // Setup
                        double[] values1 = {0.0, 5.0, 0.0};
                        double[] values2 = {2.0, 5.0, 4.0};
                        OpenMapRealVector vector1 = new OpenMapRealVector(values1);
                        OpenMapRealVector vector2 = new OpenMapRealVector(values2);
                        
                        // Execute
                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                        
                        // Verify
                        assertEquals(0.0, result.getEntry(0), 0.0001);
                        assertEquals(1.0, result.getEntry(1), 0.0001);
                        assertEquals(0.0, result.getEntry(2), 0.0001);
                    }

 @Test
                    public void testEbeDivide_DivideByZeroResultsInInfinity() {
                        // Setup
                        double[] values1 = {1.0, -1.0, 0.0};
                        double[] values2 = {1.0, 0.0, 0.0};
                        OpenMapRealVector vector1 = new OpenMapRealVector(values1);
                        OpenMapRealVector vector2 = new OpenMapRealVector(values2);
                        
                        // Execute
                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                        
                        // Verify
                        assertEquals(1.0, result.getEntry(0), 0.0001);
                        assertTrue(Double.isInfinite(result.getEntry(1)));
                        assertTrue(Double.isNaN(result.getEntry(2)));
                    }

 @Test
                    public void testEbeDivide_WithSparseVectors() {
                        // Setup - create sparse vectors (most values are 0)
                        OpenMapRealVector vector1 = new OpenMapRealVector(5);
                        OpenMapRealVector vector2 = new OpenMapRealVector(5);
                        vector1.setEntry(1, 10.0);
                        vector1.setEntry(3, 20.0);
                        vector2.setEntry(1, 2.0);
                        vector2.setEntry(3, 5.0);
                        
                        // Execute
                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                        
                        // Verify
                        assertEquals(0.0, result.getEntry(0), 0.0001);
                        assertEquals(5.0, result.getEntry(1), 0.0001);
                        assertEquals(0.0, result.getEntry(2), 0.0001);
                        assertEquals(4.0, result.getEntry(3), 0.0001);
                        assertEquals(0.0, result.getEntry(4), 0.0001);
                    }

 @Test
                    public void testEbeDivide_WithRealVectorParameter() {
                        // Setup
                        double[] values1 = {6.0, 12.0, 18.0};
                        double[] values2 = {2.0, 3.0, 6.0};
                        OpenMapRealVector vector1 = new OpenMapRealVector(values1);
                        RealVector vector2 = mock(RealVector.class);
                        
                        // Mock behavior
                        when(vector2.getDimension()).thenReturn(3);
                        when(vector2.getEntry(0)).thenReturn(2.0);
                        when(vector2.getEntry(1)).thenReturn(3.0);
                        when(vector2.getEntry(2)).thenReturn(6.0);
                        
                        // Execute
                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                        
                        // Verify
                        assertEquals(3.0, result.getEntry(0), 0.0001);
                        assertEquals(4.0, result.getEntry(1), 0.0001);
                        assertEquals(3.0, result.getEntry(2), 0.0001);
                        
                        // Verify interactions
                        verify(vector2).getDimension();
                        verify(vector2, times(3)).getEntry(anyInt());
                    }

 @Test
                    public void testEbeDivide_WithNegativeValues() {
                        // Setup
                        double[] values1 = {-4.0, 9.0, -16.0};
                        double[] values2 = {2.0, -3.0, 4.0};
                        OpenMapRealVector vector1 = new OpenMapRealVector(values1);
                        OpenMapRealVector vector2 = new OpenMapRealVector(values2);
                        
                        // Execute
                        OpenMapRealVector result = vector1.ebeDivide(vector2);
                        
                        // Verify
                        assertEquals(-2.0, result.getEntry(0), 0.0001);
                        assertEquals(-3.0, result.getEntry(1), 0.0001);
                        assertEquals(-4.0, result.getEntry(2), 0.0001);
                    }

 @Test
                    public void testEbeMultiply_TypicalValues() {
                        // Setup
                        double[] data1 = {1.0, 2.0, 3.0};
                        double[] data2 = {4.0, 5.0, 6.0};
                        OpenMapRealVector v1 = new OpenMapRealVector(data1);
                        OpenMapRealVector v2 = new OpenMapRealVector(data2);
                        
                        // Execute
                        OpenMapRealVector result = v1.ebeMultiply(v2);
                        
                        // Verify
                        assertEquals(4.0, result.getEntry(0), 0.0001);
                        assertEquals(10.0, result.getEntry(1), 0.0001);
                        assertEquals(18.0, result.getEntry(2), 0.0001);
                    }

 @Test
                    public void testEbeMultiply_WithZeroValues() {
                        // Setup
                        double[] data1 = {1.0, 0.0, 3.0};
                        double[] data2 = {4.0, 5.0, 0.0};
                        OpenMapRealVector v1 = new OpenMapRealVector(data1);
                        OpenMapRealVector v2 = new OpenMapRealVector(data2);
                        
                        // Execute
                        OpenMapRealVector result = v1.ebeMultiply(v2);
                        
                        // Verify
                        assertEquals(4.0, result.getEntry(0), 0.0001);
                        assertEquals(0.0, result.getEntry(1), 0.0001);
                        assertEquals(0.0, result.getEntry(2), 0.0001);
                    }

 @Test
                    public void testEbeMultiply_WithNaNValues() {
                        // Setup
                        double[] data1 = {1.0, 0.0, 3.0};
                        double[] data2 = {4.0, Double.NaN, 6.0};
                        OpenMapRealVector v1 = new OpenMapRealVector(data1);
                        OpenMapRealVector v2 = new OpenMapRealVector(data2);
                        
                        // Execute
                        OpenMapRealVector result = v1.ebeMultiply(v2);
                        
                        // Verify
                        assertEquals(4.0, result.getEntry(0), 0.0001);
                        assertTrue(Double.isNaN(result.getEntry(1)));
                        assertEquals(18.0, result.getEntry(2), 0.0001);
                    }

 @Test
                    public void testEbeMultiply_DimensionMismatchThrowsException() {
                        // Setup
                        double[] data1 = {1.0, 2.0};
                        double[] data2 = {1.0, 2.0, 3.0};
                        OpenMapRealVector v1 = new OpenMapRealVector(data1);
                        OpenMapRealVector v2 = new OpenMapRealVector(data2);
                        
                        // Expect exception
                        thrown.expect(IllegalArgumentException.class);
                        
                        // Execute
                        v1.ebeMultiply(v2);
                    }

 @Test
                    public void testEbeMultiply_WithSparseVectors() {
                        // Setup - using constructor that allows setting expected size
                        OpenMapRealVector v1 = new OpenMapRealVector(5, 2); // dimension 5, expected 2 non-zero
                        OpenMapRealVector v2 = new OpenMapRealVector(5, 2);
                        v1.setEntry(1, 3.0);
                        v1.setEntry(3, 4.0);
                        v2.setEntry(1, 5.0);
                        v2.setEntry(4, 6.0);
                        
                        // Execute
                        OpenMapRealVector result = v1.ebeMultiply(v2);
                        
                        // Verify
                        assertEquals(0.0, result.getEntry(0), 0.0001);
                        assertEquals(15.0, result.getEntry(1), 0.0001);
                        assertEquals(0.0, result.getEntry(2), 0.0001);
                        assertEquals(0.0, result.getEntry(3), 0.0001);
                        assertEquals(0.0, result.getEntry(4), 0.0001);
                    }

 @Test
                    public void testEbeMultiply_WithRealVectorParameter() {
                        // Setup
                        double[] data1 = {1.0, 2.0, 3.0};
                        double[] data2 = {4.0, 5.0, 6.0};
                        OpenMapRealVector v1 = new OpenMapRealVector(data1);
                        RealVector v2 = mock(RealVector.class);
                        
                        // Mock behavior
                        when(v2.getDimension()).thenReturn(3);
                        when(v2.getEntry(0)).thenReturn(4.0);
                        when(v2.getEntry(1)).thenReturn(5.0);
                        when(v2.getEntry(2)).thenReturn(6.0);
                        when(v2.isNaN()).thenReturn(false);
                        when(v2.isInfinite()).thenReturn(false);
                        
                        // Execute
                        OpenMapRealVector result = v1.ebeMultiply(v2);
                        
                        // Verify
                        assertEquals(4.0, result.getEntry(0), 0.0001);
                        assertEquals(10.0, result.getEntry(1), 0.0001);
                        assertEquals(18.0, result.getEntry(2), 0.0001);
                        
                        // Verify interactions
                        verify(v2).getDimension();
                        verify(v2, times(3)).getEntry(anyInt());
                    }

 @Test
                    public void testEbeMultiply_WithMixedSpecialValues() {
                        // Setup
                        double[] data1 = {0.0, Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY};
                        double[] data2 = {Double.NaN, 0.0, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY};
                        OpenMapRealVector v1 = new OpenMapRealVector(data1);
                        OpenMapRealVector v2 = new OpenMapRealVector(data2);
                        
                        // Execute
                        OpenMapRealVector result = v1.ebeMultiply(v2);
                        
                        // Verify
                        assertTrue(Double.isNaN(result.getEntry(0))); // 0 * NaN = NaN
                        assertTrue(Double.isNaN(result.getEntry(1))); // NaN * 0 = NaN
                        assertTrue(Double.isInfinite(result.getEntry(2)) && result.getEntry(2) < 0); // +Inf * -Inf = -Inf
                        assertTrue(Double.isInfinite(result.getEntry(3)) && result.getEntry(3) < 0); // -Inf * +Inf = -Inf
                    }

 @Test
            public void testEbeMultiply_WithInfiniteValues() {
                // Setup
                double[] data1 = {1.0, 0.0, 3.0, -2.0};
                double[] data2 = {4.0, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.0};
                OpenMapRealVector v1 = new OpenMapRealVector(data1);
                OpenMapRealVector v2 = new OpenMapRealVector(data2);
                
                // Execute
                OpenMapRealVector result = v1.ebeMultiply(v2);
                
                // Verify
                assertEquals(4.0, result.getEntry(0), 0.0001);
                assertTrue(Double.isNaN(result.getEntry(1))); // 0 * Infinity = NaN
                assertTrue(Double.isInfinite(result.getEntry(2)) && result.getEntry(2) < 0);
                assertEquals(0.0, result.getEntry(3), 0.0001);
            }

 @Test
        public void testEbeDivide_DifferentDimensionsThrowsException() {
            // Setup
            double[] values1 = {1.0, 2.0, 3.0};
            double[] values2 = {1.0, 2.0};
            OpenMapRealVector vector1 = new OpenMapRealVector(values1);
            OpenMapRealVector vector2 = new OpenMapRealVector(values2);
            
            // Expect exception
            ExpectedException exception = ExpectedException.none();
            exception.expect(IllegalArgumentException.class);
            
            // Execute
            vector1.ebeDivide(vector2);
        }

 @Test
    public void testEbeMultiply_HandlesNaNInLastElement() {
        // Create a vector with NaN in the last position
        double[] values1 = {1.0, 2.0, 3.0};
        double[] values2 = {4.0, 5.0, Double.NaN};
        
        OpenMapRealVector v1 = new OpenMapRealVector(values1);
        OpenMapRealVector v2 = new OpenMapRealVector(values2);
        
        // Perform multiplication
        OpenMapRealVector result = v1.ebeMultiply(v2);
        
        // Verify all elements were processed
        assertEquals(4.0, result.getEntry(0), 0.0001);  // 1.0 * 4.0
        assertEquals(10.0, result.getEntry(1), 0.0001); // 2.0 * 5.0
        assertTrue(Double.isNaN(result.getEntry(2)));    // 3.0 * NaN should be NaN
        
        // Also test with Infinite in last position
        double[] values3 = {1.0, 2.0, 3.0};
        double[] values4 = {4.0, 5.0, Double.POSITIVE_INFINITY};
        
        OpenMapRealVector v3 = new OpenMapRealVector(values3);
        OpenMapRealVector v4 = new OpenMapRealVector(values4);
        
        result = v3.ebeMultiply(v4);
        
        assertEquals(4.0, result.getEntry(0), 0.0001);  // 1.0 * 4.0
        assertEquals(10.0, result.getEntry(1), 0.0001); // 2.0 * 5.0
        assertTrue(Double.isInfinite(result.getEntry(2))); // 3.0 * Infinity should be Infinity
    }

 @Test
   public void testEbeMultiplyWithBothNaNAndInfiniteValues() {
       // Create test vector with both NaN and Infinite values
       double[] testValues = {1.0, Double.NaN, Double.POSITIVE_INFINITY};
       OpenMapRealVector testVector = new OpenMapRealVector(testValues);
       
       // Create input vector with some values
       double[] inputValues = {2.0, 3.0, 4.0};
       OpenMapRealVector inputVector = new OpenMapRealVector(inputValues);
       
       // Perform multiplication
       OpenMapRealVector result = testVector.ebeMultiply(inputVector);
       
       // Verify NaN takes precedence (position 1)
       assertTrue(Double.isNaN(result.getEntry(1)));
       
       // Verify Infinite is handled correctly (position 2)
       assertEquals(Double.POSITIVE_INFINITY, result.getEntry(2), 0.0);
       
       // Verify normal multiplication (position 0)
       assertEquals(2.0, result.getEntry(0), 0.0);
   }

 @Test
  public void testEbeMultiplyWithNaNValues() {
      // Create main vector with some zero and non-zero values
      double[] mainValues = {1.0, 0.0, 2.0};
      OpenMapRealVector mainVector = new OpenMapRealVector(mainValues);
      
      // Create test vector with NaN values at different positions
      double[] testValues = {Double.NaN, Double.NaN, 3.0};
      OpenMapRealVector testVector = new OpenMapRealVector(testValues);
      
      // Perform multiplication
      OpenMapRealVector result = mainVector.ebeMultiply(testVector);
      
      // Verify results
      assertEquals(Double.NaN, result.getEntry(0), 0.0);  // 1.0 * NaN = NaN
      assertEquals(Double.NaN, result.getEntry(1), 0.0);  // 0.0 * NaN = NaN (special case)
      assertEquals(6.0, result.getEntry(2), 0.0);         // 2.0 * 3.0 = 6.0
      
      // Additional check to ensure NaN is properly propagated
      assertTrue(Double.isNaN(result.getEntry(0)));
      assertTrue(Double.isNaN(result.getEntry(1)));
  }

 @Test
     public void testEbeMultiplyWithNegativeInfinity() {
         // Create a vector with some entries
         OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 0.0});
         
         // Create a mock vector that returns negative infinity at index 1
         RealVector mockVector = mock(RealVector.class);
         when(mockVector.getDimension()).thenReturn(3);
         when(mockVector.getEntry(0)).thenReturn(1.0);
         when(mockVector.getEntry(1)).thenReturn(Double.NEGATIVE_INFINITY);
         when(mockVector.getEntry(2)).thenReturn(1.0);
         when(mockVector.isNaN()).thenReturn(false);
         when(mockVector.isInfinite()).thenReturn(true);
         
         // Perform the multiplication
         OpenMapRealVector result = vector1.ebeMultiply(mockVector);
         
         // Verify the result
         assertEquals(1.0, result.getEntry(0), 0.0001);  // 1.0 * 1.0 = 1.0
         assertEquals(Double.NEGATIVE_INFINITY, result.getEntry(1), 0.0001);  // 2.0 * -Inf = -Inf
         assertEquals(0.0, result.getEntry(2), 0.0001);  // 0.0 * 1.0 = 0.0
         
         // Verify mock interactions
         verify(mockVector, atLeastOnce()).getDimension();
         verify(mockVector, atLeastOnce()).isInfinite();
         verify(mockVector, times(3)).getEntry(anyInt());
     }

}
