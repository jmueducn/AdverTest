package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.apache.commons.math3.util.MathArrays;
import org.apache.commons.math3.util.Pair;
 
public class DiscreteDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                   public void testSample_ZeroSampleSize_ThrowsException() {
                                                                                       // Setup
                                                                                       List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                       samples.add(new Pair<>("A", 1.0));
                                                                                       DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
                                                                               
                                                                                       // Expect exception
                                                                                       thrown.expect(NotStrictlyPositiveException.class);
                                                                                       thrown.expectMessage(LocalizedFormats.NUMBER_OF_SAMPLES.toString());
                                                                               
                                                                                       // Test
                                                                                       distribution.sample(0);
                                                                                   }

 @Test
                                                                                   public void testSample_NegativeSampleSize_ThrowsException() {
                                                                                       // Setup
                                                                                       List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                       samples.add(new Pair<>("A", 1.0));
                                                                                       DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
                                                                               
                                                                                       // Expect exception
                                                                                       thrown.expect(NotStrictlyPositiveException.class);
                                                                                       thrown.expectMessage(LocalizedFormats.NUMBER_OF_SAMPLES.toString());
                                                                               
                                                                                       // Test
                                                                                       distribution.sample(-5);
                                                                                   }

 @Test
                                                                                   public void testSample_SingleSample() {
                                                                                       // Setup mock sample() method behavior
                                                                                       RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                       List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                       samples.add(new Pair<>("A", 0.3));
                                                                                       samples.add(new Pair<>("B", 0.7));
                                                                                       
                                                                                       DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                                       
                                                                                       // Mock the random generator to return specific values that will select "B"
                                                                                       when(mockRandom.nextDouble()).thenReturn(0.5);
                                                                               
                                                                                       // Test
                                                                                       Object[] result = distribution.sample(1);
                                                                                       
                                                                                       // Verify
                                                                                       assertEquals(1, result.length);
                                                                                       assertEquals("B", result[0]);
                                                                                       verify(mockRandom).nextDouble();
                                                                                   }

 @Test
                                                                                   public void testSample_MultipleSamples() {
                                                                                       // Setup mock sample() method behavior
                                                                                       RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                       List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                       samples.add(new Pair<>("A", 0.3));
                                                                                       samples.add(new Pair<>("B", 0.7));
                                                                                       
                                                                                       DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                                       
                                                                                       // Mock the random generator to return specific values that will select "A" then "B"
                                                                                       when(mockRandom.nextDouble())
                                                                                           .thenReturn(0.2)  // selects A
                                                                                           .thenReturn(0.5); // selects B
                                                                               
                                                                                       // Test
                                                                                       Object[] result = distribution.sample(2);
                                                                                       
                                                                                       // Verify
                                                                                       assertEquals(2, result.length);
                                                                                       assertEquals("A", result[0]);
                                                                                       assertEquals("B", result[1]);
                                                                                       verify(mockRandom, times(2)).nextDouble();
                                                                                   }

 @Test
                                                                                   public void testSample_LargeSampleSize() {
                                                                                       // Setup
                                                                                       RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                       List<Pair<Integer, Double>> samples = new ArrayList<>();
                                                                                       samples.add(new Pair<>(1, 0.5));
                                                                                       samples.add(new Pair<>(2, 0.5));
                                                                                       
                                                                                       DiscreteDistribution<Integer> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                                       
                                                                                       // Mock random to alternate between values
                                                                                       when(mockRandom.nextDouble())
                                                                                           .thenReturn(0.1)  // selects 1
                                                                                           .thenReturn(0.6)  // selects 2
                                                                                           .thenReturn(0.3)  // selects 1
                                                                                           .thenReturn(0.8); // selects 2
                                                                               
                                                                                       // Test
                                                                                       int sampleSize = 1000;
                                                                                       Object[] result = distribution.sample(sampleSize);
                                                                                       
                                                                                       // Verify
                                                                                       assertEquals(sampleSize, result.length);
                                                                                       // Check first few values to verify pattern
                                                                                       assertEquals(1, result[0]);
                                                                                       assertEquals(2, result[1]);
                                                                                       assertEquals(1, result[2]);
                                                                                       assertEquals(2, result[3]);
                                                                                       verify(mockRandom, times(sampleSize)).nextDouble();
                                                                                   }

 @Test
                                                                                   public void testSample_WithSingleOption() {
                                                                                       // Setup
                                                                                       List<Pair<String, Double>> samples = new ArrayList<>();
                                                                                       samples.add(new Pair<>("OnlyOption", 1.0));
                                                                                       DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
                                                                               
                                                                                       // Test
                                                                                       Object[] result = distribution.sample(5);
                                                                                       
                                                                                       // Verify
                                                                                       assertEquals(5, result.length);
                                                                                       for (Object item : result) {
                                                                                           assertEquals("OnlyOption", item);
                                                                                       }
                                                                                   }

 @Test
                                                                           public void testSample_FirstBucket() {
                                                                               // Setup
                                                                               RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                               List<Pair<String, Double>> samples = new ArrayList<>();
                                                                               samples.add(new Pair<>("A", 0.2));
                                                                               samples.add(new Pair<>("B", 0.8));
                                                                               DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                               
                                                                               // Setup - random value falls in first probability bucket (0.0-0.2)
                                                                               when(mockRandom.nextDouble()).thenReturn(0.1);
                                                                               
                                                                               // Execute
                                                                               String result = distribution.sample();
                                                                               
                                                                               // Verify
                                                                               assertEquals("A", result);
                                                                           }

 @Test
                                                                           public void testSample_SecondBucket() {
                                                                               // Setup
                                                                               RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                               List<Pair<String, Double>> samples = new ArrayList<>();
                                                                               samples.add(new Pair<>("A", 0.2));
                                                                               samples.add(new Pair<>("B", 0.3));
                                                                               samples.add(new Pair<>("C", 0.5));
                                                                               DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                               
                                                                               // Setup - random value falls in second probability bucket (0.2-0.5)
                                                                               when(mockRandom.nextDouble()).thenReturn(0.3);
                                                                               
                                                                               // Execute
                                                                               String result = distribution.sample();
                                                                               
                                                                               // Verify
                                                                               assertEquals("B", result);
                                                                           }

 @Test
                                                                           public void testSample_ThirdBucket() {
                                                                               // Setup
                                                                               RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                               List<Pair<String, Double>> samples = new ArrayList<>();
                                                                               samples.add(new Pair<>("A", 0.2));
                                                                               samples.add(new Pair<>("B", 0.3));
                                                                               samples.add(new Pair<>("C", 0.5));
                                                                               
                                                                               // Create distribution with mock random generator
                                                                               DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                               
                                                                               // Setup - random value falls in third probability bucket (0.5-1.0)
                                                                               when(mockRandom.nextDouble()).thenReturn(0.6);
                                                                               
                                                                               // Execute
                                                                               String result = distribution.sample();
                                                                               
                                                                               // Verify
                                                                               assertEquals("C", result);
                                                                           }

 @Test
                                                                           public void testSample_EdgeCaseBetweenBuckets() {
                                                                               // Setup
                                                                               RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                               List<Pair<String, Double>> samples = new ArrayList<>();
                                                                               samples.add(new Pair<>("A", 0.25));
                                                                               samples.add(new Pair<>("B", 0.25));
                                                                               samples.add(new Pair<>("C", 0.5));
                                                                               
                                                                               DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                               
                                                                               // Setup - random value exactly at bucket boundary (0.5)
                                                                               when(mockRandom.nextDouble()).thenReturn(0.5);
                                                                               
                                                                               // Execute
                                                                               String result = distribution.sample();
                                                                               
                                                                               // Verify
                                                                               assertEquals("C", result);
                                                                           }

 @Test
                                                                           public void testSample_EdgeCaseFirstBucketBoundary() {
                                                                               // Setup
                                                                               RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                               List<Pair<String, Double>> samples = new ArrayList<>();
                                                                               samples.add(new Pair<>("A", 0.2));
                                                                               samples.add(new Pair<>("B", 0.8));
                                                                               
                                                                               // random value exactly at first bucket boundary (0.2)
                                                                               when(mockRandom.nextDouble()).thenReturn(0.2);
                                                                               
                                                                               // Create distribution with mock random generator
                                                                               DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                               
                                                                               // Execute
                                                                               String result = distribution.sample();
                                                                               
                                                                               // Verify
                                                                               assertEquals("B", result);
                                                                           }

 @Test
                                                                           public void testSample_EdgeCaseLastBucket() {
                                                                               // Setup
                                                                               RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                               List<Pair<String, Double>> samples = new ArrayList<>();
                                                                               samples.add(new Pair<>("A", 0.3));
                                                                               samples.add(new Pair<>("B", 0.3));
                                                                               samples.add(new Pair<>("C", 0.4));
                                                                               DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                               
                                                                               // Setup - random value very close to 1.0 (tests the fallback case)
                                                                               when(mockRandom.nextDouble()).thenReturn(0.9999999999);
                                                                               
                                                                               // Execute
                                                                               String result = distribution.sample();
                                                                               
                                                                               // Verify
                                                                               assertEquals("C", result);
                                                                           }

 @Test
                                                                           public void testSample_WithFloatingPointPrecisionIssue() {
                                                                               // Setup
                                                                               RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                               List<Pair<String, Double>> samples = new ArrayList<>();
                                                                               samples.add(new Pair<>("A", 0.3));
                                                                               samples.add(new Pair<>("B", 0.3));
                                                                               samples.add(new Pair<>("C", 0.4));
                                                                               DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                                                                               
                                                                               // Setup random value that might cause floating point precision issues
                                                                               when(mockRandom.nextDouble()).thenReturn(0.9999999999999999);
                                                                               
                                                                               // Execute
                                                                               String result = distribution.sample();
                                                                               
                                                                               // Verify - should return last element due to floating point precision handling
                                                                               assertEquals("C", result);
                                                                           }

 @Test
                                   public void testSample_WithSingleElement() {
                                       // Setup - distribution with only one element
                                       org.apache.commons.math3.random.RandomGenerator mockRandom = 
                                           new org.apache.commons.math3.random.Well19937c();
                                       java.util.List<org.apache.commons.math3.util.Pair<String, Double>> singleSample = 
                                           java.util.Arrays.asList(
                                               new org.apache.commons.math3.util.Pair<>("Single", 1.0)
                                           );
                                       org.apache.commons.math3.distribution.DiscreteDistribution<String> singleDist = 
                                           new org.apache.commons.math3.distribution.DiscreteDistribution<>(mockRandom, singleSample);
                                       
                                       // Execute
                                       String result = singleDist.sample();
                                       
                                       // Verify
                                       org.junit.Assert.assertEquals("Single", result);
                                   }

 @Test
                               public void testSample_WithZeroProbabilityElement() {
                                   // Setup - one element has zero probability
                                   java.util.List<org.apache.commons.math3.util.Pair<String, Double>> samplesWithZero = java.util.Arrays.asList(
                                       new org.apache.commons.math3.util.Pair<>("A", 0.0),
                                       new org.apache.commons.math3.util.Pair<>("B", 1.0)
                                   );
                                   
                                   // Create mock RandomGenerator
                                   org.apache.commons.math3.random.RandomGenerator mockRandom = 
                                       new org.apache.commons.math3.random.JDKRandomGenerator();
                                   org.apache.commons.math3.distribution.DiscreteDistribution<String> distWithZero = 
                                       new org.apache.commons.math3.distribution.DiscreteDistribution<String>(mockRandom, samplesWithZero);
                                   
                                   // Should never return A because it has zero probability
                                   
                                   // Execute
                                   String result = distWithZero.sample();
                                   
                                   // Verify
                                   org.junit.Assert.assertEquals("B", result);
                               }

 @Test
                          public void testSampleWithZeroSizeShouldThrowException() {
                              // Setup test data
                              List<Pair<String, Double>> samples = new ArrayList<>();
                              samples.add(new Pair<>("A", 0.5));
                              samples.add(new Pair<>("B", 0.5));
                              
                              // Create instance with mock random generator
                              RandomGenerator mockRandom = mock(RandomGenerator.class);
                              DiscreteDistribution<String> distribution = new DiscreteDistribution<>(mockRandom, samples);
                              
                              // Setup exception rule
                              ExpectedException thrown = ExpectedException.none();
                              
                              // Expect exception
                              thrown.expect(NotStrictlyPositiveException.class);
                              thrown.expectMessage(LocalizedFormats.NUMBER_OF_SAMPLES.toString());
                              
                              // Test with zero sample size
                              distribution.sample(0);
                          }

 @Test
                      public void testSampleWithZeroSizeShouldThrowException1() {
                          // Setup test data
                          List<Pair<String, Double>> samples = new ArrayList<>();
                          samples.add(new Pair<>("A", 0.5));
                          samples.add(new Pair<>("B", 0.5));
                          
                          // Create mock RandomGenerator
                          RandomGenerator mockRandom = mock(RandomGenerator.class);
                          
                          // Create instance with mock random
                          DiscreteDistribution<String> distribution = 
                              new DiscreteDistribution<>(mockRandom, samples);
                          
                          // Setup exception rule
                          ExpectedException thrown = ExpectedException.none();
                          thrown.expect(IllegalArgumentException.class);
                          thrown.expectMessage("sample size must be positive");
                          
                          // This should throw in both original and mutant
                          distribution.sample(0);
                      }

 @Test
          public void testSampleWithNegativeSizeShouldThrowException() {
              // Setup test data
              List<Pair<String, Double>> samples = new ArrayList<>();
              samples.add(new Pair<>("A", 0.5));
              samples.add(new Pair<>("B", 0.5));
              
              // Create mock RandomGenerator
              RandomGenerator mockRandom = mock(RandomGenerator.class);
              
              // Create instance with mock random
              DiscreteDistribution<String> distribution = 
                  new DiscreteDistribution<>(mockRandom, samples);
              
              // Setup exception rule
              ExpectedException expectedException = ExpectedException.none();
              expectedException.expect(IllegalArgumentException.class);
              expectedException.expectMessage("sample size must be positive");
              
              // This should throw in original but pass in mutant
              distribution.sample(-1);
          }

 @Test
      public void testSampleWithNegativeSizeShouldThrowException1() {
          // Setup test data
          List<Pair<String, Double>> samples = new ArrayList<>();
          samples.add(new Pair<>("A", 0.5));
          samples.add(new Pair<>("B", 0.5));
          
          // Create mock RandomGenerator
          RandomGenerator mockRandom = mock(RandomGenerator.class);
          
          // Create instance with mock random
          DiscreteDistribution<String> distribution = 
              new DiscreteDistribution<>(mockRandom, samples);
          
          // Setup exception rule
          ExpectedException expectedException = ExpectedException.none();
          expectedException.expect(IllegalArgumentException.class);
          expectedException.expectMessage("sample size must be positive");
          
          // This should throw in original but pass in mutant
          distribution.sample(-1);
      }

 @Test
  public void testSampleFallbackBehavior() {
      // Setup test data where probabilities might not sum exactly to 1 due to floating point
      List<Pair<String, Double>> samples = new ArrayList<>();
      samples.add(new Pair<>("A", 0.1));
      samples.add(new Pair<>("B", 0.1));
      samples.add(new Pair<>("C", 0.1));
      samples.add(new Pair<>("D", 0.1));
      samples.add(new Pair<>("E", 0.1));
      samples.add(new Pair<>("F", 0.1));
      samples.add(new Pair<>("G", 0.1));
      samples.add(new Pair<>("H", 0.1));
      samples.add(new Pair<>("I", 0.1));
      samples.add(new Pair<>("J", 0.1)); // Sum is 1.0 in theory, but might be slightly less after normalization
      
      // Mock the random generator to return a value just above the sum
      RandomGenerator mockRandom = mock(RandomGenerator.class);
      when(mockRandom.nextDouble()).thenReturn(0.9999999999); // Just below 1.0
      
      // Create discrete distribution with our mock random
      DiscreteDistribution<String> dist = new DiscreteDistribution<>(mockRandom, samples);
      
      // The original code should return the last element ("J") as fallback
      // The mutant would return the first element ("A")
      assertEquals("J", dist.sample());
  }

 @Test
  public void testSampleWithMultipleSingletonsShouldReturnVariedValues() {
      // Setup test data with multiple distinct singletons
      List<Pair<String, Double>> samples = new ArrayList<>();
      samples.add(new Pair<>("first", 1.0));
      samples.add(new Pair<>("middle", 1.0));
      samples.add(new Pair<>("last", 1.0));
      
      // Create distribution with our test data
      DiscreteDistribution<String> distribution = new DiscreteDistribution<>(samples);
      
      // Call the method under test
      int sampleSize = 100;
      Object[] results = distribution.sample(sampleSize);
      
      // Verify we got the expected number of samples
      assertEquals(sampleSize, results.length);
      
      // Verify that we get all three possible values (original behavior)
      // The mutant would only return "first" for all samples
      boolean foundFirst = false;
      boolean foundMiddle = false;
      boolean foundLast = false;
      
      for (Object result : results) {
          if ("first".equals(result)) foundFirst = true;
          if ("middle".equals(result)) foundMiddle = true;
          if ("last".equals(result)) foundLast = true;
      }
      
      assertTrue("Should contain first element", foundFirst);
      assertTrue("Should contain middle element", foundMiddle);
      assertTrue("Should contain last element", foundLast);
      
      // Additional check: verify not all results are the same (which would happen with mutant)
      boolean allSame = true;
      Object first = results[0];
      for (Object result : results) {
          if (!first.equals(result)) {
              allSame = false;
              break;
          }
      }
      assertFalse("All samples should not be identical", allSame);
  }

 @Test
 public void testSampleWithFloatingPointPrecisionIssue() {
     // Setup test data with probabilities that won't sum exactly to 1 due to floating point precision
     List<Pair<String, Double>> samples = new ArrayList<>();
     samples.add(new Pair<>("A", 0.1));
     samples.add(new Pair<>("B", 0.1));
     samples.add(new Pair<>("C", 0.1));
     samples.add(new Pair<>("D", 0.1));
     samples.add(new Pair<>("E", 0.1));
     samples.add(new Pair<>("F", 0.1));
     samples.add(new Pair<>("G", 0.1));
     samples.add(new Pair<>("H", 0.1));
     samples.add(new Pair<>("I", 0.1));
     samples.add(new Pair<>("J", 0.1)); // Sum should be 1.0 but might have floating point imprecision
     
     // Mock RandomGenerator to return a value greater than the sum of probabilities
     RandomGenerator mockRandom = mock(RandomGenerator.class);
     when(mockRandom.nextDouble()).thenReturn(1.0); // Force fallback case
     
     // Create DiscreteDistribution with our mock random
     DiscreteDistribution<String> dist = new DiscreteDistribution<>(mockRandom, samples);
     
     // Test - should return last element ("J") not middle element
     String result = dist.sample();
     assertEquals("J", result); // This will fail if mutant is present (would return "E" or "F")
 }

 @Test
 public void testSampleIntDetectsMutant() {
     // Setup test data with known singletons
     List<Pair<String, Double>> samples = new ArrayList<>();
     samples.add(new Pair<>("first", 0.2));
     samples.add(new Pair<>("middle", 0.3));
     samples.add(new Pair<>("last", 0.5));
     
     // Create DiscreteDistribution with our test data
     DiscreteDistribution<String> dist = new DiscreteDistribution<>(samples);
     
     // Call the method under test
     int sampleSize = 5;
     Object[] result = dist.sample(sampleSize);
     
     // Verify all samples are the last element (original behavior)
     // This will fail if mutant is present which would return "middle"
     for (Object sample : result) {
         assertEquals("last", sample);
     }
     
     // Additional verification that we got the expected number of samples
     assertEquals(sampleSize, result.length);
 }

}
