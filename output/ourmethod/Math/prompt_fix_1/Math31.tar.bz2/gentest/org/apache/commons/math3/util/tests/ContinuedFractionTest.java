package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
 
public class ContinuedFractionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                        public void testEvaluate_ConvergesNormally() {
                                            // Setup mock
                                            ContinuedFraction fraction = spy(new ContinuedFraction() {
                                                @Override
                                                protected double getA(int n, double x) {
                                                    return 1.0;
                                                }
                                                
                                                @Override
                                                protected double getB(int n, double x) {
                                                    return 1.0;
                                                }
                                            });
                                            
                                            double x = 1.0;
                                            double epsilon = 1e-6;
                                            int maxIterations = 100;
                                            
                                            double result = fraction.evaluate(x, epsilon, maxIterations);
                                            
                                            // Verify convergence happened before max iterations
                                            assertTrue(result != 0.0);
                                            assertFalse(Double.isNaN(result));
                                            assertFalse(Double.isInfinite(result));
                                        }

    @Test
                                        public void testEvaluate_ThrowsConvergenceExceptionWhenInfinite() {
                                            ContinuedFraction fraction = spy(new ContinuedFraction() {
                                                @Override
                                                protected double getA(int n, double x) {
                                                    return n * 1e100; // Large values that will cause overflow
                                                }
                                                
                                                @Override
                                                protected double getB(int n, double x) {
                                                    return 1.0;
                                                }
                                            });
                                            
                                            double x = 1.0;
                                            double epsilon = 1e-6;
                                            int maxIterations = 100;
                                            
                                            thrown.expect(ConvergenceException.class);
                                            thrown.expectMessage("CONTINUED_FRACTION_INFINITY_DIVERGENCE");
                                            fraction.evaluate(x, epsilon, maxIterations);
                                        }

    @Test
                                        public void testEvaluate_ThrowsConvergenceExceptionWhenNaN() {
                                            ContinuedFraction fraction = spy(new ContinuedFraction() {
                                                @Override
                                                protected double getA(int n, double x) {
                                                    return Double.NaN;
                                                }
                                                
                                                @Override
                                                protected double getB(int n, double x) {
                                                    return 1.0;
                                                }
                                            });
                                            
                                            double x = 1.0;
                                            double epsilon = 1e-6;
                                            int maxIterations = 100;
                                            
                                            thrown.expect(ConvergenceException.class);
                                            thrown.expectMessage("CONTINUED_FRACTION_NAN_DIVERGENCE");
                                            fraction.evaluate(x, epsilon, maxIterations);
                                        }

    @Test
                                        public void testEvaluate_ThrowsMaxCountExceededException() {
                                            ContinuedFraction fraction = spy(new ContinuedFraction() {
                                                @Override
                                                protected double getA(int n, double x) {
                                                    return 1.0 + 1.0/n; // Slowly converging sequence
                                                }
                                                
                                                @Override
                                                protected double getB(int n, double x) {
                                                    return 1.0;
                                                }
                                            });
                                            
                                            double x = 1.0;
                                            double epsilon = 1e-16; // Very tight tolerance
                                            int maxIterations = 10; // Low iteration limit
                                            
                                            thrown.expect(MaxCountExceededException.class);
                                            thrown.expectMessage("NON_CONVERGENT_CONTINUED_FRACTION");
                                            fraction.evaluate(x, epsilon, maxIterations);
                                        }

    @Test
                                        public void testEvaluate_HandlesSmallValues() {
                                            ContinuedFraction fraction = spy(new ContinuedFraction() {
                                                @Override
                                                protected double getA(int n, double x) {
                                                    return (n == 0) ? 1e-100 : 1.0; // Very small initial value
                                                }
                                                
                                                @Override
                                                protected double getB(int n, double x) {
                                                    return 1.0;
                                                }
                                            });
                                            
                                            double x = 1.0;
                                            double epsilon = 1e-6;
                                            int maxIterations = 100;
                                            
                                            double result = fraction.evaluate(x, epsilon, maxIterations);
                                            
                                            assertTrue(result > 0);
                                            assertFalse(Double.isNaN(result));
                                        }

    @Test
                                        public void testEvaluate_HandlesZeroInIntermediateCalculations() {
                                            ContinuedFraction fraction = spy(new ContinuedFraction() {
                                                @Override
                                                protected double getA(int n, double x) {
                                                    return (n % 2 == 0) ? 0.0 : 1.0;
                                                }
                                                
                                                @Override
                                                protected double getB(int n, double x) {
                                                    return 1.0;
                                                }
                                            });
                                            
                                            double x = 1.0;
                                            double epsilon = 1e-6;
                                            int maxIterations = 100;
                                            
                                            double result = fraction.evaluate(x, epsilon, maxIterations);
                                            
                                            assertTrue(result != 0.0);
                                            assertFalse(Double.isNaN(result));
                                        }

    @Test
                                        public void testEvaluate_WithDefaultEpsilon() {
                                            ContinuedFraction fraction = spy(new ContinuedFraction() {
                                                @Override
                                                protected double getA(int n, double x) {
                                                    return 1.0;
                                                }
                                                
                                                @Override
                                                protected double getB(int n, double x) {
                                                    return 1.0;
                                                }
                                            });
                                            
                                            double x = 1.0;
                                            int maxIterations = 100;
                                            
                                            double result = fraction.evaluate(x, maxIterations);
                                            
                                            assertTrue(result != 0.0);
                                            assertFalse(Double.isNaN(result));
                                        }

    @Test
                                public void testEvaluate_WithDefaultEpsilonAndMaxIterations() {
                                    // Create a test implementation of ContinuedFraction
                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;  // Simple constant numerator
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return n;    // Simple denominator based on iteration count
                                        }
                                    };
                                    
                                    double x = 2.0;
                                    double result = continuedFraction.evaluate(x);
                                    
                                    // Since we're using a simple test implementation, we can predict the result
                                    // The exact expected value depends on the convergence of our test implementation
                                    assertTrue(result > 0);
                                }

    @Test
                                public void testEvaluate_WithCustomEpsilon() {
                                    ContinuedFraction continuedFraction = mock(ContinuedFraction.class);
                                    when(continuedFraction.evaluate(anyDouble(), anyDouble())).thenReturn(1.0);
                                    
                                    double x = 2.0;
                                    double epsilon = 0.00001;
                                    double result = continuedFraction.evaluate(x, epsilon);
                                    
                                    // Verify result is within reasonable bounds
                                    assertTrue(result > 0);
                                }

    @Test
                                public void testEvaluate_WithMaxIterations() {
                                    // Create a concrete implementation of ContinuedFraction for testing
                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;  // Simple implementation for testing
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;  // Simple implementation for testing
                                        }
                                    };
                                    
                                    double x = 2.0;
                                    int maxIterations = 100;
                                    double result = continuedFraction.evaluate(x, maxIterations);
                                    
                                    // Verify result is within reasonable bounds
                                    assertTrue(result > 0);
                                }

    @Test
                                public void testEvaluate_WithCustomEpsilonAndMaxIterations() {
                                    // Create a mock implementation of ContinuedFraction
                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0; // Simple implementation for testing
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0; // Simple implementation for testing
                                        }
                                    };
                                    
                                    double x = 2.0;
                                    double epsilon = 0.00001;
                                    int maxIterations = 1000;
                                    double result = continuedFraction.evaluate(x, epsilon, maxIterations);
                                    
                                    // Verify result is within reasonable bounds
                                    assertTrue(result > 0);
                                }

    @Test
                                public void testEvaluate_WithZeroEpsilon_ShouldUseDefault() {
                                    // Create a concrete implementation for testing
                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double x = 2.0;
                                    double epsilon = 0.0;
                                    double result = continuedFraction.evaluate(x, epsilon);
                                    
                                    // Should use DEFAULT_EPSILON instead of 0
                                    assertTrue(result > 0);
                                }

    @Test
                                public void testEvaluate_WithNegativeEpsilon_ShouldUseDefault() {
                                    // Create a concrete implementation of ContinuedFraction for testing
                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double x = 2.0;
                                    double epsilon = -0.1;
                                    double result = continuedFraction.evaluate(x, epsilon);
                                    
                                    // Should use DEFAULT_EPSILON instead of negative value
                                    assertTrue(result > 0);
                                }

    @Test
                                public void testEvaluate_WithZeroMaxIterations_ShouldUseDefault() {
                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double x = 2.0;
                                    int maxIterations = 0;
                                    double result = continuedFraction.evaluate(x, maxIterations);
                                    
                                    // Should use Integer.MAX_VALUE instead of 0
                                    assertTrue(result > 0);
                                }

    @Test
                                public void testEvaluate_WithNegativeMaxIterations_ShouldUseDefault() {
                                    // Create a concrete implementation of ContinuedFraction for testing
                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double x = 2.0;
                                    int maxIterations = -100;
                                    double result = continuedFraction.evaluate(x, maxIterations);
                                    
                                    // Should use Integer.MAX_VALUE instead of negative value
                                    assertTrue(result > 0);
                                }

    @Test
                                public void testEvaluate_WithExtremeXValue() {
                                    // Create a concrete implementation of ContinuedFraction for testing
                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double x = Double.MAX_VALUE;
                                    double result = continuedFraction.evaluate(x);
                                    
                                    // Verify the method handles extreme values without crashing
                                    assertNotNull(Double.valueOf(result));
                                }

    @Test
                                public void testEvaluate_WithPositiveInfinity() {
                                    // Create an anonymous subclass of ContinuedFraction for testing
                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    // Setup exception rule
                                    ExpectedException thrown = ExpectedException.none();
                                    
                                    double x = Double.POSITIVE_INFINITY;
                                    thrown.expect(IllegalArgumentException.class);
                                    continuedFraction.evaluate(x);
                                }

    @Test
                                public void testEvaluate_WithNegativeInfinity() {
                                    // Create a concrete instance of ContinuedFraction for testing
                                    ContinuedFraction continuedFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    // Setup expected exception
                                    ExpectedException thrown = ExpectedException.none();
                                    thrown.expect(IllegalArgumentException.class);
                                    
                                    // Test with negative infinity
                                    double x = Double.NEGATIVE_INFINITY;
                                    continuedFraction.evaluate(x);
                                }

    @Test
                                public void testEvaluate_SingleParameter_ShouldUseDefaultEpsilon() {
                                    // Setup
                                    double x = 2.0;
                                    double epsilon = 1.0e-15; // Using typical default epsilon value since DEFAULT_EPSILON is private
                                    ContinuedFraction mockFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double expected = mockFraction.evaluate(x, epsilon, Integer.MAX_VALUE);
                                    
                                    // Test
                                    double result = mockFraction.evaluate(x);
                                    
                                    // Verify
                                    assertEquals(expected, result, 0.0001);
                                }

    @Test
                                public void testEvaluate_WithEpsilon_ShouldUseProvidedEpsilon() {
                                    // Setup
                                    ContinuedFraction mockFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    double x = 2.0;
                                    double epsilon = 0.00001;
                                    double expected = mockFraction.evaluate(x, epsilon, Integer.MAX_VALUE);
                                    
                                    // Test
                                    double result = mockFraction.evaluate(x, epsilon);
                                    
                                    // Verify
                                    assertEquals(expected, result, 0.0001);
                                }

    @Test
                                public void testEvaluate_WithMaxIterations_ShouldUseProvidedMaxIterations() {
                                    // Setup
                                    double x = 2.0;
                                    int maxIterations = 100;
                                    double epsilon = 1.0e-15; // Using a default epsilon value since DEFAULT_EPSILON is private
                                    ContinuedFraction mockFraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double expected = mockFraction.evaluate(x, epsilon, maxIterations);
                                    
                                    // Test
                                    double result = mockFraction.evaluate(x, maxIterations);
                                    
                                    // Verify
                                    assertEquals(expected, result, 0.0001);
                                }

    @Test
                                public void testEvaluate_WithAllParameters_ShouldUseProvidedValues() {
                                    // Setup
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    double x = 2.0;
                                    double epsilon = 0.00001;
                                    int maxIterations = 100;
                                    
                                    // Test
                                    double result = fraction.evaluate(x, epsilon, maxIterations);
                                    
                                    // Verify that it doesn't throw exception and returns a valid number
                                    assertNotNull(Double.valueOf(result));
                                }

    @Test
                                public void testEvaluate_ZeroEpsilon_ShouldThrowException() {
                                    // Setup
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 0;
                                        }
                                    };
                                    double x = 2.0;
                                    double epsilon = 0.0;
                                    int maxIterations = 100;
                                    
                                    // Expect exception
                                    try {
                                        fraction.evaluate(x, epsilon, maxIterations);
                                        fail("Expected IllegalArgumentException");
                                    } catch (IllegalArgumentException e) {
                                        assertEquals("epsilon must be > 0", e.getMessage());
                                    }
                                }

    @Test
                                public void testEvaluate_NegativeEpsilon_ShouldThrowException() {
                                    // Setup
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    double x = 2.0;
                                    double epsilon = -0.1;
                                    int maxIterations = 100;
                                    
                                    // Expect exception
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("epsilon must be > 0");
                                    
                                    // Test
                                    fraction.evaluate(x, epsilon, maxIterations);
                                }

    @Test
                                public void testEvaluate_ZeroMaxIterations_ShouldThrowException() {
                                    // Setup
                                    double x = 2.0;
                                    double epsilon = 0.00001;
                                    int maxIterations = 0;
                                    
                                    // Create test instance (assuming ContinuedFraction is abstract, we need to mock it)
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 0;
                                        }
                                    };
                                    
                                    // Setup exception rule
                                    ExpectedException thrown = ExpectedException.none();
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("maxIterations must be > 0");
                                    
                                    // Test
                                    fraction.evaluate(x, epsilon, maxIterations);
                                }

    @Test
                                public void testEvaluate_NegativeMaxIterations_ShouldThrowException() {
                                    // Setup
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    double x = 2.0;
                                    double epsilon = 0.00001;
                                    int maxIterations = -100;
                                    
                                    // Expect exception
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("maxIterations must be > 0");
                                    
                                    // Test
                                    fraction.evaluate(x, epsilon, maxIterations);
                                }

    @Test
                                public void testEvaluate_NaNInput_ShouldReturnNaN() {
                                    // Setup
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    double x = Double.NaN;
                                    double epsilon = 0.00001;
                                    int maxIterations = 100;
                                    
                                    // Test
                                    double result = fraction.evaluate(x, epsilon, maxIterations);
                                    
                                    // Verify
                                    assertTrue(Double.isNaN(result));
                                }

    @Test
                                public void testEvaluate_PositiveInfinityInput_ShouldReturnNaN() {
                                    // Setup
                                    ContinuedFraction mockFraction = mock(ContinuedFraction.class);
                                    when(mockFraction.evaluate(anyDouble(), anyDouble(), anyInt()))
                                           .thenReturn(Double.NaN);
                                    
                                    double x = Double.POSITIVE_INFINITY;
                                    double epsilon = 0.00001;
                                    int maxIterations = 100;
                                    
                                    // Test
                                    double result = mockFraction.evaluate(x, epsilon, maxIterations);
                                    
                                    // Verify
                                    assertTrue(Double.isNaN(result));
                                }

    @Test
                                public void testEvaluate_NegativeInfinityInput_ShouldReturnNaN() {
                                    // Setup
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    double x = Double.NEGATIVE_INFINITY;
                                    double epsilon = 0.00001;
                                    int maxIterations = 100;
                                    
                                    // Test
                                    double result = fraction.evaluate(x, epsilon, maxIterations);
                                    
                                    // Verify
                                    assertTrue(Double.isNaN(result));
                                }

    @Test
                                public void testEvaluate_SingleArg_WithDefaultEpsilonAndIterations() {
                                    // Create a concrete implementation of ContinuedFraction for testing
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double result = fraction.evaluate(2.5);
                                    // Since we're using a simple test implementation, we can verify it's not NaN or infinite
                                    assertFalse(Double.isNaN(result));
                                    assertFalse(Double.isInfinite(result));
                                }

    @Test
                                public void testEvaluate_WithEpsilon_ValidInput() {
                                    // Create an anonymous subclass of ContinuedFraction for testing
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0; // Simple implementation for testing
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0; // Simple implementation for testing
                                        }
                                    };
                                    
                                    double result = fraction.evaluate(3.0, 0.00001);
                                    assertFalse(Double.isNaN(result));
                                    assertFalse(Double.isInfinite(result));
                                }

    @Test
                                public void testEvaluate_WithMaxIterations_ValidInput() {
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0; // dummy implementation for testing
                                        }
                                
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0; // dummy implementation for testing
                                        }
                                    };
                                    
                                    double result = fraction.evaluate(1.5, 100);
                                    assertFalse(Double.isNaN(result));
                                    assertFalse(Double.isInfinite(result));
                                }

    @Test
                                public void testEvaluate_WithEpsilonAndMaxIterations_ValidInput() {
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double result = fraction.evaluate(0.5, 0.0001, 50);
                                    assertFalse(Double.isNaN(result));
                                    assertFalse(Double.isInfinite(result));
                                }

    @Test
                                public void testEvaluate_WithZeroEpsilon_ShouldUseDefault1() {
                                    // Create a concrete instance of ContinuedFraction for testing
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    // Define test epsilon value
                                    final double TEST_EPSILON = 1e-15;
                                    
                                    // Get DEFAULT_EPSILON value through reflection since it's private
                                    double defaultEpsilon = 1e-15; // Default value if reflection fails
                                    try {
                                        Field field = ContinuedFraction.class.getDeclaredField("DEFAULT_EPSILON");
                                        field.setAccessible(true);
                                        defaultEpsilon = field.getDouble(null);
                                    } catch (Exception e) {
                                        // Use default value if reflection fails
                                    }
                                    
                                    double result1 = fraction.evaluate(2.0, 0.0);
                                    double result2 = fraction.evaluate(2.0, defaultEpsilon);
                                    assertEquals(result1, result2, TEST_EPSILON);
                                }

    @Test
                                public void testEvaluate_WithNegativeMaxIterations_ShouldThrowException() {
                                    // Create a concrete instance of ContinuedFraction for testing
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    // Set up expected exception
                                    ExpectedException thrown = ExpectedException.none();
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("Max iterations must be positive");
                                    
                                    // Test the method
                                    fraction.evaluate(1.0, -1);
                                }

    @Test
                                public void testEvaluate_WithNaNInput_ShouldReturnNaN() {
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    double result = fraction.evaluate(Double.NaN);
                                    assertTrue(Double.isNaN(result));
                                }

    @Test
                                public void testEvaluate_WithInfiniteInput_ShouldHandleAppropriately() {
                                    // Create a concrete implementation of ContinuedFraction for testing
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double resultPosInf = fraction.evaluate(Double.POSITIVE_INFINITY);
                                    double resultNegInf = fraction.evaluate(Double.NEGATIVE_INFINITY);
                                    
                                    // Behavior depends on implementation - at least verify it doesn't throw
                                    assertFalse(Double.isNaN(resultPosInf));
                                    assertFalse(Double.isNaN(resultNegInf));
                                }

    @Test
                                public void testEvaluate_WithVerySmallEpsilon_ShouldConverge() {
                                    // Create a concrete implementation of ContinuedFraction for testing
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double result = fraction.evaluate(1.0, 1e-15, 1000);
                                    assertFalse(Double.isNaN(result));
                                }

    @Test
                                public void testEvaluate_WithMaxIterationsTooSmall_ShouldStillReturnValue() {
                                    // Create a concrete implementation of ContinuedFraction for testing
                                    ContinuedFraction fraction = new ContinuedFraction() {
                                        @Override
                                        protected double getA(int n, double x) {
                                            return 1.0;
                                        }
                                        
                                        @Override
                                        protected double getB(int n, double x) {
                                            return 1.0;
                                        }
                                    };
                                    
                                    double result = fraction.evaluate(1.0, 1); // Very small max iterations
                                    assertFalse(Double.isNaN(result));
                                }

    @Test
                            public void testEvaluate_WithNaNValue() {
                                ContinuedFraction continuedFraction = new ContinuedFraction() {
                                    @Override
                                    protected double getA(int n, double x) {
                                        return 1.0;
                                    }
                                    
                                    @Override
                                    protected double getB(int n, double x) {
                                        return 1.0;
                                    }
                                };
                                
                                double x = Double.NaN;
                                try {
                                    continuedFraction.evaluate(x);
                                    fail("Expected IllegalArgumentException for NaN input");
                                } catch (IllegalArgumentException e) {
                                    // Expected exception
                                }
                            }

    @Test
                            public void testEvaluate_WithZeroMaxIterations_ShouldThrowException() {
                                // Setup
                                ExpectedException thrown = ExpectedException.none();
                                ContinuedFraction fraction = new ContinuedFraction() {
                                    @Override
                                    protected double getA(int n, double x) {
                                        return 1.0;
                                    }
                                    
                                    @Override
                                    protected double getB(int n, double x) {
                                        return 1.0;
                                    }
                                };
                                
                                // Expectations
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("Max iterations must be positive");
                                
                                // Test
                                fraction.evaluate(1.0, 0);
                            }

    @Test
                            public void testEvaluate_DetectsPrematureReturnMutant() {
                                // Create a test instance of ContinuedFraction (abstract class needs to be mocked)
                                ContinuedFraction fraction = spy(new ContinuedFraction() {
                                    @Override
                                    protected double getA(int n, double x) {
                                        return 1.0; // Simple pattern for testing
                                    }
                                    
                                    @Override
                                    protected double getB(int n, double x) {
                                        return 1.0; // Simple pattern for testing
                                    }
                                });
                                
                                // Set up test parameters
                                double x = 1.0;
                                double epsilon = 1e-10; // Very small epsilon to ensure multiple iterations
                                
                                // Call the method - the mutant would return early with hN
                                double result = fraction.evaluate(x, epsilon);
                                
                                // Verify the result is properly converged
                                // For our simple pattern, we know it should converge to the golden ratio
                                double expected = (1 + Math.sqrt(5)) / 2; // ~1.618033988749895
                                assertEquals(expected, result, epsilon);
                                
                                // Additional verification - if mutant returned early, this would fail
                                assertTrue(Math.abs(result - expected) < epsilon);
                            }

    @Test
                        public void testEvaluate_ConvergenceOnLastIteration_ShouldNotReturnEarly() {
                            // Setup test data
                            final double x = 1.0;
                            final double epsilon = 1e-10;
                            final int maxIterations = 5;
                            
                            // Create a mock ContinuedFraction that converges on last iteration
                            ContinuedFraction cf = new ContinuedFraction() {
                                private int callCount = 0;
                                
                                @Override
                                protected double getA(int n, double x) {
                                    return 1.0;
                                }
                                
                                @Override
                                protected double getB(int n, double x) {
                                    callCount++;
                                    // Make deltaN reach convergence threshold exactly on last iteration
                                    if (callCount == maxIterations) {
                                        return 0.9999999999; // Will make deltaN very close to 1.0
                                    }
                                    return 0.5;
                                }
                            };
                            
                            // Test the behavior
                            double result = cf.evaluate(x, epsilon, maxIterations);
                            
                            // Verify the result is finite (would throw exception if max iterations check was skipped)
                            assertTrue(Double.isFinite(result));
                            
                            // Additional verification that we actually used all iterations
                            // This would fail if the mutant returned early
                            // (Note: In real implementation, might need to add iteration count tracking)
                            // For this test, we're mainly checking it doesn't throw MaxCountExceededException
                            // and returns a valid result
                        }

    @Test
                       public void testEvaluateShouldCompleteAllIterations() {
                           // Create a concrete test implementation since we can't instantiate the abstract class
                           ContinuedFraction fraction = new ContinuedFraction() {
                               @Override
                               protected double getA(int n, double x) {
                                   return 1.0;
                               }
                               
                               @Override
                               protected double getB(int n, double x) {
                                   return n;
                               }
                           };
                           
                           // Test with a value that requires multiple iterations
                           double x = 0.5;
                           double result = fraction.evaluate(x);
                           
                           // For x=0.5, after sufficient iterations, the value should converge to ~0.6977746579640079
                           final double TEST_EPSILON = 1e-15; // Define test epsilon
                           
                           // Assert that the result matches expected value within reasonable tolerance
                           assertEquals(0.6977746579640079, result, TEST_EPSILON);
                           
                           // If the mutant returns early (hN instead of breaking), the result would be less accurate
                           // and this assertion would fail
                       }

    @Test
                   public void testEvaluateShouldCompleteFullIterationsNotReturnEarly() {
                       // Define test epsilon value
                       final double testEpsilon = 1.0e-15;
                       
                       // Create a test instance using an anonymous subclass since ContinuedFraction is abstract
                       ContinuedFraction fraction = new ContinuedFraction() {
                           @Override
                           protected double getA(int n, double x) {
                               return 1.0; // Simple constant coefficients
                           }
                       
                           @Override
                           protected double getB(int n, double x) {
                               return 1.0; // Simple constant coefficients
                           }
                       };
                   
                       // Test with a value that should require multiple iterations
                       double x = 1.0;
                       double result = fraction.evaluate(x);
                   
                       // The mutation would return early with hN instead of completing iterations
                       // We can't know the exact expected value, but we can verify it's not NaN or zero,
                       // and that it's consistent with the default epsilon version
                       double expected = fraction.evaluate(x, testEpsilon, Integer.MAX_VALUE);
                       assertEquals("Method returned early instead of completing iterations", 
                                   expected, result, testEpsilon);
                       
                       // Additional verification that the result is reasonable
                       assertFalse("Result should not be NaN", Double.isNaN(result));
                       assertTrue("Result should be positive", result > 0);
                   }

    @Test
               public void testEvaluateWithMaxIterationsDetectsStateMutation() {
                   // Create a concrete subclass since ContinuedFraction is abstract
                   ContinuedFraction fraction = new ContinuedFraction() {
                       @Override
                       protected double getA(int n, double x) {
                           return 1.0; // Simple continued fraction pattern
                       }
                       
                       @Override
                       protected double getB(int n, double x) {
                           return 1.0; // Simple continued fraction pattern
                       }
                   };
                   
                   // Test with values where dN and hN would differ significantly
                   double x = 0.5;
                   int maxIterations = 10;
                   
                   // Get the actual result
                   double result = fraction.evaluate(x, maxIterations);
                   
                   // For a simple 1/(1+1/(1+...)) continued fraction, we know approximate expected value
                   // The golden ratio conjugate (√5 - 1)/2 ≈ 0.6180339887498948
                   double expected = (Math.sqrt(5) - 1) / 2;
                   
                   // Verify the result is close to expected (with some tolerance)
                   assertEquals(expected, result, 1e-10);
                   
                   // Also test with more iterations to ensure convergence
                   double moreAccurateResult = fraction.evaluate(x, 100);
                   assertEquals(expected, moreAccurateResult, 1e-15);
                   
                   // The mutation would cause incorrect state tracking and likely prevent proper convergence
                   // So these assertions would fail if the mutation is present
               }

    @Test
               public void testEvaluateDetectsDPrevMutation() {
                   // Setup test parameters
                   double x = 1.0;
                   double epsilon = 1e-10;
                   int maxIterations = 100;
                   
                   // Create a concrete subclass to test (since original is abstract)
                   ContinuedFraction fraction = new ContinuedFraction() {
                       @Override
                       protected double getA(int n, double x) {
                           // Simple pattern where a alternates between 1 and 2
                           return (n % 2 == 0) ? 1.0 : 2.0;
                       }
                       
                       @Override
                       protected double getB(int n, double x) {
                           // Simple pattern where b increases with n
                           return n * 0.5;
                       }
                   };
                   
                   // Calculate expected value (with correct dPrev assignment)
                   double expected = fraction.evaluate(x, epsilon, maxIterations);
                   
                   // Now test with mutation by creating a spy
                   ContinuedFraction spyFraction = spy(fraction);
                   
                   // Modify the behavior to simulate the mutation
                   doAnswer(invocation -> {
                       // Get the original value
                       double originalResult = (double) invocation.callRealMethod();
                       
                       // Force the mutation dPrev = hN instead of dPrev = dN
                       Field dPrevField = ContinuedFraction.class.getDeclaredField("dPrev");
                       dPrevField.setAccessible(true);
                       Field hNField = ContinuedFraction.class.getDeclaredField("hN");
                       hNField.setAccessible(true);
                       
                       double hNValue = hNField.getDouble(invocation.getMock());
                       dPrevField.setDouble(invocation.getMock(), hNValue);
                       
                       return originalResult;
                   }).when(spyFraction).evaluate(anyDouble(), anyDouble(), anyInt());
                   
                   // Verify the mutation causes different behavior
                   try {
                       double mutatedResult = spyFraction.evaluate(x, epsilon, maxIterations);
                       // If we get here, the mutation wasn't caught by exception
                       // So we need to verify the result is different
                       assertNotEquals("Mutation should produce different result", 
                                      expected, mutatedResult, 1e-10);
                   } catch (ConvergenceException | MaxCountExceededException e) {
                       // The mutation caused non-convergence - this also detects it
                       assertTrue("Mutation caused expected divergence", true);
                   }
               }

    @Test
              public void testEvaluateDetectsValueTrackingMutation() {
                  // Create a concrete subclass to test since ContinuedFraction is abstract
                  ContinuedFraction fraction = new ContinuedFraction() {
                      @Override
                      protected double getA(int n, double x) {
                          return 1.0; // Simple continued fraction where a_n = 1 for all n
                      }
              
                      @Override
                      protected double getB(int n, double x) {
                          return x; // b_n = x for all n
                      }
                  };
              
                  // Define our own epsilon for testing
                  final double epsilon = 1.0e-15;
                  
                  // Test with x = 1 which should converge to the golden ratio (1.618...)
                  // The mutation would affect the convergence tracking
                  double result = fraction.evaluate(1.0, epsilon);
                  
                  // Verify result is approximately golden ratio (within epsilon)
                  // The mutation would likely cause this to fail due to incorrect tracking
                  assertEquals(1.61803398875, result, epsilon);
                  
                  // Additional test with x = 0.5 which should converge to 1.0
                  // This helps verify the mutation doesn't just accidentally work for one case
                  double result2 = fraction.evaluate(0.5, epsilon);
                  assertEquals(1.0, result2, epsilon);
              }

    @Test
              public void testEvaluateDetectsMutant() {
                  // Setup - create anonymous implementation of ContinuedFraction for testing
                  ContinuedFraction cf = new ContinuedFraction() {
                      @Override
                      protected double getA(int n, double x) {
                          return 1.0;
                      }
                      
                      @Override
                      protected double getB(int n, double x) {
                          return n == 0 ? 1.0 : (n % 2 == 1 ? x : 1.0);
                      }
                  };
                  
                  double x = 1.0; // Test input value
                  double epsilon = 1e-6; // Reasonable epsilon for testing
                  
                  // Test with default max iterations
                  double result = cf.evaluate(x, epsilon);
                  
                  // The mutation would affect the convergence, so we need to verify:
                  // 1. The result is mathematically correct (or close enough)
                  // 2. The number of iterations isn't affected by the mutation
                  
                  // For a simple continued fraction with these coefficients, we know roughly what to expect
                  double expected = 0.6977746579640079; // Expected value for this simple case
                  assertEquals("Result should match expected value", expected, result, epsilon);
                  
                  // Test with limited iterations to detect if mutation affects convergence
                  int maxIterations = 100;
                  double limitedResult = cf.evaluate(x, epsilon, maxIterations);
                  
                  // If the mutation affects state tracking, it might:
                  // - Take more iterations to converge
                  // - Return a different value
                  assertEquals("Limited iteration result should match", expected, limitedResult, epsilon);
                  
                  // Test with very small max iterations to detect early convergence problems
                  int smallMaxIterations = 5;
                  double smallIterResult = cf.evaluate(x, epsilon, smallMaxIterations);
                  
                  // Verify the result with small iterations is different from final result
                  // (showing that more iterations are needed for proper convergence)
                  assertNotEquals("Small iteration result should be different", 
                                expected, smallIterResult, epsilon);
              }

    @Test
              public void testEvaluateDetectsHPrevMutation() {
                  // Create a concrete subclass to test since ContinuedFraction is abstract
                  ContinuedFraction fraction = new ContinuedFraction() {
                      @Override
                      protected double getA(int n, double x) {
                          return 1.0; // Simple pattern for testing
                      }
                      
                      @Override
                      protected double getB(int n, double x) {
                          return n; // Increasing denominator to force multiple iterations
                      }
                  };
                  
                  // Test with values that require multiple iterations
                  double x = 1.0;
                  double epsilon = 1e-6;
                  
                  // The mutation will cause incorrect convergence due to wrong hPrev assignment
                  double result = fraction.evaluate(x, epsilon);
                  
                  // Expected value calculated based on the pattern defined above
                  // For this simple pattern, we can calculate the expected value
                  // The continued fraction would be 1/(1 + 1/(2 + 1/(3 + ...)))
                  // After several iterations it should converge to ~0.6977746579640079
                  double expected = 0.6977746579640079;
                  
                  // Assert with delta to account for floating point precision
                  assertEquals("Mutation hPrev = dN not detected", 
                              expected, result, epsilon);
                  
                  // Additional assertion to verify it's not converging to some wrong value
                  assertNotEquals("Mutation not detected - result matches incorrect convergence",
                                 0.5, result, epsilon);
              }

    @Test
              public void testEvaluateDetectsHPrevMutation1() {
                  // Create a concrete test instance or mock
                  ContinuedFraction fraction = new ContinuedFraction() {
                      @Override
                      protected double getA(int n, double x) {
                          return 1.0; // Simple pattern for testing
                      }
          
                      @Override
                      protected double getB(int n, double x) {
                          return n; // Simple pattern that will show divergence if hPrev is wrong
                      }
                  };
          
                  // Test with a value that requires multiple iterations
                  // For a simple continued fraction with a_n=1 and b_n=n, we know the expected behavior
                  double x = 1.0;
                  int maxIterations = 10;
                  
                  // The mutation would cause the computation to diverge or give wrong results
                  // We test against a known good value (this would need to be calculated or known)
                  double expected = 0.6977746579640077; // Expected value for this pattern
                  double actual = fraction.evaluate(x, maxIterations);
                  
                  // Use a tight epsilon since we're testing for numerical stability
                  assertEquals("Mutation hPrev = dN should be detected by divergence", 
                              expected, actual, 1e-14);
                  
                  // Also test with more iterations to ensure stability
                  maxIterations = 100;
                  actual = fraction.evaluate(x, maxIterations);
                  assertEquals("Mutation should cause divergence with more iterations",
                              expected, actual, 1e-14);
              }

    @Test
          public void testEvaluateDetectsHPrevMutation2() {
              // Setup test with values that will make hN and dN diverge
              ContinuedFraction fraction = new ContinuedFraction() {
                  @Override
                  protected double getA(int n, double x) {
                      // Simple sequence where a alternates between 1 and 2
                      return (n % 2 == 0) ? 1.0 : 2.0;
                  }
                  
                  @Override
                  protected double getB(int n, double x) {
                      // Simple sequence where b increases with n
                      return n + 1.0;
                  }
              };
              
              // Set parameters that will ensure multiple iterations
              double x = 1.0;
              double epsilon = 1e-10;
              int maxIterations = 10;
              
              // Calculate expected value (with correct hPrev = hN behavior)
              double expected = fraction.evaluate(x, epsilon, maxIterations);
              
              // The mutation would cause different behavior because:
              // 1. In first iteration, hN and dN are different
              // 2. Using dN as hPrev would corrupt subsequent iterations
              // 3. Final result would be significantly different
              
              // If the mutation exists, the result would differ
              // We use a tight delta to catch even small differences
              assertEquals("Mutation hPrev = dN not detected", 
                          expected, 
                          fraction.evaluate(x, epsilon, maxIterations), 
                          1e-15);
          }

    @Test
         public void testEvaluateDetectsHPrevMutation3() {
             // Define test epsilon
             final double TEST_EPSILON = 1e-15;
             
             // Create a concrete subclass to test since ContinuedFraction is abstract
             ContinuedFraction cf = new ContinuedFraction() {
                 @Override
                 protected double getA(int n, double x) {
                     return n == 0 ? 1.0 : 1.0;
                 }
                 
                 @Override
                 protected double getB(int n, double x) {
                     return x;
                 }
             };
             
             // Test with x = 1.0 which should converge to (sqrt(5)-1)/2 ≈ 0.618033988749895
             double expected = (Math.sqrt(5) - 1) / 2;
             double result = cf.evaluate(1.0);
             
             // The mutation would cause either wrong result or failure to converge
             assertEquals("Continued fraction evaluation should match golden ratio conjugate", 
                         expected, result, TEST_EPSILON);
             
             // Also test with x = 2.0 which should converge to sqrt(2)-1 ≈ 0.414213562373095
             expected = Math.sqrt(2) - 1;
             result = cf.evaluate(2.0);
             assertEquals("Continued fraction evaluation should match sqrt(2)-1", 
                         expected, result, TEST_EPSILON);
         }

    @Test
         public void testEvaluateDetectsHNvsCNMutation() {
             // Create a concrete test implementation since we can't instantiate the abstract class
             ContinuedFraction cf = new ContinuedFraction() {
                 @Override
                 protected double getA(int n, double x) {
                     return 1.0; // Simple pattern for testing
                 }
                 
                 @Override
                 protected double getB(int n, double x) {
                     return n; // Increasing denominators to ensure multiple iterations
                 }
             };
             
             // Test with a value that requires multiple iterations
             double x = 0.5;
             double result = cf.evaluate(x);
             
             // The exact expected value depends on the continued fraction formula,
             // but we know it should converge to some predictable value
             // For this simple pattern, we can calculate what it should approximately be
             double expected = 1.0 / (1.0 + 1.0 / (2.0 + 1.0 / (3.0 + 1.0 / 4.0))); // Approximate expected value
             
             // Assert with a reasonable delta to account for floating point precision
             assertEquals("Evaluation should match expected continued fraction value", 
                         expected, result, 1e-10);
             
             // The mutant would produce a different result because hPrev would track cN instead of hN,
             // leading to incorrect propagation of values between iterations
         }

    @Test
         public void testEvaluateDetectsHPrevMutation4() {
             // Create a concrete test implementation for golden ratio continued fraction
             ContinuedFraction fraction = new ContinuedFraction() {
                 @Override
                 protected double getA(int n, double x) {
                     return 1.0;
                 }
                 
                 @Override
                 protected double getB(int n, double x) {
                     return 1.0;
                 }
             };
             
             // Golden ratio is (1 + sqrt(5))/2 ≈ 1.618033988749895
             double goldenRatio = (1 + Math.sqrt(5)) / 2;
             double epsilon = 1e-10;
             
             // Test evaluation with tight epsilon
             double result = fraction.evaluate(1.0, epsilon);
             
             // Verify result is close to golden ratio
             assertEquals(goldenRatio, result, epsilon);
             
             // Also test with more iterations to ensure convergence
             double resultMaxIter = fraction.evaluate(1.0, epsilon, 100);
             assertEquals(goldenRatio, resultMaxIter, epsilon);
             
             // The mutation would cause different convergence behavior,
             // so these assertions would fail if hPrev was incorrectly set to cN
         }

    @Test
     public void testEvaluateDetectsHPrevMutation6() {
         // Create a concrete subclass for testing
         ContinuedFraction fraction = new ContinuedFraction() {
             @Override
             protected double getA(int n, double x) {
                 return 1.0; // Simple constant coefficients for predictable behavior
             }
             
             @Override
             protected double getB(int n, double x) {
                 return 1.0;
             }
         };
         
         // Test parameters
         double x = 1.0;
         double epsilon = 1e-10;
         int maxIterations = 100;
         
         // Expected value calculated from known continued fraction with these coefficients
         // For 1/(1+1/(1+1/(1+...))) the value should approach (sqrt(5)-1)/2 ≈ 0.6180339887
         double expected = (Math.sqrt(5) - 1)/2;
         
         // Calculate actual value
         double actual = fraction.evaluate(x, epsilon, maxIterations);
         
         // Verify the result is correct (would fail with the mutant)
         assertEquals(expected, actual, epsilon);
         
         // Additional verification - test with different parameters
         x = 2.0;
         expected = 1.0 / (1.0 + 1.0 / (1.0 + 1.0 / (1.0 + 1.0))); // 4 iterations exact value
         actual = fraction.evaluate(x, 1e-15, 5);
         assertEquals(expected, actual, 1e-15);
     }

    @Test
    public void testEvaluateDetectsHPrevMutation5() {
        // Create a concrete test implementation since we need to test actual evaluation
        ContinuedFraction cf = new ContinuedFraction() {
            @Override
            protected double getA(int n, double x) {
                return 1.0; // Simple continued fraction where all a_n = 1
            }
    
            @Override
            protected double getB(int n, double x) {
                return 1.0; // Simple continued fraction where all b_n = 1
            }
        };
    
        // For simple 1/(1+1/(1+...)) continued fraction, it should converge to (sqrt(5)-1)/2
        double expected = (Math.sqrt(5) - 1)/2; // Golden ratio conjugate ≈ 0.6180339887498949
        double result = cf.evaluate(1.0, 100); // x=1.0, maxIterations=100
        
        // Define our own epsilon for testing
        double epsilon = 1.0e-15;
        
        // With the mutation hPrev = cN instead of hN, the convergence would be wrong
        assertEquals("Continued fraction evaluation should match golden ratio", 
                    expected, result, epsilon);
        
        // Additional assertion to ensure we're not getting default/zero value
        assertNotEquals(0.0, result, epsilon);
    }


}
