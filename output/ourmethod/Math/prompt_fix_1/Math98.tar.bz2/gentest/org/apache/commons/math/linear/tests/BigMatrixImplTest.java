package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.math.BigDecimal;
 
public class BigMatrixImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                                                                       public void testOperate_ValidInput_CorrectMultiplication() {
                                                                                                           // Create a 2x3 matrix
                                                                                                           BigDecimal[][] data = {
                                                                                                               {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                                                                               {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")}
                                                                                                           };
                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                           
                                                                                                           // Create a vector of length 3
                                                                                                           BigDecimal[] vector = {
                                                                                                               new BigDecimal("1"),
                                                                                                               new BigDecimal("2"),
                                                                                                               new BigDecimal("3")
                                                                                                           };
                                                                                                           
                                                                                                           BigDecimal[] result = matrix.operate(vector);
                                                                                                           
                                                                                                           // Expected results: 
                                                                                                           // Row 0: 1*1 + 2*2 + 3*3 = 14
                                                                                                           // Row 1: 4*1 + 5*2 + 6*3 = 32
                                                                                                           assertEquals(2, result.length);
                                                                                                           assertEquals(new BigDecimal("14"), result[0]);
                                                                                                           assertEquals(new BigDecimal("32"), result[1]);
                                                                                                       }

 @Test
                                                                                                       public void testOperate_InvalidVectorLength_ThrowsException() {
                                                                                                           // Create a 2x2 matrix
                                                                                                           BigDecimal[][] data = {
                                                                                                               {new BigDecimal("1"), new BigDecimal("2")},
                                                                                                               {new BigDecimal("3"), new BigDecimal("4")}
                                                                                                           };
                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                           
                                                                                                           // Create a vector of wrong length (3 instead of 2)
                                                                                                           BigDecimal[] vector = {
                                                                                                               new BigDecimal("1"),
                                                                                                               new BigDecimal("2"),
                                                                                                               new BigDecimal("3")
                                                                                                           };
                                                                                                           
                                                                                                           thrown.expect(IllegalArgumentException.class);
                                                                                                           thrown.expectMessage("vector has wrong length");
                                                                                                           matrix.operate(vector);
                                                                                                       }

 @Test
                                                                                                       public void testOperate_ZeroVector_ReturnsZeroVector() {
                                                                                                           // Create a 3x3 matrix
                                                                                                           BigDecimal[][] data = {
                                                                                                               {new BigDecimal("1"), new BigDecimal("2"), new BigDecimal("3")},
                                                                                                               {new BigDecimal("4"), new BigDecimal("5"), new BigDecimal("6")},
                                                                                                               {new BigDecimal("7"), new BigDecimal("8"), new BigDecimal("9")}
                                                                                                           };
                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                           
                                                                                                           // Create a zero vector
                                                                                                           BigDecimal[] vector = {
                                                                                                               BigDecimal.ZERO,
                                                                                                               BigDecimal.ZERO,
                                                                                                               BigDecimal.ZERO
                                                                                                           };
                                                                                                           
                                                                                                           BigDecimal[] result = matrix.operate(vector);
                                                                                                           
                                                                                                           assertEquals(3, result.length);
                                                                                                           assertEquals(BigDecimal.ZERO, result[0]);
                                                                                                           assertEquals(BigDecimal.ZERO, result[1]);
                                                                                                           assertEquals(BigDecimal.ZERO, result[2]);
                                                                                                       }

 @Test
                                                                                                       public void testOperate_WithNegativeValues_CorrectMultiplication() {
                                                                                                           // Create a 2x2 matrix with negative values
                                                                                                           BigDecimal[][] data = {
                                                                                                               {new BigDecimal("-1"), new BigDecimal("2")},
                                                                                                               {new BigDecimal("3"), new BigDecimal("-4")}
                                                                                                           };
                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                           
                                                                                                           // Create a vector with mixed values
                                                                                                           BigDecimal[] vector = {
                                                                                                               new BigDecimal("5"),
                                                                                                               new BigDecimal("-6")
                                                                                                           };
                                                                                                           
                                                                                                           BigDecimal[] result = matrix.operate(vector);
                                                                                                           
                                                                                                           // Expected results:
                                                                                                           // Row 0: -1*5 + 2*-6 = -5 + -12 = -17
                                                                                                           // Row 1: 3*5 + -4*-6 = 15 + 24 = 39
                                                                                                           assertEquals(2, result.length);
                                                                                                           assertEquals(new BigDecimal("-17"), result[0]);
                                                                                                           assertEquals(new BigDecimal("39"), result[1]);
                                                                                                       }

 @Test
                                                                                                       public void testOperate_WithDecimalValues_CorrectMultiplication() {
                                                                                                           // Create a 1x2 matrix with decimal values
                                                                                                           BigDecimal[][] data = {
                                                                                                               {new BigDecimal("1.5"), new BigDecimal("2.5")}
                                                                                                           };
                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                           
                                                                                                           // Create a vector with decimal values
                                                                                                           BigDecimal[] vector = {
                                                                                                               new BigDecimal("0.4"),
                                                                                                               new BigDecimal("0.6")
                                                                                                           };
                                                                                                           
                                                                                                           BigDecimal[] result = matrix.operate(vector);
                                                                                                           
                                                                                                           // Expected result: 1.5*0.4 + 2.5*0.6 = 0.6 + 1.5 = 2.1
                                                                                                           assertEquals(1, result.length);
                                                                                                           assertEquals(new BigDecimal("2.1"), result[0]);
                                                                                                       }

 @Test
                                                                                                       public void testOperate_WithLargeNumbers_CorrectMultiplication() {
                                                                                                           // Create a 2x2 matrix with large numbers
                                                                                                           BigDecimal[][] data = {
                                                                                                               {new BigDecimal("1000000000"), new BigDecimal("2000000000")},
                                                                                                               {new BigDecimal("3000000000"), new BigDecimal("4000000000")}
                                                                                                           };
                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                           
                                                                                                           // Create a vector with large numbers
                                                                                                           BigDecimal[] vector = {
                                                                                                               new BigDecimal("5000000000"),
                                                                                                               new BigDecimal("6000000000")
                                                                                                           };
                                                                                                           
                                                                                                           BigDecimal[] result = matrix.operate(vector);
                                                                                                           
                                                                                                           // Expected results:
                                                                                                           // Row 0: 1000000000*5000000000 + 2000000000*6000000000 = 5000000000000000000 + 12000000000000000000 = 17000000000000000000
                                                                                                           // Row 1: 3000000000*5000000000 + 4000000000*6000000000 = 15000000000000000000 + 24000000000000000000 = 39000000000000000000
                                                                                                           assertEquals(2, result.length);
                                                                                                           assertEquals(new BigDecimal("17000000000000000000"), result[0]);
                                                                                                           assertEquals(new BigDecimal("39000000000000000000"), result[1]);
                                                                                                       }

 @Test
                                                                                                       public void testOperate_WithMockedMatrix_VerifiesInteraction() {
                                                                                                           // Create a mock matrix with 2 rows and 3 columns
                                                                                                           BigMatrixImpl matrix = mock(BigMatrixImpl.class);
                                                                                                           when(matrix.getColumnDimension()).thenReturn(3);
                                                                                                           when(matrix.getRowDimension()).thenReturn(2);
                                                                                                           
                                                                                                           // Setup the operate method to return a specific result
                                                                                                           BigDecimal[] expectedResult = {
                                                                                                               new BigDecimal("10"),
                                                                                                               new BigDecimal("20")
                                                                                                           };
                                                                                                           when(matrix.operate(any(BigDecimal[].class))).thenReturn(expectedResult);
                                                                                                           
                                                                                                           // Test the method
                                                                                                           BigDecimal[] vector = {
                                                                                                               new BigDecimal("1"),
                                                                                                               new BigDecimal("2"),
                                                                                                               new BigDecimal("3")
                                                                                                           };
                                                                                                           BigDecimal[] result = matrix.operate(vector);
                                                                                                           
                                                                                                           // Verify the interaction
                                                                                                           verify(matrix).operate(vector);
                                                                                                           assertArrayEquals(expectedResult, result);
                                                                                                       }

 @Test
                                                                                               public void testOperate_ValidDoubleArray() {
                                                                                                   // Create a matrix instance first
                                                                                                   BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                   
                                                                                                   double[] input = {1.5, 2.5};
                                                                                                   
                                                                                                   // Mock the internal operate(BigDecimal[]) method to return expected result
                                                                                                   BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                   BigDecimal[] expectedResult = {new BigDecimal("8.5"), new BigDecimal("14.5")};
                                                                                                   doReturn(expectedResult).when(spyMatrix).operate(any(BigDecimal[].class));
                                                                                                   
                                                                                                   BigDecimal[] result = spyMatrix.operate(input);
                                                                                                   
                                                                                                   assertNotNull(result);
                                                                                                   assertEquals(2, result.length);
                                                                                                   assertEquals(new BigDecimal("8.5"), result[0]);
                                                                                                   assertEquals(new BigDecimal("14.5"), result[1]);
                                                                                               }

 @Test
                                                                                               public void testOperate_EmptyArray() {
                                                                                                   double[] input = {};
                                                                                                   BigMatrixImpl matrix = new BigMatrixImpl(); // Initialize the matrix
                                                                                                   
                                                                                                   // Set up expected exception
                                                                                                   try {
                                                                                                       matrix.operate(input);
                                                                                                       fail("Expected IllegalArgumentException");
                                                                                                   } catch (IllegalArgumentException e) {
                                                                                                       assertEquals("vector has wrong length", e.getMessage());
                                                                                                   }
                                                                                               }

 @Test
                                                                                               public void testOperate_VerifyConversionAccuracy() {
                                                                                                   // Create a matrix instance first
                                                                                                   BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                   
                                                                                                   double[] input = {1.23456789, 2.34567890};
                                                                                                   
                                                                                                   // Mock the internal operate method to just return the converted values
                                                                                                   BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                   doAnswer(invocation -> {
                                                                                                       BigDecimal[] arg = invocation.getArgument(0);
                                                                                                       return new BigDecimal[]{arg[0], arg[1]};
                                                                                                   }).when(spyMatrix).operate(any(BigDecimal[].class));
                                                                                                   
                                                                                                   BigDecimal[] result = spyMatrix.operate(input);
                                                                                                   
                                                                                                   assertEquals(new BigDecimal("1.23456789"), result[0]);
                                                                                                   assertEquals(new BigDecimal("2.34567890"), result[1]);
                                                                                               }

 @Test
                                                                                               public void testOperate_WrongVectorLength() {
                                                                                                   // Create a 2x2 matrix
                                                                                                   double[][] matrixData = {{1.0, 2.0}, {3.0, 4.0}};
                                                                                                   BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                                                                                                   
                                                                                                   // Input vector with wrong length (3 elements for 2x2 matrix)
                                                                                                   double[] input = {1.0, 2.0, 3.0};
                                                                                                   
                                                                                                   // Set up exception expectation
                                                                                                   try {
                                                                                                       matrix.operate(input);
                                                                                                       fail("Expected IllegalArgumentException");
                                                                                                   } catch (IllegalArgumentException e) {
                                                                                                       assertEquals("vector has wrong length", e.getMessage());
                                                                                                   }
                                                                                               }

 @Test
                                                                                           public void testOperate_ArrayWithNaN() {
                                                                                               double[] input = {1.0, Double.NaN};
                                                                                               BigMatrixImpl matrix = new BigMatrixImpl(2, 1); // Create matrix instance with proper dimensions
                                                                                               matrix.operate(input);
                                                                                           }

 @Test
                                                                                           public void testOperate_ArrayWithInfiniteValues() {
                                                                                               double[] input = {1.0, Double.POSITIVE_INFINITY};
                                                                                               BigMatrixImpl matrix = new BigMatrixImpl(); // Create matrix instance
                                                                                               matrix.operate(input);
                                                                                           }

 @Test
                                                      public void testGetRowAsDoubleArrayWithInvalidRowThrowsException() {
                                                          // Setup test data
                                                          int invalidRow = -1; // clearly invalid row index
                                                          BigMatrixImpl matrix = new BigMatrixImpl(2, 2); // 2x2 matrix
                                                          
                                                          // Set expectation for exception
                                                          thrown.expect(MatrixIndexException.class);
                                                          thrown.expectMessage("illegal row argument");
                                                          
                                                          // Execute the test - this should throw the expected exception
                                                          // since the row index is invalid
                                                          matrix.getRowAsDoubleArray(invalidRow);
                                                      }

 @Test
                                                 public void testGetRowAsDoubleArrayWithSingleColumnMatrix() {
                                                     // Create a single column matrix for testing
                                                     double[][] matrixData = {{10.0}, {20.0}, {30.0}};
                                                     BigMatrixImpl singleColumnMatrix = new BigMatrixImpl(matrixData);
                                                     
                                                     // Test getting row 1 (second row) as double array
                                                     double[] result = singleColumnMatrix.getRowAsDoubleArray(1);
                                                     assertNotNull(result);
                                                     assertEquals(1, result.length);
                                                     assertEquals(20.0, result[0], 0.0001);
                                                 }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                 public void testGetRowAsDoubleArrayWithInvalidRow() {
                                                     // Create a single column matrix with 1 row
                                                     BigDecimal[] data = {new BigDecimal("1.0")};
                                                     BigMatrixImpl singleColumnMatrix = new BigMatrixImpl(data);
                                                     
                                                     // This tests the original validation still works for clearly invalid rows
                                                     singleColumnMatrix.getRowAsDoubleArray(2); // row 2 doesn't exist
                                                 }

 @Test
                                            public void testGetRowAsDoubleArray_InvalidRow_ExceptionMessage() {
                                                // Setup - create a matrix with mock data
                                                BigDecimal[][] mockData = {
                                                    {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                    {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                };
                                                BigMatrixImpl matrix = new BigMatrixImpl(mockData);
                                                
                                                try {
                                                    // Try to get row with invalid index
                                                    matrix.getRowAsDoubleArray(2);
                                                    fail("Expected MatrixIndexException");
                                                } catch (MatrixIndexException e) {
                                                    // Verify the exception message matches original implementation
                                                    assertEquals("illegal row argument", e.getMessage());
                                                }
                                            }

 @Test
                                        public void testGetRowAsDoubleArrayDetectsColumnDimensionMutation() {
                                            // Create a 2x3 matrix with known values
                                            BigDecimal[][] testData = {
                                                {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                            };
                                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                            
                                            // Test first row
                                            double[] row0 = matrix.getRowAsDoubleArray(0);
                                            assertEquals("Array length should match column dimension", 3, row0.length);
                                            assertEquals(1.0, row0[0], 0.0001);
                                            assertEquals(2.0, row0[1], 0.0001);
                                            assertEquals(3.0, row0[2], 0.0001);
                                            
                                            // Test second row
                                            double[] row1 = matrix.getRowAsDoubleArray(1);
                                            assertEquals("Array length should match column dimension", 3, row1.length);
                                            assertEquals(4.0, row1[0], 0.0001);
                                            assertEquals(5.0, row1[1], 0.0001);
                                            assertEquals(6.0, row1[2], 0.0001);
                                        }

 @Test
                                       public void testGetRowAsDoubleArrayDetectsColumnDimensionMutant() {
                                           // Create a non-square matrix (2 rows x 3 columns)
                                           BigDecimal[][] testData = {
                                               {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                               {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                           };
                                           BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                           
                                           // Test with valid row index
                                           int testRow = 0;
                                           double[] result = matrix.getRowAsDoubleArray(testRow);
                                           
                                           // Verify array length matches column dimension (not row dimension)
                                           assertEquals("Array length should match column dimension", 
                                                       3, result.length);
                                           
                                           // Verify all column values are correctly copied
                                           assertEquals(1.0, result[0], 0.0001);
                                           assertEquals(2.0, result[1], 0.0001);
                                           assertEquals(3.0, result[2], 0.0001);
                                           
                                           // Additional test with different row to ensure consistency
                                           testRow = 1;
                                           result = matrix.getRowAsDoubleArray(testRow);
                                           assertEquals("Array length should still match column dimension", 
                                                       3, result.length);
                                           assertEquals(4.0, result[0], 0.0001);
                                           assertEquals(5.0, result[1], 0.0001);
                                           assertEquals(6.0, result[2], 0.0001);
                                       }

 @Test
                                      public void testGetRowAsDoubleArray_ReturnsCorrectArraySize() {
                                          // Setup test matrix with known dimensions (2x3)
                                          BigDecimal[][] testData = {
                                              {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                              {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                          };
                                          BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                          
                                          // Call method under test
                                          double[] result = matrix.getRowAsDoubleArray(0);
                                          
                                          // Verify array size matches column dimension
                                          assertEquals("Array length should match column dimension", 
                                                       matrix.getColumnDimension(), 
                                                       result.length);
                                          
                                          // Additional verification that all values were copied correctly
                                          for (int i = 0; i < result.length; i++) {
                                              assertEquals(testData[0][i].doubleValue(), result[i], 0.0001);
                                          }
                                      }

 @Test
                                     public void testGetRowAsDoubleArrayDetectsLoopBoundaryMutant() {
                                         // Setup test matrix with known dimensions (2x3)
                                         BigDecimal[][] testData = {
                                             {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                             {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                         };
                                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                         
                                         // Test valid row access - should work in original but fail in mutant
                                         try {
                                             double[] result = matrix.getRowAsDoubleArray(0);
                                             // Verify correct array length and contents
                                             assertEquals(3, result.length);
                                             assertEquals(1.0, result[0], 0.0001);
                                             assertEquals(2.0, result[1], 0.0001);
                                             assertEquals(3.0, result[2], 0.0001);
                                         } catch (ArrayIndexOutOfBoundsException e) {
                                             // This indicates the mutant was detected
                                             fail("Mutant detected: ArrayIndexOutOfBoundsException was thrown");
                                         }
                                         
                                         // Additional test to explicitly check for array bounds
                                         try {
                                             // This would throw ArrayIndexOutOfBoundsException in mutant
                                             matrix.getRowAsDoubleArray(1);
                                         } catch (ArrayIndexOutOfBoundsException e) {
                                             fail("Mutant detected: ArrayIndexOutOfBoundsException was thrown");
                                         }
                                     }

 @Test
                                    public void testGetRowAsDoubleArrayDetectsMutant() {
                                        // Setup test data - create a 2x2 matrix with known values
                                        BigDecimal[][] testData = {
                                            {new BigDecimal("1.1"), new BigDecimal("2.2")},
                                            {new BigDecimal("3.3"), new BigDecimal("4.4")}
                                        };
                                        BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                        
                                        // Test first row
                                        double[] result = matrix.getRowAsDoubleArray(0);
                                        
                                        // Verify all elements are correctly converted
                                        assertEquals(2, result.length); // Verify array length
                                        assertEquals(1.1, result[0], 0.0001); // This would fail with the mutant (0.0 vs 1.1)
                                        assertEquals(2.2, result[1], 0.0001);
                                        
                                        // Test second row for completeness
                                        result = matrix.getRowAsDoubleArray(1);
                                        assertEquals(2, result.length);
                                        assertEquals(3.3, result[0], 0.0001);
                                        assertEquals(4.4, result[1], 0.0001);
                                    }

 @Test
                                   public void testGetRowAsDoubleArrayDetectsIncrementMutant() {
                                       // Setup test data - create a simple 2x2 matrix
                                       BigDecimal[][] testData = {
                                           {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                           {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                       };
                                       BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                       
                                       // Test valid row access
                                       double[] expected = {1.0, 2.0};
                                       double[] actual = matrix.getRowAsDoubleArray(0);
                                       
                                       // Verify the array contents match expected values
                                       assertArrayEquals(expected, actual, 0.0001);
                                       
                                       // The mutated version would throw ArrayIndexOutOfBoundsException here
                                       // so if we get to this point with the correct values, the test passes
                                       // and the mutant would be caught if it throws an exception
                                   }

 @Test
                                  public void testGetRowAsDoubleArrayDetectsRowColumnSwapMutant() {
                                      // Create a non-square 2x3 test matrix with distinct values
                                      BigDecimal[][] testData = new BigDecimal[][] {
                                          {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                          {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                      };
                                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                      
                                      // Test getting first row
                                      double[] expectedRow0 = {1.0, 2.0, 3.0};
                                      double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                      assertArrayEquals("First row values incorrect", expectedRow0, actualRow0, 0.0001);
                                      
                                      // Test getting second row
                                      double[] expectedRow1 = {4.0, 5.0, 6.0};
                                      double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                                      assertArrayEquals("Second row values incorrect", expectedRow1, actualRow1, 0.0001);
                                      
                                      // The mutant would either:
                                      // 1. Throw ArrayIndexOutOfBoundsException (for non-square matrices)
                                      // 2. Return wrong values (for square matrices)
                                      // Our assertions will catch both cases
                                  }

 @Test
                                 public void testGetRowAsDoubleArrayWithDecimalValues() {
                                     // Setup test data with BigDecimal values that have decimal parts
                                     BigDecimal[][] testData = {
                                         {new BigDecimal("1.23"), new BigDecimal("4.56"), new BigDecimal("7.89")},
                                         {new BigDecimal("0.123"), new BigDecimal("45.678"), new BigDecimal("901.2345")}
                                     };
                                     
                                     // Create the matrix using the constructor that takes BigDecimal[][]
                                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                     
                                     // Test the first row
                                     double[] result = matrix.getRowAsDoubleArray(0);
                                     
                                     // Verify the values match exactly (including decimal parts)
                                     assertEquals(1.23, result[0], 0.000001);
                                     assertEquals(4.56, result[1], 0.000001);
                                     assertEquals(7.89, result[2], 0.000001);
                                     
                                     // Test the second row
                                     result = matrix.getRowAsDoubleArray(1);
                                     
                                     // Verify the values match exactly (including decimal parts)
                                     assertEquals(0.123, result[0], 0.000001);
                                     assertEquals(45.678, result[1], 0.000001);
                                     assertEquals(901.2345, result[2], 0.000001);
                                 }

 @Test
                                public void testGetRowAsDoubleArrayReturnsCorrectValues() {
                                    // Setup test data - create a 2x2 matrix with known values
                                    BigDecimal[][] testData = {
                                        {new BigDecimal("1.5"), new BigDecimal("2.5")},
                                        {new BigDecimal("3.5"), new BigDecimal("4.5")}
                                    };
                                    BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                    
                                    // Expected values for row 0
                                    double[] expectedRow0 = {1.5, 2.5};
                                    
                                    // Call method under test
                                    double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                    
                                    // Verify the array contains the correct values
                                    assertArrayEquals("Row 0 values should match matrix data", 
                                                    expectedRow0, actualRow0, 0.0001);
                                    
                                    // Also test another row to be thorough
                                    double[] expectedRow1 = {3.5, 4.5};
                                    double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                                    assertArrayEquals("Row 1 values should match matrix data",
                                                    expectedRow1, actualRow1, 0.0001);
                                }

 @Test
                               public void testGetRowAsDoubleArrayDetectsMutant1() {
                                   // Setup test data with known values
                                   BigDecimal[][] testData = {
                                       {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                       {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                   };
                                   
                                   // Create matrix with test data
                                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                   
                                   // Expected values (exact doubles we expect)
                                   double[] expectedRow0 = {1.0, 2.0, 3.0};
                                   double[] expectedRow1 = {4.0, 5.0, 6.0};
                                   
                                   // Test first row
                                   double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                   assertArrayEquals("Row 0 values should match exactly", expectedRow0, actualRow0, 0.0);
                                   
                                   // Test second row
                                   double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                                   assertArrayEquals("Row 1 values should match exactly", expectedRow1, actualRow1, 0.0);
                               }

 @Test
                              public void testGetRowAsDoubleArrayReturnsNonNullArray() {
                                  // Setup test data - create a 2x2 matrix with known values
                                  BigDecimal[][] testData = {
                                      {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                      {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                  };
                                  BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                  
                                  // Call method under test
                                  double[] result = matrix.getRowAsDoubleArray(0);
                                  
                                  // Verify the result is not null (this would catch the mutant)
                                  assertNotNull("Returned array should not be null", result);
                                  
                                  // Additional assertions to verify correct values
                                  assertEquals(2, result.length);
                                  assertEquals(1.0, result[0], 0.0001);
                                  assertEquals(2.0, result[1], 0.0001);
                              }

 @Test
                                 public void testGetRowAsDoubleArray() {
                                     // Setup test data
                                     BigDecimal[][] testData = {
                                         {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                         {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                     };
                                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                     
                                     // Test valid row
                                     double[] expected = {1.0, 2.0};
                                     double[] actual = matrix.getRowAsDoubleArray(0);
                                     assertArrayEquals(expected, actual, 0.0001);
                                     
                                     // Test another valid row
                                     double[] expected2 = {3.0, 4.0};
                                     double[] actual2 = matrix.getRowAsDoubleArray(1);
                                     assertArrayEquals(expected2, actual2, 0.0001);
                                     
                                     // Test column dimension
                                     assertEquals(2, matrix.getColumnDimension());
                                 }

 @Test(expected = MatrixIndexException.class)
                                 public void testGetRowAsDoubleArrayInvalidRow() {
                                     BigDecimal[][] testData = {{new BigDecimal("1.0")}};
                                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                     
                                     // This should throw MatrixIndexException
                                     matrix.getRowAsDoubleArray(-1);
                                 }

 @Test
                            public void testGetRowAsDoubleArray1() {
                                // Setup test data
                                BigDecimal[][] testData = {
                                    {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                    {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                };
                                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                
                                // Test valid row
                                double[] expectedRow0 = {1.0, 2.0};
                                double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                assertArrayEquals(expectedRow0, actualRow0, 0.0001);
                                
                                double[] expectedRow1 = {3.0, 4.0};
                                double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                                assertArrayEquals(expectedRow1, actualRow1, 0.0001);
                                
                                // Test invalid row (negative)
                                try {
                                    matrix.getRowAsDoubleArray(-1);
                                    fail("Expected MatrixIndexException for negative row");
                                } catch (MatrixIndexException e) {
                                    assertEquals("illegal row argument", e.getMessage());
                                }
                                
                                // Test invalid row (out of bounds)
                                try {
                                    matrix.getRowAsDoubleArray(2);
                                    fail("Expected MatrixIndexException for out-of-bounds row");
                                } catch (MatrixIndexException e) {
                                    assertEquals("illegal row argument", e.getMessage());
                                }
                                
                                // Verify column dimension affects output size
                                BigDecimal[][] singleColumnData = {
                                    {new BigDecimal("1.0")},
                                    {new BigDecimal("2.0")}
                                };
                                BigMatrixImpl singleColumnMatrix = new BigMatrixImpl(singleColumnData);
                                assertEquals(1, singleColumnMatrix.getRowAsDoubleArray(0).length);
                            }

 @Test
                           public void testGetRowAsDoubleArrayReturnsCorrectValues1() {
                               // Setup test data
                               BigDecimal[][] testData = {
                                   {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                   {new BigDecimal("3.0"), new BigDecimal("4.0")}
                               };
                               BigMatrixImpl matrix = new BigMatrixImpl(testData);
                               
                               // Call method under test
                               double[] result = matrix.getRowAsDoubleArray(0);
                               
                               // Verify results
                               assertEquals(2, result.length);
                               assertEquals(1.0, result[0], 0.0001);
                               assertEquals(2.0, result[1], 0.0001);
                               
                               // Test another row
                               result = matrix.getRowAsDoubleArray(1);
                               assertEquals(2, result.length);
                               assertEquals(3.0, result[0], 0.0001);
                               assertEquals(4.0, result[1], 0.0001);
                           }

 @Test
                          public void testGetRowAsDoubleArray_CompleteExecution() {
                              // Setup test data
                              BigDecimal[][] testData = {
                                  {new BigDecimal("1.1"), new BigDecimal("2.2")},
                                  {new BigDecimal("3.3"), new BigDecimal("4.4")}
                              };
                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                              
                              // Test valid row case
                              double[] result = matrix.getRowAsDoubleArray(0);
                              assertNotNull(result);
                              assertEquals(2, result.length);
                              assertEquals(1.1, result[0], 0.0001);
                              assertEquals(2.2, result[1], 0.0001);
                              
                              // Test another valid row
                              result = matrix.getRowAsDoubleArray(1);
                              assertNotNull(result);
                              assertEquals(2, result.length);
                              assertEquals(3.3, result[0], 0.0001);
                              assertEquals(4.4, result[1], 0.0001);
                              
                              // Test invalid row (negative)
                              try {
                                  matrix.getRowAsDoubleArray(-1);
                                  fail("Expected MatrixIndexException");
                              } catch (MatrixIndexException e) {
                                  assertEquals("illegal row argument", e.getMessage());
                              }
                              
                              // Test invalid row (out of bounds)
                              try {
                                  matrix.getRowAsDoubleArray(2);
                                  fail("Expected MatrixIndexException");
                              } catch (MatrixIndexException e) {
                                  assertEquals("illegal row argument", e.getMessage());
                              }
                          }

 @Test
                         public void testOperateThrowsIllegalArgumentException() {
                             // Setup test data that will cause IllegalArgumentException
                             BigDecimal[] invalidVector = null;
                             BigDecimal[][] matrixData = {
                                 {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                 {new BigDecimal("3.0"), new BigDecimal("4.0")}
                             };
                             
                             // Create matrix with test data
                             BigMatrixImpl matrix = new BigMatrixImpl(matrixData);
                             
                             try {
                                 // This should throw IllegalArgumentException
                                 matrix.operate(invalidVector);
                                 fail("Expected IllegalArgumentException to be thrown");
                             } catch (IllegalArgumentException e) {
                                 // Test passes if we get here
                                 assertNotNull(e);
                             } catch (Exception e) {
                                 // Fail if we get any other exception
                                 fail("Expected IllegalArgumentException but got " + e.getClass().getSimpleName());
                             }
                         }

 @Test
                        public void testGetRowAsDoubleArrayWithShorterInputArray() {
                            // Setup test matrix with known dimensions
                            BigDecimal[][] testData = {
                                {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                            };
                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                            
                            // Create input array with length less than column dimension
                            double[] inputArray = new double[2]; // Column dimension is 3
                            
                            try {
                                // This should throw an exception in original code but pass in mutant
                                double[] result = matrix.getRowAsDoubleArray(0);
                                
                                // If we get here in original code, the test should fail
                                // We need to verify the output is correct for the mutant case
                                assertEquals(3, result.length); // Verify correct output length
                                assertEquals(1.0, result[0], 0.0001);
                                assertEquals(2.0, result[1], 0.0001);
                                assertEquals(3.0, result[2], 0.0001);
                                
                                // The test should fail here for original code since exception was expected
                                fail("Expected MatrixIndexException for array length mismatch");
                            } catch (MatrixIndexException e) {
                                // This is expected for original code
                                assertEquals("illegal row argument", e.getMessage());
                            }
                        }

 @Test
                           public void testGetRowAsDoubleArrayValidInput() {
                               // Setup test data
                               BigDecimal[][] testData = {
                                   {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                   {new BigDecimal("3.0"), new BigDecimal("4.0")}
                               };
                               BigMatrixImpl matrix = new BigMatrixImpl(testData);
                               
                               // Call method under test
                               double[] result = matrix.getRowAsDoubleArray(1);
                               
                               // Verify results
                               assertNotNull("Result should not be null", result);
                               assertEquals("Array length should match column dimension", 
                                            2, result.length);
                               assertEquals(3.0, result[0], 0.0001);
                               assertEquals(4.0, result[1], 0.0001);
                           }

 @Test(expected = MatrixIndexException.class)
                           public void testGetRowAsDoubleArrayInvalidRow1() {
                               // Setup test data
                               BigDecimal[][] testData = {
                                   {new BigDecimal("1.0"), new BigDecimal("2.0")}
                               };
                               BigMatrixImpl matrix = new BigMatrixImpl(testData);
                               
                               // This should throw MatrixIndexException
                               matrix.getRowAsDoubleArray(2);
                           }

 @Test
                      public void testGetRowAsDoubleArray_CompleteExecution1() {
                          // Setup test data
                          BigDecimal[][] testData = {
                              {new BigDecimal("1.0"), new BigDecimal("2.0")},
                              {new BigDecimal("3.0"), new BigDecimal("4.0")}
                          };
                          BigMatrixImpl matrix = new BigMatrixImpl(testData);
                          
                          // Test valid row
                          double[] result = matrix.getRowAsDoubleArray(0);
                          
                          // Verify complete execution and correct values
                          assertNotNull(result);
                          assertEquals(2, result.length);
                          assertEquals(1.0, result[0], 0.0001);
                          assertEquals(2.0, result[1], 0.0001);
                          
                          // Test another valid row
                          result = matrix.getRowAsDoubleArray(1);
                          assertNotNull(result);
                          assertEquals(2, result.length);
                          assertEquals(3.0, result[0], 0.0001);
                          assertEquals(4.0, result[1], 0.0001);
                          
                          // Test invalid row (should throw exception)
                          try {
                              matrix.getRowAsDoubleArray(2);
                              fail("Expected MatrixIndexException for invalid row");
                          } catch (MatrixIndexException e) {
                              // Expected behavior
                          }
                      }

 @Test
                         public void testOperateShouldDeclareIllegalArgumentException() {
                             // Setup
                             BigDecimal[] invalidVector = null;
                             BigDecimal[][] testData = {{BigDecimal.ONE, BigDecimal.TEN}};
                             BigMatrixImpl matrix = new BigMatrixImpl(testData);
                             
                             // Expect exception (original behavior declares this)
                             thrown.expect(IllegalArgumentException.class);
                             
                             // Test
                             matrix.operate(invalidVector);
                             
                             // If mutant survives, this test will fail because:
                             // 1. The method no longer declares the exception
                             // 2. But still throws it (runtime behavior unchanged)
                             // 3. Test expects declared exception but mutant doesn't declare it
                         }

 @Test
                         public void testOperateWithValidInput() {
                             // Setup valid test case
                             BigDecimal[] vector = {BigDecimal.ONE};
                             BigDecimal[][] testData = {{BigDecimal.ONE}};
                             BigMatrixImpl matrix = new BigMatrixImpl(testData);
                             
                             // Execute and verify no exception
                             matrix.operate(vector);
                             
                             // This ensures the basic functionality works
                             // while the previous test checks the exception contract
                         }

 @Test
                   public void testGetRowAsDoubleArray_ValidRow_ReturnsCompleteArray() {
                       // Setup test data
                       BigDecimal[][] testData = {
                           {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                           {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                       };
                       
                       // Create a real instance instead of mocking since we can't mock private methods
                       BigMatrixImpl matrix = new BigMatrixImpl(testData);
                       
                       // Execute and verify
                       double[] result = matrix.getRowAsDoubleArray(0);
                       
                       // Assertions to catch the mutant
                       assertEquals(3, result.length); // Verify full array is returned
                       assertEquals(1.0, result[0], 0.0001);
                       assertEquals(2.0, result[1], 0.0001);
                       assertEquals(3.0, result[2], 0.0001);
                       
                       // Verify column dimension was accessed (if needed)
                       // Note: Since we're using a real object now, we can't verify internal calls
                       // Remove this line or find another way to verify the behavior
                       // verify(matrix, times(1)).getColumnDimension();
                   }

 @Test
               public void testGetRowAsDoubleArray2() {
                   // Setup test data
                   BigDecimal[][] testData = {
                       {new BigDecimal("1.0"), new BigDecimal("2.0")},
                       {new BigDecimal("3.0"), new BigDecimal("4.0")}
                   };
                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                   
                   // Test valid row
                   double[] expectedRow0 = {1.0, 2.0};
                   double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                   assertArrayEquals(expectedRow0, actualRow0, 0.0001);
                   
                   double[] expectedRow1 = {3.0, 4.0};
                   double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                   assertArrayEquals(expectedRow1, actualRow1, 0.0001);
                   
                   // Test invalid row (negative)
                   try {
                       matrix.getRowAsDoubleArray(-1);
                       fail("Expected MatrixIndexException for negative row");
                   } catch (MatrixIndexException e) {
                       assertEquals("illegal row argument", e.getMessage());
                   }
                   
                   // Test invalid row (too large)
                   try {
                       matrix.getRowAsDoubleArray(2);
                       fail("Expected MatrixIndexException for row beyond dimension");
                   } catch (MatrixIndexException e) {
                       assertEquals("illegal row argument", e.getMessage());
                   }
                   
                   // Test empty matrix (shouldn't be possible based on constructors)
                   // But included for completeness
                   BigDecimal[][] emptyData = {{}};
                   BigMatrixImpl emptyMatrix = new BigMatrixImpl(emptyData);
                   try {
                       emptyMatrix.getRowAsDoubleArray(0);
                       fail("Expected MatrixIndexException for empty matrix");
                   } catch (MatrixIndexException e) {
                       // Expected
                   }
               }

 @Test
                  public void testGetRowAsDoubleArrayValidRow() {
                      // Setup test matrix with known values
                      BigDecimal[][] testData = {
                          {new BigDecimal("1.5"), new BigDecimal("2.3")},
                          {new BigDecimal("-4.2"), new BigDecimal("0.0")}
                      };
                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                      
                      // Test first row
                      double[] row0 = matrix.getRowAsDoubleArray(0);
                      assertEquals(2, row0.length);
                      assertEquals(1.5, row0[0], 0.0001);
                      assertEquals(2.3, row0[1], 0.0001);
                      
                      // Test second row
                      double[] row1 = matrix.getRowAsDoubleArray(1);
                      assertEquals(2, row1.length);
                      assertEquals(-4.2, row1[0], 0.0001);
                      assertEquals(0.0, row1[1], 0.0001);
                  }

 @Test(expected = MatrixIndexException.class)
                  public void testGetRowAsDoubleArrayInvalidRow2() {
                      BigDecimal[][] testData = {
                          {new BigDecimal("1.0"), new BigDecimal("2.0")}
                      };
                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                      
                      // This should throw MatrixIndexException
                      matrix.getRowAsDoubleArray(-1);
                  }

 @Test(expected = MatrixIndexException.class)
                  public void testGetRowAsDoubleArrayRowOutOfBounds() {
                      BigDecimal[][] testData = {
                          {new BigDecimal("1.0"), new BigDecimal("2.0")}
                      };
                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                      
                      // This should throw MatrixIndexException
                      matrix.getRowAsDoubleArray(1);
                  }

 @Test
                  public void testGetRowAsDoubleArrayWithDifferentPrecision() {
                      BigDecimal[][] testData = {
                          {new BigDecimal("1.23456789"), new BigDecimal("0.00000001")}
                      };
                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                      
                      double[] row = matrix.getRowAsDoubleArray(0);
                      assertEquals(1.23456789, row[0], 0.000000001);
                      assertEquals(0.00000001, row[1], 0.000000001);
                  }

 @Test
                  public void testGetRowAsDoubleArraySingleColumn() {
                      BigDecimal[][] testData = {
                          {new BigDecimal("1.0")},
                          {new BigDecimal("2.0")}
                      };
                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                      
                      double[] row = matrix.getRowAsDoubleArray(1);
                      assertEquals(1, row.length);
                      assertEquals(2.0, row[0], 0.0001);
                  }

 @Test
                 public void testGetRowAsDoubleArray3() {
                     // Setup test data
                     BigDecimal[][] testData = {
                         {new BigDecimal("1.0"), new BigDecimal("2.0")},
                         {new BigDecimal("3.0"), new BigDecimal("4.0")}
                     };
                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                     
                     // Test valid row
                     double[] expected = {1.0, 2.0};
                     double[] actual = matrix.getRowAsDoubleArray(0);
                     assertArrayEquals(expected, actual, 0.0001);
                     
                     // Test another valid row
                     expected = new double[]{3.0, 4.0};
                     actual = matrix.getRowAsDoubleArray(1);
                     assertArrayEquals(expected, actual, 0.0001);
                     
                     // Verify column count matches
                     assertEquals(2, actual.length);
                 }

 @Test(expected = MatrixIndexException.class)
                 public void testGetRowAsDoubleArrayInvalidRow3() {
                     BigDecimal[][] testData = {{new BigDecimal("1.0")}};
                     BigMatrixImpl matrix = new BigMatrixImpl(testData);
                     
                     // This should throw MatrixIndexException
                     matrix.getRowAsDoubleArray(-1);
                 }

 @Test
           public void testGetRowAsDoubleArrayReturnsCorrectArray() {
               // Initialize test matrix with sample data
               double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
               BigMatrixImpl matrix = new BigMatrixImpl(testData);
               
               double[] row0 = matrix.getRowAsDoubleArray(0);
               assertNotNull("Returned array should not be null", row0);
               assertEquals("Array length should match column dimension", 
                            2, row0.length);
               assertArrayEquals("Array values should match matrix row", 
                                new double[]{1.0, 2.0}, row0, 0.0001);
               
               double[] row1 = matrix.getRowAsDoubleArray(1);
               assertNotNull("Returned array should not be null", row1);
               assertEquals("Array length should match column dimension", 
                            2, row1.length);
               assertArrayEquals("Array values should match matrix row", 
                                new double[]{3.0, 4.0}, row1, 0.0001);
           }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
           public void testGetRowAsDoubleArrayThrowsForInvalidRow() {
               BigMatrixImpl matrix = new BigMatrixImpl(new double[][]{{1.0, 2.0}, {3.0, 4.0}});
               matrix.getRowAsDoubleArray(-1); // Should throw ArrayIndexOutOfBoundsException
           }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
           public void testGetRowAsDoubleArrayThrowsForRowOutOfBounds() {
               BigMatrixImpl matrix = new BigMatrixImpl(2, 2); // Create 2x2 matrix (rows 0 and 1)
               matrix.getRowAsDoubleArray(2); // Should throw (only rows 0 and 1 exist)
           }

 @Test
           public void testGetRowAsDoubleArray4() {
               // Setup test matrix with known values
               BigDecimal[][] testData = {
                   {new BigDecimal("1.1"), new BigDecimal("2.2")},
                   {new BigDecimal("3.3"), new BigDecimal("4.4")}
               };
               BigMatrixImpl matrix = new BigMatrixImpl(testData);
               
               // Test valid row access
               double[] row0 = matrix.getRowAsDoubleArray(0);
               assertEquals(2, row0.length);
               assertEquals(1.1, row0[0], 0.0001);
               assertEquals(2.2, row0[1], 0.0001);
               
               double[] row1 = matrix.getRowAsDoubleArray(1);
               assertEquals(2, row1.length);
               assertEquals(3.3, row1[0], 0.0001);
               assertEquals(4.4, row1[1], 0.0001);
               
               // Test array size matches column dimension
               assertEquals(matrix.getColumnDimension(), row0.length);
               assertEquals(matrix.getColumnDimension(), row1.length);
               
               // Test invalid row access
               try {
                   matrix.getRowAsDoubleArray(-1);
                   fail("Expected MatrixIndexException for negative row");
               } catch (MatrixIndexException e) {
                   assertEquals("illegal row argument", e.getMessage());
               }
               
               try {
                   matrix.getRowAsDoubleArray(2);
                   fail("Expected MatrixIndexException for out-of-bounds row");
               } catch (MatrixIndexException e) {
                   assertEquals("illegal row argument", e.getMessage());
               }
               
               // Test with empty matrix (shouldn't be possible based on constructors)
               // Test with very large matrix to ensure no hidden issues
           }

 @Test
           public void testGetRowAsDoubleArrayEdgeCases() {
               // Test with maximum values
               BigDecimal[][] maxValues = {
                   {new BigDecimal(Double.MAX_VALUE), new BigDecimal(-Double.MAX_VALUE)}
               };
               BigMatrixImpl maxMatrix = new BigMatrixImpl(maxValues);
               double[] maxRow = maxMatrix.getRowAsDoubleArray(0);
               assertEquals(Double.MAX_VALUE, maxRow[0], 0.0);
               assertEquals(-Double.MAX_VALUE, maxRow[1], 0.0);
               
               // Test with very small values
               BigDecimal[][] minValues = {
                   {new BigDecimal(Double.MIN_VALUE), new BigDecimal("-0.0")}
               };
               BigMatrixImpl minMatrix = new BigMatrixImpl(minValues);
               double[] minRow = minMatrix.getRowAsDoubleArray(0);
               assertEquals(Double.MIN_VALUE, minRow[0], 0.0);
               assertEquals(-0.0, minRow[1], 0.0);
           }

 @Test
      public void testGetRowAsDoubleArray5() {
          // Setup test data
          BigDecimal[][] testData = {
              {new BigDecimal("1.0"), new BigDecimal("2.0")},
              {new BigDecimal("3.0"), new BigDecimal("4.0")}
          };
          BigMatrixImpl matrix = new BigMatrixImpl(testData);
          
          // Test valid row
          double[] result = matrix.getRowAsDoubleArray(0);
          assertNotNull(result);
          assertEquals(2, result.length);
          assertEquals(1.0, result[0], 0.0001);
          assertEquals(2.0, result[1], 0.0001);
          
          // Test another valid row
          result = matrix.getRowAsDoubleArray(1);
          assertNotNull(result);
          assertEquals(2, result.length);
          assertEquals(3.0, result[0], 0.0001);
          assertEquals(4.0, result[1], 0.0001);
          
          // Test invalid row (negative)
          try {
              matrix.getRowAsDoubleArray(-1);
              fail("Expected MatrixIndexException for negative row");
          } catch (MatrixIndexException e) {
              assertEquals("illegal row argument", e.getMessage());
          }
          
          // Test invalid row (out of bounds)
          try {
              matrix.getRowAsDoubleArray(2);
              fail("Expected MatrixIndexException for out-of-bounds row");
          } catch (MatrixIndexException e) {
              assertEquals("illegal row argument", e.getMessage());
          }
          
          // Verify the complete structure of the returned array
          result = matrix.getRowAsDoubleArray(0);
          assertTrue(result instanceof double[]);
          assertEquals(matrix.getColumnDimension(), result.length);
      }

 @Test
         public void testOperateWithInvalidInputThrowsException() {
             // Setup
             BigDecimal[] invalidVector = null;
             BigDecimal[][] testData = {
                 {new BigDecimal("1.0"), new BigDecimal("2.0")},
                 {new BigDecimal("3.0"), new BigDecimal("4.0")}
             };
             BigMatrixImpl matrix = new BigMatrixImpl(testData);
             
             // Expect exception
             thrown.expect(IllegalArgumentException.class);
             
             // Test - this should throw IllegalArgumentException with original code
             // but mutant version won't declare it
             matrix.operate(invalidVector);
         }

 @Test
         public void testOperateWithSizeMismatchThrowsException() {
             // Setup
             BigDecimal[] wrongSizeVector = {new BigDecimal("1.0")}; // Only 1 element
             BigDecimal[][] testData = {
                 {new BigDecimal("1.0"), new BigDecimal("2.0")},
                 {new BigDecimal("3.0"), new BigDecimal("4.0")}
             };
             BigMatrixImpl matrix = new BigMatrixImpl(testData);
             
             // Expect exception
             thrown.expect(IllegalArgumentException.class);
             
             // Test - vector size doesn't match matrix column dimension
             matrix.operate(wrongSizeVector);
         }

 @Test
    public void testGetRowAsDoubleArrayWithDifferentLengthInput() {
        // Setup test matrix with 2 columns
        BigDecimal[][] testData = {
            {new BigDecimal("1.0"), new BigDecimal("2.0")},
            {new BigDecimal("3.0"), new BigDecimal("4.0")}
        };
        BigMatrixImpl matrix = new BigMatrixImpl(testData);
        
        // Test with correct length input (should work)
        double[] row0 = matrix.getRowAsDoubleArray(0);
        assertEquals(2, row0.length);
        assertEquals(1.0, row0[0], 0.0001);
        assertEquals(2.0, row0[1], 0.0001);
        
        // Test with shorter input (should throw exception in original, but mutant would allow it)
        try {
            double[] shortInput = new double[1];
            // This would fail in original but pass in mutant
            matrix.getRowAsDoubleArray(0);
            fail("Expected MatrixIndexException for input shorter than column dimension");
        } catch (MatrixIndexException e) {
            // Expected behavior
        }
        
        // Test with longer input (both original and mutant should throw)
        try {
            double[] longInput = new double[3];
            matrix.getRowAsDoubleArray(0);
            fail("Expected MatrixIndexException for input longer than column dimension");
        } catch (MatrixIndexException e) {
            // Expected behavior
        }
    }

 @Test
       public void testGetRowAsDoubleArrayWithValidRow() {
           // Setup test data
           BigDecimal[][] testData = {
               {new BigDecimal("1.0"), new BigDecimal("2.0")},
               {new BigDecimal("3.0"), new BigDecimal("4.0")}
           };
           BigMatrixImpl matrix = new BigMatrixImpl(testData);
           
           // Expected output
           double[] expected = {1.0, 2.0};
           
           // Test execution
           double[] result = matrix.getRowAsDoubleArray(0);
           
           // Verification
           assertArrayEquals(expected, result, 0.0001);
       }

 @Test
  public void testGetRowAsDoubleArray6() {
      // Setup test data
      BigDecimal[][] testData = {
          {new BigDecimal("1.0"), new BigDecimal("2.0")},
          {new BigDecimal("3.0"), new BigDecimal("4.0")}
      };
      BigMatrixImpl matrix = new BigMatrixImpl(testData);
      
      // Test valid row
      double[] expectedRow0 = {1.0, 2.0};
      double[] actualRow0 = matrix.getRowAsDoubleArray(0);
      assertArrayEquals(expectedRow0, actualRow0, 0.0001);
      
      double[] expectedRow1 = {3.0, 4.0};
      double[] actualRow1 = matrix.getRowAsDoubleArray(1);
      assertArrayEquals(expectedRow1, actualRow1, 0.0001);
      
      // Test invalid row (negative)
      try {
          matrix.getRowAsDoubleArray(-1);
          fail("Expected MatrixIndexException for negative row");
      } catch (MatrixIndexException e) {
          assertEquals("illegal row argument", e.getMessage());
      }
      
      // Test invalid row (out of bounds)
      try {
          matrix.getRowAsDoubleArray(2);
          fail("Expected MatrixIndexException for out-of-bounds row");
      } catch (MatrixIndexException e) {
          assertEquals("illegal row argument", e.getMessage());
      }
  }

 @Test
 public void testGetRowAsDoubleArray7() {
     // Setup test data
     BigDecimal[][] testData = {
         {new BigDecimal("1.0"), new BigDecimal("2.0")},
         {new BigDecimal("3.0"), new BigDecimal("4.0")}
     };
     BigMatrixImpl matrix = new BigMatrixImpl(testData);
     
     // Test valid row
     double[] result = matrix.getRowAsDoubleArray(0);
     assertNotNull(result);
     assertEquals(2, result.length);
     assertEquals(1.0, result[0], 0.0001);
     assertEquals(2.0, result[1], 0.0001);
     
     // Test another valid row
     result = matrix.getRowAsDoubleArray(1);
     assertNotNull(result);
     assertEquals(2, result.length);
     assertEquals(3.0, result[0], 0.0001);
     assertEquals(4.0, result[1], 0.0001);
     
     // Test invalid row (negative)
     try {
         matrix.getRowAsDoubleArray(-1);
         fail("Expected MatrixIndexException");
     } catch (MatrixIndexException e) {
         assertEquals("illegal row argument", e.getMessage());
     }
     
     // Test invalid row (out of bounds)
     try {
         matrix.getRowAsDoubleArray(2);
         fail("Expected MatrixIndexException");
     } catch (MatrixIndexException e) {
         assertEquals("illegal row argument", e.getMessage());
     }
     
     // Test empty matrix (though constructor prevents this)
     BigDecimal[][] emptyData = {{}};
     try {
         new BigMatrixImpl(emptyData).getRowAsDoubleArray(0);
         fail("Expected IllegalArgumentException");
     } catch (IllegalArgumentException e) {
         // Expected
     }
 }

}
