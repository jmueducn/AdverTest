package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.MathIllegalArgumentException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.ZeroException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.ArithmeticUtils;
 
public class BigFractionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                  public void testDoubleValue_NormalFractions() {
                                                      // Test simple fractions that can be represented exactly in double
                                                      BigFraction half = new BigFraction(1, 2);
                                                      assertEquals(0.5, half.doubleValue(), 0.0);
                                              
                                                      BigFraction third = new BigFraction(1, 3);
                                                      assertEquals(1.0/3.0, third.doubleValue(), 1e-15);
                                              
                                                      BigFraction negative = new BigFraction(-3, 4);
                                                      assertEquals(-0.75, negative.doubleValue(), 0.0);
                                                  }

 @Test
                                                  public void testDoubleValue_WholeNumbers() {
                                                      // Test whole numbers
                                                      BigFraction five = new BigFraction(5);
                                                      assertEquals(5.0, five.doubleValue(), 0.0);
                                              
                                                      BigFraction zero = new BigFraction(0);
                                                      assertEquals(0.0, zero.doubleValue(), 0.0);
                                              
                                                      BigFraction large = new BigFraction(123456789);
                                                      assertEquals(123456789.0, large.doubleValue(), 0.0);
                                                  }

 @Test
                                                  public void testDoubleValue_LargeNumbers() {
                                                      // Test with very large numbers that might need shifting
                                                      BigInteger hugeNum = BigInteger.TEN.pow(100);
                                                      BigInteger hugeDen = BigInteger.TEN.pow(100).add(BigInteger.ONE);
                                                      
                                                      BigFraction hugeFraction = new BigFraction(hugeNum, hugeDen);
                                                      // Should be approximately 1.0, but not exactly due to precision limits
                                                      assertEquals(1.0, hugeFraction.doubleValue(), 1e-15);
                                                  }

 @Test
                                                  public void testDoubleValue_ExtremeValues() {
                                                      // Test with extreme values that would normally overflow
                                                      BigInteger maxLong = BigInteger.valueOf(Long.MAX_VALUE);
                                                      BigFraction maxLongFraction = new BigFraction(maxLong.multiply(maxLong), maxLong);
                                                      assertEquals((double)Long.MAX_VALUE, maxLongFraction.doubleValue(), 1e-15);
                                              
                                                      BigInteger minLong = BigInteger.valueOf(Long.MIN_VALUE);
                                                      BigFraction minLongFraction = new BigFraction(minLong.multiply(minLong), minLong.negate());
                                                      assertEquals((double)Long.MIN_VALUE, minLongFraction.doubleValue(), 1e-15);
                                                  }

 @Test
                                                  public void testDoubleValue_EdgeCases() {
                                                      // Test edge cases
                                                      BigFraction one = new BigFraction(1);
                                                      assertEquals(1.0, one.doubleValue(), 0.0);
                                              
                                                      BigFraction almostOne = new BigFraction(BigInteger.ONE.shiftLeft(53).subtract(BigInteger.ONE), 
                                                                                BigInteger.ONE.shiftLeft(53));
                                                      assertEquals(1.0, almostOne.doubleValue(), 0.0);
                                                  }

 @Test
                                                  public void testDoubleValue_WithStaticConstants() {
                                                      // Test with the class's static constants
                                                      assertEquals(1.0, BigFraction.ONE.doubleValue(), 0.0);
                                                      assertEquals(0.0, BigFraction.ZERO.doubleValue(), 0.0);
                                                      assertEquals(-1.0, BigFraction.MINUS_ONE.doubleValue(), 0.0);
                                                      assertEquals(2.0, BigFraction.TWO.doubleValue(), 0.0);
                                                      assertEquals(0.5, BigFraction.ONE_HALF.doubleValue(), 0.0);
                                                      assertEquals(0.25, BigFraction.ONE_QUARTER.doubleValue(), 0.0);
                                                      assertEquals(1.0/3.0, BigFraction.ONE_THIRD.doubleValue(), 1e-15);
                                                  }

 @Test
                                                  public void testDoubleValue_WithVerySmallNumbers() {
                                                      // Test with very small numbers
                                                      BigInteger tinyNum = BigInteger.ONE;
                                                      BigInteger hugeDen = BigInteger.TEN.pow(100);
                                                      
                                                      BigFraction tinyFraction = new BigFraction(tinyNum, hugeDen);
                                                      assertEquals(0.0, tinyFraction.doubleValue(), 0.0); // Should underflow to 0.0
                                                  }

 @Test
                                                  public void testFloatValue_NormalFractions() {
                                                      // Test simple fractions
                                                      BigFraction half = new BigFraction(1, 2);
                                                      assertEquals(0.5f, half.floatValue(), 0.000001f);
                                                      
                                                      BigFraction quarter = new BigFraction(1, 4);
                                                      assertEquals(0.25f, quarter.floatValue(), 0.000001f);
                                                      
                                                      BigFraction threeQuarters = new BigFraction(3, 4);
                                                      assertEquals(0.75f, threeQuarters.floatValue(), 0.000001f);
                                                      
                                                      // Test negative fractions
                                                      BigFraction negativeHalf = new BigFraction(-1, 2);
                                                      assertEquals(-0.5f, negativeHalf.floatValue(), 0.000001f);
                                                      
                                                      // Test whole numbers
                                                      BigFraction five = new BigFraction(5, 1);
                                                      assertEquals(5.0f, five.floatValue(), 0.000001f);
                                                  }

 @Test
                                                  public void testFloatValue_ZeroNumerator() {
                                                      BigFraction zero = new BigFraction(0, 1);
                                                      assertEquals(0.0f, zero.floatValue(), 0.0f);
                                                      
                                                      BigFraction zeroWithLargeDenominator = new BigFraction(0, 1000000);
                                                      assertEquals(0.0f, zeroWithLargeDenominator.floatValue(), 0.0f);
                                                  }

 @Test
                                                  public void testFloatValue_LargeNumbers() {
                                                      // Test with numbers that would normally overflow float range
                                                      BigInteger hugeNum = BigInteger.TEN.pow(50);
                                                      BigInteger hugeDen = BigInteger.TEN.pow(49);
                                                      
                                                      BigFraction hugeFraction = new BigFraction(hugeNum, hugeDen);
                                                      assertEquals(10.0f, hugeFraction.floatValue(), 0.000001f);
                                                      
                                                      // Test with very large numerator and denominator
                                                      BigInteger veryLargeNum = new BigInteger("123456789012345678901234567890");
                                                      BigInteger veryLargeDen = new BigInteger("987654321098765432109876543210");
                                                      
                                                      BigFraction veryLargeFraction = new BigFraction(veryLargeNum, veryLargeDen);
                                                      // The exact value might vary based on implementation, but should be approximately 0.125
                                                      assertEquals(0.125f, veryLargeFraction.floatValue(), 0.001f);
                                                  }

 @Test
                                                  public void testFloatValue_EdgeCases() {
                                                      // Test with maximum float value
                                                      BigInteger maxFloatNum = BigInteger.valueOf((long) Float.MAX_VALUE);
                                                      BigFraction maxFloatFraction = new BigFraction(maxFloatNum, BigInteger.ONE);
                                                      assertEquals(Float.MAX_VALUE, maxFloatFraction.floatValue(), 0.0f);
                                                      
                                                      // Test with minimum positive float value
                                                      BigInteger minFloatNum = BigInteger.valueOf((long) Float.MIN_VALUE);
                                                      BigFraction minFloatFraction = new BigFraction(minFloatNum, BigInteger.ONE);
                                                      assertEquals(Float.MIN_VALUE, minFloatFraction.floatValue(), 0.0f);
                                                      
                                                      // Test with numbers that would produce NaN without the special handling
                                                      BigInteger extremeNum = BigInteger.valueOf(2).pow(1000);
                                                      BigInteger extremeDen = BigInteger.valueOf(3).pow(1000);
                                                      BigFraction extremeFraction = new BigFraction(extremeNum, extremeDen);
                                                      // Should not be NaN and should return a reasonable float value
                                                      assertFalse(Float.isNaN(extremeFraction.floatValue()));
                                                  }

 @Test
                                                  public void testFloatValue_PredefinedConstants() {
                                                      // Test the predefined constants in the class
                                                      assertEquals(1.0f, BigFraction.ONE.floatValue(), 0.0f);
                                                      assertEquals(0.0f, BigFraction.ZERO.floatValue(), 0.0f);
                                                      assertEquals(-1.0f, BigFraction.MINUS_ONE.floatValue(), 0.0f);
                                                      assertEquals(2.0f, BigFraction.TWO.floatValue(), 0.0f);
                                                      assertEquals(0.5f, BigFraction.ONE_HALF.floatValue(), 0.000001f);
                                                      assertEquals(0.33333333f, BigFraction.ONE_THIRD.floatValue(), 0.000001f);
                                                      assertEquals(0.25f, BigFraction.ONE_QUARTER.floatValue(), 0.000001f);
                                                      assertEquals(0.2f, BigFraction.ONE_FIFTH.floatValue(), 0.000001f);
                                                      assertEquals(0.4f, BigFraction.TWO_FIFTHS.floatValue(), 0.000001f);
                                                      assertEquals(0.6f, BigFraction.THREE_FIFTHS.floatValue(), 0.000001f);
                                                      assertEquals(0.8f, BigFraction.FOUR_FIFTHS.floatValue(), 0.000001f);
                                                  }

 @Test
                                                  public void testFloatValue_DenominatorZero() {
                                                      thrown.expect(ZeroException.class);
                                                      thrown.expectMessage("zero denominator");
                                                      new BigFraction(BigInteger.ONE, BigInteger.ZERO).floatValue();
                                                  }

 @Test(expected = ArithmeticException.class)
                                      public void testDoubleValue_WithDenominatorZero() {
                                          // This should actually be tested in constructor tests since denominator=0 is invalid
                                          new BigFraction(BigInteger.ONE, BigInteger.ZERO);
                                      }

 @Test
                                  public void testFloatValueWithLargeNumbers() {
                                      // Create numbers large enough to cause float overflow
                                      BigInteger hugeNum = BigInteger.valueOf(2).pow(1000);
                                      BigInteger hugeDen = BigInteger.valueOf(3).pow(1000);
                                      
                                      BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                                      
                                      // Original should handle overflow and return finite float
                                      // Mutant would return NaN
                                      float result = fraction.floatValue();
                                      
                                      // Verify result is finite number (not NaN or infinite)
                                      assertFalse("Result should not be NaN", Float.isNaN(result));
                                      assertFalse("Result should not be infinite", Float.isInfinite(result));
                                      
                                      // Additional check that result is within float range
                                      assertTrue("Result should be valid float", 
                                                 Math.abs(result) <= Float.MAX_VALUE);
                                  }

 @Test
                                 public void testFloatValueDoesNotShiftWhenWithinRange() {
                                     // Create a fraction that is safely within float range
                                     BigInteger numerator = BigInteger.valueOf(1);
                                     BigInteger denominator = BigInteger.valueOf(2);
                                     BigFraction fraction = new BigFraction(numerator, denominator);
                                     
                                     // Expected behavior: direct division without shifting
                                     float expected = numerator.floatValue() / denominator.floatValue();
                                     
                                     // Actual result
                                     float actual = fraction.floatValue();
                                     
                                     // Assert they are equal (with delta for float precision)
                                     assertEquals(expected, actual, 0.0001f);
                                     
                                     // Additional check: verify the shifted version would be different
                                     // (this helps confirm the test would catch the mutant)
                                     int shift = Math.max(numerator.bitLength(), denominator.bitLength()) - Float.MAX_EXPONENT;
                                     float shiftedResult = numerator.shiftRight(shift).floatValue() / 
                                                          denominator.shiftRight(shift).floatValue();
                                     assertNotEquals(shiftedResult, actual, 0.0001f);
                                 }

 @Test
                                public void testFloatValueDetectsNaNHandlingMutation() {
                                    // Test case where result would be NaN without shifting
                                    // Using very large numbers that exceed float range
                                    BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
                                    BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
                                    BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                                    
                                    // Original behavior: should detect NaN and apply shift
                                    // Mutant behavior: will skip the shift because of inverted condition
                                    float result = fraction.floatValue();
                                    
                                    // Verify result is not NaN (proves shift happened)
                                    assertFalse("Result should not be NaN after shift adjustment", 
                                               Double.isNaN(result));
                                    
                                    // Test case where result is within float range
                                    BigFraction normalFraction = new BigFraction(1, 2);
                                    float normalResult = normalFraction.floatValue();
                                    
                                    // Original behavior: should not apply shift
                                    // Mutant behavior: will incorrectly apply shift
                                    assertEquals("Normal fraction should not be shifted", 
                                                0.5f, normalResult, 0.0001f);
                                }

 @Test
                                   public void testFloatValueWithNaN() {
                                       // Create a fraction that will produce NaN when converted to float
                                       // Using very large numbers that exceed float range
                                       BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
                                       BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
                                       BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                                       
                                       // The original code would handle this by shifting bits
                                       // The mutant would skip the handling since it's not infinite
                                       float result = fraction.floatValue();
                                       
                                       // Verify the result is finite (proving the NaN case was handled)
                                       assertFalse("Result should be finite (not NaN or Infinite)", 
                                                  Float.isNaN(result) || Float.isInfinite(result));
                                   }

 @Test
                                   public void testFloatValueWithInfinite() {
                                       // Create a fraction that will produce infinite when converted to float
                                       BigInteger hugeNum = new BigInteger("1e1000");
                                       BigInteger smallDen = BigInteger.ONE;
                                       BigFraction fraction = new BigFraction(hugeNum, smallDen);
                                       
                                       // Both original and mutant should return infinite
                                       float result = fraction.floatValue();
                                       assertTrue("Result should be infinite", Float.isInfinite(result));
                                   }

 @Test
                              public void testFloatValueWithExtremeValues() {
                                  // Create a fraction with extremely large numerator and denominator
                                  BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
                                  BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
                                  BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                                  
                                  // Calculate expected value by manually applying the scaling logic
                                  int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                                  float expected = hugeNum.shiftRight(shift).floatValue() / 
                                                  hugeDen.shiftRight(shift).floatValue();
                                  
                                  // The key test - this will fail if the NaN check is mutated to "result != result"
                                  // because with some JVM optimizations, the comparison might behave differently
                                  float actual = fraction.floatValue();
                                  
                                  // Verify the result is not NaN and matches our expected calculation
                                  assertFalse("Result should not be NaN", Float.isNaN(actual));
                                  assertEquals("Scaled value should match", expected, actual, 0.0001f);
                                  
                                  // Additional test with values that would produce infinity if not scaled
                                  BigInteger maxFloat = BigInteger.valueOf((long) Float.MAX_VALUE);
                                  BigFraction overflowFraction = new BigFraction(maxFloat.multiply(BigInteger.TEN), 
                                                                              BigInteger.ONE);
                                  float overflowResult = overflowFraction.floatValue();
                                  assertFalse("Overflow result should not be NaN", Float.isNaN(overflowResult));
                                  assertTrue("Overflow result should be finite", Float.isFinite(overflowResult));
                              }

 @Test
                             public void testFloatValueWithLargeNumbers1() {
                                 // Create numbers large enough to cause NaN in direct float conversion
                                 BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200
                                 BigInteger hugeDen = BigInteger.valueOf(3).pow(200);  // 3^200
                                 
                                 BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                                 
                                 // Calculate expected value by manual right shifting
                                 int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                                 BigInteger shiftedNum = hugeNum.shiftRight(shift);
                                 BigInteger shiftedDen = hugeDen.shiftRight(shift);
                                 float expected = shiftedNum.floatValue() / shiftedDen.floatValue();
                                 
                                 // The mutant would shiftLeft instead, producing a completely different (and wrong) result
                                 float actual = fraction.floatValue();
                                 
                                 // Verify the result is finite and matches our expected calculation
                                 assertFalse("Result should not be NaN", Float.isNaN(actual));
                                 assertFalse("Result should not be infinite", Float.isInfinite(actual));
                                 assertEquals("Float value should match shifted calculation", expected, actual, 0.0001f);
                             }

 @Test
                            public void testFloatValueWithLargeNumbers2() {
                                // Create numbers that are too large for direct float conversion
                                BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200 is way beyond float range
                                BigInteger hugeDen = BigInteger.valueOf(3).pow(150);  // 3^150 is also beyond float range
                                
                                // Create the fraction
                                BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                                
                                // Calculate expected value by scaling both numerator and denominator
                                int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                                float expected = hugeNum.shiftRight(shift).floatValue() / hugeDen.shiftRight(shift).floatValue();
                                
                                // Test the actual value
                                float actual = fraction.floatValue();
                                
                                // Verify the result is finite and correct
                                assertFalse("Result should not be NaN", Float.isNaN(actual));
                                assertFalse("Result should not be infinite", Float.isInfinite(actual));
                                assertEquals("Result should match scaled calculation", expected, actual, 0.0001f);
                            }

 @Test
                               public void testFloatValueWithDifferentBitLengths() {
                                   // Create numbers with significantly different bit lengths
                                   // numerator has more bits than denominator
                                   BigInteger hugeNumerator = new BigInteger("1234567890123456789012345678901234567890");
                                   BigInteger smallDenominator = BigInteger.valueOf(1L);
                                   
                                   BigFraction fraction = new BigFraction(hugeNumerator, smallDenominator);
                                   
                                   // The original would use numerator's bit length (large shift)
                                   // The mutant would use denominator's bit length (small shift)
                                   float result = fraction.floatValue();
                                   
                                   // Verify the result is finite (not NaN or infinite)
                                   assertFalse("Result should be finite", Float.isNaN(result));
                                   assertFalse("Result should not be infinite", Float.isInfinite(result));
                                   
                                   // Verify the result is approximately correct
                                   // We can't check exact value due to floating point imprecision,
                                   // but can check it's in a reasonable range
                                   float expected = hugeNumerator.floatValue() / smallDenominator.floatValue();
                                   assertEquals(expected, result, Math.abs(expected) * 0.0001);
                               }

 @Test
                               public void testFloatValueWithOppositeBitLengths() {
                                   // Now test the opposite case where denominator has more bits
                                   BigInteger smallNumerator = BigInteger.valueOf(1L);
                                   BigInteger hugeDenominator = new BigInteger("1234567890123456789012345678901234567890");
                                   
                                   BigFraction fraction = new BigFraction(smallNumerator, hugeDenominator);
                                   
                                   float result = fraction.floatValue();
                                   
                                   // Verify the result is finite
                                   assertFalse("Result should be finite", Float.isNaN(result));
                                   assertFalse("Result should not be infinite", Float.isInfinite(result));
                                   
                                   // Verify approximate value
                                   float expected = smallNumerator.floatValue() / hugeDenominator.floatValue();
                                   assertEquals(expected, result, Math.abs(expected) * 0.0001);
                               }

 @Test
                              public void testFloatValueWithLargeNumbers3() {
                                  // Create numbers large enough to initially produce NaN when divided as floats
                                  BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200
                                  BigInteger hugeDen = BigInteger.valueOf(3).pow(200);  // 3^200
                                  
                                  // Create BigFraction with these large numbers
                                  BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                                  
                                  // Calculate expected value by manually doing what the original method should do
                                  int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
                                  BigInteger adjustedNum = hugeNum.shiftRight(shift);
                                  BigInteger adjustedDen = hugeDen.shiftRight(shift);
                                  float expected = adjustedNum.floatValue() / adjustedDen.floatValue();
                                  
                                  // Test the actual floatValue()
                                  float actual = fraction.floatValue();
                                  
                                  // The mutant would shiftLeft instead of shiftRight, producing different (likely NaN) results
                                  assertFalse("Result should not be NaN", Float.isNaN(actual));
                                  assertEquals("Float value should match expected adjusted value", expected, actual, 0.0001f);
                              }

 @Test
                             public void testFloatValueWithLargeNumbers4() {
                                 // Create numbers large enough to require shifting (beyond float range)
                                 BigInteger hugeNum = new BigInteger("123456789012345678901234567890");
                                 BigInteger hugeDen = new BigInteger("987654321098765432109876543210");
                                 
                                 BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                                 
                                 // Calculate expected value using double precision
                                 double expected = hugeNum.doubleValue() / hugeDen.doubleValue();
                                 
                                 // Get actual float value
                                 float actual = fraction.floatValue();
                                 
                                 // Verify it's not NaN
                                 assertFalse(Float.isNaN(actual));
                                 
                                 // Verify the result is within reasonable precision of expected
                                 // The mutant using intValue() would fail this due to truncation
                                 assertEquals((float)expected, actual, 0.0001f);
                                 
                                 // Also test with numerator larger than denominator
                                 BigInteger biggerNum = hugeNum.multiply(BigInteger.TEN);
                                 BigFraction biggerFraction = new BigFraction(biggerNum, hugeDen);
                                 
                                 double expected2 = biggerNum.doubleValue() / hugeDen.doubleValue();
                                 float actual2 = biggerFraction.floatValue();
                                 
                                 assertFalse(Float.isNaN(actual2));
                                 assertEquals((float)expected2, actual2, 0.0001f);
                             }

 @Test
                        public void testFloatValueWithDifferentBitLengths1() {
                            // Create numerator and denominator with significantly different bit lengths
                            // Use very large numbers that would normally overflow float representation
                            BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890"); // ~130 bits
                            BigInteger largeDen = new BigInteger("12345678901234567890"); // ~64 bits
                            
                            // Create fraction - this will need scaling down when converting to float
                            BigFraction fraction = new BigFraction(hugeNum, largeDen);
                            
                            // Calculate expected shift using original max() logic
                            int expectedShift = Math.max(hugeNum.bitLength(), largeDen.bitLength()) - Float.MAX_EXPONENT;
                            float expected = hugeNum.shiftRight(expectedShift).floatValue() / 
                                             largeDen.shiftRight(expectedShift).floatValue();
                            
                            // Test the actual conversion
                            float actual = fraction.floatValue();
                            
                            // Verify result is finite (not NaN or infinite)
                            assertFalse("Result should be finite", Float.isInfinite(actual));
                            assertFalse("Result should not be NaN", Float.isNaN(actual));
                            
                            // Verify the value is approximately what we expect
                            assertEquals(expected, actual, 0.0001f);
                            
                            // Additional check - with original max() logic, the shift should be based on numerator's bit length
                            // With mutant min() logic, it would use denominator's bit length which is insufficient
                            // So mutant would likely still return NaN
                        }

 @Test
                       public void testFloatValueDoesNotNeedShift() {
                           // Create a fraction that can be represented exactly as float
                           BigInteger numerator = BigInteger.valueOf(1);
                           BigInteger denominator = BigInteger.valueOf(2);
                           BigFraction fraction = new BigFraction(numerator, denominator);
                           
                           // Expected exact value (0.5f)
                           float expected = 0.5f;
                           
                           // Actual value from method
                           float actual = fraction.floatValue();
                           
                           // With original code, should get exact value
                           assertEquals(expected, actual, 0.0f);
                           
                           // With mutated code (if(true)), would get shifted value which may differ
                           // So this test would fail for mutated code
                           // We can also verify no shift was needed by checking bitLengths
                           assertTrue(numerator.bitLength() <= Float.MAX_EXPONENT);
                           assertTrue(denominator.bitLength() <= Float.MAX_EXPONENT);
                       }

 @Test
                      public void testFloatValueWithExtremeValues1() {
                          // Create numerator and denominator that are too large for float representation
                          BigInteger hugeNum = new BigInteger("1234567890123456789012345678901234567890");
                          BigInteger hugeDen = new BigInteger("9876543210987654321098765432109876543210");
                          
                          BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                          
                          // The division should result in NaN due to overflow
                          float result = fraction.floatValue();
                          
                          // This assertion will catch the mutant because:
                          // - Original code (Double.isNaN) will correctly detect NaN and perform the shift
                          // - Mutant code (result != result) might fail to detect NaN in some cases
                          assertFalse("Result should not be NaN after adjustment", Float.isNaN(result));
                          
                          // Additional check to ensure we got a valid float value
                          assertTrue("Result should be finite", Float.isFinite(result));
                      }

 @Test
                     public void testFloatValueWithDifferentBitLengths2() {
                         // Create numerator and denominator with significantly different bit lengths
                         // Numerator is 2^1000 (very large)
                         BigInteger numerator = BigInteger.valueOf(2).pow(1000);
                         // Denominator is 2^10 (much smaller)
                         BigInteger denominator = BigInteger.valueOf(2).pow(10);
                         
                         BigFraction fraction = new BigFraction(numerator, denominator);
                         
                         // The direct division would result in NaN, so the method should use shift
                         float result = fraction.floatValue();
                         
                         // Verify the result is finite (not NaN or infinite)
                         assertFalse("Result should be finite", Float.isNaN(result));
                         assertFalse("Result should not be infinite", Float.isInfinite(result));
                         
                         // Verify the result is approximately correct (2^990)
                         // Using relative tolerance due to floating point precision
                         float expected = (float) Math.pow(2, 990);
                         float tolerance = expected * 0.0001f; // 0.01% tolerance
                         assertEquals("Result should be approximately 2^990", 
                                     expected, result, tolerance);
                     }

 @Test
                    public void testFloatValueWithLargeNumbers5() {
                        // Create numbers that will overflow float initially
                        BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200
                        BigInteger hugeDen = BigInteger.valueOf(3).pow(100);  // 3^100
                        
                        BigFraction fraction = new BigFraction(hugeNum, hugeDen);
                        
                        // Original should handle by shifting right and return finite value
                        // Mutant would shift left making numbers even larger and likely remain NaN/infinite
                        float result = fraction.floatValue();
                        
                        // Verify result is finite and correct order of magnitude
                        assertFalse("Result should not be NaN", Float.isNaN(result));
                        assertFalse("Result should not be infinite", Float.isInfinite(result));
                        
                        // Verify it's approximately (2/3)^100 * 2^100
                        // Exact value hard to compute but should be positive and finite
                        assertTrue("Result should be positive", result > 0);
                        assertTrue("Result should be less than 1", result < 1);
                    }

 @Test
          public void testFloatValueWithLargeNumbers6() {
              // Create numbers large enough to trigger the shift case
              BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200
              BigInteger hugeDen = BigInteger.valueOf(3).pow(100);  // 3^100
              
              BigFraction fraction = new BigFraction(hugeNum, hugeDen);
              
              // Calculate expected value using doubleValue() as in original
              int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
              float expected = (float)(hugeNum.shiftRight(shift).doubleValue() / 
                              hugeDen.shiftRight(shift).doubleValue());
              
              // Get actual value from method
              float actual = fraction.floatValue();
              
              // Verify the result matches expected calculation
              assertEquals(expected, actual, 0.0001f);
              
              // Additional check that values are different from intValue() version
              float mutantVersion = (float)(hugeNum.shiftRight(shift).intValue() / 
                                  (float)hugeDen.shiftRight(shift).intValue());
              assertNotEquals(mutantVersion, actual, 0.0001f);
          }

 @Test
          public void testFloatValueWithDifferentBitLengths3() {
              // Create numbers with significantly different bit lengths
              // 2^1000 is a very large number (301 digits)
              BigInteger hugeNum = BigInteger.valueOf(2).pow(1000);
              // 2^10 is a small number in comparison
              BigInteger smallDen = BigInteger.valueOf(2).pow(10);
              
              BigFraction fraction = new BigFraction(hugeNum, smallDen);
              
              // The original code would shift right by (1000 - Float.MAX_EXPONENT)
              // The mutant would shift right by (10 - Float.MAX_EXPONENT) which is insufficient
              float result = fraction.floatValue();
              
              // Verify the result is finite (not NaN or infinite)
              assertFalse("Result should not be NaN", Float.isNaN(result));
              assertFalse("Result should not be infinite", Float.isInfinite(result));
              
              // Verify the result is approximately correct
              // Expected value is (2^1000)/(2^10) = 2^990, but scaled down
              // We'll check it's significantly larger than Float.MAX_VALUE to ensure proper scaling
              assertTrue("Result should be properly scaled", result > Float.MAX_VALUE / 1000);
          }

 @Test
     public void testFloatValueWithLargeNumbers7() {
         // Create numbers large enough to cause float overflow
         BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200
         BigInteger hugeDen = BigInteger.valueOf(3).pow(200);  // 3^200
         
         BigFraction fraction = new BigFraction(hugeNum, hugeDen);
         
         // Calculate expected value using double precision
         int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
         double expected = hugeNum.shiftRight(shift).doubleValue() / 
                          hugeDen.shiftRight(shift).doubleValue();
         
         // Get actual float value
         float actual = fraction.floatValue();
         
         // Verify the actual float value matches what we'd get with double precision calculation
         // Using delta of 0.0001 to account for float precision limitations
         assertEquals((float)expected, actual, 0.0001f);
         
         // Additional check - verify the result isn't NaN or infinite
         assertFalse(Float.isNaN(actual));
         assertFalse(Float.isInfinite(actual));
     }

 @Test
    public void testFloatValueWithLargeNumbers8() {
        // Create numbers large enough to require shifting (beyond float range)
        BigInteger hugeNum = BigInteger.valueOf(2).pow(Float.MAX_EXPONENT + 10);
        BigInteger hugeDen = BigInteger.valueOf(3).pow(Float.MAX_EXPONENT + 5);
        
        BigFraction fraction = new BigFraction(hugeNum, hugeDen);
        
        // Calculate expected shift
        int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
        
        // Calculate what the result should be with correct shifting
        BigInteger expectedNum = hugeNum.shiftRight(shift);
        BigInteger expectedDen = hugeDen.shiftRight(shift);
        float expected = expectedNum.floatValue() / expectedDen.floatValue();
        
        // Compare with actual result
        float actual = fraction.floatValue();
        
        // The mutant would shift one extra bit, making the result different
        assertEquals(expected, actual, 0.0001f);
        
        // Additional assertion to verify the shift didn't go too far
        assertFalse(Float.isNaN(actual));
    }

 @Test
   public void testFloatValueWithDifferentBitLengths4() {
       // Create numerator with very large bit length (e.g., 2^1000)
       BigInteger hugeNum = BigInteger.valueOf(2).pow(1000);
       // Create denominator with small bit length (e.g., 1)
       BigInteger smallDen = BigInteger.ONE;
       
       BigFraction fraction = new BigFraction(hugeNum, smallDen);
       
       // Original behavior: Should return finite float after proper scaling
       // Mutant behavior: May return NaN due to insufficient scaling
       float result = fraction.floatValue();
       
       // Verify result is finite (not NaN or infinite)
       assertFalse("Result should be finite", Float.isNaN(result));
       assertFalse("Result should not be infinite", Float.isInfinite(result));
       
       // Verify the value is approximately correct (2^1000 / 1 = 2^1000)
       // Though we can't represent 2^1000 exactly as float, we can check it's very large
       assertTrue("Result should be very large", result > Float.MAX_VALUE / 2);
   }

 @Test
  public void testFloatValueWithLargeNumbers9() {
      // Create numbers large enough to need scaling down
      BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200
      BigInteger hugeDen = BigInteger.valueOf(3).pow(100);  // 3^100
      
      BigFraction fraction = new BigFraction(hugeNum, hugeDen);
      
      // Calculate expected value by manual scaling
      int shift = Math.max(hugeNum.bitLength(), hugeDen.bitLength()) - Float.MAX_EXPONENT;
      BigInteger scaledNum = hugeNum.shiftRight(shift);
      BigInteger scaledDen = hugeDen.shiftRight(shift);
      float expected = scaledNum.floatValue() / scaledDen.floatValue();
      
      // The test will fail with the mutant because shiftLeft would make numbers larger
      assertEquals(expected, fraction.floatValue(), 0.0001f);
      
      // Additional check to ensure we're not getting NaN/Infinity
      assertFalse(Float.isNaN(fraction.floatValue()));
      assertFalse(Float.isInfinite(fraction.floatValue()));
  }

 @Test
     public void testFloatValueWithLargeNumbers10() {
         // Create numbers that are too large for direct float conversion
         BigInteger hugeNum = BigInteger.valueOf(2).pow(200);  // 2^200 is way beyond float range
         BigInteger hugeDen = BigInteger.valueOf(3).pow(200);  // 3^200 is similarly large
         
         BigFraction fraction = new BigFraction(hugeNum, hugeDen);
         
         // The original code should handle this by shifting, resulting in a finite float
         // The mutant will fail to shift and likely return Infinity or NaN
         float result = fraction.floatValue();
         
         // Verify the result is finite and within float range
         assertFalse("Result should not be NaN", Float.isNaN(result));
         assertFalse("Result should not be infinite", Float.isInfinite(result));
         
         // Verify the result is approximately correct (2^200 / 3^200 = (2/3)^200)
         // After shifting, it should be (2/3)^(200-shift)
         // We can't predict exact value due to shifting, but it should be very small
         assertTrue("Result should be very small positive number", 
                    result > 0 && result < Float.MIN_VALUE * 1000);
     }

}
