package gentest.org.apache.commons.math.geometry.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.geometry.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class Vector3DTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                     public void testCrossProduct_StandardVectors() {
                                         Vector3D v1 = new Vector3D(1, 0, 0);  // X-axis
                                         Vector3D v2 = new Vector3D(0, 1, 0);  // Y-axis
                                         Vector3D result = Vector3D.crossProduct(v1, v2);
                                         
                                         // X cross Y should be Z
                                         assertEquals(0, result.getX(), MathUtils.EPSILON);
                                         assertEquals(0, result.getY(), MathUtils.EPSILON);
                                         assertEquals(1, result.getZ(), MathUtils.EPSILON);
                                     }

 @Test
                                     public void testCrossProduct_AntiCommutative() {
                                         Vector3D v1 = new Vector3D(1, 2, 3);
                                         Vector3D v2 = new Vector3D(4, 5, 6);
                                         Vector3D result1 = Vector3D.crossProduct(v1, v2);
                                         Vector3D result2 = Vector3D.crossProduct(v2, v1);
                                         
                                         // Cross product should be anti-commutative
                                         assertEquals(-result1.getX(), result2.getX(), MathUtils.EPSILON);
                                         assertEquals(-result1.getY(), result2.getY(), MathUtils.EPSILON);
                                         assertEquals(-result1.getZ(), result2.getZ(), MathUtils.EPSILON);
                                     }

 @Test
                                     public void testCrossProduct_ParallelVectors() {
                                         Vector3D v1 = new Vector3D(1, 2, 3);
                                         Vector3D v2 = new Vector3D(2, 4, 6);  // Parallel to v1
                                         Vector3D result = Vector3D.crossProduct(v1, v2);
                                         
                                         // Cross product of parallel vectors should be zero
                                         assertEquals(Vector3D.ZERO, result);
                                     }

 @Test
                                     public void testCrossProduct_VerySmallVectors() {
                                         Vector3D v1 = new Vector3D(1e-100, 2e-100, 3e-100);
                                         Vector3D v2 = new Vector3D(4e-100, 5e-100, 6e-100);
                                         Vector3D result = Vector3D.crossProduct(v1, v2);
                                         
                                         // Should handle very small vectors without returning zero
                                         assertNotEquals(Vector3D.ZERO, result);
                                         assertEquals(-3e-200, result.getX(), 1e-215);
                                         assertEquals(6e-200, result.getY(), 1e-215);
                                         assertEquals(-3e-200, result.getZ(), 1e-215);
                                     }

 @Test
                                     public void testCrossProduct_OneZeroVector() {
                                         Vector3D v1 = new Vector3D(1, 2, 3);
                                         Vector3D v2 = new Vector3D(0, 0, 0);
                                         Vector3D result = Vector3D.crossProduct(v1, v2);
                                         
                                         // Cross product with zero vector should be zero
                                         assertEquals(Vector3D.ZERO, result);
                                     }

 @Test
                                     public void testCrossProduct_OrthogonalVectors() {
                                         Vector3D v1 = new Vector3D(1, 1, 0);
                                         Vector3D v2 = new Vector3D(-1, 1, 0);
                                         Vector3D result = Vector3D.crossProduct(v1, v2);
                                         
                                         // Orthogonal vectors in XY plane should give Z vector
                                         assertEquals(0, result.getX(), MathUtils.EPSILON);
                                         assertEquals(0, result.getY(), MathUtils.EPSILON);
                                         assertEquals(2, result.getZ(), MathUtils.EPSILON);
                                     }

 @Test
                                     public void testCrossProduct_DifferentMagnitudes() {
                                         Vector3D v1 = new Vector3D(1, 0, 0);
                                         Vector3D v2 = new Vector3D(0, 1e100, 0);
                                         Vector3D result = Vector3D.crossProduct(v1, v2);
                                         
                                         // Should handle very different magnitudes
                                         assertEquals(0, result.getX(), MathUtils.EPSILON);
                                         assertEquals(0, result.getY(), MathUtils.EPSILON);
                                         assertEquals(1e100, result.getZ(), MathUtils.EPSILON);
                                     }

 @Test
                                     public void testCrossProduct_ProductBelowSafeMin() {
                                         Vector3D v1 = new Vector3D(Double.MIN_VALUE, 0, 0);
                                         Vector3D v2 = new Vector3D(0, Double.MIN_VALUE, 0);
                                         Vector3D result = Vector3D.crossProduct(v1, v2);
                                         
                                         // When product of norms is below SAFE_MIN, should return ZERO
                                         assertEquals(Vector3D.ZERO, result);
                                     }

 @Test
                             public void testCrossProduct_UsingMock() {
                                 // Mock vectors with specific behaviors
                                 Vector3D v1 = mock(Vector3D.class);
                                 Vector3D v2 = mock(Vector3D.class);
                                 
                                 when(v1.getNormSq()).thenReturn(1.0);
                                 when(v2.getNormSq()).thenReturn(1.0);
                                 when(v1.getX()).thenReturn(1.0);
                                 when(v1.getY()).thenReturn(0.0);
                                 when(v1.getZ()).thenReturn(0.0);
                                 when(v2.getX()).thenReturn(0.0);
                                 when(v2.getY()).thenReturn(1.0);
                                 when(v2.getZ()).thenReturn(0.0);
                                 
                                 Vector3D result = Vector3D.crossProduct(v1, v2);
                                 
                                 // Verify interactions
                                 verify(v1).getNormSq();
                                 verify(v2).getNormSq();
                                 
                                 // Verify result
                                 assertEquals(0, result.getX(), MathUtils.EPSILON);
                                 assertEquals(0, result.getY(), MathUtils.EPSILON);
                                 assertEquals(1, result.getZ(), MathUtils.EPSILON);
                             }

 @Test
                         public void testCrossProductDetectsDivisionToMultiplicationMutant() {
                             // Create two vectors that will produce different results with division vs multiplication
                             Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
                             Vector3D v2 = new Vector3D(4.0, 5.0, 6.0);
                             
                             // Calculate expected cross product manually (using standard cross product formula)
                             double expectedX = v1.getY() * v2.getZ() - v1.getZ() * v2.getY();
                             double expectedY = v1.getZ() * v2.getX() - v1.getX() * v2.getZ();
                             double expectedZ = v1.getX() * v2.getY() - v1.getY() * v2.getX();
                             Vector3D expected = new Vector3D(expectedX, expectedY, expectedZ);
                             
                             // Call the method under test
                             Vector3D actual = Vector3D.crossProduct(v1, v2);
                             
                             // Verify the result matches expected cross product
                             assertEquals(expected.getX(), actual.getX(), 1e-15);
                             assertEquals(expected.getY(), actual.getY(), 1e-15);
                             assertEquals(expected.getZ(), actual.getZ(), 1e-15);
                             
                             // Additional verification - check that the ratio calculation would be significantly different
                             // if multiplication was used instead of division
                             double n1 = v1.getNormSq();
                             double n2 = v2.getNormSq();
                             int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
                             double x1 = FastMath.scalb(v1.getX(), -deltaExp);
                             double y1 = FastMath.scalb(v1.getY(), -deltaExp);
                             double z1 = FastMath.scalb(v1.getZ(), -deltaExp);
                             double x2 = FastMath.scalb(v2.getX(), deltaExp);
                             double y2 = FastMath.scalb(v2.getY(), deltaExp);
                             double z2 = FastMath.scalb(v2.getZ(), deltaExp);
                             
                             double dotProduct = x1*x2 + y1*y2 + z1*z2;
                             double scalingFactor = FastMath.scalb(n2, 2*deltaExp);
                             double ratioDivision = dotProduct / scalingFactor;
                             double ratioMultiplication = dotProduct * scalingFactor;
                             
                             // Verify that multiplication would produce significantly different ratio
                             assertTrue(Math.abs(ratioDivision - ratioMultiplication) > 1e-10);
                         }

 @Test
                        public void testCrossProductWithDifferentMagnitudeVectors() {
                            // Create two vectors with significantly different magnitudes
                            Vector3D v1 = new Vector3D(1.0e10, 2.0e10, 3.0e10); // large magnitude
                            Vector3D v2 = new Vector3D(4.0e-10, 5.0e-10, 6.0e-10); // small magnitude
                            
                            // Calculate expected cross product manually
                            double expectedX = (2.0e10 * 6.0e-10) - (3.0e10 * 5.0e-10);
                            double expectedY = (3.0e10 * 4.0e-10) - (1.0e10 * 6.0e-10);
                            double expectedZ = (1.0e10 * 5.0e-10) - (2.0e10 * 4.0e-10);
                            Vector3D expected = new Vector3D(expectedX, expectedY, expectedZ);
                            
                            // Get actual cross product
                            Vector3D actual = Vector3D.crossProduct(v1, v2);
                            
                            // Verify components with tolerance for floating point precision
                            assertEquals(expected.getX(), actual.getX(), 1.0e-10);
                            assertEquals(expected.getY(), actual.getY(), 1.0e-10);
                            assertEquals(expected.getZ(), actual.getZ(), 1.0e-10);
                        }

 @Test
                       public void testCrossProductDetectsMutatedRatioCalculation() {
                           // Create two vectors where dot product != sum of components
                           Vector3D v1 = new Vector3D(1.0, -2.0, 3.0);
                           Vector3D v2 = new Vector3D(-4.0, 5.0, -6.0);
                           
                           // Calculate expected cross product using correct formula
                           // Manual calculation of cross product:
                           // i( (-2)*(-6) - 3*5 ) - j( 1*(-6) - 3*(-4) ) + k( 1*5 - (-2)*(-4) )
                           // = i(12 - 15) - j(-6 + 12) + k(5 - 8)
                           // = -3i -6j -3k
                           Vector3D expected = new Vector3D(-3.0, -6.0, -3.0);
                           
                           // Calculate actual cross product
                           Vector3D actual = Vector3D.crossProduct(v1, v2);
                           
                           // Verify components match expected values
                           assertEquals(expected.getX(), actual.getX(), 1.0e-15);
                           assertEquals(expected.getY(), actual.getY(), 1.0e-15);
                           assertEquals(expected.getZ(), actual.getZ(), 1.0e-15);
                           
                           // Also verify the vectors are not equal to ZERO (edge case check)
                           assertNotEquals(Vector3D.ZERO, actual);
                       }

 @Test
                          public void testCrossProductDetectsRhoPrecisionMutation() {
                              // Create two vectors where the dot product ratio requires full 8-bit precision
                              Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
                              Vector3D v2 = new Vector3D(0.33333333, 0.66666666, 0.99999999);
                              
                              // Calculate expected cross product using original method (manually computed)
                              // With 8-bit rho precision, the expected result would be more accurate
                              Vector3D expected = new Vector3D(
                                  2.0*0.99999999 - 3.0*0.66666666,
                                  3.0*0.33333333 - 1.0*0.99999999,
                                  1.0*0.66666666 - 2.0*0.33333333
                              );
                              
                              // Calculate actual cross product
                              Vector3D actual = Vector3D.crossProduct(v1, v2);
                              
                              // Verify the result is precise enough
                              // The delta here is set to detect the loss of precision from the mutation
                              assertEquals(expected.getX(), actual.getX(), 1e-10);
                              assertEquals(expected.getY(), actual.getY(), 1e-10);
                              assertEquals(expected.getZ(), actual.getZ(), 1e-10);
                              
                              // For the mutated version (128 instead of 256), the error would be larger than 1e-10
                          }

 @Test
                    public void testCrossProductDetectsRhoMutation() {
                        // Create two vectors where the dot product ratio will be exactly between two 8-bit steps
                        // Choose values that will make ratio = 1.5/256 = 0.005859375
                        Vector3D v1 = new Vector3D(1.0, 1.0, 1.0);
                        Vector3D v2 = new Vector3D(1.0, 1.0, 1.0 + Math.ulp(1.0));
                        
                        // Calculate expected ratio
                        double n1 = v1.getNormSq();
                        double n2 = v2.getNormSq();
                        int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
                        double x1 = FastMath.scalb(v1.getX(), -deltaExp);
                        double y1 = FastMath.scalb(v1.getY(), -deltaExp);
                        double z1 = FastMath.scalb(v1.getZ(), -deltaExp);
                        double x2 = FastMath.scalb(v2.getX(), deltaExp);
                        double y2 = FastMath.scalb(v2.getY(), deltaExp);
                        double z2 = FastMath.scalb(v2.getZ(), deltaExp);
                        double ratio = (x1 * x2 + y1 * y2 + z1 * z2) / FastMath.scalb(n2, 2 * deltaExp);
                        
                        // With original code (divide by 256), rho would be 0.00390625 (1/256)
                        // With mutant (divide by 128), rho would be 0.0078125 (1/128)
                        // This difference should propagate to the cross product result
                        
                        Vector3D originalResult = Vector3D.crossProduct(v1, v2);
                        
                        // Now test with values that would show the difference
                        // Create a vector where the difference would be most noticeable
                        Vector3D v3 = new Vector3D(1.0, 0.0, 0.0);
                        Vector3D v4 = new Vector3D(0.0, 1.0, 0.0);
                        
                        Vector3D expected = new Vector3D(0.0, 0.0, 1.0); // Standard cross product of unit vectors
                        
                        // The mutation would cause a different result due to changed rho calculation
                        Vector3D actual = Vector3D.crossProduct(v3, v4);
                        
                        // Verify the cross product is calculated correctly (would fail with mutant)
                        assertEquals(expected.getX(), actual.getX(), 1.0e-15);
                        assertEquals(expected.getY(), actual.getY(), 1.0e-15);
                        assertEquals(expected.getZ(), actual.getZ(), 1.0e-15);
                        
                        // Additional test with non-orthogonal vectors where rounding difference matters more
                        Vector3D v5 = new Vector3D(1.0, 0.5, 0.25);
                        Vector3D v6 = new Vector3D(0.5, 1.0, 0.125);
                        Vector3D result2 = Vector3D.crossProduct(v5, v6);
                        
                        // Calculate expected cross product manually
                        double ex = 0.5 * 0.125 - 0.25 * 1.0;
                        double ey = 0.25 * 0.5 - 1.0 * 0.125;
                        double ez = 1.0 * 1.0 - 0.5 * 0.5;
                        Vector3D expected2 = new Vector3D(ex, ey, ez);
                        
                        assertEquals(expected2.getX(), result2.getX(), 1.0e-15);
                        assertEquals(expected2.getY(), result2.getY(), 1.0e-15);
                        assertEquals(expected2.getZ(), result2.getZ(), 1.0e-15);
                    }

 @Test
               public void testCrossProductRhoRounding() {
                   // Mock version:
                   Vector3D mockV1 = mock(Vector3D.class);
                   when(mockV1.getNormSq()).thenReturn(1.0);  // n1 = 1
                   when(mockV1.getX()).thenReturn(1.0);
                   when(mockV1.getY()).thenReturn(1.0);
                   when(mockV1.getZ()).thenReturn(1.0);
                   
                   Vector3D mockV2 = mock(Vector3D.class);
                   when(mockV2.getNormSq()).thenReturn(1.0);  // n2 = 1
                   when(mockV2.getX()).thenReturn(-0.5/256.0/3.0);
                   when(mockV2.getY()).thenReturn(-0.5/256.0/3.0);
                   when(mockV2.getZ()).thenReturn(-0.5/256.0/3.0);
                   
                   // Calculate expected with original behavior (rho = 0)
                   double x3 = 1.0 - 0 * (-0.5/256.0/3.0);
                   double y3 = 1.0 - 0 * (-0.5/256.0/3.0);
                   double z3 = 1.0 - 0 * (-0.5/256.0/3.0);
                   double x2 = -0.5/256.0/3.0;
                   double y2 = -0.5/256.0/3.0;
                   double z2 = -0.5/256.0/3.0;
                   Vector3D expectedResult = new Vector3D(
                       y3 * z2 - z3 * y2,
                       z3 * x2 - x3 * z2,
                       x3 * y2 - y3 * x2
                   );
                   
                   Vector3D result = Vector3D.crossProduct(mockV1, mockV2);
                   
                   assertEquals(expectedResult.getX(), result.getX(), 1.0e-15);
                   assertEquals(expectedResult.getY(), result.getY(), 1.0e-15);
                   assertEquals(expectedResult.getZ(), result.getZ(), 1.0e-15);
               }

 @Test
          public void testCrossProductRoundingBehavior() {
              // Create vectors where the dot product will result in a ratio that's exactly halfway between two 1/256 increments
              // We want ratio * 256 = 127.5 (exactly halfway between 127 and 128)
              // So ratio should be 127.5/256 = 0.498046875
              
              // Let's create vectors that will produce this exact ratio
              // We need (x1*x2 + y1*y2 + z1*z2)/n2 = 0.498046875
              // Let's make n2 = 1 (for simplicity) by using a unit vector
              Vector3D v2 = new Vector3D(1, 0, 0); // norm = 1
              
              // Now we need x1*1 + y1*0 + z1*0 = 0.498046875
              // So x1 = 0.498046875, y1 and z1 can be anything
              // Let's make y1 and z1 non-zero to ensure cross product is non-zero
              Vector3D v1 = new Vector3D(0.498046875, 1, 1);
              
              // Calculate expected result with original rounding (rint)
              double expectedRho = FastMath.rint(256 * 0.498046875) / 256; // should be 0.5 (128/256)
              Vector3D temp = new Vector3D(
                  1 - expectedRho * 0,
                  0 - expectedRho * 1,
                  0 - expectedRho * 1
              );
              Vector3D expected = Vector3D.crossProduct(temp, v2);
              
              // Calculate actual result
              Vector3D actual = Vector3D.crossProduct(v1, v2);
              
              // Verify the results are different when using ceil vs rint
              // With ceil, rho would be 0.50390625 (129/256) instead of 0.5 (128/256)
              // So we should see a difference in the cross product components
              assertEquals(expected.getX(), actual.getX(), 1e-15);
              assertEquals(expected.getY(), actual.getY(), 1e-15);
              assertEquals(expected.getZ(), actual.getZ(), 1e-15);
          }

 @Test
          public void testCrossProductDetectsMutatedSecondComponent() {
              // Create two vectors that will produce a cross product with non-zero components
              // Particularly focusing on the second component
              Vector3D v1 = new Vector3D(1, 0, 0);  // Along x-axis
              Vector3D v2 = new Vector3D(0, 0, 1);  // Along z-axis
              
              // Expected cross product should be along negative y-axis (0, -1, 0)
              Vector3D expected = new Vector3D(0, -1, 0);
              Vector3D actual = Vector3D.crossProduct(v1, v2);
              
              // Verify all components
              assertEquals("X component incorrect", expected.getX(), actual.getX(), 1e-15);
              assertEquals("Y component incorrect (mutant not detected)", expected.getY(), actual.getY(), 1e-15);
              assertEquals("Z component incorrect", expected.getZ(), actual.getZ(), 1e-15);
              
              // Specifically check the second component which was mutated
              // The mutant would produce (0, 1, 0) instead of (0, -1, 0)
              assertTrue("Mutant not detected - second component sign is wrong",
                         Math.signum(expected.getY()) == Math.signum(actual.getY()));
          }

 @Test
         public void testCrossProductDetectsMutant() {
             // Create two simple orthogonal vectors where we can easily compute the expected cross product
             Vector3D v1 = new Vector3D(1, 0, 0); // Along x-axis
             Vector3D v2 = new Vector3D(0, 1, 0); // Along y-axis
             
             // Expected cross product should be along z-axis (0, 0, 1)
             Vector3D expected = new Vector3D(0, 0, 1);
             
             // Calculate actual cross product
             Vector3D actual = Vector3D.crossProduct(v1, v2);
             
             // Verify all three components
             assertEquals("X component of cross product is incorrect", 
                 expected.getX(), actual.getX(), 1e-15);
             assertEquals("Y component of cross product is incorrect", 
                 expected.getY(), actual.getY(), 1e-15);
             assertEquals("Z component of cross product is incorrect", 
                 expected.getZ(), actual.getZ(), 1e-15);
             
             // Also verify with another test case where first component is non-zero
             Vector3D v3 = new Vector3D(0, 1, 0);
             Vector3D v4 = new Vector3D(0, 0, 1);
             Vector3D expected2 = new Vector3D(1, 0, 0);
             Vector3D actual2 = Vector3D.crossProduct(v3, v4);
             
             assertEquals("X component of second cross product is incorrect", 
                 expected2.getX(), actual2.getX(), 1e-15);
             assertEquals("Y component of second cross product is incorrect", 
                 expected2.getY(), actual2.getY(), 1e-15);
             assertEquals("Z component of second cross product is incorrect", 
                 expected2.getZ(), actual2.getZ(), 1e-15);
         }

 @Test
        public void testCrossProductDetectsSignMutation() {
            // Create two vectors where y and z components contribute significantly to dot product
            Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
            Vector3D v2 = new Vector3D(4.0, 5.0, 6.0);
            
            // Calculate expected cross product using original formula
            // Manually compute expected values based on original algorithm
            double n1 = v1.getNormSq(); // 1 + 4 + 9 = 14
            double n2 = v2.getNormSq(); // 16 + 25 + 36 = 77
            
            // Skip the SAFE_MIN check since n1*n2 is large enough
            int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
            double x1 = FastMath.scalb(1.0, -deltaExp);
            double y1 = FastMath.scalb(2.0, -deltaExp);
            double z1 = FastMath.scalb(3.0, -deltaExp);
            double x2 = FastMath.scalb(4.0, deltaExp);
            double y2 = FastMath.scalb(5.0, deltaExp);
            double z2 = FastMath.scalb(6.0, deltaExp);
            
            // Original ratio calculation
            double originalRatio = (x1 * x2 + y1 * y2 + z1 * z2) / FastMath.scalb(n2, 2 * deltaExp);
            double mutatedRatio = (x1 * x2 - y1 * y2 - z1 * z2) / FastMath.scalb(n2, 2 * deltaExp);
            
            // Verify the mutation would produce different ratio
            assertNotEquals("Mutation should change ratio value", originalRatio, mutatedRatio, 1e-10);
            
            // Calculate expected cross product
            double rho = FastMath.rint(256 * originalRatio) / 256;
            double x3 = x1 - rho * x2;
            double y3 = y1 - rho * y2;
            double z3 = z1 - rho * z2;
            Vector3D expected = new Vector3D(
                y3 * z2 - z3 * y2,
                z3 * x2 - x3 * z2,
                x3 * y2 - y3 * x2
            );
            
            // Test the actual cross product
            Vector3D actual = Vector3D.crossProduct(v1, v2);
            
            // Verify all components match
            assertEquals("X component of cross product incorrect", expected.getX(), actual.getX(), 1e-10);
            assertEquals("Y component of cross product incorrect", expected.getY(), actual.getY(), 1e-10);
            assertEquals("Z component of cross product incorrect", expected.getZ(), actual.getZ(), 1e-10);
        }

 @Test
   public void testCrossProductWithLargeMagnitudeDifference() {
       // Create two vectors with significantly different magnitudes
       // Large vector
       Vector3D v1 = new Vector3D(1e100, 2e100, 3e100);
       // Small vector
       Vector3D v2 = new Vector3D(1e-100, 2e-100, 3e-100);
       
       // Calculate expected cross product manually
       // Original scaling would be: (1e100 * 1e-100) = 1, but mutant would scale differently
       double expectedX = (2e100 * 3e-100) - (3e100 * 2e-100); // Should be 0
       double expectedY = (3e100 * 1e-100) - (1e100 * 3e-100); // Should be 0
       double expectedZ = (1e100 * 2e-100) - (2e100 * 1e-100); // Should be 0
       Vector3D expected = new Vector3D(expectedX, expectedY, expectedZ);
       
       // The mutant will compute incorrect scaling and return non-zero vector
       Vector3D result = Vector3D.crossProduct(v1, v2);
       
       // Verify the result is zero vector (as parallel vectors should have zero cross product)
       assertEquals(0.0, result.getX(), 1e-15);
       assertEquals(0.0, result.getY(), 1e-15);
       assertEquals(0.0, result.getZ(), 1e-15);
       
       // Additional check against expected value
       assertEquals(expected.getX(), result.getX(), 1e-15);
       assertEquals(expected.getY(), result.getY(), 1e-15);
       assertEquals(expected.getZ(), result.getZ(), 1e-15);
   }

 @Test
      public void testCrossProductDetectsRhoMutation1() {
          // Create two vectors where the ratio (v1.v2 / v2.v2) is 1/513
          // This is chosen because:
          // 256 * (1/513) ≈ 0.499027 (would round to 0)
          // 512 * (1/513) ≈ 0.998054 (would round to 1)
          // This will show the difference in behavior
          
          Vector3D v1 = new Vector3D(1, 1, 0);
          Vector3D v2 = new Vector3D(513, 0, 0);
          
          // Original behavior: rho would be 0 (since 256*(1/513) rounds to 0)
          // Mutated behavior: rho would be 1/256 (since 512*(1/513) rounds to 1)
          
          Vector3D result = Vector3D.crossProduct(v1, v2);
          
          // Expected result with original code:
          // With rho = 0, x3 = x1 = 1/(513^(1/4)), y3 = y1 = 1/(513^(1/4)), z3 = z1 = 0
          // Cross product would be (0, 0, -y3*513^(1/4)) = (0, 0, -1)
          Vector3D expected = new Vector3D(0, 0, -1);
          
          // With mutated code:
          // rho = 1/256, x3 = x1 - rho*x2 ≈ 0, y3 = y1 ≈ 1/(513^(1/4)), z3 = 0
          // Cross product would be different
          
          // Verify the result matches expected from original code
          assertEquals(expected.getX(), result.getX(), 1e-15);
          assertEquals(expected.getY(), result.getY(), 1e-15);
          assertEquals(expected.getZ(), result.getZ(), 1e-15);
      }

 @Test
 public void testCrossProductWithNonBinaryRatio() {
     // Create vectors where the dot product ratio isn't exactly representable in 8 bits
     Vector3D v1 = new Vector3D(1.0, 1.0, 1.0);
     Vector3D v2 = new Vector3D(1.0, 1.0, 1.0001);
     
     // Calculate expected ratio manually
     double n1 = v1.getNormSq(); // 1+1+1 = 3
     double n2 = v2.getNormSq(); // 1+1+1.00020001 ≈ 3.0002
     int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
     double x1 = FastMath.scalb(1.0, -deltaExp);
     double y1 = FastMath.scalb(1.0, -deltaExp);
     double z1 = FastMath.scalb(1.0, -deltaExp);
     double x2 = FastMath.scalb(1.0, deltaExp);
     double y2 = FastMath.scalb(1.0, deltaExp);
     double z2 = FastMath.scalb(1.0001, deltaExp);
     double scaledN2 = FastMath.scalb(n2, 2 * deltaExp);
     double ratio = (x1*x2 + y1*y2 + z1*z2) / scaledN2;
     
     // Verify the rho calculation
     double expectedRho = FastMath.rint(256 * ratio) / 256;
     
     // Calculate actual cross product
     Vector3D result = Vector3D.crossProduct(v1, v2);
     
     // Verify the result isn't zero (vectors aren't parallel)
     assertNotEquals(Vector3D.ZERO, result);
     
     // Verify the direction is perpendicular to both vectors
     assertEquals(0.0, Vector3D.dotProduct(result, v1), 1e-15);
     assertEquals(0.0, Vector3D.dotProduct(result, v2), 1e-15);
     
     // For thoroughness, we could calculate expected cross product manually
     // and compare with result, but the above checks are sufficient to verify
     // the rho calculation is being used properly in the cross product
 }

}
