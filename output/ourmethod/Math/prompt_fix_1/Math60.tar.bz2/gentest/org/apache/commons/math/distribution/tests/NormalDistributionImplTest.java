package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.special.Erf;
import org.apache.commons.math.util.FastMath;
 
public class NormalDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test(expected = IllegalArgumentException.class)
                                                  public void testConstructor_NegativeStandardDeviation() {
                                                      new NormalDistributionImpl(0, -1);
                                                  }

    @Test
                                              public void testCumulativeProbability_ExtremeLeft() throws Exception {
                                                  NormalDistributionImpl dist = new NormalDistributionImpl(100, 2);
                                                  double result = dist.cumulativeProbability(20); // 100 - 20 = 80 > 40*2
                                                  assertEquals(0.0, result, 0.0001);
                                              }

    @Test
                                              public void testCumulativeProbability_ExtremeRight() throws MathException {
                                                  NormalDistributionImpl dist = new NormalDistributionImpl(100, 2);
                                                  double result = dist.cumulativeProbability(180); // 180 - 100 = 80 > 40*2
                                                  assertEquals(1.0, result, 0.0001);
                                              }

    @Test
                                              public void testCumulativeProbability_AtMean() {
                                                  try {
                                                      NormalDistributionImpl dist = new NormalDistributionImpl(100, 2);
                                                      double result = dist.cumulativeProbability(100);
                                                      assertEquals(0.5, result, 0.0001);
                                                  } catch (MathException e) {
                                                      fail("Unexpected MathException: " + e.getMessage());
                                                  }
                                              }

    @Test
                                              public void testCumulativeProbability_WithinOneSD() throws MathException {
                                                  NormalDistributionImpl dist = new NormalDistributionImpl(0, 1);
                                                  double result = dist.cumulativeProbability(1);
                                                  assertEquals(0.8413, result, 0.0001);
                                              }

    @Test
                                              public void testCumulativeProbability_WithinTwoSD() throws Exception {
                                                  NormalDistributionImpl dist = new NormalDistributionImpl(0, 1);
                                                  double result = dist.cumulativeProbability(2);
                                                  assertEquals(0.9772, result, 0.0001);
                                              }

    @Test
                                              public void testCumulativeProbability_BoundaryBelow40SD() {
                                                  try {
                                                      NormalDistributionImpl dist = new NormalDistributionImpl(0, 1);
                                                      double x = 39.999; // Just below 40 SDs
                                                      double result = dist.cumulativeProbability(x);
                                                      // Should use Erf calculation, not return 1.0
                                                      assertTrue(result > 0.9999 && result < 1.0);
                                                  } catch (MathException e) {
                                                      fail("Unexpected MathException: " + e.getMessage());
                                                  }
                                              }

    @Test
                                              public void testCumulativeProbability_BoundaryAbove40SD() throws org.apache.commons.math.MathException {
                                                  NormalDistributionImpl dist = new NormalDistributionImpl(0, 1);
                                                  double x = 40.001; // Just above 40 SDs
                                                  double result = dist.cumulativeProbability(x);
                                                  assertEquals(1.0, result, 0.0001);
                                              }

    @Test
                                              public void testCumulativeProbability_NonStandardParameters() throws Exception {
                                                  NormalDistributionImpl dist = new NormalDistributionImpl(50, 10);
                                                  // Test value at mean + 1 SD (should be same as standard normal at +1 SD)
                                                  double result = dist.cumulativeProbability(60);
                                                  assertEquals(0.8413, result, 0.0001);
                                              }

    @Test
                                              public void testCumulativeProbability_SmallStandardDeviation() throws MathException {
                                                  NormalDistributionImpl dist = new NormalDistributionImpl(0, 0.001);
                                                  // Even small deviations should be considered extreme with tiny SD
                                                  double result = dist.cumulativeProbability(0.041); // 41 SDs
                                                  assertEquals(1.0, result, 0.0001);
                                              }

    @Test
                                         public void testCumulativeProbabilityAt40SigmaBoundary() throws MathException {
                                             // Setup - create distribution with mean=0, stddev=1 for simplicity
                                             double mean = 0.0;
                                             double stddev = 1.0;
                                             NormalDistributionImpl dist = new NormalDistributionImpl(mean, stddev);
                                             
                                             // Test exactly at +40σ boundary
                                             double x = mean + 40 * stddev;
                                             double result = dist.cumulativeProbability(x);
                                             
                                             // Verify it didn't return 1.0 directly (would happen with mutant)
                                             // Instead should calculate using erf()
                                             double expected = 0.5 * (1.0 + Erf.erf(40 / Math.sqrt(2.0)));
                                             assertEquals(expected, result, 1e-10);
                                             
                                             // Test exactly at -40σ boundary
                                             x = mean - 40 * stddev;
                                             result = dist.cumulativeProbability(x);
                                             
                                             // Verify it didn't return 0.0 directly (would happen with mutant)
                                             expected = 0.5 * (1.0 + Erf.erf(-40 / Math.sqrt(2.0)));
                                             assertEquals(expected, result, 1e-10);
                                         }

    @Test
                            public void testCumulativeProbabilityAtBoundary() throws MathException {
                                // Setup - create distribution with mean 0 and std dev 1 for simplicity
                                double mean = 0;
                                double stdDev = 1;
                                NormalDistributionImpl dist = new NormalDistributionImpl(mean, stdDev);
                                
                                // Test value between 30σ and 40σ (35σ in this case)
                                double x = 35 * stdDev;  // 35 standard deviations above mean
                                
                                // Calculate expected value using original logic (should use Erf)
                                double dev = x - mean;
                                double expected = 0.5 * (1.0 + Erf.erf(dev / (stdDev * FastMath.sqrt(2.0))));
                                
                                // Actual value from method
                                double actual = dist.cumulativeProbability(x);
                                
                                // Assertion - mutant would return 1.0 instead of calculated value
                                assertEquals("Value at 35σ should use Erf calculation", expected, actual, 1e-10);
                                
                                // Also test negative side
                                x = -35 * stdDev;
                                dev = x - mean;
                                expected = 0.5 * (1.0 + Erf.erf(dev / (stdDev * FastMath.sqrt(2.0))));
                                actual = dist.cumulativeProbability(x);
                                assertEquals("Value at -35σ should use Erf calculation", expected, actual, 1e-10);
                            }

    @Test
                       public void testCumulativeProbabilityDetectsMutant() throws MathException {
                           // Create distribution with standard deviation = 2
                           // So 40*σ = 80
                           double mean = 0;
                           double stdDev = 2;
                           NormalDistributionImpl dist = new NormalDistributionImpl(mean, stdDev);
                           
                           // Test value where:
                           // Original: |dev| (50) < 40*σ (80) → calculates using Erf
                           // Mutant: |dev| (50) > 40 → returns 0 or 1
                           double x = 50; // dev = 50
                           double result = dist.cumulativeProbability(x);
                           
                           // Verify it's not 0 or 1 (which mutant would return)
                           assertTrue("Result should be between 0 and 1", result > 0 && result < 1);
                           
                           // Additional verification - compare with expected calculation
                           double expected = 0.5 * (1.0 + Erf.erf(50 / (stdDev * Math.sqrt(2.0))));
                           assertEquals(expected, result, 1e-10);
                       }

    @Test
                  public void testCumulativeProbabilityAtMeanWithLargeDeviation() throws Exception {
                      // Set up a distribution with very small standard deviation
                      // so that 0 deviation (x=mean) is >40 standard deviations
                      double mean = 10.0;
                      double tinySD = 0.0001; // 40*SD = 0.004, dev=0 < 0.004 would be false
                      NormalDistributionImpl dist = new NormalDistributionImpl(mean, tinySD);
                      
                      // Test at x = mean (dev = 0)
                      double x = mean;
                      
                      // Original should calculate using erf (returns ~0.5)
                      // Mutant would return 0.0 due to dev <= 0 condition
                      double result = dist.cumulativeProbability(x);
                      
                      // Verify it used erf calculation (not extreme value handling)
                      assertEquals(0.5, result, 0.0001);
                  }

    @Test
             public void testCumulativeProbabilityForExtremeNegativeValue() throws MathException {
                 // Setup - create distribution with mean=0, stddev=1
                 NormalDistributionImpl dist = new NormalDistributionImpl(0, 1);
                 
                 // Test value that's more than 40 std devs below mean
                 double extremeNegative = -41; // 41 std devs below mean (dev = -41)
                 
                 // Should return 0.0 for extreme negative values
                 // Mutant would return 1.0 instead
                 double result = dist.cumulativeProbability(extremeNegative);
                 
                 // Assert
                 assertEquals("Extreme negative value should return 0.0", 
                              0.0, result, 0.0001);
             }

    @Test
    public void testCumulativeProbabilityForExtremeValues() throws MathException {
        // Create a distribution with mean=0 and sd=0.25 (sqrt=0.5)
        // Thresholds:
        // Original: 40*0.25=10
        // Mutated: 40*0.5=20
        NormalDistributionImpl dist = new NormalDistributionImpl(0, 0.25);
        
        // Choose x=15 (|15-0|=15)
        // Original: 15 > 10 → returns 1
        // Mutated: 15 > 20 → false → uses Erf
        double result = dist.cumulativeProbability(15);
        
        // Original should return 1, mutant would return something else
        assertEquals(1.0, result, 0.0001);
        
        // Also test negative side
        result = dist.cumulativeProbability(-15);
        assertEquals(0.0, result, 0.0001);
    }


}
