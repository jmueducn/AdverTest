package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                public void testAdd_TypicalComplexNumbers() {
                    Complex c1 = new Complex(3.0, 4.0);
                    Complex c2 = new Complex(2.0, -1.0);
                    Complex result = c1.add(c2);
                    
                    assertEquals(5.0, result.getReal(), 0.0001);
                    assertEquals(3.0, result.getImaginary(), 0.0001);
                }

 @Test
                public void testAdd_WithZero() {
                    Complex c1 = new Complex(1.5, 2.5);
                    Complex c2 = Complex.ZERO;
                    Complex result = c1.add(c2);
                    
                    assertEquals(1.5, result.getReal(), 0.0001);
                    assertEquals(2.5, result.getImaginary(), 0.0001);
                }

 @Test
                public void testAdd_WithNaN() {
                    Complex c1 = new Complex(Double.NaN, 4.0);
                    Complex c2 = new Complex(2.0, 3.0);
                    Complex result = c1.add(c2);
                    
                    assertTrue(result.isNaN());
                }

 @Test
                public void testAdd_BothNaN() {
                    Complex c1 = new Complex(Double.NaN, Double.NaN);
                    Complex c2 = new Complex(Double.NaN, 3.0);
                    Complex result = c1.add(c2);
                    
                    assertTrue(result.isNaN());
                }

 @Test
                public void testAdd_WithInfinity() {
                    Complex c1 = new Complex(Double.POSITIVE_INFINITY, 4.0);
                    Complex c2 = new Complex(2.0, 3.0);
                    Complex result = c1.add(c2);
                    
                    assertTrue(result.isInfinite());
                }

 @Test
                public void testAdd_NullParameter() {
                    Complex c1 = new Complex(1.0, 2.0);
                    
                    thrown.expect(NullPointerException.class);
                    c1.add(null);
                }

 @Test
                public void testAdd_CommutativeProperty() {
                    Complex c1 = new Complex(1.5, 2.5);
                    Complex c2 = new Complex(3.5, 4.5);
                    
                    Complex result1 = c1.add(c2);
                    Complex result2 = c2.add(c1);
                    
                    assertEquals(result1.getReal(), result2.getReal(), 0.0001);
                    assertEquals(result1.getImaginary(), result2.getImaginary(), 0.0001);
                }

 @Test
                public void testAdd_WithNegativeNumbers() {
                    Complex c1 = new Complex(-3.0, -4.0);
                    Complex c2 = new Complex(-2.0, 1.0);
                    Complex result = c1.add(c2);
                    
                    assertEquals(-5.0, result.getReal(), 0.0001);
                    assertEquals(-3.0, result.getImaginary(), 0.0001);
                }

 @Test
                public void testAdd_WithStaticConstants() {
                    Complex c1 = Complex.ONE;
                    Complex c2 = Complex.I;
                    Complex result = c1.add(c2);
                    
                    assertEquals(1.0, result.getReal(), 0.0001);
                    assertEquals(1.0, result.getImaginary(), 0.0001);
                }

 @Test
                public void testAdd_UsingMock() {
                    Complex c1 = new Complex(2.0, 3.0);
                    Complex mockComplex = mock(Complex.class);
                    
                    when(mockComplex.getReal()).thenReturn(1.5);
                    when(mockComplex.getImaginary()).thenReturn(2.5);
                    when(mockComplex.isNaN()).thenReturn(false);
                    
                    Complex result = c1.add(mockComplex);
                    
                    assertEquals(3.5, result.getReal(), 0.0001);
                    assertEquals(5.5, result.getImaginary(), 0.0001);
                    
                    verify(mockComplex).getReal();
                    verify(mockComplex).getImaginary();
                    verify(mockComplex).isNaN();
                }

 @Test
        public void testAddWithNaN() {
            // Case 1: this is NaN, rhs is not NaN
            Complex nanComplex = new Complex(Double.NaN, 1.0);
            Complex normalComplex = new Complex(1.0, 1.0);
            assertEquals(Complex.NaN, nanComplex.add(normalComplex));
            
            // Case 2: this is not NaN, rhs is NaN
            assertEquals(Complex.NaN, normalComplex.add(nanComplex));
            
            // Case 3: both are NaN
            assertEquals(Complex.NaN, nanComplex.add(nanComplex));
            
            // Case 4: neither is NaN (normal case)
            Complex result = normalComplex.add(new Complex(2.0, 3.0));
            assertEquals(3.0, result.getReal(), 0.0001);
            assertEquals(4.0, result.getImaginary(), 0.0001);
        }

 @Test
       public void testAddWithNaNShouldReturnNaN() {
           // Case 1: Current complex is NaN
           Complex nanComplex1 = new Complex(Double.NaN, 1.0);
           Complex normalComplex1 = new Complex(2.0, 3.0);
           Complex result1 = nanComplex1.add(normalComplex1);
           assertSame("Adding NaN complex should return NaN", Complex.NaN, result1);
           
           // Case 2: Argument complex is NaN
           Complex normalComplex2 = new Complex(2.0, 3.0);
           Complex nanComplex2 = new Complex(1.0, Double.NaN);
           Complex result2 = normalComplex2.add(nanComplex2);
           assertSame("Adding to NaN complex should return NaN", Complex.NaN, result2);
           
           // Case 3: Both complexes are NaN
           Complex nanComplex3 = new Complex(Double.NaN, Double.NaN);
           Complex result3 = nanComplex1.add(nanComplex3);
           assertSame("Adding two NaN complexes should return NaN", Complex.NaN, result3);
       }

 @Test
     public void testAddWithShortCircuitOrBehavior() {
         // Create a complex number that is NaN
         Complex nanComplex = new Complex(Double.NaN, Double.NaN);
         assertTrue(nanComplex.isNaN());
         
         // Create a mock rhs that would throw exception if isNaN is accessed
         Complex rhs = mock(Complex.class);
         when(rhs.getReal()).thenReturn(1.0); // normal behavior for other methods
         when(rhs.getImaginary()).thenReturn(1.0);
         when(rhs.isNaN()).thenThrow(new RuntimeException("Should not be evaluated"));
         
         // Test that the addition works with short-circuit OR
         // Should return NaN without evaluating rhs.isNaN
         Complex result = nanComplex.add(rhs);
         assertSame(Complex.NaN, result);
         
         // Verify rhs.isNaN() was never accessed (for original code)
         verify(rhs, never()).isNaN();
     }

 @Test
     public void testAdd_CurrentObjectIsNaN() {
         // Test case where current object is NaN
         Complex nanComplex = new Complex(Double.NaN, Double.NaN);
         Complex normalComplex = new Complex(1.0, 2.0);
         
         // Should return NaN when current object is NaN (even if rhs is normal)
         Complex result = nanComplex.add(normalComplex);
         assertTrue(result.isNaN());
     }

 @Test
     public void testAdd_RhsIsNaN() {
         // Test case where rhs is NaN (current object is normal)
         Complex normalComplex = new Complex(1.0, 2.0);
         Complex nanComplex = new Complex(Double.NaN, Double.NaN);
         
         // Should return NaN when rhs is NaN (this is what the mutant misses)
         Complex result = normalComplex.add(nanComplex);
         assertTrue(result.isNaN());
     }

}
