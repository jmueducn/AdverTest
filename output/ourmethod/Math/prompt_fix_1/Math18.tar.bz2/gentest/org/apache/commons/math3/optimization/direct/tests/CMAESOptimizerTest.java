package gentest.org.apache.commons.math3.optimization.direct.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.direct.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathUnsupportedOperationException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.MultivariateOptimizer;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.optimization.SimpleValueChecker;
import org.apache.commons.math3.random.MersenneTwister;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.util.MathArrays;
 
public class CMAESOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                public void testIsFeasible_NullBoundaries() throws Exception {
                                                                                                                                                    // Test that when no boundaries are set (null boundaries), any point is considered feasible
                                                                                                                                                    int lambda = 4;
                                                                                                                                                    double[] inputSigma = {0.3};
                                                                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer(lambda, inputSigma);
                                                                                                                                                    
                                                                                                                                                    // Get the isFeasible method via reflection
                                                                                                                                                    Method isFeasibleMethod = CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                                                                                                    isFeasibleMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test with various points
                                                                                                                                                    double[] x1 = {1.0, 2.0, 3.0};
                                                                                                                                                    double[] x2 = {-1.0, -2.0, -3.0};
                                                                                                                                                    double[] x3 = {0.0, 0.0, 0.0};
                                                                                                                                                    
                                                                                                                                                    assertTrue((Boolean) isFeasibleMethod.invoke(optimizer, x1));
                                                                                                                                                    assertTrue((Boolean) isFeasibleMethod.invoke(optimizer, x2));
                                                                                                                                                    assertTrue((Boolean) isFeasibleMethod.invoke(optimizer, x3));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testIsFeasible_DimensionMismatch() {
                                                                                                                                                    // Create optimizer instance
                                                                                                                                                    CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                                    
                                                                                                                                                    // Create test input with wrong dimension
                                                                                                                                                    double[] x = {1.0};
                                                                                                                                                    
                                                                                                                                                    // To properly test dimension mismatch, we need to set up boundaries first
                                                                                                                                                    // Since we can't set boundaries directly, we'll use reflection to set them
                                                                                                                                                    try {
                                                                                                                                                        // Use reflection to set the dimension expectation
                                                                                                                                                        Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                                        boundariesField.setAccessible(true);
                                                                                                                                                        boundariesField.set(optimizer, new double[][]{new double[2], new double[2]});
                                                                                                                                                        
                                                                                                                                                        // Now test with mismatched dimension
                                                                                                                                                        try {
                                                                                                                                                            // Access isFeasible method through reflection if direct access fails
                                                                                                                                                            Method isFeasibleMethod = CMAESOptimizer.class.getMethod("isFeasible", double[].class);
                                                                                                                                                            isFeasibleMethod.invoke(optimizer, x);
                                                                                                                                                            fail("Expected DimensionMismatchException not thrown");
                                                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                                                            if (e.getCause() instanceof DimensionMismatchException) {
                                                                                                                                                                // Expected behavior
                                                                                                                                                            } else {
                                                                                                                                                                fail("Unexpected exception: " + e.getCause().getMessage());
                                                                                                                                                            }
                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                            fail("Unexpected exception: " + e.getMessage());
                                                                                                                                                        }
                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                        fail("Failed to set up test using reflection: " + e.getMessage());
                                                                                                                                                    }
                                                                                                                                                }

    @Test
                                                                                                                            public void testEncode_ZeroRangeBoundaries() {
                                                                                                                                // Setup
                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                                                                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
                                                                                                                                double[][] boundaries = {{1.0, 1.0}, {1.0, 2.0}}; // Zero range for first dimension
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    // Get the boundaries field using reflection
                                                                                                                                    java.lang.reflect.Field boundariesField = 
                                                                                                                                        optimizer.getClass().getDeclaredField("boundaries");
                                                                                                                                    boundariesField.setAccessible(true);
                                                                                                                                    boundariesField.set(optimizer, boundaries);
                                                                                                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                    org.junit.Assert.fail("Failed to set boundaries field via reflection: " + e.getMessage());
                                                                                                                                }
                                                                                                                                
                                                                                                                                double[] input = {1.0, 2.0};
                                                                                                                                
                                                                                                                                // Expect division by zero for first element
                                                                                                                                try {
                                                                                                                                    org.junit.Assert.fail("Expected ArithmeticException");
                                                                                                                                } catch (ArithmeticException e) {
                                                                                                                                    // Expected exception
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testEncode_MismatchedLengths() {
                                                                                                                                // Setup
                                                                                                                                org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                                                                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
                                                                                                                                double[][] boundaries = {{0.0, 0.0}, {1.0, 1.0}}; // 2D boundaries
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    // Get the boundaries field using reflection
                                                                                                                                    java.lang.reflect.Field boundariesField = 
                                                                                                                                        org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                    boundariesField.setAccessible(true);
                                                                                                                                    boundariesField.set(optimizer, boundaries);
                                                                                                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                    org.junit.Assert.fail("Failed to set boundaries field via reflection");
                                                                                                                                }
                                                                                                                                
                                                                                                                                double[] input = {1.0, 2.0, 3.0}; // 3D input
                                                                                                                                
                                                                                                                                // Expect array index out of bounds
                                                                                                                                exception.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                            }

    @Test
                                                                                                                            public void testDecode_ZeroRangeBoundaries() throws Exception {
                                                                                                                                // Setup
                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                
                                                                                                                                // Use reflection to set private boundaries field
                                                                                                                                Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                boundariesField.setAccessible(true);
                                                                                                                                boundariesField.set(optimizer, new double[][]{{2.0, 2.0}, {3.0, 3.0}}); // ranges: 0, 0
                                                                                                                                
                                                                                                                                // Define input and expected output
                                                                                                                                double[] input = {0.5, 0.8};
                                                                                                                                double[] expected = {2.0, 3.0}; // When range is 0, it should return the lower bound
                                                                                                                                
                                                                                                                                // Execute
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                            }

    @Test
                                                                                                                            public void testDecode_InputLengthMismatch() {
                                                                                                                                // Setup
                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                                                                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
                                                                                                                                
                                                                                                                                // Use reflection to set private boundaries field
                                                                                                                                try {
                                                                                                                                    java.lang.reflect.Field boundariesField = 
                                                                                                                                        org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                    boundariesField.setAccessible(true);
                                                                                                                                    boundariesField.set(optimizer, new double[][]{{1.0, 2.0}, {3.0, 4.0}}); // 2 elements
                                                                                                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                    org.junit.Assert.fail("Failed to set boundaries field via reflection");
                                                                                                                                }
                                                                                                                                
                                                                                                                                double[] input = {1.0, 2.0, 3.0}; // 3 elements
                                                                                                                                
                                                                                                                                // Expect exception
                                                                                                                                try {
                                                                                                                                    org.junit.Assert.fail("Expected ArrayIndexOutOfBoundsException");
                                                                                                                                } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                    // Expected exception
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testIsFeasible_BelowLowerBoundary() {
                                                                                                                                // Create mock optimizer
                                                                                                                                CMAESOptimizer optimizer = mock(CMAESOptimizer.class);
                                                                                                                                
                                                                                                                                // Setup test data
                                                                                                                                double[][] boundaries = {{1.0, 1.0, 1.0}, {10.0, 10.0, 10.0}};
                                                                                                                                double[] x = {0.5, 2.0, 3.0};
                                                                                                                                
                                                                                                                                // Mock the encode method calls
                                                                                                                        {}
                                                                                                                        {}
                                                                                                                                
                                                                                                                                // Mock the isFeasible method behavior
                                                                                                                                
                                                                                                                                // Test the isFeasible method
                                                                                                                            }

    @Test
                                                                                                                            public void testIsFeasible_AboveUpperBoundary() {
                                                                                                                                // Create optimizer instance with required parameters
                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                                                                                                    100,                    // lambda - changed from 0 to valid value
                                                                                                                                    new double[]{1.0},      // inputSigma - changed from null to valid array
                                                                                                                                    1000,                   // maxIterations - changed from 0 to valid value
                                                                                                                                    0.0,                    // stopFitness
                                                                                                                                    false,                  // isActiveCMA
                                                                                                                                    0,                      // diagonalOnly
                                                                                                                                    0,                      // checkFeasableCount
                                                                                                                                    new org.apache.commons.math3.random.MersenneTwister(),  // random
                                                                                                                                    false                   // generateStatistics
                                                                                                                                );
                                                                                                                                
                                                                                                                                // Create boundaries and test point
                                                                                                                                double[][] boundaries = new double[][]{{0.0, 0.0, 0.0}, {2.0, 2.0, 2.0}};
                                                                                                                                double[] x = new double[]{1.0, 2.5, 1.5};
                                                                                                                                
                                                                                                                                // Set boundaries using reflection since they're likely private fields
                                                                                                                                try {
                                                                                                                                    java.lang.reflect.Field boundariesField = optimizer.getClass().getDeclaredField("boundaries");
                                                                                                                                    boundariesField.setAccessible(true);
                                                                                                                                    boundariesField.set(optimizer, boundaries);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    org.junit.Assert.fail("Failed to set boundaries field: " + e.getMessage());
                                                                                                                                }
                                                                                                                                
                                                                                                                                // Test the isFeasible method
                                                                                                                            }

    @Test
                                                                                                                            public void testIsFeasible_SingleDimensionViolation() {
                                                                                                                                // Create optimizer instance with default constructor
                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                
                                                                                                                                // Create spy for the optimizer
                                                                                                                                CMAESOptimizer optimizerSpy = spy(optimizer);
                                                                                                                                
                                                                                                                                // Define test data
                                                                                                                                double[][] boundaries = {{0.0, 0.0, 0.0}, {5.0, 5.0, 5.0}};
                                                                                                                                double[] x = {3.0, 6.0, 2.0};
                                                                                                                                
                                                                                                                                // Mock the encode method calls
                                                                                                                        {}
                                                                                                                        {}
                                                                                                                                
                                                                                                                                // Verify the feasibility check
                                                                                                                            }

    @Test
                                                                                                                            public void testIsFeasible_EmptyInput() {
                                                                                                                                // Create optimizer instance with default constructor
                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                                                                
                                                                                                                                // Create test data
                                                                                                                                double[][] boundaries = new double[2][0];  // {{}, {}} alternative
                                                                                                                                double[] x = new double[0];
                                                                                                                                
                                                                                                                                // Mock the encode method calls
                                                                                                                                CMAESOptimizer optimizerSpy = spy(optimizer);
                                                                                                                                
                                                                                                                                // Test the method
                                                                                                                            }

    @Test
                                                                                                                            public void testIsFeasible_NullInput() {
                                                                                                                                // Using simplest constructor that takes just lambda parameter
                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer(10);
                                                                                                                                try {
                                                                                                                                    fail("Expected NullPointerException");
                                                                                                                                } catch (NullPointerException e) {
                                                                                                                                    // Expected exception
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                    public void testEncode_WithBoundaries() {
                                                                                        // Setup
                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer();
                                                                                {}
                                                                                {}
                                                                                        
                                                                                        // Using reflection to set private fields
                                                                                {
                                                                                            // Set valueRange
                                                                                {{}{}{}}
                                                                                            
                                                                                            // Set inputSigma if needed (might be required for proper initialization)
                                                                                {}
                                                                                            
                                                                                            // Initialize other required fields
                                                                                            Field isMinimizeField = CMAESOptimizer.class.getDeclaredField("isMinimize");
                                                                                }{
                                                                                        }
                                                                                        
                                                                                        // Execute
                                                                                        
                                                                                        // Verify
                                                                                    }

    @Test
                                                                                    public void testDecode_NegativeValues() throws Exception {
                                                                                        // Setup
                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(10, new double[]{0.5, 0.5});
                                                                                        
                                                                                        // Use reflection to set private boundaries field
                                                                                {{}{}}
                                                                                        
                                                                                        double[] input = {0.5, -0.5};
                                                                                        double[] expected = {0.0, -2.0}; // Corrected expected values based on decode logic
                                                                                        
                                                                                        // Execute
                                                                                        
                                                                                        // Verify
                                                                                    }

    @Test
                                                                                    public void testIsFeasible_WithinBoundaries() {
                                                                                        // Create optimizer with proper constructor parameters
                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(
                                                                                            10,                     // lambda
                                                                                            new double[]{1.0},      // inputSigma
                                                                                            1000,                   // maxIterations
                                                                                            0.0,                    // stopFitness
                                                                                            false,                  // isActiveCMA
                                                                                            0,                      // diagonalOnly
                                                                                            0,                      // checkFeasableCount
                                                                                            new MersenneTwister(),  // random
                                                                                            false                   // generateStatistics
                                                                                        );
                                                                                        
                                                                                        // Create test point
                                                                                        double[] x = {1.0, 2.0, 3.0};
                                                                                        
                                                                                        // Using reflection to set required boundaries for the test
                                                                                        try {
                                                                                            // Set lower bounds (assuming [-5,-5,-5] as example boundaries)
                                                                                            Field lowerBoundsField = CMAESOptimizer.class.getDeclaredField("lowerBounds");
                                                                                            lowerBoundsField.setAccessible(true);
                                                                                            lowerBoundsField.set(optimizer, new double[]{-5.0, -5.0, -5.0});
                                                                                            
                                                                                            // Set upper bounds (assuming [5,5,5] as example boundaries)
                                                                                            Field upperBoundsField = CMAESOptimizer.class.getDeclaredField("upperBounds");
                                                                                            upperBoundsField.setAccessible(true);
                                                                                            upperBoundsField.set(optimizer, new double[]{5.0, 5.0, 5.0});
                                                                                            
                                                                                            // Also need to set the dimension to match our test point
                                                                                            Field dimensionField = CMAESOptimizer.class.getDeclaredField("dimension");
                                                                                            dimensionField.setAccessible(true);
                                                                                            dimensionField.setInt(optimizer, x.length);
                                                                                        } catch (Exception e) {
                                                                                            fail("Failed to set boundaries via reflection: " + e.getMessage());
                                                                                        }
                                                                                        
                                                                                        // Test that the point is within boundaries
                                                                                    }

    @Test
                                                                        public void testEncode_NullBoundaries() {
                                                                            // Setup
                                                                            org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
                                                                            
                                                                            // Using reflection to set boundaries to null since it's private
                                                                            try {
                                                                                Field boundariesField = optimizer.getClass().getDeclaredField("boundaries");
                                                                                boundariesField.setAccessible(true);
                                                                                boundariesField.set(optimizer, null);
                                                                            } catch (Exception e) {
                                                                                org.junit.Assert.fail("Failed to set boundaries field via reflection: " + e.getMessage());
                                                                            }
                                                                            
                                                                            double[] input = {1.0, 2.0, 3.0};
                                                                            
                                                                            // Execute
                                                                            try {
                                                                                Method encodeMethod = optimizer.getClass().getMethod("encode", double[].class);
                                                                                double[] result = (double[]) encodeMethod.invoke(optimizer, input);
                                                                                
                                                                                // Verify
                                                                                org.junit.Assert.assertArrayEquals("Encoding with null boundaries should return input unchanged", 
                                                                                                               input, result, 0.0);
                                                                            } catch (Exception e) {
                                                                                org.junit.Assert.fail("Failed to invoke encode method: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                public void testIsFeasible_OnBoundary() {
                                    // Create CMAESOptimizer instance with valid parameters using available constructor
                                    org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                            10,                     // lambda (population size)
                                            new double[]{0.1},      // inputSigma
                                            100,                    // maxIterations
                                            0.0,                   // stopFitness
                                            true,                  // isActiveCMA
                                            0,                     // diagonalOnly
                                            0,                     // checkFeasableCount
                                            new org.apache.commons.math3.random.JDKRandomGenerator(),  // random
                                            false                  // generateStatistics
                                    );
                                    
                                    // Define test data
                                    double[] point = new double[]{0.0};  // Test point on boundary
                                    double[][] boundaries = new double[][]{{-1.0, 1.0}};  // Boundary range
                                    
                                    try {
                                        // Set boundaries using reflection
                                        java.lang.reflect.Field boundariesField = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class
                                            .getDeclaredField("boundaries");
                                        boundariesField.setAccessible(true);
                                        boundariesField.set(optimizer, boundaries);
                                        
                                        // Get isFeasible method using reflection since it's not public
                                        java.lang.reflect.Method isFeasibleMethod = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class
                                            .getDeclaredMethod("isFeasible", double[].class);
                                        isFeasibleMethod.setAccessible(true);
                                        
                                        // Test the isFeasible method
                                        boolean result = (boolean) isFeasibleMethod.invoke(optimizer, point);
                                        org.junit.Assert.assertTrue("Point on boundary should be feasible", result);
                                    } catch (Exception e) {
                                        org.junit.Assert.fail("Test failed due to reflection error: " + e.getMessage());
                                    }
                                }

    @Test
    public void testEncode_EmptyInput() {
        // Setup
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer(0, new double[0]);
        
        try {
            // Set boundaries field
            java.lang.reflect.Field boundariesField = 
                optimizer.getClass().getDeclaredField("boundaries");
            boundariesField.setAccessible(true);
            boundariesField.set(optimizer, new double[][]{});
            
            // Set inputSigma field (required for encode to work)
            java.lang.reflect.Field inputSigmaField = 
                optimizer.getClass().getDeclaredField("inputSigma");
            inputSigmaField.setAccessible(true);
            inputSigmaField.set(optimizer, new double[]{});
            
            // Set dimension field (required for encode to work)
            java.lang.reflect.Field dimensionField = 
                optimizer.getClass().getDeclaredField("dimension");
            dimensionField.setAccessible(true);
            dimensionField.setInt(optimizer, 0);
            
        } catch (Exception e) {
            org.junit.Assert.fail("Failed to set required fields via reflection: " + e.getMessage());
        }
        
        double[] input = new double[0];
        
        // Execute
        
        // Verify
        org.junit.Assert.assertArrayEquals(new double[0], result, 0.0);
    }

    @Test
    public void testDecode_WithBoundaries() {
        // Setup
        CMAESOptimizer optimizer = new CMAESOptimizer(10, new double[]{1.0, 1.0, 1.0});
        
        try {
            // Use reflection to call setValueRange method
            Method setValueRangeMethod = CMAESOptimizer.class.getDeclaredMethod("setValueRange", double.class);
            setValueRangeMethod.setAccessible(true);
            setValueRangeMethod.invoke(optimizer, 1.0);
            
            // Also need to set lower and upper bounds through reflection
            Field lowerBoundsField = CMAESOptimizer.class.getDeclaredField("lowerBounds");
            lowerBoundsField.setAccessible(true);
            lowerBoundsField.set(optimizer, new double[]{1.0, 2.0, 3.0});
            
            Field upperBoundsField = CMAESOptimizer.class.getDeclaredField("upperBounds");
            upperBoundsField.setAccessible(true);
            upperBoundsField.set(optimizer, new double[]{4.0, 6.0, 9.0});
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | NoSuchFieldException e) {
            fail("Failed to set boundaries fields: " + e.getMessage());
        }
        
        double[] input = {0.5, 0.5, 0.5};
        // Expected values: lower + (upper - lower) * input
        // 1.0 + (4.0-1.0)*0.5 = 2.5
        // 2.0 + (6.0-2.0)*0.5 = 4.0
        // 3.0 + (9.0-3.0)*0.5 = 6.0
        double[] expected = {2.5, 4.0, 6.0};
        
        // Execute
        
        // Verify
        assertArrayEquals(expected, result, 0.0001);
    }

    @Test
    public void testDecode_NullBoundaries() {
        // Setup
        int lambda = 4; // default population size
        double[] inputSigma = null; // default value
        int maxIterations = 1000; // changed from 0 to valid value
        double stopFitness = 0; // changed from array to primitive double
        boolean isActiveCMA = false; // default value
        int diagonalOnly = 0; // default value
        int checkFeasableCount = 0; // default value
        org.apache.commons.math3.random.RandomGenerator random = 
            new org.apache.commons.math3.random.MersenneTwister();
        boolean generateStatistics = false; // default value
        
        // Using the correct constructor with proper parameter types
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                maxIterations,
                isActiveCMA,
                diagonalOnly,
                checkFeasableCount,
                random,
                generateStatistics,
                lambda,
                inputSigma,
                new org.apache.commons.math3.optimization.SimpleValueChecker());
        
        double[] input = {1.0, 2.0, 3.0};
        
        // Using reflection to access the decode method since it's not public
        try {
            java.lang.reflect.Method decodeMethod = optimizer.getClass().getDeclaredMethod("decode", double[].class);
            decodeMethod.setAccessible(true);
            double[] result = (double[]) decodeMethod.invoke(optimizer, input);
            
            // Verify
            org.junit.Assert.assertArrayEquals(input, result, 0.0001);
        } catch (Exception e) {
            org.junit.Assert.fail("Failed to invoke decode method: " + e.getMessage());
        }
    }

    @Test
    public void testDecode_EmptyInput() {
        // Setup
        int maxIterations = 0;
        double stopFitness = 0;
        boolean isActiveCMA = false;
        int diagonalOnly = 0;
        int checkFeasableCount = 0;
        org.apache.commons.math3.random.RandomGenerator random = new org.apache.commons.math3.random.MersenneTwister();
        boolean generateStatistics = false;
        
        double[] inputSigma = new double[0];
        int lambda = 0;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer(lambda, inputSigma, maxIterations, stopFitness, isActiveCMA,
                    diagonalOnly, checkFeasableCount, random, generateStatistics,
        
        // Use reflection to set required fields if needed
{
            // Set valueRange (required for decoding)
}{
            org.junit.Assert.fail("Failed to set required fields: " + e.getMessage());
        }
        
        double[] input = new double[0];
        
        // Execute
        
        // Verify
    }


}
