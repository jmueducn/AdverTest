package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                              public void testAddValue_Comparable_AddSingleValue() {
                                                  Frequency frequency = new Frequency();
                                                  Comparable<Integer> value = 5;
                                                  
                                                  frequency.addValue(value);
                                                  
                                                  assertEquals(1, frequency.getCount(value));
                                              }

 @Test
                                              public void testAddValue_Comparable_AddMultipleSameValues() {
                                                  Frequency frequency = new Frequency();
                                                  Comparable<String> value = "test";
                                                  
                                                  frequency.addValue(value);
                                                  frequency.addValue(value);
                                                  frequency.addValue(value);
                                                  
                                                  assertEquals(3, frequency.getCount(value));
                                              }

 @Test
                                              public void testAddValue_Comparable_AddDifferentValues() {
                                                  Frequency frequency = new Frequency();
                                                  Comparable<Integer> value1 = 10;
                                                  Comparable<Integer> value2 = 20;
                                                  Comparable<Integer> value3 = 30;
                                                  
                                                  frequency.addValue(value1);
                                                  frequency.addValue(value2);
                                                  frequency.addValue(value3);
                                                  
                                                  assertEquals(1, frequency.getCount(value1));
                                                  assertEquals(1, frequency.getCount(value2));
                                                  assertEquals(1, frequency.getCount(value3));
                                              }

 @Test
                                              public void testAddValue_Comparable_AddNullValue() {
                                                  Frequency frequency = new Frequency();
                                                  
                                                  thrown.expect(NullPointerException.class);
                                                  frequency.addValue((Comparable<?>) null);
                                              }

 @Test
                                              public void testAddValue_Comparable_WithCustomComparator() {
                                                  Comparator<Comparable<?>> comparator = mock(Comparator.class);
                                                  Frequency frequency = new Frequency(comparator);
                                                  Comparable<String> value = "test";
                                                  
                                                  frequency.addValue(value);
                                                  
                                                  verify(comparator, times(1)).compare(any(), any());
                                                  assertEquals(1, frequency.getCount(value));
                                              }

 @Test
                                              public void testAddValue_Comparable_CheckOrderingWithNaturalOrder() {
                                                  Frequency frequency = new Frequency();
                                                  Comparable<Integer> value1 = 30;
                                                  Comparable<Integer> value2 = 10;
                                                  Comparable<Integer> value3 = 20;
                                                  
                                                  frequency.addValue(value1);
                                                  frequency.addValue(value2);
                                                  frequency.addValue(value3);
                                                  
                                                  Iterator<?> it = frequency.valuesIterator();
                                                  assertEquals(10, it.next());
                                                  assertEquals(20, it.next());
                                                  assertEquals(30, it.next());
                                                  assertFalse(it.hasNext());
                                              }

 @Test
                                              public void testAddValue_Comparable_CheckSumFrequency() {
                                                  Frequency frequency = new Frequency();
                                                  Comparable<Character> value1 = 'a';
                                                  Comparable<Character> value2 = 'b';
                                                  Comparable<Character> value3 = 'c';
                                                  
                                                  frequency.addValue(value1);
                                                  frequency.addValue(value2);
                                                  frequency.addValue(value2);
                                                  frequency.addValue(value3);
                                                  frequency.addValue(value3);
                                                  frequency.addValue(value3);
                                                  
                                                  assertEquals(6, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Comparable_AddAfterClear() {
                                                  Frequency frequency = new Frequency();
                                                  Comparable<Double> value1 = 3.14;
                                                  Comparable<Double> value2 = 2.71;
                                                  
                                                  frequency.addValue(value1);
                                                  frequency.addValue(value2);
                                                  frequency.clear();
                                                  frequency.addValue(value1);
                                                  
                                                  assertEquals(1, frequency.getCount(value1));
                                                  assertEquals(0, frequency.getCount(value2));
                                              }

 @Test
                                              public void testAddValue_IntegerInput() {
                                                  Frequency frequency = new Frequency();
                                                  Integer value = 5;
                                                  
                                                  frequency.addValue(value);
                                                  assertEquals(1L, frequency.getCount(value));
                                                  
                                                  frequency.addValue(value);
                                                  assertEquals(2L, frequency.getCount(value));
                                              }

 @Test
                                              public void testAddValue_IntPrimitiveInput() {
                                                  Frequency frequency = new Frequency();
                                                  int value = 10;
                                                  
                                                  frequency.addValue(value);
                                                  assertEquals(1L, frequency.getCount(value));
                                                  
                                                  frequency.addValue(value);
                                                  assertEquals(2L, frequency.getCount(value));
                                              }

 @Test
                                              public void testAddValue_LongInput() {
                                                  Frequency frequency = new Frequency();
                                                  Long value = 100L;
                                                  
                                                  frequency.addValue(value);
                                                  assertEquals(1L, frequency.getCount(value));
                                                  
                                                  frequency.addValue(value);
                                                  assertEquals(2L, frequency.getCount(value));
                                              }

 @Test
                                              public void testAddValue_CharInput() {
                                                  Frequency frequency = new Frequency();
                                                  char value = 'A';
                                                  
                                                  frequency.addValue(value);
                                                  assertEquals(1L, frequency.getCount(value));
                                                  
                                                  frequency.addValue(value);
                                                  assertEquals(2L, frequency.getCount(value));
                                              }

 @Test
                                              public void testAddValue_StringInput() {
                                                  Frequency frequency = new Frequency();
                                                  String value = "test";
                                                  
                                                  frequency.addValue(value);
                                                  assertEquals(1L, frequency.getCount(value));
                                                  
                                                  frequency.addValue(value);
                                                  assertEquals(2L, frequency.getCount(value));
                                              }

 @Test
                                              public void testAddValue_WithCustomComparator() {
                                                  Comparator<String> caseInsensitiveComparator = String::compareToIgnoreCase;
                                                  Frequency frequency = new Frequency(caseInsensitiveComparator);
                                                  
                                                  frequency.addValue("Test");
                                                  assertEquals(1L, frequency.getCount("test"));
                                                  
                                                  frequency.addValue("TEST");
                                                  assertEquals(2L, frequency.getCount("test"));
                                              }

 @Test
                                              public void testAddValue_NullInput() {
                                                  Frequency frequency = new Frequency();
                                                  
                                                  thrown.expect(IllegalArgumentException.class);
                                                  thrown.expectMessage("Value not comparable to existing values.");
                                                  
                                                  frequency.addValue(null);
                                              }

 @Test
                                              public void testAddValue_NonComparableInput() {
                                                  Frequency frequency = new Frequency();
                                                  Object nonComparable = new Object();
                                                  
                                                  thrown.expect(IllegalArgumentException.class);
                                                  thrown.expectMessage("Value not comparable to existing values.");
                                                  
                                                  frequency.addValue(nonComparable);
                                              }

 @Test
                                              public void testAddValue_MixedTypesWithSameValue() {
                                                  Frequency frequency = new Frequency();
                                                  Integer intValue = 5;
                                                  Long longValue = 5L;
                                                  
                                                  frequency.addValue(intValue);
                                                  assertEquals(1L, frequency.getCount(intValue));
                                                  assertEquals(0L, frequency.getCount(longValue)); // Different types
                                                  
                                                  frequency.addValue(longValue);
                                                  assertEquals(1L, frequency.getCount(intValue));
                                                  assertEquals(1L, frequency.getCount(longValue));
                                              }

 @Test
                                              public void testAddValue_FirstTimeAddition() {
                                                  Frequency frequency = new Frequency();
                                                  String value = "unique";
                                                  
                                                  assertEquals(0L, frequency.getCount(value));
                                                  frequency.addValue(value);
                                                  assertEquals(1L, frequency.getCount(value));
                                              }

 @Test
                                              public void testAddValue_ExistingValueIncrement() {
                                                  Frequency frequency = new Frequency();
                                                  Double value = 3.14;
                                                  
                                                  frequency.addValue(value);
                                                  frequency.addValue(value);
                                                  frequency.addValue(value);
                                                  
                                                  assertEquals(3L, frequency.getCount(value));
                                              }

 @Test
                                              public void testAddValue_Long_WithCustomComparator() {
                                                  // Test with custom comparator
                                                  Comparator<Long> reverseComparator = Comparator.reverseOrder();
                                                  Frequency customFrequency = new Frequency(reverseComparator);
                                                  
                                                  customFrequency.addValue(100L);
                                                  customFrequency.addValue(200L);
                                                  customFrequency.addValue(100L);
                                                  
                                                  assertEquals(2, customFrequency.getCount(100L));
                                                  assertEquals(1, customFrequency.getCount(200L));
                                                  assertEquals(3, customFrequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_WithLongValue_AddsToFrequencyTable() {
                                                  Frequency frequency = new Frequency();
                                                  Long value = 123L;
                                                  
                                                  frequency.addValue(value);
                                                  
                                                  assertEquals(1, frequency.getCount(value));
                                                  assertEquals(1, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_WithNullValue_ThrowsException() {
                                                  Frequency frequency = new Frequency();
                                                  
                                                  thrown.expect(IllegalArgumentException.class);
                                                  thrown.expectMessage("Value cannot be null");
                                                  
                                                  frequency.addValue((Long)null);
                                              }

 @Test
                                              public void testAddValue_WithSameValueMultipleTimes_IncrementsCount() {
                                                  Frequency frequency = new Frequency();
                                                  Long value = 456L;
                                                  
                                                  frequency.addValue(value);
                                                  frequency.addValue(value);
                                                  frequency.addValue(value);
                                                  
                                                  assertEquals(3, frequency.getCount(value));
                                                  assertEquals(3, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_WithDifferentValues_AddsAllToFrequencyTable() {
                                                  Frequency frequency = new Frequency();
                                                  Long value1 = 100L;
                                                  Long value2 = 200L;
                                                  Long value3 = 300L;
                                                  
                                                  frequency.addValue(value1);
                                                  frequency.addValue(value2);
                                                  frequency.addValue(value3);
                                                  
                                                  assertEquals(1, frequency.getCount(value1));
                                                  assertEquals(1, frequency.getCount(value2));
                                                  assertEquals(1, frequency.getCount(value3));
                                                  assertEquals(3, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_WithCustomComparator_UsesComparatorForOrdering() {
                                                  Comparator<Long> reverseComparator = (a, b) -> b.compareTo(a);
                                                  Frequency frequency = new Frequency(reverseComparator);
                                                  
                                                  frequency.addValue(1L);
                                                  frequency.addValue(2L);
                                                  frequency.addValue(3L);
                                                  
                                                  // Verify ordering is reversed
                                                  Iterator<Comparable<?>> iterator = frequency.valuesIterator();
                                                  assertEquals(3L, iterator.next());
                                                  assertEquals(2L, iterator.next());
                                                  assertEquals(1L, iterator.next());
                                              }

 @Test
                                              public void testAddValue_WithMaxAndMinLongValues_HandlesExtremes() {
                                                  Frequency frequency = new Frequency();
                                                  Long minValue = Long.MIN_VALUE;
                                                  Long maxValue = Long.MAX_VALUE;
                                                  
                                                  frequency.addValue(minValue);
                                                  frequency.addValue(maxValue);
                                                  
                                                  assertEquals(1, frequency.getCount(minValue));
                                                  assertEquals(1, frequency.getCount(maxValue));
                                                  assertEquals(2, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_AfterClear_ResetsFrequencyTable() {
                                                  Frequency frequency = new Frequency();
                                                  Long value = 999L;
                                                  
                                                  frequency.addValue(value);
                                                  frequency.clear();
                                                  frequency.addValue(value);
                                                  
                                                  assertEquals(1, frequency.getCount(value));
                                                  assertEquals(1, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Long_FirstTimeAddition() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(5L);
                                                  
                                                  assertEquals(1, frequency.getCount(5L));
                                                  assertEquals(1, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Long_MultipleAdditionsSameValue() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(10L);
                                                  frequency.addValue(10L);
                                                  frequency.addValue(10L);
                                                  
                                                  assertEquals(3, frequency.getCount(10L));
                                                  assertEquals(3, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Long_DifferentValues() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(1L);
                                                  frequency.addValue(2L);
                                                  frequency.addValue(3L);
                                                  
                                                  assertEquals(1, frequency.getCount(1L));
                                                  assertEquals(1, frequency.getCount(2L));
                                                  assertEquals(1, frequency.getCount(3L));
                                                  assertEquals(3, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Long_ZeroValue() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(0L);
                                                  
                                                  assertEquals(1, frequency.getCount(0L));
                                                  assertEquals(1, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Long_NegativeValue() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(-100L);
                                                  
                                                  assertEquals(1, frequency.getCount(-100L));
                                                  assertEquals(1, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Long_MaxLongValue() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(Long.MAX_VALUE);
                                                  
                                                  assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                                  assertEquals(1, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Long_MinLongValue() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(Long.MIN_VALUE);
                                                  
                                                  assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                                  assertEquals(1, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Long_WithCustomComparator1() {
                                                  Comparator<Long> reverseComparator = Comparator.reverseOrder();
                                                  Frequency frequency = new Frequency(reverseComparator);
                                                  
                                                  frequency.addValue(5L);
                                                  frequency.addValue(10L);
                                                  frequency.addValue(5L);
                                                  
                                                  assertEquals(2, frequency.getCount(5L));
                                                  assertEquals(1, frequency.getCount(10L));
                                                  assertEquals(3, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Long_AfterClear() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(100L);
                                                  frequency.clear();
                                                  frequency.addValue(200L);
                                                  
                                                  assertEquals(0, frequency.getCount(100L));
                                                  assertEquals(1, frequency.getCount(200L));
                                                  assertEquals(1, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Char_AddSingleCharacter() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue('a');
                                                  
                                                  assertEquals(1, frequency.getCount('a'));
                                                  assertEquals(1, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Char_AddMultipleSameCharacters() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue('b');
                                                  frequency.addValue('b');
                                                  frequency.addValue('b');
                                                  
                                                  assertEquals(3, frequency.getCount('b'));
                                                  assertEquals(3, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Char_AddDifferentCharacters() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue('c');
                                                  frequency.addValue('d');
                                                  frequency.addValue('e');
                                                  
                                                  assertEquals(1, frequency.getCount('c'));
                                                  assertEquals(1, frequency.getCount('d'));
                                                  assertEquals(1, frequency.getCount('e'));
                                                  assertEquals(3, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Char_AddSpecialCharacters() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue('@');
                                                  frequency.addValue('$');
                                                  frequency.addValue(' ');
                                                  
                                                  assertEquals(1, frequency.getCount('@'));
                                                  assertEquals(1, frequency.getCount('$'));
                                                  assertEquals(1, frequency.getCount(' '));
                                                  assertEquals(3, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Char_AddUpperCaseAndLowerCase() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue('A');
                                                  frequency.addValue('a');
                                                  
                                                  assertEquals(1, frequency.getCount('A'));
                                                  assertEquals(1, frequency.getCount('a'));
                                                  assertEquals(2, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Char_AddNumbersAsCharacters() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue('1');
                                                  frequency.addValue('2');
                                                  
                                                  assertEquals(1, frequency.getCount('1'));
                                                  assertEquals(1, frequency.getCount('2'));
                                                  assertEquals(2, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Char_WithCustomComparator() {
                                                  Comparator<Character> caseInsensitiveComparator = (c1, c2) -> 
                                                      Character.toLowerCase(c1) - Character.toLowerCase(c2);
                                                  Frequency frequency = new Frequency(caseInsensitiveComparator);
                                                  
                                                  frequency.addValue('A');
                                                  frequency.addValue('a');
                                                  frequency.addValue('B');
                                                  
                                                  assertEquals(2, frequency.getCount('A')); // 'A' and 'a' should be considered same
                                                  assertEquals(1, frequency.getCount('B'));
                                                  assertEquals(3, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Char_AfterClear() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue('x');
                                                  frequency.addValue('y');
                                                  frequency.clear();
                                                  frequency.addValue('z');
                                                  
                                                  assertEquals(0, frequency.getCount('x'));
                                                  assertEquals(0, frequency.getCount('y'));
                                                  assertEquals(1, frequency.getCount('z'));
                                                  assertEquals(1, frequency.getSumFreq());
                                              }

 @Test
                                              public void testAddValue_Char_CheckPctCalculation() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue('m');
                                                  frequency.addValue('m');
                                                  frequency.addValue('n');
                                                  
                                                  assertEquals(0.666, frequency.getPct('m'), 0.001);
                                                  assertEquals(0.333, frequency.getPct('n'), 0.001);
                                              }

 @Test
                                              public void testAddValue_Char_CheckCumulativeFreq() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue('a');
                                                  frequency.addValue('b');
                                                  frequency.addValue('b');
                                                  frequency.addValue('c');
                                                  
                                                  assertEquals(1, frequency.getCumFreq('a'));
                                                  assertEquals(3, frequency.getCumFreq('b'));
                                                  assertEquals(4, frequency.getCumFreq('c'));
                                              }

 @Test
                                      public void testAddValue_WithMockedTreeMap() throws Exception {
                                          @SuppressWarnings("unchecked")
                                          TreeMap<Object, Long> mockedMap = mock(TreeMap.class);
                                          Frequency frequency = new Frequency();
                                          
                                          // Use reflection to set the private freqTable field
                                          Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                          freqTableField.setAccessible(true);
                                          freqTableField.set(frequency, mockedMap);
                                          
                                          String value = "test";
                                          
                                          when(mockedMap.get(value)).thenReturn(null);
                                          
                                          frequency.addValue(value);
                                          
                                          verify(mockedMap).get(value);
                                          verify(mockedMap).put(value, 1L);
                                          
                                          when(mockedMap.get(value)).thenReturn(1L);
                                          
                                          frequency.addValue(value);
                                          
                                          verify(mockedMap, times(2)).get(value);
                                          verify(mockedMap).put(value, 2L);
                                      }

 @Test
                                      public void testAddValue_Long_AddSingleValue() {
                                          // Test adding a single value
                                          Frequency frequency = new Frequency();
                                          frequency.addValue(5L);
                                          assertEquals(1, frequency.getCount(5L));
                                          assertEquals(1, frequency.getSumFreq());
                                      }

 @Test
                                      public void testAddValue_Long_AddMultipleValues() {
                                          // Initialize frequency object
                                          Frequency frequency = new Frequency();
                                          
                                          // Test adding multiple values
                                          frequency.addValue(10L);
                                          frequency.addValue(20L);
                                          frequency.addValue(10L); // Duplicate
                                          
                                          assertEquals(2, frequency.getCount(10L));
                                          assertEquals(1, frequency.getCount(20L));
                                          assertEquals(3, frequency.getSumFreq());
                                      }

 @Test
                                      public void testAddValue_Long_EdgeCases() {
                                          // Initialize frequency object
                                          Frequency frequency = new Frequency();
                                          
                                          // Test edge cases
                                          frequency.addValue(Long.MAX_VALUE);
                                          frequency.addValue(Long.MIN_VALUE);
                                          frequency.addValue(0L);
                                          
                                          assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                          assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                          assertEquals(1, frequency.getCount(0L));
                                          assertEquals(3, frequency.getSumFreq());
                                      }

 @Test
                                      public void testAddValue_Long_AfterClear1() {
                                          // Test adding after clear
                                          Frequency frequency = new Frequency();
                                          frequency.addValue(5L);
                                          frequency.clear();
                                          frequency.addValue(10L);
                                          
                                          assertEquals(0, frequency.getCount(5L));
                                          assertEquals(1, frequency.getCount(10L));
                                          assertEquals(1, frequency.getSumFreq());
                                      }

 @Test
                                      public void testAddValue_Long_VerifyTreeMapInteraction() throws Exception {
                                          // Verify interaction with the underlying TreeMap
                                          @SuppressWarnings("unchecked")
                                          TreeMap<Long, Long> mockTreeMap = mock(TreeMap.class);
                                          
                                          Frequency frequencyWithMock = new Frequency();
                                          
                                          // Use reflection to set the private freqTable field
                                          Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                          freqTableField.setAccessible(true);
                                          freqTableField.set(frequencyWithMock, mockTreeMap);
                                          
                                          frequencyWithMock.addValue(42L);
                                          verify(mockTreeMap).put(42L, 1L);
                                          
                                          frequencyWithMock.addValue(42L);
                                          verify(mockTreeMap).put(42L, 2L);
                                      }

 @Test
                                      public void testAddValue_Long_NegativeValues() {
                                          // Initialize frequency object
                                          Frequency frequency = new Frequency();
                                          
                                          // Test negative values
                                          frequency.addValue(-1L);
                                          frequency.addValue(-100L);
                                          frequency.addValue(-1L);
                                          
                                          assertEquals(2, frequency.getCount(-1L));
                                          assertEquals(1, frequency.getCount(-100L));
                                          assertEquals(3, frequency.getSumFreq());
                                      }

 @Test
                                      public void testAddValue_Long_MixedValues() {
                                          // Initialize frequency object
                                          Frequency frequency = new Frequency();
                                          
                                          // Test mixed positive and negative values
                                          frequency.addValue(-5L);
                                          frequency.addValue(0L);
                                          frequency.addValue(5L);
                                          frequency.addValue(-5L);
                                          
                                          assertEquals(2, frequency.getCount(-5L));
                                          assertEquals(1, frequency.getCount(0L));
                                          assertEquals(1, frequency.getCount(5L));
                                          assertEquals(4, frequency.getSumFreq());
                                      }

 @Test
                                      public void testAddValue_Long_VerifyTreeMapInteraction1() throws Exception {
                                          @SuppressWarnings("unchecked")
                                          TreeMap<Long, Long> mockTreeMap = mock(TreeMap.class);
                                          Frequency frequency = new Frequency();
                                          
                                          // Use reflection to set the private freqTable field
                                          Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                          freqTableField.setAccessible(true);
                                          freqTableField.set(frequency, mockTreeMap);
                                          
                                          frequency.addValue(42L);
                                          
                                          verify(mockTreeMap).put(42L, 1L);
                                      }

 @Test
                                      public void testAddValueComparableShouldAddActualValueNotNull() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          String testValue = "testValue";
                                          
                                          // Get initial counts
                                          long initialTestValueCount = frequency.getCount(testValue);
                                          long initialNullCount = frequency.getCount(null);
                                          
                                          // Action
                                          frequency.addValue((Comparable<?>) testValue);
                                          
                                          // Verification
                                          // Verify testValue count increased by 1
                                          assertEquals("Count for testValue should increase by 1", 
                                                      initialTestValueCount + 1, 
                                                      frequency.getCount(testValue));
                                          
                                          // Verify null count didn't change (this catches the mutant)
                                          assertEquals("Count for null should not change when adding non-null value",
                                                      initialNullCount,
                                                      frequency.getCount(null));
                                      }

 @Test(expected = IllegalArgumentException.class)
                                      public void testAddValueWithNonComparableObjectShouldThrowException() {
                                          // Create a Frequency instance with default comparator
                                          Frequency frequency = new Frequency();
                                          
                                          // Create a non-comparable object
                                          Object nonComparable = new Object();
                                          
                                          // This should throw IllegalArgumentException because:
                                          // 1. Original code would try to cast to Comparable and fail
                                          // 2. Mutant would pass null to addValue(Comparable) which might bypass validation
                                          frequency.addValue(nonComparable);
                                          
                                          // If the mutant is present, this might not throw the expected exception
                                          // because it's passing null instead of the actual non-comparable object
                                      }

 @Test
                                      public void testAddValueWithComparableObjectShouldNotThrowException() {
                                          // Create a Frequency instance
                                          Frequency frequency = new Frequency();
                                          
                                          // Create a comparable object (String implements Comparable)
                                          String comparable = "test";
                                          
                                          try {
                                              frequency.addValue(comparable);
                                              // If we get here, the test passes (no exception thrown)
                                              assertTrue(true);
                                          } catch (IllegalArgumentException e) {
                                              fail("Should not throw exception for comparable objects");
                                          }
                                      }

 @Test
                                  public void testAddValueLongShouldNotCountNull() {
                                      // Setup
                                      Frequency frequency = new Frequency();
                                      long testValue = 123L;
                                      
                                      // Action
                                      frequency.addValue(testValue);
                                      
                                      // Verify
                                      // Original behavior: testValue should be counted
                                      assertEquals(1L, frequency.getCount(testValue));
                                      // Mutant behavior would count null instead
                                      assertEquals(0L, frequency.getCount(null));
                                      
                                      // Additional verification that no other values were affected
                                      assertEquals(1L, frequency.getSumFreq());
                                  }

 @Test
                                  public void testAddValueLongDetectsNullMutation() {
                                      // Setup
                                      Frequency frequency = new Frequency();
                                      long testValue = 12345L;
                                      
                                      // Exercise
                                      frequency.addValue(testValue);
                                      
                                      // Verify
                                      // If mutation exists (passing null), count will be 0
                                      // Original code should have count of 1
                                      assertEquals("Value should be counted once", 1, frequency.getCount(testValue));
                                      
                                      // Additional verification that null wasn't counted instead
                                      assertEquals("Null should not be counted", 0, frequency.getCount(null));
                                  }

 @Test
                                      public void testAddValueLongDetectsNullMutation1() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          long testValue = 123L;
                                          
                                          // Action - add the value
                                          frequency.addValue(testValue);
                                          
                                          // Verification
                                          // Original behavior: count for testValue should be 1
                                          assertEquals(1L, frequency.getCount(testValue));
                                          // Mutant behavior would show count 0 for testValue and count 1 for null
                                          assertEquals(0L, frequency.getCount(null));
                                          
                                          // Additional verification that no other values were affected
                                          assertEquals(0L, frequency.getCount(456L)); // some other value
                                      }

 @Test
                                  public void testAddValueCharShouldNotAddNull() {
                                      // Setup
                                      Frequency frequency = new Frequency();
                                      char testChar = 'a';
                                      
                                      // Execute
                                      frequency.addValue(testChar);
                                      
                                      // Verify
                                      // Original behavior: count for 'a' should be 1, null should be 0
                                      // Mutant behavior: count for 'a' would be 0, null would be 1
                                      assertEquals("Character count should be 1", 1, frequency.getCount(testChar));
                                      assertEquals("Null count should be 0", 0, frequency.getCount(null));
                                      
                                      // Additional verification using getPct to be thorough
                                      assertEquals("Character percentage should be 100%", 1.0, frequency.getPct(testChar), 0.0001);
                                      assertEquals("Null percentage should be 0%", 0.0, frequency.getPct(null), 0.0001);
                                  }

 @Test(expected = ClassCastException.class)
                                     public void testAddValueWithNonComparableShouldFail() {
                                         // Create a non-Comparable object
                                         class NonComparable {}
                                         Object nonComparable = new NonComparable();
                                         
                                         Frequency frequency = new Frequency();
                                         // This should throw ClassCastException when the TreeMap tries to compare
                                         // In original code, this would fail at compile time or casting
                                         frequency.addValue(nonComparable);
                                         
                                         // If we reach here, the test fails (mutant survived)
                                         fail("Expected ClassCastException when adding non-Comparable object");
                                     }

 @Test
                                     public void testAddValueWithComparableShouldSucceed() {
                                         // Create a Comparable object
                                         String comparable = "test";
                                         
                                         Frequency frequency = new Frequency();
                                         // This should work fine
                                         frequency.addValue(comparable);
                                         
                                         // Verify it was added
                                         assertEquals(1, frequency.getCount(comparable));
                                     }

 @Test(expected = IllegalArgumentException.class)
                                     public void testAddValueWithNonComparableObject() {
                                         // Create a Frequency object with default comparator
                                         Frequency frequency = new Frequency();
                                         
                                         // Create a non-comparable object
                                         Object nonComparable = new Object() {
                                             @Override
                                             public String toString() {
                                                 return "NonComparableObject";
                                             }
                                         };
                                         
                                         // This should throw IllegalArgumentException immediately in original,
                                         // but would throw ClassCastException later in the mutant
                                         frequency.addValue(nonComparable);
                                         
                                         // If we reach here, the test fails (exception wasn't thrown)
                                         fail("Expected IllegalArgumentException for non-comparable object");
                                     }

 @Test
                                     public void testAddValueWithComparableObject() {
                                         // Create a Frequency object with default comparator
                                         Frequency frequency = new Frequency();
                                         
                                         // Add a comparable object (String implements Comparable)
                                         String comparable = "test";
                                         frequency.addValue(comparable);
                                         
                                         // Verify it was added correctly
                                         assertEquals(1, frequency.getCount(comparable));
                                     }

 @Test
                                     public void testAddValueCallsCorrectOverload() {
                                         // Create a mock Frequency object
                                         Frequency frequency = mock(Frequency.class);
                                         
                                         // Create a test object that is not naturally Comparable
                                         Object nonComparable = new Object() {
                                             @Override
                                             public String toString() {
                                                 return "testObject";
                                             }
                                         };
                                         
                                         // Call the method - this would be the original version
                                         // frequency.addValue((Comparable<?>) nonComparable);
                                         
                                         // Call the method - this is the mutated version
                                         frequency.addValue(nonComparable);
                                         
                                         // Verify which addValue method was called
                                         // Original version would call addValue(Comparable)
                                         // Mutated version would call addValue(Object)
                                         verify(frequency).addValue(nonComparable); // This verifies addValue(Object) was called
                                         
                                         // To catch the mutant, we need to verify that addValue(Comparable) was NOT called
                                         verify(frequency, never()).addValue((Comparable<?>) any());
                                     }

 @Test
                                 public void testAddValueWithNonComparableObject1() {
                                     // Create a non-Comparable object
                                     class NonComparable {
                                         final long value;
                                         NonComparable(long v) { value = v; }
                                         long longValue() { return value; }
                                     }
                                     
                                     NonComparable testValue = new NonComparable(42L);
                                     Frequency frequency = new Frequency();
                                     
                                     // Test the original behavior (should work due to Long conversion)
                                     frequency.addValue(Long.valueOf(testValue.longValue()));
                                     assertEquals(1L, frequency.getCount(42L)); // Verify it was added
                                     
                                     // Now test the mutated behavior - should fail with ClassCastException
                                     try {
                                         frequency.addValue(testValue); // This would fail in mutated version
                                         fail("Expected ClassCastException when adding non-Comparable directly");
                                     } catch (ClassCastException e) {
                                         // Expected behavior for original version
                                     }
                                 }

 @Test
                                     public void testAddValueLongDetectsMutant() {
                                         // Create test instance
                                         Frequency frequency = new Frequency();
                                         
                                         // Test with regular value
                                         long testValue1 = 100L;
                                         frequency.addValue(testValue1);
                                         assertEquals(1L, frequency.getCount(testValue1));
                                         
                                         // Test with edge case (min long value)
                                         long testValue2 = Long.MIN_VALUE;
                                         frequency.addValue(testValue2);
                                         assertEquals(1L, frequency.getCount(testValue2));
                                         
                                         // Test with zero
                                         long testValue3 = 0L;
                                         frequency.addValue(testValue3);
                                         assertEquals(1L, frequency.getCount(testValue3));
                                         
                                         // Test multiple additions
                                         long testValue4 = 42L;
                                         frequency.addValue(testValue4);
                                         frequency.addValue(testValue4);
                                         assertEquals(2L, frequency.getCount(testValue4));
                                         
                                         // Verify all counts
                                         assertEquals(4L, frequency.getSumFreq());
                                     }

 @Test
                                     public void testAddValueCharacterShouldUseComparableOverload() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         Character testChar = 'a';
                                         
                                         // Use reflection to verify which method is called (indirectly)
                                         // The test will fail for the mutant because:
                                         // Original: calls addValue(Comparable) which is safe for TreeMap
                                         // Mutant: calls addValue(Object) which could cause issues
                                         
                                         // Action
                                         frequency.addValue(testChar);
                                         
                                         // Verification
                                         // If the mutant is present, the value would still be added,
                                         // but we can verify the count to ensure proper behavior
                                         assertEquals(1L, frequency.getCount(testChar));
                                         
                                         // More importantly, test with a mock to verify interaction
                                         Frequency spyFrequency = spy(frequency);
                                         spyFrequency.addValue(testChar);
                                         
                                         // This verification would fail for the mutant
                                         verify(spyFrequency).addValue((Comparable<?>) testChar);
                                     }

 @Test(expected = ClassCastException.class)
                                     public void testAddValueNonComparableShouldFail() {
                                         // This test would only pass with the original version
                                         // because the cast to Comparable would fail early
                                         Frequency frequency = new Frequency();
                                         
                                         // Create a non-Comparable object
                                         Object nonComparable = new Object() {
                                             @Override
                                             public String toString() {
                                                 return "non-comparable";
                                             }
                                         };
                                         
                                         // This should throw ClassCastException when trying to cast to Comparable
                                         // The mutant version would try to add it to the TreeMap and fail later
                                         frequency.addValue(nonComparable);
                                     }

 @Test
                                    public void testAddValueWithLargeInteger() {
                                        // Create a Frequency instance
                                        Frequency frequency = new Frequency();
                                        
                                        // Create an Integer value that's larger than Integer.MAX_VALUE
                                        // We need to cast it to Integer, but this will actually create a value
                                        // that's beyond Integer's range, which will wrap around
                                        // So we'll use a different approach to test the conversion
                                        
                                        // Instead, we'll test with Integer.MAX_VALUE which should be handled the same
                                        // in both versions, and then test with a value that would show the difference
                                        // if we could create such an Integer
                                        
                                        // Since we can't create an Integer beyond MAX_VALUE, we'll test the behavior
                                        // with MAX_VALUE itself to ensure proper long conversion
                                        Integer largeInt = Integer.MAX_VALUE;
                                        
                                        // Call the method
                                        frequency.addValue((Comparable<?>) largeInt);
                                        
                                        // Verify the value was stored correctly by checking the count
                                        // The key in the TreeMap should be a Long representation of the Integer
                                        assertEquals(1L, frequency.getCount((long) largeInt));
                                        
                                        // Also test with MIN_VALUE to cover full range
                                        Integer minInt = Integer.MIN_VALUE;
                                        frequency.addValue((Comparable<?>) minInt);
                                        assertEquals(1L, frequency.getCount((long) minInt));
                                    }

 @Test
                                    public void testAddValueWithIntegerConversion() {
                                        Frequency frequency = new Frequency();
                                        Integer testValue = 12345;
                                        
                                        frequency.addValue((Comparable<?>) testValue);
                                        
                                        // Verify the value was stored as a Long
                                        assertEquals(1L, frequency.getCount(12345L));
                                        assertEquals(0L, frequency.getCount(12345)); // Shouldn't be stored as Integer
                                    }

 @Test
                                public void testAddValueWithLargeIntegerDetectsLongConversionMutant() {
                                    // Create a frequency object
                                    Frequency frequency = new Frequency();
                                    
                                    // Create an Integer with value at Integer.MAX_VALUE
                                    Integer largeInt = Integer.MAX_VALUE;
                                    
                                    // Add the value twice to test both new entry and increment cases
                                    frequency.addValue(largeInt);
                                    frequency.addValue(largeInt);
                                    
                                    // Verify the count is 2 (proves both operations worked)
                                    assertEquals(2L, frequency.getCount(largeInt));
                                    
                                    // The key test - verify the stored key is the correct Long value
                                    // This will fail with the mutant since intValue() would be used
                                    Long expectedKey = Long.valueOf(largeInt.longValue());
                                    assertEquals(2L, frequency.getCount(expectedKey));
                                    
                                    // Also test with a value that would overflow if treated as int
                                    Integer overflowInt = Integer.MAX_VALUE - 10;
                                    frequency.addValue(overflowInt);
                                    Long overflowKey = Long.valueOf(overflowInt.longValue());
                                    assertEquals(1L, frequency.getCount(overflowKey));
                                }

 @Test
                                public void testAddValueIntegerWithLargeValue() {
                                    // Create a value that's larger than Integer.MAX_VALUE but valid as long
                                    long largeValue = (long)Integer.MAX_VALUE + 1L;
                                    Integer largeInteger = (int)largeValue; // This will overflow to Integer.MIN_VALUE
                                    
                                    Frequency frequency = new Frequency();
                                    frequency.addValue(largeInteger);
                                    
                                    // The original code would store it as -2147483648 (due to overflow then conversion)
                                    // But we want to verify the conversion method used
                                    // Check the actual stored key by getting the count
                                    long storedValueCount = frequency.getCount(largeValue);
                                    long overflowedValueCount = frequency.getCount((long)Integer.MIN_VALUE);
                                    
                                    // Original behavior would have used longValue() and stored as MIN_VALUE
                                    // Mutant behavior would be the same in this case, but we need a different approach
                                    
                                    // Alternative approach: check all stored values
                                    Iterator valuesIter = frequency.valuesIterator();
                                    Long storedValue = (Long)valuesIter.next();
                                    
                                    // The key difference is in how the conversion happens
                                    // For this specific case, both conversions give same result due to overflow
                                    // So we need a different test case
                                    
                                    // Let's test with Integer.MAX_VALUE to see conversion behavior
                                    frequency.clear();
                                    frequency.addValue(Integer.MAX_VALUE);
                                    storedValue = (Long)valuesIter.next();
                                    assertEquals(Long.valueOf(Integer.MAX_VALUE), storedValue);
                                    
                                    // The mutant would behave the same here, so we need to test edge cases
                                    // where intValue() and longValue() would differ
                                    // Such as when the Integer represents a negative value that would
                                    // be different when interpreted as long vs int
                                    
                                    // Test with -1 which has different binary representation in int vs long
                                    frequency.clear();
                                    frequency.addValue(-1);
                                    storedValue = (Long)valuesIter.next();
                                    // Original would use longValue(): 0xFFFFFFFFFFFFFFFF
                                    // Mutant would use intValue(): 0xFFFFFFFF (same value when cast to long)
                                    // So no difference
                                    
                                    // After analysis, this particular mutation is actually equivalent
                                    // because any int value when converted via intValue() or longValue()
                                    // will result in the same long value when autoboxed to Long
                                    // Therefore, this mutation is actually equivalent and cannot be killed
                                    
                                    // Conclusion: This is an equivalent mutant that cannot be detected
                                    // through testing because the behavior is identical
                                }

 @Test
                                public void testAddValueIntegerTypeConversion() throws Exception {
                                    Integer testValue = 123;
                                    Frequency frequency = new Frequency();
                                    frequency.addValue(testValue);
                                    
                                    // Verify the conversion was done using longValue() not intValue()
                                    // This would require access to internal implementation or using mocking
                                    // Since we can't easily verify which conversion was used without modifying the class,
                                    // this mutation might be effectively equivalent for all valid inputs
                                    
                                    // Alternative: test that the value is stored as a Long (not Integer)
                                    Long expectedKey = Long.valueOf(testValue.longValue());
                                    assertTrue(frequency.getCount(expectedKey) > 0);
                                }

 @Test
                                public void testAddValueIntegerWithLargeNumber() {
                                    Frequency frequency = new Frequency();
                                    
                                    // Test with normal integer value (should work in both original and mutant)
                                    Integer normalValue = 1000;
                                    frequency.addValue(normalValue);
                                    assertEquals(1L, frequency.getCount(1000L));
                                    
                                    // Test with large value that exceeds Integer.MAX_VALUE
                                    // Create a Long that's bigger than Integer.MAX_VALUE but still valid as Integer object
                                    Long largeValue = (long)Integer.MAX_VALUE + 1;
                                    Integer largeInteger = largeValue.intValue(); // This will overflow to Integer.MIN_VALUE
                                    
                                    frequency.addValue(largeInteger);
                                    
                                    // Original code would store it as 2147483648L (correct)
                                    // Mutant would store it as -2147483648L (incorrect due to intValue() overflow)
                                    assertNotEquals(1L, frequency.getCount((long)Integer.MIN_VALUE)); // Mutant would match this
                                    assertEquals(1L, frequency.getCount(largeValue)); // Original would match this
                                }

 @Test
                                public void testAddValueWithLargeInteger1() {
                                    // Create a Frequency instance
                                    Frequency frequency = new Frequency();
                                    
                                    // Create a large integer value that exceeds Integer.MAX_VALUE
                                    long largeValue = (long)Integer.MAX_VALUE + 1L;
                                    Integer largeInteger = (int)largeValue; // This will overflow to negative
                                    
                                    // Add the value to frequency table
                                    frequency.addValue(largeInteger);
                                    
                                    // Verify the correct value was stored (should be the original long value)
                                    // The original version would store 2147483648L (correct)
                                    // The mutant would store -2147483648L (incorrect, due to int overflow)
                                    assertEquals(largeValue, frequency.getCount(largeValue));
                                    
                                    // Also verify the count is 1
                                    assertEquals(1L, frequency.getCount(largeValue));
                                }

 @Test
                               public void testAddValueIntegerWithLargeNumber1() throws Exception {
                                   // Create a large number that exceeds Integer.MAX_VALUE when converted to long
                                   Integer largeNumber = Integer.MAX_VALUE;
                                   
                                   Frequency frequency = new Frequency();
                                   frequency.addValue(largeNumber);
                                   
                                   // Verify the value stored is the correct long value
                                   // The original would store 2147483647L (correct)
                                   // The mutant would store 2147483647 (same in this case, but could differ for other values)
                                   
                                   // To catch the mutant, we need a value where longValue() and intValue() differ
                                   // However, since Integer can't hold values beyond its range, we need to test edge cases
                                   
                                   // Alternative approach: test with Integer.MIN_VALUE which has different long representation
                                   frequency.clear();
                                   Integer minInt = Integer.MIN_VALUE;
                                   frequency.addValue(minInt);
                                   
                                   // The original would store -2147483648L
                                   // The mutant would store -2147483648 (same value in this case)
                                   
                                   // Use reflection to access the private freqTable field
                                   Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                   freqTableField.setAccessible(true);
                                   @SuppressWarnings("unchecked")
                                   TreeMap<Long, Long> freqTable = (TreeMap<Long, Long>) freqTableField.get(frequency);
                                   
                                   Long storedKey = freqTable.keySet().iterator().next();
                                   
                                   // Verify the stored key is exactly what we expect
                                   assertEquals(Long.valueOf(minInt.longValue()), storedKey);
                                   
                                   // The test will pass for original (longValue) but would fail if mutant (intValue) was used,
                                   // even though the values are numerically equal, they are different objects
                                   assertSame(Long.class, storedKey.getClass());
                               }

 @Test
                               public void testAddValueWithCustomComparable() {
                                   // Create a custom Comparable implementation that would be affected by the mutation
                                   class CustomComparable implements Comparable<String> {
                                       @Override
                                       public int compareTo(String o) {
                                           return o.length() - 5; // Simple comparison logic
                                       }
                                   }
                                   
                                   Frequency frequency = new Frequency();
                                   CustomComparable customComp = new CustomComparable();
                                   
                                   // This should work with both versions, but the mutation might affect type safety
                                   frequency.addValue(customComp);
                                   
                                   // Verify the value was added correctly
                                   assertEquals(1L, frequency.getCount(customComp));
                                   
                                   // Create another instance with different behavior
                                   class AnotherComparable implements Comparable<Integer> {
                                       @Override
                                       public int compareTo(Integer o) {
                                           return o - 42;
                                       }
                                   }
                                   
                                   AnotherComparable anotherComp = new AnotherComparable();
                                   frequency.addValue(anotherComp);
                                   
                                   // Verify both values are tracked separately
                                   assertEquals(1L, frequency.getCount(customComp));
                                   assertEquals(1L, frequency.getCount(anotherComp));
                               }

 @Test
                               public void testAddValueWithRegularComparable() {
                                   // Additional test to verify normal comparable objects work
                                   Frequency frequency = new Frequency();
                                   frequency.addValue("test"); // String implements Comparable<String>
                                   assertEquals(1, frequency.getCount("test"));
                               }

 @Test(expected = IllegalArgumentException.class)
                               public void testAddValueWithNonComparable() {
                                   // Test with truly non-comparable object
                                   Frequency frequency = new Frequency();
                                   frequency.addValue(new Object());
                               }

 @Test
                               public void testAddValueWithObjectComparable() {
                                   // Create a custom comparable that implements Comparable<Object>
                                   class ObjectComparable implements Comparable<Object> {
                                       private final int value;
                                       
                                       public ObjectComparable(int value) {
                                           this.value = value;
                                       }
                                       
                                       @Override
                                       public int compareTo(Object o) {
                                           if (o instanceof ObjectComparable) {
                                               return Integer.compare(value, ((ObjectComparable)o).value);
                                           }
                                           return -1;
                                       }
                                   }
                                   
                                   Frequency frequency = new Frequency();
                                   ObjectComparable objComp = new ObjectComparable(5);
                                   
                                   // This should fail if the mutation is present because the original code
                                   // would only accept Comparable<?> not Comparable<? super Object>
                                   try {
                                       frequency.addValue(objComp);
                                       // If we get here, the mutation survived
                                       fail("Expected the method to reject Comparable<Object>");
                                   } catch (ClassCastException e) {
                                       // Expected behavior for original code
                                       assertTrue(true);
                                   }
                               }

 @Test
                               public void testAddValueWithCustomComparable1() {
                                   // Create a custom Comparable object that would expose the type safety issue
                                   class CustomComparable implements Comparable<Object> {
                                       private final String value;
                                       
                                       public CustomComparable(String value) {
                                           this.value = value;
                                       }
                                       
                                       @Override
                                       public int compareTo(Object o) {
                                           // This implementation would work with Comparable<? super Object>
                                           // but might fail with stricter type bounds
                                           if (o instanceof CustomComparable) {
                                               return this.value.compareTo(((CustomComparable)o).value);
                                           }
                                           return -1;
                                       }
                                       
                                       @Override
                                       public String toString() {
                                           return value;
                                       }
                                   }
                                   
                                   Frequency frequency = new Frequency();
                                   CustomComparable comparable1 = new CustomComparable("test");
                                   CustomComparable comparable2 = new CustomComparable("test");
                                   
                                   // This should work with both original and mutated version
                                   frequency.addValue(comparable1);
                                   
                                   // Verify the count was incremented
                                   assertEquals(1L, frequency.getCount(comparable1));
                                   
                                   // Add another comparable object
                                   frequency.addValue(comparable2);
                                   
                                   // This assertion would fail if the mutation caused type comparison issues
                                   assertEquals(2L, frequency.getCount(comparable1));
                                   
                                   // Test with a different type to expose potential type safety issues
                                   try {
                                       frequency.addValue(new Object());
                                       fail("Expected ClassCastException not thrown");
                                   } catch (ClassCastException e) {
                                       // Expected behavior
                                   }
                               }

 @Test
                               public void testAddValueWithDifferentComparableTypes() {
                                   // Create a custom Comparable class that's not Comparable<Object>
                                   class CustomComparable implements Comparable<CustomComparable> {
                                       private final int value;
                                       
                                       public CustomComparable(int value) {
                                           this.value = value;
                                       }
                                       
                                       @Override
                                       public int compareTo(CustomComparable other) {
                                           return Integer.compare(this.value, other.value);
                                       }
                                       
                                       @Override
                                       public boolean equals(Object obj) {
                                           if (this == obj) return true;
                                           if (!(obj instanceof CustomComparable)) return false;
                                           CustomComparable other = (CustomComparable) obj;
                                           return value == other.value;
                                       }
                                       
                                       @Override
                                       public int hashCode() {
                                           return value;
                                       }
                                   }
                                   
                                   Frequency frequency = new Frequency();
                                   CustomComparable customValue = new CustomComparable(42);
                                   
                                   // This should call addValue(Comparable<?>) in original,
                                   // but addValue(Comparable<? super Object>) in mutated version
                                   frequency.addValue(customValue);
                                   
                                   // Verify the value was properly added to the frequency table
                                   assertEquals(1L, frequency.getCount(customValue));
                                   
                                   // Add another value to test comparison behavior
                                   CustomComparable anotherValue = new CustomComparable(42);
                                   frequency.addValue(anotherValue);
                                   
                                   // Should be counted as the same value if original behavior is preserved
                                   assertEquals(2L, frequency.getCount(customValue));
                               }

 @Test
                               public void testAddValueCharProperlyBoxesToCharacter() {
                                   // Create a Frequency instance
                                   Frequency frequency = new Frequency();
                                   
                                   // Add a char value
                                   char testChar = 'a';
                                   frequency.addValue(testChar);
                                   
                                   // Verify the value was added as a Character object
                                   // This would fail with the mutant since it would try to add as Comparable
                                   assertEquals(1L, frequency.getCount(testChar));
                                   assertEquals(1L, frequency.getCount(Character.valueOf(testChar)));
                                   
                                   // Verify no count when querying with wrong type (would pass with mutant)
                                   assertEquals(0L, frequency.getCount((Comparable<?>) testChar));
                                   
                                   // Verify sum frequency is correct
                                   assertEquals(1L, frequency.getSumFreq());
                               }

 @Test
                          public void testAddValueWithObjectComparable1() {
                              // This test should detect the mutant by using an object that implements Comparable<Object>
                              // but shouldn't be accepted by the original method
                              
                              Frequency frequency = new Frequency();
                              
                              // Define a simple Comparable implementation for testing
                              class TestComparable implements Comparable<Object> {
                                  @Override
                                  public int compareTo(Object o) {
                                      return 0;
                                  }
                              }
                              
                              TestComparable testObj = new TestComparable();
                              
                              // This should throw IllegalArgumentException in original code
                              // but would be accepted by the mutated code
                              frequency.addValue(testObj);
                          }

 @Test(expected = IllegalArgumentException.class)
                          public void testAddValueWithNonComparableObjectShouldFailWithGenericTypeSafety() {
                              // Create a Frequency object with default comparator
                              Frequency frequency = new Frequency();
                              
                              // Create a custom non-Comparable object
                              class NonComparable {}
                              Object nonComparableObj = new NonComparable();
                              
                              try {
                                  // This should fail because the object isn't Comparable
                                  frequency.addValue(nonComparableObj);
                              } catch (IllegalArgumentException e) {
                                  // Verify the exception message
                                  assertEquals("Value not comparable to existing values.", e.getMessage());
                                  throw e; // rethrow to satisfy expected exception
                              }
                              
                              // If we get here, the test failed (no exception thrown)
                              fail("Expected IllegalArgumentException for non-comparable object");
                          }

 @Test
                          public void testAddValueWithNonLongComparable() {
                              // Create test objects
                              Frequency frequency = new Frequency();
                              String nonLongComparable = "test"; // String is Comparable but not a Long
                              
                              try {
                                  // This should fail with ClassCastException in original code
                                  // but might work in mutant since it uses raw Comparable
                                  frequency.addValue(nonLongComparable);
                                  
                                  // If we get here, the mutant survived
                                  fail("Expected ClassCastException when adding non-Long Comparable");
                              } catch (ClassCastException e) {
                                  // Expected behavior for original code
                                  assertTrue("Expected ClassCastException was thrown", true);
                              }
                              
                              // Verify the value wasn't added to freqTable
                              assertEquals(0, frequency.getCount(nonLongComparable));
                          }

 @Test
                          public void testAddValueWithLong() {
                              // Create test objects
                              Frequency frequency = new Frequency();
                              Long longValue = 123L;
                              
                              // This should work in both original and mutant
                              frequency.addValue(longValue);
                              
                              // Verify the value was added to freqTable
                              assertEquals(1, frequency.getCount(longValue));
                          }

 @Test
                      public void testAddValueWithCustomComparable2() {
                          // Create a custom Comparable object that implements Comparable<Long>
                          Comparable<Long> customComparable = new Comparable<Long>() {
                              @Override
                              public int compareTo(Long o) {
                                  return o.compareTo(5L); // Compare with fixed value 5
                              }
                              
                              @Override
                              public String toString() {
                                  return "CustomComparable";
                              }
                          };
                          
                          Frequency frequency = new Frequency();
                          
                          // This should work with Comparable<?> but might fail with raw Comparable
                          frequency.addValue(customComparable);
                          
                          // Verify the value was added correctly
                          assertEquals(1L, frequency.getCount(customComparable));
                          
                          // Add another value to test comparison works
                          frequency.addValue(10L);
                          assertEquals(1L, frequency.getCount(10L));
                          
                          // The mutation might cause issues when comparing different types
                          // This test would catch if the raw type causes comparison problems
                          frequency.addValue(5L);
                          assertEquals(1L, frequency.getCount(5L));
                      }

 @Test
                          public void testAddValueWithNonLongComparableShouldNotBeCounted() {
                              // Setup
                              Frequency frequency = new Frequency();
                              String nonLongComparable = "test"; // String is Comparable but not a Long
                              
                              // Verify initial state
                              assertEquals(0, frequency.getCount(nonLongComparable));
                              
                              try {
                                  // This should fail in original version due to ClassCastException
                                  // but might work in mutated version
                                  frequency.addValue(nonLongComparable);
                                  
                                  // If we get here, the mutation survived
                                  fail("Expected ClassCastException not thrown");
                              } catch (ClassCastException e) {
                                  // Expected behavior for original version
                                  assertEquals(0, frequency.getCount(nonLongComparable));
                              }
                              
                              // Additional verification that proper Long values still work
                              Long validLong = 123L;
                              frequency.addValue(validLong);
                              assertEquals(1, frequency.getCount(validLong));
                          }

 @Test
                      public void testAddValueCharDetectsGenericTypeMutant() {
                          // Setup
                          Frequency frequency = new Frequency();
                          char testChar = 'a';
                          
                          // Action
                          frequency.addValue(testChar);
                          
                          // Verification
                          // Verify the character was properly added and counted
                          assertEquals(1L, frequency.getCount(testChar));
                          
                          // Additional verification to ensure proper type handling
                          // This would fail if the type casting mutation caused issues
                          assertEquals(1L, frequency.getCount(Character.valueOf(testChar)));
                          
                          // Verify the sum frequency is correct
                          assertEquals(1L, frequency.getSumFreq());
                      }

 @Test
                     public void testAddValueWithGenericComparable() {
                         // Define a simple Comparable implementation for testing
                         class TestComparable<T> implements Comparable<TestComparable<T>> {
                             private final T value;
                             
                             public TestComparable(T value) {
                                 this.value = value;
                             }
                             
                             @Override
                             public int compareTo(TestComparable<T> other) {
                                 return value.toString().compareTo(other.value.toString());
                             }
                             
                             @Override
                             public boolean equals(Object obj) {
                                 if (this == obj) return true;
                                 if (!(obj instanceof TestComparable)) return false;
                                 TestComparable<?> other = (TestComparable<?>) obj;
                                 return value.equals(other.value);
                             }
                             
                             @Override
                             public int hashCode() {
                                 return value.hashCode();
                             }
                         }
                     
                         // Setup
                         Frequency frequency = new Frequency();
                         TestComparable<String> stringComparable = new TestComparable<>("test");
                         
                         // Action
                         frequency.addValue(stringComparable);
                         
                         // Verification
                         assertEquals(1L, frequency.getCount(stringComparable));
                         
                         // Additional verification that the value was stored correctly
                         // This would fail if the raw type was used due to potential type mismatches
                         assertEquals(1L, frequency.getCount(new TestComparable<>("test")));
                     }

 @Test
                     public void testAddValueComparableWithLeadingZeroInteger() {
                         // Create test object
                         Frequency frequency = new Frequency();
                         
                         // Create an Integer with leading zeros in string representation
                         Integer testValue = Integer.valueOf("0010"); // Actual numeric value is 10
                         
                         // Call the method
                         frequency.addValue((Comparable<?>) testValue);
                         
                         // Verify the value was stored correctly as Long 10 (not 0010)
                         // Check count for numeric value 10 (should be 1)
                         assertEquals(1L, frequency.getCount(10L));
                         
                         // Check count for string representation "0010" (should be 0)
                         assertEquals(0L, frequency.getCount("0010"));
                         
                         // Also verify the sum frequency is correct
                         assertEquals(1L, frequency.getSumFreq());
                     }

 @Test
                 public void testAddValueWithMaxInteger() {
                     Frequency frequency = new Frequency();
                     Integer maxInt = Integer.MAX_VALUE;
                     
                     // Add the value twice - should count properly
                     frequency.addValue(maxInt);
                     frequency.addValue(maxInt);
                     
                     // Verify the count is 2 and the key is stored as Long
                     assertEquals(2L, frequency.getCount(maxInt));
                     
                     // Verify the key in freqTable is actually Long.MAX_VALUE (2147483647L)
                     // This is where the mutant would fail - toString() would work the same in this case,
                     // but we need to verify the exact Long value stored
                     Long expectedKey = Long.valueOf(maxInt.longValue());
                     assertTrue(frequency.getCount(expectedKey) == 2L);
                     
                     // Alternative verification by checking the sum of frequencies
                     assertEquals(2L, frequency.getSumFreq());
                 }

 @Test
                 public void testAddValueWithIntegerConversion1() {
                     Frequency frequency = new Frequency();
                     Integer testValue = 12345;
                     
                     frequency.addValue(testValue);
                     
                     // Verify the key was stored as Long, not as String representation
                     Long expectedKey = Long.valueOf(testValue.longValue());
                     assertNotNull(frequency.getCount(expectedKey));
                     assertEquals(1L, frequency.getCount(expectedKey));
                     
                     // Verify no entry exists with String key
                     assertEquals(0L, frequency.getCount(testValue.toString()));
                 }

 @Test
                 public void testAddValueIntegerBoundaryCases() {
                     Frequency frequency = new Frequency();
                     
                     // Test with Integer.MIN_VALUE - most likely to expose conversion differences
                     Integer minValue = Integer.MIN_VALUE;
                     frequency.addValue(minValue);
                     // Verify the value was properly converted and stored
                     assertEquals(1L, frequency.getCount(Long.valueOf(minValue.longValue())));
                     
                     // Test with Integer.MAX_VALUE
                     Integer maxValue = Integer.MAX_VALUE;
                     frequency.addValue(maxValue);
                     assertEquals(1L, frequency.getCount(Long.valueOf(maxValue.longValue())));
                     
                     // Test with zero
                     Integer zero = 0;
                     frequency.addValue(zero);
                     assertEquals(1L, frequency.getCount(0L));
                     
                     // Test with negative number
                     Integer negative = -12345;
                     frequency.addValue(negative);
                     assertEquals(1L, frequency.getCount(-12345L));
                     
                     // Test with positive number
                     Integer positive = 12345;
                     frequency.addValue(positive);
                     assertEquals(1L, frequency.getCount(12345L));
                 }

 @Test
                 public void testAddValueIntegerWithMaxValue() {
                     Frequency frequency = new Frequency();
                     Integer maxInt = Integer.MAX_VALUE;
                     
                     // Expected behavior - should convert directly to Long
                     Long expected = Long.valueOf(maxInt.longValue());
                     
                     frequency.addValue(maxInt);
                     
                     // Verify the count for this value is 1
                     assertEquals(1L, frequency.getCount(maxInt));
                     
                     // Verify the stored key is the correct Long representation
                     // Since we can't directly access freqTable, we check via getCount
                     assertEquals(1L, frequency.getCount(expected));
                     
                     // Also verify the sum frequency is correct
                     assertEquals(1L, frequency.getSumFreq());
                 }

 @Test
                public void testAddValueIntegerWithLargeValue1() throws Exception {
                    // Setup
                    Frequency frequency = new Frequency();
                    Integer largeValue = Integer.MAX_VALUE;
                    
                    // Execute
                    frequency.addValue(largeValue);
                    
                    // Get private freqTable field using reflection
                    Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                    freqTableField.setAccessible(true);
                    @SuppressWarnings("unchecked")
                    TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                    
                    // Verify the value was stored correctly as Long
                    Long expected = Long.valueOf(Integer.MAX_VALUE);
                    Long actual = (Long)freqTable.keySet().iterator().next();
                    
                    assertEquals("Large Integer value should be converted to correct Long value", 
                                 expected, actual);
                    assertEquals("Frequency count should be 1", 
                                 1L, (long)freqTable.get(actual));
                }

 @Test
                public void testAddValueIntegerWithLargeValue2() throws Exception {
                    // Create test object
                    Frequency frequency = new Frequency();
                    
                    // Test with Integer.MAX_VALUE
                    Integer largeInt = Integer.MAX_VALUE;
                    frequency.addValue(largeInt);
                    
                    // Use reflection to access private freqTable field
                    Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                    freqTableField.setAccessible(true);
                    @SuppressWarnings("unchecked")
                    TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                    
                    Long expected = Long.valueOf(largeInt.longValue()); // Correct conversion
                    Long actual = freqTable.get(expected);
                    
                    // The mutant would fail here because:
                    // - Original: stores 2147483647L (correct)
                    // - Mutant: tries to parse "2147483647" which would work in this case
                    // So we need a case where toString() would differ from longValue()
                    
                    // Now test with Integer.MIN_VALUE which has different string representation
                    Integer minInt = Integer.MIN_VALUE;
                    frequency.addValue(minInt);
                    
                    expected = Long.valueOf(minInt.longValue()); // -2147483648L
                    actual = freqTable.get(expected);
                    
                    assertNotNull("Value should be in frequency table", actual);
                    assertEquals(1L, actual.longValue());
                    
                    // Additional edge case: Integer with string representation that would fail
                    // if parsed directly (though this would require exception testing)
                }

 @Test
                public void testAddValueIntegerWithCustomToString() {
                    // Create a Comparable wrapper with custom toString that differs from its numeric value
                    Comparable<Integer> trickyInt = new Comparable<Integer>() {
                        private final Integer value = 123;
                        
                        @Override
                        public String toString() {
                            return "not-a-number";
                        }
                        
                        @Override
                        public int compareTo(Integer o) {
                            return value.compareTo(o);
                        }
                    };
                    
                    Frequency frequency = new Frequency();
                    
                    try {
                        frequency.addValue(trickyInt);
                        // Original would work (stores 123L)
                        // Mutant would throw NumberFormatException when parsing "not-a-number"
                        fail("Expected NumberFormatException for mutant version");
                    } catch (NumberFormatException e) {
                        // This is expected for the mutant
                        // Test passes if exception is thrown (detects mutant)
                    }
                    
                    // Verify original behavior would store the correct value using reflection
                    try {
                        Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                        freqTableField.setAccessible(true);
                        @SuppressWarnings("unchecked")
                        TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                        assertNull("Value should not be added for mutant", freqTable.get(123L));
                    } catch (Exception e) {
                        fail("Failed to access freqTable via reflection: " + e.getMessage());
                    }
                }

 @Test
                public void testAddValueWithNonComparableThrowsIllegalArgumentException() {
                    // Setup
                    Frequency frequency = new Frequency();
                    frequency.addValue("string1"); // Add initial comparable value
                    
                    // Expect IllegalArgumentException, not RuntimeException
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Value not comparable to existing values.");
                    
                    // Test with non-comparable value
                    // Create a custom Comparable that's not comparable with String
                    Comparable<?> nonComparableValue = new Comparable<Object>() {
                        @Override
                        public int compareTo(Object o) {
                            throw new ClassCastException("Not comparable");
                        }
                    };
                    
                    // This should throw IllegalArgumentException
                    frequency.addValue(nonComparableValue);
                }

 @Test(expected = IllegalArgumentException.class)
            public void testAddValueWithNonComparableObjectShouldThrowIllegalArgumentException() {
                // Setup
                Frequency frequency = new Frequency();
                Object nonComparableObject = new Object(); // Object is not Comparable
                
                // Exercise
                frequency.addValue(nonComparableObject);
                
                // Verification is handled by the expected exception in the @Test annotation
            }

 @Test
                public void testAddValueWithNonComparableShouldThrowIllegalArgumentException() {
                    // Create a Frequency object with a natural ordering comparator
                    Frequency frequency = new Frequency();
                    
                    // Create a non-comparable object
                    Object nonComparable = new Object() {
                        @Override
                        public String toString() {
                            return "NonComparableObject";
                        }
                    };
                    
                    // Expect IllegalArgumentException to be thrown
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Value not comparable to existing values.");
                    
                    // Call the method that should throw the exception
                    frequency.addValue(nonComparable);
                }

 @Test
                public void testAddValueWithNonComparableShouldThrowIllegalArgumentException1() {
                    // Create a custom comparator that throws ClassCastException for certain values
                    Comparator<Object> comparator = new Comparator<Object>() {
                        @Override
                        public int compare(Object o1, Object o2) {
                            if (o1 instanceof Long && o2 instanceof Long) {
                                return ((Long) o1).compareTo((Long) o2);
                            }
                            throw new ClassCastException("Cannot compare these types");
                        }
                    };
                    
                    Frequency frequency = new Frequency(comparator);
                    
                    // Set expectation for the specific exception type
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Value not comparable to existing values.");
                    
                    // This should trigger the exception since the comparator doesn't support Strings
                    frequency.addValue("non-comparable-value");
                }

 @Test
                public void testAddValueWithNonComparableShouldThrowIllegalArgumentException2() {
                    // Create a Frequency object with a comparator that doesn't accept the test value
                    Frequency frequency = new Frequency((o1, o2) -> {
                        // This comparator only works with Long values
                        if (!(o1 instanceof Long) || !(o2 instanceof Long)) {
                            throw new ClassCastException("Only Long values are comparable");
                        }
                        return ((Long)o1).compareTo((Long)o2);
                    });
            
                    // Set expectation for IllegalArgumentException
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Value not comparable to existing values.");
            
                    // Try to add a non-Long value (String in this case)
                    frequency.addValue("not-a-long");
                }

 @Test
                public void testAddValueWithInvalidCharacterShouldThrowIllegalArgumentException() {
                    // Create a Frequency with a comparator that always throws ClassCastException
                    Comparator<Character> failingComparator = (c1, c2) -> {
                        throw new ClassCastException("Cannot compare");
                    };
                    Frequency frequency = new Frequency(failingComparator);
                    
                    // Expect IllegalArgumentException, not RuntimeException
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Value not comparable to existing values.");
                    
                    // Try to add a character value that will fail comparison
                    frequency.addValue('a');
                }

 @Test
               public void testAddValueWithNonComparableObject2() {
                   // Create a non-comparable object
                   class NonComparable {}
                   Object nonComparable = new NonComparable();
                   
                   // Create frequency object
                   Frequency frequency = new Frequency();
                   
                   // Expect exception with specific message
                   thrown.expect(IllegalArgumentException.class);
                   thrown.expectMessage("Value not comparable to existing values.");
                   
                   // Try to add non-comparable object
                   frequency.addValue(nonComparable);
               }

 @Test(expected = IllegalArgumentException.class)
               public void testAddValueWithIncompatibleType() {
                   // Create a frequency object with natural ordering
                   Frequency frequency = new Frequency();
                   
                   // Add some initial comparable values
                   frequency.addValue(1L);
                   frequency.addValue(2L);
                   
                   try {
                       // Attempt to add an incompatible object
                       frequency.addValue(new Object());
                       fail("Expected IllegalArgumentException");
                   } catch (IllegalArgumentException e) {
                       // Verify the exception message matches the original
                       assertEquals("Value not comparable to existing values.", e.getMessage());
                       throw e; // rethrow for the expected exception check
                   }
               }

 @Test
               public void testAddValueWithCustomComparator() {
                   // Create a frequency object with custom comparator
                   Frequency frequency = new Frequency(new Comparator() {
                       @Override
                       public int compare(Object o1, Object o2) {
                           // Force all comparisons to be invalid
                           throw new ClassCastException("Incomparable types");
                       }
                   });
                   
                   try {
                       frequency.addValue(1L);
                       fail("Expected IllegalArgumentException");
                   } catch (IllegalArgumentException e) {
                       // Verify the exception message matches the original
                       assertEquals("Value not comparable to existing values.", e.getMessage());
                   }
               }

 @Test
               public void testAddValueWithIncomparableObjectShouldThrowCorrectException() {
                   // Create a Frequency instance with a custom comparator
                   Frequency frequency = new Frequency((o1, o2) -> {
                       // Force comparison to fail for testing
                       throw new ClassCastException("Incomparable types");
                   });
           
                   // Set up expectation for the exception
                   thrown.expect(IllegalArgumentException.class);
                   thrown.expectMessage("Value not comparable to existing values.");
           
                   // Try to add a value that will trigger the exception
                   frequency.addValue(new Object() {
                       // Anonymous object that will fail comparison
                       @Override
                       public String toString() {
                           return "TestObject";
                       }
                   });
               }

 @Test
               public void testAddValueWithNonComparableObject3() {
                   Frequency frequency = new Frequency();
                   
                   // First add a comparable value to initialize the map
                   frequency.addValue(1L);
                   
                   try {
                       // Create a non-comparable object
                       Object nonComparable = new Object();
                       frequency.addValue(nonComparable);
                       fail("Expected IllegalArgumentException to be thrown");
                   } catch (IllegalArgumentException e) {
                       // Verify the exact exception message matches the original
                       assertEquals("Value not comparable to existing values.", e.getMessage());
                   }
               }

 @Test
           public void testAddValueWithNonComparableObjectShouldThrowCorrectExceptionMessage() {
               // Create a Frequency instance with a custom comparator that makes certain values non-comparable
               Frequency frequency = new Frequency(new Comparator<Object>() {
                   @Override
                   public int compare(Object o1, Object o2) {
                       if (o1 instanceof Character && o2 instanceof Integer) {
                           throw new ClassCastException("Cannot compare Character with Integer");
                       }
                       return ((Comparable<Object>) o1).compareTo(o2);
                   }
               });
               
               // First add an Integer value to the frequency table
               frequency.addValue(Integer.valueOf(1));
               
               try {
                   // Then try to add a Character value which should be non-comparable with the existing Integer
                   frequency.addValue(Character.valueOf('a'));
                   fail("Expected IllegalArgumentException to be thrown");
               } catch (IllegalArgumentException e) {
                   // Verify both the exception type and exact message
                   assertEquals("Expected different exception message", 
                                "Value not comparable to existing values.", 
                                e.getMessage());
               }
           }

 @Test
          public void testAddValueComparable_ShouldThrowExceptionWithCorrectMessage() {
              // Setup
              Frequency frequency = new Frequency();
              frequency.addValue(1); // Add an Integer first
              
              try {
                  // Attempt to add incompatible type
                  frequency.addValue(new java.math.BigDecimal("1.0"));
                  fail("Expected IllegalArgumentException to be thrown");
              } catch (IllegalArgumentException e) {
                  // Verify both the exception type and message
                  assertEquals("Value not comparable to existing values.", e.getMessage());
              }
          }

 @Test
          public void testAddValueLong() {
              // Setup
              Frequency frequency = new Frequency();
              Long testValue = 12345L;
              
              // Verify initial state
              assertEquals(0L, frequency.getCount(testValue));
              
              // Test method
              frequency.addValue(testValue);
              
              // Verify the value was added
              assertEquals(1L, frequency.getCount(testValue));
              
              // Add same value again
              frequency.addValue(testValue);
              
              // Verify count increased
              assertEquals(2L, frequency.getCount(testValue));
              
              // Verify other values unaffected
              assertEquals(0L, frequency.getCount(99999L));
          }

 @Test
      public void testAddValueLongCompletesExecutionAndUpdatesFrequency() {
          // Setup
          Frequency frequency = new Frequency();
          long testValue = 12345L;
          
          // Action
          frequency.addValue(testValue);
          
          // Verification
          // Verify the value was added to freqTable
          assertEquals(1L, frequency.getCount(testValue));
          // Verify sum frequency is updated
          assertEquals(1L, frequency.getSumFreq());
          
          // Add another value to verify proper counting
          frequency.addValue(testValue);
          assertEquals(2L, frequency.getCount(testValue));
          assertEquals(2L, frequency.getSumFreq());
          
          // Verify with a different value
          long anotherValue = 67890L;
          frequency.addValue(anotherValue);
          assertEquals(1L, frequency.getCount(anotherValue));
          assertEquals(3L, frequency.getSumFreq());
      }

 @Test
          public void testAddValueChar() {
              // Setup
              Frequency frequency = new Frequency();
              char testChar = 'a';
              
              // Test single addition
              frequency.addValue(testChar);
              assertEquals(1L, frequency.getCount(testChar));
              
              // Test multiple additions
              frequency.addValue(testChar);
              frequency.addValue(testChar);
              assertEquals(3L, frequency.getCount(testChar));
              
              // Test with different character
              char anotherChar = 'b';
              frequency.addValue(anotherChar);
              assertEquals(1L, frequency.getCount(anotherChar));
              assertEquals(3L, frequency.getCount(testChar)); // Verify previous count remains
              
              // Verify the total frequency count
              assertEquals(4L, frequency.getSumFreq());
          }

 @Test
     public void testAddValueComparable() {
         // Setup
         Frequency frequency = new Frequency();
         Comparable<String> testValue = "testValue";
         
         // Test adding a value
         frequency.addValue(testValue);
         
         // Verify the value was added with count 1
         assertEquals("Count should be 1 after first addition", 
                      1L, frequency.getCount(testValue));
         
         // Test adding the same value again
         frequency.addValue(testValue);
         
         // Verify the count was incremented to 2
         assertEquals("Count should be 2 after second addition", 
                      2L, frequency.getCount(testValue));
     }

 @Test
     public void testAddValueWithNewInteger() {
         // Initialize Frequency object
         Frequency frequency = new Frequency();
         
         // Use reflection to access private freqTable field for verification
         TreeMap<Long, Long> freqTable;
         try {
             Field field = Frequency.class.getDeclaredField("freqTable");
             field.setAccessible(true);
             freqTable = (TreeMap<Long, Long>) field.get(frequency);
         } catch (Exception e) {
             throw new RuntimeException("Failed to access freqTable field", e);
         }
         
         // Test Integer input conversion and new entry
         frequency.addValue(5);
         assertEquals(Long.valueOf(1), freqTable.get(Long.valueOf(5)));
     }

 @Test
     public void testAddValueWithExistingInteger() {
         // Create Frequency instance and get its freqTable via reflection
         Frequency frequency = new Frequency();
         TreeMap<Long, Long> freqTable;
         try {
             Field field = Frequency.class.getDeclaredField("freqTable");
             field.setAccessible(true);
             freqTable = (TreeMap<Long, Long>) field.get(frequency);
         } catch (Exception e) {
             throw new RuntimeException("Failed to access freqTable field", e);
         }
         
         // Test Integer input and existing entry update
         freqTable.put(Long.valueOf(5), Long.valueOf(2));
         frequency.addValue(5);
         assertEquals(Long.valueOf(3), freqTable.get(Long.valueOf(5)));
     }

 @Test
     public void testAddValueWithNewLong() {
         // Initialize frequency object
         Frequency frequency = new Frequency();
         
         // Test direct Long input
         frequency.addValue(Long.valueOf(10));
         
         // Get the frequency count for value 10
         long count = frequency.getCount(Long.valueOf(10));
         
         // Verify the count is 1
         assertEquals(1L, count);
     }

 @Test
     public void testAddValueWithExistingLong() {
         // Test Long input and existing entry update
         Frequency frequency = new Frequency();
         TreeMap<Long, Long> freqTable = new TreeMap<>();
         
         // Use reflection to set the private freqTable field
         try {
             Field field = Frequency.class.getDeclaredField("freqTable");
             field.setAccessible(true);
             field.set(frequency, freqTable);
         } catch (Exception e) {
             fail("Failed to set freqTable field via reflection");
         }
         
         freqTable.put(Long.valueOf(10), Long.valueOf(3));
         frequency.addValue(Long.valueOf(10));
         assertEquals(Long.valueOf(4), freqTable.get(Long.valueOf(10)));
     }

 @Test(expected = ClassCastException.class)
     public void testAddValueWithNonComparable1() {
         // Test non-comparable object
         Frequency frequency = new Frequency();
         frequency.addValue(new Object());
     }

 @Test
     public void testAddValueWithNull() {
         // Create a new Frequency instance
         Frequency frequency = new Frequency();
         
         // Test null input
         try {
             frequency.addValue(null);
             fail("Expected IllegalArgumentException");
         } catch (IllegalArgumentException e) {
             assertEquals("Value not comparable to existing values.", e.getMessage());
         }
     }

 @Test
     public void testAddValueLongShouldUpdateFrequencyTable() {
         // Setup
         Frequency frequency = new Frequency();
         long testValue = 12345L;
         
         // Action
         frequency.addValue(testValue);
         
         // Verification
         // Verify the value was added to the freqTable
         try {
             Field field = Frequency.class.getDeclaredField("freqTable");
             field.setAccessible(true);
             @SuppressWarnings("unchecked")
             TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
             assertTrue("Frequency table should contain the test value", 
                 freqTable.containsKey(testValue));
             
             // Verify the count is 1
             assertEquals("Count for test value should be 1", 
                 1L, frequency.getCount(testValue));
             
             // Verify the sum frequency is updated
             assertEquals("Total frequency count should be 1", 
                 1L, frequency.getSumFreq());
         } catch (NoSuchFieldException | IllegalAccessException e) {
             fail("Failed to access freqTable field: " + e.getMessage());
         }
     }

 @Test
     public void testAddValueComparable1() {
         // Setup
         Frequency frequency = new Frequency();
         String testValue = "test";
         
         // Test adding a comparable value
         frequency.addValue((Comparable<?>) testValue);
         
         // Verify the value was added correctly
         assertEquals(1L, frequency.getCount(testValue));
         assertEquals(1L, frequency.getSumFreq());
         
         // Test adding the same value again
         frequency.addValue((Comparable<?>) testValue);
         assertEquals(2L, frequency.getCount(testValue));
         assertEquals(2L, frequency.getSumFreq());
         
         // Test adding a different comparable value
         String anotherValue = "another";
         frequency.addValue((Comparable<?>) anotherValue);
         assertEquals(1L, frequency.getCount(anotherValue));
         assertEquals(3L, frequency.getSumFreq());
     }

 @Test
     public void testAddValueComparableWithComparator() {
         // Setup with custom comparator
         Frequency frequency = new Frequency(Comparator.reverseOrder());
         String testValue = "test";
         
         // Test adding a comparable value
         frequency.addValue((Comparable<?>) testValue);
         
         // Verify the value was added correctly
         assertEquals(1L, frequency.getCount(testValue));
         assertEquals(1L, frequency.getSumFreq());
     }

 @Test(expected = IllegalArgumentException.class)
     public void testAddValueWithNonComparableObject4() {
         // Setup
         Frequency frequency = new Frequency();
         Object nonComparable = new Object(); // Object is not Comparable
         
         try {
             // Exercise
             frequency.addValue(nonComparable);
             fail("Expected IllegalArgumentException but none was thrown");
         } catch (IllegalArgumentException e) {
             // Verify
             assertEquals("Value not comparable to existing values.", e.getMessage());
             throw e;
         }
     }

 @Test
     public void testAddValueWithComparableObject1() {
         // Setup
         Frequency frequency = new Frequency();
         String comparable = "test"; // String is Comparable
         
         // Exercise
         frequency.addValue(comparable);
         
         // Verify
         assertEquals(1L, frequency.getCount(comparable));
     }

 @Test
     public void testAddValueWithInteger() {
         // Setup
         Frequency frequency = new Frequency();
         Integer integerValue = 5;
         
         // Exercise
         frequency.addValue(integerValue);
         
         // Verify - should be stored as Long
         assertEquals(1L, frequency.getCount(Long.valueOf(integerValue)));
     }

 @Test
     public void testAddValueLong1() {
         // Setup
         Frequency frequency = new Frequency();
         long testValue = 12345L;
         
         // Test single addition
         frequency.addValue(testValue);
         assertEquals("Count should be 1 after first addition", 
                      1L, frequency.getCount(testValue));
         
         // Test multiple additions
         frequency.addValue(testValue);
         frequency.addValue(testValue);
         assertEquals("Count should be 3 after three additions", 
                      3L, frequency.getCount(testValue));
         
         // Test with different value
         long anotherValue = 67890L;
         frequency.addValue(anotherValue);
         assertEquals("Count should be 1 for new value", 
                      1L, frequency.getCount(anotherValue));
         assertEquals("Original value count should remain 3", 
                      3L, frequency.getCount(testValue));
     }

 @Test
     public void testAddValueLong2() {
         // Setup
         Frequency frequency = new Frequency();
         Long testValue = 12345L;
         
         // Verify initial state
         assertEquals(0, frequency.getCount(testValue));
         assertEquals(0, frequency.getSumFreq());
         
         // Test the method
         frequency.addValue(testValue);
         
         // Verify post conditions
         assertEquals(1, frequency.getCount(testValue));
         assertEquals(1, frequency.getSumFreq());
         
         // Add same value again
         frequency.addValue(testValue);
         assertEquals(2, frequency.getCount(testValue));
         assertEquals(2, frequency.getSumFreq());
         
         // Add different value
         Long anotherValue = 67890L;
         frequency.addValue(anotherValue);
         assertEquals(1, frequency.getCount(anotherValue));
         assertEquals(3, frequency.getSumFreq());
     }

 @Test
     public void testAddValueLong3() {
         // Setup
         Frequency frequency = new Frequency();
         long testValue = 42L;
         
         // Action
         frequency.addValue(testValue);
         
         // Verification
         // Verify the count for the added value is 1
         assertEquals(1, frequency.getCount(testValue));
         
         // Verify the sum frequency is correct
         assertEquals(1, frequency.getSumFreq());
         
         // Add another value and verify both counts
         frequency.addValue(testValue);
         assertEquals(2, frequency.getCount(testValue));
         assertEquals(2, frequency.getSumFreq());
         
         // Add a different value and verify counts
         frequency.addValue(99L);
         assertEquals(1, frequency.getCount(99L));
         assertEquals(3, frequency.getSumFreq());
     }

 @Test
 public void testAddValueChar1() {
     // Setup
     Frequency frequency = new Frequency();
     char testChar = 'a';
     
     // Action
     frequency.addValue(testChar);
     
     // Verification
     // Verify the character was added to the frequency table
     assertEquals(1L, frequency.getCount(testChar));
     
     // Verify no other values were added
     assertEquals(1L, frequency.getSumFreq());
     
     // Add same character again and verify count increases
     frequency.addValue(testChar);
     assertEquals(2L, frequency.getCount(testChar));
     assertEquals(2L, frequency.getSumFreq());
     
     // Add different character and verify separate counting
     char anotherChar = 'b';
     frequency.addValue(anotherChar);
     assertEquals(1L, frequency.getCount(anotherChar));
     assertEquals(3L, frequency.getSumFreq());
     assertEquals(2L, frequency.getCount(testChar)); // original count remains
 }

}
