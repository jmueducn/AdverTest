package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class ArrayRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                       public void testGetLInfNorm_SinglePositiveElement() {
                                                           ArrayRealVector vector = new ArrayRealVector(new double[]{5.0});
                                                           assertEquals(5.0, vector.getLInfNorm(), 0.0001);
                                                       }

 @Test
                                                       public void testGetLInfNorm_SingleNegativeElement() {
                                                           ArrayRealVector vector = new ArrayRealVector(new double[]{-3.0});
                                                           assertEquals(3.0, vector.getLInfNorm(), 0.0001);
                                                       }

 @Test
                                                       public void testGetLInfNorm_MultipleElementsAllPositive() {
                                                           ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.5, 3.0, 0.5});
                                                           assertEquals(3.0, vector.getLInfNorm(), 0.0001);
                                                       }

 @Test
                                                       public void testGetLInfNorm_MultipleElementsAllNegative() {
                                                           ArrayRealVector vector = new ArrayRealVector(new double[]{-1.0, -2.5, -3.0, -0.5});
                                                           assertEquals(3.0, vector.getLInfNorm(), 0.0001);
                                                       }

 @Test
                                                       public void testGetLInfNorm_MixedPositiveNegativeElements() {
                                                           ArrayRealVector vector = new ArrayRealVector(new double[]{-1.0, 2.5, -3.0, 0.5});
                                                           assertEquals(3.0, vector.getLInfNorm(), 0.0001);
                                                       }

 @Test
                                                       public void testGetLInfNorm_WithZeroElements() {
                                                           ArrayRealVector vector = new ArrayRealVector(new double[]{0.0, 0.0, 0.0});
                                                           assertEquals(0.0, vector.getLInfNorm(), 0.0001);
                                                       }

 @Test
                                                       public void testGetLInfNorm_WithLargeValues() {
                                                           ArrayRealVector vector = new ArrayRealVector(new double[]{Double.MAX_VALUE, -Double.MAX_VALUE});
                                                           assertEquals(Double.MAX_VALUE, vector.getLInfNorm(), 0.0001);
                                                       }

 @Test
                                                       public void testGetLInfNorm_WithSmallValues() {
                                                           ArrayRealVector vector = new ArrayRealVector(new double[]{Double.MIN_VALUE, -Double.MIN_VALUE});
                                                           assertEquals(Double.MIN_VALUE, vector.getLInfNorm(), 0.0001);
                                                       }

 @Test
                                                       public void testGetLInfNorm_WithNaNValues() {
                                                           ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, Double.NaN, 2.0});
                                                           assertTrue(Double.isNaN(vector.getLInfNorm()));
                                                       }

 @Test
                                                       public void testGetLInfNorm_WithInfiniteValues() {
                                                           ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, Double.POSITIVE_INFINITY, -2.0});
                                                           assertEquals(Double.POSITIVE_INFINITY, vector.getLInfNorm(), 0.0001);
                                                       }

 @Test
                                                       public void testGetLInfNorm_AfterModification() {
                                                           ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.0, 3.0});
                                                           assertEquals(3.0, vector.getLInfNorm(), 0.0001);
                                                           
                                                           vector.setEntry(1, 5.0); // Modify the vector
                                                           assertEquals(5.0, vector.getLInfNorm(), 0.0001);
                                                       }

 @Test
                                               public void testMapInvToSelf_WithPositiveValues() {
                                                   // Test with positive values
                                                   double[] input = {1.0, 2.0, 4.0, 8.0};
                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                   
                                                   RealVector result = vector.mapInvToSelf();
                                                   
                                                   // Verify the vector was modified in place
                                                   assertSame(vector, result);
                                                   
                                                   // Verify each element was inverted correctly
                                                   assertArrayEquals(new double[]{1.0, 0.5, 0.25, 0.125}, ((ArrayRealVector)result).getData(), 0.0001);
                                               }

 @Test
                                               public void testMapInvToSelf_WithNegativeValues() {
                                                   // Test with negative values
                                                   double[] input = {-1.0, -2.0, -4.0};
                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                   
                                                   // mapInvToSelf returns RealVector, so we'll use that type
                                                   RealVector result = vector.mapInvToSelf();
                                                   
                                                   assertArrayEquals(new double[]{-1.0, -0.5, -0.25}, result.getData(), 0.0001);
                                               }

 @Test
                                               public void testMapInvToSelf_WithMixedValues() {
                                                   // Test with mixed positive and negative values
                                                   double[] input = {1.0, -2.0, 0.5, -0.25};
                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                   
                                                   // mapInvToSelf returns RealVector but modifies the vector in place
                                                   vector.mapInvToSelf();
                                                   
                                                   assertArrayEquals(new double[]{1.0, -0.5, 2.0, -4.0}, vector.getData(), 0.0001);
                                               }

 @Test
                                               public void testMapInvToSelf_WithZeroValue() {
                                                   // Test with zero value (should throw exception)
                                                   double[] input = {1.0, 0.0, 2.0};
                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                   
                                                   try {
                                                       vector.mapInvToSelf();
                                                       fail("Expected ArithmeticException");
                                                   } catch (ArithmeticException e) {
                                                       assertEquals("/ by zero", e.getMessage());
                                                   }
                                               }

 @Test
                                               public void testMapInvToSelf_WithEmptyVector() {
                                                   // Test with empty vector
                                                   double[] input = {};
                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                   
                                                   RealVector result = vector.mapInvToSelf();
                                                   
                                                   assertSame(vector, result);
                                                   assertEquals(0, result.getDimension());
                                               }

 @Test
                                               public void testMapInvToSelf_WithSpecialDoubleValues() {
                                                   // Test with special double values (Infinity, NaN)
                                                   double[] input = {Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NaN};
                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                   
                                                   RealVector result = vector.mapInvToSelf();
                                                   
                                                   assertEquals(0.0, result.getEntry(0), 0.0001);
                                                   assertEquals(-0.0, result.getEntry(1), 0.0001);
                                                   assertTrue(Double.isNaN(result.getEntry(2)));
                                               }

 @Test
                                               public void testMapInvToSelf_WithVerySmallValues() {
                                                   // Test with very small values that could cause overflow
                                                   double[] input = {Double.MIN_VALUE, -Double.MIN_VALUE};
                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                   
                                                   RealVector result = vector.mapInvToSelf();
                                                   
                                                   assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0001);
                                                   assertEquals(Double.NEGATIVE_INFINITY, result.getEntry(1), 0.0001);
                                               }

 @Test
                                               public void testMapInvToSelf_WithVeryLargeValues() {
                                                   // Test with very large values that could cause underflow
                                                   double[] input = {Double.MAX_VALUE, -Double.MAX_VALUE};
                                                   ArrayRealVector vector = new ArrayRealVector(input);
                                                   
                                                   RealVector result = vector.mapInvToSelf();
                                                   
                                                   assertEquals(0.0, result.getEntry(0), 0.0001);
                                                   assertEquals(-0.0, result.getEntry(1), 0.0001);
                                               }

 @Test
                                               public void testMapInvToSelf_VerifiesInPlaceModification() {
                                                   // Verify that the original data array is modified in place
                                                   double[] input = {1.0, 2.0, 3.0};
                                                   ArrayRealVector vector = new ArrayRealVector(input, false); // don't copy array
                                                   
                                                   RealVector result = vector.mapInvToSelf();
                                                   
                                                   // Verify the input array was modified
                                                   assertArrayEquals(new double[]{1.0, 0.5, 1.0/3.0}, input, 0.0001);
                                               }

 @Test
                                               public void testGetLInfNorm_EmptyVector() {
                                                   org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                   exceptionRule.expect(IllegalArgumentException.class);
                                                   exceptionRule.expectMessage("vector must have at least one element");
                                                   ArrayRealVector vector = new ArrayRealVector(new double[0]);
                                                   vector.getLInfNorm();
                                               }

 @Test
                                               public void testMapAtanToSelfDoesNotThrowArrayIndexOutOfBounds() {
                                                   // Create a vector with some test data
                                                   double[] testData = {0.5, 1.0, 1.5};
                                                   ArrayRealVector vector = new ArrayRealVector(testData);
                                                   
                                                   try {
                                                       // This should not throw an exception with original code
                                                       vector.mapAtanToSelf();
                                                       
                                                       // If we get here, the test passes (original behavior)
                                                       // Also verify the transformation was applied correctly
                                                       double[] result = vector.getData();
                                                       assertEquals(testData.length, result.length);
                                                       for (int i = 0; i < testData.length; i++) {
                                                           assertEquals(Math.atan(testData[i]), result[i], 0.0001);
                                                       }
                                                   } catch (ArrayIndexOutOfBoundsException e) {
                                                       // If we catch this, the mutant was detected
                                                       fail("ArrayIndexOutOfBoundsException was thrown, indicating the mutant was detected");
                                                   }
                                               }

 @Test
                                              public void testMapAtanToSelfProcessesFirstElement() {
                                                  // Create a vector with known values
                                                  double[] testData = {1.0, 2.0, 3.0}; // First element is 1.0
                                                  ArrayRealVector vector = new ArrayRealVector(testData);
                                                  
                                                  // Store original first element for comparison
                                                  double originalFirstElement = vector.getEntry(0);
                                                  
                                                  // Apply the transformation
                                                  vector.mapAtanToSelf();
                                                  
                                                  // Verify first element was processed (changed from original)
                                                  assertNotEquals("First element should be processed (atan applied)", 
                                                                 originalFirstElement, 
                                                                 vector.getEntry(0), 
                                                                 0.0001);
                                                  
                                                  // Additional verification that the value is indeed atan of original
                                                  assertEquals("First element should be Math.atan(1.0)", 
                                                              Math.atan(1.0), 
                                                              vector.getEntry(0), 
                                                              0.0001);
                                              }

 @Test
                                         public void testMapAtanToSelfProcessesAllElements() {
                                             // Create test data with at least 2 elements
                                             double[] testData = {1.0, 2.0, 3.0}; // Using 3 elements to be thorough
                                             ArrayRealVector vector = new ArrayRealVector(testData);
                                             
                                             // Store original values for comparison
                                             double originalFirst = testData[0];
                                             double originalMiddle = testData[1];
                                             double originalLast = testData[2];
                                             
                                             // Apply the transformation
                                             vector.mapAtanToSelf();
                                             
                                             // Verify all elements were processed
                                             // First element
                                             assertEquals(Math.atan(originalFirst), vector.getEntry(0), 0.0001);
                                             // Middle element
                                             assertEquals(Math.atan(originalMiddle), vector.getEntry(1), 0.0001);
                                             // Last element - this will fail for the mutant
                                             assertEquals(Math.atan(originalLast), vector.getEntry(2), 0.0001);
                                             
                                             // Additional check for method chaining
                                             assertSame(vector, vector.mapAtanToSelf());
                                         }

 @Test
                                            public void testMapAtanToSelfProcessesAllElements1() {
                                                // Create test data with distinct values at all positions
                                                double[] testData = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                ArrayRealVector vector = new ArrayRealVector(testData);
                                                
                                                // Store original values for comparison
                                                double[] originalData = testData.clone();
                                                
                                                // Apply the transformation
                                                vector.mapAtanToSelf();
                                                
                                                // Get the transformed data
                                                double[] transformedData = vector.getData();
                                                
                                                // Verify ALL elements were transformed
                                                for (int i = 0; i < originalData.length; i++) {
                                                    assertEquals(Math.atan(originalData[i]), transformedData[i], 0.0001);
                                                }
                                                
                                                // Also verify the return value is the same object (for chaining)
                                                assertSame(vector, vector.mapAtanToSelf());
                                            }

 @Test
                                      public void testMapAtanToSelf() {
                                          // Create test data where atan and asin produce different results
                                          double[] testData = {0.5, -0.5, 0.0, 0.707}; // values where atan != asin
                                          ArrayRealVector vector = new ArrayRealVector(testData);
                                          
                                          // Expected results using Math.atan
                                          double[] expected = new double[testData.length];
                                          for (int i = 0; i < testData.length; i++) {
                                              expected[i] = Math.atan(testData[i]);
                                          }
                                          
                                          // Apply the operation - changed to use RealVector as the return type
                                          RealVector result = vector.mapAtanToSelf();
                                          
                                          // Verify the vector was modified correctly
                                          assertArrayEquals(expected, result.getData(), 1e-10);
                                          
                                          // Verify the original vector was modified in place
                                          assertArrayEquals(expected, vector.getData(), 1e-10);
                                          
                                          // Verify the returned object is the same instance
                                          assertSame(vector, result);
                                      }

 @Test
                                 public void testMapAtanToSelfDetectsNegativeMutant() {
                                     // Create test data with values that will show the difference
                                     double[] testData = {1.0, 0.5, -0.5, -1.0, 0.0}; // Include positive, negative and zero
                                     ArrayRealVector vector = new ArrayRealVector(testData);
                                     
                                     // Make a copy of original data for comparison
                                     double[] originalData = testData.clone();
                                     
                                     // Apply the operation - changed to use RealVector as return type
                                     RealVector result = vector.mapAtanToSelf();
                                     
                                     // Verify each element was transformed correctly
                                     for (int i = 0; i < originalData.length; i++) {
                                         double expected = Math.atan(originalData[i]);
                                         double actual = result.getEntry(i);
                                         assertEquals("Element at index " + i + " should be atan of original value", 
                                                      expected, actual, 1e-10);
                                     }
                                     
                                     // Additional check: verify the result is the same object (for method chaining)
                                     assertSame("Method should return the same object", vector, result);
                                 }

 @Test
                                 public void testMapAtanToSelfDetectsMutant() {
                                     // Create test data where atan(x) is significantly different from atan(x+1)
                                     double[] testData = {0.0, 1.0, -1.0, 10.0, -10.0};
                                     ArrayRealVector vector = new ArrayRealVector(testData.clone());
                                     
                                     // Call the method
                                     vector.mapAtanToSelf();
                                     
                                     // Verify each element was transformed correctly
                                     double[] expected = new double[testData.length];
                                     for (int i = 0; i < testData.length; i++) {
                                         expected[i] = Math.atan(testData[i]);
                                     }
                                     
                                     // This will fail if the mutant is present because:
                                     // - For testData[0] (0.0): atan(0) = 0 vs atan(1) ≈ 0.785
                                     // - For testData[1] (1.0): atan(1) ≈ 0.785 vs atan(2) ≈ 1.107
                                     // - etc.
                                     assertArrayEquals(expected, vector.getData(), 0.0001);
                                 }

 @Test
                           public void testMapAtanToSelfDetectsMultiplicationMutant() {
                               // Create test data with values that will show difference between atan(x) and atan(2x)
                               double[] testData = {0.5, 1.0, -0.5, -1.0};
                               ArrayRealVector vector = new ArrayRealVector(testData);
                               
                               // Calculate expected results using original formula
                               double[] expected = new double[testData.length];
                               for (int i = 0; i < testData.length; i++) {
                                   expected[i] = Math.atan(testData[i]);
                               }
                               
                               // Call the method under test and cast the result
                               ArrayRealVector result = (ArrayRealVector) vector.mapAtanToSelf();
                               
                               // Verify the vector was modified correctly
                               assertArrayEquals(expected, result.getData(), 1e-15);
                               
                               // Additional check that the returned object is the same instance
                               assertSame(vector, result);
                           }

 @Test
                  public void testMapAtanToSelfDetectsMutant1() {
                      // Create test data with various values (positive, negative, zero)
                      double[] testData = {1.0, -0.5, 0.0, 2.5, -1.5};
                      ArrayRealVector vector = new ArrayRealVector(testData);
                      
                      // Store expected results (Math.atan of each original value)
                      double[] expected = new double[testData.length];
                      for (int i = 0; i < testData.length; i++) {
                          expected[i] = Math.atan(testData[i]);
                      }
                      
                      // Call the method - now properly handling the RealVector return type
                      RealVector result = vector.mapAtanToSelf();
                      
                      // Verify:
                      // 1. The returned object is the same instance (for method chaining)
                      assertSame(vector, result);
                      
                      // 2. Each element was transformed correctly (not all set to Math.atan(0))
                      double[] actual = ((ArrayRealVector)result).getData();
                      for (int i = 0; i < expected.length; i++) {
                          assertEquals("Element at index " + i + " was not transformed correctly",
                                      expected[i], actual[i], 0.0001);
                      }
                      
                      // Additional check that not all elements are 0.0 (would happen with mutant)
                      boolean allZero = true;
                      for (double value : actual) {
                          if (value != 0.0) {
                              allZero = false;
                              break;
                          }
                      }
                      assertFalse("All elements were set to Math.atan(0) - mutant detected", allZero);
                  }

 @Test
                  public void testMapAtanToSelfDetectsMutant2() {
                      // Create test data with values where atan(x) differs significantly from atan(1/x)
                      double[] testData = {1.0, -1.0, 0.5, -0.5, 2.0, -2.0};
                      ArrayRealVector vector = new ArrayRealVector(testData);
                      
                      // Make a copy for comparison
                      double[] originalData = testData.clone();
                      
                      // Apply the operation
                      vector.mapAtanToSelf();
                      
                      // Verify each element was transformed correctly
                      for (int i = 0; i < originalData.length; i++) {
                          double expected = Math.atan(originalData[i]);
                          double actual = vector.getEntry(i);
                          assertEquals("Element at index " + i + " should be Math.atan of original value", 
                                       expected, actual, 1e-10);
                      }
                      
                      // Specifically test x=1 case where difference is most obvious
                      // atan(1) = π/4 ≈ 0.785398
                      // atan(1/1) = atan(1) = π/4 (same in this case, but other values differ)
                      // So we need to test with values where atan(x) != atan(1/x)
                      double testValue = 0.5;
                      double expectedAtan = Math.atan(testValue);
                      double mutantAtan = Math.atan(1/testValue);
                      assertNotEquals("This assertion verifies our test can detect the mutant", 
                                      mutantAtan, expectedAtan, 1e-10);
                  }

 @Test
            public void testMapAtanToSelfReturnsThis() {
                // Create test data
                double[] testData = {0.5, 1.0, 1.5};
                ArrayRealVector vector = new ArrayRealVector(testData);
                
                // Call the method and capture return value
                RealVector result = vector.mapAtanToSelf();
                
                // Verify the method returns the same object (not null)
                assertSame("Method should return this", vector, result);
                
                // Additional verification that data was modified correctly
                double[] expectedData = new double[testData.length];
                for (int i = 0; i < testData.length; i++) {
                    expectedData[i] = Math.atan(testData[i]);
                }
                assertArrayEquals(expectedData, ((ArrayRealVector)result).getData(), 0.0001);
            }

}
