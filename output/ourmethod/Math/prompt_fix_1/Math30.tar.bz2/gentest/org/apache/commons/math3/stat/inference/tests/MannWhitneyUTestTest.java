package gentest.org.apache.commons.math3.stat.inference.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.stat.inference.*;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.stat.ranking.NaNStrategy;
import org.apache.commons.math3.stat.ranking.NaturalRanking;
import org.apache.commons.math3.stat.ranking.TiesStrategy;
import org.apache.commons.math3.util.FastMath;
 
public class MannWhitneyUTestTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
    public void testCalculateAsymptoticPValue_StandardCase() throws Exception {
        // Setup
        MannWhitneyUTest test = new MannWhitneyUTest();
        double Umin = 10;
        int n1 = 5;
        int n2 = 5;
        
        // Expected calculations
        double n1n2prod = n1 * n2;
        double EU = n1n2prod / 2.0;
        double VarU = n1n2prod * (n1 + n2 + 1) / 12.0;
        double z = (Umin - EU) / Math.sqrt(VarU);
        NormalDistribution standardNormal = new NormalDistribution(0, 1);
        double expected = 2 * standardNormal.cumulativeProbability(z);
        
        // Use reflection to access private method
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        double result = (double) method.invoke(test, Umin, n1, n2);
        
        assertEquals(expected, result, 1e-10);
    }

    @Test
    public void testCalculateAsymptoticPValue_LargeSampleSizes() throws Exception {
        // Setup
        MannWhitneyUTest test = new MannWhitneyUTest();
        double Umin = 500;
        int n1 = 50;
        int n2 = 50;
        
        // Expected calculations
        double n1n2prod = n1 * n2;
        double EU = n1n2prod / 2.0;
        double VarU = n1n2prod * (n1 + n2 + 1) / 12.0;
        double z = (Umin - EU) / Math.sqrt(VarU);
        NormalDistribution standardNormal = new NormalDistribution(0, 1);
        double expected = 2 * standardNormal.cumulativeProbability(z);
        
        // Use reflection to access private method
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        double result = (double) method.invoke(test, Umin, n1, n2);
        
        assertEquals(expected, result, 1e-10);
    }

    @Test
    public void testCalculateAsymptoticPValue_ExtremeUminValue() throws Exception {
        // Setup
        MannWhitneyUTest test = new MannWhitneyUTest();
        double Umin = 0; // Minimum possible U value
        int n1 = 10;
        int n2 = 10;
        
        // Expected calculations
        double n1n2prod = n1 * n2;
        double EU = n1n2prod / 2.0;
        double VarU = n1n2prod * (n1 + n2 + 1) / 12.0;
        double z = (Umin - EU) / Math.sqrt(VarU);
        NormalDistribution standardNormal = new NormalDistribution(0, 1);
        double expected = 2 * standardNormal.cumulativeProbability(z);
        
        // Use reflection to access private method
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        double result = (double) method.invoke(test, Umin, n1, n2);
        
        assertEquals(expected, result, 1e-10);
    }

    @Test
    public void testCalculateAsymptoticPValue_UnequalSampleSizes() throws Exception {
        // Setup
        MannWhitneyUTest test = new MannWhitneyUTest();
        double Umin = 15;
        int n1 = 5;
        int n2 = 10;
        
        // Expected calculations
        double n1n2prod = n1 * n2;
        double EU = n1n2prod / 2.0;
        double VarU = n1n2prod * (n1 + n2 + 1) / 12.0;
        double z = (Umin - EU) / Math.sqrt(VarU);
        NormalDistribution standardNormal = new NormalDistribution(0, 1);
        double expected = 2 * standardNormal.cumulativeProbability(z);
        
        // Use reflection to access private method
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        double result = (double) method.invoke(test, Umin, n1, n2);
        
        assertEquals(expected, result, 1e-10);
    }

    @Test
    public void testCalculateAsymptoticPValue_UminEqualsExpectedValue() throws Exception {
        // Setup
        MannWhitneyUTest test = new MannWhitneyUTest();
        int n1 = 8;
        int n2 = 8;
        double EU = (n1 * n2) / 2.0; // Umin equals expected value
        double Umin = EU;
        
        // Expected calculations
        double z = 0; // (Umin - EU) / sqrt(VarU) = 0
        NormalDistribution standardNormal = new NormalDistribution(0, 1);
        double expected = 2 * standardNormal.cumulativeProbability(z); // should be 1.0
        
        // Use reflection to access private method
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        // Test
        double result = (double) method.invoke(test, Umin, n1, n2);
        assertEquals(1.0, result, 1e-10);
    }

    @Test
    public void testCalculateAsymptoticPValue_ZeroSampleSize() throws Exception {
        // Setup
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        // Verify exception is thrown
        thrown.expect(IllegalArgumentException.class);
        method.invoke(test, 0.0, 0, 5);
    }

    @Test
    public void testCalculateAsymptoticPValue_NegativeSampleSize() throws Exception {
        // Setup
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        // Verify exception is thrown
        thrown.expect(IllegalArgumentException.class);
        method.invoke(test, 10.0, -1, 5);
    }

    @Test
    public void testCalculateAsymptoticPValue_NegativeUmin() throws Exception {
        // Setup
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        // Test for exception
        thrown.expect(IllegalArgumentException.class);
        method.invoke(test, -5.0, 10, 10);
    }

    @Test
    public void testCalculateAsymptoticPValue_UminLargerThanProduct() throws Exception {
        // Setup
        MannWhitneyUTest test = new MannWhitneyUTest();
        int n1 = 5;
        int n2 = 5;
        double Umin = n1 * n2 + 1; // Larger than maximum possible U value
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        // Verify exception is thrown
        thrown.expect(IllegalArgumentException.class);
        method.invoke(test, Umin, n1, n2);
    }

    @Test
    public void testCalculateAsymptoticPValue_MockedNormalDistribution() throws Exception {
        // Setup
        MannWhitneyUTest test = new MannWhitneyUTest();
        double Umin = 10;
        int n1 = 5;
        int n2 = 5;
        
        // Mock the NormalDistribution
        NormalDistribution mockNormal = mock(NormalDistribution.class);
        when(mockNormal.cumulativeProbability(anyDouble())).thenReturn(0.25);
        
        // Use reflection to inject our mock into the test instance
        Field normalDistributionField = MannWhitneyUTest.class.getDeclaredField("standardNormal");
        normalDistributionField.setAccessible(true);
        normalDistributionField.set(test, mockNormal);
        
        // Use reflection to access the private method
        Method method = MannWhitneyUTest.class.getDeclaredMethod("calculateAsymptoticPValue", 
                double.class, int.class, int.class);
        method.setAccessible(true);
        
        // Expected result with our mock behavior
        double expected = 2 * 0.25; // 0.5
        
        // Test
        double result = (double) method.invoke(test, Umin, n1, n2);
        assertEquals(expected, result, 1e-10);
        
        // Verify interaction with mock
        verify(mockNormal).cumulativeProbability(anyDouble());
    }


}
