package gentest.org.apache.commons.math.optimization.univariate.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.univariate.*;
import java.util.Arrays;
import java.util.Comparator;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.ConvergenceException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.random.RandomGenerator;
import org.apache.commons.math.optimization.GoalType;
import org.apache.commons.math.optimization.ConvergenceChecker;
import org.apache.commons.math.util.FastMath;
 
public class MultiStartUnivariateRealOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                           public void testOptimize_WithValidParameters() throws Exception {
                                                                                                                                                               // Setup
                                                                                                                                                               BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                               RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                                               UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                               
                                                                                                                                                               // Mock the behavior of the underlying optimizer
                                                                                                                                                               UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(2.5, 10.0);
                                                                                                                                                               when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                                                                                                                                                                    anyDouble(), anyDouble(), anyDouble())).thenReturn(expectedResult);
                                                                                                                                                               
                                                                                                                                                               MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                                                   new MultiStartUnivariateRealOptimizer(mockOptimizer, 5, mockGenerator);
                                                                                                                                                               
                                                                                                                                                               // Test
                                                                                                                                                               UnivariateRealPointValuePair result = optimizer.optimize(mockFunction, GoalType.MINIMIZE, 0.0, 5.0);
                                                                                                                                                               
                                                                                                                                                               // Verify
                                                                                                                                                               assertNotNull(result);
                                                                                                                                                               assertEquals(2.5, result.getPoint(), 0.0001);
                                                                                                                                                               assertEquals(10.0, result.getValue(), 0.0001);
                                                                                                                                                               verify(mockOptimizer, times(5)).optimize(eq(mockFunction), eq(GoalType.MINIMIZE), 
                                                                                                                                                                   anyDouble(), anyDouble(), anyDouble());
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testOptimize_WithInvalidRange() throws Exception {
                                                                                                                                                               // Setup
                                                                                                                                                               BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                               RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                                               UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                               
                                                                                                                                                               MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                                                   new MultiStartUnivariateRealOptimizer(mockOptimizer, 3, mockGenerator);
                                                                                                                                                               
                                                                                                                                                               // Expect exception
                                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                                               
                                                                                                                                                               // Test with invalid range (min > max)
                                                                                                                                                               optimizer.optimize(mockFunction, GoalType.MINIMIZE, 5.0, 0.0);
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testOptimize_WithZeroStarts() throws Exception {
                                                                                                                                                               // Setup
                                                                                                                                                               BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                               RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                                               UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                               
                                                                                                                                                               // Expect exception
                                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                                               
                                                                                                                                                               // Test with zero starts (should be invalid)
                                                                                                                                                               new MultiStartUnivariateRealOptimizer(mockOptimizer, 0, mockGenerator)
                                                                                                                                                                   .optimize(mockFunction, GoalType.MINIMIZE, 0.0, 5.0);
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testOptimize_WithSingleStart() throws Exception {
                                                                                                                                                               // Setup
                                                                                                                                                               BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                               RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                                               UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                               
                                                                                                                                                               // Mock single result
                                                                                                                                                               UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(3.0, 15.0);
                                                                                                                                                               when(mockOptimizer.optimize(eq(mockFunction), eq(GoalType.MAXIMIZE), 
                                                                                                                                                                    eq(1.0), eq(5.0), anyDouble())).thenReturn(expectedResult);
                                                                                                                                                               
                                                                                                                                                               MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                                                   new MultiStartUnivariateRealOptimizer(mockOptimizer, 1, mockGenerator);
                                                                                                                                                               
                                                                                                                                                               // Test
                                                                                                                                                               UnivariateRealPointValuePair result = optimizer.optimize(mockFunction, GoalType.MAXIMIZE, 1.0, 5.0);
                                                                                                                                                               
                                                                                                                                                               // Verify
                                                                                                                                                               assertNotNull(result);
                                                                                                                                                               assertEquals(3.0, result.getPoint(), 0.0001);
                                                                                                                                                               assertEquals(15.0, result.getValue(), 0.0001);
                                                                                                                                                               verify(mockOptimizer, times(1)).optimize(eq(mockFunction), eq(GoalType.MAXIMIZE), 
                                                                                                                                                                   eq(1.0), eq(5.0), anyDouble());
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testOptimize_VerifiesOptimaStorage() throws Exception {
                                                                                                                                                               // Setup
                                                                                                                                                               BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                               RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                                               UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                               
                                                                                                                                                               // Mock multiple results
                                                                                                                                                               UnivariateRealPointValuePair result1 = new UnivariateRealPointValuePair(1.0, 10.0);
                                                                                                                                                               UnivariateRealPointValuePair result2 = new UnivariateRealPointValuePair(2.0, 5.0);
                                                                                                                                                               UnivariateRealPointValuePair result3 = new UnivariateRealPointValuePair(3.0, 15.0);
                                                                                                                                                               
                                                                                                                                                               when(mockOptimizer.optimize(eq(mockFunction), eq(GoalType.MAXIMIZE), 
                                                                                                                                                                    eq(0.0), eq(5.0), anyDouble()))
                                                                                                                                                                   .thenReturn(result1)
                                                                                                                                                                   .thenReturn(result2)
                                                                                                                                                                   .thenReturn(result3);
                                                                                                                                                               
                                                                                                                                                               MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                                                   new MultiStartUnivariateRealOptimizer(mockOptimizer, 3, mockGenerator);
                                                                                                                                                               
                                                                                                                                                               // Test
                                                                                                                                                               UnivariateRealPointValuePair finalResult = optimizer.optimize(mockFunction, GoalType.MAXIMIZE, 0.0, 5.0);
                                                                                                                                                               UnivariateRealPointValuePair[] optima = optimizer.getOptima();
                                                                                                                                                               
                                                                                                                                                               // Verify
                                                                                                                                                               assertNotNull(finalResult);
                                                                                                                                                               assertEquals(3.0, finalResult.getPoint(), 0.0001); // Should be the maximum value
                                                                                                                                                               assertEquals(15.0, finalResult.getValue(), 0.0001);
                                                                                                                                                               
                                                                                                                                                               assertNotNull(optima);
                                                                                                                                                               assertEquals(3, optima.length);
                                                                                                                                                               // Verify optima are stored (order may vary depending on sorting)
                                                                                                                                                           }

    @Test
                                                                                                                                                           public void testOptimize_WithMaxEvaluations() throws Exception {
                                                                                                                                                               // Setup
                                                                                                                                                               BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                               RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                                               UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                                               
                                                                                                                                                               // Mock behavior
                                                                                                                                                               UnivariateRealPointValuePair result = new UnivariateRealPointValuePair(2.5, 10.0);
                                                                                                                                                               when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                                                                                                                                                                    anyDouble(), anyDouble(), anyDouble())).thenReturn(result);
                                                                                                                                                               
                                                                                                                                                               MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                                                   new MultiStartUnivariateRealOptimizer(mockOptimizer, 5, mockGenerator);
                                                                                                                                                               optimizer.setMaxEvaluations(100);
                                                                                                                                                               
                                                                                                                                                               // Test
                                                                                                                                                               UnivariateRealPointValuePair finalResult = optimizer.optimize(mockFunction, GoalType.MINIMIZE, 0.0, 5.0);
                                                                                                                                                               
                                                                                                                                                               // Verify
                                                                                                                                                               assertNotNull(finalResult);
                                                                                                                                                               assertTrue(optimizer.getEvaluations() <= 100);
                                                                                                                                                           }

    @Test
                                                                                                                                                   public void testOptimize_SuccessfulOptimization() throws Exception {
                                                                                                                                                       // Setup
                                                                                                                                                       @SuppressWarnings("unchecked")
                                                                                                                                                       BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                       RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                                       MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                                                                                                                                           new MultiStartUnivariateRealOptimizer(optimizer, 3, generator);
                                                                                                                                                       
                                                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                       GoalType goal = GoalType.MINIMIZE;
                                                                                                                                                       double min = 0.0;
                                                                                                                                                       double max = 10.0;
                                                                                                                                                       double startValue = 5.0;
                                                                                                                                                       
                                                                                                                                                       UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(2.0, 1.0);
                                                                                                                                                       
                                                                                                                                                       // Mock behavior
                                                                                                                                                       when(optimizer.optimize(f, goal, min, max, startValue)).thenReturn(expectedResult);
                                                                                                                                                       when(optimizer.optimize(f, goal, min, max, anyDouble())).thenReturn(expectedResult);
                                                                                                                                                       when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                                                       when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                                                       when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                                                                                                       
                                                                                                                                                       // Test
                                                                                                                                                       UnivariateRealPointValuePair result = multiStartOptimizer.optimize(f, goal, min, max, startValue);
                                                                                                                                                       
                                                                                                                                                       // Verify
                                                                                                                                                       assertEquals(expectedResult, result);
                                                                                                                                                       verify(optimizer, times(3)).optimize(f, goal, min, max, anyDouble());
                                                                                                                                                       verify(optimizer, times(3)).getEvaluations();
                                                                                                                                                       verify(optimizer, times(3)).setMaxEvaluations(anyInt());
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testOptimize_FirstOptimizationFailsButSecondSucceeds() throws Exception {
                                                                                                                                                       // Setup
                                                                                                                                                       @SuppressWarnings("unchecked")
                                                                                                                                                       BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                       RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                                       MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                                                                                                                                           new MultiStartUnivariateRealOptimizer(optimizer, 2, generator);
                                                                                                                                                       
                                                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                       GoalType goal = GoalType.MINIMIZE;
                                                                                                                                                       double min = 0.0;
                                                                                                                                                       double max = 10.0;
                                                                                                                                                       double startValue = 5.0;
                                                                                                                                                       
                                                                                                                                                       UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(2.0, 1.0);
                                                                                                                                                       
                                                                                                                                                       // Mock behavior - first attempt fails, second succeeds
                                                                                                                                                       when(optimizer.optimize(f, goal, min, max, startValue))
                                                                                                                                                           .thenThrow(new ConvergenceException());
                                                                                                                                                       when(optimizer.optimize(f, goal, min, max, anyDouble()))
                                                                                                                                                           .thenReturn(expectedResult);
                                                                                                                                                       when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                                                       when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                                                       when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                                                                                                       
                                                                                                                                                       // Test
                                                                                                                                                       UnivariateRealPointValuePair result = multiStartOptimizer.optimize(f, goal, min, max, startValue);
                                                                                                                                                       
                                                                                                                                                       // Verify
                                                                                                                                                       assertEquals(expectedResult, result);
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testOptimize_AllOptimizationsFail() throws Exception {
                                                                                                                                                       // Setup
                                                                                                                                                       @SuppressWarnings("unchecked")
                                                                                                                                                       BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                       RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                                       MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                                                                                                                                           new MultiStartUnivariateRealOptimizer(optimizer, 2, generator);
                                                                                                                                                       
                                                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                       GoalType goal = GoalType.MINIMIZE;
                                                                                                                                                       double min = 0.0;
                                                                                                                                                       double max = 10.0;
                                                                                                                                                       double startValue = 5.0;
                                                                                                                                                       
                                                                                                                                                       // Mock behavior - all attempts fail
                                                                                                                                                       when(optimizer.optimize(f, goal, min, max, anyDouble()))
                                                                                                                                                           .thenThrow(new ConvergenceException());
                                                                                                                                                       when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                                                       when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                                                       when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                                                                                                       
                                                                                                                                                       // Expect exception
                                                                                                                                                       thrown.expect(ConvergenceException.class);
                                                                                                                                                       thrown.expectMessage("no convergence with any start point");
                                                                                                                                                       
                                                                                                                                                       // Test
                                                                                                                                                       multiStartOptimizer.optimize(f, goal, min, max, startValue);
                                                                                                                                                   }

    @Test
                                                                                                                                                   public void testOptimize_FunctionEvaluationExceptionHandled() throws Exception {
                                                                                                                                                       // Setup
                                                                                                                                                       @SuppressWarnings("unchecked")
                                                                                                                                                       BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                       RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                                       MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                                                                                                                                           new MultiStartUnivariateRealOptimizer(optimizer, 2, generator);
                                                                                                                                                       
                                                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                       GoalType goal = GoalType.MINIMIZE;
                                                                                                                                                       double min = 0.0;
                                                                                                                                                       double max = 10.0;
                                                                                                                                                       double startValue = 5.0;
                                                                                                                                                       
                                                                                                                                                       UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(2.0, 1.0);
                                                                                                                                                       
                                                                                                                                                       // Mock behavior - first attempt throws FunctionEvaluationException, second succeeds
                                                                                                                                                       when(optimizer.optimize(f, goal, min, max, startValue))
                                                                                                                                                           .thenThrow(new FunctionEvaluationException(0.0));
                                                                                                                                                       when(optimizer.optimize(f, goal, min, max, anyDouble()))
                                                                                                                                                           .thenReturn(expectedResult);
                                                                                                                                                       when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                                                       when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                                                       when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                                                                                                       
                                                                                                                                                       // Test
                                                                                                                                                       UnivariateRealPointValuePair result = multiStartOptimizer.optimize(f, goal, min, max, startValue);
                                                                                                                                                       
                                                                                                                                                       // Verify
                                                                                                                                                       assertEquals(expectedResult, result);
                                                                                                                                                       assertNull(multiStartOptimizer.getOptima()[0]);
                                                                                                                                                       assertNotNull(multiStartOptimizer.getOptima()[1]);
                                                                                                                                                   }

    @Test
                                                                                                                                               public void testOptimize_EvaluationsTracking() throws Exception {
                                                                                                                                                   // Setup
                                                                                                                                                   @SuppressWarnings("unchecked")
                                                                                                                                                   BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                                   RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                                   MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                                                                                                                                       new MultiStartUnivariateRealOptimizer(optimizer, 3, generator);
                                                                                                                                                   
                                                                                                                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                   GoalType goal = GoalType.MINIMIZE;
                                                                                                                                                   double min = 0.0;
                                                                                                                                                   double max = 10.0;
                                                                                                                                                   double startValue = 5.0;
                                                                                                                                                   
                                                                                                                                                   UnivariateRealPointValuePair resultPair = new UnivariateRealPointValuePair(2.0, 1.0);
                                                                                                                                                   
                                                                                                                                                   // Mock behavior
                                                                                                                                                   when(optimizer.optimize(f, goal, min, max, anyDouble())).thenReturn(resultPair);
                                                                                                                                                   when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                                                   when(optimizer.getEvaluations()).thenReturn(15, 20, 10); // Different evaluation counts
                                                                                                                                                   when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                                                                                                   
                                                                                                                                                   // Test
                                                                                                                                                   multiStartOptimizer.optimize(f, goal, min, max, startValue);
                                                                                                                                                   
                                                                                                                                                   // Verify total evaluations
                                                                                                                                                   assertEquals(45, multiStartOptimizer.getEvaluations());
                                                                                                                                                   
                                                                                                                                                   // Verify max evaluations was updated correctly
                                                                                                                                                   verify(optimizer).setMaxEvaluations(100 - 15);
                                                                                                                                                   verify(optimizer).setMaxEvaluations(85 - 20);
                                                                                                                                                   verify(optimizer).setMaxEvaluations(65 - 10);
                                                                                                                                               }

    @Test
                                                                                                                                      public void testOptimizeLoopIterationCount() throws Exception {
                                                                                                                                          // Setup
                                                                                                                                          final int starts = 5;
                                                                                                                                          final double min = 0.0;
                                                                                                                                          final double max = 1.0;
                                                                                                                                          final double startValue = 0.5;
                                                                                                                                          
                                                                                                                                          // Mock dependencies
                                                                                                                                          @SuppressWarnings("unchecked")
                                                                                                                                          BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                          RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                                                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                          
                                                                                                                                          // Configure mocks
                                                                                                                                          when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                                                                                                                                               eq(min), eq(max), anyDouble()))
                                                                                                                                              .thenReturn(new UnivariateRealPointValuePair(0.5, 0.0));
                                                                                                                                          when(mockOptimizer.getEvaluations()).thenReturn(10);
                                                                                                                                          when(mockGenerator.nextDouble()).thenReturn(0.1, 0.2, 0.3, 0.4);
                                                                                                                                          
                                                                                                                                          // Create test instance
                                                                                                                                          MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                              new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                                                                                                                                          
                                                                                                                                          // Execute
                                                                                                                                          optimizer.optimize(mockFunction, GoalType.MINIMIZE, min, max, startValue);
                                                                                                                                          
                                                                                                                                          // Verify exact number of iterations
                                                                                                                                          verify(mockOptimizer, times(starts)).optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                                                                                                                                              anyDouble(), anyDouble(), anyDouble());
                                                                                                                                          
                                                                                                                                          // Verify total evaluations matches expected iterations
                                                                                                                                          assertEquals(starts * 10, optimizer.getEvaluations());
                                                                                                                                      }

    @Test
                                                                                                                                  public void testOptimizePerformsExactNumberOfStarts() {
                                                                                                                                      // Arrange
                                                                                                                                      final int TEST_STARTS = 5;
                                                                                                                                      BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                                      RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                      MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, TEST_STARTS, mockRandom);
                                                                                                                                      
                                                                                                                                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                                      GoalType goal = GoalType.MAXIMIZE;
                                                                                                                                      double min = 0.0;
                                                                                                                                      double max = 10.0;
                                                                                                                                      
                                                                                                                                      try {
                                                                                                                                          // Mock the behavior of the underlying optimizer
                                                                                                                                          when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble()))
                                                                                                                                              .thenReturn(new UnivariateRealPointValuePair(5.0, 10.0));
                                                                                                                                          
                                                                                                                                          // Act
                                                                                                                                          optimizer.optimize(mockFunction, goal, min, max);
                                                                                                                                          
                                                                                                                                          // Assert
                                                                                                                                          // Verify optimizer was called exactly TEST_STARTS times
                                                                                                                                          verify(mockOptimizer, times(TEST_STARTS)).optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble());
                                                                                                                                          
                                                                                                                                          // Verify total evaluations were properly tracked
                                                                                                                                          assertEquals(TEST_STARTS, optimizer.getEvaluations());
                                                                                                                                      } catch (FunctionEvaluationException e) {
                                                                                                                                          fail("Unexpected FunctionEvaluationException: " + e.getMessage());
                                                                                                                                      }
                                                                                                                                  }

    @Test
                                                                                                             public void testOptimizeUsesStartValueForFirstIteration() throws Exception {
                                                                                                                 // Setup test data
                                                                                                                 final double min = 0.0;
                                                                                                                 final double max = 10.0;
                                                                                                                 final double startValue = 5.0;
                                                                                                                 final int starts = 2;
                                                                                                                 
                                                                                                                 // Mock dependencies
                                                                                                                 org.apache.commons.math.random.RandomGenerator generator = mock(org.apache.commons.math.random.RandomGenerator.class);
                                                                                                                 when(generator.nextDouble()).thenReturn(0.5); // will produce (0 + 0.5 * (10-0)) = 5.0
                                                                                                                 
                                                                                                                 @SuppressWarnings("unchecked")
                                                                                                                 org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer<org.apache.commons.math.analysis.UnivariateRealFunction> optimizer = 
                                                                                                                     mock(org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer.class);
                                                                                                                 when(optimizer.optimize(
                                                                                                                     any(org.apache.commons.math.analysis.UnivariateRealFunction.class), 
                                                                                                                     any(org.apache.commons.math.optimization.GoalType.class), 
                                                                                                                     eq(min), eq(max), anyDouble()))
                                                                                                                     .thenReturn(new org.apache.commons.math.optimization.univariate.UnivariateRealPointValuePair(5.0, 10.0));
                                                                                                                 when(optimizer.getEvaluations()).thenReturn(1);
                                                                                                                 
                                                                                                                 // Create test instance
                                                                                                                 org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                                                                                                     new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer(optimizer, starts, generator);
                                                                                                                 
                                                                                                                 // Test
                                                                                                                 org.apache.commons.math.optimization.univariate.UnivariateRealPointValuePair result = multiStartOptimizer.optimize(
                                                                                                                     mock(org.apache.commons.math.analysis.UnivariateRealFunction.class), 
                                                                                                                     org.apache.commons.math.optimization.GoalType.MAXIMIZE, 
                                                                                                                     min, max, startValue);
                                                                                                                 
                                                                                                                 // Verify first optimization call used startValue (5.0)
                                                                                                                 org.mockito.ArgumentCaptor<Double> startCaptor = org.mockito.ArgumentCaptor.forClass(Double.class);
                                                                                                                 verify(optimizer, times(starts)).optimize(
                                                                                                                     any(org.apache.commons.math.analysis.UnivariateRealFunction.class), 
                                                                                                                     any(org.apache.commons.math.optimization.GoalType.class), 
                                                                                                                     eq(min), eq(max), startCaptor.capture());
                                                                                                                 
                                                                                                                 // First call should use startValue (5.0), second call should use random (5.0 in this case)
                                                                                                                 assertEquals(startValue, startCaptor.getAllValues().get(0), 0.0001);
                                                                                                                 
                                                                                                                 // Verify result is not null
                                                                                                                 assertNotNull(result);
                                                                                                             }

    @Test
                                                                                                     public void testOptimizeUsesCorrectStartValues() throws FunctionEvaluationException {
                                                                                                         // Setup
                                                                                                         @SuppressWarnings("unchecked")
                                                                                                         BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = 
                                                                                                             mock(BaseUnivariateRealOptimizer.class);
                                                                                                         RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                                                         
                                                                                                         // Configure mock generator to return predictable value
                                                                                                         when(mockGenerator.nextDouble()).thenReturn(0.5);
                                                                                                         
                                                                                                         // Create test instance with 2 starts
                                                                                                         MultiStartUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                                                                                                             new MultiStartUnivariateRealOptimizer<>(mockOptimizer, 2, mockGenerator);
                                                                                                         
                                                                                                         // Mock the optimize method to return dummy results
                                                                                                         UnivariateRealPointValuePair dummyResult = new UnivariateRealPointValuePair(0.0, 0.0);
                                                                                                         when(mockOptimizer.optimize(
                                                                                                             any(UnivariateRealFunction.class), 
                                                                                                             any(GoalType.class), 
                                                                                                             anyDouble(), 
                                                                                                             anyDouble(), 
                                                                                                             anyDouble()))
                                                                                                             .thenReturn(dummyResult);
                                                                                                         
                                                                                                         // Test parameters
                                                                                                         double min = 0.0;
                                                                                                         double max = 10.0;
                                                                                                         double startValue = 2.0;  // Our specific start value
                                                                                                         
                                                                                                         // Execute
                                                                                                         optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MINIMIZE, min, max, startValue);
                                                                                                         
                                                                                                         // Verify the calls - should use startValue first, then random value
                                                                                                         org.mockito.ArgumentCaptor<Double> startCaptor = org.mockito.ArgumentCaptor.forClass(Double.class);
                                                                                                         verify(mockOptimizer, times(2)).optimize(
                                                                                                             any(UnivariateRealFunction.class),
                                                                                                             any(GoalType.class),
                                                                                                             anyDouble(),
                                                                                                             anyDouble(),
                                                                                                             startCaptor.capture());
                                                                                                         
                                                                                                         // First call should use our startValue (2.0)
                                                                                                         assertEquals(startValue, startCaptor.getAllValues().get(0), 0.0001);
                                                                                                         
                                                                                                         // Second call should use random value (min + 0.5*(max-min) = 5.0)
                                                                                                         assertEquals(5.0, startCaptor.getAllValues().get(1), 0.0001);
                                                                                                     }

    @Test
                                                                        public void testOptimizeUsesStartValueForFirstIteration1() throws Exception {
                                                                            // Setup
                                                                            final double min = 0.0;
                                                                            final double max = 10.0;
                                                                            final double startValue = 5.0; // Different from min
                                                                            final int starts = 2;
                                                                            
                                                                            // Mock dependencies
                                                                            @SuppressWarnings("unchecked")
                                                                            org.apache.commons.math.optimization.univariate.UnivariateRealOptimizer optimizer = 
                                                                                mock(org.apache.commons.math.optimization.univariate.UnivariateRealOptimizer.class);
                                                                            org.apache.commons.math.random.RandomGenerator generator = mock(org.apache.commons.math.random.RandomGenerator.class);
                                                                            org.apache.commons.math.analysis.UnivariateRealFunction function = mock(org.apache.commons.math.analysis.UnivariateRealFunction.class);
                                                                            
                                                                            // Configure mocks
                                                                            when(generator.nextDouble()).thenReturn(0.5); // For second iteration
                                                                            when(optimizer.optimize(any(org.apache.commons.math.analysis.UnivariateRealFunction.class), 
                                                                                                   any(org.apache.commons.math.optimization.GoalType.class), 
                                                                                                   eq(min), eq(max), eq(startValue))) // First call should use startValue
                                                                                .thenReturn(new org.apache.commons.math.optimization.univariate.UnivariateRealPointValuePair(startValue, 0.0));
                                                                            when(optimizer.optimize(any(org.apache.commons.math.analysis.UnivariateRealFunction.class), 
                                                                                                   any(org.apache.commons.math.optimization.GoalType.class), 
                                                                                                   eq(min), eq(max), eq(min + 0.5 * (max - min)))) // Second call uses random
                                                                                .thenReturn(new org.apache.commons.math.optimization.univariate.UnivariateRealPointValuePair(7.5, 0.0));
                                                                            when(optimizer.getEvaluations()).thenReturn(1);
                                                                            when(optimizer.getMaxEvaluations()).thenReturn(100);
                                                                            
                                                                            // Create test instance
                                                                            org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer multiOptimizer = 
                                                                                new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer(optimizer, starts, generator);
                                                                            multiOptimizer.setMaxEvaluations(100);
                                                                            
                                                                            // Test
                                                                            org.apache.commons.math.optimization.univariate.UnivariateRealPointValuePair result = multiOptimizer.optimize(
                                                                                function, org.apache.commons.math.optimization.GoalType.MINIMIZE, min, max, startValue);
                                                                            
                                                                            // Verify
                                                                            // Original behavior would use startValue (5.0) for first iteration
                                                                            // Mutant would use min (0.0) instead
                                                                            verify(optimizer).optimize(any(org.apache.commons.math.analysis.UnivariateRealFunction.class), 
                                                                                                      any(org.apache.commons.math.optimization.GoalType.class), 
                                                                                                      eq(min), eq(max), eq(startValue));
                                                                            assertEquals(startValue, result.getPoint(), 0.0001);
                                                                        }

    @Test
                                                                    public void testOptimizeUsesStartValueForFirstAttempt() throws FunctionEvaluationException {
                                                                        // Setup
                                                                        double min = 0.0;
                                                                        double max = 10.0;
                                                                        double startValue = 5.0; // Different from min
                                                                        
                                                                        // Mock dependencies
                                                                        @SuppressWarnings("unchecked")
                                                                        BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = 
                                                                            mock(BaseUnivariateRealOptimizer.class);
                                                                        RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                                                        
                                                                        // Setup mock behavior
                                                                        when(mockOptimizer.optimize(
                                                                            any(UnivariateRealFunction.class), 
                                                                            any(GoalType.class), 
                                                                            eq(min), 
                                                                            eq(max), 
                                                                            anyDouble()))
                                                                            .thenReturn(new UnivariateRealPointValuePair(0, 0));
                                                                        
                                                                        // Create test instance
                                                                        MultiStartUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                                                                            new MultiStartUnivariateRealOptimizer<>(mockOptimizer, 1, mockGenerator);
                                                                        
                                                                        // Execute
                                                                        optimizer.optimize(null, null, min, max, startValue);
                                                                        
                                                                        // Verify - should use startValue (5.0) for first attempt
                                                                        verify(mockOptimizer).optimize(
                                                                            any(UnivariateRealFunction.class), 
                                                                            any(GoalType.class), 
                                                                            eq(min), 
                                                                            eq(max), 
                                                                            eq(startValue));
                                                                    }

    @Test
                                           public void testOptimizeRandomStartValuesWithinBounds() throws Exception {
                                               // Setup test parameters
                                               final double min = 2.0;
                                               final double max = 5.0;
                                               final double startValue = 3.0;
                                               final int starts = 3;
                                               
                                               // Mock dependencies
                                               BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = 
                                                   mock(BaseUnivariateRealOptimizer.class);
                                               RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                               
                                               // Configure mock generator to return known values (0.5 for test)
                                               when(mockGenerator.nextDouble()).thenReturn(0.5);
                                               
                                               // Configure mock optimizer to return dummy result
                                               UnivariateRealPointValuePair dummyResult = new UnivariateRealPointValuePair(3.0, 1.0);
                                               when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                                                       eq(min), eq(max), anyDouble())).thenReturn(dummyResult);
                                               
                                               // Create test instance
                                               MultiStartUnivariateRealOptimizer optimizer = 
                                                       new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                                               
                                               // Test
                                               optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, min, max, startValue);
                                               
                                               // Verify the random values generated are within [min, max] range
                                               // First call should use startValue (3.0)
                                               // Second call should use random value (should be min + 0.5*(max-min) = 3.5)
                                               org.mockito.ArgumentCaptor<Double> valueCaptor = org.mockito.ArgumentCaptor.forClass(Double.class);
                                               verify(mockOptimizer, times(starts)).optimize(any(UnivariateRealFunction.class), any(GoalType.class),
                                                       eq(min), eq(max), valueCaptor.capture());
                                               
                                               List<Double> values = valueCaptor.getAllValues();
                                               assertEquals(startValue, values.get(0), 0.0001); // First value is startValue
                                               
                                               // Check subsequent values are in [min,max] range
                                               for (int i = 1; i < starts; i++) {
                                                   double val = values.get(i);
                                                   assertTrue("Value should be >= min", val >= min);
                                                   assertTrue("Value should be <= max", val <= max);
                                               }
                                               
                                               // This test will fail with the mutant because:
                                               // Mutated version would generate: 2.0 - 0.5*(5.0-2.0) = 0.5 (outside [2,5] range)
                                           }

    @Test
                                       public void testOptimize_GeneratedPointsWithinBounds() throws FunctionEvaluationException {
                                           // Setup
                                           @SuppressWarnings("unchecked")
                                           BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                           RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                           
                                           // Configure mock generator to return fixed values (0.0, 0.5, 1.0)
                                           when(mockGenerator.nextDouble()).thenReturn(0.0, 0.5, 1.0);
                                           
                                           // Create optimizer with 3 starts
                                           MultiStartUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                                               new MultiStartUnivariateRealOptimizer<>(mockOptimizer, 3, mockGenerator);
                                           
                                           // Setup mock optimizer to return dummy results
                                           UnivariateRealPointValuePair dummyResult = new UnivariateRealPointValuePair(0, 0);
                                           when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
                                               .thenReturn(dummyResult);
                                           
                                           // Test bounds
                                           double min = 10.0;
                                           double max = 20.0;
                                           
                                           // Execute
                                           optimizer.optimize(null, GoalType.MINIMIZE, min, max);
                                           
                                           // Verify all optimizations were called with values within bounds
                                           verify(mockOptimizer).optimize(any(UnivariateRealFunction.class), any(GoalType.class), eq(min), eq(max), eq(min)); // first start (i=0)
                                           verify(mockOptimizer).optimize(any(UnivariateRealFunction.class), any(GoalType.class), eq(min), eq(max), eq(15.0)); // second start (0.5 scaled to bounds)
                                           verify(mockOptimizer).optimize(any(UnivariateRealFunction.class), any(GoalType.class), eq(min), eq(max), eq(max)); // third start
                                           
                                           // Additional verification on optima
                                           UnivariateRealPointValuePair[] optima = optimizer.getOptima();
                                           for (UnivariateRealPointValuePair pair : optima) {
                                               assertTrue("Point should be within bounds", 
                                                   pair.getPoint() >= min && pair.getPoint() <= max);
                                           }
                                       }

    @Test
                                  public void testOptimizeUsesRandomStartValuesForSubsequentAttempts() throws Exception {
                                      // Setup
                                      final double min = 0.0;
                                      final double max = 10.0;
                                      final double startValue = 5.0;
                                      final int starts = 3;
                                      
                                      // Mock dependencies
                                      @SuppressWarnings("unchecked")
                                      BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                      RandomGenerator generator = mock(RandomGenerator.class);
                                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                      
                                      // Configure mocks
                                      when(generator.nextDouble()).thenReturn(0.25, 0.75); // Will produce 2.5 and 7.5 for starts 2 and 3
                                      
                                      // Setup different return values based on start value
                                      UnivariateRealPointValuePair result1 = new UnivariateRealPointValuePair(startValue, 1.0);
                                      UnivariateRealPointValuePair result2 = new UnivariateRealPointValuePair(2.5, 0.5);
                                      UnivariateRealPointValuePair result3 = new UnivariateRealPointValuePair(7.5, 0.3);
                                      
                                      when(optimizer.optimize(f, GoalType.MINIMIZE, min, max, startValue)).thenReturn(result1);
                                      when(optimizer.optimize(f, GoalType.MINIMIZE, min, max, 2.5)).thenReturn(result2);
                                      when(optimizer.optimize(f, GoalType.MINIMIZE, min, max, 7.5)).thenReturn(result3);
                                      
                                      // Create test object
                                      MultiStartUnivariateRealOptimizer multiOptimizer = 
                                          new MultiStartUnivariateRealOptimizer(optimizer, starts, generator);
                                      multiOptimizer.setMaxEvaluations(100);
                                      
                                      // Test
                                      UnivariateRealPointValuePair best = multiOptimizer.optimize(f, GoalType.MINIMIZE, min, max, startValue);
                                      
                                      // Verify
                                      // Check that optimizer was called with correct start values
                                      verify(optimizer).optimize(f, GoalType.MINIMIZE, min, max, startValue);
                                      verify(optimizer).optimize(f, GoalType.MINIMIZE, min, max, 2.5); // min + 0.25*(max-min)
                                      verify(optimizer).optimize(f, GoalType.MINIMIZE, min, max, 7.5); // min + 0.75*(max-min)
                                      
                                      // Verify random generator was used
                                      verify(generator, times(2)).nextDouble();
                                      
                                      // Verify best result is returned (should be result3 with lowest value 0.3)
                                      assertEquals(7.5, best.getPoint(), 0.0001);
                                      assertEquals(0.3, best.getValue(), 0.0001);
                                  }

    @Test
                  public void testOptimizeUsesDifferentStartValues() throws FunctionEvaluationException {
                      // Setup
                      @SuppressWarnings("unchecked")
                      BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = 
                          mock(BaseUnivariateRealOptimizer.class);
                      RandomGenerator mockGenerator = mock(RandomGenerator.class);
                      
                      // Configure mock optimizer to return dummy results
                      UnivariateRealPointValuePair dummyResult = new UnivariateRealPointValuePair(0.0, 0.0);
                      when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                              anyDouble(), anyDouble(), anyDouble())).thenReturn(dummyResult);
                      
                      // Create test instance with 3 starts
                      MultiStartUnivariateRealOptimizer optimizer = 
                              new MultiStartUnivariateRealOptimizer(mockOptimizer, 3, mockGenerator);
                      
                      // Configure random generator to return predictable sequence
                      when(mockGenerator.nextDouble()).thenReturn(0.1, 0.2, 0.3);
                      
                      // Test data
                      double min = 0.0;
                      double max = 10.0;
                      double startValue = 5.0;
                      
                      // Execute
                      optimizer.optimize(null, GoalType.MAXIMIZE, min, max, startValue);
                      
                      // Verify the start values used were different (original behavior)
                      org.mockito.ArgumentCaptor<Double> startValueCaptor = org.mockito.ArgumentCaptor.forClass(Double.class);
                      verify(mockOptimizer, times(3)).optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                              eq(min), eq(max), startValueCaptor.capture());
                      
                      List<Double> usedStartValues = startValueCaptor.getAllValues();
                      assertNotEquals("First start value should not equal input startValue", 
                              startValue, usedStartValues.get(0), 0.0001);
                      assertNotEquals("Second start value should not equal input startValue", 
                              startValue, usedStartValues.get(1), 0.0001);
                      assertNotEquals("Third start value should not equal input startValue", 
                              startValue, usedStartValues.get(2), 0.0001);
                      
                      // Also verify they are different from each other
                      assertNotEquals("Start values should be different", 
                              usedStartValues.get(0), usedStartValues.get(1), 0.0001);
                      assertNotEquals("Start values should be different", 
                              usedStartValues.get(1), usedStartValues.get(2), 0.0001);
                  }

    @Test
                  public void testOptimizeShouldNotDuplicateOptimaResults() throws Exception {
                      // Setup
                      BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                      RandomGenerator mockGenerator = mock(RandomGenerator.class);
                      int starts = 3;
                      
                      // Create different optimization results to return
                      UnivariateRealPointValuePair result1 = new UnivariateRealPointValuePair(1.0, 10.0);
                      UnivariateRealPointValuePair result2 = new UnivariateRealPointValuePair(2.0, 20.0);
                      UnivariateRealPointValuePair result3 = new UnivariateRealPointValuePair(3.0, 30.0);
                      
                      // Make the optimizer return different results for each start
                      when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                          anyDouble(), anyDouble(), anyDouble()))
                          .thenReturn(result1)
                          .thenReturn(result2)
                          .thenReturn(result3);
                      
                      MultiStartUnivariateRealOptimizer optimizer = 
                          new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                      
                      // Test
                      UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                      UnivariateRealPointValuePair[] optima = optimizer.getOptima();
                      
                      // Verify before optimization all are null
                      for (int i = 0; i < starts; i++) {
                          assertNull(optima[i]);
                      }
                      
                      // Perform optimization
                      optimizer.optimize(mockFunction, GoalType.MINIMIZE, 0.0, 10.0);
                      optima = optimizer.getOptima();
                      
                      // Verify after optimization
                      // Check we have 3 distinct results (no duplicates)
                      assertEquals(starts, optima.length);
                      assertNotNull(optima[0]);
                      assertNotNull(optima[1]);
                      assertNotNull(optima[2]);
                      
                      // Verify all results are different (no duplicates from mutation)
                      assertNotEquals(optima[0], optima[1]);
                      assertNotEquals(optima[0], optima[2]);
                      assertNotEquals(optima[1], optima[2]);
                      
                      // Verify values are different
                      assertNotEquals(optima[0].getPoint(), optima[1].getPoint());
                      assertNotEquals(optima[0].getPoint(), optima[2].getPoint());
                      assertNotEquals(optima[1].getPoint(), optima[2].getPoint());
                  }

    @Test
         public void testOptimizeWithSomeFailuresShouldStoreNullForFailedAttempts() throws Exception {
             // Setup
             @SuppressWarnings("unchecked")
             BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
             RandomGenerator mockGenerator = mock(RandomGenerator.class);
             MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 2, mockGenerator);
             
             // First optimization succeeds, second fails
             UnivariateRealPointValuePair successResult = new UnivariateRealPointValuePair(1.0, 2.0);
             when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
                 .thenReturn(successResult)
                 .thenThrow(new ConvergenceException());
             
             when(mockOptimizer.getEvaluations()).thenReturn(10);
             when(mockGenerator.nextDouble()).thenReturn(0.5);
             
             // Test
             UnivariateRealPointValuePair result = optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, 0.0, 1.0, 0.5);
             
             // Verify
             UnivariateRealPointValuePair[] optima = optimizer.getOptima();
             // Original behavior: optima[1] should be null
             // Mutant behavior: optima[1] would be optima[0]
             assertNull("Failed optimization should store null", optima[1]);
             assertEquals("Should return the successful result", successResult, result);
             assertEquals("Should have correct total evaluations", 20, optimizer.getEvaluations());
         }

    @Test
    public void testOptimizeHandlesConvergenceException() throws Exception {
        // Setup mocks and required objects
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        BaseUnivariateRealOptimizer<UnivariateRealFunction> baseOptimizer = mock(BaseUnivariateRealOptimizer.class);
        RandomGenerator random = mock(RandomGenerator.class);
        
        // Create the optimizer under test with mocked dependencies
        MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(baseOptimizer, 1, random);
        
        // Configure mock to throw ConvergenceException
        when(baseOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
            .thenThrow(new ConvergenceException());
        
        // This should not throw any exception as ConvergenceException should be caught
        optimizer.optimize(f, GoalType.MINIMIZE, 0.0, 1.0);
        
        // Verify the optimizer was called
        verify(baseOptimizer, atLeastOnce()).optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble());
    }

    @Test
    public void testOptimizePropagatesOtherExceptions() throws Exception {
        // Setup mocks and test objects
        BaseUnivariateRealOptimizer<UnivariateRealFunction> baseOptimizer = 
            mock(BaseUnivariateRealOptimizer.class);
        RandomGenerator generator = mock(RandomGenerator.class);
        MultiStartUnivariateRealOptimizer optimizer = 
            new MultiStartUnivariateRealOptimizer(baseOptimizer, 10, generator);
        
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(baseOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
             anyDouble(), anyDouble(), anyDouble()))
            .thenThrow(new NullPointerException());
        
        // This should propagate the NullPointerException
        try {
            optimizer.optimize(f, GoalType.MINIMIZE, 0.0, 1.0);
            fail("Expected NullPointerException to be thrown");
        } catch (NullPointerException e) {
            // Expected exception
        }
    }

    @Test
    public void testOptimizeShouldNotCatchOtherExceptions() throws Exception {
        // Setup
        @SuppressWarnings("unchecked")
        BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
        RandomGenerator mockGenerator = mock(RandomGenerator.class);
        MultiStartUnivariateRealOptimizer optimizer = 
            new MultiStartUnivariateRealOptimizer(mockOptimizer, 1, mockGenerator);
        
        // Configure mock to throw an exception that isn't ConvergenceException
        when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
            .thenThrow(new IllegalArgumentException("Test exception"));
        
        // Set max evaluations
        optimizer.setMaxEvaluations(100);
        
        // Test - should throw the exception (original behavior)
        // If mutant is present, it will catch the exception and the test will fail
        try {
            optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, 0.0, 1.0, 0.5);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Expected behavior
        }
    }

    @Test
    public void testOptimizeShouldStillCatchConvergenceException() throws Exception {
        // Setup
        @SuppressWarnings("unchecked")
        BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = 
            mock(BaseUnivariateRealOptimizer.class);
        RandomGenerator mockGenerator = mock(RandomGenerator.class);
        MultiStartUnivariateRealOptimizer optimizer = 
            new MultiStartUnivariateRealOptimizer(mockOptimizer, 1, mockGenerator);
        
        // Configure mock to throw ConvergenceException
        when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
             anyDouble(), anyDouble(), anyDouble()))
            .thenThrow(new ConvergenceException());
        
        // Set max evaluations
        optimizer.setMaxEvaluations(100);
        
        // Test - should catch the exception (both original and mutant behavior)
        try {
            optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, 0.0, 1.0, 0.5);
        } catch (ConvergenceException e) {
            fail("ConvergenceException should have been caught");
        }
        
        // Verify optima array was set to null for failed optimization
        assertNull(optimizer.getOptima()[0]);
    }


}
