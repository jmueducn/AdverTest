package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.NonPositiveDefiniteMatrixException;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.SingularMatrixException;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class MultivariateNormalDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                public void testDensity_ValidInput() throws Exception {
                                    // Setup test data
                                    double[] means = {1.0, 2.0};
                                    double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                                    MultivariateNormalDistribution distribution = 
                                        new MultivariateNormalDistribution(new Well19937c(), means, covariances);
                                    
                                    // Test point where we expect high probability
                                    double[] vals = {1.0, 2.0};
                                    double density = distribution.density(vals);
                                    
                                    // The exact value would be 1/(2π√det(Σ)) * exp(0) = 1/(2π*0.866) ≈ 0.1837
                                    assertEquals(0.1837, density, 0.001);
                                }

    @Test
                                public void testDensity_DimensionMismatch() throws Exception {
                                    // Setup test data
                                    double[] means = {1.0, 2.0};
                                    double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                                    MultivariateNormalDistribution distribution = 
                                        new MultivariateNormalDistribution(new Well19937c(), means, covariances);
                                    
                                    // Wrong dimension input
                                    double[] vals = {1.0, 2.0, 3.0}; // 3 values for 2D distribution
                                    
                                    thrown.expect(DimensionMismatchException.class);
                                    thrown.expectMessage("3 != 2");
                                    distribution.density(vals);
                                }

    @Test
                                public void testDensity_ZeroCovariance() throws Exception {
                                    // Setup test data with diagonal covariance (no correlation)
                                    double[] means = {0.0, 0.0};
                                    double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
                                    MultivariateNormalDistribution distribution = 
                                        new MultivariateNormalDistribution(new Well19937c(), means, covariances);
                                    
                                    // Test point at origin
                                    double[] vals = {0.0, 0.0};
                                    double density = distribution.density(vals);
                                    
                                    // For standard normal, density at mean should be 1/(2π) ≈ 0.159
                                    assertEquals(0.159, density, 0.001);
                                }

    @Test
                                public void testDensity_ExtremeValues() throws Exception {
                                    // Setup test data with small covariance
                                    double[] means = {0.0, 0.0};
                                    double[][] covariances = {{0.01, 0.0}, {0.0, 0.01}};
                                    MultivariateNormalDistribution distribution = 
                                        new MultivariateNormalDistribution(new Well19937c(), means, covariances);
                                    
                                    // Test point far from mean
                                    double[] vals = {10.0, 10.0};
                                    double density = distribution.density(vals);
                                    
                                    // Should be very close to zero
                                    assertEquals(0.0, density, 1e-20);
                                }

    @Test
                public void testDensity_WithMockedExponentTerm() throws Exception {
                    // Setup test data
                    double[] means = {1.0, 2.0};
                    double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
                    
                    // Create instance
                    MultivariateNormalDistribution distribution = 
                        new MultivariateNormalDistribution(new Well19937c(), means, covariances);
                    
                    // Create a spy to intercept calls
                    MultivariateNormalDistribution spyDistribution = spy(distribution);
                    
                    // Use reflection to access the private covarianceMatrixDeterminant field
                    Field covarianceMatrixDeterminantField = MultivariateNormalDistribution.class
                        .getDeclaredField("covarianceMatrixDeterminant");
                    covarianceMatrixDeterminantField.setAccessible(true);
                    double determinant = covarianceMatrixDeterminantField.getDouble(distribution);
                    
                    // Mock the density calculation by overriding the entire method
                    doAnswer(invocation -> {
                        double[] vals = (double[]) invocation.getArguments()[0];
                        // Calculate the constant part: (2π)^(-d/2) * det(Σ)^(-1/2)
                        double d = means.length;
                        double constant = FastMath.pow(2 * FastMath.PI, -d / 2.0) * 
                                        FastMath.pow(determinant, -0.5);
                        // Use our fixed exponent term (0.5) instead of the real calculation
                        return constant * 0.5;
                    }).when(spyDistribution).density(any(double[].class));
                    
                    double[] vals = {1.5, 2.5};
                    double density = spyDistribution.density(vals);
                    
                    // Calculate expected value: (2π)^(-d/2) * det(Σ)^(-1/2) * exponentTerm
                    // For d=2, det(Σ)=0.75: (6.283)^(-1) * (0.75)^(-0.5) * 0.5 ≈ 0.1837 * 0.5 ≈ 0.0918
                    assertEquals(0.0918, density, 0.001);
                }

    @Test
           public void testDensityWithCorrectDimension() {
               // Create a valid MultivariateNormalDistribution instance
               double[] means = {0.0, 0.0};
               double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
               MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
               
               double[] vals = {1.5, 2.5};
               // Should not throw exception
               double result = dist.density(vals);
               // Just verify it doesn't throw, we don't care about actual value here
               assertTrue(!Double.isNaN(result));
           }

    @Test(expected = DimensionMismatchException.class)
           public void testDensityWithLongerInput() {
               // Create a distribution with dimension 2
               double[] means = {0.0, 0.0};
               double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
               MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
               
               // Test with input longer than dimension (3 elements vs dimension 2)
               double[] vals = {1.5, 2.5, 3.5};
               dist.density(vals);
           }

    @Test(expected = DimensionMismatchException.class)
           public void testDensityWithShorterInput() {
               double[] means = {0.0, 0.0}; // Dimension 2
               double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}}; // 2x2 covariance matrix
               MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
               
               double[] vals = {1.5}; // Shorter than dimension (2)
               dist.density(vals);
               // This will catch the mutant because:
               // Original: throws exception (test passes)
               // Mutant: doesn't throw (test fails)
           }

    @Test
       public void testDensityWithExponentTerm() {
           // Setup test data
           double[] means = {0.0, 0.0};
           double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}}; // Identity matrix
           double[] testPoint = {1.0, 1.0};
           
           // Create distribution
           MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
           
           // Calculate expected value manually
           double dim = 2;
           double covarianceMatrixDeterminant = 1.0; // For identity matrix
           double exponentTerm = Math.exp(-0.5 * (1.0*1.0 + 1.0*1.0)); // e^(-0.5*(x1^2 + x2^2))
           double expected = Math.pow(2 * Math.PI, -0.5 * dim) * 
                            Math.pow(covarianceMatrixDeterminant, -0.5) * 
                            exponentTerm;
           
           // Test the method
           double actual = dist.density(testPoint);
           
           // Assert with delta for floating point precision
           assertEquals("Density calculation should include exponent term", 
                       expected, actual, 1e-10);
           
           // Additional check that the result isn't just the first part
           double wrongValue = Math.pow(2 * Math.PI, -0.5 * dim) * 
                              Math.pow(covarianceMatrixDeterminant, -0.5);
           assertNotEquals("Result should not equal just the first part", 
                          wrongValue, actual, 1e-10);
       }

    @Test
      public void testDensityWithNonUnitCovariance() {
          // Setup test data with known values
          double[] means = {0.0, 0.0};
          double[][] covariances = {{2.0, 0.0}, {0.0, 2.0}}; // determinant = 4
          MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
          
          // Input values at the mean (simplest case)
          double[] vals = {0.0, 0.0};
          
          // Calculate expected value manually:
          // (2π)^(-d/2) * det(Σ)^(-1/2) * exp(...)
          // For d=2, det=4, vals at mean:
          // (2π)^-1 * (4)^-0.5 * exp(0) = (1/2π) * (1/2) * 1 = 1/(4π)
          double expected = 1.0 / (4 * FastMath.PI);
          
          // Call method and assert
          double actual = dist.density(vals);
          assertEquals(expected, actual, 1e-15);
          
          // Additional test with different determinant value
          double[][] cov2 = {{3.0, 0.0}, {0.0, 3.0}}; // determinant = 9
          MultivariateNormalDistribution dist2 = new MultivariateNormalDistribution(means, cov2);
          double expected2 = 1.0 / (2 * FastMath.PI * 3); // (2π)^-1 * (9)^-0.5
          double actual2 = dist2.density(vals);
          assertEquals(expected2, actual2, 1e-15);
      }

    @Test
    public void testDensityWithExtremeCovarianceDeterminant() throws Exception {
        // Setup test with very small covariance determinant where FastMath and Math differ
        double[] means = {0.0, 0.0};
        double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
        
        // Create distribution
        MultivariateNormalDistribution dist = new MultivariateNormalDistribution(means, covariances);
        
        // Use reflection to set the private covarianceMatrixDeterminant field
        Field determinantField = MultivariateNormalDistribution.class.getDeclaredField("covarianceMatrixDeterminant");
        determinantField.setAccessible(true);
        double extremeDeterminant = Double.MIN_VALUE;
        determinantField.set(dist, extremeDeterminant);
        
        // Calculate expected value using FastMath (original behavior)
        double dim = 2;
        double expected = FastMath.pow(2 * FastMath.PI, -0.5 * dim) *
                         FastMath.pow(extremeDeterminant, -0.5) * 
                         FastMath.exp(0); // Since exponent term would be 0 for means
        
        // Calculate actual value (would use Math.pow in mutant)
        double[] vals = {0.0, 0.0};
        double actual = dist.density(vals);
        
        // Assert they are equal - would fail for the mutant
        assertEquals("Density calculation should use FastMath for precision", 
                    expected, actual, 0.0000001);
    }


}
