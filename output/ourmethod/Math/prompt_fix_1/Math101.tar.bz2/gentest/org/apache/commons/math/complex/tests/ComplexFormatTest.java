package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.text.FieldPosition;
import java.text.Format;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Locale;
 
public class ComplexFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                  public void testParse_ValidComplexNumber() throws ParseException {
                                                      // Setup
                                                      ComplexFormat format = new ComplexFormat();
                                                      String source = "1.23 + 4.56i";
                                                      
                                                      // Execute
                                                      Complex result = format.parse(source);
                                                      
                                                      // Verify
                                                      assertEquals(1.23, result.getReal(), 0.0001);
                                                      assertEquals(4.56, result.getImaginary(), 0.0001);
                                                  }

 @Test
                                                  public void testParse_ValidNegativeComplexNumber() throws ParseException {
                                                      // Setup
                                                      ComplexFormat format = new ComplexFormat();
                                                      String source = "-1.23 - 4.56i";
                                                      
                                                      // Execute
                                                      Complex result = format.parse(source);
                                                      
                                                      // Verify
                                                      assertEquals(-1.23, result.getReal(), 0.0001);
                                                      assertEquals(-4.56, result.getImaginary(), 0.0001);
                                                  }

 @Test
                                                  public void testParse_ValidRealOnlyNumber() throws ParseException {
                                                      // Setup
                                                      ComplexFormat format = new ComplexFormat();
                                                      String source = "3.14";
                                                      
                                                      // Execute
                                                      Complex result = format.parse(source);
                                                      
                                                      // Verify
                                                      assertEquals(3.14, result.getReal(), 0.0001);
                                                      assertEquals(0.0, result.getImaginary(), 0.0001);
                                                  }

 @Test
                                                  public void testParse_ValidImaginaryOnlyNumber() throws ParseException {
                                                      // Setup
                                                      ComplexFormat format = new ComplexFormat();
                                                      String source = "2.71i";
                                                      
                                                      // Execute
                                                      Complex result = format.parse(source);
                                                      
                                                      // Verify
                                                      assertEquals(0.0, result.getReal(), 0.0001);
                                                      assertEquals(2.71, result.getImaginary(), 0.0001);
                                                  }

 @Test
                                                  public void testParse_WithCustomImaginaryCharacter() throws ParseException {
                                                      // Setup
                                                      ComplexFormat format = new ComplexFormat("j");
                                                      String source = "1.0 + 2.0j";
                                                      
                                                      // Execute
                                                      Complex result = format.parse(source);
                                                      
                                                      // Verify
                                                      assertEquals(1.0, result.getReal(), 0.0001);
                                                      assertEquals(2.0, result.getImaginary(), 0.0001);
                                                  }

 @Test
                                                  public void testParse_WithCustomNumberFormat() throws ParseException {
                                                      // Setup
                                                      NumberFormat format = NumberFormat.getInstance();
                                                      format.setMaximumFractionDigits(2);
                                                      ComplexFormat complexFormat = new ComplexFormat(format);
                                                      String source = "1.234 + 5.678i";
                                                      
                                                      // Execute
                                                      Complex result = complexFormat.parse(source);
                                                      
                                                      // Verify
                                                      assertEquals(1.23, result.getReal(), 0.0001);
                                                      assertEquals(5.68, result.getImaginary(), 0.0001);
                                                  }

 @Test
                                                  public void testParse_EmptyString_ThrowsParseException() throws ParseException {
                                                      // Setup
                                                      ComplexFormat format = new ComplexFormat();
                                                      String source = "";
                                                      
                                                      // Expect exception
                                                      thrown.expect(ParseException.class);
                                                      thrown.expectMessage("Unparseable complex number: \"\"");
                                                      
                                                      // Execute
                                                      format.parse(source);
                                                  }

 @Test
                                                  public void testParse_InvalidFormat_ThrowsParseException() throws ParseException {
                                                      // Setup
                                                      ComplexFormat format = new ComplexFormat();
                                                      String source = "abc + defi";
                                                      
                                                      // Expect exception
                                                      thrown.expect(ParseException.class);
                                                      thrown.expectMessage("Unparseable complex number: \"abc + defi\"");
                                                      
                                                      // Execute
                                                      format.parse(source);
                                                  }

 @Test
                                                  public void testParse_PartialMatch_ThrowsParseException() throws ParseException {
                                                      // Setup
                                                      ComplexFormat format = new ComplexFormat();
                                                      String source = "1.23 + abc";
                                                      
                                                      // Expect exception
                                                      thrown.expect(ParseException.class);
                                                      thrown.expectMessage("Unparseable complex number: \"1.23 + abc\"");
                                                      
                                                      // Execute
                                                      format.parse(source);
                                                  }

 @Test
                                                  public void testParse_WithMockedNumberFormat() throws ParseException {
                                                      // Setup
                                                      NumberFormat mockFormat = mock(NumberFormat.class);
                                                      when(mockFormat.parse(anyString(), any(ParsePosition.class)))
                                                          .thenReturn(1.23);
                                                      ComplexFormat format = new ComplexFormat(mockFormat);
                                                      String source = "1.23 + 4.56i";
                                                      
                                                      // Execute
                                                      Complex result = format.parse(source);
                                                      
                                                      // Verify
                                                      verify(mockFormat, atLeastOnce()).parse(anyString(), any(ParsePosition.class));
                                                      assertEquals(1.23, result.getReal(), 0.0001);
                                                  }

 @Test
                                          public void testParse_ValidComplexNumber1() {
                                              // Setup mock NumberFormat
                                              NumberFormat numberFormat = mock(NumberFormat.class);
                                              
                                              // Create ComplexFormat with the mock NumberFormat
                                              ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                              
                                              ParsePosition pos = new ParsePosition(0);
                                              when(numberFormat.parse("3.5", pos)).thenReturn(3.5);
                                              when(numberFormat.parse("2.1", pos)).thenReturn(2.1);
                                              
                                              Complex result = complexFormat.parse("3.5 + 2.1i", pos);
                                              assertNotNull(result);
                                              assertEquals(3.5, result.getReal(), 0.0001);
                                              assertEquals(2.1, result.getImaginary(), 0.0001);
                                          }

 @Test
                                          public void testParse_ValidComplexNumberWithNegativeImaginary() {
                                              // Create mock NumberFormat
                                              NumberFormat numberFormat = mock(NumberFormat.class);
                                              
                                              // Create ComplexFormat instance with the mock NumberFormat
                                              ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                              
                                              ParsePosition pos = new ParsePosition(0);
                                              when(numberFormat.parse("1.0", pos)).thenReturn(1.0);
                                              when(numberFormat.parse("5.0", pos)).thenReturn(5.0);
                                              
                                              Complex result = complexFormat.parse("1.0 - 5.0i", pos);
                                              assertNotNull(result);
                                              assertEquals(1.0, result.getReal(), 0.0001);
                                              assertEquals(-5.0, result.getImaginary(), 0.0001);
                                          }

 @Test
                                          public void testParse_RealOnlyNumber() {
                                              NumberFormat numberFormat = mock(NumberFormat.class);
                                              ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                              ParsePosition pos = new ParsePosition(0);
                                              
                                              when(numberFormat.parse("7.2", pos)).thenReturn(7.2);
                                              
                                              Complex result = complexFormat.parse("7.2", pos);
                                              assertNotNull(result);
                                              assertEquals(7.2, result.getReal(), 0.0001);
                                              assertEquals(0.0, result.getImaginary(), 0.0001);
                                          }

 @Test
                                          public void testParse_InvalidRealNumber() {
                                              // Setup
                                              NumberFormat numberFormat = mock(NumberFormat.class);
                                              ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                              ParsePosition pos = new ParsePosition(0);
                                              
                                              // Mock behavior
                                              when(numberFormat.parse("abc", pos)).thenReturn(null);
                                              
                                              // Test
                                              Complex result = complexFormat.parse("abc + 2i", pos);
                                              
                                              // Verify
                                              assertNull(result);
                                              assertEquals(0, pos.getIndex()); // Should reset to initial position
                                          }

 @Test
                                          public void testParse_InvalidImaginaryNumber() {
                                              NumberFormat numberFormat = NumberFormat.getInstance();
                                              ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                              ParsePosition pos = new ParsePosition(0);
                                              
                                              // Mock the number format behavior
                                              NumberFormat spyNumberFormat = spy(numberFormat);
                                              when(spyNumberFormat.parse("3.0", pos)).thenReturn(3.0);
                                              when(spyNumberFormat.parse("xyz", pos)).thenReturn(null);
                                              
                                              // Create complex format with mocked number format
                                              ComplexFormat spyComplexFormat = new ComplexFormat(spyNumberFormat);
                                              
                                              Complex result = spyComplexFormat.parse("3.0 + xyzi", pos);
                                              assertNull(result);
                                              assertEquals(0, pos.getIndex()); // Should reset to initial position
                                          }

 @Test
                                          public void testParse_InvalidSignCharacter() {
                                              NumberFormat numberFormat = NumberFormat.getInstance();
                                              ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                              ParsePosition pos = new ParsePosition(0);
                                              
                                              Complex result = complexFormat.parse("2.5 * 3.0i", pos);
                                              assertNull(result);
                                              assertEquals(0, pos.getIndex()); // Should reset to initial position
                                              assertTrue(pos.getErrorIndex() > 0); // Should set error index
                                          }

 @Test
                                          public void testParse_MissingImaginaryCharacter() {
                                              // Setup test objects
                                              NumberFormat numberFormat = mock(NumberFormat.class);
                                              ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                              ParsePosition pos = new ParsePosition(0);
                                              
                                              // Mock behavior
                                              when(numberFormat.parse("1.0", pos)).thenReturn(1.0);
                                              when(numberFormat.parse("2.0", pos)).thenReturn(2.0);
                                              
                                              // Execute test
                                              Complex result = complexFormat.parse("1.0 + 2.0", pos);
                                              
                                              // Verify results
                                              assertNull(result);
                                              assertEquals(0, pos.getIndex()); // Should reset to initial position
                                          }

 @Test
                                          public void testParse_WithWhitespace() {
                                              // Create mock NumberFormat
                                              NumberFormat numberFormat = mock(NumberFormat.class);
                                              
                                              // Create ComplexFormat instance with the mock NumberFormat
                                              ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                              
                                              ParsePosition pos = new ParsePosition(0);
                                              when(numberFormat.parse("4.2", pos)).thenReturn(4.2);
                                              when(numberFormat.parse("1.8", pos)).thenReturn(1.8);
                                              
                                              Complex result = complexFormat.parse("  4.2  +  1.8i  ", pos);
                                              assertNotNull(result);
                                              assertEquals(4.2, result.getReal(), 0.0001);
                                              assertEquals(1.8, result.getImaginary(), 0.0001);
                                          }

 @Test
                                          public void testParse_EmptyString() {
                                              ComplexFormat complexFormat = new ComplexFormat();
                                              ParsePosition pos = new ParsePosition(0);
                                              Complex result = complexFormat.parse("", pos);
                                              assertNull(result);
                                              assertEquals(0, pos.getIndex());
                                          }

 @Test
                                          public void testParse_NullString() {
                                              ComplexFormat complexFormat = new ComplexFormat();
                                              ParsePosition pos = new ParsePosition(0);
                                              Complex result = complexFormat.parse(null, pos);
                                              assertNull(result);
                                              assertEquals(0, pos.getIndex());
                                          }

 @Test
                                          public void testParse_WithDifferentImaginaryCharacter() {
                                              // Create mock NumberFormat
                                              NumberFormat numberFormat = mock(NumberFormat.class);
                                              
                                              // Create ComplexFormat with custom imaginary character
                                              ComplexFormat complexFormat = new ComplexFormat("j", numberFormat);
                                              
                                              ParsePosition pos = new ParsePosition(0);
                                              
                                              // Mock numberFormat.parse() calls
                                              when(numberFormat.parse("3.0", pos)).thenReturn(3.0);
                                              when(numberFormat.parse("4.0", pos)).thenReturn(4.0);
                                              
                                              Complex result = complexFormat.parse("3.0 + 4.0j", pos);
                                              assertNotNull(result);
                                              assertEquals(3.0, result.getReal(), 0.0001);
                                              assertEquals(4.0, result.getImaginary(), 0.0001);
                                          }

 @Test(expected = ParseException.class)
                                      public void testParseWithStartIndexEqualToLength() throws ParseException {
                                          // Setup
                                          ComplexFormat complexFormat = new ComplexFormat();
                                          String source = "1+2i";  // Example complex number string
                                          
                                          // Mock the internal parse method to simulate reaching exactly the end
                                          ComplexFormat spy = spy(complexFormat);
                                          doReturn(null).when(spy).parse(eq(source), any(ParsePosition.class));
                                          
                                          // This will make parsePosition.getIndex() return source.length()
                                          doAnswer(invocation -> {
                                              ParsePosition pos = invocation.getArgument(1);
                                              pos.setIndex(source.length());  // Set to exactly the length
                                              return null;
                                          }).when(spy).parse(eq(source), any(ParsePosition.class));
                                          
                                          // Execute - should throw ParseException
                                          spy.parse(source);
                                      }

 @Test
                                 public void testParseWithExactLengthInput() throws Exception {
                                     // Setup test data where startIndex will equal source.length()
                                     ComplexFormat format = new ComplexFormat();
                                     ParsePosition pos = new ParsePosition(0);
                                     
                                     // Create input with exactly enough characters for real number and sign
                                     // but nothing left for imaginary part (which requires at least 1 char + imaginaryCharacter)
                                     String source = "1.0+i"; // Assuming default imaginary character is "i"
                                     
                                     // Get private methods via reflection
                                     Method parseNumberMethod = ComplexFormat.class.getDeclaredMethod(
                                         "parseNumber", String.class, NumberFormat.class, ParsePosition.class);
                                     parseNumberMethod.setAccessible(true);
                                     
                                     Method parseNextCharacterMethod = ComplexFormat.class.getDeclaredMethod(
                                         "parseNextCharacter", String.class, ParsePosition.class);
                                     parseNextCharacterMethod.setAccessible(true);
                                     
                                     Method getImaginaryCharacterMethod = ComplexFormat.class.getDeclaredMethod(
                                         "getImaginaryCharacter");
                                     getImaginaryCharacterMethod.setAccessible(true);
                                     
                                     // Create spy and mock the behavior
                                     ComplexFormat spyFormat = spy(format);
                                     
                                     // Mock getImaginaryCharacter
                                     when(spyFormat.getImaginaryCharacter()).thenReturn("i");
                                     
                                     // Mock parseNumber via reflection - fixed the syntax here
                                     when((Number)parseNumberMethod.invoke(spyFormat, eq(source), any(NumberFormat.class), any(ParsePosition.class)))
                                         .thenReturn(1.0)  // First call returns real number
                                         .thenReturn(null); // Second call returns null (no imaginary number)
                                     
                                     // Mock parseNextCharacter via reflection
                                     when((Character)parseNextCharacterMethod.invoke(spyFormat, anyString(), any(ParsePosition.class)))
                                         .thenReturn('+');
                                     
                                     // Execute
                                     Complex result = spyFormat.parse(source, pos);
                                     
                                     // Verify
                                     assertNull("Should return null when input has no characters left for imaginary part", result);
                                     assertEquals("Error index should be set to start of imaginary part", 
                                                 source.indexOf('+') + 1, pos.getErrorIndex());
                                     assertEquals("Parse position should be reset", 0, pos.getIndex());
                                 }

 @Test
                             public void testParseWithIncompleteImaginaryPart() {
                                 // Setup
                                 ComplexFormat format = new ComplexFormat();
                                 ParsePosition pos = new ParsePosition(0);
                                 
                                 // Create input that has real part but incomplete imaginary part
                                 // The string is exactly long enough for real part + sign but no imaginary
                                 String source = "1.23+i";  // Missing the 'i' character (assuming default imaginary char is "i")
                                 
                                 // Execute
                                 Complex result = format.parse(source, pos);
                                 
                                 // Verify
                                 assertNull("Should return null for incomplete imaginary part", result);
                                 assertEquals("Error index should point to start of imaginary character", 
                                              4, pos.getErrorIndex());
                                 assertEquals("Parse position should be reset to initial", 
                                              0, pos.getIndex());
                                 
                                 // Additional verification for the specific mutant
                                 // Create a string that's exactly the length where endIndex == source.length()
                                 String edgeCaseSource = "1.23+";  // Exactly at boundary where imaginary char should start
                                 pos = new ParsePosition(0);
                                 result = format.parse(edgeCaseSource, pos);
                                 
                                 assertNull("Should return null when imaginary character is missing", result);
                                 assertEquals("Error index should point to start of missing imaginary character", 
                                              4, pos.getErrorIndex());
                             }

 @Test
                            public void testParseWithNumbersAtStringBoundaries() {
                                ComplexFormat format = new ComplexFormat();
                                
                                // Test case where number is at end of string (boundary case)
                                // This should pass in original but fail with mutant
                                String source1 = "1.23";
                                Complex result1 = null;
                                try {
                                    result1 = format.parse(source1);
                                    assertNotNull(result1);
                                } catch (ParseException e) {
                                    fail("Unexpected ParseException for valid input");
                                }
                                
                                // Test case with extra characters after number
                                // Original should parse just the number part, mutant might fail
                                String source2 = "1.23abc";
                                Complex result2 = null;
                                try {
                                    result2 = format.parse(source2);
                                    assertNotNull(result2);
                                } catch (ParseException e) {
                                    fail("Unexpected ParseException for input with trailing characters");
                                }
                                
                                // Test case with invalid position (should throw exception)
                                String source3 = "abc1.23";
                                try {
                                    format.parse(source3);
                                    fail("Should have thrown ParseException");
                                } catch (ParseException e) {
                                    // Expected behavior
                                }
                                
                                // Test empty string case
                                String source4 = "";
                                try {
                                    format.parse(source4);
                                    fail("Should have thrown ParseException");
                                } catch (ParseException e) {
                                    // Expected behavior
                                }
                            }

 @Test
                        public void testParseWithLexSmallerImaginaryCharacter() {
                            // Setup
                            ComplexFormat format = new ComplexFormat("j"); // imaginary character is "j"
                            ParsePosition pos = new ParsePosition(0);
                            
                            // Test string: "1.0 + 2.0i" where "i" < "j" lexicographically
                            // This should fail in original (since "i" != "j") but pass in mutant (since "i" < "j")
                            String source = "1.0 + 2.0i";
                            
                            // Execute
                            Complex result = format.parse(source, pos);
                            
                            // Verify
                            assertNull("Should reject when imaginary character doesn't match", result);
                            assertEquals("Error index should be set to start of imaginary character", 
                                         source.indexOf('i'), pos.getErrorIndex());
                            assertEquals("Parse position should be reset", 0, pos.getIndex());
                        }

 @Test
                       public void testParseWithNegativeImaginaryCharacter() {
                           // Setup
                           ComplexFormat format = new ComplexFormat("-i");
                           String source = "1 - 2i";  // Complex number with negative imaginary part
                           
                           try {
                               // Test
                               Complex result = format.parse(source);
                               
                               // Verify
                               assertNotNull(result);
                               assertEquals(1.0, result.getReal(), 0.0001);
                               assertEquals(-2.0, result.getImaginary(), 0.0001);
                           } catch (ParseException e) {
                               fail("Parsing failed with exception: " + e.getMessage());
                           }
                       }

 @Test
                       public void testParseWithPositiveImaginaryCharacter() throws ParseException {
                           // Setup
                           ComplexFormat format = new ComplexFormat("i");
                           String source = "1 + 2i";  // Complex number with positive imaginary part
                           
                           // Test
                           Complex result = format.parse(source);
                           
                           // Verify
                           assertNotNull(result);
                           assertEquals(1.0, result.getReal(), 0.0001);
                           assertEquals(2.0, result.getImaginary(), 0.0001);
                       }

 @Test(expected = ParseException.class)
                       public void testParseWithZeroImaginaryCharacter() throws ParseException {
                           // Setup
                           ComplexFormat format = new ComplexFormat("\0");  // Null character
                           String source = "1 + 2\0";  // Using null character as imaginary marker
                           
                           // This should throw ParseException in both original and mutated versions
                           format.parse(source);
                       }

 @Test(expected = ParseException.class)
                   public void testParseWithIndexBeyondLength() throws ParseException {
                       // Setup
                       ComplexFormat complexFormat = new ComplexFormat();
                       String invalidSource = "1.0 + 2.0i";
                       
                       // Mock ParsePosition to simulate index beyond source length
                       ParsePosition mockPosition = mock(ParsePosition.class);
                       when(mockPosition.getIndex()).thenReturn(invalidSource.length() + 1); // Index beyond length
                       
                       // Mock the parse method to return a complex number but with invalid position
                       Complex mockComplex = mock(Complex.class);
                       ComplexFormat spy = spy(complexFormat);
                       doReturn(mockComplex).when(spy).parse(eq(invalidSource), any(ParsePosition.class));
                       
                       // This should throw ParseException in original, but would pass in mutated version
                       spy.parse(invalidSource);
                   }

 @Test
                   public void testParseWithInvalidImaginaryPartPosition() {
                       // Setup
                       ComplexFormat format = new ComplexFormat();
                       ParsePosition pos = new ParsePosition(0);
                       
                       // Test case where startIndex > source.length() (should fail with mutant)
                       String source1 = "1.23 + 4.56"; // Missing 'i' at end and string shorter than needed
                       pos.setIndex(0);
                       Complex result1 = format.parse(source1, pos);
                       assertNull("Should return null when imaginary character is missing", result1);
                       assertEquals("Error index should be set to start of imaginary character", 
                                    source1.indexOf('4'), pos.getErrorIndex());
                       
                       // Test case where startIndex == source.length() (both original and mutant catch this)
                       String source2 = "1.23 + "; // Just reaches end of string after sign
                       pos.setIndex(0);
                       Complex result2 = format.parse(source2, pos);
                       assertNull("Should return null when no imaginary number present", result2);
                       assertEquals("Error index should be set to start of missing imaginary", 
                                    source2.length(), pos.getErrorIndex());
                       
                       // Verify original behavior with valid input
                       String validSource = "1.23 + 4.56i";
                       pos.setIndex(0);
                       Complex validResult = format.parse(validSource, pos);
                       assertNotNull("Valid input should parse correctly", validResult);
                       assertEquals(1.23, validResult.getReal(), 0.0001);
                       assertEquals(4.56, validResult.getImaginary(), 0.0001);
                   }

 @Test(expected = ParseException.class)
                  public void testParseWithPartialParseShouldFailWithMutant() throws ParseException {
                      // Setup - create a ComplexFormat instance with mocked number parsing
                      ComplexFormat format = new ComplexFormat();
                      
                      // Mock the internal parse method to simulate partial parsing
                      // where parsePosition advances but doesn't reach end of string
                      ComplexFormat spyFormat = spy(format);
                      doAnswer(invocation -> {
                          ParsePosition pos = invocation.getArgument(1);
                          pos.setIndex(5); // Advance index but not to end
                          return new Complex(1.0, 1.0); // Return dummy complex number
                      }).when(spyFormat).parse(anyString(), any(ParsePosition.class));
                      
                      // Test with a string longer than the parse position will reach
                      String source = "1.0 + 2.0i";
                      spyFormat.parse(source);
                      
                      // The original would return the Complex number since index > 0
                      // The mutant would throw because index != source.length()
                      // This test will pass only with the mutant (expecting exception)
                      // and fail with original (no exception)
                  }

 @Test
                  public void testParseWithInvalidImaginaryCharacterLength() {
                      // Setup
                      ComplexFormat format = new ComplexFormat("i");
                      ParsePosition pos = new ParsePosition(0);
                      
                      // Create a string where:
                      // - Real part is valid (1.0)
                      // - Sign is valid (+)
                      // - Imaginary part is valid (2.0)
                      // - But has extra characters after imaginary character ("ix")
                      String source = "1.0 + 2.0ix";
                      
                      // Execute
                      Complex result = format.parse(source, pos);
                      
                      // Verify
                      // Original should return null (invalid format)
                      assertNull("Should return null for invalid format", result);
                      // Original should reset position to start
                      assertEquals("Position should be reset to start", 0, pos.getIndex());
                      // Original should set error index to start of imaginary character check
                      assertTrue("Error index should be set", pos.getErrorIndex() > 0);
                      
                      // The mutant would incorrectly accept this input because:
                      // endIndex (10) != source.length() (11) would be true
                      // But original condition endIndex > source.length() would be false
                      // So mutant would proceed when it shouldn't
                  }

 @Test
                 public void testParseWithDifferentImaginaryCharacters() {
                     // Setup ComplexFormat with a specific imaginary character
                     ComplexFormat format = new ComplexFormat("i");
                     
                     // Test with default imaginary character (should pass in original, fail in mutant)
                     try {
                         Complex result = format.parse("1 + 2i");
                         assertEquals(1.0, result.getReal(), 0.0001);
                         assertEquals(2.0, result.getImaginary(), 0.0001);
                     } catch (ParseException e) {
                         fail("Should not throw exception for valid complex number");
                     }
                     
                     // Test with different imaginary character (should pass in original, fail in mutant)
                     format.setImaginaryCharacter("j");
                     try {
                         Complex result = format.parse("3 + 4j");
                         assertEquals(3.0, result.getReal(), 0.0001);
                         assertEquals(4.0, result.getImaginary(), 0.0001);
                     } catch (ParseException e) {
                         fail("Should not throw exception for valid complex number with different imaginary character");
                     }
                     
                     // Test with empty imaginary character (should fail in both)
                     format.setImaginaryCharacter("");
                     try {
                         format.parse("5 + 6");
                         fail("Should throw exception for missing imaginary character");
                     } catch (ParseException e) {
                         // Expected behavior
                     }
                 }

 @Test
                 public void testParseWithInvalidImaginaryCharacterComparison() {
                     // Setup
                     ComplexFormat format = new ComplexFormat("i"); // default imaginary character is "i"
                     ParsePosition pos = new ParsePosition(0);
                     String source = "1.0 + 2.0j"; // using 'j' instead of 'i' which would return positive compareTo result
                     
                     // Execute
                     Complex result = format.parse(source, pos);
                     
                     // Verify
                     assertNull("Should reject invalid imaginary character", result);
                     assertEquals("Error index should be set to start of imaginary character", 
                                  source.indexOf('j'), pos.getErrorIndex());
                     assertEquals("Parse position should be reset", 0, pos.getIndex());
                 }

 @Test
                public void testParseWithInvalidSignCharacter_ErrorIndexShouldPointToInvalidChar() {
                    // Setup
                    ComplexFormat format = new ComplexFormat();
                    ParsePosition pos = new ParsePosition(0);
                    String source = "1.23x4.56i"; // 'x' is invalid sign character
                    
                    // Execute
                    Complex result = format.parse(source, pos);
                    
                    // Verify
                    assertNull("Should return null for invalid sign", result);
                    assertEquals("Index should be reset to initial position", 0, pos.getIndex());
                    
                    // This is the key assertion that catches the mutant
                    // Original code would set error index to 4 (position of 'x')
                    // Mutant would set it to 5 (position after 'x')
                    assertEquals("Error index should point to invalid sign character", 4, pos.getErrorIndex());
                }

 @Test(expected = ParseException.class)
               public void testParseWithInvalidInputShouldSetCorrectErrorIndex() throws ParseException {
                   ComplexFormat complexFormat = new ComplexFormat();
                   String invalidInput = "invalid_complex_number";
                   
                   try {
                       complexFormat.parse(invalidInput);
                   } catch (ParseException e) {
                       // Verify the error index is correctly set to 0 (not 1 as the mutant would do)
                       assertEquals("Error index should point to start of unparseable input", 
                                    0, e.getErrorOffset());
                       throw e;
                   }
               }

 @Test
           public void testParseWithInvalidSign_ErrorIndexShouldPointToInvalidSign() {
               // Setup
               ComplexFormat complexFormat = new ComplexFormat();
               ParsePosition pos = new ParsePosition(0);
               String invalidComplex = "1.23 x 4.56i"; // 'x' is invalid sign
               
               // Execute
               Complex result = complexFormat.parse(invalidComplex, pos);
               
               // Verify
               assertNull("Should return null for invalid sign", result);
               assertEquals("Error index should point to invalid sign position", 
                            5, // position of 'x' in "1.23 x 4.56i"
                            pos.getErrorIndex());
               
               // Also verify the parse position was reset
               assertEquals("Parse position should be reset to initial index",
                            0, pos.getIndex());
           }

 @Test
      public void testParseWithErrorNotAtStartPosition() {
          ComplexFormat format = new ComplexFormat();
          String invalidInput = "1.0 + invalid"; // Error occurs at position 5
          
          try {
              format.parse(invalidInput);
              fail("Expected ParseException");
          } catch (ParseException e) {
              // Original behavior would set error index to 5 (where 'i' is)
              // Mutant would set it to 0
              assertEquals("Error index should point to where parsing failed", 5, e.getErrorOffset());
          }
      }

 @Test(expected = ParseException.class)
  public void testParse_UnparseableString_ShouldThrowException() throws ParseException {
      // Setup
      ComplexFormat complexFormat = new ComplexFormat();
      String unparseableString = "invalid_complex_number";
      
      // Mock the internal parse method to simulate parsing failure
      ComplexFormat spy = spy(complexFormat);
      doReturn(null).when(spy).parse(anyString(), any(ParsePosition.class));
      
      // Execute - should throw ParseException
      spy.parse(unparseableString);
      
      // If we get here, the test fails (exception wasn't thrown)
      fail("Expected ParseException for unparseable string");
  }

 @Test
  public void testParse_UnparseableString_ShouldNotIncrementPosition() {
      // Setup
      ComplexFormat complexFormat = new ComplexFormat();
      String unparseableString = "invalid_complex_number";
      ParsePosition parsePosition = new ParsePosition(0);
      
      // Mock the internal parse method to simulate parsing failure
      ComplexFormat spy = spy(complexFormat);
      doReturn(null).when(spy).parse(anyString(), any(ParsePosition.class));
      
      try {
          spy.parse(unparseableString, parsePosition);
      } catch (Exception e) {
          // Expected
      }
      
      // Verify parse position wasn't incremented (would be 1 if mutant survived)
      assertEquals("Parse position should remain 0 when parsing fails", 
                   0, parsePosition.getIndex());
  }

 @Test
  public void testParseInvalidRealNumberPositionReset() {
      // Setup
      ComplexFormat format = new ComplexFormat();
      ParsePosition pos = new ParsePosition(0);
      String invalidInput = "abc + 2i"; // invalid real number
      
      // Execute
      Complex result = format.parse(invalidInput, pos);
      
      // Verify
      assertNull("Should return null for invalid input", result);
      assertEquals("Parse position should be reset to initial index", 
                   0, pos.getIndex());
      assertNotEquals("Should detect mutant where position is initialIndex+1",
                     1, pos.getIndex());
  }

 @Test
  public void testParseInvalidSignPositionReset() {
      // Setup
      ComplexFormat format = new ComplexFormat();
      ParsePosition pos = new ParsePosition(0);
      String invalidInput = "1.23 x 2i"; // invalid sign character
      
      // Execute
      Complex result = format.parse(invalidInput, pos);
      
      // Verify
      assertNull("Should return null for invalid sign", result);
      assertEquals("Parse position should be reset to initial index", 
                   0, pos.getIndex());
      assertNotEquals("Should detect mutant where position is initialIndex+1",
                     1, pos.getIndex());
  }

 @Test
  public void testParseInvalidImaginaryNumberPositionReset() {
      // Setup
      ComplexFormat format = new ComplexFormat();
      ParsePosition pos = new ParsePosition(0);
      String invalidInput = "1.23 + abc"; // invalid imaginary number
      
      // Execute
      Complex result = format.parse(invalidInput, pos);
      
      // Verify
      assertNull("Should return null for invalid imaginary number", result);
      assertEquals("Parse position should be reset to initial index", 
                   0, pos.getIndex());
      assertNotEquals("Should detect mutant where position is initialIndex+1",
                     1, pos.getIndex());
  }

 @Test
 public void testParseWithPartialSuccessShouldNotThrowException() {
     // Setup
     ComplexFormat complexFormat = new ComplexFormat();
     String partialComplex = "1.0 + ";  // Valid start but incomplete complex number
     
     // Test - should not throw exception for original code
     try {
         complexFormat.parse(partialComplex);
         // If we get here, the test passes (original behavior)
     } catch (ParseException e) {
         // If we get here, the mutant was detected
         fail("Should not throw ParseException for partial parse in original code");
     }
     
     // Additional verification that parsing actually happened
     ParsePosition pos = new ParsePosition(0);
     complexFormat.parse(partialComplex, pos);
     assertTrue("ParsePosition should have advanced for partial parse", 
                pos.getIndex() > 0);
 }

 @Test
 public void testParseInvalidImaginaryNumberPositionReset1() {
     // Setup
     ComplexFormat format = new ComplexFormat();
     ParsePosition pos = new ParsePosition(2); // Start parsing at index 2
     String source = "  1.0+invalid"; // Valid real but invalid imaginary
     
     // Execute
     Complex result = format.parse(source, pos);
     
     // Verify
     assertNull("Should return null for invalid input", result);
     assertEquals("Parse position should be reset to initial index", 
                 2, pos.getIndex());
     assertTrue("Error index should be set", 
                pos.getErrorIndex() >= 0);
 }

}
