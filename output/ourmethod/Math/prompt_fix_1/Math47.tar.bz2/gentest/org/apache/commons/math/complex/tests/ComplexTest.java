package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                public void testDivide_NaNbyNaN() {
                    Complex nan = Complex.NaN;
                    Complex result = nan.divide(nan);
                    assertSame(Complex.NaN, result);
                }

 @Test
                public void testDivide_NumberByNaN() {
                    Complex num = new Complex(3.0, 4.0);
                    Complex nan = Complex.NaN;
                    Complex result = num.divide(nan);
                    assertSame(Complex.NaN, result);
                }

 @Test
                public void testDivide_NaNbyNumber() {
                    Complex nan = Complex.NaN;
                    Complex num = new Complex(3.0, 4.0);
                    Complex result = nan.divide(num);
                    assertSame(Complex.NaN, result);
                }

 @Test
                public void testDivide_ByZero() {
                    Complex num = new Complex(1.0, 1.0);
                    Complex zero = Complex.ZERO;
                    Complex result = num.divide(zero);
                    assertSame(Complex.INF, result);
                }

 @Test
                public void testDivide_ZeroByZero() {
                    Complex zero = Complex.ZERO;
                    Complex result = zero.divide(zero);
                    assertSame(Complex.NaN, result);
                }

 @Test
                public void testDivide_ByInfinite() {
                    Complex infinite = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                    Complex num = new Complex(1.0, 1.0);
                    Complex result = num.divide(infinite);
                    assertSame(Complex.ZERO, result);
                }

 @Test
                public void testDivide_RegularNumbers_AbsCGreaterThanAbsD() {
                    Complex a = new Complex(4.0, 2.0);  // (4 + 2i)
                    Complex b = new Complex(3.0, 1.0);  // (3 + i)
                    Complex result = a.divide(b);
                    
                    // Expected: (4 + 2i)/(3 + i) = (14 + 2i)/10 = (1.4 + 0.2i)
                    assertEquals(1.4, result.getReal(), 0.0001);
                    assertEquals(0.2, result.getImaginary(), 0.0001);
                }

 @Test
                public void testDivide_RegularNumbers_AbsCLessThanAbsD() {
                    Complex a = new Complex(1.0, 4.0);  // (1 + 4i)
                    Complex b = new Complex(2.0, 3.0);  // (2 + 3i)
                    Complex result = a.divide(b);
                    
                    // Expected: (1 + 4i)/(2 + 3i) = (14 + 5i)/13 ≈ (1.0769 + 0.3846i)
                    assertEquals(1.0769, result.getReal(), 0.0001);
                    assertEquals(0.3846, result.getImaginary(), 0.0001);
                }

 @Test
                public void testDivide_InfiniteByInfinite() {
                    Complex inf1 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                    Complex inf2 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                    Complex result = inf1.divide(inf2);
                    assertSame(Complex.NaN, result);
                }

 @Test
                public void testDivide_RealNumberByComplex() {
                    Complex a = new Complex(6.0, 0.0);  // 6
                    Complex b = new Complex(3.0, 2.0);  // (3 + 2i)
                    Complex result = a.divide(b);
                    
                    // Expected: 6/(3 + 2i) = (18 - 12i)/13 ≈ (1.3846 - 0.9231i)
                    assertEquals(1.3846, result.getReal(), 0.0001);
                    assertEquals(-0.9231, result.getImaginary(), 0.0001);
                }

 @Test
                public void testDivide_ComplexByRealNumber() {
                    Complex a = new Complex(3.0, 4.0);  // (3 + 4i)
                    Complex b = new Complex(2.0, 0.0);  // 2
                    Complex result = a.divide(b);
                    
                    // Expected: (3 + 4i)/2 = (1.5 + 2i)
                    assertEquals(1.5, result.getReal(), 0.0001);
                    assertEquals(2.0, result.getImaginary(), 0.0001);
                }

 @Test
                public void testDivide_NaNdivisor() {
                    Complex complex = new Complex(3.0, 4.0);
                    Complex result = complex.divide(Double.NaN);
                    assertTrue(result.isNaN());
                }

 @Test
                public void testDivide_ComplexIsNaN() {
                    Complex complex = new Complex(Double.NaN, Double.NaN);
                    Complex result = complex.divide(2.0);
                    assertTrue(result.isNaN());
                }

 @Test
                public void testDivide_ByZero_ComplexIsZero() {
                    Complex complex = new Complex(0.0, 0.0);
                    Complex result = complex.divide(0.0);
                    assertTrue(result.isNaN());
                }

 @Test
                public void testDivide_ByZero_ComplexNotZero() {
                    Complex complex = new Complex(3.0, 4.0);
                    Complex result = complex.divide(0.0);
                    assertEquals(Complex.INF, result);
                }

 @Test
                public void testDivide_ByInfinite_ComplexNotInfinite() {
                    Complex complex = new Complex(3.0, 4.0);
                    Complex result = complex.divide(Double.POSITIVE_INFINITY);
                    assertEquals(Complex.ZERO, result);
                }

 @Test
                public void testDivide_ByInfinite_ComplexIsInfinite() {
                    Complex complex = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
                    Complex result = complex.divide(Double.POSITIVE_INFINITY);
                    assertTrue(result.isNaN());
                }

 @Test
                public void testDivide_NormalCase() {
                    Complex complex = new Complex(6.0, 8.0);
                    Complex result = complex.divide(2.0);
                    assertEquals(3.0, result.getReal(), 0.0001);
                    assertEquals(4.0, result.getImaginary(), 0.0001);
                }

 @Test
                public void testDivide_NormalCaseWithNegativeDivisor() {
                    Complex complex = new Complex(6.0, 8.0);
                    Complex result = complex.divide(-2.0);
                    assertEquals(-3.0, result.getReal(), 0.0001);
                    assertEquals(-4.0, result.getImaginary(), 0.0001);
                }

 @Test
                public void testDivide_ComplexWithNegativeImaginary() {
                    Complex complex = new Complex(6.0, -8.0);
                    Complex result = complex.divide(2.0);
                    assertEquals(3.0, result.getReal(), 0.0001);
                    assertEquals(-4.0, result.getImaginary(), 0.0001);
                }

 @Test
                public void testDivide_ComplexWithZeroReal() {
                    Complex complex = new Complex(0.0, 8.0);
                    Complex result = complex.divide(2.0);
                    assertEquals(0.0, result.getReal(), 0.0001);
                    assertEquals(4.0, result.getImaginary(), 0.0001);
                }

 @Test
                public void testDivide_ComplexWithZeroImaginary() {
                    Complex complex = new Complex(6.0, 0.0);
                    Complex result = complex.divide(2.0);
                    assertEquals(3.0, result.getReal(), 0.0001);
                    assertEquals(0.0, result.getImaginary(), 0.0001);
                }

 @Test
                public void testDivide_ByNegativeZero() {
                    Complex complex = new Complex(6.0, 8.0);
                    Complex result = complex.divide(-0.0);
                    assertEquals(Complex.INF, result);
                }

 @Test
                public void testDivide_ComplexWithNegativeValues() {
                    Complex complex = new Complex(-6.0, -8.0);
                    Complex result = complex.divide(2.0);
                    assertEquals(-3.0, result.getReal(), 0.0001);
                    assertEquals(-4.0, result.getImaginary(), 0.0001);
                }

 @Test
        public void testDivide_ByNull() {
            ExpectedException exceptionRule = ExpectedException.none();
            exceptionRule.expect(NullPointerException.class);
            Complex complex = new Complex(1.0, 2.0);
            complex.divide(null);
        }

 @Test
        public void testDivide_WithMockedComplex() {
            Complex mockDivisor = mock(Complex.class);
            when(mockDivisor.isNaN()).thenReturn(false);
            when(mockDivisor.isInfinite()).thenReturn(false);
            when(mockDivisor.getReal()).thenReturn(2.0);
            when(mockDivisor.getImaginary()).thenReturn(1.0);
            
            // Mock the isZero field behavior by checking real and imaginary parts
            when(mockDivisor.getReal()).thenReturn(2.0);
            when(mockDivisor.getImaginary()).thenReturn(1.0);
            
            Complex num = new Complex(4.0, 2.0);
            Complex result = num.divide(mockDivisor);
            
            // Verify interactions
            verify(mockDivisor).isNaN();
            verify(mockDivisor).isInfinite();
            verify(mockDivisor, times(2)).getReal(); // called twice: once for isZero check, once for calculation
            verify(mockDivisor).getImaginary();
            
            // Expected: (4 + 2i)/(2 + i) = (10 + 0i)/5 = (2 + 0i)
            assertEquals(2.0, result.getReal(), 0.0001);
            assertEquals(0.0, result.getImaginary(), 0.0001);
        }

 @Test
    public void testDivideWithNaNCases() {
        // Create test cases where only one operand is NaN
        Complex nonNaN = new Complex(1.0, 1.0);
        Complex nanComplex = new Complex(Double.NaN, 1.0);
        Complex nanDivisor = new Complex(1.0, Double.NaN);
        
        // Case 1: Current complex is NaN, divisor is not
        Complex result1 = nanComplex.divide(nonNaN);
        assertEquals("Should return NaN when current complex is NaN", 
                    Complex.NaN, result1);
        
        // Case 2: Divisor is NaN, current complex is not
        Complex result2 = nonNaN.divide(nanDivisor);
        assertEquals("Should return NaN when divisor is NaN", 
                    Complex.NaN, result2);
        
        // Case 3: Both are NaN
        Complex result3 = nanComplex.divide(nanDivisor);
        assertEquals("Should return NaN when both operands are NaN", 
                    Complex.NaN, result3);
        
        // Case 4: Neither is NaN (normal case)
        Complex result4 = nonNaN.divide(nonNaN);
        assertNotEquals("Should not return NaN for normal division", 
                       Complex.NaN, result4);
    }

 @Test
    public void testDivideWithNaNCases1() {
        // Case 1: Complex is NaN, divisor is valid
        Complex nanComplex = new Complex(Double.NaN, 1.0);
        Complex result1 = nanComplex.divide(2.0);
        assertEquals("Should return NaN when complex is NaN", 
                     Complex.NaN, result1);
    
        // Case 2: Complex is valid, divisor is NaN
        Complex validComplex = new Complex(1.0, 1.0);
        Complex result2 = validComplex.divide(Double.NaN);
        assertEquals("Should return NaN when divisor is NaN", 
                     Complex.NaN, result2);
    
        // Case 3: Both complex and divisor are NaN
        Complex result3 = nanComplex.divide(Double.NaN);
        assertEquals("Should return NaN when both are NaN", 
                     Complex.NaN, result3);
    
        // Case 4: Neither is NaN
        Complex result4 = validComplex.divide(2.0);
        assertNotEquals("Should not return NaN when neither is NaN", 
                       Complex.NaN, result4);
    }

 @Test
   public void testDivide_CurrentIsNaN_DivisorNotNaN_ShouldReturnNaN() {
       // Create a complex number that is NaN (using NaN in real part)
       Complex current = new Complex(Double.NaN, 1.0);
       
       // Create a valid divisor (not NaN)
       Complex divisor = new Complex(1.0, 1.0);
       
       // Perform the division
       Complex result = current.divide(divisor);
       
       // Verify the result is NaN (original behavior)
       assertTrue(result.isNaN());
       
       // Also verify the real and imaginary parts are both NaN
       assertTrue(Double.isNaN(result.getReal()));
       assertTrue(Double.isNaN(result.getImaginary()));
   }

 @Test
   public void testDivideWhenComplexIsNaN() {
       // Create a complex number that is NaN (real part is NaN)
       Complex complexNaN = new Complex(Double.NaN, 1.0);
       
       // Divide by a valid number
       Complex result = complexNaN.divide(2.0);
       
       // Original code would return NaN, mutated code would try to divide
       assertEquals(Complex.NaN, result);
       
       // Also test case where imaginary part is NaN
       Complex complexNaN2 = new Complex(1.0, Double.NaN);
       result = complexNaN2.divide(2.0);
       assertEquals(Complex.NaN, result);
       
       // Test case where both parts are NaN
       Complex complexNaN3 = new Complex(Double.NaN, Double.NaN);
       result = complexNaN3.divide(2.0);
       assertEquals(Complex.NaN, result);
   }

 @Test
  public void testDivideWithNaNDivisorShouldReturnNaN() {
      // Create a valid complex number (not NaN)
      Complex dividend = new Complex(1.0, 2.0);
      
      // Create a NaN divisor by using Double.NaN in constructor
      Complex divisor = new Complex(Double.NaN, 0.0);
      
      // Perform division
      Complex result = dividend.divide(divisor);
      
      // Original code should return NaN when divisor is NaN
      // Mutant will proceed with calculation instead
      assertTrue("Division by NaN should return NaN", result.isNaN());
      
      // Additional check to ensure we're getting the static NaN field
      assertSame("Should return the static NaN instance", Complex.NaN, result);
  }

 @Test
  public void testDivideWithNaNDivisorShouldReturnNaN1() {
      // Create a non-NaN complex number
      Complex complex = new Complex(1.0, 2.0);
      
      // Use NaN as divisor
      double nanDivisor = Double.NaN;
      
      // Call the method
      Complex result = complex.divide(nanDivisor);
      
      // Verify it returns NaN (original behavior)
      // The mutant would not enter this branch and might return incorrect result
      assertEquals(Complex.NaN, result);
      
      // Additional verification that the complex number itself is not NaN
      assertFalse(complex.isNaN());
  }

 @Test
 public void testDivideWithNaNShouldReturnNaN() {
     // Test case where current complex is NaN
     Complex nanComplex = new Complex(Double.NaN, 1.0);
     Complex divisor1 = new Complex(1.0, 1.0);
     assertEquals(Complex.NaN, nanComplex.divide(divisor1));
     
     // Test case where divisor is NaN
     Complex validComplex = new Complex(1.0, 1.0);
     Complex nanDivisor = new Complex(Double.NaN, 1.0);
     assertEquals(Complex.NaN, validComplex.divide(nanDivisor));
     
     // Test case where both are NaN
     assertEquals(Complex.NaN, nanComplex.divide(nanDivisor));
 }

 @Test
 public void testDivideWithNaNValuesShouldReturnNaN() {
     // Test case 1: Complex number is NaN
     Complex nanComplex = new Complex(Double.NaN, 1.0);
     Complex result1 = nanComplex.divide(2.0);
     assertEquals("Dividing NaN complex by real should return NaN", 
                  Complex.NaN, result1);
 
     // Test case 2: Divisor is NaN
     Complex normalComplex = new Complex(1.0, 1.0);
     Complex result2 = normalComplex.divide(Double.NaN);
     assertEquals("Dividing complex by NaN should return NaN",
                  Complex.NaN, result2);
 
     // Test case 3: Both complex and divisor are NaN
     Complex result3 = nanComplex.divide(Double.NaN);
     assertEquals("Dividing NaN complex by NaN should return NaN",
                  Complex.NaN, result3);
 }

}
