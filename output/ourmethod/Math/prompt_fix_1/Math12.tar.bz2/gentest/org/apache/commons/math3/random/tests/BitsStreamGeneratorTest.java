package gentest.org.apache.commons.math3.random.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.random.*;
import java.io.Serializable;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.util.FastMath;
 
public class BitsStreamGeneratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                  public void testNextGaussianInitialState() {
                                                                      // Verify initial state of nextGaussian is NaN
                                                                      BitsStreamGenerator newGenerator = new BitsStreamGenerator() {
                                                                          @Override public void setSeed(int seed) {}
                                                                          @Override public void setSeed(int[] seed) {}
                                                                          @Override public void setSeed(long seed) {}
                                                                          @Override protected int next(int bits) { return 0; }
                                                                      };
                                                                      
                                                                      // Access private field through reflection for testing
                                                                      try {
                                                                          java.lang.reflect.Field field = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                          field.setAccessible(true);
                                                                          double value = (Double)field.get(newGenerator);
                                                                          assertTrue(Double.isNaN(value));
                                                                      } catch (Exception e) {
                                                                          fail("Failed to test nextGaussian initial state: " + e.getMessage());
                                                                      }
                                                                  }

 @Test
                                                                  public void testNextGaussian_StatisticalProperties_OverManyCalls() {
                                                                      // This test verifies the statistical properties over many calls
                                                                      // We'll use real random values (not mocked) for this test
                                                                      
                                                                      BitsStreamGenerator realGenerator = new BitsStreamGenerator() {
                                                                          @Override
                                                                          protected int next(int bits) {
                                                                              return (int)(Math.random() * (1L << bits));
                                                                          }
                                                                          
                                                                          @Override
                                                                          public void setSeed(int seed) {}
                                                                          @Override
                                                                          public void setSeed(int[] seed) {}
                                                                          @Override
                                                                          public void setSeed(long seed) {}
                                                                      };
                                                                      
                                                                      int numSamples = 10000;
                                                                      double sum = 0;
                                                                      double sumSquares = 0;
                                                                      
                                                                      for (int i = 0; i < numSamples; i++) {
                                                                          double value = realGenerator.nextGaussian();
                                                                          sum += value;
                                                                          sumSquares += value * value;
                                                                      }
                                                                      
                                                                      double mean = sum / numSamples;
                                                                      double variance = sumSquares / numSamples - mean * mean;
                                                                      
                                                                      // Check mean is approximately 0 (within 3 standard errors)
                                                                      assertEquals(0.0, mean, 3.0 / Math.sqrt(numSamples));
                                                                      // Check variance is approximately 1 (within reasonable tolerance)
                                                                      assertEquals(1.0, variance, 0.1);
                                                                  }

 @Test
                                                                  public void testNextInt_ThrowsForNonPositiveInput() {
                                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                          @Override
                                                                          protected int next(int bits) { return 0; }
                                                                          @Override
                                                                          public void setSeed(int seed) {}
                                                                          @Override
                                                                          public void setSeed(int[] seed) {}
                                                                          @Override
                                                                          public void setSeed(long seed) {}
                                                                      };
                                                              
                                                                      thrown.expect(NotStrictlyPositiveException.class);
                                                                      generator.nextInt(0);
                                                              
                                                                      thrown.expect(NotStrictlyPositiveException.class);
                                                                      generator.nextInt(-1);
                                                                  }

 @Test(expected = NullPointerException.class)
                                                          public void testSetSeed_WithIntArray_NullInput() {
                                                              BitsStreamGenerator concreteGenerator = new BitsStreamGenerator() {
                                                                  @Override
                                                                  public void setSeed(int seed) {}
                                                                  
                                                                  @Override
                                                                  public void setSeed(int[] seed) {}
                                                                  
                                                                  @Override
                                                                  public void setSeed(long seed) {}
                                                                  
                                                                  @Override
                                                                  protected int next(int bits) {
                                                                      return 0;
                                                                  }
                                                              };
                                                              concreteGenerator.setSeed((int[])null);
                                                          }

 @Test
                                                          public void testSetSeed_VerifyAbstractMethodCalled_IntVersion() {
                                                              int testSeed = 42;
                                                              BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                              generator.setSeed(testSeed);
                                                              verify(generator).setSeed(testSeed);
                                                          }

 @Test
                                                          public void testSetSeed_VerifyAbstractMethodCalled_IntArrayVersion() {
                                                              BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                              int[] testSeed = {1, 2, 3};
                                                              generator.setSeed(testSeed);
                                                              verify(generator).setSeed(testSeed);
                                                          }

 @Test
                                                          public void testSetSeed_VerifyAbstractMethodCalled_LongVersion() {
                                                              long testSeed = 987654321L;
                                                              BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                              generator.setSeed(testSeed);
                                                              verify(generator).setSeed(testSeed);
                                                          }

 @Test(expected = NullPointerException.class)
                                                          public void testSetSeed_WithNullIntArray() {
                                                              BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                  @Override
                                                                  public void setSeed(int seed) {}
                                                                  
                                                                  @Override
                                                                  public void setSeed(int[] seed) {
                                                                      if (seed == null) {
                                                                          throw new NullPointerException();
                                                                      }
                                                                  }
                                                                  
                                                                  @Override
                                                                  public void setSeed(long seed) {}
                                                                  
                                                                  @Override
                                                                  protected int next(int bits) {
                                                                      return 0;
                                                                  }
                                                              };
                                                              generator.setSeed((int[])null);
                                                          }

 @Test
                                                          public void testSetSeed_WithMaxInt() throws Exception {
                                                              // Create a concrete instance of the abstract BitsStreamGenerator
                                                              BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                  @Override
                                                                  public void setSeed(int seed) {}
                                                                  @Override
                                                                  public void setSeed(int[] seed) {}
                                                                  @Override
                                                                  public void setSeed(long seed) {}
                                                                  @Override
                                                                  protected int next(int bits) { return 0; }
                                                              };
                                                              
                                                              // Use reflection to access the private intSeed field
                                                              Field intSeedField = BitsStreamGenerator.class.getDeclaredField("intSeed");
                                                              intSeedField.setAccessible(true);
                                                              
                                                              int testSeed = Integer.MAX_VALUE;
                                                              generator.setSeed(testSeed);
                                                              
                                                              assertEquals(testSeed, intSeedField.getInt(generator));
                                                          }

 @Test
                                                          public void testSetSeed_WithMinInt() throws Exception {
                                                              int testSeed = Integer.MIN_VALUE;
                                                              // Create a concrete subclass since BitsStreamGenerator is abstract
                                                              BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                  @Override
                                                                  public void setSeed(int seed) {}
                                                                  @Override
                                                                  public void setSeed(int[] seed) {}
                                                                  @Override
                                                                  public void setSeed(long seed) {}
                                                                  @Override
                                                                  protected int next(int bits) { return 0; }
                                                              };
                                                              
                                                              generator.setSeed(testSeed);
                                                              
                                                              // Use reflection to access the private intSeed field
                                                              Field intSeedField = BitsStreamGenerator.class.getDeclaredField("intSeed");
                                                              intSeedField.setAccessible(true);
                                                              int actualSeed = intSeedField.getInt(generator);
                                                              
                                                              assertEquals(testSeed, actualSeed);
                                                          }

 @Test
                                                          public void testSetSeed_WithMaxLong() {
                                                              // Create an anonymous subclass of BitsStreamGenerator for testing
                                                              BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                  private long longSeed;
                                                                  
                                                                  @Override
                                                                  public void setSeed(int seed) {}
                                                                  
                                                                  @Override
                                                                  public void setSeed(int[] seed) {}
                                                                  
                                                                  @Override
                                                                  public void setSeed(long seed) {
                                                                      this.longSeed = seed;
                                                                  }
                                                                  
                                                                  @Override
                                                                  protected int next(int bits) {
                                                                      return 0;
                                                                  }
                                                              };
                                                              
                                                              long testSeed = Long.MAX_VALUE;
                                                              generator.setSeed(testSeed);
                                                              
                                                              // Use reflection to access the private longSeed field
                                                              try {
                                                                  Field field = generator.getClass().getDeclaredField("longSeed");
                                                                  field.setAccessible(true);
                                                                  long actualSeed = field.getLong(generator);
                                                                  assertEquals(testSeed, actualSeed);
                                                              } catch (Exception e) {
                                                                  fail("Failed to access longSeed field: " + e.getMessage());
                                                              }
                                                          }

 @Test
                                                          public void testSetSeed_WithMinLong() throws Exception {
                                                              long testSeed = Long.MIN_VALUE;
                                                              // Create a concrete instance (using MersenneTwister as an example)
                                                              org.apache.commons.math3.random.MersenneTwister generator = new org.apache.commons.math3.random.MersenneTwister();
                                                              
                                                              generator.setSeed(testSeed);
                                                              
                                                              // Use reflection to access the private longSeed field
                                                              java.lang.reflect.Field field = generator.getClass().getSuperclass().getDeclaredField("longSeed");
                                                              field.setAccessible(true);
                                                              long actualSeed = field.getLong(generator);
                                                              
                                                              assertEquals(testSeed, actualSeed);
                                                          }

 @Test
                                                          public void testSetSeedWithInt() {
                                                              // Create an anonymous subclass of BitsStreamGenerator for testing
                                                              BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                  @Override
                                                                  public void setSeed(int seed) {
                                                                      // Implementation for test
                                                                  }
                                                                  
                                                                  @Override
                                                                  public void setSeed(int[] seed) {
                                                                      // Implementation for test
                                                                  }
                                                                  
                                                                  @Override
                                                                  public void setSeed(long seed) {
                                                                      // Implementation for test
                                                                  }
                                                                  
                                                                  @Override
                                                                  protected int next(int bits) {
                                                                      return 42; // Fixed return for test
                                                                  }
                                                                  
                                                                  @Override
                                                                  public boolean nextBoolean() {
                                                                      return true; // Fixed return for test
                                                                  }
                                                              };
                                                              
                                                              // Test that setting seed with int doesn't throw exception
                                                              generator.setSeed(12345);
                                                              
                                                              // Verify that after setting seed, next operations work
                                                              assertNotNull(generator.nextBoolean());
                                                              assertEquals(42, generator.nextInt());
                                                          }

 @Test
                                                          public void testSetSeedWithIntArray() {
                                                              // Create a concrete implementation or mock of BitsStreamGenerator
                                                              BitsStreamGenerator generator = new MersenneTwister(); // Using MersenneTwister as a concrete implementation
                                                              
                                                              // Test normal case
                                                              generator.setSeed(new int[]{1, 2, 3});
                                                              
                                                              // Verify that after setting seed, next operations work
                                                              // Note: The expected value 42 is arbitrary - in a real test, you would either:
                                                              // 1. Know the expected sequence for a given seed
                                                              // 2. Mock the generator to return specific values
                                                              // 3. Test properties rather than exact values
                                                              assertNotNull(generator.nextInt());
                                                              
                                                              // Test edge case with single element array
                                                              generator.setSeed(new int[]{1});
                                                              assertNotNull(generator.nextInt());
                                                          }

 @Test
                                                          public void testSetSeedWithLong() {
                                                              // Create a concrete implementation or mock of BitsStreamGenerator
                                                              BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                  @Override
                                                                  public void setSeed(int seed) {}
                                                                  
                                                                  @Override
                                                                  public void setSeed(int[] seed) {}
                                                                  
                                                                  @Override
                                                                  public void setSeed(long seed) {}
                                                                  
                                                                  @Override
                                                                  protected int next(int bits) {
                                                                      return 42; // Fixed value for testing
                                                                  }
                                                              };
                                                              
                                                              // Test normal case
                                                              generator.setSeed(123456789L);
                                                              
                                                              // Verify that after setting seed, next operations work
                                                              assertEquals(42L, generator.nextLong());
                                                              
                                                              // Test edge cases
                                                              generator.setSeed(0L);
                                                              assertEquals(42L, generator.nextLong());
                                                              
                                                              generator.setSeed(Long.MAX_VALUE);
                                                              assertEquals(42L, generator.nextLong());
                                                              
                                                              generator.setSeed(Long.MIN_VALUE);
                                                              assertEquals(42L, generator.nextLong());
                                                          }

 @Test
                                                          public void testClearMethod() {
                                                              // Create an anonymous subclass of BitsStreamGenerator for testing
                                                              BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                  @Override
                                                                  public void setSeed(int seed) {}
                                                                  @Override
                                                                  public void setSeed(int[] seed) {}
                                                                  @Override
                                                                  public void setSeed(long seed) {}
                                                                  @Override
                                                                  protected int next(int bits) { return 0; }
                                                              };
                                                              
                                                              // Verify that clear resets nextGaussian to NaN
                                                              generator.nextGaussian(); // This might change the state
                                                              
                                                              generator.clear();
                                                              
                                                              // Access private field through reflection for testing
                                                              try {
                                                                  java.lang.reflect.Field field = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                                  field.setAccessible(true);
                                                                  double value = (Double)field.get(generator);
                                                                  assertTrue(Double.isNaN(value));
                                                              } catch (Exception e) {
                                                                  fail("Failed to test clear method: " + e.getMessage());
                                                              }
                                                          }

 @Test
                                                          public void testNextLong_UsesNextMethod() throws Exception {
                                                              // Create a mock of BitsStreamGenerator
                                                              BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                  private int callCount = 0;
                                                                  
                                                                  @Override
                                                                  protected int next(int bits) {
                                                                      // First call returns 0x12345678, second call returns same
                                                                      return 0x12345678;
                                                                  }
                                                          
                                                                  @Override
                                                                  public void setSeed(int seed) {}
                                                                  
                                                                  @Override
                                                                  public void setSeed(int[] seed) {}
                                                                  
                                                                  @Override
                                                                  public void setSeed(long seed) {}
                                                              };
                                                              
                                                              // Test that nextLong uses next(32) twice
                                                              assertEquals(0x1234567812345678L, generator.nextLong());
                                                          }

 @Test
                                                          public void testClear_ResetsNextGaussian() {
                                                              // Create a concrete instance of BitsStreamGenerator for testing
                                                              // We'll use a mock or anonymous subclass since BitsStreamGenerator is abstract
                                                              BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                                  @Override
                                                                  protected int next(int bits) {
                                                                      return 0;
                                                                  }
                                                                  
                                                                  @Override
                                                                  public void setSeed(int seed) {}
                                                                  
                                                                  @Override
                                                                  public void setSeed(int[] seed) {}
                                                                  
                                                                  @Override
                                                                  public void setSeed(long seed) {}
                                                              };
                                                              
                                                              // First set a Gaussian value
                                                              generator.nextGaussian();
                                                              assertFalse(Double.isNaN(generator.nextGaussian()));
                                                              
                                                              // After clear, should be NaN again
                                                              generator.clear();
                                                              assertTrue(Double.isNaN(generator.nextGaussian()));
                                                          }

 @Test
                                                      public void testNextBytes_EmptyArray() {
                                                          BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                              @Override
                                                              public void setSeed(int seed) {}
                                                              
                                                              @Override
                                                              public void setSeed(int[] seed) {}
                                                              
                                                              @Override
                                                              public void setSeed(long seed) {}
                                                              
                                                              @Override
                                                              protected int next(int bits) {
                                                                  return 0;
                                                              }
                                                          };
                                                          
                                                          byte[] bytes = new byte[0];
                                                          generator.nextBytes(bytes);
                                                          // Should not throw any exception
                                                          assertEquals(0, bytes.length);
                                                      }

 @Test
                                                      public void testNextBytes_NullArray() {
                                                          org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                                              @Override
                                                              public void setSeed(int seed) {}
                                                              @Override
                                                              public void setSeed(int[] seed) {}
                                                              @Override
                                                              public void setSeed(long seed) {}
                                                              @Override
                                                              protected int next(int bits) { return 0; }
                                                          };
                                                          org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                          thrown.expect(NullPointerException.class);
                                                          generator.nextBytes(null);
                                                      }

 @Test
                                                      public void testNextGaussian_WhenNextGaussianIsNaN_GeneratesNewPair() {
                                                          // Setup
                                                          BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                          when(generator.nextDouble()).thenReturn(0.5, 0.5); // x=0.5, y=0.5
                                                          
                                                          // Execute
                                                          double result = generator.nextGaussian();
                                                          
                                                          // Verify
                                                          verify(generator, times(2)).nextDouble();
                                                          assertEquals(0.0, result, 1e-10);
                                                          
                                                          // Verify nextGaussian was set to a new value (not NaN)
                                                          double nextResult = generator.nextGaussian();
                                                          assertFalse(Double.isNaN(nextResult));
                                                      }

 @Test
                                                      public void testNextGaussian_WhenNextGaussianHasValue_ReturnsStoredValue() throws Exception {
                                                          // Setup
                                                          BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                          
                                                          // Use reflection to set private nextGaussian field
                                                          Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                          nextGaussianField.setAccessible(true);
                                                          nextGaussianField.set(generator, 1.23);
                                                          
                                                          // Mock the actual method call
                                                          when(generator.nextGaussian()).thenCallRealMethod();
                                                          
                                                          // Execute
                                                          double result = generator.nextGaussian();
                                                          
                                                          // Verify
                                                          assertEquals(1.23, result, 1e-10);
                                                          assertTrue(Double.isNaN((Double)nextGaussianField.get(generator)));
                                                          verify(generator, never()).nextDouble();
                                                      }

 @Test
                                                      public void testNextGaussian_SequenceOfCalls_GeneratesPairsCorrectly() {
                                                          // Create mock generator
                                                          BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                          
                                                          // Setup mock values for Box-Muller transform
                                                          // First pair: x=0.25, y=0.25
                                                          // Second pair: x=0.75, y=0.75
                                                          when(generator.nextDouble())
                                                              .thenReturn(0.25, 0.25)  // First pair
                                                              .thenReturn(0.75, 0.75); // Second pair
                                                          
                                                          // First call - generates first pair (a,b)
                                                          double first = generator.nextGaussian();
                                                          // Second call - returns b from first pair
                                                          double second = generator.nextGaussian();
                                                          // Third call - generates second pair (c,d)
                                                          double third = generator.nextGaussian();
                                                          
                                                          // Verify values (calculated based on Box-Muller formula)
                                                          double alpha1 = 2 * Math.PI * 0.25;
                                                          double r1 = Math.sqrt(-2 * Math.log(0.25));
                                                          double expectedFirst = r1 * Math.cos(alpha1);
                                                          double expectedSecond = r1 * Math.sin(alpha1);
                                                          
                                                          double alpha2 = 2 * Math.PI * 0.75;
                                                          double r2 = Math.sqrt(-2 * Math.log(0.75));
                                                          double expectedThird = r2 * Math.cos(alpha2);
                                                          
                                                          assertEquals(expectedFirst, first, 1e-10);
                                                          assertEquals(expectedSecond, second, 1e-10);
                                                          assertEquals(expectedThird, third, 1e-10);
                                                      }

 @Test
                                                      public void testNextGaussian_WithZeroYValue_HandlesLogarithmCorrectly() {
                                                          // Setup mock generator
                                                          BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                          // Setup exception rule
                                                          ExpectedException exception = ExpectedException.none();
                                                          
                                                          // Setup - y=0 would cause log(0) which is -Infinity
                                                          when(generator.nextDouble()).thenReturn(0.5, 0.0);
                                                          
                                                          exception.expect(IllegalArgumentException.class);
                                                          generator.nextGaussian();
                                                      }

 @Test
                                                      public void testNextInt_NonPowerOfTwoInput() {
                                                          // Create a concrete subclass that we can spy on
                                                          class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                              @Override
                                                              protected int next(int bits) { return 0; }
                                                              @Override
                                                              public void setSeed(int seed) {}
                                                              @Override
                                                              public void setSeed(int[] seed) {}
                                                              @Override
                                                              public void setSeed(long seed) {}
                                                          }
                                                          
                                                          TestableBitsStreamGenerator generator = spy(new TestableBitsStreamGenerator());
                                                      
                                                          // Mock the rejection scenario first, then valid scenario
                                                          doReturn(Integer.MAX_VALUE)  // This would be rejected
                                                              .doReturn(1000)          // This would be accepted
                                                              .when(generator).next(31);
                                                      
                                                          int result = generator.nextInt(100);
                                                          assertTrue(result >= 0 && result < 100);
                                                      }

 @Test
                                                      public void testNextInt_EdgeCases() {
                                                          // Create a concrete subclass to access protected method
                                                          BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                              @Override
                                                              protected int next(int bits) {
                                                                  // Default implementation returns 0
                                                                  return 0;
                                                              }
                                                              
                                                              @Override
                                                              public void setSeed(int seed) {}
                                                              
                                                              @Override
                                                              public void setSeed(int[] seed) {}
                                                              
                                                              @Override
                                                              public void setSeed(long seed) {}
                                                              
                                                              // Override next(int) to make it public for testing
                                                              public int publicNext(int bits) {
                                                                  return next(bits);
                                                              }
                                                          };
                                                          
                                                          // Use reflection to test the protected method
                                                          try {
                                                              // Test n = 1 should always return 0
                                                              Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                              nextMethod.setAccessible(true);
                                                              nextMethod.invoke(generator, 31); // This would normally return 0 from our implementation
                                                              
                                                              assertEquals(0, generator.nextInt(1));
                                                              
                                                              // Test large n value
                                                              // We can't directly mock the protected method, so we test with the actual implementation
                                                              // The actual implementation should handle edge cases properly
                                                              int result = generator.nextInt(Integer.MAX_VALUE);
                                                              assertTrue(result >= 0 && result < Integer.MAX_VALUE);
                                                          } catch (Exception e) {
                                                              fail("Reflection failed: " + e.getMessage());
                                                          }
                                                      }

 @Test
                                                      public void testNextInt_DistributionCheck() {
                                                          BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                              @Override
                                                              protected int next(int bits) {
                                                                  // Return predefined sequence of values
                                                                  return new int[]{0, 100, 200, 300, 400, 500, 600, 700, 800, 900}[(int)(Math.random() * 10)];
                                                              }
                                                              @Override
                                                              public void setSeed(int seed) {}
                                                              @Override
                                                              public void setSeed(int[] seed) {}
                                                              @Override
                                                              public void setSeed(long seed) {}
                                                          };
                                                      
                                                          int n = 10;
                                                          int[] counts = new int[n];
                                                          int trials = 10000;
                                                      
                                                          for (int i = 0; i < trials; i++) {
                                                              int val = generator.nextInt(n);
                                                              counts[val]++;
                                                          }
                                                      
                                                          // Verify all buckets got some hits
                                                          for (int count : counts) {
                                                              assertTrue(count > 0);
                                                          }
                                                      }

 @Test
                                                  public void testConstructor_InitializesNextGaussian() {
                                                      // Create an anonymous subclass of BitsStreamGenerator for testing
                                                      BitsStreamGenerator newGenerator = new BitsStreamGenerator() {
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                          @Override
                                                          protected int next(int bits) { return 0; }
                                                      };
                                                      assertTrue(Double.isNaN(newGenerator.nextGaussian()));
                                                  }

 @Test
                                                  public void testSetSeed_WithEmptyIntArray() {
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          private int[] arraySeed;
                                                          
                                                          @Override
                                                          public void setSeed(int seed) {
                                                              // Empty implementation
                                                          }
                                                          
                                                          @Override
                                                          public void setSeed(int[] seed) {
                                                              this.arraySeed = seed;
                                                          }
                                                          
                                                          @Override
                                                          public void setSeed(long seed) {
                                                              // Empty implementation
                                                          }
                                                          
                                                          @Override
                                                          protected int next(int bits) {
                                                              return 0;
                                                          }
                                                          
                                                          // Helper method to access the arraySeed for testing
                                                          public int[] getArraySeed() {
                                                              return arraySeed;
                                                          }
                                                      };
                                                      
                                                      int[] testSeed = {};
                                                      generator.setSeed(testSeed);
                                                      
                                                      // Using reflection to access the private field since we can't modify the original class
                                                      try {
                                                          Field field = generator.getClass().getDeclaredField("arraySeed");
                                                          field.setAccessible(true);
                                                          int[] actualSeed = (int[]) field.get(generator);
                                                          assertArrayEquals(testSeed, actualSeed);
                                                      } catch (Exception e) {
                                                          fail("Failed to access arraySeed field: " + e.getMessage());
                                                      }
                                                  }

 @Test
                                                  public void testConstructor_InitializesNextGaussian1() {
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                          @Override
                                                          protected int next(int bits) { return 0; }
                                                      };
                                                      assertTrue(Double.isNaN(generator.nextGaussian()));
                                                  }

 @Test
                                                  public void testSetSeedWithIntArray_NullInput() {
                                                      BitsStreamGenerator generator = new MersenneTwister(); // Using MersenneTwister as a concrete implementation
                                                      try {
                                                          generator.setSeed((int[])null);
                                                          fail("Expected IllegalArgumentException");
                                                      } catch (IllegalArgumentException e) {
                                                          assertEquals("Seed array cannot be null or empty", e.getMessage());
                                                      }
                                                  }

 @Test
                                                  public void testNext_WithZeroBits() throws Exception {
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                          @Override
                                                          protected int next(int bits) {
                                                              return 0; // Mock implementation for testing
                                                          }
                                                      };
                                                      
                                                      // Use reflection to access the protected next() method
                                                      Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                      nextMethod.setAccessible(true);
                                                      int result = (int) nextMethod.invoke(generator, 0);
                                                      
                                                      assertEquals(0, result);
                                                  }

 @Test
                                                  public void testNext_WithOneBit() throws Exception {
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                          @Override
                                                          protected int next(int bits) {
                                                              return 1; // Mock implementation for testing
                                                          }
                                                      };
                                                      
                                                      // Use reflection to access protected next() method
                                                      Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                      nextMethod.setAccessible(true);
                                                      int result = (int) nextMethod.invoke(generator, 1);
                                                      
                                                      assertEquals(1, result);
                                                  }

 @Test
                                                  public void testNext_WithThirtyTwoBits() {
                                                      // Create a concrete implementation of BitsStreamGenerator for testing
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          private int nextValue;
                                                          
                                                          @Override
                                                          public void setSeed(int seed) {
                                                              nextValue = seed;
                                                          }
                                                          
                                                          @Override
                                                          public void setSeed(int[] seed) {
                                                              // Not used in this test
                                                          }
                                                          
                                                          @Override
                                                          public void setSeed(long seed) {
                                                              // Not used in this test
                                                          }
                                                          
                                                          @Override
                                                          protected int next(int bits) {
                                                              return nextValue;
                                                          }
                                                          
                                                          // Override nextInt() to test the 32-bit case
                                                          @Override
                                                          public int nextInt() {
                                                              return next(32);
                                                          }
                                                      };
                                                      
                                                      generator.setSeed(0xFFFFFFFF);
                                                      int result = generator.nextInt();
                                                      assertEquals(0xFFFFFFFF, result);
                                                  }

 @Test
                                                  public void testNext_WithNegativeBits() throws Exception {
                                                      // Create an anonymous subclass of BitsStreamGenerator for testing
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          @Override
                                                          protected int next(int bits) {
                                                              return 0; // dummy implementation
                                                          }
                                                      
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                      
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                      
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // Setup expected exception
                                                      ExpectedException thrown = ExpectedException.none();
                                                      thrown.expect(IllegalArgumentException.class);
                                                      
                                                      // Use reflection to access the protected method
                                                      Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                      nextMethod.setAccessible(true);
                                                      nextMethod.invoke(generator, -1);
                                                  }

 @Test
                                                  public void testNextBoolean_ReturnsTrueWhenNextReturnsNonZero() {
                                                      // Arrange
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          @Override
                                                          protected int next(int bits) {
                                                              return 1;  // Return non-zero value
                                                          }
                                                  
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // Act
                                                      boolean result = generator.nextBoolean();
                                                      
                                                      // Assert
                                                      assertTrue(result);
                                                  }

 @Test
                                                  public void testNextBoolean_ReturnsFalseWhenNextReturnsZero() {
                                                      // Arrange
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          @Override
                                                          protected int next(int bits) {
                                                              return 0; // Always return 0 to simulate the case we want to test
                                                          }
                                                  
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // Act
                                                      boolean result = generator.nextBoolean();
                                                      
                                                      // Assert
                                                      assertFalse(result);
                                                  }

 @Test
                                                  public void testNextBoolean_MultipleCalls() {
                                                      // Arrange
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          private int[] values = {1, 0, 1, 0};
                                                          private int index = 0;
                                                          
                                                          @Override
                                                          protected int next(int bits) {
                                                              return values[index++];
                                                          }
                                                          
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // Act & Assert
                                                      assertTrue(generator.nextBoolean());
                                                      assertFalse(generator.nextBoolean());
                                                      assertTrue(generator.nextBoolean());
                                                      assertFalse(generator.nextBoolean());
                                                  }

 @Test
                                                  public void testNextBoolean_AlwaysCallsNextWithOne() {
                                                      // Arrange
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          private int lastBits;
                                                          
                                                          @Override
                                                          protected int next(int bits) {
                                                              lastBits = bits;
                                                              return 1;
                                                          }
                                                  
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // Act
                                                      generator.nextBoolean();
                                                      
                                                      // Assert - verify next(1) was called through reflection
                                                      try {
                                                          Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                          nextMethod.setAccessible(true);
                                                          int result = (int) nextMethod.invoke(generator, 1);
                                                          assertEquals(1, result);
                                                      } catch (Exception e) {
                                                          fail("Reflection failed: " + e.getMessage());
                                                      }
                                                  }

 @Test
                                                  public void testNextBytes_SingleByte() {
                                                      // Create a concrete subclass to test the protected method
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          private int nextValue = 0x12345678;
                                                          
                                                          @Override
                                                          protected int next(int bits) {
                                                              return nextValue;
                                                          }
                                                          
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      byte[] bytes = new byte[1];
                                                      generator.nextBytes(bytes);
                                                      
                                                      assertEquals((byte)0x78, bytes[0]);
                                                  }

 @Test
                                                  public void testNextBytes_ThreeBytes() {
                                                      // Create a subclass of BitsStreamGenerator that we can test
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          @Override
                                                          protected int next(int bits) {
                                                              return 0xAABBCCDD; // Return our test value
                                                          }
                                                  
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      byte[] bytes = new byte[3];
                                                      generator.nextBytes(bytes);
                                                      
                                                      assertEquals((byte)0xDD, bytes[0]);
                                                      assertEquals((byte)0xCC, bytes[1]);
                                                      assertEquals((byte)0xBB, bytes[2]);
                                                  }

 @Test
                                                  public void testNextBytes_FourBytes() {
                                                      // Create test subclass that exposes the protected method
                                                      class TestGenerator extends BitsStreamGenerator {
                                                          @Override
                                                          protected int next(int bits) {
                                                              return bits == 32 ? 0x11223344 : 0;
                                                          }
                                                          
                                                          // Implement abstract methods
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      }
                                                      
                                                      BitsStreamGenerator generator = new TestGenerator();
                                                      
                                                      byte[] bytes = new byte[4];
                                                      generator.nextBytes(bytes);
                                                      
                                                      // Verify bytes are filled in little-endian order
                                                      assertEquals((byte)0x44, bytes[0]);
                                                      assertEquals((byte)0x33, bytes[1]);
                                                      assertEquals((byte)0x22, bytes[2]);
                                                      assertEquals((byte)0x11, bytes[3]);
                                                  }

 @Test
                                                  public void testNextBytes_FiveBytes() {
                                                      // Create a concrete subclass to test the protected method
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          private int callCount = 0;
                                                          
                                                          @Override
                                                          protected int next(int bits) {
                                                              if (callCount++ == 0) {
                                                                  return 0x99887766;
                                                              } else {
                                                                  return 0x55443322;
                                                              }
                                                          }
                                                  
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      byte[] bytes = new byte[5];
                                                      generator.nextBytes(bytes);
                                                      
                                                      // First 4 bytes from first random
                                                      assertEquals((byte)0x66, bytes[0]);
                                                      assertEquals((byte)0x77, bytes[1]);
                                                      assertEquals((byte)0x88, bytes[2]);
                                                      assertEquals((byte)0x99, bytes[3]);
                                                      // Fifth byte from second random
                                                      assertEquals((byte)0x22, bytes[4]);
                                                  }

 @Test
                                                  public void testNextDouble_MinValue() {
                                                      // Setup
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          private int callCount = 0;
                                                          
                                                          @Override
                                                          protected int next(int bits) {
                                                              callCount++;
                                                              return 0; // Always return 0 to simulate minimum value
                                                          }
                                                  
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // Execute
                                                      double result = generator.nextDouble();
                                                      
                                                      // Verify
                                                      assertEquals(0.0, result, 0.0);
                                                  }

 @Test
                                                  public void testNextDouble_MaxValue() throws Exception {
                                                      // Setup mock generator
                                                      BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                      
                                                      // Use reflection to access the protected next(int) method
                                                      Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                      nextMethod.setAccessible(true);
                                                      
                                                      // when next(26) returns max value (2^26-1) for both parts
                                                      int max26bit = (1 << 26) - 1;
                                                      when(nextMethod.invoke(generator, 26)).thenReturn(max26bit);
                                                      
                                                      // Execute
                                                      double result = generator.nextDouble();
                                                      
                                                      // Verify
                                                      // Expected: (2^52 - 1) * 2^-52 = 1 - 2^-52
                                                      double expected = 1.0 - Math.pow(2, -52);
                                                      assertEquals(expected, result, 1e-10);
                                                      
                                                      // Verify next(26) was called twice
                                                      verify(generator, times(2)).nextDouble();
                                                  }

 @Test
                                                  public void testNextDouble_RangeCheck() {
                                                      // Setup: create concrete subclass to test protected method
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          private int callCount = 0;
                                                          
                                                          @Override
                                                          protected int next(int bits) {
                                                              // Alternate between the two test values
                                                              return (callCount++ % 2 == 0) ? 123 : 456;
                                                          }
                                                  
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // Execute
                                                      double result = generator.nextDouble();
                                                      
                                                      // Verify range
                                                      assertTrue(result >= 0.0);
                                                      assertTrue(result < 1.0);
                                                  }

 @Test
                                                  public void testNextDouble_Distribution() {
                                                      // Create a mock of BitsStreamGenerator using anonymous class to access protected method
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          private int callCount = 0;
                                                          
                                                          @Override
                                                          protected int next(int bits) {
                                                              if (callCount++ == 0) {
                                                                  return 1 << 25;  // high part with bit 25 set
                                                              } else {
                                                                  return 1 << 24;  // low part with bit 24 set
                                                              }
                                                          }
                                                  
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // Execute
                                                      double result = generator.nextDouble();
                                                      
                                                      // Verify the bits are properly combined and scaled
                                                      long expectedBits = (1L << 51) | (1L << 24);
                                                      double expected = expectedBits * Math.pow(2, -52);
                                                      assertEquals(expected, result, 1e-10);
                                                  }

 @Test
                                                  public void testNextFloat_EdgeCases() throws Exception {
                                                      // Create a subclass that exposes the protected method
                                                      class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                          @Override
                                                          protected int next(int bits) {
                                                              return 0; // Will be overridden by reflection
                                                          }
                                                          
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      }
                                                      
                                                      TestableBitsStreamGenerator generator = new TestableBitsStreamGenerator();
                                                      
                                                      // Use reflection to modify the behavior of next()
                                                      Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                      nextMethod.setAccessible(true);
                                                      
                                                      // First call returns 0, second call returns max 23-bit value
                                                      when(nextMethod.invoke(generator, 23)).thenReturn(0, (1 << 23) - 1);
                                                      
                                                      assertEquals(0.0f, generator.nextFloat(), 0.0f);
                                                      assertEquals(0.99999994f, generator.nextFloat(), 0.0f);
                                                  }

 @Test
                                                  public void testNextFloat_DoesNotReturnNaN() {
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          private int callCount = 0;
                                                          private final int[] values = {0, 1, (1 << 23) - 1};
                                                          
                                                          @Override
                                                          protected int next(int bits) {
                                                              return values[callCount++ % values.length];
                                                          }
                                                          
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      assertFalse(Float.isNaN(generator.nextFloat()));
                                                      assertFalse(Float.isNaN(generator.nextFloat()));
                                                      assertFalse(Float.isNaN(generator.nextFloat()));
                                                  }

 @Test
                                                  public void testNextInt_CallsNextWith32Bits() {
                                                      // Arrange
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          @Override
                                                          protected int next(int bits) {
                                                              return 123456;
                                                          }
                                                  
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // Act
                                                      int result = generator.nextInt();
                                                      
                                                      // Assert
                                                      assertEquals(123456, result);
                                                  }

 @Test
                                                  public void testNextInt_DoesNotAffectNextGaussianState() throws Exception {
                                                      // Arrange
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          @Override
                                                          protected int next(int bits) {
                                                              return 0;
                                                          }
                                                          
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // Use reflection to access private nextGaussian field
                                                      Field nextGaussianField = BitsStreamGenerator.class.getDeclaredField("nextGaussian");
                                                      nextGaussianField.setAccessible(true);
                                                      
                                                      double initialGaussian = 1.5;
                                                      nextGaussianField.set(generator, initialGaussian);
                                                      
                                                      // Create a spy and mock the behavior
                                                      BitsStreamGenerator spyGenerator = spy(generator);
                                                      doReturn(999).when(spyGenerator).nextInt();  // Mock nextInt() directly instead of next()
                                                      
                                                      // Act
                                                      int result = spyGenerator.nextInt();
                                                      
                                                      // Assert
                                                      assertEquals(999, result);
                                                      assertEquals(initialGaussian, nextGaussianField.getDouble(spyGenerator), 0.0001);
                                                  }

 @Test
                                                  public void testNextInt_WithMockedNextReturningNegativeValue() {
                                                      // Arrange
                                                      BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                      int negativeValue = -123456789;
                                                      
                                                      // Mock the protected next() method
                                                      try {
                                                          Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                          nextMethod.setAccessible(true);
                                                          when(nextMethod.invoke(generator, 32)).thenReturn(negativeValue);
                                                      } catch (Exception e) {
                                                          fail("Failed to mock protected next() method: " + e.getMessage());
                                                      }
                                                      
                                                      // Act
                                                      int result = generator.nextInt();
                                                      
                                                      // Assert
                                                      assertEquals(negativeValue, result);
                                                  }

 @Test
                                                  public void testNextInt_PowerOfTwoInput() {
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          @Override
                                                          protected int next(int bits) {
                                                              // For power of two inputs, nextInt(n) uses next(31) and takes bits % n
                                                              if (bits == 31) {
                                                                  return Integer.MAX_VALUE; // This will produce n-1 when n is power of two
                                                              }
                                                              return 0; // This will produce 0 when n is power of two
                                                          }
                                                          
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // First test case - should return n-1 (1023) when next(31) returns MAX_VALUE
                                                      assertEquals(1023, generator.nextInt(1024));
                                                      
                                                      // Second test case - should return 0 when next(31) returns 0
                                                      assertEquals(0, generator.nextInt(16));
                                                  }

 @Test
                                                  public void testNextLong_CombinesHighAndLowBitsCorrectly() {
                                                      // Arrange
                                                      class TestableBitsStreamGenerator extends BitsStreamGenerator {
                                                          @Override
                                                          protected int next(int bits) {
                                                              return 0; // will be mocked
                                                          }
                                                          
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      }
                                                      
                                                      TestableBitsStreamGenerator generator = mock(TestableBitsStreamGenerator.class);
                                                      when(generator.next(32))
                                                          .thenReturn(0x12345678)  // high part
                                                          .thenReturn(0x9ABCDEF0); // low part
                                                      
                                                      // Act
                                                      long result = generator.nextLong();
                                                      
                                                      // Assert
                                                      assertEquals(0x123456789ABCDEF0L, result);
                                                      verify(generator, times(2)).next(32);
                                                  }

 @Test
                                                  public void testNextLong_MaxValues() {
                                                      // Arrange
                                                      BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                      try {
                                                          Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                          nextMethod.setAccessible(true);
                                                          when(nextMethod.invoke(generator, 32))
                                                              .thenReturn(0xFFFFFFFF)  // high part
                                                              .thenReturn(0xFFFFFFFF); // low part
                                                      } catch (Exception e) {
                                                          fail("Failed to set up mock for protected method");
                                                      }
                                                      
                                                      // Act
                                                      long result = generator.nextLong();
                                                      
                                                      // Assert
                                                      assertEquals(0xFFFFFFFFFFFFFFFFL, result);
                                                  }

 @Test
                                                  public void testNextLong_MixedValues() {
                                                      // Arrange
                                                      BitsStreamGenerator generator = mock(BitsStreamGenerator.class);
                                                      try {
                                                          Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                                                          nextMethod.setAccessible(true);
                                                          when(nextMethod.invoke(generator, 32))
                                                              .thenReturn(0x0000FFFF)  // high part
                                                              .thenReturn(0xFFFF0000); // low part
                                                      } catch (Exception e) {
                                                          fail("Failed to set up mock for protected method");
                                                      }
                                                      
                                                      // Act
                                                      long result = generator.nextLong();
                                                      
                                                      // Assert
                                                      assertEquals(0x0000FFFF00000000L | 0xFFFF0000L, result);
                                                  }

 @Test
                                                  public void testNextLong_VerifyBitOperations() {
                                                      // Arrange
                                                      BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                          private int callCount = 0;
                                                          
                                                          @Override
                                                          protected int next(int bits) {
                                                              if (callCount++ == 0) {
                                                                  return 0xA5A5A5A5;  // high part
                                                              } else {
                                                                  return 0x5A5A5A5A; // low part
                                                              }
                                                          }
                                                  
                                                          @Override
                                                          public void setSeed(int seed) {}
                                                          @Override
                                                          public void setSeed(int[] seed) {}
                                                          @Override
                                                          public void setSeed(long seed) {}
                                                      };
                                                      
                                                      // Act
                                                      long result = generator.nextLong();
                                                      
                                                      // Assert
                                                      long expectedHigh = 0xA5A5A5A5L << 32;
                                                      long expectedLow = 0x5A5A5A5AL & 0xffffffffL;
                                                      assertEquals(expectedHigh | expectedLow, result);
                                                  }

 @Test
                                              public void testSetSeedWithIntArray_EmptyInput() {
                                                  BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                      @Override
                                                      public void setSeed(int seed) {}
                                                      
                                                      @Override
                                                      public void setSeed(int[] seed) {
                                                          if (seed == null || seed.length == 0) {
                                                              throw new IllegalArgumentException("Seed array cannot be null or empty");
                                                          }
                                                      }
                                                      
                                                      @Override
                                                      public void setSeed(long seed) {}
                                                      
                                                      @Override
                                                      protected int next(int bits) {
                                                          return 0;
                                                      }
                                                  };
                                                  
                                                  try {
                                                      generator.setSeed(new int[0]);
                                                      fail("Expected IllegalArgumentException");
                                                  } catch (IllegalArgumentException e) {
                                                      assertEquals("Seed array cannot be null or empty", e.getMessage());
                                                  }
                                              }

 @Test
                                              public void testNextBytes_MultipleChunks() {
                                                  // Create a test subclass that exposes the protected method
                                                  class TestGenerator extends BitsStreamGenerator {
                                                      @Override
                                                      protected int next(int bits) {
                                                          return 0; // will be mocked
                                                      }
                                                      
                                                      @Override
                                                      public void setSeed(int seed) {
                                                          // empty implementation for test
                                                      }
                                                      
                                                      @Override
                                                      public void setSeed(int[] seed) {
                                                          // empty implementation for test
                                                      }
                                                      
                                                      @Override
                                                      public void setSeed(long seed) {
                                                          // empty implementation for test
                                                      }
                                                  }
                                                  
                                                  TestGenerator generator = mock(TestGenerator.class);
                                                  
                                                  when(generator.next(32))
                                                      .thenReturn(0x01020304)
                                                      .thenReturn(0xAABBCCDD);
                                                  
                                                  byte[] bytes = new byte[8];
                                                  generator.nextBytes(bytes);
                                                  
                                                  // First chunk
                                                  assertEquals((byte)0x04, bytes[0]);
                                                  assertEquals((byte)0x03, bytes[1]);
                                                  assertEquals((byte)0x02, bytes[2]);
                                                  assertEquals((byte)0x01, bytes[3]);
                                                  // Second chunk
                                                  assertEquals((byte)0xDD, bytes[4]);
                                                  assertEquals((byte)0xCC, bytes[5]);
                                                  assertEquals((byte)0xBB, bytes[6]);
                                                  assertEquals((byte)0xAA, bytes[7]);
                                              }

 @Test
                                              public void testNextDouble_TypicalValue() throws Exception {
                                                  // Create a concrete implementation
                                                  BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                      private int callCount = 0;
                                                      private final int[] values = {123456, 654321};
                                                      
                                                      @Override
                                                      protected int next(int bits) {
                                                          return values[callCount++];
                                                      }
                                                  
                                                      @Override
                                                      public void setSeed(int seed) {}
                                                      @Override
                                                      public void setSeed(int[] seed) {}
                                                      @Override
                                                      public void setSeed(long seed) {}
                                                  };
                                                  
                                                  // Execute
                                                  double result = generator.nextDouble();
                                                  
                                                  // Verify
                                                  // Calculate expected value: (high << 26 | low) * 2^-52
                                                  long high = 123456L << 26;
                                                  int low = 654321;
                                                  double expected = (high | low) * Math.pow(2, -52);
                                                  assertEquals(expected, result, 1e-10);
                                              }

 @Test
                                              public void testNextFloat_UniformDistribution() {
                                                  // Create a concrete subclass to test the protected method
                                                  BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                      private int callCount = 0;
                                                      private final int[] values = {
                                                          0, 1, 100, 1000, 10000,
                                                          (1 << 22) - 1, 1 << 22,
                                                          (1 << 23) - 2, (1 << 23) - 1
                                                      };
                                                      
                                                      @Override
                                                      protected int next(int bits) {
                                                          return values[callCount++ % values.length];
                                                      }
                                                      
                                                      @Override
                                                      public void setSeed(int seed) {}
                                                      
                                                      @Override
                                                      public void setSeed(int[] seed) {}
                                                      
                                                      @Override
                                                      public void setSeed(long seed) {}
                                                  };
                                                  
                                                  // Test multiple values to check they're in range
                                                  for (int i = 0; i < 9; i++) {
                                                      float result = generator.nextFloat();
                                                      assertTrue("Value should be >= 0.0f: " + result, result >= 0.0f);
                                                      assertTrue("Value should be < 1.0f: " + result, result < 1.0f);
                                                  }
                                              }

 @Test
                                              public void testNextFloat_DoesNotReturnInfinity() {
                                                  BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                      private int callCount = 0;
                                                      
                                                      @Override
                                                      protected int next(int bits) {
                                                          switch (callCount++) {
                                                              case 0: return 0;
                                                              case 1: return 1;
                                                              case 2: return (1 << 23) - 1;
                                                              default: return 0;
                                                          }
                                                      }
                                              
                                                      @Override
                                                      public void setSeed(int seed) {}
                                                      @Override
                                                      public void setSeed(int[] seed) {}
                                                      @Override
                                                      public void setSeed(long seed) {}
                                                  };
                                                  
                                                  assertFalse(Float.isInfinite(generator.nextFloat()));
                                                  assertFalse(Float.isInfinite(generator.nextFloat()));
                                                  assertFalse(Float.isInfinite(generator.nextFloat()));
                                              }

 @Test
                                          public void testNextLong_MinValues() {
                                              // Arrange
                                              BitsStreamGenerator generator = new BitsStreamGenerator() {
                                                  @Override
                                                  protected int next(int bits) {
                                                      return 0;  // Always return 0 for both high and low parts
                                                  }
                                          
                                                  @Override
                                                  public void setSeed(int seed) {}
                                                  @Override
                                                  public void setSeed(int[] seed) {}
                                                  @Override
                                                  public void setSeed(long seed) {}
                                              };
                                              
                                              // Act
                                              long result = generator.nextLong();
                                              
                                              // Assert
                                              assertEquals(0x0000000000000000L, result);
                                          }

 @Test
                                      public void testClear_WhenNextGaussianIsNumber_SetsToNaN() {
                                          // Arrange
                                          org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                                              private double nextGaussian = Double.NaN;
                                              
                                              @Override
                                              public void setSeed(int seed) {}
                                              
                                              @Override
                                              public void setSeed(int[] seed) {}
                                              
                                              @Override
                                              public void setSeed(long seed) {}
                                              
                                              @Override
                                              protected int next(int bits) { return 0; }
                                              
                                              @Override
                                              public double nextGaussian() {
                                                  return nextGaussian;
                                              }
                                              
                                              @Override
                                              public void clear() {
                                                  nextGaussian = Double.NaN;
                                              }
                                          };
                                          
                                          // Use reflection to set the private nextGaussian field since we can't use setNextGaussian()
                                          try {
                                              Field nextGaussianField = generator.getClass().getDeclaredField("nextGaussian");
                                              nextGaussianField.setAccessible(true);
                                              nextGaussianField.setDouble(generator, 1.23);
                                          } catch (Exception e) {
                                              fail("Failed to set nextGaussian field via reflection");
                                          }
                                          
                                          // Act
                                          generator.clear();
                                          
                                          // Assert
                                          assertTrue(Double.isNaN(generator.nextGaussian()));
                                      }

 @Test
                                      public void testNextFloat_ReturnsValueInRange() {
                                          // Create a subclass of BitsStreamGenerator to test protected methods
                                          BitsStreamGenerator generator = new BitsStreamGenerator() {
                                              private int callCount = 0;
                                              
                                              @Override
                                              protected int next(int bits) {
                                                  if (bits == 23) {
                                                      switch (callCount++) {
                                                          case 0: return 0;
                                                          case 1: return 1;
                                                          case 2: return (1 << 23) - 1;
                                                          case 3: return 123456;
                                                          default: return 0;
                                                      }
                                                  }
                                                  return 0;
                                              }
                                              
                                              @Override
                                              public void setSeed(int seed) {
                                              }
                                              
                                              @Override
                                              public void setSeed(int[] seed) {
                                              }
                                              
                                              @Override
                                              public void setSeed(long seed) {
                                              }
                                          };
                                          
                                          // First call: 0 * 2^-23 = 0.0f
                                          assertEquals(0.0f, generator.nextFloat(), 0.0f);
                                          
                                          // Second call: 1 * 2^-23 ≈ 1.1920929E-7f
                                          assertEquals(1.1920929E-7f, generator.nextFloat(), 0.0f);
                                          
                                          // Third call: (2^23 - 1) * 2^-23 ≈ 0.99999994f
                                          assertEquals(0.99999994f, generator.nextFloat(), 0.0f);
                                          
                                          // Fourth call: random value in range
                                          float result = generator.nextFloat();
                                          assertTrue(result >= 0.0f && result < 1.0f);
                                      }

 @Test
                                      public void testNextLong_CallsNext32Twice() {
                                          // Arrange
                                          BitsStreamGenerator generator = new BitsStreamGenerator() {
                                              private int callCount = 0;
                                              
                                              @Override
                                              protected int next(int bits) {
                                                  callCount++;
                                                  return 0;
                                              }
                                          
                                              @Override
                                              public void setSeed(int seed) {
                                              }
                                          
                                              @Override
                                              public void setSeed(int[] seed) {
                                              }
                                          
                                              @Override
                                              public void setSeed(long seed) {
                                              }
                                          };
                                          
                                          // Act
                                          generator.nextLong();
                                          
                                          // Assert
                                          try {
                                              java.lang.reflect.Field field = generator.getClass().getDeclaredField("callCount");
                                              field.setAccessible(true);
                                              int actualCallCount = field.getInt(generator);
                                              assertEquals(2, actualCallCount);
                                          } catch (Exception e) {
                                              fail("Failed to access callCount field: " + e.getMessage());
                                          }
                                      }

 @Test
                              public void testNextInt_ReturnsDifferentValuesOnMultipleCalls() {
                                  // Arrange - create a subclass that we can control
                                  BitsStreamGenerator generator = new BitsStreamGenerator() {
                                      private int callCount = 0;
                                      private final int[] values = {123, 456, 789};
                                      
                                      @Override
                                      protected int next(int bits) {
                                          return values[callCount++ % values.length];
                                      }
                                      
                                      @Override
                                      public void setSeed(int seed) {}
                                      
                                      @Override
                                      public void setSeed(int[] seed) {}
                                      
                                      @Override
                                      public void setSeed(long seed) {}
                                  };
                                  
                                  // Act & Assert
                                  assertEquals(123, generator.nextInt());
                                  assertEquals(456, generator.nextInt());
                                  assertEquals(789, generator.nextInt());
                              }

 @Test
                          public void testNextInt_ReturnsFullRangeOfValues() throws Exception {
                              // Create a named subclass to test the protected method
                              class TestGenerator extends BitsStreamGenerator {
                                  private int nextValue;
                                  
                                  public void setNextValue(int value) {
                                      this.nextValue = value;
                                  }
                                  
                                  @Override
                                  protected int next(int bits) {
                                      return nextValue;
                                  }
                              
                                  @Override
                                  public void setSeed(int seed) {
                                      // Empty implementation for testing
                                  }
                              
                                  @Override
                                  public void setSeed(int[] seed) {
                                      // Empty implementation for testing
                                  }
                              
                                  @Override
                                  public void setSeed(long seed) {
                                      // Empty implementation for testing
                                  }
                              }
                              
                              TestGenerator generator = new TestGenerator();
                          
                              // Test minimum 32-bit value
                              generator.setNextValue(Integer.MIN_VALUE);
                              assertEquals(Integer.MIN_VALUE, generator.nextInt());
                              
                              // Test maximum 32-bit value
                              generator.setNextValue(Integer.MAX_VALUE);
                              assertEquals(Integer.MAX_VALUE, generator.nextInt());
                              
                              // Test zero
                              generator.setNextValue(0);
                              assertEquals(0, generator.nextInt());
                          }

 @Test
                      public void testSetSeed_WithInt() {
                          // Create a concrete implementation of BitsStreamGenerator for testing
                          BitsStreamGenerator concreteGenerator = new BitsStreamGenerator() {
                              private int lastIntSeed;
                              
                              @Override
                              public void setSeed(int seed) {
                                  this.lastIntSeed = seed;
                              }
                              
                              @Override
                              public void setSeed(int[] seed) {
                                  // Not used in this test
                              }
                              
                              @Override
                              public void setSeed(long seed) {
                                  // Not used in this test
                              }
                              
                              @Override
                              protected int next(int bits) {
                                  return 0; // Not used in this test
                              }
                              
                              public int getLastIntSeed() {
                                  return lastIntSeed;
                              }
                          };
                          
                          int testSeed = 12345;
                          concreteGenerator.setSeed(testSeed);
                      }

 @Test
                      public void testSetSeed_WithIntArray() {
                          // Create a concrete instance of the abstract class for testing
                          org.apache.commons.math3.random.BitsStreamGenerator concreteGenerator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                              private int[] lastIntArraySeed;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {
                                  this.lastIntArraySeed = seed;
                              }
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) {
                                  return 0;
                              }
                              
                              public int[] getLastIntArraySeed() {
                                  return lastIntArraySeed;
                              }
                          };
                          
                          int[] testSeed = new int[]{1, 2, 3, 4, 5};
                          concreteGenerator.setSeed(testSeed);
                      }

 @Test
                      public void testSetSeed_WithLong() {
                          // Create a concrete implementation of BitsStreamGenerator for testing
                          BitsStreamGenerator concreteGenerator = new BitsStreamGenerator() {
                              private long lastLongSeed;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {}
                              
                              @Override
                              public void setSeed(long seed) {
                                  this.lastLongSeed = seed;
                              }
                              
                              @Override
                              protected int next(int bits) {
                                  return 0;
                              }
                              
                              public long getLastLongSeed() {
                                  return lastLongSeed;
                              }
                          };
                          
                          long testSeed = 123456789L;
                          concreteGenerator.setSeed(testSeed);
                      }

 @Test
                      public void testSetSeed_WithNegativeInt() {
                          // Create a concrete implementation of BitsStreamGenerator for testing
                          org.apache.commons.math3.random.BitsStreamGenerator concreteGenerator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                              private int lastIntSeed;
                              
                              @Override
                              public void setSeed(int seed) {
                                  this.lastIntSeed = seed;
                              }
                              
                              @Override
                              public void setSeed(int[] seed) {
                                  // Not used in this test
                              }
                              
                              @Override
                              public void setSeed(long seed) {
                                  // Not used in this test
                              }
                              
                              @Override
                              protected int next(int bits) {
                                  return 0; // Not used in this test
                              }
                              
                              public int getLastIntSeed() {
                                  return lastIntSeed;
                              }
                          };
                          
                          int testSeed = -12345;
                          concreteGenerator.setSeed(testSeed);
                      }

 @Test
                      public void testClear_WhenNextGaussianIsAlreadyNaN_RemainsNaN() {
                          // Arrange
                          BitsStreamGenerator generator = new BitsStreamGenerator() {
                              private double nextGaussian = Double.NaN;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {}
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) { return 0; }
                              
                              @Override
                              public boolean nextBoolean() { return false; }
                              
                              @Override
                              public void nextBytes(byte[] bytes) {}
                              
                              @Override
                              public double nextDouble() { return 0; }
                              
                              @Override
                              public float nextFloat() { return 0; }
                              
                              @Override
                              public double nextGaussian() { return nextGaussian; }
                              
                              @Override
                              public int nextInt() { return 0; }
                              
                              @Override
                              public int nextInt(int n) { return 0; }
                              
                              @Override
                              public long nextLong() { return 0; }
                              
                              @Override
                              public void clear() {
                                  nextGaussian = Double.NaN;
                              }
                              
                              public void setNextGaussian(double value) {
                                  this.nextGaussian = value;
                              }
                              
                              public double getNextGaussian() {
                                  return nextGaussian;
                              }
                          };
                          
                          
                          // Act
                          generator.clear();
                          
                          // Assert
                      }

 @Test
                      public void testClear_WhenNextGaussianIsPositiveInfinity_SetsToNaN() {
                          // Arrange
                          BitsStreamGenerator generator = new BitsStreamGenerator() {
                              private double nextGaussian = Double.NaN;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {}
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) { return 0; }
                              
                              public void setNextGaussian(double value) {
                                  this.nextGaussian = value;
                              }
                              
                              @Override
                              public double nextGaussian() {
                                  return nextGaussian;
                              }
                              
                              @Override
                              public void clear() {
                                  nextGaussian = Double.NaN;
                              }
                              
                              @Override
                              public boolean nextBoolean() { return false; }
                              
                              @Override
                              public void nextBytes(byte[] bytes) {}
                              
                              @Override
                              public double nextDouble() { return 0; }
                              
                              @Override
                              public float nextFloat() { return 0; }
                              
                              @Override
                              public int nextInt() { return 0; }
                              
                              @Override
                              public int nextInt(int n) { return 0; }
                              
                              @Override
                              public long nextLong() { return 0; }
                          };
                          
                          
                          // Act
                          generator.clear();
                          
                          // Assert
                          assertTrue(Double.isNaN(generator.nextGaussian()));
                      }

 @Test
                      public void testClear_WhenNextGaussianIsNegativeInfinity_SetsToNaN() {
                          // Arrange
                          BitsStreamGenerator generator = new BitsStreamGenerator() {
                              private double nextGaussian = Double.NaN;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {}
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) { return 0; }
                              
                              public void setNextGaussian(double value) {
                                  this.nextGaussian = value;
                              }
                              
                              @Override
                              public double nextGaussian() {
                                  return nextGaussian;
                              }
                              
                              @Override
                              public void clear() {
                                  nextGaussian = Double.NaN;
                              }
                              
                              @Override
                              public boolean nextBoolean() { return false; }
                              
                              @Override
                              public void nextBytes(byte[] bytes) {}
                              
                              @Override
                              public double nextDouble() { return 0; }
                              
                              @Override
                              public float nextFloat() { return 0; }
                              
                              @Override
                              public int nextInt() { return 0; }
                              
                              @Override
                              public int nextInt(int n) { return 0; }
                              
                              @Override
                              public long nextLong() { return 0; }
                          };
                          
                          
                          // Act
                          generator.clear();
                          
                          // Assert
                          assertTrue(Double.isNaN(generator.nextGaussian()));
                      }

 @Test
                      public void testClear_WhenNextGaussianIsMaxValue_SetsToNaN() {
                          // Arrange
                          BitsStreamGenerator generator = new BitsStreamGenerator() {
                              private double nextGaussian = Double.NaN;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {}
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) { return 0; }
                              
                              public void setNextGaussian(double value) {
                                  this.nextGaussian = value;
                              }
                              
                              @Override
                              public double nextGaussian() {
                                  return nextGaussian;
                              }
                              
                              @Override
                              public void clear() {
                                  nextGaussian = Double.NaN;
                              }
                              
                              @Override
                              public boolean nextBoolean() { return false; }
                              
                              @Override
                              public void nextBytes(byte[] bytes) {}
                              
                              @Override
                              public double nextDouble() { return 0; }
                              
                              @Override
                              public float nextFloat() { return 0; }
                              
                              @Override
                              public int nextInt() { return 0; }
                              
                              @Override
                              public int nextInt(int n) { return 0; }
                              
                              @Override
                              public long nextLong() { return 0; }
                          };
                          
                          
                          // Act
                          generator.clear();
                          
                          // Assert
                          assertTrue(Double.isNaN(generator.nextGaussian()));
                      }

 @Test
                      public void testClear_WhenNextGaussianIsMinValue_SetsToNaN() {
                          // Arrange
                          org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                              private double nextGaussian = Double.NaN;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {}
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) { return 0; }
                              
                              public void setNextGaussian(double value) {
                                  this.nextGaussian = value;
                              }
                              
                              @Override
                              public double nextGaussian() {
                                  return nextGaussian;
                              }
                              
                              @Override
                              public void clear() {
                                  nextGaussian = Double.NaN;
                              }
                              
                              @Override
                              public boolean nextBoolean() { return false; }
                              
                              @Override
                              public void nextBytes(byte[] bytes) {}
                              
                              @Override
                              public double nextDouble() { return 0.0; }
                              
                              @Override
                              public float nextFloat() { return 0.0f; }
                              
                              @Override
                              public int nextInt() { return 0; }
                              
                              @Override
                              public int nextInt(int n) { return 0; }
                              
                              @Override
                              public long nextLong() { return 0L; }
                          };
                          
                          // Set initial value
                          
                          // Act
                          generator.clear();
                          
                          // Assert
                          assertTrue(Double.isNaN(generator.nextGaussian()));
                      }

 @Test
                      public void testSetSeed_WithInt1() {
                          // Create a concrete implementation of BitsStreamGenerator for testing
                          BitsStreamGenerator concreteGenerator = new BitsStreamGenerator() {
                              private int lastIntSeed;
                              
                              @Override
                              public void setSeed(int seed) {
                                  this.lastIntSeed = seed;
                              }
                              
                              @Override
                              public void setSeed(int[] seed) {
                                  // Not used in this test
                              }
                              
                              @Override
                              public void setSeed(long seed) {
                                  // Not used in this test
                              }
                              
                              @Override
                              protected int next(int bits) {
                                  return 0; // Not used in this test
                              }
                              
                              public int getLastIntSeed() {
                                  return lastIntSeed;
                              }
                          };
                          
                          int testSeed = 12345;
                          concreteGenerator.setSeed(testSeed);
                      }

 @Test
                      public void testSetSeed_WithIntArray1() {
                          // Create a concrete instance of the abstract class for testing
                          org.apache.commons.math3.random.BitsStreamGenerator concreteGenerator = 
                              new org.apache.commons.math3.random.BitsStreamGenerator() {
                                  private int[] lastIntArraySeed;
                                  
                                  @Override
                                  public void setSeed(int seed) {}
                                  
                                  @Override
                                  public void setSeed(int[] seed) {
                                      this.lastIntArraySeed = seed;
                                  }
                                  
                                  @Override
                                  public void setSeed(long seed) {}
                                  
                                  @Override
                                  protected int next(int bits) {
                                      return 0;
                                  }
                                  
                                  public int[] getLastIntArraySeed() {
                                      return lastIntArraySeed;
                                  }
                              };
                          
                          int[] testSeed = {1, 2, 3, 4, 5};
                          concreteGenerator.setSeed(testSeed);
                      }

 @Test
                      public void testSetSeed_WithIntArray_EmptyArray() {
                          // Create a concrete implementation of BitsStreamGenerator for testing
                          BitsStreamGenerator concreteGenerator = new BitsStreamGenerator() {
                              private int[] lastIntArraySeed;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {
                                  this.lastIntArraySeed = seed;
                              }
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) {
                                  return 0;
                              }
                              
                              public int[] getLastIntArraySeed() {
                                  return lastIntArraySeed;
                              }
                          };
                          
                          int[] testSeed = new int[0];
                          concreteGenerator.setSeed(testSeed);
                      }

 @Test
                      public void testSetSeed_WithLong1() {
                          // Create a concrete implementation of BitsStreamGenerator for testing
                          org.apache.commons.math3.random.BitsStreamGenerator concreteGenerator = 
                              new org.apache.commons.math3.random.BitsStreamGenerator() {
                                  private long lastLongSeed;
                                  
                                  @Override
                                  public void setSeed(int seed) {}
                                  
                                  @Override
                                  public void setSeed(int[] seed) {}
                                  
                                  @Override
                                  public void setSeed(long seed) {
                                      this.lastLongSeed = seed;
                                  }
                                  
                                  @Override
                                  protected int next(int bits) {
                                      return 0;
                                  }
                                  
                                  // Make this method public to ensure it's accessible
                                  public long getLastLongSeed() {
                                      return this.lastLongSeed;
                                  }
                              };
                          
                          long testSeed = 123456789L;
                          concreteGenerator.setSeed(testSeed);
                      }

 @Test
                      public void testSetSeed_WithNegativeInt1() {
                          // Create a concrete implementation of BitsStreamGenerator for testing
                          BitsStreamGenerator concreteGenerator = new BitsStreamGenerator() {
                              private int lastIntSeed;
                              private double nextGaussian = Double.NaN;
                              
                              @Override
                              public void setSeed(int seed) {
                                  this.lastIntSeed = seed;
                              }
                              
                              @Override
                              public void setSeed(int[] seed) {
                                  // Not used in this test
                              }
                              
                              @Override
                              public void setSeed(long seed) {
                                  // Not used in this test
                              }
                              
                              @Override
                              protected int next(int bits) {
                                  return 0; // Not used in this test
                              }
                              
                              public int getLastIntSeed() {
                                  return lastIntSeed;
                              }
                              
                              @Override
                              public boolean nextBoolean() {
                                  return false;
                              }
                              
                              @Override
                              public void nextBytes(byte[] bytes) {
                              }
                              
                              @Override
                              public double nextDouble() {
                                  return 0;
                              }
                              
                              @Override
                              public float nextFloat() {
                                  return 0;
                              }
                              
                              @Override
                              public double nextGaussian() {
                                  return 0;
                              }
                              
                              @Override
                              public int nextInt() {
                                  return 0;
                              }
                              
                              @Override
                              public int nextInt(int n) {
                                  return 0;
                              }
                              
                              @Override
                              public long nextLong() {
                                  return 0;
                              }
                              
                              @Override
                              public void clear() {
                              }
                          };
                          
                          int testSeed = -12345;
                          concreteGenerator.setSeed(testSeed);
                      }

 @Test
                      public void testSetSeed_WithNegativeLong() {
                          // Create a concrete instance of the abstract class for testing
                          org.apache.commons.math3.random.BitsStreamGenerator concreteGenerator = 
                              new org.apache.commons.math3.random.BitsStreamGenerator() {
                                  private long lastSeed;
                                  
                                  @Override
                                  public void setSeed(int seed) {}
                                  
                                  @Override
                                  public void setSeed(int[] seed) {}
                                  
                                  @Override
                                  public void setSeed(long seed) {
                                      this.lastSeed = seed;
                                  }
                                  
                                  @Override
                                  protected int next(int bits) {
                                      return 0;
                                  }
                                  
                                  public long getLastLongSeed() {
                                      return lastSeed;
                                  }
                              };
                          
                          long testSeed = -123456789L;
                          concreteGenerator.setSeed(testSeed);
                      }

 @Test
                      public void testNextBoolean_UsesNextMethod() {
                          // Create a mock of BitsStreamGenerator
                          org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                              private int nextValue;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {}
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) {
                                  return nextValue;
                              }
                              
                              public void setNextValue(int value) {
                                  this.nextValue = value;
                              }
                          };
                          
                          // Test that nextBoolean uses next(1)
                          assertTrue(generator.nextBoolean());
                          
                          assertFalse(generator.nextBoolean());
                      }

 @Test
                      public void testNextInt_UsesNextMethod() {
                          // Create a concrete implementation of BitsStreamGenerator for testing
                          BitsStreamGenerator generator = new BitsStreamGenerator() {
                              private int nextValue;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {}
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) {
                                  // Verify that nextInt() calls next(32)
                                  assertEquals(32, bits);
                                  return nextValue;
                              }
                              
                              public void setNextValue(int value) {
                                  this.nextValue = value;
                              }
                          };
                          
                          // Test that nextInt uses next(32)
                          int expectedValue = 123456789;
                          assertEquals(expectedValue, generator.nextInt());
                      }

 @Test
                      public void testNextFloat_UsesNextMethod() {
                          // Create a concrete implementation of BitsStreamGenerator for testing
                          BitsStreamGenerator generator = new BitsStreamGenerator() {
                              private int nextValue;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {}
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) {
                                  return nextValue;
                              }
                              
                              public void setNextValue(int value) {
                                  this.nextValue = value;
                              }
                              
                              @Override
                              public boolean nextBoolean() {
                                  return next(1) != 0;
                              }
                              
                              @Override
                              public void nextBytes(byte[] bytes) {
                                  // Not used in this test
                              }
                              
                              @Override
                              public double nextDouble() {
                                  // Not used in this test
                                  return 0;
                              }
                              
                              @Override
                              public float nextFloat() {
                                  return Float.intBitsToFloat(next(24) >>> 8);
                              }
                              
                              @Override
                              public double nextGaussian() {
                                  // Not used in this test
                                  return 0;
                              }
                              
                              @Override
                              public int nextInt() {
                                  // Not used in this test
                                  return 0;
                              }
                              
                              @Override
                              public int nextInt(int n) {
                                  // Not used in this test
                                  return 0;
                              }
                              
                              @Override
                              public long nextLong() {
                                  // Not used in this test
                                  return 0;
                              }
                              
                              @Override
                              public void clear() {
                                  // Not used in this test
                              }
                          };
                          
                          // Test that nextFloat uses next(24)
                          assertEquals(1.0f, generator.nextFloat(), 0.0001f);
                      }

 @Test
                      public void testNextDouble_UsesNextMethod() {
                          // Create a concrete implementation of BitsStreamGenerator for testing
                          org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                              private int nextValue;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {}
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) {
                                  return nextValue;
                              }
                              
                              public void setNextValue(int value) {
                                  this.nextValue = value;
                              }
                          };
                          
                          // Test that next() returns the set value
                          try {
                              // Get the protected next method from the parent class
                              java.lang.reflect.Method nextMethod = org.apache.commons.math3.random.BitsStreamGenerator.class
                                  .getDeclaredMethod("next", int.class);
                              nextMethod.setAccessible(true);
                              int result = (int) nextMethod.invoke(generator, 26);
                              org.junit.Assert.assertEquals(0x3FF00000, result);
                          } catch (Exception e) {
                              org.junit.Assert.fail("Reflection failed: " + e.getMessage());
                          }
                      }

 @Test
                      public void testNextGaussian_WhenNaN() {
                          // Create a mock generator that extends BitsStreamGenerator
                          org.apache.commons.math3.random.BitsStreamGenerator generator = new org.apache.commons.math3.random.BitsStreamGenerator() {
                              private long nextValue;
                              
                              @Override
                              public void setSeed(int seed) {}
                              
                              @Override
                              public void setSeed(int[] seed) {}
                              
                              @Override
                              public void setSeed(long seed) {}
                              
                              @Override
                              protected int next(int bits) {
                                  return (int)(nextValue & ((1L << bits) - 1));
                              }
                              
                              public void setNextValue(long value) {
                                  this.nextValue = value;
                              }
                          };
                          
                          // First call should compute new Gaussian value
                          // We need to access the anonymous class's setNextValue method
                          // Since we can't cast to the anonymous class, we'll use reflection
                          try {
                              Method setNextValue = generator.getClass().getMethod("setNextValue", long.class);
                              setNextValue.invoke(generator, 0x3FF00000L); // Mock values that would produce a Gaussian
                              double result = generator.nextGaussian();
                              assertNotEquals(Double.NaN, result, 0.0001);
                              
                              // Second call should return cached value
                              setNextValue.invoke(generator, 0L); // Different value that would normally produce different result
                              assertEquals(result, generator.nextGaussian(), 0.0001);
                          } catch (Exception e) {
                              fail("Failed to invoke setNextValue method: " + e.getMessage());
                          }
                      }

 @Test
          public void testNext_WithMoreThanThirtyTwoBits() {
              BitsStreamGenerator generator = new BitsStreamGenerator() {
                  private int nextValue;
                  private double nextGaussian;
                  
                  @Override
                  public void setSeed(int seed) {}
                  
                  @Override
                  public void setSeed(int[] seed) {}
                  
                  @Override
                  public void setSeed(long seed) {}
                  
                  @Override
                  protected int next(int bits) {
                      return nextValue;
                  }
                  
                  public void setNextValue(int value) {
                      this.nextValue = value;
                  }
                  
                  @Override
                  public double nextGaussian() {
                      return nextGaussian;
                  }
                  
                  @Override
                  public boolean nextBoolean() {
                      return false;
                  }
                  
                  @Override
                  public void nextBytes(byte[] bytes) {}
                  
                  @Override
                  public double nextDouble() {
                      return 0;
                  }
                  
                  @Override
                  public float nextFloat() {
                      return 0;
                  }
                  
                  @Override
                  public int nextInt() {
                      return 0;
                  }
                  
                  @Override
                  public int nextInt(int n) {
                      return 0;
                  }
                  
                  @Override
                  public long nextLong() {
                      return 0;
                  }
                  
                  @Override
                  public void clear() {}
              };
              
              // Use reflection to set the nextValue since it's private
              try {
                  Field nextValueField = generator.getClass().getDeclaredField("nextValue");
                  nextValueField.setAccessible(true);
                  nextValueField.set(generator, 0xFFFFFFFF);
              } catch (Exception e) {
                  fail("Failed to set nextValue via reflection: " + e.getMessage());
              }
              
              // Use reflection to call the protected next() method
              try {
                  Method nextMethod = BitsStreamGenerator.class.getDeclaredMethod("next", int.class);
                  nextMethod.setAccessible(true);
                  int result = (int) nextMethod.invoke(generator, 32);
                  assertEquals(0xFFFFFFFF, result);
              } catch (Exception e) {
                  fail("Failed to invoke next() method: " + e.getMessage());
              }
          }

}
