package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
 
public class FractionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testConstructor_WithZeroValue() {
                                                Fraction fraction = new Fraction(0.0);
                                                assertEquals(0, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithIntegerValue() {
                                                Fraction fraction = new Fraction(5.0);
                                                assertEquals(5, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithNegativeValue() {
                                                Fraction fraction = new Fraction(-3.0);
                                                assertEquals(-3, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithSimpleFraction() {
                                                Fraction fraction = new Fraction(0.5);
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(2, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithCommonFraction() {
                                                Fraction fraction = new Fraction(0.3333333333);
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(3, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithRepeatingDecimal() {
                                                Fraction fraction = new Fraction(0.6666666666);
                                                assertEquals(2, fraction.getNumerator());
                                                assertEquals(3, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithPrecisionLimit() {
                                                // Test a value that requires precision within the default epsilon
                                                Fraction fraction = new Fraction(0.123456789);
                                                double delta = Math.abs(0.123456789 - fraction.doubleValue());
                                                assertTrue(delta <= 1.0e-5);
                                            }

    @Test
                                            public void testConstructor_WithVerySmallValue() {
                                                Fraction fraction = new Fraction(1.0e-6);
                                                assertNotEquals(0, fraction.getNumerator());
                                                assertTrue(fraction.doubleValue() > 0);
                                            }

    @Test
                                            public void testConstructor_WithVeryLargeValue() {
                                                Fraction fraction = new Fraction(1.0e6);
                                                assertEquals(1000000, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithNaNValue() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(Double.NaN);
                                            }

    @Test
                                            public void testConstructor_WithPositiveInfinity() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(Double.POSITIVE_INFINITY);
                                            }

    @Test
                                            public void testConstructor_WithNegativeInfinity() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(Double.NEGATIVE_INFINITY);
                                            }

    @Test
                                            public void testConstructor_WithPredefinedFractionValues() {
                                                // Test that constructor produces same fractions as predefined constants
                                                Fraction half = new Fraction(0.5);
                                                assertEquals(Fraction.ONE_HALF.getNumerator(), half.getNumerator());
                                                assertEquals(Fraction.ONE_HALF.getDenominator(), half.getDenominator());
                                        
                                                Fraction third = new Fraction(1.0/3.0);
                                                assertEquals(Fraction.ONE_THIRD.getNumerator(), third.getNumerator());
                                                assertEquals(Fraction.ONE_THIRD.getDenominator(), third.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithValueVeryCloseToPredefinedFraction() {
                                                // Test value just slightly different from a known fraction
                                                Fraction almostHalf = new Fraction(0.500001);
                                                assertEquals(Fraction.ONE_HALF.getNumerator(), almostHalf.getNumerator());
                                                assertEquals(Fraction.ONE_HALF.getDenominator(), almostHalf.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithTypicalValues() {
                                                Fraction half = new Fraction(0.5, 0.0001, 100);
                                                assertEquals(1, half.getNumerator());
                                                assertEquals(2, half.getDenominator());
                                                
                                                Fraction third = new Fraction(0.33333, 0.0001, 100);
                                                assertEquals(1, third.getNumerator());
                                                assertEquals(3, third.getDenominator());
                                                
                                                Fraction quarter = new Fraction(0.25, 0.0001, 100);
                                                assertEquals(1, quarter.getNumerator());
                                                assertEquals(4, quarter.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithZeroValue1() {
                                                Fraction zero = new Fraction(0.0, 0.0001, 100);
                                                assertEquals(0, zero.getNumerator());
                                                assertEquals(1, zero.getDenominator());
                                                assertSame(Fraction.ZERO, zero);
                                            }

    @Test
                                            public void testConstructor_WithNegativeValues() {
                                                Fraction negativeHalf = new Fraction(-0.5, 0.0001, 100);
                                                assertEquals(-1, negativeHalf.getNumerator());
                                                assertEquals(2, negativeHalf.getDenominator());
                                                
                                                Fraction negativeThird = new Fraction(-0.33333, 0.0001, 100);
                                                assertEquals(-1, negativeThird.getNumerator());
                                                assertEquals(3, negativeThird.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithVerySmallEpsilon() {
                                                Fraction piApprox = new Fraction(3.1415926535, 0.0000001, 1000);
                                                assertEquals(355, piApprox.getNumerator());
                                                assertEquals(113, piApprox.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithLargerEpsilon() {
                                                Fraction approx = new Fraction(0.123456, 0.01, 100);
                                                assertEquals(1, approx.getNumerator());
                                                assertEquals(8, approx.getDenominator()); // 1/8 = 0.125
                                            }

    @Test
                                            public void testConstructor_WhenMaxIterationsReached() {
                                                // This should still work but might be less precise
                                                Fraction fraction = new Fraction(0.123456789, 0.000000001, 5);
                                                // We can't predict exact values but should have some approximation
                                                assertNotNull(fraction);
                                                assertTrue(Math.abs(fraction.doubleValue() - 0.123456789) < 0.1);
                                            }

    @Test
                                            public void testConstructor_WithZeroEpsilon_ThrowsException() {
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("epsilon must be > 0");
                                                new Fraction(0.5, 0.0, 100);
                                            }

    @Test
                                            public void testConstructor_WithNegativeEpsilon_ThrowsException() {
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("epsilon must be > 0");
                                                new Fraction(0.5, -0.1, 100);
                                            }

    @Test
                                            public void testConstructor_WithZeroMaxIterations_ThrowsException() {
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("maximum number of iterations must be > 0");
                                                new Fraction(0.5, 0.0001, 0);
                                            }

    @Test
                                            public void testConstructor_WithNegativeMaxIterations_ThrowsException() {
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("maximum number of iterations must be > 0");
                                                new Fraction(0.5, 0.0001, -100);
                                            }

    @Test
                                            public void testConstructor_WithLargeValue() {
                                                Fraction large = new Fraction(123456.789, 0.001, 1000);
                                                // Verify it's a reasonable approximation
                                                assertTrue(Math.abs(large.doubleValue() - 123456.789) < 0.001);
                                            }

    @Test
                                            public void testConstructor_WithVerySmallValue1() {
                                                Fraction small = new Fraction(0.000000123, 0.000000001, 1000);
                                                // Verify it's a reasonable approximation
                                                assertTrue(Math.abs(small.doubleValue() - 0.000000123) < 0.000000001);
                                            }

    @Test
                                            public void testConstructor_ReturnsCachedConstants() {
                                                Fraction half = new Fraction(0.5, 0.0001, 100);
                                                assertSame(Fraction.ONE_HALF, half);
                                                
                                                Fraction third = new Fraction(0.33333, 0.0001, 100);
                                                assertSame(Fraction.ONE_THIRD, third);
                                                
                                                Fraction quarter = new Fraction(0.25, 0.0001, 100);
                                                assertSame(Fraction.ONE_QUARTER, quarter);
                                            }

    @Test
                                            public void testConstructor_SimpleFractions() {
                                                // Test simple fractions that can be exactly represented
                                                Fraction half = new Fraction(0.5, 100);
                                                assertEquals(1, half.getNumerator());
                                                assertEquals(2, half.getDenominator());
                                        
                                                Fraction third = new Fraction(1.0/3, 100);
                                                assertEquals(1, third.getNumerator());
                                                assertEquals(3, third.getDenominator());
                                        
                                                Fraction twoThirds = new Fraction(2.0/3, 100);
                                                assertEquals(2, twoThirds.getNumerator());
                                                assertEquals(3, twoThirds.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WholeNumbers() {
                                                // Test whole numbers
                                                Fraction five = new Fraction(5.0, 100);
                                                assertEquals(5, five.getNumerator());
                                                assertEquals(1, five.getDenominator());
                                        
                                                Fraction zero = new Fraction(0.0, 100);
                                                assertEquals(0, zero.getNumerator());
                                                assertEquals(1, zero.getDenominator());
                                        
                                                Fraction negativeTwo = new Fraction(-2.0, 100);
                                                assertEquals(-2, negativeTwo.getNumerator());
                                                assertEquals(1, negativeTwo.getDenominator());
                                            }

    @Test
                                            public void testConstructor_ApproximateFractions() {
                                                // Test approximations with limited denominator
                                                Fraction piApprox = new Fraction(Math.PI, 7);
                                                assertEquals(22, piApprox.getNumerator());
                                                assertEquals(7, piApprox.getDenominator());
                                        
                                                Fraction eApprox = new Fraction(Math.E, 7);
                                                assertEquals(19, eApprox.getNumerator());
                                                assertEquals(7, eApprox.getDenominator());
                                            }

    @Test
                                            public void testConstructor_NegativeValues() {
                                                // Test negative fractions
                                                Fraction negativeHalf = new Fraction(-0.5, 100);
                                                assertEquals(-1, negativeHalf.getNumerator());
                                                assertEquals(2, negativeHalf.getDenominator());
                                        
                                                Fraction negativeApprox = new Fraction(-Math.PI, 7);
                                                assertEquals(-22, negativeApprox.getNumerator());
                                                assertEquals(7, negativeApprox.getDenominator());
                                            }

    @Test
                                            public void testConstructor_EdgeCases() {
                                                // Test edge cases
                                                Fraction verySmall = new Fraction(0.0001, 10000);
                                                assertEquals(1, verySmall.getNumerator());
                                                assertEquals(10000, verySmall.getDenominator());
                                        
                                                Fraction veryCloseToOne = new Fraction(0.9999, 100);
                                                assertEquals(100, veryCloseToOne.getNumerator());
                                                assertEquals(100, veryCloseToOne.getDenominator());
                                            }

    @Test
                                            public void testConstructor_MaxDenominatorLimits() {
                                                // Test that max denominator is respected
                                                Fraction limitedPi = new Fraction(Math.PI, 10);
                                                assertTrue(limitedPi.getDenominator() <= 10);
                                        
                                                Fraction limitedE = new Fraction(Math.E, 5);
                                                assertTrue(limitedE.getDenominator() <= 5);
                                            }

    @Test
                                            public void testConstructor_ZeroMaxDenominator() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(0.5, 0);
                                            }

    @Test
                                            public void testConstructor_NegativeMaxDenominator() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(0.5, -1);
                                            }

    @Test
                                            public void testConstructor_Infinity() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(Double.POSITIVE_INFINITY, 100);
                                            }

    @Test
                                            public void testConstructor_NaN() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(Double.NaN, 100);
                                            }

    @Test
                                            public void testConstructor_CompareWithStaticConstants() {
                                                // Test that constructor matches static constants
                                                Fraction half = new Fraction(0.5, 100);
                                                assertEquals(Fraction.ONE_HALF, half);
                                        
                                                Fraction third = new Fraction(1.0/3, 100);
                                                assertEquals(Fraction.ONE_THIRD, third);
                                        
                                                Fraction twoThirds = new Fraction(2.0/3, 100);
                                                assertEquals(Fraction.TWO_THIRDS, twoThirds);
                                            }

    @Test
                                            public void testConstructorWithIntegerValue() {
                                                Fraction fraction = Fraction.getReducedFraction(3, 1);
                                                assertEquals(3, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithExactFraction() {
                                                Fraction fraction = Fraction.getReducedFraction(1, 2);
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(2, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithValueCloseToEpsilon() {
                                                // This should be treated as 0.5 since it's within default epsilon
                                                Fraction fraction = Fraction.getReducedFraction(1, 2);
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(2, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithMaxDenominator() {
                                                Fraction fraction = Fraction.getReducedFraction(1, 100);
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(100, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithNegativeValue() {
                                                Fraction fraction = Fraction.getReducedFraction(-1, 2);
                                                assertEquals(-1, fraction.getNumerator());
                                                assertEquals(2, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithZeroValue() {
                                                Fraction fraction = Fraction.getReducedFraction(0, 1);
                                                assertEquals(0, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorReducesFraction() {
                                                Fraction fraction = Fraction.getReducedFraction(2, 4);
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(2, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithReciprocal() {
                                                Fraction fraction = Fraction.getReducedFraction(5, 1).reciprocal();
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(5, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithInt_PositiveNumber() {
                                                Fraction fraction = new Fraction(3);
                                                assertEquals(3, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithInt_NegativeNumber() {
                                                Fraction fraction = new Fraction(-5);
                                                assertEquals(-5, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithInt_Zero() {
                                                Fraction fraction = new Fraction(0);
                                                assertEquals(0, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithInt_MaxValue() {
                                                Fraction fraction = new Fraction(Integer.MAX_VALUE);
                                                assertEquals(Integer.MAX_VALUE, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithInt_MinValue() {
                                                Fraction fraction = new Fraction(Integer.MIN_VALUE);
                                                assertEquals(Integer.MIN_VALUE, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructorWithInt_EqualsMethod() {
                                                Fraction fraction1 = new Fraction(7);
                                                Fraction fraction2 = new Fraction(7);
                                                assertTrue(fraction1.equals(fraction2));
                                            }

    @Test
                                            public void testConstructorWithInt_NotEqualsMethod() {
                                                Fraction fraction1 = new Fraction(7);
                                                Fraction fraction2 = new Fraction(8);
                                                assertFalse(fraction1.equals(fraction2));
                                            }

    @Test
                                            public void testConstructorWithInt_ToString() {
                                                Fraction fraction = new Fraction(4);
                                                assertEquals("4", fraction.toString());
                                            }

    @Test
                                            public void testConstructorWithInt_DoubleValue() {
                                                Fraction fraction = new Fraction(3);
                                                assertEquals(3.0, fraction.doubleValue(), 0.0001);
                                            }

    @Test
                                            public void testConstructorWithInt_FloatValue() {
                                                Fraction fraction = new Fraction(3);
                                                assertEquals(3.0f, fraction.floatValue(), 0.0001);
                                            }

    @Test
                                            public void testConstructorWithInt_IntValue() {
                                                Fraction fraction = new Fraction(3);
                                                assertEquals(3, fraction.intValue());
                                            }

    @Test
                                            public void testConstructorWithInt_LongValue() {
                                                Fraction fraction = new Fraction(3);
                                                assertEquals(3L, fraction.longValue());
                                            }

    @Test
                                            public void testConstructor_NormalFraction() {
                                                Fraction fraction = new Fraction(3, 4);
                                                assertEquals(3, fraction.getNumerator());
                                                assertEquals(4, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_FractionReduction() {
                                                Fraction fraction = new Fraction(6, 8);
                                                assertEquals(3, fraction.getNumerator());
                                                assertEquals(4, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_NegativeDenominator() {
                                                Fraction fraction = new Fraction(3, -4);
                                                assertEquals(-3, fraction.getNumerator());
                                                assertEquals(4, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_BothNegative() {
                                                Fraction fraction = new Fraction(-3, -4);
                                                assertEquals(3, fraction.getNumerator());
                                                assertEquals(4, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_ZeroNumerator() {
                                                Fraction fraction = new Fraction(0, 5);
                                                assertEquals(0, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator()); // Should be reduced to 0/1
                                            }

    @Test
                                            public void testConstructor_ReductionWithGCD() {
                                                Fraction fraction = new Fraction(15, 25);
                                                assertEquals(3, fraction.getNumerator());
                                                assertEquals(5, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_DenominatorOne() {
                                                Fraction fraction = new Fraction(7, 1);
                                                assertEquals(7, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_NumeratorEqualsDenominator() {
                                                Fraction fraction = new Fraction(5, 5);
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                    public void testConstructorThrowsWhenDenominatorOverflows() {
                                        ExpectedException exception = ExpectedException.none();
                                        exception.expect(FractionConversionException.class);
                                        Fraction.getReducedFraction(1, Integer.MAX_VALUE);
                                    }

    @Test
                                    public void testConstructorWithMaxIterationsReached() {
                                        ExpectedException exception = ExpectedException.none();
                                        exception.expect(FractionConversionException.class);
                                        // This will force the iteration limit to be reached
                                        Fraction.getReducedFraction(1, 1000000);
                                    }

    @Test
                                    public void testConstructor_ZeroDenominator() {
                                        org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                        exception.expect(org.apache.commons.math3.exception.MathArithmeticException.class);
                                        exception.expectMessage(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION.toString());
                                        new Fraction(1, 0);
                                    }

    @Test
                                    public void testConstructor_MinValueEdgeCase() {
                                        org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                        exception.expect(org.apache.commons.math3.exception.MathArithmeticException.class);
                                        exception.expectMessage(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION.toString());
                                        new Fraction(Integer.MIN_VALUE, -1);
                                    }

    @Test
                                    public void testConstructor_MinValueDenominator() {
                                        org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                        exception.expect(org.apache.commons.math3.exception.MathArithmeticException.class);
                                        exception.expectMessage(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION.toString());
                                        new Fraction(1, Integer.MIN_VALUE);
                                    }

    @Test(expected = ArithmeticException.class)
                                public void testConstructorThrowsWhenNumeratorOverflows() {
                                    Fraction.getReducedFraction(Integer.MAX_VALUE, 1);
                                }

    @Test
                            public void testFractionCreationWithNegativeValueDetectsFloorMutation() {
                                // Test with a negative double value where floor behavior differs from cast
                                double value = -3.7;
                                
                                // Create fraction - should be -37/10 with proper floor behavior
                                Fraction fraction = new Fraction(value);
                                
                                // With mutation (direct cast), numerator would be -3*10 + -7 = -37
                                // But with floor, we should get -4 + 0.3 = -37/10
                                // So both cases actually give same result here - need more precise test
                                
                                // Better test case - value where fractional part is > 0.5
                                value = -2.6;
                                fraction = new Fraction(value);
                                
                                // Proper floor behavior: floor(-2.6) = -3, remainder 0.4 → -3 + 0.4 = -2.6 → -26/10 → -13/5
                                // Mutant behavior: (long)-2.6 = -2, remainder -0.6 → -2 + -0.6 = -2.6 → -26/10 → -13/5
                                // Still same - need different approach
                                
                                // Even better - test the components directly by accessing numerator/denominator
                                value = -1.75;
                                fraction = new Fraction(value);
                                
                                // Original: floor(-1.75) = -2, remainder 0.25 → -2 + 0.25 = -1.75 → -7/4
                                // Mutant: (long)-1.75 = -1, remainder -0.75 → -1 + -0.75 = -1.75 → -7/4
                                // Still same - seems this mutation might not affect final fraction
                                
                                // Alternative approach - test with value that would have different continued fraction
                                // representation depending on floor vs truncate
                                value = 0.9999999999;
                                fraction = new Fraction(value);
                                
                                // Original would floor to 0, mutant would truncate to 0 - same result
                                // This mutation might actually be equivalent for all inputs
                                
                                // After careful analysis, it appears this particular mutation might not
                                // produce detectable differences in the final Fraction due to how the
                                // continued fraction algorithm works. The test would need to access
                                // intermediate values to detect it.
                                
                                // Since we can't test intermediate private calculations, we might need to:
                                // 1. Test with very large values where floating point precision matters
                                // 2. Or conclude this mutant is actually equivalent
                                
                                // Final attempt with very precise value:
                                value = 1.0e16 + 0.5;
                                fraction = new Fraction(value);
                                // Original: floor would give 1.0e16 exactly
                                // Mutant: cast would give 1.0e16 exactly
                                // Still same
                                
                                // Conclusion: This mutation appears to be equivalent for all practical inputs
                                // in the context of the Fraction class. It cannot be detected through normal
                                // Fraction method outputs.
                            }

    @Test
                            public void testFractionConversionWithNegativeValue() {
                                // This test will catch the mutant because:
                                // Original: floor(-1.2) → -2 → creates fraction -2/1
                                // Mutant: (long)(-1.2) → -1 → creates fraction -1/1
                                
                                // Test with a negative value that has decimal part
                                Fraction fraction = new Fraction(-1.2, 100, 100);
                                
                                // Verify the numerator and denominator
                                // Original would give -6/5 (after reduction) or similar
                                // Mutant would give -1/1
                                assertEquals(-6, fraction.getNumerator());
                                assertEquals(5, fraction.getDenominator());
                                
                                // Also test the double value to ensure proper conversion
                                assertEquals(-1.2, fraction.doubleValue(), 0.0001);
                            }

    @Test
                            public void testFractionConversionWithPositiveValue() {
                                // Additional test case for positive value where floor and cast behave same
                                // This ensures we don't break the normal case
                                Fraction fraction = new Fraction(1.2, 100, 100);
                                
                                assertEquals(6, fraction.getNumerator());
                                assertEquals(5, fraction.getDenominator());
                                assertEquals(1.2, fraction.doubleValue(), 0.0001);
                            }

    @Test
                                public void testConstructorWithNegativeDecimal() {
                                    // This test will catch the mutant by using a negative decimal value
                                    // Original: FastMath.floor(-1.5) → -2.0 → fraction -2/1
                                    // Mutant: (long)(-1.5) → -1 → fraction -1/1
                                    Fraction fraction = new Fraction(-1.5);
                                    
                                    // Verify numerator and denominator
                                    assertEquals(-3, fraction.getNumerator());  // -1.5 should become -3/2
                                    assertEquals(2, fraction.getDenominator());
                                    
                                    // Verify the double value matches expected
                                    assertEquals(-1.5, fraction.doubleValue(), 0.00001);
                                }

    @Test
                                public void testConstructorWithPositiveDecimal() {
                                    // Test positive decimal case
                                    Fraction fraction = new Fraction(1.5);
                                    assertEquals(3, fraction.getNumerator());  // 1.5 should become 3/2
                                    assertEquals(2, fraction.getDenominator());
                                    assertEquals(1.5, fraction.doubleValue(), 0.00001);
                                }

    @Test
                                public void testConstructorWithIntegerValue1() {
                                    // Test case where input is exactly an integer
                                    Fraction fraction = new Fraction(2.0);
                                    assertEquals(2, fraction.getNumerator());
                                    assertEquals(1, fraction.getDenominator());
                                    assertEquals(2.0, fraction.doubleValue(), 0.00001);
                                }

    @Test
                            public void testNegativeFractionReduction() {
                                // Test case that would show difference between floor() and direct cast
                                // for negative numbers
                                Fraction f = new Fraction(-3, 2);  // -1.5
                                
                                // With floor(): numerator would be -3/2 = -1.5 -> floor(-1.5) = -2
                                // With direct cast: (long)-1.5 = -1
                                // So we need to verify the numerator is properly reduced
                                
                                // Verify numerator and denominator after reduction
                                assertEquals(-3, f.getNumerator());
                                assertEquals(2, f.getDenominator());
                                
                                // Test another case that would show the difference
                                Fraction f2 = new Fraction(-5, 3);  // -1.666...
                                assertEquals(-5, f2.getNumerator());
                                assertEquals(3, f2.getDenominator());
                                
                                // Test boundary case where floor and cast would give same result
                                Fraction f3 = new Fraction(-4, 2);  // -2.0
                                assertEquals(-2, f3.getNumerator());
                                assertEquals(1, f3.getDenominator());
                            }

    @Test
                           public void testNegativeFractionCreationWithDecimal() {
                               // This test will catch the mutant where FastMath.floor() was replaced with direct cast
                               // For value = -1.5:
                               // - Original (with floor): floor(-1.5) = -2
                               // - Mutant (direct cast): (long)(-1.5) = -1
                               // This difference will propagate to the fraction creation
                               
                               double value = -1.5;
                               double epsilon = 0.00001;
                               int maxIterations = 100; // Adding default max iterations value
                               
                               // Create fraction with the original implementation
                               Fraction originalFraction = new Fraction(value, epsilon, maxIterations);
                               
                               // Verify the numerator and denominator
                               // For -1.5, best fraction approximation would be -3/2
                               assertEquals(-3, originalFraction.getNumerator());
                               assertEquals(2, originalFraction.getDenominator());
                               
                               // The mutant would create a different fraction (likely -1/1) which would fail this assertion
                           }

    @Test
                           public void testNegativeNonIntegerIntermediateValue() {
                               // This value will produce a negative non-integer r1 during the continued fraction process
                               double value = 1.0 / (-1.5);
                               
                               // Create fraction with standard parameters using available public constructor
                               Fraction fraction = new Fraction(value, 1.0e-5, 100);
                               
                               // With floor(): r1 = -1.5 → a1 = -2 (floor)
                               // Without floor(): r1 = -1.5 → a1 = -1 (direct cast)
                               // These different coefficients will lead to different fractions
                               
                               // Expected fraction when using floor() - this is the correct behavior
                               Fraction expected = new Fraction(-2, 3);  // -1.5 → -3/2 → reciprocal is -2/3
                               
                               // Verify numerator and denominator
                               assertEquals("Numerator should match expected value when using floor()", 
                                           expected.getNumerator(), fraction.getNumerator());
                               assertEquals("Denominator should match expected value when using floor()", 
                                           expected.getDenominator(), fraction.getDenominator());
                               
                               // Also verify the double value is close to original
                               assertEquals(value, fraction.doubleValue(), 1.0e-5);
                           }

    @Test
                           public void testOverflowCondition() throws FractionConversionException {
                               // Test case where only p2 exceeds overflow
                               try {
                                   // Create a fraction that would make p2 exceed overflow but not q2
                                   // This depends on the actual implementation, but we can try very large values
                                   Fraction fraction = new Fraction(Integer.MAX_VALUE, 1);
                                   fraction.add(new Fraction(1, Integer.MAX_VALUE));
                                   // In original code, this should pass (OR condition)
                                   // In mutant, this might fail (AND condition not met)
                               } catch (FractionConversionException e) {
                                   // This is unexpected for original code
                                   fail("Original code should handle when only p2 exceeds overflow");
                               }
                       
                               // Test case where only q2 exceeds overflow
                               try {
                                   // Create a fraction that would make q2 exceed overflow but not p2
                                   Fraction fraction = new Fraction(1, Integer.MAX_VALUE);
                                   fraction.add(new Fraction(Integer.MAX_VALUE, 1));
                                   // In original code, this should pass (OR condition)
                                   // In mutant, this might fail (AND condition not met)
                               } catch (FractionConversionException e) {
                                   // This is unexpected for original code
                                   fail("Original code should handle when only q2 exceeds overflow");
                               }
                       
                               // Test case where both exceed overflow
                               try {
                                   // Create fractions that would make both p2 and q2 exceed overflow
                                   Fraction fraction = new Fraction(Integer.MAX_VALUE, 1);
                                   fraction.add(new Fraction(Integer.MAX_VALUE, 1));
                                   // Both original and mutant should throw here
                                   fail("Should throw exception when both values exceed overflow");
                               } catch (FractionConversionException e) {
                                   // Expected for both original and mutant
                                   assertTrue(true);
                               }
                           }

    @Test
                           public void testOverflowCondition1() {
                               // Test case where only p2 exceeds overflow
                               try {
                                   // Create a fraction with numerator near Integer.MAX_VALUE and denominator 1
                                   // This should trigger overflow check in original but not in mutant
                                   Fraction f = new Fraction(Integer.MAX_VALUE - 1);
                                   f = f.add(new Fraction(2));  // This should cause p2 to overflow
                                   fail("Expected ArithmeticException for overflow");
                               } catch (ArithmeticException e) {
                                   // Expected in original, should pass
                               }
                       
                               // Test case where only q2 exceeds overflow
                               try {
                                   // Create a fraction with denominator that would overflow when manipulated
                                   Fraction f = new Fraction(1, Integer.MAX_VALUE - 1);
                                   f = f.reciprocal().add(new Fraction(1));  // This should cause q2 to overflow
                                   fail("Expected ArithmeticException for overflow");
                               } catch (ArithmeticException e) {
                                   // Expected in original, should pass
                               }
                       
                               // Test case where both exceed overflow
                               try {
                                   // Create fractions that when manipulated will cause both p2 and q2 to overflow
                                   Fraction f1 = new Fraction(Integer.MAX_VALUE - 1, Integer.MAX_VALUE - 1);
                                   Fraction f2 = new Fraction(Integer.MAX_VALUE - 1, Integer.MAX_VALUE - 1);
                                   f1 = f1.add(f2);  // This should cause both p2 and q2 to overflow
                                   fail("Expected ArithmeticException for overflow");
                               } catch (ArithmeticException e) {
                                   // Expected in both original and mutant
                               }
                       
                               // Test case where neither exceeds overflow
                               try {
                                   Fraction f = new Fraction(1, 1);
                                   f = f.add(new Fraction(1));  // Should not cause overflow
                                   assertEquals(2, f.getNumerator());
                                   assertEquals(1, f.getDenominator());
                               } catch (ArithmeticException e) {
                                   fail("Unexpected ArithmeticException");
                               }
                           }

    @Test(expected = MathArithmeticException.class)
                       public void testOverflowConditionWithSingleValueOverflow() {
                           // Test case where only numerator would cause overflow
                           // Original would throw exception, mutant would pass
                           Fraction.getReducedFraction(Integer.MIN_VALUE, 1);
                       }

    @Test(expected = MathArithmeticException.class)
                       public void testOverflowConditionWithOtherValueOverflow() {
                           // Test case where only denominator would cause overflow
                           // Original would throw exception, mutant would pass
                           Fraction.getReducedFraction(1, Integer.MIN_VALUE);
                       }

    @Test
                       public void testNoOverflowCondition() {
                           // Test case where neither value causes overflow
                           // Both original and mutant should pass
                           Fraction f = Fraction.getReducedFraction(1, 2);
                           assertEquals(1, f.getNumerator());
                           assertEquals(2, f.getDenominator());
                       }

    @Test(expected = MathArithmeticException.class)
                       public void testBothValuesOverflow() {
                           // Test case where both values cause overflow
                           // Both original and mutant would throw exception
                           Fraction.getReducedFraction(Integer.MIN_VALUE, Integer.MIN_VALUE);
                       }

    @Test(expected = MathArithmeticException.class)
                      public void testOverflowConditionWithLargeP() {
                          // This test should pass with original code (throws exception)
                          // but fail with mutant (no exception)
                          // Case where only p2 would overflow
                          new Fraction(Integer.MAX_VALUE, 1);
                      }

    @Test(expected = MathArithmeticException.class)
                      public void testOverflowConditionWithLargeQ() {
                          // This test should pass with original code (throws exception)
                          // but fail with mutant (no exception)
                          // Case where only q2 would overflow
                          new Fraction(1, Integer.MAX_VALUE);
                      }

    @Test
                      public void testOverflowConditionWithBothLarge() {
                          // This test should pass with both original and mutant
                          // Case where both numerator and denominator would be large
                          new Fraction(Integer.MAX_VALUE, Integer.MAX_VALUE);
                      }

    @Test
                      public void testOverflowConditionWithSingleValueExceedingThreshold() {
                          // This test should detect the mutant by having only one value exceed overflow
                          
                          try {
                              // Create a fraction that would cause overflow in numerator
                              new Fraction(Integer.MAX_VALUE, 1).add(new Fraction(1, 1));
                              
                              // If we reach here, the mutant wasn't caught (bad)
                              fail("Expected ArithmeticException for overflow not thrown");
                          } catch (ArithmeticException e) {
                              // Original code should throw exception when either value overflows
                              // Mutant would only throw when both overflow, so this test catches the mutant
                              assertTrue(e.getMessage().contains("overflow"));
                          }
                          
                          try {
                              // Test the other case where denominator would overflow
                              new Fraction(1, Integer.MAX_VALUE).add(new Fraction(1, Integer.MAX_VALUE));
                              
                              // If we reach here, the mutant wasn't caught (bad)
                              fail("Expected ArithmeticException for overflow not thrown");
                          } catch (ArithmeticException e) {
                              // Original code should throw exception when either value overflows
                              assertTrue(e.getMessage().contains("overflow"));
                          }
                      }

    @Test
                      public void testConversionWithPartialOverflow() {
                          // This value is carefully chosen to cause p2 to overflow while q2 remains within bounds
                          // during the continued fraction computation
                          double value = 1.0e16; // Large value that will cause numerator to overflow first
                          
                          // Set epsilon very small to force continued fraction computation
                          double epsilon = 1.0e-20;
                          
                          // Set max iterations high enough to reach the overflow condition
                          int maxIterations = 100;
                          
                          // This should throw FractionConversionException in original code
                          // Mutant would continue processing because q2 hasn't overflowed yet
                          new Fraction(value, epsilon, maxIterations);
                      }

    @Test
                      public void testOverflowConditionWithExactThreshold() {
                          // The overflow threshold in the original code is likely Integer.MAX_VALUE
                          // or similar. We'll test with values exactly at this threshold.
                          
                          // Create a test case where p2 is exactly at overflow threshold
                          // and q2 is below it
                          int overflowThreshold = Integer.MAX_VALUE;
                          int p2 = overflowThreshold;  // Exactly at threshold
                          int q2 = overflowThreshold - 1;  // Just below threshold
                          
                          // In original code: (p2 > overflow) is false, so no overflow
                          // In mutated code: (p2 >= overflow) is true, so overflow
                          
                          // We need to create a scenario where these values are used
                          // Since we don't have the full constructor code, we'll test via
                          // a method that would trigger this condition, likely getReducedFraction
                          
                          try {
                              // This should throw ArithmeticException in mutated code
                              // but not in original code when p2 is exactly at threshold
                              Fraction result = Fraction.getReducedFraction(p2, q2);
                              
                              // If we get here in mutated code, the test fails
                              fail("Expected ArithmeticException for overflow condition not thrown");
                          } catch (ArithmeticException e) {
                              // This is expected for the mutated code
                              assertEquals("overflow in fraction", e.getMessage());
                          }
                          
                          // For completeness, test the opposite case where p2 is just below threshold
                          // Both original and mutated code should behave the same
                          p2 = overflowThreshold - 1;
                          Fraction validResult = Fraction.getReducedFraction(p2, q2);
                          assertNotNull(validResult);
                      }

    @Test(expected = FractionConversionException.class)
                      public void testOverflowConditionWithExactMaxValue() {
                          // This test should pass with original code but fail with mutant
                          // We need to create a scenario where p2 exactly equals Integer.MAX_VALUE
                          
                          // The exact way to trigger this depends on the full implementation,
                          // but we can try creating a fraction that would generate p2 = Integer.MAX_VALUE
                          // during its construction
                          
                          // One approach is to use a value very close to 1 with high precision,
                          // which might generate Integer.MAX_VALUE during the conversion process
                          double value = 1.0 - 1.0/(Integer.MAX_VALUE + 1.0);
                          double epsilon = 1.0e-20;
                          int maxIterations = 100;
                          
                          // With original code, this should succeed
                          // With mutant, this should throw FractionConversionException
                          new Fraction(value, epsilon, maxIterations);
                          
                          // If we reach here, the test fails (original code passed, mutant not caught)
                          fail("Expected FractionConversionException when p2 exactly equals Integer.MAX_VALUE");
                      }

    @Test(expected = FractionConversionException.class)
                      public void testOverflowConditionWithExactValue() {
                          // This test should pass with original code but fail with mutant
                          // because original would not throw when p2 exactly equals overflow
                          
                          // We need to find values that will make p2 exactly equal to overflow (100)
                          // This requires knowing the internal algorithm, but we can approximate
                          // by trying to create a fraction that would generate these values
                          
                          // Try to create a fraction that would cause p2 to be exactly at overflow boundary
                          // The exact value depends on the internal implementation, but we can try
                          // values that are known to potentially hit overflow conditions
                          
                          // This test might need adjustment based on actual overflow value used
                          // but demonstrates the principle of testing the boundary condition
                          
                          // For the purpose of this test, we'll assume overflow is 100
                          // and try to create a fraction that would make p2=100 in the conversion
                          
                          // This is a challenging test to create without knowing the exact algorithm,
                          // but the key is that we need to verify behavior when p2 exactly equals overflow
                          
                          // In practice, we might need to:
                          // 1. Make the overflow value configurable for testing
                          // 2. Use reflection to verify internal state
                          // 3. Find known values that trigger this condition
                          
                          // For now, we'll use a value that's likely to trigger overflow
                          new Fraction(1.0 / 3.0, 100, 100);
                          
                          // If we reach here, the test fails (original code didn't throw)
                          // The mutant would throw when p2 exactly equals overflow
                      }

    @Test(expected = FractionConversionException.class)
                      public void testDefiniteOverflow() {
                          // This should always throw for both original and mutant
                          new Fraction(Math.PI, 1, 100);
                      }

    @Test
                      public void testBelowOverflow() {
                          // This should not throw for either original or mutant
                          Fraction f = new Fraction(0.5, 100, 100);
                          assertEquals(1, f.getNumerator());
                          assertEquals(2, f.getDenominator());
                      }

    @Test
                      public void testOverflowBoundaryCondition() {
                          // This test is designed to catch the mutant where > was changed to >= in overflow check
                          
                          // Create a fraction that would make p2 exactly equal to overflow value when operated on
                          // First we need to determine what the overflow value is in the implementation
                          // For Apache Commons Math, this is typically Integer.MAX_VALUE
                          
                          // Test case where numerator * other denominator equals exactly Integer.MAX_VALUE
                          Fraction f1 = new Fraction(1, 1);
                          Fraction f2 = new Fraction(Integer.MAX_VALUE, 1);
                          
                          try {
                              // This operation should not throw an exception in original code
                              // but might in mutated code due to incorrect overflow detection
                              Fraction result = f1.multiply(f2);
                              
                              // Verify the result is correct
                              assertEquals(Integer.MAX_VALUE, result.getNumerator());
                              assertEquals(1, result.getDenominator());
                          } catch (ArithmeticException e) {
                              // This exception would indicate the mutant was caught
                              fail("Original code should handle exact overflow boundary without exception");
                          }
                          
                          // Additional test case where the product is exactly overflow
                          Fraction f3 = new Fraction(Integer.MAX_VALUE / 2, 1);
                          Fraction f4 = new Fraction(2, 1);
                          
                          try {
                              Fraction result2 = f3.multiply(f4);
                              assertEquals(Integer.MAX_VALUE, result2.getNumerator());
                              assertEquals(1, result2.getDenominator());
                          } catch (ArithmeticException e) {
                              fail("Original code should handle exact overflow boundary without exception");
                          }
                      }

    @Test
                      public void testFractionCreationAtOverflowLimit() {
                          // Test case where values exactly equal overflow threshold
                          // This should be accepted by original code but rejected by mutant
                          
                          // Case 1: Numerator at MIN_VALUE with denominator that would normalize to threshold
                          try {
                              Fraction f = new Fraction(Integer.MIN_VALUE, 1);
                              // Should succeed in original
                              assertEquals(Integer.MIN_VALUE, f.getNumerator());
                              assertEquals(1, f.getDenominator());
                          } catch (MathArithmeticException e) {
                              fail("Original should accept exact overflow threshold");
                          }
                          
                          // Case 2: Denominator at MIN_VALUE with numerator that would normalize to threshold
                          try {
                              Fraction f = new Fraction(1, Integer.MIN_VALUE);
                              // Should succeed in original
                              assertEquals(-1, f.getNumerator()); // Sign gets flipped
                              assertEquals(Integer.MIN_VALUE, f.getDenominator());
                          } catch (MathArithmeticException e) {
                              fail("Original should accept exact overflow threshold");
                          }
                          
                          // Case 3: Both at MIN_VALUE
                          try {
                              Fraction f = new Fraction(Integer.MIN_VALUE, Integer.MIN_VALUE);
                              // Should succeed in original (reduces to 1/1)
                              assertEquals(1, f.getNumerator());
                              assertEquals(1, f.getDenominator());
                          } catch (MathArithmeticException e) {
                              fail("Original should accept exact overflow threshold");
                          }
                      }

    @Test
             public void testConversionWithP2ExactlyAtOverflow() {
                 // This value should lead to p2 being exactly Integer.MAX_VALUE during conversion
                 // The exact value needs to be calculated based on the continued fraction algorithm
                 // For testing purposes, we'll use Double.MAX_VALUE which should trigger this condition
                 
                 try {
                     // Using public constructor with maximum iterations
                     new Fraction(Double.MAX_VALUE, Double.MAX_VALUE, Integer.MAX_VALUE);
                 } catch (FractionConversionException e) {
                     // In original code, this shouldn't throw because p2=MAX_VALUE is not > overflow
                     // But mutant will throw because p2=MAX_VALUE is >= overflow
                     throw e;
                 }
                 
                 // Alternative approach using public constructor with max denominator
                 try {
                     new Fraction(Double.MAX_VALUE, Integer.MAX_VALUE);
                 } catch (FractionConversionException e) {
                     throw e;
                 }
             }

    @Test
             public void testOverflowBoundaryCondition1() {
                 // This test is designed to catch the mutant where q2 >= overflow instead of q2 > overflow
                 // We need to find a value where q2 exactly equals the overflow threshold
                 
                 // Assuming overflow is Integer.MAX_VALUE based on typical Fraction implementations
                 // We'll try to create a fraction that would make q2 equal to MAX_VALUE
                 
                 try {
                     // Attempt to create a fraction with components that would make q2 = MAX_VALUE
                     // The exact construction depends on the Fraction class implementation,
                     // but we can try using reciprocal of a very small fraction
                     Fraction fraction = new Fraction(1, Integer.MAX_VALUE);
                     Fraction reciprocal = fraction.reciprocal();
                     
                     // If we reach here, the original code passed the overflow check
                     // The mutant would have thrown an exception for q2 = MAX_VALUE
                     assertEquals(Integer.MAX_VALUE, reciprocal.getNumerator());
                     assertEquals(1, reciprocal.getDenominator());
                     
                 } catch (ArithmeticException e) {
                     // If we get here, it means the mutant was caught (>= condition triggered)
                     fail("Original code should handle q2 exactly at overflow threshold");
                 }
                 
                 // Additional test case where q2 is just above overflow
                 try {
                     // This should throw exception in both original and mutated code
                     new Fraction(1, Integer.MAX_VALUE).reciprocal().multiply(2);
                     fail("Expected ArithmeticException for overflow");
                 } catch (ArithmeticException expected) {
                     // Expected behavior for both original and mutant
                 }
             }

    @Test(expected = FractionConversionException.class)
             public void testOverflowConditionWithExactQ2Value() {
                 // This test should pass with original code but fail with mutant
                 // We need to create a scenario where q2 exactly equals overflow value
                 // and p2 is below overflow
                 
                 // Using Integer.MAX_VALUE as overflow value (as seen in the constructor call)
                 // We need to find values that would make q2 = Integer.MAX_VALUE during conversion
                 
                 // This is tricky because we need to trigger the exact condition in the conversion logic
                 // One approach is to use a value that would generate q2 = MAX_VALUE during continued fraction conversion
                 
                 // For a simple fraction that would generate q2 = MAX_VALUE in the conversion process
                 // We'll use a value very close to 1 but requiring maximum precision
                 double value = 0.9999999999999999;
                 double epsilon = 1.0e-20;
                 int maxIterations = 100;
                 
                 // Original code: should NOT throw exception since q2 is exactly MAX_VALUE but condition is ">"
                 // Mutant code: WILL throw exception since condition becomes ">="
                 new Fraction(value, epsilon, maxIterations);
             }

    @Test
             public void testOverflowConditionWithExactBoundary() {
                 // This test is designed to catch the mutant where q2 >= overflow instead of q2 > overflow
                 // We need to create a scenario where q2 exactly equals the overflow value (100)
                 
                 // Case where q2 would be exactly 100 (overflow threshold)
                 // We'll use a value that would make q2 hit exactly 100 during the conversion
                 // For example, trying to create a fraction with denominator 100
                 
                 try {
                     // The exact value depends on the implementation, but we know overflow is 100
                     // We need to find a value that would make q2 = 100 in the conversion process
                     // For simplicity, we'll try creating a fraction with denominator 100
                     Fraction fraction = new Fraction(1, 100);
                     
                     // If the mutant is present, this might throw an exception
                     // But with original code, it should work fine
                     assertNotNull(fraction);
                     assertEquals(1, fraction.getNumerator());
                     assertEquals(100, fraction.getDenominator());
                     
                 } catch (Exception e) {
                     fail("Should not throw exception for denominator exactly equal to overflow threshold");
                 }
                 
                 // Another test case where q2 would be just above overflow
                 try {
                     Fraction fraction = new Fraction(1, 101);
                     assertNotNull(fraction);
                     assertEquals(1, fraction.getNumerator());
                     assertEquals(101, fraction.getDenominator());
                 } catch (Exception e) {
                     fail("Should not throw exception for denominator above overflow threshold");
                 }
                 
                 // And one where q2 is just below overflow
                 try {
                     Fraction fraction = new Fraction(1, 99);
                     assertNotNull(fraction);
                     assertEquals(1, fraction.getNumerator());
                     assertEquals(99, fraction.getDenominator());
                 } catch (Exception e) {
                     fail("Should not throw exception for denominator below overflow threshold");
                 }
             }

    @Test
             public void testOverflowCondition2() {
                 // Find the overflow threshold (likely Integer.MAX_VALUE)
                 int overflow = Integer.MAX_VALUE;
                 
                 // Case 1: q2 exactly equals overflow threshold
                 try {
                     Fraction f = Fraction.getReducedFraction(1, overflow);
                     // Original should pass, mutant would throw
                     assertNotNull(f);
                 } catch (ArithmeticException e) {
                     fail("Original should handle exact overflow threshold without exception");
                 }
                 
                 // Case 2: q2 just above overflow threshold
                 try {
                     Fraction.getReducedFraction(1, overflow + 1);
                     fail("Should throw ArithmeticException for overflow");
                 } catch (ArithmeticException e) {
                     // Expected for both original and mutant
                     assertTrue(true);
                 }
                 
                 // Case 3: q2 just below overflow threshold
                 try {
                     Fraction f = Fraction.getReducedFraction(1, overflow - 1);
                     assertNotNull(f);
                 } catch (ArithmeticException e) {
                     fail("Should not throw for values below threshold");
                 }
             }

    @Test
        public void testFractionCreationAtOverflowLimit1() {
            // The overflow value isn't shown in the code, but based on context it's likely Integer.MIN_VALUE
            // since that's what's checked in the negative denominator case
            
            // Test case where denominator is exactly at overflow limit (Integer.MIN_VALUE)
            try {
                Fraction fraction = new Fraction(1, Integer.MIN_VALUE);
                // Original code should handle this case without exception
                // If we reach here, mutant wasn't caught - test fails
                fail("Expected MathArithmeticException not thrown - mutant survived");
            } catch (MathArithmeticException e) {
                // Mutant would throw exception here - test passes
                assertEquals("overflow in fraction", e.getLocalizedMessage());
            }
            
            // Also test numerator case
            try {
                Fraction fraction = new Fraction(Integer.MIN_VALUE, 1);
                // Original code should handle this case without exception
                // If we reach here, mutant wasn't caught - test fails
                fail("Expected MathArithmeticException not thrown - mutant survived");
            } catch (MathArithmeticException e) {
                // Mutant would throw exception here - test passes
                assertEquals("overflow in fraction", e.getLocalizedMessage());
            }
        }

    @Test(expected = FractionConversionException.class)
    public void testFractionConversionWithQ2EqualToOverflow() throws Exception {
        // This test is designed to create a scenario where q2 exactly equals Integer.MAX_VALUE
        // The original code would accept this (since q2 is not > overflow)
        // The mutated code would reject it (since q2 >= overflow)
        
        // Define epsilon value for the test
        double epsilon = 1.0e-5;
        
        // We need to find a value that will produce q2 = Integer.MAX_VALUE during conversion
        // This is tricky, but we can approximate by using a value very close to 1
        // since the continued fraction for numbers near 1 will have denominators
        // that grow large quickly
        
        // The exact value needed would require reverse engineering the algorithm,
        // but we can use a value that we know will produce a denominator near MAX_VALUE
        double value = 1.0 - (1.0 / Integer.MAX_VALUE);
        
        // Set maxDenominator to MAX_VALUE to allow the algorithm to reach this point
        int maxDenominator = Integer.MAX_VALUE;
        int maxIterations = 100; // Sufficiently large
        
        // Get the private constructor via reflection
        Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
            double.class, double.class, int.class, int.class);
        constructor.setAccessible(true);
        
        try {
            // This should throw in the mutated version but not in original
            constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
            
            // If we get here, the test fails (mutant survived)
            fail("Expected FractionConversionException not thrown");
        } catch (InvocationTargetException e) {
            // Verify it's the correct exception (overflow case)
            if (e.getCause() instanceof FractionConversionException) {
                throw (FractionConversionException) e.getCause();
            }
            throw e;
        }
    }


}
