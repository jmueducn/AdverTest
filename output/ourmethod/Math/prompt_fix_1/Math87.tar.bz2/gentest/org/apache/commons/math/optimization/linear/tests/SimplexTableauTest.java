package gentest.org.apache.commons.math.optimization.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.linear.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.math.linear.MatrixUtils;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.RealMatrixImpl;
import org.apache.commons.math.linear.RealVector;
import org.apache.commons.math.optimization.GoalType;
import org.apache.commons.math.optimization.RealPointValuePair;
import org.apache.commons.math.util.MathUtils;
 
public class SimplexTableauTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                           public void testGetBasicRow_ZeroWithinEpsilonCountsAsZero() throws Exception {
                                                                                                               // Define epsilon value
                                                                                                               final double EPSILON = 1.0e-6;
                                                                                                               
                                                                                                               // Create mock tableau using reflection
                                                                                                               Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                               Constructor<?> constructor = tableauClass.getDeclaredConstructors()[0];
                                                                                                               constructor.setAccessible(true);
                                                                                                               
                                                                                                               // Create dummy parameters for constructor
                                                                                                               LinearObjectiveFunction f = mock(LinearObjectiveFunction.class);
                                                                                                               Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                               GoalType goalType = GoalType.MAXIMIZE;
                                                                                                               boolean restrictToNonNegative = true;
                                                                                                               
                                                                                                               // Create instance
                                                                                                               Object tableau = constructor.newInstance(f, constraints, goalType, restrictToNonNegative, EPSILON);
                                                                                                               
                                                                                                               // Mock necessary methods
                                                                                                               Method getNumObjectiveFunctions = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                                                                               getNumObjectiveFunctions.setAccessible(true);
                                                                                                               when(getNumObjectiveFunctions.invoke(tableau)).thenReturn(1);
                                                                                                               
                                                                                                               Method getHeight = tableauClass.getDeclaredMethod("getHeight");
                                                                                                               getHeight.setAccessible(true);
                                                                                                               when(getHeight.invoke(tableau)).thenReturn(4);
                                                                                                               
                                                                                                               Method getEntry = tableauClass.getDeclaredMethod("getEntry", int.class, int.class);
                                                                                                               getEntry.setAccessible(true);
                                                                                                               when(getEntry.invoke(tableau, 1, 0)).thenReturn(0.0);
                                                                                                               when(getEntry.invoke(tableau, 2, 0)).thenReturn(1.0);
                                                                                                               when(getEntry.invoke(tableau, 3, 0)).thenReturn(EPSILON/2);
                                                                                                               
                                                                                                               // Call getBasicRow via reflection
                                                                                                               Method getBasicRow = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                               getBasicRow.setAccessible(true);
                                                                                                               Integer result = (Integer) getBasicRow.invoke(tableau, 0);
                                                                                                               
                                                                                                               assertNull(result);  // Should detect non-zero in row 3
                                                                                                           }

    @Test
                                                                                                       public void testGetBasicRow_NoOneEntryReturnsNull() throws Exception {
                                                                                                           // Create necessary objects for constructor
                                                                                                           LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0}, 0);
                                                                                                           Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                                                                           GoalType goalType = GoalType.MAXIMIZE;
                                                                                                           boolean restrictToNonNegative = true;
                                                                                                           double epsilon = 1e-6;
                                                                                                           
                                                                                                           // Create real tableau instance using reflection since constructor is not public
                                                                                                           Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                           Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                               LinearObjectiveFunction.class, 
                                                                                                               Collection.class, 
                                                                                                               GoalType.class, 
                                                                                                               boolean.class, 
                                                                                                               double.class
                                                                                                           );
                                                                                                           constructor.setAccessible(true);
                                                                                                           Object tableau = constructor.newInstance(f, constraints, goalType, restrictToNonNegative, epsilon);
                                                                                                           
                                                                                                           // Use reflection to access private getBasicRow method
                                                                                                           Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                           getBasicRowMethod.setAccessible(true);
                                                                                                           
                                                                                                           // Invoke the method
                                                                                                           Integer result = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                                                                                           
                                                                                                           assertNull(result);
                                                                                                       }

    @Test
                                                                                                   public void testGetBasicRow_FindsSingleOneWithZeros() throws Exception {
                                                                                                       // Create a real SimplexTableau instance with dummy parameters
                                                                                                       LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0}, 0);
                                                                                                       Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                                                                       GoalType goalType = GoalType.MAXIMIZE;
                                                                                                       
                                                                                                       // Use reflection to create SimplexTableau instance since it's package-private
                                                                                                       Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                       Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                           LinearObjectiveFunction.class, 
                                                                                                           Collection.class, 
                                                                                                           GoalType.class, 
                                                                                                           boolean.class, 
                                                                                                           double.class
                                                                                                       );
                                                                                                       constructor.setAccessible(true);
                                                                                                       Object tableau = constructor.newInstance(f, constraints, goalType, false, 0.0);
                                                                                                       
                                                                                                       // Use reflection to access the private getBasicRow method
                                                                                                       Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                       getBasicRowMethod.setAccessible(true);
                                                                                                       
                                                                                                       // Mock the internal behavior using reflection to set up test conditions
                                                                                                       Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                       tableauField.setAccessible(true);
                                                                                                       
                                                                                                       // Create mock matrix
                                                                                                       RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                                                       
                                                                                                       // Setup mock behavior for the matrix
                                                                                                       when(mockMatrix.getRowDimension()).thenReturn(4);
                                                                                                       when(mockMatrix.getEntry(1, 0)).thenReturn(0.0);
                                                                                                       when(mockMatrix.getEntry(2, 0)).thenReturn(1.0);  // This should be the basic row
                                                                                                       when(mockMatrix.getEntry(3, 0)).thenReturn(0.0);
                                                                                                       
                                                                                                       // Inject the mock matrix into the tableau
                                                                                                       tableauField.set(tableau, mockMatrix);
                                                                                                       
                                                                                                       // Call the method through reflection
                                                                                                       Integer result = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                                                                                       assertEquals(Integer.valueOf(2), result);
                                                                                                   }

    @Test
                                                                                                   public void testGetBasicRow_NonZeroNonOneEntryReturnsNull() {
                                                                                                       try {
                                                                                                           // Get the LinearObjectiveFunction class
                                                                                                           Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                           Constructor<?> objectiveFunctionConstructor = linearObjectiveFunctionClass.getConstructor(double[].class, double.class);
                                                                                                           Object f = objectiveFunctionConstructor.newInstance(new double[]{1.0}, 0.0);
                                                                                                   
                                                                                                           // Create constraints list
                                                                                                           List<Object> constraints = new ArrayList<>();
                                                                                                           Class<?> linearConstraintClass = Class.forName("org.apache.commons.math.optimization.linear.LinearConstraint");
                                                                                                           Class<?> relationshipClass = Class.forName("org.apache.commons.math.optimization.linear.Relationship");
                                                                                                           Object eqRelationship = Enum.valueOf((Class<Enum>) relationshipClass, "EQ");
                                                                                                           Constructor<?> constraintConstructor = linearConstraintClass.getConstructor(double[].class, relationshipClass, double.class);
                                                                                                           Object constraint = constraintConstructor.newInstance(new double[]{1.0}, eqRelationship, 0.0);
                                                                                                           constraints.add(constraint);
                                                                                                   
                                                                                                           // Get SimplexTableau class and create instance
                                                                                                           Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                           Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                                           Object maximizeGoal = Enum.valueOf((Class<Enum>) goalTypeClass, "MAXIMIZE");
                                                                                                           Constructor<?> tableauConstructor = simplexTableauClass.getConstructor(
                                                                                                               linearObjectiveFunctionClass, Collection.class, goalTypeClass, boolean.class, double.class);
                                                                                                           Object tableau = tableauConstructor.newInstance(f, constraints, maximizeGoal, false, 0.0);
                                                                                                   
                                                                                                           // Get and invoke getBasicRow method
                                                                                                           Method getBasicRow = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                           getBasicRow.setAccessible(true);
                                                                                                   
                                                                                                           // Get and invoke setEntry method to setup test conditions
                                                                                                           Method setEntry = simplexTableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                                           setEntry.setAccessible(true);
                                                                                                   
                                                                                                           setEntry.invoke(tableau, 1, 0, 0.0);
                                                                                                           setEntry.invoke(tableau, 2, 0, 0.5);  // Not zero or one
                                                                                                           setEntry.invoke(tableau, 3, 0, 0.0);
                                                                                                   
                                                                                                           Integer result = (Integer) getBasicRow.invoke(tableau, 0);
                                                                                                           assertNull(result);
                                                                                                       } catch (Exception e) {
                                                                                                           fail("Exception occurred during test: " + e.getMessage());
                                                                                                       }
                                                                                                   }

    @Test
                                                                                                   public void testGetBasicRow_OneWithinEpsilonCountsAsOne() {
                                                                                                       // Create necessary objects for SimplexTableau constructor
                                                                                                       LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0}, 0);
                                                                                                       Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                                                                       GoalType goalType = GoalType.MAXIMIZE;
                                                                                                       double EPSILON = 1.0e-6;
                                                                                                       
                                                                                                       // Create SimplexTableau instance using reflection
                                                                                                       Object tableau = null;
                                                                                                       try {
                                                                                                           Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                           Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                               LinearObjectiveFunction.class, 
                                                                                                               Collection.class, 
                                                                                                               GoalType.class, 
                                                                                                               boolean.class, 
                                                                                                               double.class);
                                                                                                           constructor.setAccessible(true);
                                                                                                           tableau = constructor.newInstance(f, constraints, goalType, false, EPSILON);
                                                                                                       } catch (Exception e) {
                                                                                                           fail("Failed to create SimplexTableau instance: " + e.getMessage());
                                                                                                       }
                                                                                                       
                                                                                                       // Use reflection to set up the tableau entries since they're not directly accessible
                                                                                                       try {
                                                                                                           Class<?> tableauClass = tableau.getClass();
                                                                                                           Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                           tableauField.setAccessible(true);
                                                                                                           Object matrix = tableauField.get(tableau);
                                                                                                           
                                                                                                           // Get setEntry method from matrix class
                                                                                                           Method setEntry = matrix.getClass().getMethod("setEntry", int.class, int.class, double.class);
                                                                                                           
                                                                                                           // Set up entries (rows 1-3, column 0)
                                                                                                           setEntry.invoke(matrix, 1, 0, 0.0);
                                                                                                           setEntry.invoke(matrix, 2, 0, 1.0 + EPSILON/2);  // Within epsilon
                                                                                                           setEntry.invoke(matrix, 3, 0, 0.0);
                                                                                                       } catch (Exception e) {
                                                                                                           fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                       }
                                                                                                       
                                                                                                       // Use reflection to call getBasicRow since it's private
                                                                                                       try {
                                                                                                           Class<?> tableauClass = tableau.getClass();
                                                                                                           Method getBasicRow = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                           getBasicRow.setAccessible(true);
                                                                                                           Integer result = (Integer) getBasicRow.invoke(tableau, 0);
                                                                                                           assertEquals(Integer.valueOf(2), result);
                                                                                                       } catch (Exception e) {
                                                                                                           fail("Failed to test getBasicRow due to reflection error: " + e.getMessage());
                                                                                                       }
                                                                                                   }

    @Test
                                                                                                   public void testGetBasicRow_FirstRowAfterObjectiveFunctionsIsOne() throws Exception {
                                                                                                       // Create necessary objects to construct SimplexTableau
                                                                                                       LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1.0}, 0.0);
                                                                                                       Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                                                                       GoalType goalType = GoalType.MAXIMIZE;
                                                                                                       double epsilon = 1e-6;
                                                                                                       
                                                                                                       // Get the SimplexTableau class using reflection
                                                                                                       Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                       
                                                                                                       // Get the constructor using reflection
                                                                                                       Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                                                           LinearObjectiveFunction.class, 
                                                                                                           Collection.class, 
                                                                                                           GoalType.class, 
                                                                                                           boolean.class, 
                                                                                                           double.class
                                                                                                       );
                                                                                                       constructor.setAccessible(true);
                                                                                                       
                                                                                                       // Create actual tableau instance
                                                                                                       Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                                                                                                       
                                                                                                       // Use reflection to access private getBasicRow method
                                                                                                       Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                       getBasicRowMethod.setAccessible(true);
                                                                                                       
                                                                                                       // Set up the tableau data using reflection
                                                                                                       Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                                                                                       tableauField.setAccessible(true);
                                                                                                       
                                                                                                       // Create RealMatrixImpl instance using reflection
                                                                                                       Class<?> realMatrixImplClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                                                       Object matrix = realMatrixImplClass.getConstructor(double[][].class)
                                                                                                           .newInstance((Object) new double[][] {
                                                                                                               {0.0, 0.0}, // objective function 1
                                                                                                               {0.0, 0.0}, // objective function 2
                                                                                                               {1.0, 0.0}, // first constraint row (should be identified as basic row)
                                                                                                               {0.0, 0.0}  // second constraint row
                                                                                                           });
                                                                                                       tableauField.set(tableau, matrix);
                                                                                                       
                                                                                                       // Call the private method
                                                                                                       Integer result = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                                                                                       
                                                                                                       // Verify the result
                                                                                                       assertEquals(Integer.valueOf(2), result);
                                                                                                   }

    @Test
                                                                                               public void testGetBasicRow_MultipleOnesReturnsNull() {
                                                                                                   try {
                                                                                                       // Create real tableau with necessary parameters using reflection
                                                                                                       Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                       Object f = linearObjectiveFunctionClass.getConstructor(double[].class, double.class)
                                                                                                           .newInstance(new double[]{1, 1}, 0.0);
                                                                                               
                                                                                                       java.util.Collection<Object> constraints = new java.util.ArrayList<>();
                                                                                                       Class<?> linearConstraintClass = Class.forName("org.apache.commons.math.optimization.linear.LinearConstraint");
                                                                                                       Class<?> relationshipClass = Class.forName("org.apache.commons.math.optimization.linear.Relationship");
                                                                                                       Object leq = Enum.valueOf((Class<Enum>)relationshipClass, "LEQ");
                                                                                                       
                                                                                                       constraints.add(linearConstraintClass.getConstructor(double[].class, relationshipClass, double.class)
                                                                                                           .newInstance(new double[]{1, 1}, leq, 1.0));
                                                                                                       constraints.add(linearConstraintClass.getConstructor(double[].class, relationshipClass, double.class)
                                                                                                           .newInstance(new double[]{1, 1}, leq, 1.0));
                                                                                               
                                                                                                       Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                                       Object maximize = Enum.valueOf((Class<Enum>)goalTypeClass, "MAXIMIZE");
                                                                                               
                                                                                                       Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                       Object tableau = simplexTableauClass.getConstructor(
                                                                                                               linearObjectiveFunctionClass,
                                                                                                               java.util.Collection.class,
                                                                                                               goalTypeClass,
                                                                                                               boolean.class,
                                                                                                               double.class)
                                                                                                           .newInstance(f, constraints, maximize, false, 0.000001);
                                                                                                       
                                                                                                       // Use reflection to test private method
                                                                                                       java.lang.reflect.Method getBasicRowMethod = simplexTableauClass
                                                                                                           .getDeclaredMethod("getBasicRow", int.class);
                                                                                                       getBasicRowMethod.setAccessible(true);
                                                                                                       
                                                                                                       // Setup test data by directly modifying tableau entries
                                                                                                       java.lang.reflect.Field tableauField = simplexTableauClass
                                                                                                           .getDeclaredField("tableau");
                                                                                                       tableauField.setAccessible(true);
                                                                                                       org.apache.commons.math.linear.RealMatrix matrix = 
                                                                                                           (org.apache.commons.math.linear.RealMatrix) tableauField.get(tableau);
                                                                                                       
                                                                                                       // Set multiple entries with 1.0 in column 0
                                                                                                       matrix.setEntry(1, 0, 1.0);
                                                                                                       matrix.setEntry(2, 0, 0.0);
                                                                                                       matrix.setEntry(3, 0, 1.0);
                                                                                                       matrix.setEntry(4, 0, 0.0);
                                                                                                       
                                                                                                       Integer result = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                                                                                       assertNull(result);
                                                                                                   } catch (Exception e) {
                                                                                                       fail("Reflection failed: " + e.getMessage());
                                                                                                   }
                                                                                               }

    @Test
                                                                                       public void testGetBasicRow_EmptyTableauReturnsNull() {
                                                                                           // Create a real tableau with minimal setup using reflection
                                                                                           try {
                                                                                               // Create LinearObjectiveFunction
                                                                                               Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                               Constructor<?> fConstructor = linearObjectiveFunctionClass.getConstructor(double[].class, double.class);
                                                                                               Object f = fConstructor.newInstance(new double[]{0}, 0.0);
                                                                                               
                                                                                               // Create empty constraints collection
                                                                                               Collection<Object> constraints = new ArrayList<>();
                                                                                               
                                                                                               // Get SimplexTableau class via reflection
                                                                                               Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                               
                                                                                               // Get GoalType enum
                                                                                               Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.GoalType");
                                                                                               Object maximizeGoal = Enum.valueOf((Class<Enum>) goalTypeClass, "MAXIMIZE");
                                                                                               
                                                                                               // Get SimplexTableau constructor via reflection
                                                                                               Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                                                   linearObjectiveFunctionClass,
                                                                                                   Collection.class,
                                                                                                   goalTypeClass,
                                                                                                   boolean.class,
                                                                                                   double.class);
                                                                                               constructor.setAccessible(true);
                                                                                               
                                                                                               // Create tableau instance
                                                                                               Object tableau = constructor.newInstance(
                                                                                                   f, 
                                                                                                   constraints, 
                                                                                                   maximizeGoal, 
                                                                                                   false, 
                                                                                                   0.0);
                                                                                               
                                                                                               // Use reflection to access the private getBasicRow method
                                                                                               Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                               getBasicRowMethod.setAccessible(true);
                                                                                               Integer result = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                                                                               assertNull(result);
                                                                                           } catch (Exception e) {
                                                                                               fail("Failed to create tableau or invoke getBasicRow method: " + e.getMessage());
                                                                                           }
                                                                                       }

    @Test
                                                                          public void testGetBasicRowDetectsMutant() {
                                                                              // Setup test data that will expose the mutant
                                                                              int col = 2;
                                                                              double epsilon = 0.000001;
                                                                              
                                                                              try {
                                                                                  // Create LinearObjectiveFunction and constraints using reflection
                                                                                  Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                  Constructor<?> objectiveFunctionConstructor = linearObjectiveFunctionClass.getConstructor(double[].class, double.class);
                                                                                  Object f = objectiveFunctionConstructor.newInstance(new double[]{1, 1}, 0.0);
                                                                                  
                                                                                  Collection<Object> constraints = new ArrayList<Object>();
                                                                                  Class<?> linearConstraintClass = Class.forName("org.apache.commons.math.optimization.linear.LinearConstraint");
                                                                                  Class<?> relationshipClass = Class.forName("org.apache.commons.math.optimization.linear.Relationship");
                                                                                  Object leq = Enum.valueOf((Class<Enum>)relationshipClass, "LEQ");
                                                                                  Constructor<?> constraintConstructor = linearConstraintClass.getConstructor(double[].class, relationshipClass, double.class);
                                                                                  constraints.add(constraintConstructor.newInstance(new double[]{1, 1}, leq, 1.0));
                                                                                  
                                                                                  // Create SimplexTableau instance using reflection
                                                                                  Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                  Object maximize = Enum.valueOf((Class<Enum>)goalTypeClass, "MAXIMIZE");
                                                                                  Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                  Constructor<?> tableauConstructor = tableauClass.getConstructor(
                                                                                      linearObjectiveFunctionClass, Collection.class, goalTypeClass, boolean.class, double.class);
                                                                                  Object tableau = tableauConstructor.newInstance(f, constraints, maximize, false, epsilon);
                                                                                  
                                                                                  // Access the tableau matrix using reflection
                                                                                  Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                  tableauField.setAccessible(true);
                                                                                  Object matrix = tableauField.get(tableau);
                                                                                  
                                                                                  // Set up our test scenario: row 0 and 2 have 1.0, row 1 has 0.5
                                                                                  Method setEntry = matrix.getClass().getMethod("setEntry", int.class, int.class, double.class);
                                                                                  setEntry.invoke(matrix, 0, col, 1.0);
                                                                                  setEntry.invoke(matrix, 1, col, 0.5);  // Non-zero, non-1 value
                                                                                  setEntry.invoke(matrix, 2, col, 1.0);
                                                                                  
                                                                                  // Call the private method using reflection
                                                                                  Method method = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                  method.setAccessible(true);
                                                                                  Integer result = (Integer) method.invoke(tableau, col);
                                                                                  
                                                                                  // Original behavior should return null because of the 0.5 in row 1
                                                                                  // Mutant would continue and return row 2 because row==null is true
                                                                                  assertNull("Should return null when non-zero non-1 entry exists", result);
                                                                              } catch (Exception e) {
                                                                                  fail("Test failed due to reflection error: " + e.getMessage());
                                                                              }
                                                                          }

    @Test
                                                                      public void testGetBasicRowDetectsMutant1() throws Exception {
                                                                          // Create a test case where:
                                                                          // - First row has 1.0 (should be candidate)
                                                                          // - Second row has non-zero value (should make method return null)
                                                                          // - Third row has 1.0 (shouldn't be reached in original)
                                                                          
                                                                          // Setup test data
                                                                          int col = 2;
                                                                          double epsilon = 0.000001;
                                                                          
                                                                          // Create real SimplexTableau instance with minimal required parameters
                                                                          LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0, 0}, 0);
                                                                          Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                                          GoalType goalType = GoalType.MAXIMIZE;
                                                                          
                                                                          // Create instance using reflection since constructor is not public
                                                                          Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                          Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                              LinearObjectiveFunction.class, 
                                                                              Collection.class, 
                                                                              GoalType.class, 
                                                                              boolean.class, 
                                                                              double.class
                                                                          );
                                                                          constructor.setAccessible(true);
                                                                          Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                                                                          
                                                                          // Use reflection to access private getBasicRow method
                                                                          Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                          getBasicRowMethod.setAccessible(true);
                                                                          
                                                                          // Mock the behavior using a spy
                                                                          Object spyTableau = spy(tableau);
                                                                          
                                                                          // Configure mock behavior
                                                                          Method getNumObjectiveFunctions = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                                          getNumObjectiveFunctions.setAccessible(true);
                                                                          when(getNumObjectiveFunctions.invoke(spyTableau)).thenReturn(0);
                                                                          
                                                                          Method getHeight = tableauClass.getDeclaredMethod("getHeight");
                                                                          getHeight.setAccessible(true);
                                                                          when(getHeight.invoke(spyTableau)).thenReturn(3);
                                                                          
                                                                          Method getEntry = tableauClass.getDeclaredMethod("getEntry", int.class, int.class);
                                                                          getEntry.setAccessible(true);
                                                                          when(getEntry.invoke(spyTableau, 0, col)).thenReturn(1.0);
                                                                          when(getEntry.invoke(spyTableau, 1, col)).thenReturn(0.5);  // This should make original return null
                                                                          when(getEntry.invoke(spyTableau, 2, col)).thenReturn(1.0);
                                                                          
                                                                          Method getEpsilon = tableauClass.getDeclaredMethod("getEpsilon");
                                                                          getEpsilon.setAccessible(true);
                                                                          when(getEpsilon.invoke(spyTableau)).thenReturn(epsilon);
                                                                          
                                                                          // Test the behavior
                                                                          Integer result = (Integer) getBasicRowMethod.invoke(spyTableau, col);
                                                                          
                                                                          // Assertions
                                                                          assertNull("Should return null when non-zero non-1 entry exists", result);
                                                                          
                                                                          // Verify interactions using reflected method calls
                                                                          verify(getEntry, times(1)).invoke(spyTableau, 0, col);
                                                                          verify(getEntry, times(1)).invoke(spyTableau, 1, col);
                                                                          // Should not reach row 2 in original implementation
                                                                          verify(getEntry, never()).invoke(spyTableau, 2, col);
                                                                      }

    @Test
                                                             public void testGetBasicRowDetectsEpsilonMutation() throws Exception {
                                                                 // Setup test with real instance using reflection
                                                                 Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                 Object f = linearObjectiveFunctionClass.getConstructor(double[].class, double.class)
                                                                         .newInstance(new double[]{1.0}, 0.0);
                                                                 
                                                                 Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                 Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                 Object goalType = Enum.valueOf((Class<Enum>)goalTypeClass, "MAXIMIZE");
                                                                 double epsilon = 0.000001;
                                                                 
                                                                 Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                 Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                         linearObjectiveFunctionClass, 
                                                                         Collection.class, 
                                                                         goalTypeClass, 
                                                                         boolean.class, 
                                                                         double.class);
                                                                 constructor.setAccessible(true);
                                                                 Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                                                                 
                                                                 // Configure test values
                                                                 int col = 0;
                                                                 double testValue = 1.0 + epsilon * 1.5; // Between epsilon and 2*epsilon
                                                                 
                                                                 // Use reflection to set private fields needed for the test
                                                                 Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                                                 tableauField.setAccessible(true);
                                                                 Class<?> realMatrixImplClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                 Object matrix = realMatrixImplClass.getConstructor(double[][].class)
                                                                         .newInstance((Object) new double[][]{
                                                                             {0.0, 0.0},  // First row not matching
                                                                             {testValue, 0.0}  // Second row with our test value
                                                                         });
                                                                 tableauField.set(tableau, matrix);
                                                                 
                                                                 Field heightField = simplexTableauClass.getDeclaredField("height");
                                                                 heightField.setAccessible(true);
                                                                 heightField.set(tableau, 2);
                                                                 
                                                                 // Call method - should return null with original epsilon check
                                                                 Method getBasicRow = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                 getBasicRow.setAccessible(true);
                                                                 Integer result = (Integer) getBasicRow.invoke(tableau, col);
                                                                 
                                                                 // Verify - original would return null, mutant would return 1
                                                                 assertNull("Should return null when value is within 2*epsilon but not epsilon of 1.0", result);
                                                             }

    @Test
                                            public void testGetBasicRow_DetectsNonZeroWithinEpsilonRange() throws Exception {
                                                // Setup test data
                                                double epsilon = 0.000001;
                                                double valueJustAboveEpsilon = epsilon * 1.5; // Between epsilon and 2*epsilon
                                                
                                                // Create dummy parameters for constructor
                                                LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1.0}, 0.0);
                                                Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                GoalType goalType = GoalType.MAXIMIZE;
                                                
                                                // Get SimplexTableau class via reflection
                                                Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                
                                                // Create real instance instead of mock using reflection
                                                Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                    LinearObjectiveFunction.class, 
                                                    Collection.class, 
                                                    GoalType.class, 
                                                    boolean.class, 
                                                    double.class
                                                );
                                                constructor.setAccessible(true);
                                                Object tableau = constructor.newInstance(f, constraints, goalType, true, epsilon);
                                                
                                                // Use reflection to access private getBasicRow method
                                                Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                getBasicRowMethod.setAccessible(true);
                                                
                                                // Mock the behavior using reflection to set internal state
                                                Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                                tableauField.setAccessible(true);
                                                RealMatrix mockMatrix = mock(RealMatrix.class);
                                                tableauField.set(tableau, mockMatrix);
                                                
                                                // Configure mock matrix behavior
                                                when(mockMatrix.getRowDimension()).thenReturn(3);
                                                when(mockMatrix.getEntry(0, 0)).thenReturn(1.0);  // Valid basic row
                                                when(mockMatrix.getEntry(1, 0)).thenReturn(valueJustAboveEpsilon);  // Should be considered non-zero
                                                when(mockMatrix.getEntry(2, 0)).thenReturn(0.0);  // Wouldn't be reached in original
                                                
                                                // Call method via reflection
                                                Integer result = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                                
                                                // Original should return null because of non-zero at row 1
                                                // Mutant would continue and return row 0
                                                assertNull("Should return null when encountering value just above epsilon", result);
                                                
                                                // Verify mock interactions
                                                verify(mockMatrix).getEntry(0, 0);
                                                verify(mockMatrix).getEntry(1, 0);
                                                verify(mockMatrix, never()).getEntry(2, 0); // Shouldn't reach last row
                                            }

    @Test
                               public void testGetBasicRow_ShouldReturnNullWhenNonZeroEntryFoundAfterValidRow() {
                                   // Setup test data
                                   int col = 2;
                                   int height = 4;
                                   int numObjectiveFunctions = 1;
                                   double epsilon = 0.0001;
                                   
                                   // Create real SimplexTableau with minimal setup using reflection
                                   try {
                                       // Get constructor
                                       Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                       Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                           LinearObjectiveFunction.class, 
                                           Collection.class, 
                                           GoalType.class, 
                                           boolean.class, 
                                           double.class
                                       );
                                       constructor.setAccessible(true);
                                       
                                       LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0, 0}, 0);
                                       Collection<LinearConstraint> constraints = new ArrayList<>();
                                       constraints.add(new LinearConstraint(new double[]{1, 0, 0}, Relationship.EQ, 0));
                                       Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, epsilon);
                                       
                                       // Set height and numObjectiveFunctions
                                       Field heightField = simplexTableauClass.getDeclaredField("height");
                                       heightField.setAccessible(true);
                                       heightField.set(tableau, height);
                                       
                                       Field numObjectiveFunctionsField = simplexTableauClass.getDeclaredField("numObjectiveFunctions");
                                       numObjectiveFunctionsField.setAccessible(true);
                                       numObjectiveFunctionsField.set(tableau, numObjectiveFunctions);
                                       
                                       // Set entries in the tableau
                                       Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                       tableauField.setAccessible(true);
                                       RealMatrix matrix = (RealMatrix) tableauField.get(tableau);
                                       
                                       // Setup entries:
                                       // row 1 (objective functions): 0.0 (not checked)
                                       // row 2: 1.0 (should mark this row)
                                       // row 3: 0.5 (invalid - should make original return null, mutant would return row 2)
                                       // row 4: 0.0 (not reached)
                                       matrix.setEntry(1, col, 1.0);
                                       matrix.setEntry(2, col, 0.5);
                                       matrix.setEntry(3, col, 0.0);
                                       
                                       // Call the private method
                                       Method method = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                       method.setAccessible(true);
                                       Integer result = (Integer) method.invoke(tableau, col);
                                       
                                       // Assertion - original should return null, mutant would return 1
                                       assertNull("Should return null when non-zero entry found after valid row", result);
                                   } catch (Exception e) {
                                       fail("Test failed due to reflection error: " + e.getMessage());
                                   }
                               }

    @Test
                      public void testGetBasicRow_ShouldReturnNullWhenNonZeroNonOneEntryExists() throws Exception {
                          // Setup test data
                          int col = 1;
                          int numObjectiveFunctions = 0;
                          int height = 3;
                          
                          // Create required objects using reflection
                          Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                          Constructor<?> linearObjectiveFunctionConstructor = linearObjectiveFunctionClass.getConstructor(double[].class, double.class);
                          Object f = linearObjectiveFunctionConstructor.newInstance(new double[]{1.0}, 0.0);
                          
                          Collection<Object> constraints = new ArrayList<>();
                          Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                          Object goalType = Enum.valueOf((Class<Enum>) goalTypeClass, "MAXIMIZE");
                          double epsilon = 1.0e-6;
                          
                          // Create SimplexTableau instance using reflection
                          Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                          Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                              linearObjectiveFunctionClass, 
                              Collection.class, 
                              goalTypeClass, 
                              boolean.class, 
                              double.class
                          );
                          constructor.setAccessible(true);
                          Object tableau = constructor.newInstance(f, constraints, goalType, true, epsilon);
                          
                          // Create a spy of the tableau
                          Object spyTableau = spy(tableau);
                          
                          // Stub method calls
                          when(simplexTableauClass.getMethod("getNumObjectiveFunctions").invoke(spyTableau))
                              .thenReturn(numObjectiveFunctions);
                          when(simplexTableauClass.getMethod("getHeight").invoke(spyTableau))
                              .thenReturn(height);
                          when(simplexTableauClass.getMethod("getEntry", int.class, int.class).invoke(spyTableau, 0, col))
                              .thenReturn(1.0);  // Valid basic row
                          when(simplexTableauClass.getMethod("getEntry", int.class, int.class).invoke(spyTableau, 1, col))
                              .thenReturn(0.5);  // Invalid entry (not 0 or 1)
                          when(simplexTableauClass.getMethod("getEntry", int.class, int.class).invoke(spyTableau, 2, col))
                              .thenReturn(0.0);  // Valid zero entry
                          
                          // Call the private method using reflection
                          Method method = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                          method.setAccessible(true);
                          Integer result = (Integer) method.invoke(spyTableau, col);
                          
                          // Verify the result
                          assertNull("Should return null when non-zero non-one entry exists", result);
                          
                          // Verify interactions
                          verify(simplexTableauClass.getMethod("getNumObjectiveFunctions").invoke(spyTableau));
                          verify(simplexTableauClass.getMethod("getHeight").invoke(spyTableau));
                          verify(simplexTableauClass.getMethod("getEntry", int.class, int.class).invoke(spyTableau, 0, col));
                          verify(simplexTableauClass.getMethod("getEntry", int.class, int.class).invoke(spyTableau, 1, col));
                      }

    @Test
             public void testGetBasicRow_NonZeroEntry_ShouldReturnNull() {
                 // Setup test data
                 int col = 1;
                 double epsilon = 0.0001;
                 
                 // Create real instance of SimplexTableau with minimal required parameters
                 LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0}, 0);
                 Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                 GoalType goalType = GoalType.MAXIMIZE;
                 
                 // Create instance using reflection since constructor is not public
                 Object tableau;
                 try {
                     Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                     Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                         LinearObjectiveFunction.class, 
                         Collection.class, 
                         GoalType.class, 
                         boolean.class, 
                         double.class
                     );
                     constructor.setAccessible(true);
                     tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                 } catch (Exception e) {
                     fail("Failed to create SimplexTableau instance: " + e.getMessage());
                     return;
                 }
                 
                 // Set up test data in the tableau using reflection
                 try {
                     // Get the tableau data field
                     Class<?> tableauClass = tableau.getClass();
                     Field tableauField = tableauClass.getDeclaredField("tableau");
                     tableauField.setAccessible(true);
                     Object matrix = tableauField.get(tableau);
                     
                     // Get setEntry method from RealMatrixImpl
                     Method setEntryMethod = matrix.getClass().getMethod("setEntry", int.class, int.class, double.class);
                     
                     // Create test data - first row has non-zero entry (0.5), others have 0.0
                     setEntryMethod.invoke(matrix, 0, col, 0.5);
                     setEntryMethod.invoke(matrix, 1, col, 0.0);
                     setEntryMethod.invoke(matrix, 2, col, 0.0);
                 } catch (Exception e) {
                     fail("Failed to setup test data: " + e.getMessage());
                     return;
                 }
                 
                 // Call the private method under test
                 try {
                     Class<?> tableauClass = tableau.getClass();
                     Method method = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                     method.setAccessible(true);
                     Integer result = (Integer) method.invoke(tableau, col);
                     
                     // Verify - should return null when non-zero entry found
                     assertNull("Should return null when non-zero entry found", result);
                 } catch (Exception e) {
                     fail("Test failed due to reflection exception: " + e.getMessage());
                 }
             }

    @Test
    public void testGetBasicRow_NonZeroEntry_ShouldThrowException() throws Exception {
        // Setup test data
        int col = 1;
        double epsilon = 0.0001;
        
        // Create a real SimplexTableau instance with minimal required parameters
        LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0}, 0);
        Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
        GoalType goalType = GoalType.MAXIMIZE;
        
        // Get the SimplexTableau class
        Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
        
        // Create instance with reflection since constructor is not public
        Constructor<?> constructor = tableauClass.getDeclaredConstructor(
            LinearObjectiveFunction.class, 
            Collection.class, 
            GoalType.class, 
            boolean.class, 
            double.class
        );
        constructor.setAccessible(true);
        Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
        
        // Set up the tableau entries using reflection
        Method setEntryMethod = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
        setEntryMethod.setAccessible(true);
        setEntryMethod.invoke(tableau, 0, col, 0.5);  // Non-zero, non-one value
        setEntryMethod.invoke(tableau, 1, col, 0.0);
        setEntryMethod.invoke(tableau, 2, col, 0.0);
        
        // Call the method - should throw RuntimeException
        try {
            Method method = tableauClass.getDeclaredMethod("getBasicRow", int.class);
            method.setAccessible(true);
            method.invoke(tableau, col);
            fail("Expected RuntimeException");
        } catch (InvocationTargetException e) {
            if (!(e.getCause() instanceof RuntimeException)) {
                fail("Expected RuntimeException but got: " + e.getCause());
            }
            // Expected exception
        }
    }


}
