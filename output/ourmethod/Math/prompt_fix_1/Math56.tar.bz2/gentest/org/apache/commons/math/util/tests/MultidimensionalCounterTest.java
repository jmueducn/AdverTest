package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import org.apache.commons.math.exception.DimensionMismatchException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.util.MathUtils;
 
public class MultidimensionalCounterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                public void testGetCounts_TwoDimensions() {
                                    int[] sizes = {3, 4}; // 3x4 grid
                                    MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                    
                                    // Test various indices
                                    assertArrayEquals(new int[]{0, 0}, counter.getCounts(0));
                                    assertArrayEquals(new int[]{0, 1}, counter.getCounts(1));
                                    assertArrayEquals(new int[]{0, 3}, counter.getCounts(3));
                                    assertArrayEquals(new int[]{1, 0}, counter.getCounts(4));
                                    assertArrayEquals(new int[]{2, 3}, counter.getCounts(11));
                                }

    @Test
                                public void testGetCounts_ThreeDimensions() {
                                    int[] sizes = {2, 3, 4}; // 2x3x4 cube
                                    MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                    
                                    // Test various indices
                                    assertArrayEquals(new int[]{0, 0, 0}, counter.getCounts(0));
                                    assertArrayEquals(new int[]{0, 0, 1}, counter.getCounts(1));
                                    assertArrayEquals(new int[]{0, 1, 0}, counter.getCounts(4));
                                    assertArrayEquals(new int[]{0, 2, 3}, counter.getCounts(11));
                                    assertArrayEquals(new int[]{1, 0, 0}, counter.getCounts(12));
                                    assertArrayEquals(new int[]{1, 2, 3}, counter.getCounts(23));
                                }

    @Test
                                public void testGetCounts_SingleDimension() {
                                    int[] sizes = {5}; // Single dimension
                                    MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                    
                                    assertArrayEquals(new int[]{0}, counter.getCounts(0));
                                    assertArrayEquals(new int[]{1}, counter.getCounts(1));
                                    assertArrayEquals(new int[]{4}, counter.getCounts(4));
                                }

    @Test
                                public void testGetCounts_NegativeIndex() {
                                    int[] sizes = {2, 2};
                                    MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                    
                                    thrown.expect(OutOfRangeException.class);
                                    thrown.expectMessage("-1 out of [0, 4)");
                                    counter.getCounts(-1);
                                }

    @Test
                                public void testGetCounts_IndexTooLarge() {
                                    int[] sizes = {2, 2};
                                    MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                    
                                    thrown.expect(OutOfRangeException.class);
                                    thrown.expectMessage("4 out of [0, 4)");
                                    counter.getCounts(4);
                                }

    @Test
                                public void testGetCounts_BoundaryConditions() {
                                    int[] sizes = {3, 3, 3};
                                    MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                    
                                    // First element
                                    assertArrayEquals(new int[]{0, 0, 0}, counter.getCounts(0));
                                    // Last element
                                    assertArrayEquals(new int[]{2, 2, 2}, counter.getCounts(26));
                                    // Middle element
                                    assertArrayEquals(new int[]{1, 1, 1}, counter.getCounts(13));
                                }

    @Test
                                public void testGetCounts_LargerDimensions() {
                                    int[] sizes = {5, 4, 3, 2};
                                    MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                                    
                                    assertArrayEquals(new int[]{0, 0, 0, 0}, counter.getCounts(0));
                                    assertArrayEquals(new int[]{0, 0, 0, 1}, counter.getCounts(1));
                                    assertArrayEquals(new int[]{0, 0, 1, 0}, counter.getCounts(2));
                                    assertArrayEquals(new int[]{0, 1, 0, 0}, counter.getCounts(6));
                                    assertArrayEquals(new int[]{1, 0, 0, 0}, counter.getCounts(24));
                                    assertArrayEquals(new int[]{4, 3, 2, 1}, counter.getCounts(119));
                                }

    @Test
                    public void testGetCounts_EmptyCounter() throws Exception {
                        int[] sizes = {};
                        MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                        
                        Method getCountsMethod = MultidimensionalCounter.class.getDeclaredMethod("getCounts");
                        getCountsMethod.setAccessible(true);
                        int[] result = (int[]) getCountsMethod.invoke(counter);
                        
                        assertNotNull(result);
                        assertEquals(0, result.length);
                    }

    @Test
                    public void testGetCounts_MultipleElements() {
                        int[] sizes = {2, 3, 4};
                        MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                        
                        // Test with a specific index (0 in this case)
                        int[] result = counter.getCounts(0);
                        assertNotNull(result);
                        assertEquals(3, result.length);
                        assertArrayEquals(new int[]{0, 0, 0}, result);
                        
                        // Verify it's a deep copy
                        result[0] = 1;
                        result[1] = 2;
                        result[2] = 3;
                        assertArrayEquals(new int[]{0, 0, 0}, counter.getCounts(0));
                    }

    @Test
                    public void testGetCounts_VerifyImmutability() {
                        int[] sizes = {2, 2};
                        MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                        
                        // Get counts for index 0 (assuming valid index)
                        int[] firstCopy = counter.getCounts(0);
                        int[] secondCopy = counter.getCounts(0);
                        
                        assertNotSame(firstCopy, secondCopy);
                        assertArrayEquals(firstCopy, secondCopy);
                        
                        firstCopy[0] = 5;
                        assertNotEquals(firstCopy[0], secondCopy[0]);
                    }

    @Test
        public void testGetCounts_AfterModification() {
            int[] sizes = {1, 2, 3};
            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
            
            // Simulate some counting operations (assuming other methods modify counter)
            // This would normally be done through other methods, but we'll simulate
            int[] modifiedCounter = {1, 1, 2};
            // Note: In real usage, counter would be modified through class methods
            // For testing purposes, we'll assume it was modified
            
            // Use reflection to set the private counter for testing
            try {
                java.lang.reflect.Field field = MultidimensionalCounter.class.getDeclaredField("counter");
                field.setAccessible(true);
                field.set(counter, modifiedCounter);
            } catch (Exception e) {
                fail("Failed to set counter field for testing");
            }
            
            // Get counts for index 0 (or any valid index)
            int[] result = counter.getCounts(0);
            assertArrayEquals(modifiedCounter, result);
            
            // Verify it's a copy
            result[0] = 99;
            assertNotEquals(modifiedCounter[0], result[0]);
        }

    @Test
    public void testGetCounts_SingleElementCounter() {
        int[] sizes = {5};
        MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
        
        // Test getCounts() with index 0
        int[] result = counter.getCounts(0);
        assertNotNull(result);
        assertEquals(1, result.length);
        assertEquals(0, result[0]); // Initial count should be 0
        
        // Verify it's a copy
        result[0] = 10;
        assertNotEquals(result[0], counter.getCounts(0)[0]);
    }


}
