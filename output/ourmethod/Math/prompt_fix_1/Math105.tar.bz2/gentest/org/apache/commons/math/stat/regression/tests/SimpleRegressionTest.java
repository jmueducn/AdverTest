package gentest.org.apache.commons.math.stat.regression.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.regression.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.DistributionFactory;
import org.apache.commons.math.distribution.TDistribution;
 
public class SimpleRegressionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
              public void testGetSumSquaredErrors_AllZeroValues() throws Exception {
                  // Create regression instance
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 0.0);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.set(regression, 0.0);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 0.0);
                  
                  double result = regression.getSumSquaredErrors();
                  assertEquals(0.0, result, 0.0001);
              }

 @Test
              public void testGetSumSquaredErrors_PositiveCase() throws Exception {
                  // Create regression object
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 10.0);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.set(regression, 20.0);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 5.0);
                  
                  // Expected: 20 - (5*5)/10 = 20 - 2.5 = 17.5
                  double result = regression.getSumSquaredErrors();
                  assertEquals(17.5, result, 0.0001);
              }

 @Test
              public void testGetSumSquaredErrors_NegativeResultClampedToZero() throws Exception {
                  // Create regression instance
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 10.0);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.set(regression, 2.0);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 5.0);
                  
                  // Expected: max(0, 2 - (5*5)/10) = max(0, -0.5) = 0
                  double result = regression.getSumSquaredErrors();
                  assertEquals(0.0, result, 0.0001);
              }

 @Test
              public void testGetSumSquaredErrors_PerfectCorrelation() throws Exception {
                  // Create regression instance
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 4.0);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.set(regression, 9.0);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 6.0);
                  
                  // Expected: max(0, 9 - (6*6)/4) = max(0, 0) = 0
                  double result = regression.getSumSquaredErrors();
                  assertEquals(0.0, result, 0.0001);
              }

 @Test
              public void testGetSumSquaredErrors_WithVerySmallValues() throws Exception {
                  // Create regression instance
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 1e-10);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.set(regression, 1e-10);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 1e-10);
                  
                  // Test with very small values to check precision
                  double result = regression.getSumSquaredErrors();
                  assertEquals(0.0, result, 1e-20);
              }

 @Test
              public void testGetSumSquaredErrors_WithVeryLargeValues() throws Exception {
                  // Create regression instance
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.setDouble(regression, 1e10);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.setDouble(regression, 2e10);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.setDouble(regression, 1e10);
                  
                  // Expected: 2e10 - (1e10 * 1e10)/1e10 = 1e10
                  double result = regression.getSumSquaredErrors();
                  assertEquals(1e10, result, 1e5);  // Using larger delta due to floating point precision with large numbers
              }

 @Test
              public void testGetSumSquaredErrors_SumXXZeroButOthersNot() throws Exception {
                  // Edge case where sumXX is zero but other values are not
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Use reflection to set private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  sumXXField.setAccessible(true);
                  sumXXField.set(regression, 0.0);
                  
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  sumYYField.setAccessible(true);
                  sumYYField.set(regression, 10.0);
                  
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  sumXYField.setAccessible(true);
                  sumXYField.set(regression, 5.0);
                  
                  // Should return max(0, 10 - (5*5)/0) but division by zero should be handled
                  // Since we're using doubles, division by zero gives Infinity
                  // 10 - Infinity = -Infinity, so max(0, -Infinity) = 0
                  double result = regression.getSumSquaredErrors();
                  assertEquals(0.0, result, 0.0001);
              }

 @Test
              public void testGetSumSquaredErrors_NaNInputs() throws Exception {
                  // Create regression instance
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Get field references using reflection
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  
                  // Make fields accessible
                  sumXXField.setAccessible(true);
                  sumYYField.setAccessible(true);
                  sumXYField.setAccessible(true);
                  
                  // Test with NaN in sumXX
                  sumXXField.set(regression, Double.NaN);
                  sumYYField.set(regression, 10.0);
                  sumXYField.set(regression, 5.0);
                  
                  double result = regression.getSumSquaredErrors();
                  assertTrue(Double.isNaN(result));
                  
                  // Test with NaN in sumYY
                  sumXXField.set(regression, 10.0);
                  sumYYField.set(regression, Double.NaN);
                  sumXYField.set(regression, 5.0);
                  
                  result = regression.getSumSquaredErrors();
                  assertTrue(Double.isNaN(result));
                  
                  // Test with NaN in sumXY
                  sumXXField.set(regression, 10.0);
                  sumYYField.set(regression, 10.0);
                  sumXYField.set(regression, Double.NaN);
                  
                  result = regression.getSumSquaredErrors();
                  assertTrue(Double.isNaN(result));
              }

 @Test
              public void testGetSumSquaredErrors_InfiniteValues() throws Exception {
                  // Create regression instance
                  SimpleRegression regression = new SimpleRegression();
                  
                  // Get Field objects for private fields
                  Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                  Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                  Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                  
                  // Make fields accessible
                  sumXXField.setAccessible(true);
                  sumYYField.setAccessible(true);
                  sumXYField.setAccessible(true);
                  
                  // Test with infinite sumXX
                  sumXXField.set(regression, Double.POSITIVE_INFINITY);
                  sumYYField.set(regression, 10.0);
                  sumXYField.set(regression, 5.0);
                  
                  double result = regression.getSumSquaredErrors();
                  assertEquals(10.0, result, 0.0001);
                  
                  // Test with infinite sumYY
                  sumXXField.set(regression, 10.0);
                  sumYYField.set(regression, Double.POSITIVE_INFINITY);
                  sumXYField.set(regression, 5.0);
                  
                  result = regression.getSumSquaredErrors();
                  assertTrue(Double.isInfinite(result));
              }

 @Test
          public void testGetSlopeWithTwoDataPoints() {
              // Create regression object and add exactly 2 data points
              SimpleRegression regression = new SimpleRegression();
              regression.addData(1.0, 2.0);
              regression.addData(2.0, 3.0);
              
              // Verify slope is calculated (not NaN)
              double slope = regression.getSlope();
              assertFalse("Slope should not be NaN for n=2", Double.isNaN(slope));
              
              // Verify the actual slope calculation is correct
              // For points (1,2) and (2,3), slope should be 1.0
              assertEquals(1.0, slope, 0.0001);
          }

 @Test
             public void testGetSlopeWithOneDataPoint() {
                 // Create test object
                 SimpleRegression regression = new SimpleRegression();
                 
                 // Add exactly one data point (n=1)
                 regression.addData(1.0, 2.0);
                 
                 // Verify the slope with n=1 should be NaN (original behavior)
                 // The mutant would return a calculated value instead
                 assertEquals(Double.NaN, regression.getSlope(), 0.0);
                 
                 // Additional verification that n is indeed 1
                 assertEquals(1L, regression.getN());
             }

 @Test
            public void testGetSlope_NotEnoughData_ReturnsNaN() {
                // Create a new regression instance (starts with n=0)
                SimpleRegression regression = new SimpleRegression();
                
                // Verify initial state has n=0
                assertEquals(0, regression.getN());
                
                // Test getSlope with n < 2
                double slope = regression.getSlope();
                
                // Original should return NaN, mutant returns POSITIVE_INFINITY
                assertTrue("Slope should be NaN when n < 2", Double.isNaN(slope));
                
                // Add one data point (n=1)
                regression.addData(1.0, 2.0);
                assertEquals(1, regression.getN());
                
                // Test again with n=1
                slope = regression.getSlope();
                assertTrue("Slope should be NaN when n < 2", Double.isNaN(slope));
            }

 @Test
           public void testGetSlope_NotEnoughData_ShouldReturnNaN() {
               // Create regression object with no data (n = 0)
               SimpleRegression regression = new SimpleRegression();
               
               // Verify n is indeed 0 (just to be safe)
               assertEquals(0, regression.getN());
               
               // Call getSlope and verify it returns NaN for insufficient data
               double slope = regression.getSlope();
               assertTrue("Slope should be NaN when n < 2", Double.isNaN(slope));
               
               // Add one data point (n = 1)
               regression.addData(1.0, 2.0);
               assertEquals(1, regression.getN());
               
               // Verify still returns NaN with n = 1
               slope = regression.getSlope();
               assertTrue("Slope should be NaN when n < 2", Double.isNaN(slope));
           }

 @Test
      public void testGetSlope_BoundaryConditionForSumXX() {
          // Setup
          SimpleRegression regression = new SimpleRegression();
          
          // Use reflection to set private fields since there's no public setter
          try {
              // Set n >= 2 to avoid first NaN condition
              Field nField = SimpleRegression.class.getDeclaredField("n");
              nField.setAccessible(true);
              nField.setLong(regression, 2L);
              
              // Set sumXX to exactly 10*Double.MIN_VALUE (the boundary value)
              Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
              sumXXField.setAccessible(true);
              sumXXField.setDouble(regression, 10 * Double.MIN_VALUE);
              
              // Set sumXY to some non-zero value to make slope calculation meaningful
              Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
              sumXYField.setAccessible(true);
              sumXYField.setDouble(regression, 1.0);
          } catch (Exception e) {
              fail("Failed to set up test due to reflection error: " + e.getMessage());
          }
          
          // Test - original should return a valid slope, mutant would return NaN
          double slope = regression.getSlope();
          assertFalse("Slope should not be NaN when sumXX equals 10*MIN_VALUE", 
                     Double.isNaN(slope));
          
          // Verify the slope calculation is correct
          double expectedSlope = 1.0 / (10 * Double.MIN_VALUE);
          assertEquals(expectedSlope, slope, 0.0001);
      }

 @Test
         public void testGetSlope_DetectsSmallSumXXMutation() {
             // Create test instance
             SimpleRegression regression = new SimpleRegression();
             
             // Use reflection to set private fields since we need specific test values
             try {
                 // Set n to 2 to pass first check
                 java.lang.reflect.Field nField = SimpleRegression.class.getDeclaredField("n");
                 nField.setAccessible(true);
                 nField.setLong(regression, 2L);
                 
                 // Set sumXX to a value between 10 and 100 * MIN_VALUE
                 double testSumXX = 50 * Double.MIN_VALUE;
                 java.lang.reflect.Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                 sumXXField.setAccessible(true);
                 sumXXField.setDouble(regression, testSumXX);
                 
                 // Set sumXY to some arbitrary value
                 java.lang.reflect.Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                 sumXYField.setAccessible(true);
                 sumXYField.setDouble(regression, 1.0);
                 
                 // Test - original should return NaN, mutant will return a value
                 double result = regression.getSlope();
                 assertTrue("Should return NaN for sumXX = 50*MIN_VALUE", 
                           Double.isNaN(result));
                 
             } catch (Exception e) {
                 fail("Reflection failed: " + e.getMessage());
             }
         }

 @Test
        public void testGetSlope_WhenNoXVariation_ShouldReturnNaN() {
            // Setup - create regression object and add data with no x variation
            SimpleRegression regression = new SimpleRegression();
            
            // Add two points with identical x values (no variation)
            regression.addData(5.0, 10.0);
            regression.addData(5.0, 20.0);
            
            // Verify the sumXX is very small (less than threshold)
            // Note: We can't directly access sumXX as it's private, but we know adding
            // identical x values will make it very small
            
            // Test and assert
            double result = regression.getSlope();
            assertTrue("Should return NaN when no x variation", 
                      Double.isNaN(result));
            
            // This will catch the mutant because:
            // Original code returns NaN
            // Mutant returns POSITIVE_INFINITY
            // Our assertion checks for NaN specifically
        }

 @Test
       public void testGetSlope_WhenSumXXIsVerySmall_ShouldReturnNaN() {
           // Setup
           SimpleRegression regression = new SimpleRegression();
           
           // Add data points with identical x values (sumXX will be very small)
           regression.addData(5.0, 10.0);
           regression.addData(5.0, 20.0);  // Same x value
           
           // Test
           double result = regression.getSlope();
           
           // Verify
           assertTrue("Should return NaN when sumXX is very small", 
                     Double.isNaN(result));
       }

 @Test
      public void testGetSlopeDetectsDivisionMutant() {
          // Setup test data where sumXY != sumXX
          SimpleRegression regression = new SimpleRegression();
          
          // Add data points that will produce known sumXX and sumXY
          // Using points (1,3) and (2,5) - line with slope 2
          regression.addData(1.0, 3.0);
          regression.addData(2.0, 5.0);
          
          // Calculate expected slope: sumXY/sumXX
          // For these points:
          // sumXY = (1-1.5)*(3-4) + (2-1.5)*(5-4) = 0.5 + 0.5 = 1.0
          // sumXX = (1-1.5)^2 + (2-1.5)^2 = 0.25 + 0.25 = 0.5
          // Expected slope = 1.0 / 0.5 = 2.0
          double expectedSlope = 2.0;
          
          // The mutant would return 0.5 / 1.0 = 0.5 instead
          double actualSlope = regression.getSlope();
          
          // This assertion will fail if the mutant is present
          assertEquals("Slope calculation is incorrect", expectedSlope, actualSlope, 1e-10);
      }

 @Test
 public void testGetSlope_DetectsDivisionToMultiplicationMutant() {
     // Setup test data that will clearly show the difference between division and multiplication
     SimpleRegression regression = new SimpleRegression();
     
     // Add data points that create known sumXY and sumXX values
     // Using simple numbers that make verification easy
     regression.addData(1, 2);  // x=1, y=2
     regression.addData(2, 4);  // x=2, y=4
     
     // For these points:
     // sumXY = (1-1.5)*(2-3) + (2-1.5)*(4-3) = 0.5 + 0.5 = 1.0
     // sumXX = (1-1.5)^2 + (2-1.5)^2 = 0.25 + 0.25 = 0.5
     // Expected slope = sumXY/sumXX = 1.0/0.5 = 2.0
     // Mutant would return 1.0 * 0.5 = 0.5
     
     double expectedSlope = 2.0;
     double actualSlope = regression.getSlope();
     
     // This assertion will fail if the mutant is present (would get 0.5 instead of 2.0)
     assertEquals("Slope calculation should use division, not multiplication", 
                  expectedSlope, actualSlope, 0.0001);
     
     // Additional verification that we're not getting the product
     assertNotEquals("Should not be getting product of sumXY and sumXX",
                   1.0 * 0.5, actualSlope, 0.0001);
 }

}
