package gentest.org.apache.commons.math3.genetics.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.genetics.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
 
public class ListPopulationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                               public void testIterator_VerifyUnmodifiable() {
                                                                                                                                   // Setup
                                                                                                                                   List<Chromosome> chromosomes = new ArrayList<>();
                                                                                                                                   Chromosome chr1 = mock(Chromosome.class);
                                                                                                                                   chromosomes.add(chr1);
                                                                                                                                   
                                                                                                                                   // Use concrete implementation of ListPopulation
                                                                                                                                   ListPopulation population = new ElitisticListPopulation(chromosomes, 10, 0.1);
                                                                                                                                   Iterator<Chromosome> iterator = population.iterator();
                                                                                                                                   
                                                                                                                                   // Test & Verify
                                                                                                                                   thrown.expect(UnsupportedOperationException.class);
                                                                                                                                   iterator.remove();
                                                                                                                               }

    @Test
                                                                                                                       public void testIterator_EmptyPopulation() {
                                                                                                                           // Setup
                                                                                                                           List<Chromosome> emptyList = Collections.emptyList();
                                                                                                                           ListPopulation population = new ListPopulation(emptyList, 10) {
                                                                                                                               @Override
                                                                                                                               public Population nextGeneration() {
                                                                                                                                   return new ListPopulation(this.getChromosomes(), this.getPopulationLimit()) {
                                                                                                                                       @Override
                                                                                                                                       public Population nextGeneration() {
                                                                                                                                           return null; // Not used in this test
                                                                                                                                       }
                                                                                                                                   };
                                                                                                                               }
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Test
                                                                                                                           Iterator<Chromosome> iterator = population.iterator();
                                                                                                                           
                                                                                                                           // Verify
                                                                                                                           assertNotNull("Iterator should not be null", iterator);
                                                                                                                           assertFalse("Iterator should have no elements", iterator.hasNext());
                                                                                                                       }

    @Test
                                                                                                                       public void testIterator_PopulatedList() {
                                                                                                                           // Setup
                                                                                                                           List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                                                           Chromosome chr1 = mock(Chromosome.class);
                                                                                                                           Chromosome chr2 = mock(Chromosome.class);
                                                                                                                           chromosomes.add(chr1);
                                                                                                                           chromosomes.add(chr2);
                                                                                                                           
                                                                                                                           // Create an anonymous subclass of ListPopulation for testing
                                                                                                                           ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                               @Override
                                                                                                                               public Population nextGeneration() {
                                                                                                                                   // Simple implementation for testing purposes
                                                                                                                                   return new ListPopulation(this.getChromosomes(), this.getPopulationLimit()) {
                                                                                                                                       @Override
                                                                                                                                       public Population nextGeneration() {
                                                                                                                                           return null; // Not used in this test
                                                                                                                                       }
                                                                                                                                   };
                                                                                                                               }
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Test
                                                                                                                           Iterator<Chromosome> iterator = population.iterator();
                                                                                                                           
                                                                                                                           // Verify
                                                                                                                           assertNotNull("Iterator should not be null", iterator);
                                                                                                                           assertTrue("Iterator should have elements", iterator.hasNext());
                                                                                                                           
                                                                                                                           // Verify iteration order matches list order
                                                                                                                           assertEquals("First element should match", chr1, iterator.next());
                                                                                                                           assertEquals("Second element should match", chr2, iterator.next());
                                                                                                                           assertFalse("Iterator should be exhausted", iterator.hasNext());
                                                                                                                       }

    @Test
                                                                                                                       public void testIterator_WithNullChromosomes() {
                                                                                                                           // Create a concrete subclass of ListPopulation for testing
                                                                                                                           ListPopulation population = new ListPopulation(10) {
                                                                                                                               @Override
                                                                                                                               public String toString() {
                                                                                                                                   return "TestPopulation";
                                                                                                                               }
                                                                                                                               
                                                                                                                               @Override
                                                                                                                               public Population nextGeneration() {
                                                                                                                                   return new ListPopulation(10) {
                                                                                                                                       @Override
                                                                                                                                       public Population nextGeneration() {
                                                                                                                                           return null;
                                                                                                                                       }
                                                                                                                                   };
                                                                                                                               }
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Setup chromosomes
                                                                                                                           List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                                                           chromosomes.add(null);
                                                                                                                           chromosomes.add(mock(Chromosome.class));
                                                                                                                           
                                                                                                                           // Use reflection to set chromosomes since setChromosomes might have validation
                                                                                                                           try {
                                                                                                                               Field chromosomesField = ListPopulation.class.getDeclaredField("chromosomes");
                                                                                                                               chromosomesField.setAccessible(true);
                                                                                                                               chromosomesField.set(population, chromosomes);
                                                                                                                           } catch (Exception e) {
                                                                                                                               fail("Failed to set chromosomes via reflection: " + e.getMessage());
                                                                                                                           }
                                                                                                                           
                                                                                                                           // Test
                                                                                                                           Iterator<Chromosome> iterator = population.iterator();
                                                                                                                           
                                                                                                                           // Verify
                                                                                                                           assertNull("Should handle null chromosomes", iterator.next());
                                                                                                                           assertNotNull("Should handle non-null chromosomes", iterator.next());
                                                                                                                           assertFalse("Iterator should be exhausted", iterator.hasNext());
                                                                                                                       }

    @Test
                                                                                                               public void testIterator_AfterModifyingPopulation() {
                                                                                                                   // Setup
                                                                                                                   List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                                                   Chromosome chr1 = mock(Chromosome.class);
                                                                                                                   Chromosome chr2 = mock(Chromosome.class);
                                                                                                                   chromosomes.add(chr1);
                                                                                                                   
                                                                                                                   // Create concrete instance of ListPopulation using anonymous class
                                                                                                                   ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                                       @Override
                                                                                                                       public Population nextGeneration() {
                                                                                                                           // Return a new concrete instance instead of abstract ListPopulation
                                                                                                                           return new ListPopulation(getChromosomes(), getPopulationLimit()) {
                                                                                                                               @Override
                                                                                                                               public Population nextGeneration() {
                                                                                                                                   return null; // Not used in this test
                                                                                                                               }
                                                                                                                           };
                                                                                                                       }
                                                                                                                   };
                                                                                                                   Iterator<Chromosome> iterator = population.iterator();
                                                                                                                   
                                                                                                                   // Modify population after getting iterator
                                                                                                                   population.addChromosome(chr2);
                                                                                                                   
                                                                                                                   // Verify iterator still only sees original state
                                                                                                                   assertTrue(iterator.hasNext());
                                                                                                                   assertEquals(chr1, iterator.next());
                                                                                                                   assertFalse("Iterator should not see added chromosome", iterator.hasNext());
                                                                                                               }

    @Test
                                                                                                  public void testIteratorReturnsRegularIteratorNotListIterator() {
                                                                                                      // Would need: import java.util.ListIterator;
                                                                                                      // Setup - create a population with some chromosomes
                                                                                                      List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                                                      chromosomes.add(new Chromosome() {
                                                                                                          @Override
                                                                                                          public double fitness() {
                                                                                                              return 0;
                                                                                                          }
                                                                                                      });
                                                                                                      chromosomes.add(new Chromosome() {
                                                                                                          @Override
                                                                                                          public double fitness() {
                                                                                                              return 0;
                                                                                                          }
                                                                                                      });
                                                                                                      
                                                                                                      // Create a concrete subclass with required abstract method implemented
                                                                                                      ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                                          @Override
                                                                                                          public Population nextGeneration() {
                                                                                                              return null; // Simple implementation for test
                                                                                                          }
                                                                                                      };
                                                                                                      
                                                                                                      // Test the iterator() method
                                                                                                      Iterator<Chromosome> iterator = population.iterator();
                                                                                                      
                                                                                                      // Verify it's not a ListIterator (this will catch the mutant)
                                                                                                      assertFalse("Returned iterator should not be a ListIterator", 
                                                                                                                 iterator instanceof java.util.ListIterator<?>);
                                                                                                      
                                                                                                      // Additional verification of basic iterator functionality
                                                                                                      assertTrue("Iterator should have next element", iterator.hasNext());
                                                                                                      assertNotNull("First element should not be null", iterator.next());
                                                                                                      
                                                                                                      // Verify ListIterator-specific methods would throw ClassCastException
                                                                                                      try {
                                                                                                          ((java.util.ListIterator<Chromosome>)iterator).hasPrevious();
                                                                                                          fail("Expected ClassCastException when trying to cast to ListIterator");
                                                                                                      } catch (ClassCastException expected) {
                                                                                                          // This is expected behavior for regular Iterator
                                                                                                      }
                                                                                                  }

    @Test
                                                                         public void testIteratorReturnsDirectListIterator() {
                                                                             // Setup - create a population with some chromosomes using concrete implementations
                                                                             List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                             chromosomes.add(new Chromosome() {
                                                                                 @Override
                                                                                 public double fitness() {
                                                                                     return 0;
                                                                                 }
                                                                             });
                                                                             chromosomes.add(new Chromosome() {
                                                                                 @Override
                                                                                 public double fitness() {
                                                                                     return 0;
                                                                                 }
                                                                             });
                                                                             
                                                                             // Create a concrete subclass of ListPopulation with required abstract method implemented
                                                                             ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                                                 @Override
                                                                                 public Population nextGeneration() {
                                                                                     return null; // Simple implementation for test purposes
                                                                                 }
                                                                             };
                                                                             
                                                                             // Get the iterator
                                                                             Iterator<Chromosome> iterator = population.iterator();
                                                                             
                                                                             // Modify the underlying list directly
                                                                             population.getChromosomes().add(new Chromosome() {
                                                                                 @Override
                                                                                 public double fitness() {
                                                                                     return 0;
                                                                                 }
                                                                             });
                                                                             
                                                                             // Verify the iterator detects the modification (fail-fast behavior)
                                                                             try {
                                                                                 iterator.next();
                                                                                 org.junit.Assert.fail("Expected ConcurrentModificationException");
                                                                             } catch (java.util.ConcurrentModificationException e) {
                                                                                 // This is expected for the original implementation
                                                                             }
                                                                         }

    @Test
                                                            public void testIteratorBehavior() {
                                                                // Setup test data
                                                                Chromosome c1 = mock(Chromosome.class);
                                                                Chromosome c2 = mock(Chromosome.class);
                                                                List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                                                chromosomes.add(c1);
                                                                chromosomes.add(c2);
                                                                
                                                                // Create concrete subclass of ListPopulation for testing
                                                                class TestPopulation extends ListPopulation {
                                                                    public TestPopulation(List<Chromosome> chromosomes, int populationLimit) {
                                                                        super(chromosomes, populationLimit);
                                                                    }
                                                                    
                                                                    @Override
                                                                    public Population nextGeneration() {
                                                                        // Simple implementation for testing purposes
                                                                        return new TestPopulation(new ArrayList<Chromosome>(), getPopulationLimit());
                                                                    }
                                                                }
                                                                
                                                                // Create population with test data
                                                                TestPopulation population = new TestPopulation(chromosomes, 10);
                                                                
                                                                // Test the iterator
                                                                Iterator<Chromosome> iterator = population.iterator();
                                                                
                                                                // Verify basic iterator properties
                                                                assertNotNull("Iterator should not be null", iterator);
                                                                assertTrue("Iterator should have first element", iterator.hasNext());
                                                                assertEquals("First element should match", c1, iterator.next());
                                                                assertTrue("Iterator should have second element", iterator.hasNext());
                                                                assertEquals("Second element should match", c2, iterator.next());
                                                                assertFalse("Iterator should be exhausted after all elements", iterator.hasNext());
                                                                
                                                                // Test iterator reflects changes to underlying list
                                                                population.addChromosome(mock(Chromosome.class));
                                                                Iterator<Chromosome> newIterator = population.iterator();
                                                                int count = 0;
                                                                while (newIterator.hasNext()) {
                                                                    newIterator.next();
                                                                    count++;
                                                                }
                                                                assertEquals("New iterator should reflect added chromosome", 
                                                                            3, count);
                                                            }

    @Test
                                           public void testIteratorReturnsBasicIteratorNotListIterator() {
                                               // Imports needed (shown here for reference, would normally be at class level):
                                               // import java.util.Iterator;
                                               // import java.util.ListIterator;
                                               
                                               // Setup - create a population with some chromosomes
                                               List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                                               chromosomes.add(mock(Chromosome.class));
                                               chromosomes.add(mock(Chromosome.class));
                                               
                                               // Create a concrete subclass since ListPopulation is abstract
                                               ListPopulation population = new ListPopulation(chromosomes, 10) {
                                                   @Override
                                                   public Population nextGeneration() {
                                                       return null; // Simple implementation for testing
                                                   }
                                               };
                                               
                                               // Execute - get the iterator
                                               Iterator<Chromosome> iterator = population.iterator();
                                               
                                               // Verify - check it's not a ListIterator
                                               assertNotNull("Iterator should not be null", iterator);
                                               assertFalse("Should return basic Iterator, not ListIterator", 
                                                          iterator instanceof java.util.ListIterator);
                                               
                                               // Additional check to verify basic iteration works
                                               assertTrue("Iterator should have next element", iterator.hasNext());
                                               assertNotNull("First element should not be null", iterator.next());
                                           }

    @Test
                              public void testIteratorReturnsDirectListIterator1() {
                                  // Setup test data
                                  List<Chromosome> chromosomes = new ArrayList<>();
                                  chromosomes.add(mock(Chromosome.class));
                                  chromosomes.add(mock(Chromosome.class));
                                  
                                  // Create concrete subclass of ListPopulation for testing
                                  ListPopulation population = new ListPopulation(chromosomes, 10) {
                                      // Implement the abstract method
                                      @Override
                                      public Population nextGeneration() {
                                          return new ListPopulation(getPopulationLimit()) {
                                              @Override
                                              public Population nextGeneration() {
                                                  return null; // Not used in this test
                                              }
                                          };
                                      }
                                  };
                                  
                                  // Get the iterator
                                  Iterator<Chromosome> iterator = population.iterator();
                                  
                                  // Verify it's the same instance as the list's iterator
                                  // This will fail for the mutant which creates a new stream iterator
                                  assertSame("Iterator should be the list's direct iterator", 
                                            chromosomes.iterator(), iterator);
                                  
                                  // Verify behavior - should match list iterator exactly
                                  assertTrue(iterator.hasNext());
                                  assertEquals(chromosomes.get(0), iterator.next());
                                  assertTrue(iterator.hasNext());
                                  assertEquals(chromosomes.get(1), iterator.next());
                                  assertFalse(iterator.hasNext());
                              }

    @Test
                 public void testIteratorReturnsChromosomeIterator() {
                     // Setup test data
                     Chromosome c1 = mock(Chromosome.class);
                     Chromosome c2 = mock(Chromosome.class);
                     List<Chromosome> chromosomes = new ArrayList<Chromosome>();
                     chromosomes.add(c1);
                     chromosomes.add(c2);
                     
                     // Create a concrete subclass with required method implementation
                     ListPopulation population = new ListPopulation(chromosomes, 10) {
                         @Override
                         public Population nextGeneration() {
                             return new ListPopulation(new ArrayList<Chromosome>(), getPopulationLimit()) {
                                 @Override
                                 public Population nextGeneration() {
                                     return null;
                                 }
                             };
                         }
                     };
                     
                     // Call the method under test
                     Iterator<Chromosome> iterator = population.iterator();
                     
                     // Verify the iterator behavior
                     assertNotNull("Iterator should not be null", iterator);
                     assertTrue("Iterator should have next element", iterator.hasNext());
                     assertEquals("First chromosome should match", c1, iterator.next());
                     assertTrue("Iterator should have next element", iterator.hasNext());
                     assertEquals("Second chromosome should match", c2, iterator.next());
                     assertFalse("Iterator should not have more elements", iterator.hasNext());
                     
                     // Additional check for return type
                     assertTrue("Return value should be Iterator", 
                               Iterator.class.isAssignableFrom(iterator.getClass()));
                 }

    @Test
    public void testIteratorReturnType() {
        // Setup - create a concrete subclass of ListPopulation with some chromosomes
        List<Chromosome> chromosomes = new ArrayList<>();
        chromosomes.add(mock(Chromosome.class));
        
        // Create anonymous concrete subclass of ListPopulation
        ListPopulation population = new ListPopulation(chromosomes, 10) {
            @Override
            public Population nextGeneration() {
                // Create another anonymous subclass to return
                return new ListPopulation(this.getChromosomes(), this.getPopulationLimit()) {
                    @Override
                    public Population nextGeneration() {
                        return null; // Simple implementation
                    }
                };
            }
        };
        
        // Test the iterator method
        Iterator<Chromosome> result = population.iterator();
        
        // Verify the return type is Iterator
        assertTrue("iterator() should return Iterator<Chromosome>", 
                  result instanceof Iterator);
    }


}
