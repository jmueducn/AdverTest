package gentest.org.apache.commons.math3.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.linear.*;
import org.apache.commons.math3.util.FastMath;
 
public class RectangularCholeskyDecompositionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                   public void testConstructorWithPositiveDefiniteMatrix() {
                                       // Create a simple 2x2 positive definite matrix
                                       double[][] data = {{4, 12}, {12, 37}};
                                       RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                       double small = 1e-10;
                               
                                       RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
                               
                                       // Verify rank is full (2)
                                       assertEquals(2, decomposition.getRank());
                               
                                       // Verify root matrix
                                       RealMatrix root = decomposition.getRootMatrix();
                                       assertEquals(2, root.getRowDimension());
                                       assertEquals(2, root.getColumnDimension());
                               
                                       // Verify decomposition (should satisfy A ≈ R*R^T)
                                       RealMatrix reconstructed = root.multiply(root.transpose());
                                       assertArrayEquals(data[0], reconstructed.getRow(0), 1e-10);
                                       assertArrayEquals(data[1], reconstructed.getRow(1), 1e-10);
                                   }

    @Test
                                   public void testConstructorWithSemidefiniteMatrix() {
                                       // Create a semidefinite matrix (rank 1)
                                       double[][] data = {{1, 2}, {2, 4}};
                                       RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                       double small = 1e-10;
                               
                                       RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
                               
                                       // Verify rank is 1
                                       assertEquals(1, decomposition.getRank());
                               
                                       // Verify root matrix dimensions
                                       RealMatrix root = decomposition.getRootMatrix();
                                       assertEquals(2, root.getRowDimension());
                                       assertEquals(1, root.getColumnDimension());
                               
                                       // Verify decomposition
                                       RealMatrix reconstructed = root.multiply(root.transpose());
                                       assertArrayEquals(data[0], reconstructed.getRow(0), 1e-10);
                                       assertArrayEquals(data[1], reconstructed.getRow(1), 1e-10);
                                   }

    @Test
                                   public void testConstructorWithNegativeDiagonalElement() {
                                       // Create a matrix with negative diagonal element
                                       double[][] data = {{1, 2}, {2, -4}};
                                       RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                       double small = 1e-10;
                               
                                       thrown.expect(NonPositiveDefiniteMatrixException.class);
                                       thrown.expectMessage("not positive definite");
                                       new RectangularCholeskyDecomposition(matrix, small);
                                   }

    @Test
                                   public void testConstructorWithAllZeroMatrix() {
                                       // Create a zero matrix
                                       double[][] data = {{0, 0}, {0, 0}};
                                       RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                       double small = 1e-10;
                               
                                       thrown.expect(NonPositiveDefiniteMatrixException.class);
                                       new RectangularCholeskyDecomposition(matrix, small);
                                   }

    @Test
                                   public void testConstructorWithSmallDiagonalElements() {
                                       // Create a matrix with diagonal elements smaller than the threshold
                                       double[][] data = {{1e-11, 0}, {0, 1e-12}};
                                       RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                       double small = 1e-10;
                               
                                       thrown.expect(NonPositiveDefiniteMatrixException.class);
                                       new RectangularCholeskyDecomposition(matrix, small);
                                   }

    @Test
                                   public void testConstructorWithNonSquareMatrix() {
                                       // Create a non-square matrix
                                       double[][] data = {{1, 2, 3}, {4, 5, 6}};
                                       RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                       double small = 1e-10;
                               
                                       thrown.expect(NonSquareMatrixException.class);
                                       new RectangularCholeskyDecomposition(matrix, small);
                                   }

    @Test
                                   public void testConstructorWithNonSymmetricMatrix() {
                                       // Create a non-symmetric matrix
                                       double[][] data = {{1, 2}, {3, 4}};
                                       RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                       double small = 1e-10;
                               
                                       // Note: The constructor doesn't explicitly check for symmetry,
                                       // but the algorithm will fail with NonPositiveDefiniteMatrixException
                                       // when it encounters negative values during decomposition
                                       thrown.expect(NonPositiveDefiniteMatrixException.class);
                                       new RectangularCholeskyDecomposition(matrix, small);
                                   }

    @Test
                                   public void testGetRootMatrix() {
                                       double[][] data = {{4, 12}, {12, 37}};
                                       RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                       double small = 1e-10;
                               
                                       RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
                                       RealMatrix root = decomposition.getRootMatrix();
                               
                                       assertNotNull(root);
                                       assertEquals(2, root.getRowDimension());
                                       assertEquals(2, root.getColumnDimension());
                                       assertTrue(root.getEntry(0, 0) > 0); // Diagonal should be positive
                                   }

    @Test
                                   public void testGetRank() {
                                       double[][] fullRankData = {{4, 12}, {12, 37}};
                                       RealMatrix fullRankMatrix = MatrixUtils.createRealMatrix(fullRankData);
                                       double small = 1e-10;
                               
                                       RectangularCholeskyDecomposition fullDecomp = new RectangularCholeskyDecomposition(fullRankMatrix, small);
                                       assertEquals(2, fullDecomp.getRank());
                               
                                       double[][] rank1Data = {{1, 2}, {2, 4}};
                                       RealMatrix rank1Matrix = MatrixUtils.createRealMatrix(rank1Data);
                                       RectangularCholeskyDecomposition rank1Decomp = new RectangularCholeskyDecomposition(rank1Matrix, small);
                                       assertEquals(1, rank1Decomp.getRank());
                                   }

    @Test
                                   public void testPivotSelection() {
                                       // Create matrix where pivoting will occur (diagonal elements not in order)
                                       double[][] data = {{1, 0.5}, {0.5, 2}};
                                       RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                       double small = 1e-10;
                               
                                       RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
                                       
                                       // Verify decomposition is correct despite pivoting
                                       RealMatrix root = decomposition.getRootMatrix();
                                       RealMatrix reconstructed = root.multiply(root.transpose());
                                       assertArrayEquals(data[0], reconstructed.getRow(0), 1e-10);
                                       assertArrayEquals(data[1], reconstructed.getRow(1), 1e-10);
                                   }

    @Test
                           public void testCholeskyDecompositionDetectsPivotMutation() {
                               // Create a simple 2x2 matrix where diagonal elements are different
                               double[][] data = {
                                   {4.0, 1.0},
                                   {1.0, 9.0}  // This should be selected first since 9 > 4
                               };
                               RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                               
                               // Perform decomposition
                               RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, 1e-10);
                               
                               // Get the root matrix
                               RealMatrix root = decomposition.getRootMatrix();
                               
                               // Verify the root matrix values
                               // Correct decomposition would have sqrt(9) = 3 in (1,0) position
                               // Mutant would use wrong pivot and give different values
                               assertEquals(3.0, root.getEntry(1, 0), 1e-10);
                               
                               // Verify other elements as well
                               assertEquals(2.0, root.getEntry(0, 0), 1e-10);
                               assertEquals(0.0, root.getEntry(0, 1), 1e-10);
                               assertEquals(0.0, root.getEntry(1, 1), 1e-10);
                               
                               // Verify rank is correct
                               assertEquals(2, decomposition.getRank());
                           }

    @Test
                          public void testCholeskyDecompositionWithPivotingDetectsIndexMutation() {
                              // Create a matrix that requires pivoting (diagonal not in descending order)
                              double[][] data = {
                                  {4.0, 1.0, 1.0},
                                  {1.0, 3.0, 0.5},
                                  {1.0, 0.5, 2.0}
                              };
                              RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                              
                              // Create decomposition with small threshold that won't trigger exceptions
                              double small = 1e-10;
                              RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
                              
                              // Get the root matrix which would be affected by the mutation
                              RealMatrix root = decomposition.getRootMatrix();
                              
                              // Verify specific values that would differ between original and mutant
                              // The mutation would cause wrong column indexing during transformation
                              double expectedValue = 0.5 / Math.sqrt(4.0); // 1.0/sqrt(4.0) * 0.5
                              assertEquals("Value at [1,0] should reflect correct pivoted transformation", 
                                          expectedValue, root.getEntry(1, 0), 1e-10);
                              
                              // Verify another transformed value that would be affected
                              double expectedValue2 = (2.0 - (1.0*1.0)/4.0 - (0.25*0.25)/(3.0 - (1.0*1.0)/4.0));
                              expectedValue2 = Math.sqrt(expectedValue2);
                              assertEquals("Value at [2,2] should reflect correct pivoted transformation",
                                          expectedValue2, root.getEntry(2, 2), 1e-10);
                              
                              // Verify rank is correct (full rank in this case)
                              assertEquals("Matrix should be full rank", 3, decomposition.getRank());
                          }

    @Test
                         public void testCholeskyDecompositionDetectsIndexMutation() {
                             // Create a 3x3 test matrix where the mutation would produce different results
                             double[][] testData = {
                                 {4, 1, 1},
                                 {1, 5, 2},
                                 {1, 2, 6}
                             };
                             RealMatrix matrix = MatrixUtils.createRealMatrix(testData);
                             
                             // Perform the decomposition
                             RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                             RealMatrix root = decomposition.getRootMatrix();
                             
                             // Verify specific elements that would be affected by the wrong index
                             // The mutation would cause incorrect elements to be modified in the transformation
                             // Check a non-diagonal element that depends on the correct index
                             double expectedValue = 0.5; // Expected value at (1,0) in the root matrix
                             double actualValue = root.getEntry(1, 0);
                             
                             // The mutation would make this assertion fail because it would use wrong indices
                             assertEquals("Element (1,0) should be 0.5", expectedValue, actualValue, 1.0e-10);
                             
                             // Also check another element that would be affected
                             expectedValue = 0.25; // Expected value at (2,0)
                             actualValue = root.getEntry(2, 0);
                             assertEquals("Element (2,0) should be 0.25", expectedValue, actualValue, 1.0e-10);
                             
                             // Check an element from the second column that would be affected by the mutation
                             expectedValue = 2.179449471770337; // Expected value at (2,1)
                             actualValue = root.getEntry(2, 1);
                             assertEquals("Element (2,1) should be correct", expectedValue, actualValue, 1.0e-10);
                         }

    @Test
                       public void testCholeskyDecompositionCatchesSubtractionMutant() {
                           // Create a simple 2x2 positive definite matrix
                           double[][] data = {
                               {4.0, 12.0},
                               {12.0, 37.0}
                           };
                           RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                           
                           // Perform decomposition with small value parameter
                           double small = 1e-10; // typical small value for numerical stability
                           RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
                           RealMatrix root = decomposition.getRootMatrix();
                           
                           // Verify the decomposition is correct (A = LL^T)
                           RealMatrix reconstructed = root.multiply(root.transpose());
                           
                           // Check the original matrix is reconstructed properly
                           for (int i = 0; i < matrix.getRowDimension(); i++) {
                               for (int j = 0; j < matrix.getColumnDimension(); j++) {
                                   assertEquals(matrix.getEntry(i, j), reconstructed.getEntry(i, j), 1e-10);
                               }
                           }
                           
                           // Specifically check the values affected by the mutation
                           // The correct decomposition should be:
                           // [ 2  0 ]
                           // [ 6  1 ]
                           assertEquals(2.0, root.getEntry(0, 0), 1e-10);
                           assertEquals(6.0, root.getEntry(1, 0), 1e-10);
                           assertEquals(1.0, root.getEntry(1, 1), 1e-10);
                           
                           // The mutant would produce incorrect values here because:
                           // Instead of subtracting e*b[j][r], it would add them,
                           // leading to wrong off-diagonal elements in the decomposition
                       }

    @Test
                   public void testMatrixTransformationDetectsMutant() {
                       // Create a test matrix where the subtraction term will make a difference
                       double[][] testData = {
                           {4.0, 1.0, 1.0},
                           {1.0, 4.0, 1.0},
                           {1.0, 1.0, 4.0}
                       };
                       RealMatrix matrix = MatrixUtils.createRealMatrix(testData);
                       double small = 1.0e-10;
                       
                       // Perform the decomposition
                       RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
                       RealMatrix root = decomposition.getRootMatrix();
                       
                       // Verify specific values that would be affected by the mutation
                       // The mutation would cause these assertions to fail
                       assertEquals(2.0, root.getEntry(0, 0), 1.0e-10);
                       assertEquals(0.5, root.getEntry(1, 0), 1.0e-10);
                       assertEquals(0.5, root.getEntry(2, 0), 1.0e-10);
                       
                       // The mutation would particularly affect these transformed values
                       double expectedTransformedValue1 = 1.0 - (0.5 * 0.5); // c[ii][ij] - e*b[j][r]
                       assertEquals(Math.sqrt(expectedTransformedValue1), root.getEntry(1, 1), 1.0e-10);
                       
                       double expectedTransformedValue2 = 1.0 - (0.5 * 0.5); // c[ii][ij] - e*b[j][r]
                       assertEquals(Math.sqrt(expectedTransformedValue2), root.getEntry(2, 1), 1.0e-10);
                   }

    @Test
                  public void testMatrixTransformationWithIndexMutation() {
                      // Create a positive definite matrix that will exercise the transformation logic
                      double[][] data = {
                          {4, 12, -16},
                          {12, 37, -43},
                          {-16, -43, 98}
                      };
                      RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                      double small = 1.0e-10;
                      
                      // Perform the decomposition
                      RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
                      RealMatrix root = decomposition.getRootMatrix();
                      
                      // Verify the root matrix values
                      // Expected values based on correct Cholesky decomposition
                      assertEquals(2.0, root.getEntry(0, 0), 1.0e-10);
                      assertEquals(6.0, root.getEntry(1, 0), 1.0e-10);
                      assertEquals(-8.0, root.getEntry(2, 0), 1.0e-10);
                      assertEquals(0.0, root.getEntry(0, 1), 1.0e-10);
                      assertEquals(1.0, root.getEntry(1, 1), 1.0e-10);
                      assertEquals(5.0, root.getEntry(2, 1), 1.0e-10);
                      
                      // Verify rank (should be 2 for this matrix)
                      assertEquals(2, decomposition.getRank());
                  }

    @Test
                 public void testCholeskyDecompositionDetectsIndexMutation1() {
                     // Create a test matrix that will exercise the transformation logic
                     double[][] data = {
                         {4, 2, 1},
                         {2, 5, 3},
                         {1, 3, 6}
                     };
                     RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                     double small = 1e-10;
                     
                     // Perform the decomposition
                     RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
                     RealMatrix root = decomposition.getRootMatrix();
                     
                     // Verify multiple elements in the root matrix
                     // The mutation would affect these values since they depend on correct index access
                     assertEquals(2.0, root.getEntry(0, 0), 1e-10);
                     assertEquals(1.0, root.getEntry(0, 1), 1e-10);
                     assertEquals(0.5, root.getEntry(0, 2), 1e-10);
                     assertEquals(0.0, root.getEntry(1, 0), 1e-10);
                     assertEquals(2.0, root.getEntry(1, 1), 1e-10);
                     assertEquals(1.5, root.getEntry(1, 2), 1e-10);
                     assertEquals(0.0, root.getEntry(2, 0), 1e-10);
                     assertEquals(0.0, root.getEntry(2, 1), 1e-10);
                     assertEquals(2.0, root.getEntry(2, 2), 1e-10);
                     
                     // Also verify the rank
                     assertEquals(3, decomposition.getRank());
                 }

    @Test
               public void testMatrixSymmetryAfterTransformation() {
                   // Create a symmetric positive definite matrix that will exercise the transformation logic
                   double[][] data = {
                       {4, 12, -16},
                       {12, 37, -43},
                       {-16, -43, 98}
                   };
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   // Perform decomposition with small value parameter
                   double small = 1.0e-10; // typical small value for numerical stability
                   RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
                   
                   // Get the internal matrix data after transformation
                   // Since we can't access 'c' directly, we'll verify symmetry through the root matrix
                   RealMatrix root = decomposition.getRootMatrix();
                   RealMatrix reconstructed = root.multiply(root.transpose());
                   
                   // Verify the reconstructed matrix is symmetric
                   for (int i = 0; i < reconstructed.getRowDimension(); i++) {
                       for (int j = 0; j < i; j++) {
                           // Check that off-diagonal elements are symmetric
                           assertEquals("Matrix should remain symmetric after transformation",
                                       reconstructed.getEntry(i, j),
                                       reconstructed.getEntry(j, i),
                                       1e-10);
                       }
                   }
                   
                   // Additional verification that the decomposition is correct
                   RealMatrix original = matrix;
                   RealMatrix difference = original.subtract(reconstructed);
                   double norm = difference.getNorm();
                   assertTrue("Decomposition should reconstruct original matrix",
                             norm < 1e-10);
               }

    @Test
           public void testCholeskyDecompositionMaintainsSymmetry() {
               // Create a symmetric positive definite matrix
               double[][] data = {
                   {4, 12, -16},
                   {12, 37, -43},
                   {-16, -43, 98}
               };
               RealMatrix matrix = MatrixUtils.createRealMatrix(data);
               
               // Perform decomposition
               RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, 1.0e-10);
               RealMatrix root = decomposition.getRootMatrix();
               
               // Reconstruct the original matrix from its decomposition
               RealMatrix reconstructed = root.multiply(root.transpose());
               
               // Verify symmetry was maintained by checking specific off-diagonal elements
               // The mutation would cause these to be wrong
               assertEquals("Element [1][2] should match", reconstructed.getEntry(1, 2), reconstructed.getEntry(2, 1), 1.0e-10);
               assertEquals("Element [0][2] should match", reconstructed.getEntry(0, 2), reconstructed.getEntry(2, 0), 1.0e-10);
               
               // Also verify the decomposition is correct by comparing with original matrix
               for (int i = 0; i < data.length; i++) {
                   for (int j = 0; j < data.length; j++) {
                       assertEquals("Decomposition should reconstruct original matrix", 
                                   matrix.getEntry(i, j), reconstructed.getEntry(i, j), 1.0e-10);
                   }
               }
           }

    @Test
          public void testCholeskyDecompositionDetectsIndexMutation2() {
              // Create a positive definite matrix that will exercise the j > 0 case
              double[][] data = {
                  {4, 12, -16},
                  {12, 37, -43},
                  {-16, -43, 98}
              };
              RealMatrix matrix = MatrixUtils.createRealMatrix(data);
              
              // Perform decomposition
              RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, 1.0e-10);
              RealMatrix root = decomposition.getRootMatrix();
              
              // Verify the root matrix values - these would be different with the mutation
              // Expected values computed from correct implementation
              assertEquals(2.0, root.getEntry(0, 0), 1.0e-10);
              assertEquals(6.0, root.getEntry(1, 0), 1.0e-10);
              assertEquals(-8.0, root.getEntry(2, 0), 1.0e-10);
              assertEquals(0.0, root.getEntry(0, 1), 1.0e-10);
              assertEquals(1.0, root.getEntry(1, 1), 1.0e-10);
              assertEquals(5.0, root.getEntry(2, 1), 1.0e-10);
              
              // Also verify rank is correct
              assertEquals(2, decomposition.getRank());
          }

    @Test
         public void testCholeskyDecompositionWithIndexPermutation() {
             // Create a matrix that will trigger index permutation
             double[][] data = {
                 {4, 2, 2},  // Largest diagonal element (4)
                 {2, 3, 1},  // Middle diagonal element (3)
                 {2, 1, 2}   // Smallest diagonal element (2)
             };
             RealMatrix matrix = MatrixUtils.createRealMatrix(data);
             double small = 1e-10;
             
             // Perform decomposition
             RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
             RealMatrix root = decomposition.getRootMatrix();
             
             // Expected root matrix (manually calculated)
             double[][] expectedData = {
                 {2.0, 0.0},  // First column is sqrt of diagonal
                 {1.0, Math.sqrt(2.0)},  // Second column depends on correct index handling
                 {1.0, 0.0}
             };
             RealMatrix expectedRoot = MatrixUtils.createRealMatrix(expectedData);
             
             // Verify the root matrix matches expected
             for (int i = 0; i < expectedRoot.getRowDimension(); i++) {
                 for (int j = 0; j < expectedRoot.getColumnDimension(); j++) {
                     assertEquals("Element [" + i + "," + j + "] differs",
                                 expectedRoot.getEntry(i, j),
                                 root.getEntry(i, j),
                                 1e-10);
                 }
             }
             
             // Also verify rank is correct
             assertEquals(2, decomposition.getRank());
         }

    @Test
        public void testCholeskyDecompositionDetectsSubtractionMutant() {
            // Create a positive definite matrix that will exercise the transformation logic
            double[][] data = {
                {4, 12, -16},
                {12, 37, -43},
                {-16, -43, 98}
            };
            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
            
            // Perform decomposition
            RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, 1.0e-10);
            RealMatrix root = decomposition.getRootMatrix();
            
            // Expected correct decomposition result (calculated manually)
            double[][] expectedRootData = {
                {2, 0, 0},
                {6, 1, 0},
                {-8, 5, 3}
            };
            RealMatrix expectedRoot = MatrixUtils.createRealMatrix(expectedRootData);
            
            // Verify the root matrix matches expected values
            // The mutant using addition instead of subtraction would produce different values
            for (int i = 0; i < expectedRoot.getRowDimension(); i++) {
                for (int j = 0; j < expectedRoot.getColumnDimension(); j++) {
                    assertEquals("Matrix element [" + i + "][" + j + "] differs",
                                expectedRoot.getEntry(i, j),
                                root.getEntry(i, j),
                                1.0e-10);
                }
            }
            
            // Also verify rank is correct
            assertEquals(3, decomposition.getRank());
        }

    @Test
       public void testCholeskyDecompositionDetectsDivisionMutant() {
           // Create a test matrix where b[j][r] will be 2 (not 1) during transformation
           // This ensures multiplication and division produce different results
           double[][] testData = {
               {4, 2, 2},
               {2, 5, 3},
               {2, 3, 6}
           };
           RealMatrix matrix = MatrixUtils.createRealMatrix(testData);
           double small = 1e-10;
           
           // Perform the decomposition
           RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
           RealMatrix root = decomposition.getRootMatrix();
           
           // Verify specific values in the root matrix that would be affected by the mutation
           // The original calculation (multiplication) would produce different results than the mutant (division)
           // We check values that are derived from the 'f' calculation
           
           // Expected values based on multiplication
           double expectedValue1 = 2.0; // From original calculation
           double expectedValue2 = 1.0; // From original calculation
           
           // These assertions will fail if the mutant is present because:
           // - With multiplication: 4 - (2 * 1) = 2
           // - With division: 4 - (2 / 1) = 2 (same when b[j][r]=1)
           // But with our test matrix, b[j][r] becomes 2 during processing:
           // - Original: value - (e * 2)
           // - Mutant: value - (e / 2)
           assertEquals("First value should match multiplication result", 
                       expectedValue1, root.getEntry(1, 0), 1e-10);
           assertEquals("Second value should match multiplication result", 
                       expectedValue2, root.getEntry(2, 0), 1e-10);
           
           // Additional check for rank to ensure full processing
           assertEquals("Matrix should be full rank", 3, decomposition.getRank());
       }

    @Test
      public void testMatrixTransformationPreservesOffDiagonalElements() {
          // Create a simple 2x2 positive definite matrix
          double[][] data = {
              {4.0, 1.0},
              {1.0, 4.0}
          };
          RealMatrix matrix = MatrixUtils.createRealMatrix(data);
          
          // Perform decomposition with small threshold
          double small = 1e-10;
          RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
          
          // Get the root matrix
          RealMatrix root = decomposition.getRootMatrix();
          
          // Verify the root matrix values
          // Expected root matrix (calculated manually):
          // [2.0   0.0 ]
          // [0.5   1.93649167]
          assertEquals(2.0, root.getEntry(0, 0), 1e-10);
          assertEquals(0.5, root.getEntry(1, 0), 1e-10);
          assertEquals(0.0, root.getEntry(0, 1), 1e-10);
          assertEquals(1.9364916731037085, root.getEntry(1, 1), 1e-10);
          
          // The mutant would set c[ii][ij] to 0 during transformation,
          // which would affect the final root matrix values, particularly the (1,1) entry
          // The original correct value is ~1.936, while the mutant would produce a different value
      }

    @Test
    public void testCholeskyDecompositionSymmetry() {
        // Create a symmetric positive definite matrix
        double[][] data = {
            {4, 12, -16},
            {12, 37, -43},
            {-16, -43, 98}
        };
        RealMatrix matrix = MatrixUtils.createRealMatrix(data);
        
        // Perform decomposition with small value parameter
        double small = 1.0e-10; // Define small value threshold
        RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
        RealMatrix root = decomposition.getRootMatrix();
        
        // Verify symmetry is maintained in the decomposition
        // Check a non-diagonal position that would be affected by the mutation
        double expectedVal = root.getEntry(0, 1);
        double mutatedVal = root.getEntry(1, 0);
        
        // The original code maintains symmetry, so these should be equal
        // The mutant would make them different
        assertEquals("Matrix symmetry not maintained in decomposition", 
                    expectedVal, mutatedVal, 1e-10);
        
        // Additional verification - check another non-diagonal position
        expectedVal = root.getEntry(0, 2);
        mutatedVal = root.getEntry(2, 0);
        assertEquals("Matrix symmetry not maintained in decomposition", 
                    expectedVal, mutatedVal, 1e-10);
        
        // Verify the decomposition is correct by reconstructing the original
        RealMatrix reconstructed = root.multiply(root.transpose());
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data.length; j++) {
                assertEquals("Decomposition not accurate at [" + i + "," + j + "]", 
                            matrix.getEntry(i, j), reconstructed.getEntry(i, j), 1e-10);
            }
        }
    }


}
