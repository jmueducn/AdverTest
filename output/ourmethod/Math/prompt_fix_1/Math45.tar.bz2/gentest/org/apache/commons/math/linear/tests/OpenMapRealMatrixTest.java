package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import org.apache.commons.math.exception.NumberIsTooLargeException;
import org.apache.commons.math.util.OpenIntToDoubleHashMap;
 
public class OpenMapRealMatrixTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                        public void testConstructor_ValidDimensions() {
                                            // Test normal valid dimensions
                                            OpenMapRealMatrix matrix1 = new OpenMapRealMatrix(10, 20);
                                            assertEquals(10, matrix1.getRowDimension());
                                            assertEquals(20, matrix1.getColumnDimension());
                                            
                                            // Test minimum valid dimensions
                                            OpenMapRealMatrix matrix2 = new OpenMapRealMatrix(1, 1);
                                            assertEquals(1, matrix2.getRowDimension());
                                            assertEquals(1, matrix2.getColumnDimension());
                                            
                                            // Test square matrix
                                            OpenMapRealMatrix matrix3 = new OpenMapRealMatrix(100, 100);
                                            assertEquals(100, matrix3.getRowDimension());
                                            assertEquals(100, matrix3.getColumnDimension());
                                        }

    @Test
                                        public void testConstructor_ZeroDimension() {
                                            // Test zero row dimension
                                            thrown.expect(IllegalArgumentException.class);
                                            new OpenMapRealMatrix(0, 5);
                                            
                                            // Test zero column dimension
                                            thrown.expect(IllegalArgumentException.class);
                                            new OpenMapRealMatrix(5, 0);
                                            
                                            // Test both dimensions zero
                                            thrown.expect(IllegalArgumentException.class);
                                            new OpenMapRealMatrix(0, 0);
                                        }

    @Test
                                        public void testConstructor_NegativeDimension() {
                                            // Test negative row dimension
                                            thrown.expect(IllegalArgumentException.class);
                                            new OpenMapRealMatrix(-1, 5);
                                            
                                            // Test negative column dimension
                                            thrown.expect(IllegalArgumentException.class);
                                            new OpenMapRealMatrix(5, -1);
                                            
                                            // Test both dimensions negative
                                            thrown.expect(IllegalArgumentException.class);
                                            new OpenMapRealMatrix(-1, -1);
                                        }

    @Test
                                        public void testConstructor_TooLargeDimensions() {
                                            // Test dimensions that would cause overflow
                                            thrown.expect(NumberIsTooLargeException.class);
                                            thrown.expectMessage("larger than");
                                            
                                            // This multiplication would exceed Integer.MAX_VALUE
                                            int largeDim = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                            new OpenMapRealMatrix(largeDim, largeDim);
                                        }

    @Test
                                        public void testConstructor_EntriesInitialization() {
                                            OpenMapRealMatrix matrix = new OpenMapRealMatrix(5, 5);
                                            
                                            // Verify all entries are initialized to 0.0
                                            for (int i = 0; i < 5; i++) {
                                                for (int j = 0; j < 5; j++) {
                                                    assertEquals(0.0, matrix.getEntry(i, j), 0.0001);
                                                }
                                            }
                                        }

    @Test
                                        public void testConstructor_MaxValidDimensions() {
                                            // Test dimensions just below the overflow threshold
                                            int maxDim = (int) Math.sqrt(Integer.MAX_VALUE);
                                            OpenMapRealMatrix matrix = new OpenMapRealMatrix(maxDim, maxDim);
                                            
                                            assertEquals(maxDim, matrix.getRowDimension());
                                            assertEquals(maxDim, matrix.getColumnDimension());
                                        }

    @Test
                                        public void testConstructor_NonSquareLargeMatrix() {
                                            // Test non-square matrix with large dimensions that don't cause overflow
                                            int rows = 10000;
                                            int cols = 20000;
                                            OpenMapRealMatrix matrix = new OpenMapRealMatrix(rows, cols);
                                            
                                            assertEquals(rows, matrix.getRowDimension());
                                            assertEquals(cols, matrix.getColumnDimension());
                                        }

    @Test
                                        public void testConstructor_CopyNullMatrix() {
                                            thrown.expect(NullPointerException.class);
                                            new OpenMapRealMatrix(null);
                                        }

    @Test
                                        public void testConstructor_VerifyDeepCopyOfEntries() {
                                            // Setup original matrix with actual entries
                                            OpenMapRealMatrix original = new OpenMapRealMatrix(2, 2);
                                            original.setEntry(0, 0, 1.5);
                                            original.setEntry(1, 1, 2.5);
                                    
                                            // Exercise constructor
                                            OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                    
                                            // Verify values were copied
                                            assertEquals(1.5, copy.getEntry(0, 0), 0.0001);
                                            assertEquals(2.5, copy.getEntry(1, 1), 0.0001);
                                    
                                            // Verify it's a deep copy by modifying original
                                            original.setEntry(0, 0, 3.0);
                                            assertEquals(1.5, copy.getEntry(0, 0), 0.0001); // Copy should remain unchanged
                                        }

    @Test
                                public void testConstructor_CopyValidMatrix() throws Exception {
                                    // Setup original matrix with mock entries
                                    OpenMapRealMatrix original = mock(OpenMapRealMatrix.class);
                                    when(original.getRowDimension()).thenReturn(3);
                                    when(original.getColumnDimension()).thenReturn(4);
                                    
                                    OpenIntToDoubleHashMap mockEntries = mock(OpenIntToDoubleHashMap.class);
                                    
                                    // Use reflection to set the private entries field in the original matrix
                                    Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                                    entriesField.setAccessible(true);
                                    entriesField.set(original, mockEntries);
                                
                                    // Exercise constructor
                                    OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                
                                    // Verify dimensions were copied
                                    assertEquals(3, copy.getRowDimension());
                                    assertEquals(4, copy.getColumnDimension());
                                    
                                    // Verify entries were copied using reflection
                                    OpenIntToDoubleHashMap copiedEntries = (OpenIntToDoubleHashMap) entriesField.get(copy);
                                    assertNotNull(copiedEntries);
                                }

    @Test
                                public void testConstructor_CopyMatrixWithZeroDimensions() throws Exception {
                                    // Setup original matrix with zero dimensions
                                    OpenMapRealMatrix original = mock(OpenMapRealMatrix.class);
                                    when(original.getRowDimension()).thenReturn(0);
                                    when(original.getColumnDimension()).thenReturn(0);
                                    
                                    // Create a real entries map (not mocked) since we can't mock private fields
                                    OpenIntToDoubleHashMap originalEntries = new OpenIntToDoubleHashMap();
                                    
                                    // Use reflection to set the private entries field
                                    Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                                    entriesField.setAccessible(true);
                                    entriesField.set(original, originalEntries);
                                    
                                    // Exercise constructor
                                    OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                    
                                    // Verify dimensions
                                    assertEquals(0, copy.getRowDimension());
                                    assertEquals(0, copy.getColumnDimension());
                                    
                                    // Verify entries were copied properly using reflection
                                    OpenIntToDoubleHashMap copiedEntries = (OpenIntToDoubleHashMap) entriesField.get(copy);
                                    assertNotNull(copiedEntries);
                                }

    @Test
                                public void testConstructor_CopyMatrixWithNullEntries() throws Exception {
                                    // Setup original matrix with null entries
                                    OpenMapRealMatrix original = mock(OpenMapRealMatrix.class);
                                    when(original.getRowDimension()).thenReturn(2);
                                    when(original.getColumnDimension()).thenReturn(2);
                                    
                                    // Use reflection to set private entries field to null
                                    Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                                    entriesField.setAccessible(true);
                                    entriesField.set(original, null);
                                    
                                    thrown.expect(NullPointerException.class);
                                    new OpenMapRealMatrix(original);
                                }

    @Test
                                public void testConstructorDimensions() {
                                    // Create a source matrix with different row and column dimensions
                                    OpenMapRealMatrix sourceMatrix = new OpenMapRealMatrix(3, 5); // 3 rows, 5 columns
                                    
                                    // Add some entries to ensure the copy constructor is properly exercised
                                    sourceMatrix.setEntry(0, 0, 1.0);
                                    sourceMatrix.setEntry(2, 4, 2.0);
                                    
                                    // Create a copy using the constructor under test
                                    OpenMapRealMatrix copiedMatrix = new OpenMapRealMatrix(sourceMatrix);
                                    
                                    // Verify dimensions are correctly copied (this would fail with the mutant)
                                    assertEquals("Row dimension should match source", 
                                                 sourceMatrix.getRowDimension(), copiedMatrix.getRowDimension());
                                    assertEquals("Column dimension should match source", 
                                                 sourceMatrix.getColumnDimension(), copiedMatrix.getColumnDimension());
                                    
                                    // Verify entries were properly copied
                                    assertEquals(1.0, copiedMatrix.getEntry(0, 0), 0.0001);
                                    assertEquals(2.0, copiedMatrix.getEntry(2, 4), 0.0001);
                                }

    @Test
                           public void testConstructorDimensions1() throws Exception {
                               // Test with different row and column dimensions to detect swapped parameters
                               int testRows = 3;
                               int testCols = 5;
                               
                               OpenMapRealMatrix matrix = new OpenMapRealMatrix(testRows, testCols);
                               
                               // Verify dimensions are stored correctly
                               assertEquals("Row dimension should match constructor parameter", 
                                            testRows, matrix.getRowDimension());
                               assertEquals("Column dimension should match constructor parameter", 
                                            testCols, matrix.getColumnDimension());
                               
                               // Use reflection to access private fields
                               Field rowsField = OpenMapRealMatrix.class.getDeclaredField("rows");
                               rowsField.setAccessible(true);
                               int actualRows = (int) rowsField.get(matrix);
                               
                               Field columnsField = OpenMapRealMatrix.class.getDeclaredField("columns");
                               columnsField.setAccessible(true);
                               int actualColumns = (int) columnsField.get(matrix);
                               
                               assertEquals("Internal rows field should match constructor parameter", 
                                            testRows, actualRows);
                               assertEquals("Internal columns field should match constructor parameter", 
                                            testCols, actualColumns);
                           }

    @Test
                           public void testConstructorWithLargeDimensions() {
                               // These values are chosen so that:
                               // As integers: 46341 * 46341 = -2147479015 (overflow)
                               // As longs: 46341L * 46341L = 2147488281L (valid, but > Integer.MAX_VALUE)
                               int largeDim = 46341;
                               
                               // Original code should throw exception since 46341*46341 > Integer.MAX_VALUE
                               thrown.expect(NumberIsTooLargeException.class);
                               thrown.expectMessage("2147488281");
                               
                               // This will fail with the mutated code because:
                               // Without the long cast, it does 46341*46341 as integers first (which overflows to negative)
                               // Then converts to long, so the check passes incorrectly
                               new OpenMapRealMatrix(largeDim, largeDim);
                           }

    @Test
                           public void testConstructorWithMaxSafeDimensions() {
                               // These values should work (sqrt(Integer.MAX_VALUE) ~= 46340)
                               int safeDim = 46340;
                               
                               // Should not throw exception
                               OpenMapRealMatrix matrix = new OpenMapRealMatrix(safeDim, safeDim);
                               assertEquals(safeDim, matrix.getRowDimension());
                               assertEquals(safeDim, matrix.getColumnDimension());
                           }

    @Test
                      public void testCopyConstructorWithMaxRows() {
                          // Create a mock matrix with Integer.MAX_VALUE rows
                          OpenMapRealMatrix original = new OpenMapRealMatrix(Integer.MAX_VALUE, 1);
                          
                          // Set some test values
                          original.setEntry(0, 0, 1.0);
                          original.setEntry(100, 0, 2.0);
                          
                          // The test will fail if there's an integer overflow issue due to the missing cast
                          OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                          
                          // Verify the copy has the same dimensions
                          assertEquals(Integer.MAX_VALUE, copy.getRowDimension());
                          assertEquals(1, copy.getColumnDimension());
                          
                          // Verify the entries were properly copied by checking sample values
                          assertEquals(1.0, copy.getEntry(0, 0), 0.0);
                          assertEquals(2.0, copy.getEntry(100, 0), 0.0);
                      }

    @Test
                      public void testConstructorSizeValidationWithDifferentDimensions() {
                          // This test will catch the mutant because:
                          // Original: 30000 * 20000 = 600000000 (valid)
                          // Mutant: 20000 * 20000 = 400000000 (valid)
                          // But if we use dimensions where row*col would exceed MAX_VALUE when rows != columns
                          
                          // Case 1: row > column, product just below MAX_VALUE
                          int bigRows = (int) Math.sqrt(Integer.MAX_VALUE) + 10000;
                          int smallCols = (int) Math.sqrt(Integer.MAX_VALUE) - 10000;
                          new OpenMapRealMatrix(bigRows, smallCols); // Should pass
                          
                          // Case 2: row < column, product just below MAX_VALUE
                          int smallRows = (int) Math.sqrt(Integer.MAX_VALUE) - 10000;
                          int bigCols = (int) Math.sqrt(Integer.MAX_VALUE) + 10000;
                          new OpenMapRealMatrix(smallRows, bigCols); // Should pass
                          
                          // Case 3: row > column, product exceeds MAX_VALUE
                          int veryBigRows = (int) Math.sqrt(Integer.MAX_VALUE) + 100000;
                          int verySmallCols = (int) Math.sqrt(Integer.MAX_VALUE) - 100000;
                          thrown.expect(NumberIsTooLargeException.class);
                          new OpenMapRealMatrix(veryBigRows, verySmallCols); // Should throw
                          
                          // Case 4: row < column, product exceeds MAX_VALUE
                          int verySmallRows = (int) Math.sqrt(Integer.MAX_VALUE) - 100000;
                          int veryBigCols = (int) Math.sqrt(Integer.MAX_VALUE) + 100000;
                          thrown.expect(NumberIsTooLargeException.class);
                          new OpenMapRealMatrix(verySmallRows, veryBigCols); // Should throw
                      }

    @Test
                      public void testCopyConstructorWithNonSquareMatrix() {
                          // Create a non-square matrix (2x3) where rows != columns
                          OpenMapRealMatrix original = new OpenMapRealMatrix(2, 3);
                          
                          // Set some values at positions where row != column
                          original.setEntry(0, 1, 1.5);  // row 0, column 1
                          original.setEntry(1, 0, 2.5);  // row 1, column 0
                          
                          // Create a copy using the constructor being tested
                          OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                          
                          // Verify dimensions are correctly copied
                          assertEquals(original.getRowDimension(), copy.getRowDimension());
                          assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                          
                          // Verify entries are correctly copied - these would fail with the mutant
                          assertEquals(1.5, copy.getEntry(0, 1), 0.0001);  // Tests lRow calculation
                          assertEquals(2.5, copy.getEntry(1, 0), 0.0001);  // Tests lRow calculation
                          
                          // Additional check for diagonal (where row == column) to ensure both cases are covered
                          original.setEntry(0, 0, 3.0);
                          OpenMapRealMatrix copy2 = new OpenMapRealMatrix(original);
                          assertEquals(3.0, copy2.getEntry(0, 0), 0.0001);
                      }

    @Test
                     public void testConstructorWithLargeDimensions1() {
                         // These values are chosen so that:
                         // - As ints: 46342 * 46342 = Integer.MAX_VALUE (overflow)
                         // - As longs: 46342L * 46342L = 2147487364 (valid)
                         int largeDim = 46342;
                         
                         try {
                             // Original code should work (due to early long conversion)
                             OpenMapRealMatrix matrix = new OpenMapRealMatrix(largeDim, largeDim);
                             
                             // Verify the matrix was created properly
                             assertEquals(largeDim, matrix.getRowDimension());
                             assertEquals(largeDim, matrix.getColumnDimension());
                         } catch (NumberIsTooLargeException e) {
                             // If we get here, the test fails - this indicates the mutant was caught
                             // because the multiplication overflowed before long conversion
                             fail("Constructor threw unexpected NumberIsTooLargeException");
                         }
                     }

    @Test
                public void testLargeColumnDimensionHandling() {
                    // Create a matrix with maximum column dimension
                    int maxColumns = Integer.MAX_VALUE;
                    int rows = 1;
                    
                    // Mock the entries map
                    OpenIntToDoubleHashMap mockEntries = new OpenIntToDoubleHashMap();
                    
                    // Create a source matrix with max columns
                    OpenMapRealMatrix source = new OpenMapRealMatrix(rows, maxColumns);
                    // We need to set the entries directly (using reflection since it's private)
                    try {
                        java.lang.reflect.Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                        entriesField.setAccessible(true);
                        entriesField.set(source, mockEntries);
                    } catch (Exception e) {
                        fail("Failed to set entries field via reflection");
                    }
                    
                    // Create a copy of the matrix - this will use the constructor being tested
                    OpenMapRealMatrix copy = new OpenMapRealMatrix(source);
                    
                    // Verify the column dimension was correctly copied
                    assertEquals(maxColumns, copy.getColumnDimension());
                    
                    // Test computeKey which likely uses the column dimension
                    // This would fail if the long conversion was incorrect
                    int testRow = 0;
                    int testCol = Integer.MAX_VALUE - 1;
                    
                    // Use reflection to access the private computeKey method
                    try {
                        java.lang.reflect.Method computeKeyMethod = OpenMapRealMatrix.class.getDeclaredMethod("computeKey", int.class, int.class);
                        computeKeyMethod.setAccessible(true);
                        int key = (int) computeKeyMethod.invoke(copy, testRow, testCol);
                        
                        // Verify the key computation is correct (this would fail with incorrect long conversion)
                        long expectedKey = (long)testRow * (long)maxColumns + (long)testCol;
                        assertEquals((int)expectedKey, key);
                    } catch (Exception e) {
                        fail("Failed to access computeKey method via reflection");
                    }
                }

    @Test
                public void testConstructorWithUnequalDimensions() {
                    // Test case where row != column to catch the mutation
                    // Original would calculate 500 * 1000 = 500,000 (valid)
                    // Mutated would calculate 500 * 500 = 250,000 (also valid but wrong)
                    // So we need a case where row*col would exceed MAX_VALUE but row*row wouldn't
                    
                    // This case would pass both original and mutated, so we need something more extreme
                    int largeButValid = (int) Math.sqrt(Integer.MAX_VALUE) - 1;
                    int veryLarge = Integer.MAX_VALUE / 2 + 1;
                    
                    // Test with unequal dimensions where one dimension is very large
                    // Original: would throw exception for 2 * (MAX_VALUE/2 + 1) > MAX_VALUE
                    // Mutated: would calculate 2 * 2 = 4 (no exception)
                    thrown.expect(NumberIsTooLargeException.class);
                    new OpenMapRealMatrix(2, veryLarge);
                    
                    // Additional test with different unequal dimensions
                    thrown.expect(NumberIsTooLargeException.class);
                    new OpenMapRealMatrix(100, Integer.MAX_VALUE / 50 + 1);
                }

    @Test
                public void testConstructorWithEqualDimensions() {
                    // This case wouldn't catch the mutation since row == column
                    // Included for completeness
                    int size = 100;
                    OpenMapRealMatrix matrix = new OpenMapRealMatrix(size, size);
                    assertEquals(size, matrix.getRowDimension());
                    assertEquals(size, matrix.getColumnDimension());
                }

    @Test
                public void testConstructorPreservesCorrectDimensions() {
                    // Create a non-square matrix (2x3) to test the dimension handling
                    OpenMapRealMatrix original = new OpenMapRealMatrix(2, 3);
                    
                    // Set some test values at different positions
                    original.setEntry(0, 0, 1.0);  // first row, first column
                    original.setEntry(1, 2, 2.0);  // last row, last column
                    
                    // Create a copy using the constructor under test
                    OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                    
                    // Verify dimensions are preserved
                    assertEquals(2, copy.getRowDimension());
                    assertEquals(3, copy.getColumnDimension());
                    
                    // Verify entries are correctly copied
                    assertEquals(1.0, copy.getEntry(0, 0), 0.0001);
                    assertEquals(2.0, copy.getEntry(1, 2), 0.0001);
                    
                    // Test edge case positions that would fail with the mutation
                    // The mutation would compute wrong keys for these positions
                    copy.setEntry(0, 2, 3.0);  // first row, last column
                    assertEquals(3.0, copy.getEntry(0, 2), 0.0001);
                    
                    copy.setEntry(1, 0, 4.0);  // last row, first column
                    assertEquals(4.0, copy.getEntry(1, 0), 0.0001);
                }

    @Test
               public void testConstructorWhenProductEqualsMaxValue() {
                   // Find dimensions where product equals Integer.MAX_VALUE
                   // Using 1 and Integer.MAX_VALUE as simplest case
                   int rows = 1;
                   int columns = Integer.MAX_VALUE;
                   
                   // Expect exception to be thrown
                   thrown.expect(NumberIsTooLargeException.class);
                   thrown.expectMessage(Long.toString(Integer.MAX_VALUE));
                   
                   // This should throw in original, but pass in mutated version
                   new OpenMapRealMatrix(rows, columns);
               }

    @Test
               public void testConstructorWhenProductExceedsMaxValue() {
                   // Using 2 and Integer.MAX_VALUE as product will exceed
                   int rows = 2;
                   int columns = Integer.MAX_VALUE;
                   
                   thrown.expect(NumberIsTooLargeException.class);
                   thrown.expectMessage(Long.toString(2L * Integer.MAX_VALUE));
                   
                   new OpenMapRealMatrix(rows, columns);
               }

    @Test
               public void testConstructorWhenProductBelowMaxValue() {
                   // Normal case where product is below max
                   int rows = 100;
                   int columns = 100;
                   
                   // Should not throw
                   OpenMapRealMatrix matrix = new OpenMapRealMatrix(rows, columns);
                   assertEquals(rows, matrix.getRowDimension());
                   assertEquals(columns, matrix.getColumnDimension());
               }

    @Test
               public void testConstructorWithMaxValueDimensions() {
                   // Dimensions that multiply to exactly Integer.MAX_VALUE
                   // Using 1 and Integer.MAX_VALUE since 1*MAX_VALUE = MAX_VALUE
                   int rows = 1;
                   int columns = Integer.MAX_VALUE;
                   
                   // Prepare a mock matrix with these dimensions
                   OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
                   when(mockMatrix.getRowDimension()).thenReturn(rows);
                   when(mockMatrix.getColumnDimension()).thenReturn(columns);
                   
                   // Expect exception for original code
                   thrown.expect(IllegalArgumentException.class);
                   thrown.expectMessage("Number of elements must be less than Integer.MAX_VALUE");
                   
                   // This should throw in original but not in mutant
                   new OpenMapRealMatrix(mockMatrix);
               }

    @Test
              public void testConstructorThrowsWhenTotalElementsExceedsMaxValue() {
                  // Choose dimensions where:
                  // (46341 * 46341) = 2,147,488,281 > Integer.MAX_VALUE (2,147,483,647)
                  // but 46341 + 46341 = 92,682 < Integer.MAX_VALUE
                  int largeDimension = 46341;
                  
                  thrown.expect(NumberIsTooLargeException.class);
                  thrown.expectMessage("2,147,488,281");
                  
                  // This should throw in original code but pass in mutant
                  new OpenMapRealMatrix(largeDimension, largeDimension);
              }

    @Test
         public void testConstructorThrowsWhenMatrixTooLarge() {
             // Create a matrix mock with dimensions that would make lRow * lCol > Integer.MAX_VALUE
             // but lRow + lCol < Integer.MAX_VALUE
             int largeDim = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
             OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
             when(mockMatrix.getRowDimension()).thenReturn(largeDim);
             when(mockMatrix.getColumnDimension()).thenReturn(largeDim);
             
             // Create a real matrix to get the entries from, since we can't mock private fields directly
             OpenMapRealMatrix realMatrix = new OpenMapRealMatrix(1, 1);
             try {
                 Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                 entriesField.setAccessible(true);
                 entriesField.set(mockMatrix, new OpenIntToDoubleHashMap());
             } catch (Exception e) {
                 fail("Failed to set private entries field via reflection");
             }
         
             // Expect NumberIsTooLargeException because the total size would exceed max
             thrown.expect(NumberIsTooLargeException.class);
             thrown.expectMessage(String.valueOf(Integer.MAX_VALUE));
         
             // This should throw in original code but not in mutated code
             new OpenMapRealMatrix(mockMatrix);
         }

    @Test
         public void testConstructorThrowsWhenSizeEqualsMaxValue() {
             // Calculate dimensions that will make row*col = Integer.MAX_VALUE
             // Using prime factors of Integer.MAX_VALUE (which is 2^31-1)
             int rows = 2147483647; // MAX_VALUE itself
             int cols = 1;
             
             thrown.expect(NumberIsTooLargeException.class);
             // Verify the exception message contains the correct comparison
             thrown.expectMessage("2147483647 >= 2147483647");
             
             // This should throw in original, but not in mutant
             new OpenMapRealMatrix(rows, cols);
         }

    @Test
         public void testConstructorThrowsWhenSizeExceedsMaxValue() {
             int rows = 46341; // sqrt(Integer.MAX_VALUE) + 1
             int cols = 46341;
             
             thrown.expect(NumberIsTooLargeException.class);
             thrown.expectMessage("2147699721 >= 2147483647");
             
             new OpenMapRealMatrix(rows, cols);
         }

    @Test
    public void testConstructorWithMaxSizeMatrix() throws Exception {
        // Create a mock matrix with dimensions that multiply to Integer.MAX_VALUE
        // We need to find factors of Integer.MAX_VALUE (which is prime, so only 1 and MAX_VALUE)
        // So we'll use 1 row and Integer.MAX_VALUE columns
        OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
        when(mockMatrix.getRowDimension()).thenReturn(1);
        when(mockMatrix.getColumnDimension()).thenReturn(Integer.MAX_VALUE);
        
        // Use reflection to set the private entries field
        OpenIntToDoubleHashMap entries = new OpenIntToDoubleHashMap();
        Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
        entriesField.setAccessible(true);
        entriesField.set(mockMatrix, entries);
        
        // The original code should handle this case without exception
        // The mutant would throw an exception here
        new OpenMapRealMatrix(mockMatrix);
        
        // If we want to test the opposite case (where it should throw):
        // For a matrix that exceeds MAX_VALUE (1 row and MAX_VALUE+1 columns)
        OpenMapRealMatrix invalidMatrix = mock(OpenMapRealMatrix.class);
        when(invalidMatrix.getRowDimension()).thenReturn(1);
        // Cast to int since getColumnDimension() returns int
        when(invalidMatrix.getColumnDimension()).thenReturn(Integer.MAX_VALUE);
        
        thrown.expect(NumberIsTooLargeException.class);
        new OpenMapRealMatrix(invalidMatrix);
    }


}
